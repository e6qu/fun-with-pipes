
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ef 00 00 	mov    0xefc9(%rip),%rax        # 11fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 ed 00 00    	push   0xede2(%rip)        # 11e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 ed 00 00    	jmp    *0xede4(%rip)        # 11e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e ec 00 00    	jmp    *0xec4e(%rip)        # 11fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e ea 00 00    	jmp    *0xea6e(%rip)        # 11e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 ea 00 00    	jmp    *0xea66(%rip)        # 11e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e ea 00 00    	jmp    *0xea5e(%rip)        # 11e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 ea 00 00    	jmp    *0xea56(%rip)        # 11e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e ea 00 00    	jmp    *0xea4e(%rip)        # 11e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 ea 00 00    	jmp    *0xea46(%rip)        # 11e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e ea 00 00    	jmp    *0xea3e(%rip)        # 11e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 ea 00 00    	jmp    *0xea36(%rip)        # 11e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e ea 00 00    	jmp    *0xea2e(%rip)        # 11e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 ea 00 00    	jmp    *0xea26(%rip)        # 11e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e ea 00 00    	jmp    *0xea1e(%rip)        # 11e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 ea 00 00    	jmp    *0xea16(%rip)        # 11e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e ea 00 00    	jmp    *0xea0e(%rip)        # 11e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 ea 00 00    	jmp    *0xea06(%rip)        # 11e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe e9 00 00    	jmp    *0xe9fe(%rip)        # 11e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 e9 00 00    	jmp    *0xe9f6(%rip)        # 11e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee e9 00 00    	jmp    *0xe9ee(%rip)        # 11e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 e9 00 00    	jmp    *0xe9e6(%rip)        # 11ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de e9 00 00    	jmp    *0xe9de(%rip)        # 11ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 e9 00 00    	jmp    *0xe9d6(%rip)        # 11eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce e9 00 00    	jmp    *0xe9ce(%rip)        # 11eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 e9 00 00    	jmp    *0xe9c6(%rip)        # 11ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be e9 00 00    	jmp    *0xe9be(%rip)        # 11ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 e9 00 00    	jmp    *0xe9b6(%rip)        # 11ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae e9 00 00    	jmp    *0xe9ae(%rip)        # 11ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 e9 00 00    	jmp    *0xe9a6(%rip)        # 11ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e e9 00 00    	jmp    *0xe99e(%rip)        # 11ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 e9 00 00    	jmp    *0xe996(%rip)        # 11ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e e9 00 00    	jmp    *0xe98e(%rip)        # 11ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 e9 00 00    	jmp    *0xe986(%rip)        # 11f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e e9 00 00    	jmp    *0xe97e(%rip)        # 11f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 e9 00 00    	jmp    *0xe976(%rip)        # 11f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e e9 00 00    	jmp    *0xe96e(%rip)        # 11f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 e9 00 00    	jmp    *0xe966(%rip)        # 11f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e e9 00 00    	jmp    *0xe95e(%rip)        # 11f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 e9 00 00    	jmp    *0xe956(%rip)        # 11f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e e9 00 00    	jmp    *0xe94e(%rip)        # 11f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 e9 00 00    	jmp    *0xe946(%rip)        # 11f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e e9 00 00    	jmp    *0xe93e(%rip)        # 11f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 e9 00 00    	jmp    *0xe936(%rip)        # 11f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e e9 00 00    	jmp    *0xe92e(%rip)        # 11f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 e9 00 00    	jmp    *0xe926(%rip)        # 11f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e e9 00 00    	jmp    *0xe91e(%rip)        # 11f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 e9 00 00    	jmp    *0xe916(%rip)        # 11f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e e9 00 00    	jmp    *0xe90e(%rip)        # 11f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 e9 00 00    	jmp    *0xe906(%rip)        # 11f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe e8 00 00    	jmp    *0xe8fe(%rip)        # 11f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 e8 00 00    	jmp    *0xe8f6(%rip)        # 11f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee e8 00 00    	jmp    *0xe8ee(%rip)        # 11f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 e8 00 00    	jmp    *0xe8e6(%rip)        # 11fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de e8 00 00    	jmp    *0xe8de(%rip)        # 11fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 e8 00 00    	jmp    *0xe8d6(%rip)        # 11fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce e8 00 00    	jmp    *0xe8ce(%rip)        # 11fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 e8 00 00    	jmp    *0xe8c6(%rip)        # 11fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a a9 00 00 	lea    0xa97a(%rip),%r9        # e091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 a9 00 00 	lea    0xa977(%rip),%r8        # e095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 cb 00 00 	lea    0xcba1(%rip),%rax        # 10320 <fwp_fn_table>
    377f:	48 89 05 32 0c 02 00 	mov    %rax,0x20c32(%rip)        # 243b8 <fwp_fns>
    3786:	48 8b 05 93 e8 00 00 	mov    0xe893(%rip),%rax        # 12020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c 0c 02 00 	mov    %rax,0x20c2c(%rip)        # 243c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 aa 00 00 	lea    0xaa59(%rip),%rdi        # e1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 e8 00 00 	mov    0xe818(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 cf 9d 00 00 	lea    0x9dcf(%rip),%rdx        # d630 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 e7 00 00 	mov    0xe783(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 e7 01 00    	mov    0x1e7d8(%rip),%eax        # 22080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 a9 00 00 	lea    0xa909(%rip),%rdi        # e202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 96 b0 00 00 	lea    0xb096(%rip),%rdi        # e9a0 <_IO_stdin_used+0x9a0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 50 b0 00 00 	lea    0xb050(%rip),%rdi        # e978 <_IO_stdin_used+0x978>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 14 b0 00 00 	lea    0xb014(%rip),%rdi        # e948 <_IO_stdin_used+0x948>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d e0 af 00 00 	lea    0xafe0(%rip),%rdi        # e920 <_IO_stdin_used+0x920>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 e6 00 00    	call   *0xe653(%rip)        # 11fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 e6 00 00 	lea    0xe699(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 e6 00 00 	lea    0xe692(%rip),%rax        # 12020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 e6 00 00 	mov    0xe636(%rip),%rax        # 11fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 e6 00 00 	lea    0xe669(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 e6 00 00 	lea    0xe662(%rip),%rsi        # 12020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 e6 00 00 	mov    0xe605(%rip),%rax        # 11fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d e6 00 00 00 	cmpb   $0x0,0xe64d(%rip)        # 12048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 e5 00 00 	cmpq   $0x0,0xe5e2(%rip)        # 11fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 e5 00 00 	mov    0xe5f6(%rip),%rdi        # 12008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 e6 00 00 01 	movb   $0x1,0xe625(%rip)        # 12048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce e4 01 00 	add    0x1e4ce(%rip),%rdx        # 220f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc e4 01 00 	add    0x1e4bc(%rip),%rax        # 220f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 07 02 00 	mov    0x20749(%rip),%rdi        # 243c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 e3 00 00 	mov    0xe394(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 e3 00 00 	mov    0xe381(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 a3 00 00 	lea    0xa345(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 e3 00 00 	mov    0xe372(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 ea 01 00 	mov    0x1ea41(%rip),%rax        # 22740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 e3 01 00 	mov    0x1e381(%rip),%rax        # 22100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d e3 01 00 	sub    0x1e36d(%rip),%rax        # 220f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd ac 00 00 	lea    0xacbd(%rip),%rsi        # ea80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b fd 01 00 	mov    0x1fd5b(%rip),%rax        # 23b50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 fd 01 00 	lea    0x1fd54(%rip),%r8        # 23b50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 fd 01 00 	mov    0x1fd35(%rip),%rbx        # 23b38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 fd 01 00 	mov    0x1fd45(%rip),%rcx        # 23b58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 fc 01 00 	mov    0x1fce1(%rip),%rdi        # 23b40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a fd 01 00 	sub    %rsi,0x1fd2a(%rip)        # 23b90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba fc 01 00 	mov    0x1fcba(%rip),%rax        # 23b30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 fc 01 00 	add    0x1fc70(%rip),%rdi        # 23b10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e fc 01 00 	mov    0x1fc7e(%rip),%rsi        # 23b40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c fc 01 00 	mov    0x1fc8c(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b fc 01 00 	mov    %r12,0x1fc3b(%rip)        # 23b40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 fc 01 00 	mov    %rbp,0x1fc29(%rip)        # 23b38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e fc 01 00 	cmp    %rdi,0x1fc0e(%rip)        # 23b28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 fc 01 00 	mov    %rdi,0x1fc05(%rip)        # 23b28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 fc 01 00 	sub    %rdi,0x1fc49(%rip)        # 23b90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 fb 01 00 	mov    0x1fbf1(%rip),%rax        # 23b48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea fb 01 00 	lea    0x1fbea(%rip),%r8        # 23b48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd df 00 00 	mov    0xdffd(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 9f 00 00 	lea    0x9fb4(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 e6 01 00 	cmp    0x1e689(%rip),%rdi        # 22740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f e6 01 00 	mov    0x1e64f(%rip),%rax        # 22720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d e6 01 00 	mov    %rdi,0x1e62d(%rip)        # 22720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 e6 01 00 	mov    %rdi,0x1e609(%rip)        # 22728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db 9f 00 00 	lea    0x9fdb(%rip),%rsi        # e13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 9e 00 00 	lea    0x9ea7(%rip),%rsi        # e01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 de 00 00 	mov    0xde78(%rip),%rdi        # 12040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 9e 00 00 	lea    0x9e51(%rip),%rdx        # e020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 de 00 00 	mov    0xde60(%rip),%rdi        # 12040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 dd 00 00 	mov    0xdd71(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 9d 00 00 	lea    0x9d28(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 9d 00 00 	lea    0x9d32(%rip),%rdi        # e02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 9c 00 00 	lea    0x9cba(%rip),%rdi        # e049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 70 a2 00 00 	lea    0xa270(%rip),%rdi        # e610 <_IO_stdin_used+0x610>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 10 a7 00 	movdqa 0xa710(%rip),%xmm0        # ead0 <msg.4+0x50>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a ff 01 00 	add    0x1ff9a(%rip),%rax        # 243b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d cc a1 00 00 	lea    0xa1cc(%rip),%rdi        # e640 <_IO_stdin_used+0x640>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 dc 01 00 	cmp    %rax,0x1dc55(%rip)        # 220e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 dc 01 00 	add    0x1dc50(%rip),%rax        # 220f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d b5 a1 00 00 	lea    0xa1b5(%rip),%rdi        # e670 <_IO_stdin_used+0x670>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 9b 00 00 	lea    0x9b92(%rip),%r8        # e065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 99 00 00 	lea    0x99e7(%rip),%r8        # e074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 98 00 00 	lea    0x9874(%rip),%r8        # e06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 96 00 00 	lea    0x964c(%rip),%rdi        # e079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 97 00 00 	lea    0x9736(%rip),%rsi        # e184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 f0 01 00 	mov    0x1f065(%rip),%r9        # 23b28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be f0 01 00 	mov    0x1f0be(%rip),%r8        # 23b88 <fwp_heap+0x1428>
    4aca:	48 8d 15 ef 9b 00 00 	lea    0x9bef(%rip),%rdx        # e6c0 <_IO_stdin_used+0x6c0>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 f0 01 00 	mov    0x1f0a6(%rip),%rcx        # 23b80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 f0 01 	movsd  0x1f0b4(%rip),%xmm1        # 23ba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 f0 01 	movsd  0x1f0a4(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 d5 00 00 	mov    0xd545(%rip),%rdi        # 12040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 a8 9f 00 	movdqa 0x9fa8(%rip),%xmm0        # eae0 <msg.4+0x60>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f eb 01 00 	lea    0x1eb5f(%rip),%rax        # 236a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 d1 9f 00 	movdqa 0x9fd1(%rip),%xmm2        # eb20 <msg.4+0xa0>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 eb 01 00 	movaps %xmm0,0x1eb05(%rip)        # 23660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 8d 9f 00 	movdqa 0x9f8d(%rip),%xmm0        # eaf0 <msg.4+0x70>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 ef 01 00 01 	movl   $0x1,0x1ef93(%rip)        # 23b04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 ea 01 00 	movaps %xmm0,0x1eaf3(%rip)        # 23670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 7b 9f 00 	movdqa 0x9f7b(%rip),%xmm0        # eb00 <msg.4+0x80>
    4b84:	00 
    4b85:	0f 29 05 f4 ea 01 00 	movaps %xmm0,0x1eaf4(%rip)        # 23680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 7c 9f 00 	movdqa 0x9f7c(%rip),%xmm0        # eb10 <msg.4+0x90>
    4b93:	00 
    4b94:	0f 29 05 f5 ea 01 00 	movaps %xmm0,0x1eaf5(%rip)        # 23690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 db 01 00 	lea    0x1db75(%rip),%r8        # 22760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 ee 01 00 	mov    %rax,0x1ee90(%rip)        # 23b18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e ee 01 00 	mov    %r12,0x1ee6e(%rip)        # 23b20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 ee 01 00 	mov    %rax,0x1ee57(%rip)        # 23b10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 ee 01 00 	mov    %rbx,0x1ee70(%rip)        # 23b30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 ee 01 00 	mov    %rsi,0x1ee99(%rip)        # 23b60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 93 00 00 	lea    0x93d6(%rip),%rdi        # e0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 ee 01 00 	mov    %rax,0x1ee78(%rip)        # 23b58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc ed 01 00    	mov    %eax,0x1edfc(%rip)        # 23b08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec d9 01 00 	mov    0x1d9ec(%rip),%r8        # 22720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c d9 01 00 	mov    %rbx,0x1d91c(%rip)        # 22728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 d9 01 00 	mov    %r8,0x1d908(%rip)        # 22720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 92 00 00 	lea    0x9239(%rip),%rdi        # e0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd d1 01 00 	lea    0x1d1dd(%rip),%rdi        # 220a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 d1 01 00 	movaps %xmm0,0x1d1c5(%rip)        # 220a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 d1 01 00 	mov    %rax,0x1d1a1(%rip)        # 22088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 d1 01 00 	movaps %xmm0,0x1d1c2(%rip)        # 220b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 d1 01 00 	movaps %xmm0,0x1d1c6(%rip)        # 220c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 d1 01 00 	mov    %rdx,0x1d1c7(%rip)        # 220d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 91 00 00 	lea    0x9190(%rip),%rdi        # e0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 d7 01 00 	mov    0x1d797(%rip),%rbx        # 22718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca cf 00 00 	mov    0xcfca(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d cb 96 00 00 	lea    0x96cb(%rip),%rdi        # e748 <_IO_stdin_used+0x748>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d d6 01 00 	mov    0x1d66d(%rip),%rax        # 22720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 d6 01 00 	mov    %rdx,0x1d647(%rip)        # 22720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 d5 01 00 	mov    0x1d594(%rip),%rbx        # 22718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 d5 01 00 	mov    %rbx,0x1d551(%rip)        # 22718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 d5 01 00 	mov    %rdx,0x1d551(%rip)        # 22728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 d5 01 00 	lea    0x1d566(%rip),%rsi        # 22760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 f0 01 00 	addq   $0x1,0x1f0e5(%rip)        # 243a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 9f 94 00 00 	lea    0x949f(%rip),%rdi        # e778 <_IO_stdin_used+0x778>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d b0 94 00 00 	lea    0x94b0(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 8d 00 00 	lea    0x8dd4(%rip),%rdi        # e0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e d4 01 00 	lea    0x1d41e(%rip),%rcx        # 22760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f f0 01 00 	subq   $0x1,0x1f01f(%rip)        # 243a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 0b 94 00 00 	lea    0x940b(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 f0 01 00 	cmpq   $0x0,0x1f000(%rip)        # 243a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 ef 01 00 	sub    %rax,0x1ef55(%rip)        # 243b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 ef 01 00 	add    %r12,0x1ef33(%rip)        # 243b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f e6 01 00 	mov    0x1e68f(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c d2 01 00 	lea    0x1d28c(%rip),%rax        # 22760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 e5 01 00 	add    0x1e5e3(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 e5 01 00 	mov    0x1e5b0(%rip),%rsi        # 23b10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 e5 01 00 	mov    0x1e5d1(%rip),%rax        # 23b38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 e5 01 00 	add    0x1e5c5(%rip),%r8        # 23b58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d e5 01 	addsd  0x1e58d(%rip),%xmm0        # 23ba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 d1 01 00 	lea    0x1d142(%rip),%rax        # 22760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c e5 01 00 	sub    %rdi,0x1e54c(%rip)        # 23b80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 e5 01 	movsd  %xmm0,0x1e564(%rip)        # 23ba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e e5 01 00 	sub    %rdx,0x1e51e(%rip)        # 23b80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 e5 01 	addsd  0x1e524(%rip),%xmm0        # 23ba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 e5 01 	movsd  %xmm0,0x1e518(%rip)        # 23ba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af e4 01 00 	mov    0x1e4af(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 e4 01 00 	add    %rcx,0x1e4a9(%rip)        # 23b90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 e4 01 00 	cmp    0x1e462(%rip),%r9        # 23b50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 e4 01 00 	mov    %r9,0x1e459(%rip)        # 23b50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a e4 01 00 	cmp    0x1e44a(%rip),%r9        # 23b48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d e4 01 00 	mov    %r9,0x1e43d(%rip)        # 23b48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 e3 01 00 	add    0x1e353(%rip),%rdi        # 23b58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 cf 01 00 	lea    0x1cf30(%rip),%r15        # 22760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 e2 01 00 	add    0x1e2a0(%rip),%r12        # 23b10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 e2 01 00 	add    0x1e2f9(%rip),%rax        # 23b80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 e2 01 00 	cmp    %rax,0x1e2f8(%rip)        # 23b88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 e2 01 00 	mov    %rax,0x1e2e9(%rip)        # 23b80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 e2 01 00 	mov    %rax,0x1e2e8(%rip)        # 23b88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 e2 01 	addsd  0x1e2e4(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc e2 01 	movsd  %xmm0,0x1e2dc(%rip)        # 23b98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 e2 01 00    	mov    0x1e223(%rip),%eax        # 23b04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f ce 01 00 	lea    0x1ce5f(%rip),%rdi        # 22760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 e2 01 00 	add    0x1e218(%rip),%rax        # 23b80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 e2 01 00 	cmp    %rax,0x1e213(%rip)        # 23b88 <fwp_heap+0x1428>
    5975:	48 89 05 04 e2 01 00 	mov    %rax,0x1e204(%rip)        # 23b80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 e2 01 00 	mov    %rax,0x1e203(%rip)        # 23b88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff e1 01 	addsd  0x1e1ff(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 e1 01 	movsd  %xmm0,0x1e1f7(%rip)        # 23b98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae e0 01 00    	mov    0x1e0ae(%rip),%eax        # 23b04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 cc 01 00 	lea    0x1cce5(%rip),%rax        # 22760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b e0 01 00 	add    0x1e09b(%rip),%rax        # 23b80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a e0 01 00 	cmp    %rax,0x1e09a(%rip)        # 23b88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b e0 01 00 	mov    %rax,0x1e08b(%rip)        # 23b80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a e0 01 00 	mov    %rax,0x1e08a(%rip)        # 23b88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 e0 01 	addsd  0x1e086(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e e0 01 	movsd  %xmm0,0x1e07e(%rip)        # 23b98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_data.part.0.constprop.0>:
    5b70:	41 56                	push   %r14
    5b72:	41 89 fe             	mov    %edi,%r14d
    5b75:	41 54                	push   %r12
    5b77:	49 89 f4             	mov    %rsi,%r12
    5b7a:	55                   	push   %rbp
    5b7b:	53                   	push   %rbx
    5b7c:	48 83 ec 08          	sub    $0x8,%rsp
    5b80:	8b 05 7e df 01 00    	mov    0x1df7e(%rip),%eax        # 23b04 <fwp_heap+0x13a4>
    5b86:	85 c0                	test   %eax,%eax
    5b88:	0f 84 fa 00 00 00    	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5b8e:	0f b6 05 6d db 01 00 	movzbl 0x1db6d(%rip),%eax        # 23702 <fwp_heap+0xfa2>
    5b95:	48 8d 15 c4 cb 01 00 	lea    0x1cbc4(%rip),%rdx        # 22760 <fwp_heap>
    5b9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5ba3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ba7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5bab:	48 8b 18             	mov    (%rax),%rbx
    5bae:	48 85 db             	test   %rbx,%rbx
    5bb1:	0f 84 a9 00 00 00    	je     5c60 <fwp_data.part.0.constprop.0+0xf0>
    5bb7:	48 8b 13             	mov    (%rbx),%rdx
    5bba:	48 f7 d2             	not    %rdx
    5bbd:	48 89 10             	mov    %rdx,(%rax)
    5bc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5bc4:	76 1b                	jbe    5be1 <fwp_data.part.0.constprop.0+0x71>
    5bc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5bca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5bce:	31 f6                	xor    %esi,%esi
    5bd0:	48 c1 e8 03          	shr    $0x3,%rax
    5bd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5bdb:	00 
    5bdc:	e8 df d8 ff ff       	call   34c0 <memset@plt>
    5be1:	48 89 e8             	mov    %rbp,%rax
    5be4:	48 03 05 95 df 01 00 	add    0x1df95(%rip),%rax        # 23b80 <fwp_heap+0x1420>
    5beb:	0f 82 a8 00 00 00    	jb     5c99 <fwp_data.part.0.constprop.0+0x129>
    5bf1:	48 39 05 90 df 01 00 	cmp    %rax,0x1df90(%rip)        # 23b88 <fwp_heap+0x1428>
    5bf8:	48 89 05 81 df 01 00 	mov    %rax,0x1df81(%rip)        # 23b80 <fwp_heap+0x1420>
    5bff:	73 07                	jae    5c08 <fwp_data.part.0.constprop.0+0x98>
    5c01:	48 89 05 80 df 01 00 	mov    %rax,0x1df80(%rip)        # 23b88 <fwp_heap+0x1428>
    5c08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c11:	f2 0f 58 05 7f df 01 	addsd  0x1df7f(%rip),%xmm0        # 23b98 <fwp_heap+0x1438>
    5c18:	00 
    5c19:	f2 0f 11 05 77 df 01 	movsd  %xmm0,0x1df77(%rip)        # 23b98 <fwp_heap+0x1438>
    5c20:	00 
    5c21:	b8 02 00 00 00       	mov    $0x2,%eax
    5c26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c37:	49 8b 04 24          	mov    (%r12),%rax
    5c3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c48:	48 83 c4 08          	add    $0x8,%rsp
    5c4c:	48 89 d8             	mov    %rbx,%rax
    5c4f:	5b                   	pop    %rbx
    5c50:	5d                   	pop    %rbp
    5c51:	41 5c                	pop    %r12
    5c53:	41 5e                	pop    %r14
    5c55:	c3                   	ret
    5c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c5d:	00 00 00 
    5c60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c64:	48 85 db             	test   %rbx,%rbx
    5c67:	74 1f                	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c6d:	48 29 da             	sub    %rbx,%rdx
    5c70:	48 39 ea             	cmp    %rbp,%rdx
    5c73:	72 13                	jb     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c7d:	e9 3e ff ff ff       	jmp    5bc0 <fwp_data.part.0.constprop.0+0x50>
    5c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c88:	31 f6                	xor    %esi,%esi
    5c8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c8f:	e8 bc fd ff ff       	call   5a50 <fwp_heap_alloc>
    5c94:	48 89 c3             	mov    %rax,%rbx
    5c97:	eb 88                	jmp    5c21 <fwp_data.part.0.constprop.0+0xb1>
    5c99:	e8 12 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c9e:	66 90                	xchg   %ax,%ax

0000000000005ca0 <fwp_p_ad_push.constprop.0>:
    5ca0:	41 57                	push   %r15
    5ca2:	41 56                	push   %r14
    5ca4:	41 55                	push   %r13
    5ca6:	49 89 d5             	mov    %rdx,%r13
    5ca9:	41 54                	push   %r12
    5cab:	49 89 fc             	mov    %rdi,%r12
    5cae:	55                   	push   %rbp
    5caf:	53                   	push   %rbx
    5cb0:	48 83 ec 38          	sub    $0x38,%rsp
    5cb4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5cb9:	48 85 ff             	test   %rdi,%rdi
    5cbc:	79 09                	jns    5cc7 <fwp_p_ad_push.constprop.0+0x27>
    5cbe:	48 85 d2             	test   %rdx,%rdx
    5cc1:	0f 88 a9 01 00 00    	js     5e70 <fwp_p_ad_push.constprop.0+0x1d0>
    5cc7:	48 89 f8             	mov    %rdi,%rax
    5cca:	48 89 0c 24          	mov    %rcx,(%rsp)
    5cce:	48 09 d0             	or     %rdx,%rax
    5cd1:	0f 89 79 01 00 00    	jns    5e50 <fwp_p_ad_push.constprop.0+0x1b0>
    5cd7:	48 89 f8             	mov    %rdi,%rax
    5cda:	48 c1 f8 20          	sar    $0x20,%rax
    5cde:	48 85 ff             	test   %rdi,%rdi
    5ce1:	79 24                	jns    5d07 <fwp_p_ad_push.constprop.0+0x67>
    5ce3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5ce8:	48 89 d0             	mov    %rdx,%rax
    5ceb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5cf2:	00 
    5cf3:	49 89 d4             	mov    %rdx,%r12
    5cf6:	48 c1 f8 20          	sar    $0x20,%rax
    5cfa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5d01:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5d07:	48 89 c7             	mov    %rax,%rdi
    5d0a:	e8 71 e7 ff ff       	call   4480 <fwp_tape_of>
    5d0f:	48 89 c3             	mov    %rax,%rbx
    5d12:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5d17:	0f 85 f0 02 00 00    	jne    600d <fwp_p_ad_push.constprop.0+0x36d>
    5d1d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5d21:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5d28:	0f 8f 51 02 00 00    	jg     5f7f <fwp_p_ad_push.constprop.0+0x2df>
    5d2e:	44 89 e0             	mov    %r12d,%eax
    5d31:	49 39 c7             	cmp    %rax,%r15
    5d34:	0f 8e 51 02 00 00    	jle    5f8b <fwp_p_ad_push.constprop.0+0x2eb>
    5d3a:	4d 85 ed             	test   %r13,%r13
    5d3d:	78 0c                	js     5d4b <fwp_p_ad_push.constprop.0+0xab>
    5d3f:	44 89 e8             	mov    %r13d,%eax
    5d42:	49 39 c7             	cmp    %rax,%r15
    5d45:	0f 8e 40 02 00 00    	jle    5f8b <fwp_p_ad_push.constprop.0+0x2eb>
    5d4b:	4d 89 fe             	mov    %r15,%r14
    5d4e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5d52:	49 8d 46 01          	lea    0x1(%r14),%rax
    5d56:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5d5c:	0f 87 1d 02 00 00    	ja     5f7f <fwp_p_ad_push.constprop.0+0x2df>
    5d62:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5d66:	48 39 e8             	cmp    %rbp,%rax
    5d69:	0f 8e 31 01 00 00    	jle    5ea0 <fwp_p_ad_push.constprop.0+0x200>
    5d6f:	48 85 ed             	test   %rbp,%rbp
    5d72:	b9 40 00 00 00       	mov    $0x40,%ecx
    5d77:	48 0f 44 e9          	cmove  %rcx,%rbp
    5d7b:	48 39 e8             	cmp    %rbp,%rax
    5d7e:	7e 20                	jle    5da0 <fwp_p_ad_push.constprop.0+0x100>
    5d80:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5d87:	0f 8f 03 01 00 00    	jg     5e90 <fwp_p_ad_push.constprop.0+0x1f0>
    5d8d:	48 01 ed             	add    %rbp,%rbp
    5d90:	48 39 e8             	cmp    %rbp,%rax
    5d93:	7f eb                	jg     5d80 <fwp_p_ad_push.constprop.0+0xe0>
    5d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d9c:	00 00 00 00 
    5da0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5da7:	00 
    5da8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5dac:	48 89 c6             	mov    %rax,%rsi
    5daf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5db4:	e8 17 d8 ff ff       	call   35d0 <realloc@plt>
    5db9:	48 85 c0             	test   %rax,%rax
    5dbc:	0f 84 d5 01 00 00    	je     5f97 <fwp_p_ad_push.constprop.0+0x2f7>
    5dc2:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5dc6:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5dca:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5dce:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5dd2:	48 89 e9             	mov    %rbp,%rcx
    5dd5:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5dd9:	48 c1 e1 04          	shl    $0x4,%rcx
    5ddd:	48 89 ce             	mov    %rcx,%rsi
    5de0:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5de5:	e8 e6 d7 ff ff       	call   35d0 <realloc@plt>
    5dea:	48 85 c0             	test   %rax,%rax
    5ded:	0f 84 a4 01 00 00    	je     5f97 <fwp_p_ad_push.constprop.0+0x2f7>
    5df3:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5df7:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5dfc:	4d 85 f6             	test   %r14,%r14
    5dff:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5e03:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5e08:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5e0f:	00 
    5e10:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5e17:	00 
    5e18:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5e1c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5e23:	00 
    5e24:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5e28:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5e2c:	0f 85 e6 00 00 00    	jne    5f18 <fwp_p_ad_push.constprop.0+0x278>
    5e32:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5e36:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5e3a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5e3e:	49 01 c8             	add    %rcx,%r8
    5e41:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5e45:	eb 79                	jmp    5ec0 <fwp_p_ad_push.constprop.0+0x220>
    5e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e4e:	00 00 
    5e50:	48 89 d0             	mov    %rdx,%rax
    5e53:	48 c1 ff 20          	sar    $0x20,%rdi
    5e57:	48 c1 f8 20          	sar    $0x20,%rax
    5e5b:	48 39 c7             	cmp    %rax,%rdi
    5e5e:	0f 84 a3 fe ff ff    	je     5d07 <fwp_p_ad_push.constprop.0+0x67>
    5e64:	48 8d 3d 5d 89 00 00 	lea    0x895d(%rip),%rdi        # e7c8 <_IO_stdin_used+0x7c8>
    5e6b:	e8 30 e3 ff ff       	call   41a0 <fwp_trap>
    5e70:	48 83 c4 38          	add    $0x38,%rsp
    5e74:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5e7b:	5b                   	pop    %rbx
    5e7c:	5d                   	pop    %rbp
    5e7d:	41 5c                	pop    %r12
    5e7f:	41 5d                	pop    %r13
    5e81:	41 5e                	pop    %r14
    5e83:	41 5f                	pop    %r15
    5e85:	c3                   	ret
    5e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e8d:	00 00 00 
    5e90:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5e95:	e9 06 ff ff ff       	jmp    5da0 <fwp_p_ad_push.constprop.0+0x100>
    5e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ea0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5ea4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5ea8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5eaf:	00 
    5eb0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5eb7:	00 
    5eb8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5ebc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5ec0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5ec6:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5eca:	4d 85 ed             	test   %r13,%r13
    5ecd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5ed2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5ed8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5edf:	4c 0f 48 e8          	cmovs  %rax,%r13
    5ee3:	49 8d 47 01          	lea    0x1(%r15),%rax
    5ee7:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5eeb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    5ef1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5ef5:	48 83 c4 38          	add    $0x38,%rsp
    5ef9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f00:	ff ff ff 
    5f03:	4c 21 e0             	and    %r12,%rax
    5f06:	5b                   	pop    %rbx
    5f07:	5d                   	pop    %rbp
    5f08:	4c 09 f8             	or     %r15,%rax
    5f0b:	41 5c                	pop    %r12
    5f0d:	41 5d                	pop    %r13
    5f0f:	41 5e                	pop    %r14
    5f11:	41 5f                	pop    %r15
    5f13:	c3                   	ret
    5f14:	0f 1f 40 00          	nopl   0x0(%rax)
    5f18:	48 39 ca             	cmp    %rcx,%rdx
    5f1b:	49 89 d6             	mov    %rdx,%r14
    5f1e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5f23:	48 0f 43 ca          	cmovae %rdx,%rcx
    5f27:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    5f2c:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    5f31:	48 29 d1             	sub    %rdx,%rcx
    5f34:	4c 89 ca             	mov    %r9,%rdx
    5f37:	e8 24 d6 ff ff       	call   3560 <__memmove_chk@plt>
    5f3c:	4c 03 73 30          	add    0x30(%rbx),%r14
    5f40:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    5f45:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    5f49:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    5f4e:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    5f52:	48 03 7b 20          	add    0x20(%rbx),%rdi
    5f56:	4c 89 d2             	mov    %r10,%rdx
    5f59:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    5f5e:	e8 ad d6 ff ff       	call   3610 <memmove@plt>
    5f63:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5f67:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5f6b:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    5f70:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5f75:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    5f7a:	e9 b7 fe ff ff       	jmp    5e36 <fwp_p_ad_push.constprop.0+0x196>
    5f7f:	48 8d 3d 63 81 00 00 	lea    0x8163(%rip),%rdi        # e0e9 <_IO_stdin_used+0xe9>
    5f86:	e8 15 e2 ff ff       	call   41a0 <fwp_trap>
    5f8b:	48 8d 3d 72 81 00 00 	lea    0x8172(%rip),%rdi        # e104 <_IO_stdin_used+0x104>
    5f92:	e8 09 e2 ff ff       	call   41a0 <fwp_trap>
    5f97:	48 89 df             	mov    %rbx,%rdi
    5f9a:	e8 61 dc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    5f9f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5fa3:	e8 18 d4 ff ff       	call   33c0 <free@plt>
    5fa8:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5fac:	e8 0f d4 ff ff       	call   33c0 <free@plt>
    5fb1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    5fb5:	e8 06 d4 ff ff       	call   33c0 <free@plt>
    5fba:	31 c9                	xor    %ecx,%ecx
    5fbc:	31 c0                	xor    %eax,%eax
    5fbe:	31 d2                	xor    %edx,%edx
    5fc0:	89 53 04             	mov    %edx,0x4(%rbx)
    5fc3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fc7:	ba 13 00 00 00       	mov    $0x13,%edx
    5fcc:	be 01 00 00 00       	mov    $0x1,%esi
    5fd1:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    5fd5:	48 8d 3d 2c 80 00 00 	lea    0x802c(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    5fdc:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    5fe0:	48 8b 0d 59 c0 00 00 	mov    0xc059(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    5fe7:	48 89 43 40          	mov    %rax,0x40(%rbx)
    5feb:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5fef:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    5ff3:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    5ff7:	e8 84 d6 ff ff       	call   3680 <fwrite@plt>
    5ffc:	31 ff                	xor    %edi,%edi
    5ffe:	e8 bd d5 ff ff       	call   35c0 <fflush@plt>
    6003:	bf 66 00 00 00       	mov    $0x66,%edi
    6008:	e8 93 d6 ff ff       	call   36a0 <_Exit@plt>
    600d:	48 8d 3d fc 87 00 00 	lea    0x87fc(%rip),%rdi        # e810 <_IO_stdin_used+0x810>
    6014:	e8 87 e1 ff ff       	call   41a0 <fwp_trap>
    6019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006020 <w120>:
    6020:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6024:	41 55                	push   %r13
    6026:	48 89 fa             	mov    %rdi,%rdx
    6029:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    602d:	41 54                	push   %r12
    602f:	49 89 fc             	mov    %rdi,%r12
    6032:	55                   	push   %rbp
    6033:	53                   	push   %rbx
    6034:	48 89 f3             	mov    %rsi,%rbx
    6037:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    603c:	48 89 f1             	mov    %rsi,%rcx
    603f:	48 83 ec 28          	sub    $0x28,%rsp
    6043:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6049:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    604f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6055:	e8 46 fc ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    605a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6060:	48 89 da             	mov    %rbx,%rdx
    6063:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6069:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6070:	00 f0 3f 
    6073:	48 89 c7             	mov    %rax,%rdi
    6076:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    607d:	00 f0 bf 
    6080:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6085:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    608b:	e8 10 fc ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    6090:	f2 0f 10 05 10 8a 00 	movsd  0x8a10(%rip),%xmm0        # eaa8 <msg.4+0x28>
    6097:	00 
    6098:	4c 89 e7             	mov    %r12,%rdi
    609b:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    60a1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    60a8:	00 f0 3f 
    60ab:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    60b2:	49 89 c5             	mov    %rax,%r13
    60b5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    60bc:	00 f0 bf 
    60bf:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    60c4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    60ca:	e8 d1 fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    60cf:	48 89 e9             	mov    %rbp,%rcx
    60d2:	4c 89 ea             	mov    %r13,%rdx
    60d5:	48 89 ee             	mov    %rbp,%rsi
    60d8:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    60de:	4c 89 ef             	mov    %r13,%rdi
    60e1:	49 89 c4             	mov    %rax,%r12
    60e4:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    60e8:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    60ee:	e8 ad fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    60f3:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    60f9:	f2 0f 59 1d af 89 00 	mulsd  0x89af(%rip),%xmm3        # eab0 <msg.4+0x30>
    6100:	00 
    6101:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6108:	00 59 40 
    610b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6110:	48 89 c2             	mov    %rax,%rdx
    6113:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    611a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6120:	e8 7b fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    6125:	48 89 d9             	mov    %rbx,%rcx
    6128:	4c 89 e2             	mov    %r12,%rdx
    612b:	48 89 de             	mov    %rbx,%rsi
    612e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6134:	4c 89 e7             	mov    %r12,%rdi
    6137:	48 89 c5             	mov    %rax,%rbp
    613a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    613e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6144:	e8 57 fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    6149:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    614f:	48 89 ea             	mov    %rbp,%rdx
    6152:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6158:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    615f:	00 f0 3f 
    6162:	48 89 c7             	mov    %rax,%rdi
    6165:	48 89 ce             	mov    %rcx,%rsi
    6168:	66 48 0f 7e db       	movq   %xmm3,%rbx
    616d:	e8 2e fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    6172:	48 83 c4 28          	add    $0x28,%rsp
    6176:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    617b:	5b                   	pop    %rbx
    617c:	5d                   	pop    %rbp
    617d:	41 5c                	pop    %r12
    617f:	41 5d                	pop    %r13
    6181:	c3                   	ret
    6182:	0f 1f 00             	nopl   (%rax)
    6185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    618c:	00 00 00 00 

0000000000006190 <w176.constprop.0>:
    6190:	41 54                	push   %r12
    6192:	55                   	push   %rbp
    6193:	53                   	push   %rbx
    6194:	48 83 ec 10          	sub    $0x10,%rsp
    6198:	4c 8b 27             	mov    (%rdi),%r12
    619b:	4d 85 e4             	test   %r12,%r12
    619e:	74 58                	je     61f8 <w176.constprop.0+0x68>
    61a0:	48 89 fd             	mov    %rdi,%rbp
    61a3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61a7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    61ae:	31 db                	xor    %ebx,%ebx
    61b0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    61b6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    61bb:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    61c2:	00 f0 3f 
    61c5:	48 83 c3 02          	add    $0x2,%rbx
    61c9:	48 89 ce             	mov    %rcx,%rsi
    61cc:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    61d2:	e8 c9 fa ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    61d7:	4c 39 e3             	cmp    %r12,%rbx
    61da:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    61e0:	48 89 c7             	mov    %rax,%rdi
    61e3:	72 cb                	jb     61b0 <w176.constprop.0+0x20>
    61e5:	48 83 c4 10          	add    $0x10,%rsp
    61e9:	48 89 f8             	mov    %rdi,%rax
    61ec:	5b                   	pop    %rbx
    61ed:	5d                   	pop    %rbp
    61ee:	41 5c                	pop    %r12
    61f0:	c3                   	ret
    61f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    61f8:	48 83 c4 10          	add    $0x10,%rsp
    61fc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6203:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6207:	5b                   	pop    %rbx
    6208:	48 89 f8             	mov    %rdi,%rax
    620b:	5d                   	pop    %rbp
    620c:	41 5c                	pop    %r12
    620e:	c3                   	ret
    620f:	90                   	nop

0000000000006210 <fwp_rc_share>:
    6210:	48 8b 05 21 d9 01 00 	mov    0x1d921(%rip),%rax        # 23b38 <fwp_heap+0x13d8>
    6217:	48 2b 3d f2 d8 01 00 	sub    0x1d8f2(%rip),%rdi        # 23b10 <fwp_heap+0x13b0>
    621e:	48 c1 e0 10          	shl    $0x10,%rax
    6222:	48 39 c7             	cmp    %rax,%rdi
    6225:	73 4a                	jae    6271 <fwp_rc_share+0x61>
    6227:	48 89 f8             	mov    %rdi,%rax
    622a:	48 c1 e8 10          	shr    $0x10,%rax
    622e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6232:	48 8b 05 1f d9 01 00 	mov    0x1d91f(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    6239:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    623d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6241:	48 85 d2             	test   %rdx,%rdx
    6244:	74 2b                	je     6271 <fwp_rc_share+0x61>
    6246:	0f b6 08             	movzbl (%rax),%ecx
    6249:	80 f9 02             	cmp    $0x2,%cl
    624c:	74 2a                	je     6278 <fwp_rc_share+0x68>
    624e:	80 f9 01             	cmp    $0x1,%cl
    6251:	75 1e                	jne    6271 <fwp_rc_share+0x61>
    6253:	8b 48 18             	mov    0x18(%rax),%ecx
    6256:	0f b7 ff             	movzwl %di,%edi
    6259:	8b 40 1c             	mov    0x1c(%rax),%eax
    625c:	48 0f af f9          	imul   %rcx,%rdi
    6260:	48 c1 ef 20          	shr    $0x20,%rdi
    6264:	48 39 c7             	cmp    %rax,%rdi
    6267:	73 08                	jae    6271 <fwp_rc_share+0x61>
    6269:	48 01 fa             	add    %rdi,%rdx
    626c:	80 3a 00             	cmpb   $0x0,(%rdx)
    626f:	75 0d                	jne    627e <fwp_rc_share+0x6e>
    6271:	c3                   	ret
    6272:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6278:	66 85 ff             	test   %di,%di
    627b:	74 ef                	je     626c <fwp_rc_share+0x5c>
    627d:	c3                   	ret
    627e:	50                   	push   %rax
    627f:	48 8d 3d ba 85 00 00 	lea    0x85ba(%rip),%rdi        # e840 <_IO_stdin_used+0x840>
    6286:	e8 15 df ff ff       	call   41a0 <fwp_trap>
    628b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006290 <fwp_rc_fresh>:
    6290:	48 8b 15 a1 d8 01 00 	mov    0x1d8a1(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    6297:	48 89 f8             	mov    %rdi,%rax
    629a:	48 89 fe             	mov    %rdi,%rsi
    629d:	48 2b 05 6c d8 01 00 	sub    0x1d86c(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    62a4:	48 c1 e2 10          	shl    $0x10,%rdx
    62a8:	48 39 d0             	cmp    %rdx,%rax
    62ab:	73 4f                	jae    62fc <fwp_rc_fresh+0x6c>
    62ad:	48 89 c2             	mov    %rax,%rdx
    62b0:	48 c1 ea 10          	shr    $0x10,%rdx
    62b4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    62b8:	48 8b 15 99 d8 01 00 	mov    0x1d899(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    62bf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    62c3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    62c7:	48 85 d2             	test   %rdx,%rdx
    62ca:	74 30                	je     62fc <fwp_rc_fresh+0x6c>
    62cc:	0f b6 39             	movzbl (%rcx),%edi
    62cf:	40 80 ff 02          	cmp    $0x2,%dil
    62d3:	74 2b                	je     6300 <fwp_rc_fresh+0x70>
    62d5:	40 80 ff 01          	cmp    $0x1,%dil
    62d9:	75 21                	jne    62fc <fwp_rc_fresh+0x6c>
    62db:	8b 79 18             	mov    0x18(%rcx),%edi
    62de:	0f b7 c0             	movzwl %ax,%eax
    62e1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    62e4:	48 0f af c7          	imul   %rdi,%rax
    62e8:	48 c1 e8 20          	shr    $0x20,%rax
    62ec:	48 39 c8             	cmp    %rcx,%rax
    62ef:	73 0b                	jae    62fc <fwp_rc_fresh+0x6c>
    62f1:	48 01 c2             	add    %rax,%rdx
    62f4:	80 3a ff             	cmpb   $0xff,(%rdx)
    62f7:	74 17                	je     6310 <fwp_rc_fresh+0x80>
    62f9:	c6 02 01             	movb   $0x1,(%rdx)
    62fc:	48 89 f0             	mov    %rsi,%rax
    62ff:	c3                   	ret
    6300:	66 85 c0             	test   %ax,%ax
    6303:	74 ef                	je     62f4 <fwp_rc_fresh+0x64>
    6305:	48 89 f0             	mov    %rsi,%rax
    6308:	c3                   	ret
    6309:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6310:	48 83 ec 18          	sub    $0x18,%rsp
    6314:	48 89 d7             	mov    %rdx,%rdi
    6317:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    631c:	48 89 14 24          	mov    %rdx,(%rsp)
    6320:	e8 eb ef ff ff       	call   5310 <fwp_rc_forget_slot>
    6325:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    632a:	48 8b 14 24          	mov    (%rsp),%rdx
    632e:	48 89 f0             	mov    %rsi,%rax
    6331:	c6 02 01             	movb   $0x1,(%rdx)
    6334:	48 83 c4 18          	add    $0x18,%rsp
    6338:	c3                   	ret
    6339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006340 <fwp_rc_free_obj>:
    6340:	48 8b 15 f1 d7 01 00 	mov    0x1d7f1(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    6347:	48 89 f8             	mov    %rdi,%rax
    634a:	48 2b 05 bf d7 01 00 	sub    0x1d7bf(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6351:	48 c1 e2 10          	shl    $0x10,%rdx
    6355:	48 39 d0             	cmp    %rdx,%rax
    6358:	73 5b                	jae    63b5 <fwp_rc_free_obj+0x75>
    635a:	48 89 c2             	mov    %rax,%rdx
    635d:	48 c1 ea 10          	shr    $0x10,%rdx
    6361:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6365:	48 8b 15 ec d7 01 00 	mov    0x1d7ec(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    636c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6370:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6374:	48 85 c9             	test   %rcx,%rcx
    6377:	74 3c                	je     63b5 <fwp_rc_free_obj+0x75>
    6379:	0f b6 32             	movzbl (%rdx),%esi
    637c:	40 80 fe 02          	cmp    $0x2,%sil
    6380:	74 2e                	je     63b0 <fwp_rc_free_obj+0x70>
    6382:	40 80 fe 01          	cmp    $0x1,%sil
    6386:	75 2d                	jne    63b5 <fwp_rc_free_obj+0x75>
    6388:	8b 72 18             	mov    0x18(%rdx),%esi
    638b:	0f b7 c0             	movzwl %ax,%eax
    638e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6391:	48 0f af c6          	imul   %rsi,%rax
    6395:	48 c1 e8 20          	shr    $0x20,%rax
    6399:	48 39 d0             	cmp    %rdx,%rax
    639c:	73 17                	jae    63b5 <fwp_rc_free_obj+0x75>
    639e:	48 01 c1             	add    %rax,%rcx
    63a1:	80 39 01             	cmpb   $0x1,(%rcx)
    63a4:	75 0f                	jne    63b5 <fwp_rc_free_obj+0x75>
    63a6:	e9 a5 f1 ff ff       	jmp    5550 <fwp_mem_free>
    63ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    63b0:	66 85 c0             	test   %ax,%ax
    63b3:	74 ec                	je     63a1 <fwp_rc_free_obj+0x61>
    63b5:	c3                   	ret
    63b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    63bd:	00 00 00 

00000000000063c0 <fwp_rc_dup>:
    63c0:	f3 0f 1e fa          	endbr64
    63c4:	48 8b 05 6d d7 01 00 	mov    0x1d76d(%rip),%rax        # 23b38 <fwp_heap+0x13d8>
    63cb:	48 2b 3d 3e d7 01 00 	sub    0x1d73e(%rip),%rdi        # 23b10 <fwp_heap+0x13b0>
    63d2:	48 c1 e0 10          	shl    $0x10,%rax
    63d6:	48 39 c7             	cmp    %rax,%rdi
    63d9:	73 56                	jae    6431 <fwp_rc_dup+0x71>
    63db:	48 89 f8             	mov    %rdi,%rax
    63de:	48 c1 e8 10          	shr    $0x10,%rax
    63e2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    63e6:	48 8b 05 6b d7 01 00 	mov    0x1d76b(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    63ed:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    63f1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    63f5:	48 85 c0             	test   %rax,%rax
    63f8:	74 37                	je     6431 <fwp_rc_dup+0x71>
    63fa:	0f b6 0a             	movzbl (%rdx),%ecx
    63fd:	80 f9 02             	cmp    $0x2,%cl
    6400:	74 36                	je     6438 <fwp_rc_dup+0x78>
    6402:	80 f9 01             	cmp    $0x1,%cl
    6405:	75 2a                	jne    6431 <fwp_rc_dup+0x71>
    6407:	8b 4a 18             	mov    0x18(%rdx),%ecx
    640a:	0f b7 ff             	movzwl %di,%edi
    640d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6410:	48 0f af f9          	imul   %rcx,%rdi
    6414:	48 c1 ef 20          	shr    $0x20,%rdi
    6418:	48 39 d7             	cmp    %rdx,%rdi
    641b:	73 14                	jae    6431 <fwp_rc_dup+0x71>
    641d:	48 01 f8             	add    %rdi,%rax
    6420:	0f b6 10             	movzbl (%rax),%edx
    6423:	84 d2                	test   %dl,%dl
    6425:	74 0a                	je     6431 <fwp_rc_dup+0x71>
    6427:	80 fa fd             	cmp    $0xfd,%dl
    642a:	77 14                	ja     6440 <fwp_rc_dup+0x80>
    642c:	83 c2 01             	add    $0x1,%edx
    642f:	88 10                	mov    %dl,(%rax)
    6431:	c3                   	ret
    6432:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6438:	66 85 ff             	test   %di,%di
    643b:	74 e3                	je     6420 <fwp_rc_dup+0x60>
    643d:	c3                   	ret
    643e:	66 90                	xchg   %ax,%ax
    6440:	48 89 c7             	mov    %rax,%rdi
    6443:	e9 a8 ed ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6448:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    644f:	00 

0000000000006450 <fwp_owned_entry173>:
    6450:	f3 0f 1e fa          	endbr64
    6454:	48 83 ec 38          	sub    $0x38,%rsp
    6458:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    645d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6464:	00 00 
    6466:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    646b:	31 c0                	xor    %eax,%eax
    646d:	48 8b 07             	mov    (%rdi),%rax
    6470:	48 03 47 10          	add    0x10(%rdi),%rax
    6474:	0f 80 c2 00 00 00    	jo     653c <fwp_owned_entry173+0xec>
    647a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    647f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6484:	31 ff                	xor    %edi,%edi
    6486:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    648a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    648f:	e8 dc f6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6494:	48 8b 15 9d d6 01 00 	mov    0x1d69d(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    649b:	48 89 c6             	mov    %rax,%rsi
    649e:	48 2b 05 6b d6 01 00 	sub    0x1d66b(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    64a5:	48 c1 e2 10          	shl    $0x10,%rdx
    64a9:	48 39 d0             	cmp    %rdx,%rax
    64ac:	73 4f                	jae    64fd <fwp_owned_entry173+0xad>
    64ae:	48 89 c2             	mov    %rax,%rdx
    64b1:	48 c1 ea 10          	shr    $0x10,%rdx
    64b5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    64b9:	48 8b 15 98 d6 01 00 	mov    0x1d698(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    64c0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    64c4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    64c8:	48 85 d2             	test   %rdx,%rdx
    64cb:	74 30                	je     64fd <fwp_owned_entry173+0xad>
    64cd:	0f b6 39             	movzbl (%rcx),%edi
    64d0:	40 80 ff 02          	cmp    $0x2,%dil
    64d4:	74 42                	je     6518 <fwp_owned_entry173+0xc8>
    64d6:	40 80 ff 01          	cmp    $0x1,%dil
    64da:	75 21                	jne    64fd <fwp_owned_entry173+0xad>
    64dc:	8b 79 18             	mov    0x18(%rcx),%edi
    64df:	0f b7 c0             	movzwl %ax,%eax
    64e2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    64e5:	48 0f af c7          	imul   %rdi,%rax
    64e9:	48 c1 e8 20          	shr    $0x20,%rax
    64ed:	48 39 c8             	cmp    %rcx,%rax
    64f0:	73 0b                	jae    64fd <fwp_owned_entry173+0xad>
    64f2:	48 01 c2             	add    %rax,%rdx
    64f5:	80 3a ff             	cmpb   $0xff,(%rdx)
    64f8:	74 26                	je     6520 <fwp_owned_entry173+0xd0>
    64fa:	c6 02 01             	movb   $0x1,(%rdx)
    64fd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6502:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6509:	00 00 
    650b:	75 34                	jne    6541 <fwp_owned_entry173+0xf1>
    650d:	48 89 f0             	mov    %rsi,%rax
    6510:	48 83 c4 38          	add    $0x38,%rsp
    6514:	c3                   	ret
    6515:	0f 1f 00             	nopl   (%rax)
    6518:	66 85 c0             	test   %ax,%ax
    651b:	75 e0                	jne    64fd <fwp_owned_entry173+0xad>
    651d:	eb d6                	jmp    64f5 <fwp_owned_entry173+0xa5>
    651f:	90                   	nop
    6520:	48 89 d7             	mov    %rdx,%rdi
    6523:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6528:	48 89 14 24          	mov    %rdx,(%rsp)
    652c:	e8 df ed ff ff       	call   5310 <fwp_rc_forget_slot>
    6531:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6536:	48 8b 14 24          	mov    (%rsp),%rdx
    653a:	eb be                	jmp    64fa <fwp_owned_entry173+0xaa>
    653c:	e8 bf d1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6541:	e8 1a cf ff ff       	call   3460 <__stack_chk_fail@plt>
    6546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    654d:	00 00 00 

0000000000006550 <e173>:
    6550:	f3 0f 1e fa          	endbr64
    6554:	53                   	push   %rbx
    6555:	48 83 ec 30          	sub    $0x30,%rsp
    6559:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    655e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6565:	00 00 
    6567:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    656c:	31 c0                	xor    %eax,%eax
    656e:	48 8b 07             	mov    (%rdi),%rax
    6571:	48 03 47 10          	add    0x10(%rdi),%rax
    6575:	0f 80 c9 00 00 00    	jo     6644 <e173+0xf4>
    657b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6580:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6585:	31 ff                	xor    %edi,%edi
    6587:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    658b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6590:	e8 db f5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6595:	48 8b 15 9c d5 01 00 	mov    0x1d59c(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    659c:	48 89 c3             	mov    %rax,%rbx
    659f:	48 2b 05 6a d5 01 00 	sub    0x1d56a(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    65a6:	48 c1 e2 10          	shl    $0x10,%rdx
    65aa:	48 39 d0             	cmp    %rdx,%rax
    65ad:	73 4f                	jae    65fe <e173+0xae>
    65af:	48 89 c2             	mov    %rax,%rdx
    65b2:	48 c1 ea 10          	shr    $0x10,%rdx
    65b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    65ba:	48 8b 15 97 d5 01 00 	mov    0x1d597(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    65c1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    65c5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    65c9:	48 85 d2             	test   %rdx,%rdx
    65cc:	74 30                	je     65fe <e173+0xae>
    65ce:	0f b6 31             	movzbl (%rcx),%esi
    65d1:	40 80 fe 02          	cmp    $0x2,%sil
    65d5:	74 49                	je     6620 <e173+0xd0>
    65d7:	40 80 fe 01          	cmp    $0x1,%sil
    65db:	75 21                	jne    65fe <e173+0xae>
    65dd:	8b 71 18             	mov    0x18(%rcx),%esi
    65e0:	0f b7 c0             	movzwl %ax,%eax
    65e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    65e6:	48 0f af c6          	imul   %rsi,%rax
    65ea:	48 c1 e8 20          	shr    $0x20,%rax
    65ee:	48 39 c8             	cmp    %rcx,%rax
    65f1:	73 0b                	jae    65fe <e173+0xae>
    65f3:	48 01 c2             	add    %rax,%rdx
    65f6:	80 3a ff             	cmpb   $0xff,(%rdx)
    65f9:	74 35                	je     6630 <e173+0xe0>
    65fb:	c6 02 01             	movb   $0x1,(%rdx)
    65fe:	48 89 df             	mov    %rbx,%rdi
    6601:	e8 0a fc ff ff       	call   6210 <fwp_rc_share>
    6606:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    660b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6612:	00 00 
    6614:	75 33                	jne    6649 <e173+0xf9>
    6616:	48 83 c4 30          	add    $0x30,%rsp
    661a:	48 89 d8             	mov    %rbx,%rax
    661d:	5b                   	pop    %rbx
    661e:	c3                   	ret
    661f:	90                   	nop
    6620:	66 85 c0             	test   %ax,%ax
    6623:	75 d9                	jne    65fe <e173+0xae>
    6625:	eb cf                	jmp    65f6 <e173+0xa6>
    6627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    662e:	00 00 
    6630:	48 89 d7             	mov    %rdx,%rdi
    6633:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6638:	e8 d3 ec ff ff       	call   5310 <fwp_rc_forget_slot>
    663d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6642:	eb b7                	jmp    65fb <e173+0xab>
    6644:	e8 b7 d0 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6649:	e8 12 ce ff ff       	call   3460 <__stack_chk_fail@plt>
    664e:	66 90                	xchg   %ax,%ax

0000000000006650 <fwp_closure_drop>:
    6650:	48 8b 15 e1 d4 01 00 	mov    0x1d4e1(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    6657:	48 89 f8             	mov    %rdi,%rax
    665a:	48 2b 05 af d4 01 00 	sub    0x1d4af(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6661:	48 c1 e2 10          	shl    $0x10,%rdx
    6665:	48 39 d0             	cmp    %rdx,%rax
    6668:	73 6b                	jae    66d5 <fwp_closure_drop+0x85>
    666a:	48 89 c2             	mov    %rax,%rdx
    666d:	48 c1 ea 10          	shr    $0x10,%rdx
    6671:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6675:	48 8b 15 dc d4 01 00 	mov    0x1d4dc(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    667c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6680:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6684:	48 85 d2             	test   %rdx,%rdx
    6687:	74 4c                	je     66d5 <fwp_closure_drop+0x85>
    6689:	0f b6 31             	movzbl (%rcx),%esi
    668c:	40 80 fe 02          	cmp    $0x2,%sil
    6690:	74 3e                	je     66d0 <fwp_closure_drop+0x80>
    6692:	40 80 fe 01          	cmp    $0x1,%sil
    6696:	75 3d                	jne    66d5 <fwp_closure_drop+0x85>
    6698:	8b 71 18             	mov    0x18(%rcx),%esi
    669b:	0f b7 c0             	movzwl %ax,%eax
    669e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    66a1:	48 0f af c6          	imul   %rsi,%rax
    66a5:	48 c1 e8 20          	shr    $0x20,%rax
    66a9:	48 39 c8             	cmp    %rcx,%rax
    66ac:	73 27                	jae    66d5 <fwp_closure_drop+0x85>
    66ae:	48 01 c2             	add    %rax,%rdx
    66b1:	0f b6 02             	movzbl (%rdx),%eax
    66b4:	84 c0                	test   %al,%al
    66b6:	74 1d                	je     66d5 <fwp_closure_drop+0x85>
    66b8:	3c 01                	cmp    $0x1,%al
    66ba:	74 24                	je     66e0 <fwp_closure_drop+0x90>
    66bc:	3c ff                	cmp    $0xff,%al
    66be:	74 48                	je     6708 <fwp_closure_drop+0xb8>
    66c0:	83 e8 01             	sub    $0x1,%eax
    66c3:	88 02                	mov    %al,(%rdx)
    66c5:	c3                   	ret
    66c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    66cd:	00 00 00 
    66d0:	66 85 c0             	test   %ax,%ax
    66d3:	74 dc                	je     66b1 <fwp_closure_drop+0x61>
    66d5:	c3                   	ret
    66d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    66dd:	00 00 00 
    66e0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    66e7:	ff ff 
    66e9:	48 85 c0             	test   %rax,%rax
    66ec:	74 12                	je     6700 <fwp_closure_drop+0xb0>
    66ee:	48 89 fe             	mov    %rdi,%rsi
    66f1:	48 89 c7             	mov    %rax,%rdi
    66f4:	e9 07 db ff ff       	jmp    4200 <fwp_closure_drop_push>
    66f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6700:	e9 ab dc ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6705:	0f 1f 00             	nopl   (%rax)
    6708:	48 89 d0             	mov    %rdx,%rax
    670b:	48 8d 35 4e c0 01 00 	lea    0x1c04e(%rip),%rsi        # 22760 <fwp_heap>
    6712:	48 83 ec 18          	sub    $0x18,%rsp
    6716:	48 c1 e8 11          	shr    $0x11,%rax
    671a:	48 31 d0             	xor    %rdx,%rax
    671d:	48 89 c1             	mov    %rax,%rcx
    6720:	48 c1 e9 09          	shr    $0x9,%rcx
    6724:	48 31 c8             	xor    %rcx,%rax
    6727:	0f b6 c8             	movzbl %al,%ecx
    672a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6731:	00 
    6732:	48 85 c0             	test   %rax,%rax
    6735:	75 12                	jne    6749 <fwp_closure_drop+0xf9>
    6737:	eb 49                	jmp    6782 <fwp_closure_drop+0x132>
    6739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6740:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6744:	48 85 c0             	test   %rax,%rax
    6747:	74 39                	je     6782 <fwp_closure_drop+0x132>
    6749:	48 89 c1             	mov    %rax,%rcx
    674c:	48 39 10             	cmp    %rdx,(%rax)
    674f:	75 ef                	jne    6740 <fwp_closure_drop+0xf0>
    6751:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6755:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6759:	48 89 48 08          	mov    %rcx,0x8(%rax)
    675d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6764:	74 05                	je     676b <fwp_closure_drop+0x11b>
    6766:	48 83 c4 18          	add    $0x18,%rsp
    676a:	c3                   	ret
    676b:	48 89 d7             	mov    %rdx,%rdi
    676e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6773:	e8 98 eb ff ff       	call   5310 <fwp_rc_forget_slot>
    6778:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    677d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6780:	eb e4                	jmp    6766 <fwp_closure_drop+0x116>
    6782:	48 8d 3d 17 80 00 00 	lea    0x8017(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    6789:	e8 12 da ff ff       	call   41a0 <fwp_trap>
    678e:	66 90                	xchg   %ax,%ax

0000000000006790 <fwp_owned_tape_release>:
    6790:	48 85 ff             	test   %rdi,%rdi
    6793:	0f 84 f7 00 00 00    	je     6890 <fwp_owned_tape_release+0x100>
    6799:	41 54                	push   %r12
    679b:	55                   	push   %rbp
    679c:	53                   	push   %rbx
    679d:	48 8b 07             	mov    (%rdi),%rax
    67a0:	48 85 c0             	test   %rax,%rax
    67a3:	74 08                	je     67ad <fwp_owned_tape_release+0x1d>
    67a5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    67a9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    67ad:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    67b1:	48 85 d2             	test   %rdx,%rdx
    67b4:	74 03                	je     67b9 <fwp_owned_tape_release+0x29>
    67b6:	48 89 02             	mov    %rax,(%rdx)
    67b9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    67bd:	48 89 fb             	mov    %rdi,%rbx
    67c0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    67c4:	48 85 c0             	test   %rax,%rax
    67c7:	0f 84 89 00 00 00    	je     6856 <fwp_owned_tape_release+0xc6>
    67cd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    67d1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    67d5:	7e 47                	jle    681e <fwp_owned_tape_release+0x8e>
    67d7:	31 ed                	xor    %ebp,%ebp
    67d9:	eb 0d                	jmp    67e8 <fwp_owned_tape_release+0x58>
    67db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    67e0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    67e4:	48 8b 40 68          	mov    0x68(%rax),%rax
    67e8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    67ec:	49 89 ec             	mov    %rbp,%r12
    67ef:	48 83 c5 01          	add    $0x1,%rbp
    67f3:	49 c1 e4 04          	shl    $0x4,%r12
    67f7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    67fb:	ff d0                	call   *%rax
    67fd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6801:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6806:	48 8b 43 10          	mov    0x10(%rbx),%rax
    680a:	ff 50 68             	call   *0x68(%rax)
    680d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6811:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6815:	48 39 e8             	cmp    %rbp,%rax
    6818:	7f c6                	jg     67e0 <fwp_owned_tape_release+0x50>
    681a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    681e:	31 ed                	xor    %ebp,%ebp
    6820:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6825:	7e 28                	jle    684f <fwp_owned_tape_release+0xbf>
    6827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    682e:	00 00 
    6830:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6834:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6838:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    683c:	74 07                	je     6845 <fwp_owned_tape_release+0xb5>
    683e:	ff 52 68             	call   *0x68(%rdx)
    6841:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6845:	48 83 c5 01          	add    $0x1,%rbp
    6849:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    684d:	7f e1                	jg     6830 <fwp_owned_tape_release+0xa0>
    684f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6853:	ff 52 68             	call   *0x68(%rdx)
    6856:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    685a:	e8 f1 fd ff ff       	call   6650 <fwp_closure_drop>
    685f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6863:	e8 e8 fd ff ff       	call   6650 <fwp_closure_drop>
    6868:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    686c:	e8 df fd ff ff       	call   6650 <fwp_closure_drop>
    6871:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6875:	e8 d6 ec ff ff       	call   5550 <fwp_mem_free>
    687a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    687e:	e8 cd ec ff ff       	call   5550 <fwp_mem_free>
    6883:	48 89 df             	mov    %rbx,%rdi
    6886:	5b                   	pop    %rbx
    6887:	5d                   	pop    %rbp
    6888:	41 5c                	pop    %r12
    688a:	e9 c1 ec ff ff       	jmp    5550 <fwp_mem_free>
    688f:	90                   	nop
    6890:	c3                   	ret
    6891:	0f 1f 40 00          	nopl   0x0(%rax)
    6895:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    689c:	00 00 00 00 

00000000000068a0 <fwp_tape_finish>:
    68a0:	f3 0f 1e fa          	endbr64
    68a4:	41 56                	push   %r14
    68a6:	48 8d 3d f3 b7 01 00 	lea    0x1b7f3(%rip),%rdi        # 220a0 <fwp_tape_workspace>
    68ad:	41 55                	push   %r13
    68af:	41 54                	push   %r12
    68b1:	55                   	push   %rbp
    68b2:	53                   	push   %rbx
    68b3:	e8 b8 d6 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    68b8:	48 83 3d 28 b8 01 00 	cmpq   $0x0,0x1b828(%rip)        # 220e8 <fwp_ntapes>
    68bf:	00 
    68c0:	48 c7 05 bd b7 01 00 	movq   $0x0,0x1b7bd(%rip)        # 22088 <fwp_tape_cached_bytes>
    68c7:	00 00 00 00 
    68cb:	7e 68                	jle    6935 <fwp_tape_finish+0x95>
    68cd:	45 31 e4             	xor    %r12d,%r12d
    68d0:	31 ed                	xor    %ebp,%ebp
    68d2:	0f 1f 00             	nopl   (%rax)
    68d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68dc:	00 00 00 00 
    68e0:	48 8b 1d 09 b8 01 00 	mov    0x1b809(%rip),%rbx        # 220f0 <fwp_tapes>
    68e7:	48 83 c5 01          	add    $0x1,%rbp
    68eb:	4c 01 e3             	add    %r12,%rbx
    68ee:	49 83 c4 68          	add    $0x68,%r12
    68f2:	48 89 df             	mov    %rbx,%rdi
    68f5:	e8 06 d3 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    68fa:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    68fe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6902:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6906:	e8 b5 ca ff ff       	call   33c0 <free@plt>
    690b:	4c 89 f7             	mov    %r14,%rdi
    690e:	e8 ad ca ff ff       	call   33c0 <free@plt>
    6913:	4c 89 ef             	mov    %r13,%rdi
    6916:	e8 a5 ca ff ff       	call   33c0 <free@plt>
    691b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    691f:	e8 6c fe ff ff       	call   6790 <fwp_owned_tape_release>
    6924:	48 39 2d bd b7 01 00 	cmp    %rbp,0x1b7bd(%rip)        # 220e8 <fwp_ntapes>
    692b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6932:	00 
    6933:	7f ab                	jg     68e0 <fwp_tape_finish+0x40>
    6935:	48 8b 3d b4 b7 01 00 	mov    0x1b7b4(%rip),%rdi        # 220f0 <fwp_tapes>
    693c:	e8 7f ca ff ff       	call   33c0 <free@plt>
    6941:	5b                   	pop    %rbx
    6942:	5d                   	pop    %rbp
    6943:	48 c7 05 a2 b7 01 00 	movq   $0x0,0x1b7a2(%rip)        # 220f0 <fwp_tapes>
    694a:	00 00 00 00 
    694e:	48 c7 05 87 b7 01 00 	movq   $0x0,0x1b787(%rip)        # 220e0 <fwp_tapes_cap>
    6955:	00 00 00 00 
    6959:	41 5c                	pop    %r12
    695b:	48 c7 05 82 b7 01 00 	movq   $0x0,0x1b782(%rip)        # 220e8 <fwp_ntapes>
    6962:	00 00 00 00 
    6966:	41 5d                	pop    %r13
    6968:	48 c7 05 65 b7 01 00 	movq   $0x0,0x1b765(%rip)        # 220d8 <fwp_tape_next_slot>
    696f:	00 00 00 00 
    6973:	41 5e                	pop    %r14
    6975:	c3                   	ret
    6976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    697d:	00 00 00 

0000000000006980 <fwp_tape_scope_release>:
    6980:	f3 0f 1e fa          	endbr64
    6984:	41 55                	push   %r13
    6986:	41 54                	push   %r12
    6988:	55                   	push   %rbp
    6989:	53                   	push   %rbx
    698a:	48 83 ec 58          	sub    $0x58,%rsp
    698e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6995:	00 00 
    6997:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    699c:	48 63 07             	movslq (%rdi),%rax
    699f:	85 c0                	test   %eax,%eax
    69a1:	0f 88 05 01 00 00    	js     6aac <fwp_tape_scope_release+0x12c>
    69a7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    69ae:	ec c4 4e 
    69b1:	48 89 fb             	mov    %rdi,%rbx
    69b4:	eb 3c                	jmp    69f2 <fwp_tape_scope_release+0x72>
    69b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69bd:	00 00 00 
    69c0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    69c5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    69c9:	e8 f2 c9 ff ff       	call   33c0 <free@plt>
    69ce:	48 8b 3c 24          	mov    (%rsp),%rdi
    69d2:	e8 e9 c9 ff ff       	call   33c0 <free@plt>
    69d7:	4c 89 ef             	mov    %r13,%rdi
    69da:	e8 e1 c9 ff ff       	call   33c0 <free@plt>
    69df:	4c 89 e7             	mov    %r12,%rdi
    69e2:	e8 a9 fd ff ff       	call   6790 <fwp_owned_tape_release>
    69e7:	48 63 03             	movslq (%rbx),%rax
    69ea:	85 c0                	test   %eax,%eax
    69ec:	0f 88 ba 00 00 00    	js     6aac <fwp_tape_scope_release+0x12c>
    69f2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    69f6:	48 8b 35 f3 b6 01 00 	mov    0x1b6f3(%rip),%rsi        # 220f0 <fwp_tapes>
    69fd:	4c 01 c6             	add    %r8,%rsi
    6a00:	48 89 f7             	mov    %rsi,%rdi
    6a03:	e8 f8 d1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6a08:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6a0d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6a12:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6a19:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6a1d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6a21:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6a28:	00 
    6a29:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6a2e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6a32:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6a37:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6a3b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6a40:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6a47:	00 
    6a48:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6a4f:	00 
    6a50:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6a57:	00 
    6a58:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6a5d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6a62:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6a66:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6a6a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6a6e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6a74:	77 18                	ja     6a8e <fwp_tape_scope_release+0x10e>
    6a76:	49 c1 f8 03          	sar    $0x3,%r8
    6a7a:	4c 0f af c5          	imul   %rbp,%r8
    6a7e:	4c 3b 05 53 b6 01 00 	cmp    0x1b653(%rip),%r8        # 220d8 <fwp_tape_next_slot>
    6a85:	7d 07                	jge    6a8e <fwp_tape_scope_release+0x10e>
    6a87:	4c 89 05 4a b6 01 00 	mov    %r8,0x1b64a(%rip)        # 220d8 <fwp_tape_next_slot>
    6a8e:	4d 85 e4             	test   %r12,%r12
    6a91:	0f 85 29 ff ff ff    	jne    69c0 <fwp_tape_scope_release+0x40>
    6a97:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6a9c:	e8 8f e3 ff ff       	call   4e30 <fwp_tape_buffers_release>
    6aa1:	48 63 03             	movslq (%rbx),%rax
    6aa4:	85 c0                	test   %eax,%eax
    6aa6:	0f 89 46 ff ff ff    	jns    69f2 <fwp_tape_scope_release+0x72>
    6aac:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6ab1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ab8:	00 00 
    6aba:	75 0b                	jne    6ac7 <fwp_tape_scope_release+0x147>
    6abc:	48 83 c4 58          	add    $0x58,%rsp
    6ac0:	5b                   	pop    %rbx
    6ac1:	5d                   	pop    %rbp
    6ac2:	41 5c                	pop    %r12
    6ac4:	41 5d                	pop    %r13
    6ac6:	c3                   	ret
    6ac7:	e8 94 c9 ff ff       	call   3460 <__stack_chk_fail@plt>
    6acc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006ad0 <fwp_drop4>:
    6ad0:	48 8b 0d 61 d0 01 00 	mov    0x1d061(%rip),%rcx        # 23b38 <fwp_heap+0x13d8>
    6ad7:	48 89 f8             	mov    %rdi,%rax
    6ada:	48 2b 05 2f d0 01 00 	sub    0x1d02f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6ae1:	48 c1 e1 10          	shl    $0x10,%rcx
    6ae5:	48 39 c8             	cmp    %rcx,%rax
    6ae8:	0f 83 42 01 00 00    	jae    6c30 <fwp_drop4+0x160>
    6aee:	48 83 ec 18          	sub    $0x18,%rsp
    6af2:	48 89 fa             	mov    %rdi,%rdx
    6af5:	4c 8d 05 64 bc 01 00 	lea    0x1bc64(%rip),%r8        # 22760 <fwp_heap>
    6afc:	48 89 c1             	mov    %rax,%rcx
    6aff:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6b06:	48 c1 e9 10          	shr    $0x10,%rcx
    6b0a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6b0e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6b12:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6b16:	48 85 c9             	test   %rcx,%rcx
    6b19:	74 40                	je     6b5b <fwp_drop4+0x8b>
    6b1b:	0f b6 3e             	movzbl (%rsi),%edi
    6b1e:	40 80 ff 02          	cmp    $0x2,%dil
    6b22:	74 3c                	je     6b60 <fwp_drop4+0x90>
    6b24:	40 80 ff 01          	cmp    $0x1,%dil
    6b28:	75 31                	jne    6b5b <fwp_drop4+0x8b>
    6b2a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6b2d:	0f b7 c0             	movzwl %ax,%eax
    6b30:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6b33:	48 0f af c7          	imul   %rdi,%rax
    6b37:	48 c1 e8 20          	shr    $0x20,%rax
    6b3b:	48 39 f0             	cmp    %rsi,%rax
    6b3e:	73 1b                	jae    6b5b <fwp_drop4+0x8b>
    6b40:	48 01 c1             	add    %rax,%rcx
    6b43:	0f b6 01             	movzbl (%rcx),%eax
    6b46:	84 c0                	test   %al,%al
    6b48:	74 11                	je     6b5b <fwp_drop4+0x8b>
    6b4a:	3c 01                	cmp    $0x1,%al
    6b4c:	74 22                	je     6b70 <fwp_drop4+0xa0>
    6b4e:	3c ff                	cmp    $0xff,%al
    6b50:	0f 84 0a 01 00 00    	je     6c60 <fwp_drop4+0x190>
    6b56:	83 e8 01             	sub    $0x1,%eax
    6b59:	88 01                	mov    %al,(%rcx)
    6b5b:	48 83 c4 18          	add    $0x18,%rsp
    6b5f:	c3                   	ret
    6b60:	66 85 c0             	test   %ax,%ax
    6b63:	74 de                	je     6b43 <fwp_drop4+0x73>
    6b65:	48 83 c4 18          	add    $0x18,%rsp
    6b69:	c3                   	ret
    6b6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b70:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6b74:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6b7b:	48 89 f8             	mov    %rdi,%rax
    6b7e:	48 c1 e1 10          	shl    $0x10,%rcx
    6b82:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b89:	48 39 c8             	cmp    %rcx,%rax
    6b8c:	73 62                	jae    6bf0 <fwp_drop4+0x120>
    6b8e:	48 89 c1             	mov    %rax,%rcx
    6b91:	48 c1 e9 10          	shr    $0x10,%rcx
    6b95:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6b99:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6b9d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6ba1:	48 85 c9             	test   %rcx,%rcx
    6ba4:	74 4a                	je     6bf0 <fwp_drop4+0x120>
    6ba6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6baa:	41 80 f9 02          	cmp    $0x2,%r9b
    6bae:	0f 84 9c 00 00 00    	je     6c50 <fwp_drop4+0x180>
    6bb4:	41 80 f9 01          	cmp    $0x1,%r9b
    6bb8:	75 36                	jne    6bf0 <fwp_drop4+0x120>
    6bba:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6bbe:	0f b7 c0             	movzwl %ax,%eax
    6bc1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6bc4:	49 0f af c1          	imul   %r9,%rax
    6bc8:	48 c1 e8 20          	shr    $0x20,%rax
    6bcc:	48 39 f0             	cmp    %rsi,%rax
    6bcf:	73 1f                	jae    6bf0 <fwp_drop4+0x120>
    6bd1:	48 01 c1             	add    %rax,%rcx
    6bd4:	0f b6 01             	movzbl (%rcx),%eax
    6bd7:	84 c0                	test   %al,%al
    6bd9:	74 15                	je     6bf0 <fwp_drop4+0x120>
    6bdb:	3c 01                	cmp    $0x1,%al
    6bdd:	74 59                	je     6c38 <fwp_drop4+0x168>
    6bdf:	3c ff                	cmp    $0xff,%al
    6be1:	0f 84 ff 00 00 00    	je     6ce6 <fwp_drop4+0x216>
    6be7:	83 e8 01             	sub    $0x1,%eax
    6bea:	88 01                	mov    %al,(%rcx)
    6bec:	0f 1f 40 00          	nopl   0x0(%rax)
    6bf0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6bf4:	48 89 d7             	mov    %rdx,%rdi
    6bf7:	48 89 0c 24          	mov    %rcx,(%rsp)
    6bfb:	e8 40 f7 ff ff       	call   6340 <fwp_rc_free_obj>
    6c00:	4c 8d 05 59 bb 01 00 	lea    0x1bb59(%rip),%r8        # 22760 <fwp_heap>
    6c07:	48 8b 04 24          	mov    (%rsp),%rax
    6c0b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6c12:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6c19:	48 c1 e2 10          	shl    $0x10,%rdx
    6c1d:	48 39 d0             	cmp    %rdx,%rax
    6c20:	0f 83 35 ff ff ff    	jae    6b5b <fwp_drop4+0x8b>
    6c26:	48 8b 14 24          	mov    (%rsp),%rdx
    6c2a:	e9 cd fe ff ff       	jmp    6afc <fwp_drop4+0x2c>
    6c2f:	90                   	nop
    6c30:	c3                   	ret
    6c31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c38:	48 89 14 24          	mov    %rdx,(%rsp)
    6c3c:	e8 ff f6 ff ff       	call   6340 <fwp_rc_free_obj>
    6c41:	48 8b 14 24          	mov    (%rsp),%rdx
    6c45:	eb a9                	jmp    6bf0 <fwp_drop4+0x120>
    6c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c4e:	00 00 
    6c50:	66 85 c0             	test   %ax,%ax
    6c53:	75 9b                	jne    6bf0 <fwp_drop4+0x120>
    6c55:	e9 7a ff ff ff       	jmp    6bd4 <fwp_drop4+0x104>
    6c5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c60:	48 89 c8             	mov    %rcx,%rax
    6c63:	48 c1 e8 11          	shr    $0x11,%rax
    6c67:	48 31 c8             	xor    %rcx,%rax
    6c6a:	48 89 c2             	mov    %rax,%rdx
    6c6d:	48 c1 ea 09          	shr    $0x9,%rdx
    6c71:	48 31 d0             	xor    %rdx,%rax
    6c74:	0f b6 d0             	movzbl %al,%edx
    6c77:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6c7e:	00 
    6c7f:	48 85 c0             	test   %rax,%rax
    6c82:	75 29                	jne    6cad <fwp_drop4+0x1dd>
    6c84:	e9 e3 00 00 00       	jmp    6d6c <fwp_drop4+0x29c>
    6c89:	90                   	nop
    6c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c91:	00 00 00 00 
    6c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c9c:	00 00 00 00 
    6ca0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6ca4:	48 85 c0             	test   %rax,%rax
    6ca7:	0f 84 bf 00 00 00    	je     6d6c <fwp_drop4+0x29c>
    6cad:	48 89 c2             	mov    %rax,%rdx
    6cb0:	48 39 08             	cmp    %rcx,(%rax)
    6cb3:	75 eb                	jne    6ca0 <fwp_drop4+0x1d0>
    6cb5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6cb9:	48 83 ea 01          	sub    $0x1,%rdx
    6cbd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6cc1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6cc8:	0f 85 8d fe ff ff    	jne    6b5b <fwp_drop4+0x8b>
    6cce:	48 89 cf             	mov    %rcx,%rdi
    6cd1:	48 89 0c 24          	mov    %rcx,(%rsp)
    6cd5:	e8 36 e6 ff ff       	call   5310 <fwp_rc_forget_slot>
    6cda:	48 8b 0c 24          	mov    (%rsp),%rcx
    6cde:	c6 01 fe             	movb   $0xfe,(%rcx)
    6ce1:	e9 75 fe ff ff       	jmp    6b5b <fwp_drop4+0x8b>
    6ce6:	48 89 ce             	mov    %rcx,%rsi
    6ce9:	48 c1 ee 11          	shr    $0x11,%rsi
    6ced:	48 31 ce             	xor    %rcx,%rsi
    6cf0:	48 89 f0             	mov    %rsi,%rax
    6cf3:	48 c1 e8 09          	shr    $0x9,%rax
    6cf7:	48 31 c6             	xor    %rax,%rsi
    6cfa:	40 0f b6 f6          	movzbl %sil,%esi
    6cfe:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6d05:	00 
    6d06:	48 85 c0             	test   %rax,%rax
    6d09:	75 1e                	jne    6d29 <fwp_drop4+0x259>
    6d0b:	eb 5f                	jmp    6d6c <fwp_drop4+0x29c>
    6d0d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d14:	00 
    6d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d1c:	00 00 00 00 
    6d20:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6d24:	48 85 c0             	test   %rax,%rax
    6d27:	74 43                	je     6d6c <fwp_drop4+0x29c>
    6d29:	48 89 c6             	mov    %rax,%rsi
    6d2c:	48 39 08             	cmp    %rcx,(%rax)
    6d2f:	75 ef                	jne    6d20 <fwp_drop4+0x250>
    6d31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d35:	48 83 ee 01          	sub    $0x1,%rsi
    6d39:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6d3d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6d44:	0f 85 a6 fe ff ff    	jne    6bf0 <fwp_drop4+0x120>
    6d4a:	48 89 cf             	mov    %rcx,%rdi
    6d4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d52:	48 89 0c 24          	mov    %rcx,(%rsp)
    6d56:	e8 b5 e5 ff ff       	call   5310 <fwp_rc_forget_slot>
    6d5b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6d5f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d64:	c6 01 fe             	movb   $0xfe,(%rcx)
    6d67:	e9 84 fe ff ff       	jmp    6bf0 <fwp_drop4+0x120>
    6d6c:	48 8d 3d 2d 7a 00 00 	lea    0x7a2d(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    6d73:	e8 28 d4 ff ff       	call   41a0 <fwp_trap>
    6d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d7f:	00 

0000000000006d80 <fwp_arg_drop37>:
    6d80:	f3 0f 1e fa          	endbr64
    6d84:	85 f6                	test   %esi,%esi
    6d86:	75 04                	jne    6d8c <fwp_arg_drop37+0xc>
    6d88:	85 d2                	test   %edx,%edx
    6d8a:	75 04                	jne    6d90 <fwp_arg_drop37+0x10>
    6d8c:	c3                   	ret
    6d8d:	0f 1f 00             	nopl   (%rax)
    6d90:	48 8b 3f             	mov    (%rdi),%rdi
    6d93:	e9 38 fd ff ff       	jmp    6ad0 <fwp_drop4>
    6d98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d9f:	00 

0000000000006da0 <fwp_task_dispose>:
    6da0:	53                   	push   %rbx
    6da1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6da5:	0f 84 9b c9 ff ff    	je     3746 <fwp_task_dispose.cold>
    6dab:	48 89 fb             	mov    %rdi,%rbx
    6dae:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6db3:	0f 85 8d c9 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6db9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6dbd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6dc4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6dcb:	00 
    6dcc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6dd0:	48 85 ff             	test   %rdi,%rdi
    6dd3:	74 07                	je     6ddc <fwp_task_dispose+0x3c>
    6dd5:	48 85 c0             	test   %rax,%rax
    6dd8:	74 02                	je     6ddc <fwp_task_dispose+0x3c>
    6dda:	ff d0                	call   *%rax
    6ddc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6de3:	e8 68 e7 ff ff       	call   5550 <fwp_mem_free>
    6de8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6def:	00 00 00 00 
    6df3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6df7:	74 6f                	je     6e68 <fwp_task_dispose+0xc8>
    6df9:	48 8b 15 38 cd 01 00 	mov    0x1cd38(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    6e00:	48 89 d8             	mov    %rbx,%rax
    6e03:	48 2b 05 06 cd 01 00 	sub    0x1cd06(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6e0a:	48 c1 e2 10          	shl    $0x10,%rdx
    6e0e:	48 39 d0             	cmp    %rdx,%rax
    6e11:	73 4c                	jae    6e5f <fwp_task_dispose+0xbf>
    6e13:	48 89 c2             	mov    %rax,%rdx
    6e16:	48 c1 ea 10          	shr    $0x10,%rdx
    6e1a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e1e:	48 8b 15 33 cd 01 00 	mov    0x1cd33(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    6e25:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6e29:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6e2d:	48 85 c9             	test   %rcx,%rcx
    6e30:	74 2d                	je     6e5f <fwp_task_dispose+0xbf>
    6e32:	0f b6 32             	movzbl (%rdx),%esi
    6e35:	40 80 fe 02          	cmp    $0x2,%sil
    6e39:	74 3d                	je     6e78 <fwp_task_dispose+0xd8>
    6e3b:	40 80 fe 01          	cmp    $0x1,%sil
    6e3f:	75 1e                	jne    6e5f <fwp_task_dispose+0xbf>
    6e41:	8b 72 18             	mov    0x18(%rdx),%esi
    6e44:	0f b7 c0             	movzwl %ax,%eax
    6e47:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e4a:	48 0f af c6          	imul   %rsi,%rax
    6e4e:	48 c1 e8 20          	shr    $0x20,%rax
    6e52:	48 39 d0             	cmp    %rdx,%rax
    6e55:	73 08                	jae    6e5f <fwp_task_dispose+0xbf>
    6e57:	48 01 c1             	add    %rax,%rcx
    6e5a:	80 39 01             	cmpb   $0x1,(%rcx)
    6e5d:	74 09                	je     6e68 <fwp_task_dispose+0xc8>
    6e5f:	5b                   	pop    %rbx
    6e60:	c3                   	ret
    6e61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e68:	48 89 df             	mov    %rbx,%rdi
    6e6b:	5b                   	pop    %rbx
    6e6c:	e9 df e6 ff ff       	jmp    5550 <fwp_mem_free>
    6e71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e78:	66 85 c0             	test   %ax,%ax
    6e7b:	74 dd                	je     6e5a <fwp_task_dispose+0xba>
    6e7d:	5b                   	pop    %rbx
    6e7e:	c3                   	ret
    6e7f:	90                   	nop

0000000000006e80 <fwp_free_zombie>:
    6e80:	48 8b 15 a9 b8 01 00 	mov    0x1b8a9(%rip),%rdx        # 22730 <fwp_zombie>
    6e87:	48 85 d2             	test   %rdx,%rdx
    6e8a:	0f 84 98 00 00 00    	je     6f28 <fwp_free_zombie+0xa8>
    6e90:	48 3b 15 a9 b8 01 00 	cmp    0x1b8a9(%rip),%rdx        # 22740 <fwp_cur>
    6e97:	0f 84 8b 00 00 00    	je     6f28 <fwp_free_zombie+0xa8>
    6e9d:	48 83 ec 18          	sub    $0x18,%rsp
    6ea1:	48 63 05 64 b2 01 00 	movslq 0x1b264(%rip),%rax        # 2210c <fwp_stack_pool_n>
    6ea8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6eac:	83 f8 3f             	cmp    $0x3f,%eax
    6eaf:	7f 7f                	jg     6f30 <fwp_free_zombie+0xb0>
    6eb1:	8d 48 01             	lea    0x1(%rax),%ecx
    6eb4:	89 0d 52 b2 01 00    	mov    %ecx,0x1b252(%rip)        # 2210c <fwp_stack_pool_n>
    6eba:	48 8d 0d 5f b2 01 00 	lea    0x1b25f(%rip),%rcx        # 22120 <fwp_stack_pool>
    6ec1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6ec5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6ecc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6ed0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6ed7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6edb:	48 85 c9             	test   %rcx,%rcx
    6ede:	0f 84 fc 00 00 00    	je     6fe0 <fwp_free_zombie+0x160>
    6ee4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    6eeb:	48 85 c0             	test   %rax,%rax
    6eee:	74 07                	je     6ef7 <fwp_free_zombie+0x77>
    6ef0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    6ef7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    6efa:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6efe:	48 c7 05 27 b8 01 00 	movq   $0x0,0x1b827(%rip)        # 22730 <fwp_zombie>
    6f05:	00 00 00 00 
    6f09:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    6f10:	85 c0                	test   %eax,%eax
    6f12:	74 34                	je     6f48 <fwp_free_zombie+0xc8>
    6f14:	83 f8 01             	cmp    $0x1,%eax
    6f17:	0f 84 b3 00 00 00    	je     6fd0 <fwp_free_zombie+0x150>
    6f1d:	48 83 c4 18          	add    $0x18,%rsp
    6f21:	c3                   	ret
    6f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f28:	c3                   	ret
    6f29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f30:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    6f34:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f39:	e8 a2 c6 ff ff       	call   35e0 <munmap@plt>
    6f3e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f43:	eb 80                	jmp    6ec5 <fwp_free_zombie+0x45>
    6f45:	0f 1f 00             	nopl   (%rax)
    6f48:	48 8b 0d e9 cb 01 00 	mov    0x1cbe9(%rip),%rcx        # 23b38 <fwp_heap+0x13d8>
    6f4f:	48 89 d0             	mov    %rdx,%rax
    6f52:	48 2b 05 b7 cb 01 00 	sub    0x1cbb7(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    6f59:	48 c1 e1 10          	shl    $0x10,%rcx
    6f5d:	48 39 c8             	cmp    %rcx,%rax
    6f60:	73 bb                	jae    6f1d <fwp_free_zombie+0x9d>
    6f62:	48 89 c1             	mov    %rax,%rcx
    6f65:	48 c1 e9 10          	shr    $0x10,%rcx
    6f69:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6f6d:	48 8b 0d e4 cb 01 00 	mov    0x1cbe4(%rip),%rcx        # 23b58 <fwp_heap+0x13f8>
    6f74:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    6f78:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6f7c:	48 85 c9             	test   %rcx,%rcx
    6f7f:	74 9c                	je     6f1d <fwp_free_zombie+0x9d>
    6f81:	0f b6 3e             	movzbl (%rsi),%edi
    6f84:	40 80 ff 02          	cmp    $0x2,%dil
    6f88:	74 66                	je     6ff0 <fwp_free_zombie+0x170>
    6f8a:	40 80 ff 01          	cmp    $0x1,%dil
    6f8e:	75 8d                	jne    6f1d <fwp_free_zombie+0x9d>
    6f90:	8b 7e 18             	mov    0x18(%rsi),%edi
    6f93:	0f b7 c0             	movzwl %ax,%eax
    6f96:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6f99:	48 0f af c7          	imul   %rdi,%rax
    6f9d:	48 c1 e8 20          	shr    $0x20,%rax
    6fa1:	48 39 f0             	cmp    %rsi,%rax
    6fa4:	0f 83 73 ff ff ff    	jae    6f1d <fwp_free_zombie+0x9d>
    6faa:	48 01 c1             	add    %rax,%rcx
    6fad:	0f b6 01             	movzbl (%rcx),%eax
    6fb0:	84 c0                	test   %al,%al
    6fb2:	0f 84 65 ff ff ff    	je     6f1d <fwp_free_zombie+0x9d>
    6fb8:	3c 01                	cmp    $0x1,%al
    6fba:	74 14                	je     6fd0 <fwp_free_zombie+0x150>
    6fbc:	3c ff                	cmp    $0xff,%al
    6fbe:	74 3b                	je     6ffb <fwp_free_zombie+0x17b>
    6fc0:	83 e8 01             	sub    $0x1,%eax
    6fc3:	88 01                	mov    %al,(%rcx)
    6fc5:	e9 53 ff ff ff       	jmp    6f1d <fwp_free_zombie+0x9d>
    6fca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fd0:	48 89 d7             	mov    %rdx,%rdi
    6fd3:	48 83 c4 18          	add    $0x18,%rsp
    6fd7:	e9 c4 fd ff ff       	jmp    6da0 <fwp_task_dispose>
    6fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    6fe0:	48 89 05 21 b7 01 00 	mov    %rax,0x1b721(%rip)        # 22708 <fwp_tasks_active>
    6fe7:	e9 ff fe ff ff       	jmp    6eeb <fwp_free_zombie+0x6b>
    6fec:	0f 1f 40 00          	nopl   0x0(%rax)
    6ff0:	66 85 c0             	test   %ax,%ax
    6ff3:	0f 85 24 ff ff ff    	jne    6f1d <fwp_free_zombie+0x9d>
    6ff9:	eb b2                	jmp    6fad <fwp_free_zombie+0x12d>
    6ffb:	48 89 ca             	mov    %rcx,%rdx
    6ffe:	48 8d 35 5b b7 01 00 	lea    0x1b75b(%rip),%rsi        # 22760 <fwp_heap>
    7005:	48 c1 ea 11          	shr    $0x11,%rdx
    7009:	48 31 ca             	xor    %rcx,%rdx
    700c:	48 89 d0             	mov    %rdx,%rax
    700f:	48 c1 e8 09          	shr    $0x9,%rax
    7013:	48 31 c2             	xor    %rax,%rdx
    7016:	0f b6 d2             	movzbl %dl,%edx
    7019:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7020:	00 
    7021:	48 85 c0             	test   %rax,%rax
    7024:	75 23                	jne    7049 <fwp_free_zombie+0x1c9>
    7026:	eb 5c                	jmp    7084 <fwp_free_zombie+0x204>
    7028:	66 90                	xchg   %ax,%ax
    702a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7031:	00 00 00 00 
    7035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    703c:	00 00 00 00 
    7040:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7044:	48 85 c0             	test   %rax,%rax
    7047:	74 3b                	je     7084 <fwp_free_zombie+0x204>
    7049:	48 89 c2             	mov    %rax,%rdx
    704c:	48 39 08             	cmp    %rcx,(%rax)
    704f:	75 ef                	jne    7040 <fwp_free_zombie+0x1c0>
    7051:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7055:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7059:	48 89 50 08          	mov    %rdx,0x8(%rax)
    705d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7064:	0f 85 b3 fe ff ff    	jne    6f1d <fwp_free_zombie+0x9d>
    706a:	48 89 cf             	mov    %rcx,%rdi
    706d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7072:	e8 99 e2 ff ff       	call   5310 <fwp_rc_forget_slot>
    7077:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    707c:	c6 01 fe             	movb   $0xfe,(%rcx)
    707f:	e9 99 fe ff ff       	jmp    6f1d <fwp_free_zombie+0x9d>
    7084:	48 8d 3d 15 77 00 00 	lea    0x7715(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    708b:	e8 10 d1 ff ff       	call   41a0 <fwp_trap>

0000000000007090 <fwp_block>:
    7090:	48 83 ec 08          	sub    $0x8,%rsp
    7094:	48 8b 05 8d b6 01 00 	mov    0x1b68d(%rip),%rax        # 22728 <fwp_ready_head>
    709b:	48 85 c0             	test   %rax,%rax
    709e:	0f 84 1c 01 00 00    	je     71c0 <fwp_block+0x130>
    70a4:	90                   	nop
    70a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70ac:	00 00 00 00 
    70b0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    70b7:	48 89 15 6a b6 01 00 	mov    %rdx,0x1b66a(%rip)        # 22728 <fwp_ready_head>
    70be:	48 85 d2             	test   %rdx,%rdx
    70c1:	0f 84 19 01 00 00    	je     71e0 <fwp_block+0x150>
    70c7:	48 8b 15 72 b6 01 00 	mov    0x1b672(%rip),%rdx        # 22740 <fwp_cur>
    70ce:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    70d2:	48 39 c2             	cmp    %rax,%rdx
    70d5:	0f 84 d5 00 00 00    	je     71b0 <fwp_block+0x120>
    70db:	48 8b 0d e6 d2 01 00 	mov    0x1d2e6(%rip),%rcx        # 243c8 <fwp_state_owners>
    70e2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    70e6:	48 89 05 53 b6 01 00 	mov    %rax,0x1b653(%rip)        # 22740 <fwp_cur>
    70ed:	f3 0f 7e 05 fb d2 01 	movq   0x1d2fb(%rip),%xmm0        # 243f0 <fwp_foreign_callbacks>
    70f4:	00 
    70f5:	0f 16 05 e4 d2 01 00 	movhps 0x1d2e4(%rip),%xmm0        # 243e0 <fwp_state>
    70fc:	f3 0f 7e 0d e4 d2 01 	movq   0x1d2e4(%rip),%xmm1        # 243e8 <fwp_handlers>
    7103:	00 
    7104:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    710b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7112:	0f 16 0d df d2 01 00 	movhps 0x1d2df(%rip),%xmm1        # 243f8 <fwp_cleanups>
    7119:	f3 0f 7e 05 b7 d2 01 	movq   0x1d2b7(%rip),%xmm0        # 243d8 <fwp_state_len>
    7120:	00 
    7121:	0f 16 05 a8 d2 01 00 	movhps 0x1d2a8(%rip),%xmm0        # 243d0 <fwp_state_cap>
    7128:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    712f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7136:	48 8b 70 08          	mov    0x8(%rax),%rsi
    713a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7141:	48 89 0d a0 d2 01 00 	mov    %rcx,0x1d2a0(%rip)        # 243e8 <fwp_handlers>
    7148:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    714f:	48 89 0d a2 d2 01 00 	mov    %rcx,0x1d2a2(%rip)        # 243f8 <fwp_cleanups>
    7156:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    715d:	48 89 0d 8c d2 01 00 	mov    %rcx,0x1d28c(%rip)        # 243f0 <fwp_foreign_callbacks>
    7164:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    716b:	48 89 0d 6e d2 01 00 	mov    %rcx,0x1d26e(%rip)        # 243e0 <fwp_state>
    7172:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7179:	48 89 0d 58 d2 01 00 	mov    %rcx,0x1d258(%rip)        # 243d8 <fwp_state_len>
    7180:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7187:	48 89 0d 42 d2 01 00 	mov    %rcx,0x1d242(%rip)        # 243d0 <fwp_state_cap>
    718e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7195:	48 89 0d 2c d2 01 00 	mov    %rcx,0x1d22c(%rip)        # 243c8 <fwp_state_owners>
    719c:	e8 ef c2 ff ff       	call   3490 <swapcontext@plt>
    71a1:	f3 0f 1e fa          	endbr64
    71a5:	e8 d6 fc ff ff       	call   6e80 <fwp_free_zombie>
    71aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71b0:	8b 05 52 af 01 00    	mov    0x1af52(%rip),%eax        # 22108 <fwp_slice>
    71b6:	85 c0                	test   %eax,%eax
    71b8:	74 36                	je     71f0 <fwp_block+0x160>
    71ba:	48 83 c4 08          	add    $0x8,%rsp
    71be:	c3                   	ret
    71bf:	90                   	nop
    71c0:	e8 9b dd ff ff       	call   4f60 <fwp_poll_events>
    71c5:	48 8b 05 5c b5 01 00 	mov    0x1b55c(%rip),%rax        # 22728 <fwp_ready_head>
    71cc:	48 85 c0             	test   %rax,%rax
    71cf:	0f 85 db fe ff ff    	jne    70b0 <fwp_block+0x20>
    71d5:	eb e9                	jmp    71c0 <fwp_block+0x130>
    71d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    71de:	00 00 
    71e0:	48 c7 05 35 b5 01 00 	movq   $0x0,0x1b535(%rip)        # 22720 <fwp_ready_tail>
    71e7:	00 00 00 00 
    71eb:	e9 d7 fe ff ff       	jmp    70c7 <fwp_block+0x37>
    71f0:	48 8d 3d 2a 6f 00 00 	lea    0x6f2a(%rip),%rdi        # e121 <_IO_stdin_used+0x121>
    71f7:	e8 a4 c1 ff ff       	call   33a0 <getenv@plt>
    71fc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7201:	48 85 c0             	test   %rax,%rax
    7204:	74 05                	je     720b <fwp_block+0x17b>
    7206:	80 38 00             	cmpb   $0x0,(%rax)
    7209:	75 0b                	jne    7216 <fwp_block+0x186>
    720b:	89 15 f7 ae 01 00    	mov    %edx,0x1aef7(%rip)        # 22108 <fwp_slice>
    7211:	48 83 c4 08          	add    $0x8,%rsp
    7215:	c3                   	ret
    7216:	ba 0a 00 00 00       	mov    $0xa,%edx
    721b:	31 f6                	xor    %esi,%esi
    721d:	48 89 c7             	mov    %rax,%rdi
    7220:	e8 2b c3 ff ff       	call   3550 <strtoll@plt>
    7225:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7229:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7230:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7235:	0f 46 d0             	cmovbe %eax,%edx
    7238:	eb d1                	jmp    720b <fwp_block+0x17b>
    723a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007240 <fwp_caps173>:
    7240:	f3 0f 1e fa          	endbr64
    7244:	85 f6                	test   %esi,%esi
    7246:	74 08                	je     7250 <fwp_caps173+0x10>
    7248:	c3                   	ret
    7249:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7250:	48 8b 15 e1 c8 01 00 	mov    0x1c8e1(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7257:	48 89 f8             	mov    %rdi,%rax
    725a:	48 2b 05 af c8 01 00 	sub    0x1c8af(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7261:	48 c1 e2 10          	shl    $0x10,%rdx
    7265:	48 39 d0             	cmp    %rdx,%rax
    7268:	73 de                	jae    7248 <fwp_caps173+0x8>
    726a:	48 89 c2             	mov    %rax,%rdx
    726d:	48 c1 ea 10          	shr    $0x10,%rdx
    7271:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7275:	48 8b 15 dc c8 01 00 	mov    0x1c8dc(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    727c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7280:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7284:	48 85 c9             	test   %rcx,%rcx
    7287:	74 bf                	je     7248 <fwp_caps173+0x8>
    7289:	0f b6 32             	movzbl (%rdx),%esi
    728c:	40 80 fe 02          	cmp    $0x2,%sil
    7290:	74 2e                	je     72c0 <fwp_caps173+0x80>
    7292:	40 80 fe 01          	cmp    $0x1,%sil
    7296:	75 b0                	jne    7248 <fwp_caps173+0x8>
    7298:	8b 72 18             	mov    0x18(%rdx),%esi
    729b:	0f b7 c0             	movzwl %ax,%eax
    729e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    72a1:	48 0f af c6          	imul   %rsi,%rax
    72a5:	48 c1 e8 20          	shr    $0x20,%rax
    72a9:	48 39 d0             	cmp    %rdx,%rax
    72ac:	73 9a                	jae    7248 <fwp_caps173+0x8>
    72ae:	48 01 c1             	add    %rax,%rcx
    72b1:	80 39 01             	cmpb   $0x1,(%rcx)
    72b4:	75 92                	jne    7248 <fwp_caps173+0x8>
    72b6:	e9 95 e2 ff ff       	jmp    5550 <fwp_mem_free>
    72bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    72c0:	66 85 c0             	test   %ax,%ax
    72c3:	74 ec                	je     72b1 <fwp_caps173+0x71>
    72c5:	c3                   	ret
    72c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72cd:	00 00 00 

00000000000072d0 <fwp_args37>:
    72d0:	f3 0f 1e fa          	endbr64
    72d4:	85 d2                	test   %edx,%edx
    72d6:	74 04                	je     72dc <fwp_args37+0xc>
    72d8:	85 f6                	test   %esi,%esi
    72da:	74 04                	je     72e0 <fwp_args37+0x10>
    72dc:	c3                   	ret
    72dd:	0f 1f 00             	nopl   (%rax)
    72e0:	48 8b 15 51 c8 01 00 	mov    0x1c851(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    72e7:	48 8b 07             	mov    (%rdi),%rax
    72ea:	48 2b 05 1f c8 01 00 	sub    0x1c81f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    72f1:	48 c1 e2 10          	shl    $0x10,%rdx
    72f5:	48 39 d0             	cmp    %rdx,%rax
    72f8:	73 e2                	jae    72dc <fwp_args37+0xc>
    72fa:	48 89 c2             	mov    %rax,%rdx
    72fd:	48 c1 ea 10          	shr    $0x10,%rdx
    7301:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7305:	48 8b 15 4c c8 01 00 	mov    0x1c84c(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    730c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7310:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7314:	48 85 ff             	test   %rdi,%rdi
    7317:	74 c3                	je     72dc <fwp_args37+0xc>
    7319:	0f b6 0a             	movzbl (%rdx),%ecx
    731c:	80 f9 02             	cmp    $0x2,%cl
    731f:	74 2f                	je     7350 <fwp_args37+0x80>
    7321:	80 f9 01             	cmp    $0x1,%cl
    7324:	75 b6                	jne    72dc <fwp_args37+0xc>
    7326:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7329:	0f b7 c0             	movzwl %ax,%eax
    732c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    732f:	48 0f af c1          	imul   %rcx,%rax
    7333:	48 c1 e8 20          	shr    $0x20,%rax
    7337:	48 39 d0             	cmp    %rdx,%rax
    733a:	73 a0                	jae    72dc <fwp_args37+0xc>
    733c:	48 01 c7             	add    %rax,%rdi
    733f:	0f b6 07             	movzbl (%rdi),%eax
    7342:	84 c0                	test   %al,%al
    7344:	74 96                	je     72dc <fwp_args37+0xc>
    7346:	3c fd                	cmp    $0xfd,%al
    7348:	77 0c                	ja     7356 <fwp_args37+0x86>
    734a:	83 c0 01             	add    $0x1,%eax
    734d:	88 07                	mov    %al,(%rdi)
    734f:	c3                   	ret
    7350:	66 85 c0             	test   %ax,%ax
    7353:	74 ea                	je     733f <fwp_args37+0x6f>
    7355:	c3                   	ret
    7356:	e9 95 de ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    735b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007360 <fwp_caps37>:
    7360:	f3 0f 1e fa          	endbr64
    7364:	48 83 ec 18          	sub    $0x18,%rsp
    7368:	8b 57 04             	mov    0x4(%rdi),%edx
    736b:	48 89 f8             	mov    %rdi,%rax
    736e:	85 d2                	test   %edx,%edx
    7370:	0f 84 9a 00 00 00    	je     7410 <fwp_caps37+0xb0>
    7376:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    737a:	85 f6                	test   %esi,%esi
    737c:	0f 85 9e 00 00 00    	jne    7420 <fwp_caps37+0xc0>
    7382:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7387:	e8 44 f7 ff ff       	call   6ad0 <fwp_drop4>
    738c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7391:	48 8b 0d a0 c7 01 00 	mov    0x1c7a0(%rip),%rcx        # 23b38 <fwp_heap+0x13d8>
    7398:	48 89 c2             	mov    %rax,%rdx
    739b:	48 2b 15 6e c7 01 00 	sub    0x1c76e(%rip),%rdx        # 23b10 <fwp_heap+0x13b0>
    73a2:	48 c1 e1 10          	shl    $0x10,%rcx
    73a6:	48 39 ca             	cmp    %rcx,%rdx
    73a9:	73 6d                	jae    7418 <fwp_caps37+0xb8>
    73ab:	48 89 d1             	mov    %rdx,%rcx
    73ae:	48 c1 e9 10          	shr    $0x10,%rcx
    73b2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    73b6:	48 8b 0d 9b c7 01 00 	mov    0x1c79b(%rip),%rcx        # 23b58 <fwp_heap+0x13f8>
    73bd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    73c1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    73c5:	48 85 f6             	test   %rsi,%rsi
    73c8:	74 4e                	je     7418 <fwp_caps37+0xb8>
    73ca:	0f b6 39             	movzbl (%rcx),%edi
    73cd:	40 80 ff 02          	cmp    $0x2,%dil
    73d1:	0f 84 b9 00 00 00    	je     7490 <fwp_caps37+0x130>
    73d7:	40 80 ff 01          	cmp    $0x1,%dil
    73db:	75 3b                	jne    7418 <fwp_caps37+0xb8>
    73dd:	8b 79 18             	mov    0x18(%rcx),%edi
    73e0:	0f b7 d2             	movzwl %dx,%edx
    73e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    73e6:	48 0f af d7          	imul   %rdi,%rdx
    73ea:	48 c1 ea 20          	shr    $0x20,%rdx
    73ee:	48 39 ca             	cmp    %rcx,%rdx
    73f1:	73 25                	jae    7418 <fwp_caps37+0xb8>
    73f3:	48 01 d6             	add    %rdx,%rsi
    73f6:	80 3e 01             	cmpb   $0x1,(%rsi)
    73f9:	75 1d                	jne    7418 <fwp_caps37+0xb8>
    73fb:	48 89 c7             	mov    %rax,%rdi
    73fe:	48 83 c4 18          	add    $0x18,%rsp
    7402:	e9 49 e1 ff ff       	jmp    5550 <fwp_mem_free>
    7407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    740e:	00 00 
    7410:	85 f6                	test   %esi,%esi
    7412:	0f 84 79 ff ff ff    	je     7391 <fwp_caps37+0x31>
    7418:	48 83 c4 18          	add    $0x18,%rsp
    741c:	c3                   	ret
    741d:	0f 1f 00             	nopl   (%rax)
    7420:	48 8b 05 11 c7 01 00 	mov    0x1c711(%rip),%rax        # 23b38 <fwp_heap+0x13d8>
    7427:	48 2b 3d e2 c6 01 00 	sub    0x1c6e2(%rip),%rdi        # 23b10 <fwp_heap+0x13b0>
    742e:	48 c1 e0 10          	shl    $0x10,%rax
    7432:	48 39 c7             	cmp    %rax,%rdi
    7435:	73 e1                	jae    7418 <fwp_caps37+0xb8>
    7437:	48 89 f8             	mov    %rdi,%rax
    743a:	48 c1 e8 10          	shr    $0x10,%rax
    743e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7442:	48 8b 05 0f c7 01 00 	mov    0x1c70f(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    7449:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    744d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7451:	48 85 c0             	test   %rax,%rax
    7454:	74 c2                	je     7418 <fwp_caps37+0xb8>
    7456:	0f b6 0a             	movzbl (%rdx),%ecx
    7459:	80 f9 02             	cmp    $0x2,%cl
    745c:	74 42                	je     74a0 <fwp_caps37+0x140>
    745e:	80 f9 01             	cmp    $0x1,%cl
    7461:	75 b5                	jne    7418 <fwp_caps37+0xb8>
    7463:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7466:	0f b7 ff             	movzwl %di,%edi
    7469:	8b 52 1c             	mov    0x1c(%rdx),%edx
    746c:	48 0f af f9          	imul   %rcx,%rdi
    7470:	48 c1 ef 20          	shr    $0x20,%rdi
    7474:	48 39 d7             	cmp    %rdx,%rdi
    7477:	73 9f                	jae    7418 <fwp_caps37+0xb8>
    7479:	48 01 f8             	add    %rdi,%rax
    747c:	0f b6 10             	movzbl (%rax),%edx
    747f:	84 d2                	test   %dl,%dl
    7481:	74 95                	je     7418 <fwp_caps37+0xb8>
    7483:	80 fa fd             	cmp    $0xfd,%dl
    7486:	77 23                	ja     74ab <fwp_caps37+0x14b>
    7488:	83 c2 01             	add    $0x1,%edx
    748b:	88 10                	mov    %dl,(%rax)
    748d:	eb 89                	jmp    7418 <fwp_caps37+0xb8>
    748f:	90                   	nop
    7490:	66 85 d2             	test   %dx,%dx
    7493:	0f 85 7f ff ff ff    	jne    7418 <fwp_caps37+0xb8>
    7499:	e9 58 ff ff ff       	jmp    73f6 <fwp_caps37+0x96>
    749e:	66 90                	xchg   %ax,%ax
    74a0:	66 85 ff             	test   %di,%di
    74a3:	0f 85 6f ff ff ff    	jne    7418 <fwp_caps37+0xb8>
    74a9:	eb d1                	jmp    747c <fwp_caps37+0x11c>
    74ab:	48 89 c7             	mov    %rax,%rdi
    74ae:	48 83 c4 18          	add    $0x18,%rsp
    74b2:	e9 39 dd ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    74b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    74be:	00 00 

00000000000074c0 <fwp_drop0>:
    74c0:	f3 0f 1e fa          	endbr64
    74c4:	48 8b 15 6d c6 01 00 	mov    0x1c66d(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    74cb:	48 89 f8             	mov    %rdi,%rax
    74ce:	48 2b 05 3b c6 01 00 	sub    0x1c63b(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    74d5:	48 c1 e2 10          	shl    $0x10,%rdx
    74d9:	48 39 d0             	cmp    %rdx,%rax
    74dc:	0f 83 36 01 00 00    	jae    7618 <fwp_drop0+0x158>
    74e2:	48 83 ec 18          	sub    $0x18,%rsp
    74e6:	48 8d 35 73 b2 01 00 	lea    0x1b273(%rip),%rsi        # 22760 <fwp_heap>
    74ed:	48 89 c2             	mov    %rax,%rdx
    74f0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    74f7:	48 c1 ea 10          	shr    $0x10,%rdx
    74fb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    74ff:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7503:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7507:	48 85 d2             	test   %rdx,%rdx
    750a:	74 42                	je     754e <fwp_drop0+0x8e>
    750c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7510:	41 80 f8 02          	cmp    $0x2,%r8b
    7514:	74 42                	je     7558 <fwp_drop0+0x98>
    7516:	41 80 f8 01          	cmp    $0x1,%r8b
    751a:	75 32                	jne    754e <fwp_drop0+0x8e>
    751c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7520:	0f b7 c0             	movzwl %ax,%eax
    7523:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7526:	49 0f af c0          	imul   %r8,%rax
    752a:	48 c1 e8 20          	shr    $0x20,%rax
    752e:	48 39 c8             	cmp    %rcx,%rax
    7531:	73 1b                	jae    754e <fwp_drop0+0x8e>
    7533:	48 01 c2             	add    %rax,%rdx
    7536:	0f b6 02             	movzbl (%rdx),%eax
    7539:	84 c0                	test   %al,%al
    753b:	74 11                	je     754e <fwp_drop0+0x8e>
    753d:	3c 01                	cmp    $0x1,%al
    753f:	74 27                	je     7568 <fwp_drop0+0xa8>
    7541:	3c ff                	cmp    $0xff,%al
    7543:	0f 84 e7 00 00 00    	je     7630 <fwp_drop0+0x170>
    7549:	83 e8 01             	sub    $0x1,%eax
    754c:	88 02                	mov    %al,(%rdx)
    754e:	48 83 c4 18          	add    $0x18,%rsp
    7552:	c3                   	ret
    7553:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7558:	66 85 c0             	test   %ax,%ax
    755b:	74 d9                	je     7536 <fwp_drop0+0x76>
    755d:	48 83 c4 18          	add    $0x18,%rsp
    7561:	c3                   	ret
    7562:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7568:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    756f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7576:	48 89 f8             	mov    %rdi,%rax
    7579:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    757d:	48 29 c8             	sub    %rcx,%rax
    7580:	48 c1 e2 10          	shl    $0x10,%rdx
    7584:	48 39 d0             	cmp    %rdx,%rax
    7587:	73 71                	jae    75fa <fwp_drop0+0x13a>
    7589:	49 89 c2             	mov    %rax,%r10
    758c:	49 c1 ea 10          	shr    $0x10,%r10
    7590:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7594:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7598:	4d 8b 51 20          	mov    0x20(%r9),%r10
    759c:	4d 85 d2             	test   %r10,%r10
    759f:	74 59                	je     75fa <fwp_drop0+0x13a>
    75a1:	45 0f b6 19          	movzbl (%r9),%r11d
    75a5:	41 80 fb 02          	cmp    $0x2,%r11b
    75a9:	74 75                	je     7620 <fwp_drop0+0x160>
    75ab:	41 80 fb 01          	cmp    $0x1,%r11b
    75af:	75 49                	jne    75fa <fwp_drop0+0x13a>
    75b1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    75b5:	0f b7 c0             	movzwl %ax,%eax
    75b8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    75bc:	49 0f af c3          	imul   %r11,%rax
    75c0:	48 c1 e8 20          	shr    $0x20,%rax
    75c4:	4c 39 c8             	cmp    %r9,%rax
    75c7:	73 31                	jae    75fa <fwp_drop0+0x13a>
    75c9:	49 01 c2             	add    %rax,%r10
    75cc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    75d0:	75 28                	jne    75fa <fwp_drop0+0x13a>
    75d2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    75d7:	e8 74 df ff ff       	call   5550 <fwp_mem_free>
    75dc:	48 8d 35 7d b1 01 00 	lea    0x1b17d(%rip),%rsi        # 22760 <fwp_heap>
    75e3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    75e8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    75ef:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    75f6:	48 c1 e2 10          	shl    $0x10,%rdx
    75fa:	4c 89 c0             	mov    %r8,%rax
    75fd:	48 29 c8             	sub    %rcx,%rax
    7600:	48 39 d0             	cmp    %rdx,%rax
    7603:	0f 83 45 ff ff ff    	jae    754e <fwp_drop0+0x8e>
    7609:	4c 89 c7             	mov    %r8,%rdi
    760c:	e9 dc fe ff ff       	jmp    74ed <fwp_drop0+0x2d>
    7611:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7618:	c3                   	ret
    7619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7620:	66 85 c0             	test   %ax,%ax
    7623:	75 d5                	jne    75fa <fwp_drop0+0x13a>
    7625:	eb a5                	jmp    75cc <fwp_drop0+0x10c>
    7627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    762e:	00 00 
    7630:	48 89 d0             	mov    %rdx,%rax
    7633:	48 c1 e8 11          	shr    $0x11,%rax
    7637:	48 31 d0             	xor    %rdx,%rax
    763a:	48 89 c1             	mov    %rax,%rcx
    763d:	48 c1 e9 09          	shr    $0x9,%rcx
    7641:	48 31 c8             	xor    %rcx,%rax
    7644:	0f b6 c8             	movzbl %al,%ecx
    7647:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    764e:	00 
    764f:	48 85 c0             	test   %rax,%rax
    7652:	75 15                	jne    7669 <fwp_drop0+0x1a9>
    7654:	eb 4e                	jmp    76a4 <fwp_drop0+0x1e4>
    7656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    765d:	00 00 00 
    7660:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7664:	48 85 c0             	test   %rax,%rax
    7667:	74 3b                	je     76a4 <fwp_drop0+0x1e4>
    7669:	48 89 c1             	mov    %rax,%rcx
    766c:	48 39 10             	cmp    %rdx,(%rax)
    766f:	75 ef                	jne    7660 <fwp_drop0+0x1a0>
    7671:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7675:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7679:	48 89 48 08          	mov    %rcx,0x8(%rax)
    767d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7684:	0f 85 c4 fe ff ff    	jne    754e <fwp_drop0+0x8e>
    768a:	48 89 d7             	mov    %rdx,%rdi
    768d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7692:	e8 79 dc ff ff       	call   5310 <fwp_rc_forget_slot>
    7697:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    769c:	c6 02 fe             	movb   $0xfe,(%rdx)
    769f:	e9 aa fe ff ff       	jmp    754e <fwp_drop0+0x8e>
    76a4:	48 8d 3d f5 70 00 00 	lea    0x70f5(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    76ab:	e8 f0 ca ff ff       	call   41a0 <fwp_trap>

00000000000076b0 <fwp_drop1>:
    76b0:	f3 0f 1e fa          	endbr64
    76b4:	48 8b 15 7d c4 01 00 	mov    0x1c47d(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    76bb:	48 89 f8             	mov    %rdi,%rax
    76be:	48 2b 05 4b c4 01 00 	sub    0x1c44b(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    76c5:	48 c1 e2 10          	shl    $0x10,%rdx
    76c9:	48 39 d0             	cmp    %rdx,%rax
    76cc:	0f 83 36 01 00 00    	jae    7808 <fwp_drop1+0x158>
    76d2:	48 83 ec 18          	sub    $0x18,%rsp
    76d6:	48 8d 35 83 b0 01 00 	lea    0x1b083(%rip),%rsi        # 22760 <fwp_heap>
    76dd:	48 89 c2             	mov    %rax,%rdx
    76e0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    76e7:	48 c1 ea 10          	shr    $0x10,%rdx
    76eb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    76ef:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    76f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    76f7:	48 85 d2             	test   %rdx,%rdx
    76fa:	74 42                	je     773e <fwp_drop1+0x8e>
    76fc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7700:	41 80 f8 02          	cmp    $0x2,%r8b
    7704:	74 42                	je     7748 <fwp_drop1+0x98>
    7706:	41 80 f8 01          	cmp    $0x1,%r8b
    770a:	75 32                	jne    773e <fwp_drop1+0x8e>
    770c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7710:	0f b7 c0             	movzwl %ax,%eax
    7713:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7716:	49 0f af c0          	imul   %r8,%rax
    771a:	48 c1 e8 20          	shr    $0x20,%rax
    771e:	48 39 c8             	cmp    %rcx,%rax
    7721:	73 1b                	jae    773e <fwp_drop1+0x8e>
    7723:	48 01 c2             	add    %rax,%rdx
    7726:	0f b6 02             	movzbl (%rdx),%eax
    7729:	84 c0                	test   %al,%al
    772b:	74 11                	je     773e <fwp_drop1+0x8e>
    772d:	3c 01                	cmp    $0x1,%al
    772f:	74 27                	je     7758 <fwp_drop1+0xa8>
    7731:	3c ff                	cmp    $0xff,%al
    7733:	0f 84 e7 00 00 00    	je     7820 <fwp_drop1+0x170>
    7739:	83 e8 01             	sub    $0x1,%eax
    773c:	88 02                	mov    %al,(%rdx)
    773e:	48 83 c4 18          	add    $0x18,%rsp
    7742:	c3                   	ret
    7743:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7748:	66 85 c0             	test   %ax,%ax
    774b:	74 d9                	je     7726 <fwp_drop1+0x76>
    774d:	48 83 c4 18          	add    $0x18,%rsp
    7751:	c3                   	ret
    7752:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7758:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    775f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7766:	48 89 f8             	mov    %rdi,%rax
    7769:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    776d:	48 29 c8             	sub    %rcx,%rax
    7770:	48 c1 e2 10          	shl    $0x10,%rdx
    7774:	48 39 d0             	cmp    %rdx,%rax
    7777:	73 71                	jae    77ea <fwp_drop1+0x13a>
    7779:	49 89 c2             	mov    %rax,%r10
    777c:	49 c1 ea 10          	shr    $0x10,%r10
    7780:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7784:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7788:	4d 8b 51 20          	mov    0x20(%r9),%r10
    778c:	4d 85 d2             	test   %r10,%r10
    778f:	74 59                	je     77ea <fwp_drop1+0x13a>
    7791:	45 0f b6 19          	movzbl (%r9),%r11d
    7795:	41 80 fb 02          	cmp    $0x2,%r11b
    7799:	74 75                	je     7810 <fwp_drop1+0x160>
    779b:	41 80 fb 01          	cmp    $0x1,%r11b
    779f:	75 49                	jne    77ea <fwp_drop1+0x13a>
    77a1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    77a5:	0f b7 c0             	movzwl %ax,%eax
    77a8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    77ac:	49 0f af c3          	imul   %r11,%rax
    77b0:	48 c1 e8 20          	shr    $0x20,%rax
    77b4:	4c 39 c8             	cmp    %r9,%rax
    77b7:	73 31                	jae    77ea <fwp_drop1+0x13a>
    77b9:	49 01 c2             	add    %rax,%r10
    77bc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    77c0:	75 28                	jne    77ea <fwp_drop1+0x13a>
    77c2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    77c7:	e8 84 dd ff ff       	call   5550 <fwp_mem_free>
    77cc:	48 8d 35 8d af 01 00 	lea    0x1af8d(%rip),%rsi        # 22760 <fwp_heap>
    77d3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    77d8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    77df:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    77e6:	48 c1 e2 10          	shl    $0x10,%rdx
    77ea:	4c 89 c0             	mov    %r8,%rax
    77ed:	48 29 c8             	sub    %rcx,%rax
    77f0:	48 39 d0             	cmp    %rdx,%rax
    77f3:	0f 83 45 ff ff ff    	jae    773e <fwp_drop1+0x8e>
    77f9:	4c 89 c7             	mov    %r8,%rdi
    77fc:	e9 dc fe ff ff       	jmp    76dd <fwp_drop1+0x2d>
    7801:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7808:	c3                   	ret
    7809:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7810:	66 85 c0             	test   %ax,%ax
    7813:	75 d5                	jne    77ea <fwp_drop1+0x13a>
    7815:	eb a5                	jmp    77bc <fwp_drop1+0x10c>
    7817:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    781e:	00 00 
    7820:	48 89 d0             	mov    %rdx,%rax
    7823:	48 c1 e8 11          	shr    $0x11,%rax
    7827:	48 31 d0             	xor    %rdx,%rax
    782a:	48 89 c1             	mov    %rax,%rcx
    782d:	48 c1 e9 09          	shr    $0x9,%rcx
    7831:	48 31 c8             	xor    %rcx,%rax
    7834:	0f b6 c8             	movzbl %al,%ecx
    7837:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    783e:	00 
    783f:	48 85 c0             	test   %rax,%rax
    7842:	75 25                	jne    7869 <fwp_drop1+0x1b9>
    7844:	eb 5e                	jmp    78a4 <fwp_drop1+0x1f4>
    7846:	0f 1f 40 00          	nopl   0x0(%rax)
    784a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7851:	00 00 00 00 
    7855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    785c:	00 00 00 00 
    7860:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7864:	48 85 c0             	test   %rax,%rax
    7867:	74 3b                	je     78a4 <fwp_drop1+0x1f4>
    7869:	48 89 c1             	mov    %rax,%rcx
    786c:	48 39 10             	cmp    %rdx,(%rax)
    786f:	75 ef                	jne    7860 <fwp_drop1+0x1b0>
    7871:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7875:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7879:	48 89 48 08          	mov    %rcx,0x8(%rax)
    787d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7884:	0f 85 b4 fe ff ff    	jne    773e <fwp_drop1+0x8e>
    788a:	48 89 d7             	mov    %rdx,%rdi
    788d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7892:	e8 79 da ff ff       	call   5310 <fwp_rc_forget_slot>
    7897:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    789c:	c6 02 fe             	movb   $0xfe,(%rdx)
    789f:	e9 9a fe ff ff       	jmp    773e <fwp_drop1+0x8e>
    78a4:	48 8d 3d f5 6e 00 00 	lea    0x6ef5(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    78ab:	e8 f0 c8 ff ff       	call   41a0 <fwp_trap>

00000000000078b0 <fwp_drop10>:
    78b0:	48 8b 0d 81 c2 01 00 	mov    0x1c281(%rip),%rcx        # 23b38 <fwp_heap+0x13d8>
    78b7:	48 89 f8             	mov    %rdi,%rax
    78ba:	48 2b 05 4f c2 01 00 	sub    0x1c24f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    78c1:	48 c1 e1 10          	shl    $0x10,%rcx
    78c5:	48 39 c8             	cmp    %rcx,%rax
    78c8:	0f 83 c2 01 00 00    	jae    7a90 <fwp_drop10+0x1e0>
    78ce:	48 83 ec 18          	sub    $0x18,%rsp
    78d2:	48 89 fa             	mov    %rdi,%rdx
    78d5:	48 8d 35 84 ae 01 00 	lea    0x1ae84(%rip),%rsi        # 22760 <fwp_heap>
    78dc:	48 89 c1             	mov    %rax,%rcx
    78df:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    78e6:	48 c1 e9 10          	shr    $0x10,%rcx
    78ea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    78ee:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    78f2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    78f6:	48 85 c9             	test   %rcx,%rcx
    78f9:	74 46                	je     7941 <fwp_drop10+0x91>
    78fb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    78ff:	41 80 f9 02          	cmp    $0x2,%r9b
    7903:	0f 84 d7 00 00 00    	je     79e0 <fwp_drop10+0x130>
    7909:	41 80 f9 01          	cmp    $0x1,%r9b
    790d:	75 32                	jne    7941 <fwp_drop10+0x91>
    790f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7913:	0f b7 c0             	movzwl %ax,%eax
    7916:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7919:	49 0f af c1          	imul   %r9,%rax
    791d:	48 c1 e8 20          	shr    $0x20,%rax
    7921:	48 39 f8             	cmp    %rdi,%rax
    7924:	73 1b                	jae    7941 <fwp_drop10+0x91>
    7926:	48 01 c1             	add    %rax,%rcx
    7929:	0f b6 01             	movzbl (%rcx),%eax
    792c:	84 c0                	test   %al,%al
    792e:	74 11                	je     7941 <fwp_drop10+0x91>
    7930:	3c 01                	cmp    $0x1,%al
    7932:	74 1c                	je     7950 <fwp_drop10+0xa0>
    7934:	3c ff                	cmp    $0xff,%al
    7936:	0f 84 5c 01 00 00    	je     7a98 <fwp_drop10+0x1e8>
    793c:	83 e8 01             	sub    $0x1,%eax
    793f:	88 01                	mov    %al,(%rcx)
    7941:	48 83 c4 18          	add    $0x18,%rsp
    7945:	c3                   	ret
    7946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    794d:	00 00 00 
    7950:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7957:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    795e:	48 89 d0             	mov    %rdx,%rax
    7961:	49 89 d1             	mov    %rdx,%r9
    7964:	48 c1 e1 10          	shl    $0x10,%rcx
    7968:	48 29 f8             	sub    %rdi,%rax
    796b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    796f:	78 7f                	js     79f0 <fwp_drop10+0x140>
    7971:	48 39 c8             	cmp    %rcx,%rax
    7974:	73 cb                	jae    7941 <fwp_drop10+0x91>
    7976:	48 89 c1             	mov    %rax,%rcx
    7979:	48 c1 e9 10          	shr    $0x10,%rcx
    797d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7981:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7985:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7989:	48 85 f6             	test   %rsi,%rsi
    798c:	74 b3                	je     7941 <fwp_drop10+0x91>
    798e:	0f b6 39             	movzbl (%rcx),%edi
    7991:	40 80 ff 02          	cmp    $0x2,%dil
    7995:	74 39                	je     79d0 <fwp_drop10+0x120>
    7997:	40 80 ff 01          	cmp    $0x1,%dil
    799b:	75 a4                	jne    7941 <fwp_drop10+0x91>
    799d:	8b 79 18             	mov    0x18(%rcx),%edi
    79a0:	0f b7 c0             	movzwl %ax,%eax
    79a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    79a6:	48 0f af c7          	imul   %rdi,%rax
    79aa:	48 c1 e8 20          	shr    $0x20,%rax
    79ae:	48 39 c8             	cmp    %rcx,%rax
    79b1:	73 8e                	jae    7941 <fwp_drop10+0x91>
    79b3:	48 01 c6             	add    %rax,%rsi
    79b6:	80 3e 01             	cmpb   $0x1,(%rsi)
    79b9:	75 86                	jne    7941 <fwp_drop10+0x91>
    79bb:	48 89 d7             	mov    %rdx,%rdi
    79be:	48 83 c4 18          	add    $0x18,%rsp
    79c2:	e9 89 db ff ff       	jmp    5550 <fwp_mem_free>
    79c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    79ce:	00 00 
    79d0:	66 85 c0             	test   %ax,%ax
    79d3:	74 e1                	je     79b6 <fwp_drop10+0x106>
    79d5:	48 83 c4 18          	add    $0x18,%rsp
    79d9:	c3                   	ret
    79da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79e0:	66 85 c0             	test   %ax,%ax
    79e3:	0f 84 40 ff ff ff    	je     7929 <fwp_drop10+0x79>
    79e9:	48 83 c4 18          	add    $0x18,%rsp
    79ed:	c3                   	ret
    79ee:	66 90                	xchg   %ax,%ax
    79f0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    79f4:	48 39 c8             	cmp    %rcx,%rax
    79f7:	73 74                	jae    7a6d <fwp_drop10+0x1bd>
    79f9:	49 89 c2             	mov    %rax,%r10
    79fc:	49 c1 ea 10          	shr    $0x10,%r10
    7a00:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7a04:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7a08:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7a0c:	4d 85 d2             	test   %r10,%r10
    7a0f:	74 5c                	je     7a6d <fwp_drop10+0x1bd>
    7a11:	45 0f b6 18          	movzbl (%r8),%r11d
    7a15:	41 80 fb 02          	cmp    $0x2,%r11b
    7a19:	74 6d                	je     7a88 <fwp_drop10+0x1d8>
    7a1b:	41 80 fb 01          	cmp    $0x1,%r11b
    7a1f:	75 4c                	jne    7a6d <fwp_drop10+0x1bd>
    7a21:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7a25:	0f b7 c0             	movzwl %ax,%eax
    7a28:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7a2c:	49 0f af c3          	imul   %r11,%rax
    7a30:	48 c1 e8 20          	shr    $0x20,%rax
    7a34:	4c 39 c0             	cmp    %r8,%rax
    7a37:	73 34                	jae    7a6d <fwp_drop10+0x1bd>
    7a39:	49 01 c2             	add    %rax,%r10
    7a3c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7a40:	75 2b                	jne    7a6d <fwp_drop10+0x1bd>
    7a42:	4c 89 cf             	mov    %r9,%rdi
    7a45:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a4a:	e8 01 db ff ff       	call   5550 <fwp_mem_free>
    7a4f:	48 8d 35 0a ad 01 00 	lea    0x1ad0a(%rip),%rsi        # 22760 <fwp_heap>
    7a56:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a5b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7a62:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7a69:	48 c1 e1 10          	shl    $0x10,%rcx
    7a6d:	48 89 d0             	mov    %rdx,%rax
    7a70:	48 29 f8             	sub    %rdi,%rax
    7a73:	48 39 c8             	cmp    %rcx,%rax
    7a76:	0f 82 60 fe ff ff    	jb     78dc <fwp_drop10+0x2c>
    7a7c:	e9 c0 fe ff ff       	jmp    7941 <fwp_drop10+0x91>
    7a81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a88:	66 85 c0             	test   %ax,%ax
    7a8b:	75 e0                	jne    7a6d <fwp_drop10+0x1bd>
    7a8d:	eb ad                	jmp    7a3c <fwp_drop10+0x18c>
    7a8f:	90                   	nop
    7a90:	c3                   	ret
    7a91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a98:	48 89 c8             	mov    %rcx,%rax
    7a9b:	48 c1 e8 11          	shr    $0x11,%rax
    7a9f:	48 31 c8             	xor    %rcx,%rax
    7aa2:	48 89 c2             	mov    %rax,%rdx
    7aa5:	48 c1 ea 09          	shr    $0x9,%rdx
    7aa9:	48 31 d0             	xor    %rdx,%rax
    7aac:	0f b6 d0             	movzbl %al,%edx
    7aaf:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7ab6:	00 
    7ab7:	48 85 c0             	test   %rax,%rax
    7aba:	75 0d                	jne    7ac9 <fwp_drop10+0x219>
    7abc:	eb 46                	jmp    7b04 <fwp_drop10+0x254>
    7abe:	66 90                	xchg   %ax,%ax
    7ac0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7ac4:	48 85 c0             	test   %rax,%rax
    7ac7:	74 3b                	je     7b04 <fwp_drop10+0x254>
    7ac9:	48 89 c2             	mov    %rax,%rdx
    7acc:	48 39 08             	cmp    %rcx,(%rax)
    7acf:	75 ef                	jne    7ac0 <fwp_drop10+0x210>
    7ad1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ad5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7ad9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7add:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7ae4:	0f 85 57 fe ff ff    	jne    7941 <fwp_drop10+0x91>
    7aea:	48 89 cf             	mov    %rcx,%rdi
    7aed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7af2:	e8 19 d8 ff ff       	call   5310 <fwp_rc_forget_slot>
    7af7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7afc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7aff:	e9 3d fe ff ff       	jmp    7941 <fwp_drop10+0x91>
    7b04:	48 8d 3d 95 6c 00 00 	lea    0x6c95(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    7b0b:	e8 90 c6 ff ff       	call   41a0 <fwp_trap>

0000000000007b10 <f37>:
    7b10:	41 57                	push   %r15
    7b12:	41 56                	push   %r14
    7b14:	41 55                	push   %r13
    7b16:	41 54                	push   %r12
    7b18:	55                   	push   %rbp
    7b19:	53                   	push   %rbx
    7b1a:	48 83 ec 38          	sub    $0x38,%rsp
    7b1e:	48 8b 15 13 c0 01 00 	mov    0x1c013(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7b25:	48 8b 0d e4 bf 01 00 	mov    0x1bfe4(%rip),%rcx        # 23b10 <fwp_heap+0x13b0>
    7b2c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7b33:	00 00 
    7b35:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7b3a:	49 89 fc             	mov    %rdi,%r12
    7b3d:	48 c1 e2 10          	shl    $0x10,%rdx
    7b41:	48 85 ff             	test   %rdi,%rdi
    7b44:	0f 84 bc 02 00 00    	je     7e06 <f37+0x2f6>
    7b4a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7b4f:	48 89 d8             	mov    %rbx,%rax
    7b52:	48 29 c8             	sub    %rcx,%rax
    7b55:	48 39 d0             	cmp    %rdx,%rax
    7b58:	0f 83 72 03 00 00    	jae    7ed0 <f37+0x3c0>
    7b5e:	48 89 c2             	mov    %rax,%rdx
    7b61:	48 c1 ea 10          	shr    $0x10,%rdx
    7b65:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b69:	48 8b 15 e8 bf 01 00 	mov    0x1bfe8(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    7b70:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b74:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7b78:	48 85 ff             	test   %rdi,%rdi
    7b7b:	0f 84 4f 03 00 00    	je     7ed0 <f37+0x3c0>
    7b81:	0f b6 0a             	movzbl (%rdx),%ecx
    7b84:	80 f9 02             	cmp    $0x2,%cl
    7b87:	0f 84 53 02 00 00    	je     7de0 <f37+0x2d0>
    7b8d:	80 f9 01             	cmp    $0x1,%cl
    7b90:	75 24                	jne    7bb6 <f37+0xa6>
    7b92:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b95:	0f b7 c0             	movzwl %ax,%eax
    7b98:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b9b:	48 0f af c1          	imul   %rcx,%rax
    7b9f:	48 c1 e8 20          	shr    $0x20,%rax
    7ba3:	48 39 d0             	cmp    %rdx,%rax
    7ba6:	73 0e                	jae    7bb6 <f37+0xa6>
    7ba8:	48 01 c7             	add    %rax,%rdi
    7bab:	0f b6 07             	movzbl (%rdi),%eax
    7bae:	84 c0                	test   %al,%al
    7bb0:	0f 85 ca 02 00 00    	jne    7e80 <f37+0x370>
    7bb6:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7bbb:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7bc0:	ba 01 00 00 00       	mov    $0x1,%edx
    7bc5:	48 85 db             	test   %rbx,%rbx
    7bc8:	74 13                	je     7bdd <f37+0xcd>
    7bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bd0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7bd4:	48 83 c2 01          	add    $0x1,%rdx
    7bd8:	48 85 db             	test   %rbx,%rbx
    7bdb:	75 f3                	jne    7bd0 <f37+0xc0>
    7bdd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7be2:	48 85 c0             	test   %rax,%rax
    7be5:	0f 84 15 03 00 00    	je     7f00 <f37+0x3f0>
    7beb:	31 db                	xor    %ebx,%ebx
    7bed:	0f 1f 00             	nopl   (%rax)
    7bf0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7bf4:	48 83 c3 01          	add    $0x1,%rbx
    7bf8:	48 85 c0             	test   %rax,%rax
    7bfb:	75 f3                	jne    7bf0 <f37+0xe0>
    7bfd:	48 39 d3             	cmp    %rdx,%rbx
    7c00:	48 0f 47 da          	cmova  %rdx,%rbx
    7c04:	48 89 d8             	mov    %rbx,%rax
    7c07:	48 c1 e8 3c          	shr    $0x3c,%rax
    7c0b:	0f 85 8f 03 00 00    	jne    7fa0 <f37+0x490>
    7c11:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7c15:	be 02 00 00 00       	mov    $0x2,%esi
    7c1a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7c21:	00 
    7c22:	e8 29 de ff ff       	call   5a50 <fwp_heap_alloc>
    7c27:	48 89 28             	mov    %rbp,(%rax)
    7c2a:	48 8b 15 07 bf 01 00 	mov    0x1bf07(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7c31:	49 89 c6             	mov    %rax,%r14
    7c34:	48 2b 05 d5 be 01 00 	sub    0x1bed5(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7c3b:	48 c1 e2 10          	shl    $0x10,%rdx
    7c3f:	48 39 d0             	cmp    %rdx,%rax
    7c42:	73 57                	jae    7c9b <f37+0x18b>
    7c44:	48 89 c2             	mov    %rax,%rdx
    7c47:	48 c1 ea 10          	shr    $0x10,%rdx
    7c4b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c4f:	48 8b 15 02 bf 01 00 	mov    0x1bf02(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    7c56:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c5a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7c5e:	48 85 ed             	test   %rbp,%rbp
    7c61:	74 38                	je     7c9b <f37+0x18b>
    7c63:	0f b6 0a             	movzbl (%rdx),%ecx
    7c66:	80 f9 02             	cmp    $0x2,%cl
    7c69:	0f 84 51 02 00 00    	je     7ec0 <f37+0x3b0>
    7c6f:	80 f9 01             	cmp    $0x1,%cl
    7c72:	75 27                	jne    7c9b <f37+0x18b>
    7c74:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c77:	0f b7 c0             	movzwl %ax,%eax
    7c7a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c7d:	48 0f af c1          	imul   %rcx,%rax
    7c81:	48 c1 e8 20          	shr    $0x20,%rax
    7c85:	48 39 d0             	cmp    %rdx,%rax
    7c88:	73 11                	jae    7c9b <f37+0x18b>
    7c8a:	48 01 c5             	add    %rax,%rbp
    7c8d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7c91:	0f 84 d5 02 00 00    	je     7f6c <f37+0x45c>
    7c97:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7c9b:	48 85 db             	test   %rbx,%rbx
    7c9e:	74 5d                	je     7cfd <f37+0x1ed>
    7ca0:	48 c1 e3 04          	shl    $0x4,%rbx
    7ca4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7ca9:	4c 89 f5             	mov    %r14,%rbp
    7cac:	4d 89 e5             	mov    %r12,%r13
    7caf:	4c 01 f3             	add    %r14,%rbx
    7cb2:	0f 1f 00             	nopl   (%rax)
    7cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7cbc:	00 00 00 00 
    7cc0:	49 8b 45 08          	mov    0x8(%r13),%rax
    7cc4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7cc8:	48 83 c5 10          	add    $0x10,%rbp
    7ccc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7cd1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7cd5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7cd9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7cde:	e8 3d e3 ff ff       	call   6020 <w120>
    7ce3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7ce8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7cec:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7cf0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7cf4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7cf8:	48 39 dd             	cmp    %rbx,%rbp
    7cfb:	75 c3                	jne    7cc0 <f37+0x1b0>
    7cfd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7d02:	e8 c9 ed ff ff       	call   6ad0 <fwp_drop4>
    7d07:	4c 89 e7             	mov    %r12,%rdi
    7d0a:	e8 c1 ed ff ff       	call   6ad0 <fwp_drop4>
    7d0f:	4c 89 f7             	mov    %r14,%rdi
    7d12:	e8 79 e4 ff ff       	call   6190 <w176.constprop.0>
    7d17:	4c 89 f7             	mov    %r14,%rdi
    7d1a:	48 89 c3             	mov    %rax,%rbx
    7d1d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7d23:	e8 88 fb ff ff       	call   78b0 <fwp_drop10>
    7d28:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7d2e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7d33:	31 ff                	xor    %edi,%edi
    7d35:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7d3a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7d3e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7d43:	e8 28 de ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    7d48:	48 8b 15 e9 bd 01 00 	mov    0x1bde9(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7d4f:	48 89 c5             	mov    %rax,%rbp
    7d52:	48 2b 05 b7 bd 01 00 	sub    0x1bdb7(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7d59:	48 c1 e2 10          	shl    $0x10,%rdx
    7d5d:	48 39 d0             	cmp    %rdx,%rax
    7d60:	73 55                	jae    7db7 <f37+0x2a7>
    7d62:	48 89 c2             	mov    %rax,%rdx
    7d65:	48 c1 ea 10          	shr    $0x10,%rdx
    7d69:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d6d:	48 8b 15 e4 bd 01 00 	mov    0x1bde4(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    7d74:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d78:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7d7c:	48 85 db             	test   %rbx,%rbx
    7d7f:	74 36                	je     7db7 <f37+0x2a7>
    7d81:	0f b6 0a             	movzbl (%rdx),%ecx
    7d84:	80 f9 02             	cmp    $0x2,%cl
    7d87:	0f 84 1b 01 00 00    	je     7ea8 <f37+0x398>
    7d8d:	80 f9 01             	cmp    $0x1,%cl
    7d90:	75 25                	jne    7db7 <f37+0x2a7>
    7d92:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d95:	0f b7 c0             	movzwl %ax,%eax
    7d98:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d9b:	48 0f af c1          	imul   %rcx,%rax
    7d9f:	48 c1 e8 20          	shr    $0x20,%rax
    7da3:	48 39 d0             	cmp    %rdx,%rax
    7da6:	73 0f                	jae    7db7 <f37+0x2a7>
    7da8:	48 01 c3             	add    %rax,%rbx
    7dab:	80 3b ff             	cmpb   $0xff,(%rbx)
    7dae:	0f 84 ab 01 00 00    	je     7f5f <f37+0x44f>
    7db4:	c6 03 01             	movb   $0x1,(%rbx)
    7db7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7dbc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7dc3:	00 00 
    7dc5:	0f 85 d0 01 00 00    	jne    7f9b <f37+0x48b>
    7dcb:	48 83 c4 38          	add    $0x38,%rsp
    7dcf:	48 89 e8             	mov    %rbp,%rax
    7dd2:	5b                   	pop    %rbx
    7dd3:	5d                   	pop    %rbp
    7dd4:	41 5c                	pop    %r12
    7dd6:	41 5d                	pop    %r13
    7dd8:	41 5e                	pop    %r14
    7dda:	41 5f                	pop    %r15
    7ddc:	c3                   	ret
    7ddd:	0f 1f 00             	nopl   (%rax)
    7de0:	66 85 c0             	test   %ax,%ax
    7de3:	0f 85 cd fd ff ff    	jne    7bb6 <f37+0xa6>
    7de9:	0f b6 07             	movzbl (%rdi),%eax
    7dec:	84 c0                	test   %al,%al
    7dee:	0f 84 c2 fd ff ff    	je     7bb6 <f37+0xa6>
    7df4:	3c fd                	cmp    $0xfd,%al
    7df6:	0f 87 95 01 00 00    	ja     7f91 <f37+0x481>
    7dfc:	83 c0 01             	add    $0x1,%eax
    7dff:	88 07                	mov    %al,(%rdi)
    7e01:	e9 b0 fd ff ff       	jmp    7bb6 <f37+0xa6>
    7e06:	48 f7 d9             	neg    %rcx
    7e09:	48 39 d1             	cmp    %rdx,%rcx
    7e0c:	0f 83 ee 00 00 00    	jae    7f00 <f37+0x3f0>
    7e12:	48 89 c8             	mov    %rcx,%rax
    7e15:	48 c1 e8 10          	shr    $0x10,%rax
    7e19:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7e1d:	48 8b 05 34 bd 01 00 	mov    0x1bd34(%rip),%rax        # 23b58 <fwp_heap+0x13f8>
    7e24:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7e28:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7e2c:	48 85 ff             	test   %rdi,%rdi
    7e2f:	0f 84 cb 00 00 00    	je     7f00 <f37+0x3f0>
    7e35:	0f b6 02             	movzbl (%rdx),%eax
    7e38:	3c 02                	cmp    $0x2,%al
    7e3a:	0f 84 9a 00 00 00    	je     7eda <f37+0x3ca>
    7e40:	3c 01                	cmp    $0x1,%al
    7e42:	0f 85 b8 00 00 00    	jne    7f00 <f37+0x3f0>
    7e48:	0f b7 c1             	movzwl %cx,%eax
    7e4b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e51:	48 0f af c1          	imul   %rcx,%rax
    7e55:	48 c1 e8 20          	shr    $0x20,%rax
    7e59:	48 39 d0             	cmp    %rdx,%rax
    7e5c:	0f 83 9e 00 00 00    	jae    7f00 <f37+0x3f0>
    7e62:	48 01 c7             	add    %rax,%rdi
    7e65:	0f b6 07             	movzbl (%rdi),%eax
    7e68:	84 c0                	test   %al,%al
    7e6a:	0f 84 90 00 00 00    	je     7f00 <f37+0x3f0>
    7e70:	31 db                	xor    %ebx,%ebx
    7e72:	0f 1f 00             	nopl   (%rax)
    7e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e7c:	00 00 00 00 
    7e80:	3c fd                	cmp    $0xfd,%al
    7e82:	0f 87 f1 00 00 00    	ja     7f79 <f37+0x469>
    7e88:	83 c0 01             	add    $0x1,%eax
    7e8b:	88 07                	mov    %al,(%rdi)
    7e8d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7e92:	31 d2                	xor    %edx,%edx
    7e94:	4d 85 e4             	test   %r12,%r12
    7e97:	0f 85 1e fd ff ff    	jne    7bbb <f37+0xab>
    7e9d:	e9 3b fd ff ff       	jmp    7bdd <f37+0xcd>
    7ea2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ea8:	66 85 c0             	test   %ax,%ax
    7eab:	0f 85 06 ff ff ff    	jne    7db7 <f37+0x2a7>
    7eb1:	e9 f5 fe ff ff       	jmp    7dab <f37+0x29b>
    7eb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7ebd:	00 00 00 
    7ec0:	66 85 c0             	test   %ax,%ax
    7ec3:	0f 85 d2 fd ff ff    	jne    7c9b <f37+0x18b>
    7ec9:	e9 bf fd ff ff       	jmp    7c8d <f37+0x17d>
    7ece:	66 90                	xchg   %ax,%ax
    7ed0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7ed5:	e9 e6 fc ff ff       	jmp    7bc0 <f37+0xb0>
    7eda:	66 85 c9             	test   %cx,%cx
    7edd:	75 21                	jne    7f00 <f37+0x3f0>
    7edf:	0f b6 07             	movzbl (%rdi),%eax
    7ee2:	84 c0                	test   %al,%al
    7ee4:	74 1a                	je     7f00 <f37+0x3f0>
    7ee6:	3c fd                	cmp    $0xfd,%al
    7ee8:	0f 87 be 00 00 00    	ja     7fac <f37+0x49c>
    7eee:	83 c0 01             	add    $0x1,%eax
    7ef1:	88 07                	mov    %al,(%rdi)
    7ef3:	66 90                	xchg   %ax,%ax
    7ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7efc:	00 00 00 00 
    7f00:	be 02 00 00 00       	mov    $0x2,%esi
    7f05:	bf 08 00 00 00       	mov    $0x8,%edi
    7f0a:	e8 41 db ff ff       	call   5a50 <fwp_heap_alloc>
    7f0f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7f16:	48 8b 15 1b bc 01 00 	mov    0x1bc1b(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    7f1d:	49 89 c6             	mov    %rax,%r14
    7f20:	48 2b 05 e9 bb 01 00 	sub    0x1bbe9(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    7f27:	48 c1 e2 10          	shl    $0x10,%rdx
    7f2b:	48 39 d0             	cmp    %rdx,%rax
    7f2e:	73 53                	jae    7f83 <f37+0x473>
    7f30:	48 89 c2             	mov    %rax,%rdx
    7f33:	48 c1 ea 10          	shr    $0x10,%rdx
    7f37:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f3b:	48 8b 15 16 bc 01 00 	mov    0x1bc16(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    7f42:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f46:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7f4a:	48 85 ed             	test   %rbp,%rbp
    7f4d:	74 34                	je     7f83 <f37+0x473>
    7f4f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7f56:	00 00 
    7f58:	31 db                	xor    %ebx,%ebx
    7f5a:	e9 04 fd ff ff       	jmp    7c63 <f37+0x153>
    7f5f:	48 89 df             	mov    %rbx,%rdi
    7f62:	e8 a9 d3 ff ff       	call   5310 <fwp_rc_forget_slot>
    7f67:	e9 48 fe ff ff       	jmp    7db4 <f37+0x2a4>
    7f6c:	48 89 ef             	mov    %rbp,%rdi
    7f6f:	e8 9c d3 ff ff       	call   5310 <fwp_rc_forget_slot>
    7f74:	e9 1e fd ff ff       	jmp    7c97 <f37+0x187>
    7f79:	e8 72 d2 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7f7e:	e9 0a ff ff ff       	jmp    7e8d <f37+0x37d>
    7f83:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7f8a:	00 00 
    7f8c:	e9 6c fd ff ff       	jmp    7cfd <f37+0x1ed>
    7f91:	e8 5a d2 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7f96:	e9 1b fc ff ff       	jmp    7bb6 <f37+0xa6>
    7f9b:	e8 c0 b4 ff ff       	call   3460 <__stack_chk_fail@plt>
    7fa0:	48 8d 3d 86 61 00 00 	lea    0x6186(%rip),%rdi        # e12d <_IO_stdin_used+0x12d>
    7fa7:	e8 f4 c1 ff ff       	call   41a0 <fwp_trap>
    7fac:	e8 3f d2 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7fb1:	e9 4a ff ff ff       	jmp    7f00 <f37+0x3f0>
    7fb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7fbd:	00 00 00 

0000000000007fc0 <fwp_owned_entry37>:
    7fc0:	f3 0f 1e fa          	endbr64
    7fc4:	48 8b 3f             	mov    (%rdi),%rdi
    7fc7:	e9 44 fb ff ff       	jmp    7b10 <f37>
    7fcc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007fd0 <e37>:
    7fd0:	f3 0f 1e fa          	endbr64
    7fd4:	53                   	push   %rbx
    7fd5:	48 8b 1f             	mov    (%rdi),%rbx
    7fd8:	48 89 df             	mov    %rbx,%rdi
    7fdb:	e8 30 e2 ff ff       	call   6210 <fwp_rc_share>
    7fe0:	48 89 df             	mov    %rbx,%rdi
    7fe3:	e8 28 fb ff ff       	call   7b10 <f37>
    7fe8:	48 89 c3             	mov    %rax,%rbx
    7feb:	48 89 c7             	mov    %rax,%rdi
    7fee:	e8 1d e2 ff ff       	call   6210 <fwp_rc_share>
    7ff3:	48 89 d8             	mov    %rbx,%rax
    7ff6:	5b                   	pop    %rbx
    7ff7:	c3                   	ret
    7ff8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7fff:	00 

0000000000008000 <fwp_write>:
    8000:	41 57                	push   %r15
    8002:	41 56                	push   %r14
    8004:	41 55                	push   %r13
    8006:	41 54                	push   %r12
    8008:	55                   	push   %rbp
    8009:	53                   	push   %rbx
    800a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8011:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8018:	00 00 
    801a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8021:	00 
    8022:	49 89 d4             	mov    %rdx,%r12
    8025:	8b 12                	mov    (%rdx),%edx
    8027:	83 fa 19             	cmp    $0x19,%edx
    802a:	77 6a                	ja     8096 <fwp_write+0x96>
    802c:	48 89 f5             	mov    %rsi,%rbp
    802f:	89 d0                	mov    %edx,%eax
    8031:	89 ce                	mov    %ecx,%esi
    8033:	48 89 fb             	mov    %rdi,%rbx
    8036:	48 8d 0d d3 69 00 00 	lea    0x69d3(%rip),%rcx        # ea10 <_IO_stdin_used+0xa10>
    803d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8041:	48 01 c8             	add    %rcx,%rax
    8044:	3e ff e0             	notrack jmp *%rax
    8047:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    804e:	00 00 
    8050:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8054:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8058:	48 89 ca             	mov    %rcx,%rdx
    805b:	48 85 c9             	test   %rcx,%rcx
    805e:	0f 88 9c 0c 00 00    	js     8d00 <fwp_write+0xd00>
    8064:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    806b:	00 
    806c:	48 89 c6             	mov    %rax,%rsi
    806f:	4c 89 e7             	mov    %r12,%rdi
    8072:	e8 c9 b9 ff ff       	call   3a40 <fwp_fmt_u128>
    8077:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    807e:	00 00 
    8080:	4c 89 e7             	mov    %r12,%rdi
    8083:	e8 c8 b3 ff ff       	call   3450 <strlen@plt>
    8088:	4c 89 e6             	mov    %r12,%rsi
    808b:	48 89 df             	mov    %rbx,%rdi
    808e:	48 89 c2             	mov    %rax,%rdx
    8091:	e8 da bf ff ff       	call   4070 <buf_put>
    8096:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    809d:	00 
    809e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    80a5:	00 00 
    80a7:	0f 85 28 04 00 00    	jne    84d5 <fwp_write+0x4d5>
    80ad:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    80b4:	5b                   	pop    %rbx
    80b5:	5d                   	pop    %rbp
    80b6:	41 5c                	pop    %r12
    80b8:	41 5d                	pop    %r13
    80ba:	41 5e                	pop    %r14
    80bc:	41 5f                	pop    %r15
    80be:	c3                   	ret
    80bf:	90                   	nop
    80c0:	49 89 e9             	mov    %rbp,%r9
    80c3:	4c 8d 05 8d 60 00 00 	lea    0x608d(%rip),%r8        # e157 <_IO_stdin_used+0x157>
    80ca:	b9 00 02 00 00       	mov    $0x200,%ecx
    80cf:	ba 02 00 00 00       	mov    $0x2,%edx
    80d4:	be 00 02 00 00       	mov    $0x200,%esi
    80d9:	31 c0                	xor    %eax,%eax
    80db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    80e2:	00 
    80e3:	e8 c8 b2 ff ff       	call   33b0 <__snprintf_chk@plt>
    80e8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    80ef:	00 
    80f0:	e8 5b b3 ff ff       	call   3450 <strlen@plt>
    80f5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    80fc:	00 
    80fd:	48 89 df             	mov    %rbx,%rdi
    8100:	48 89 c2             	mov    %rax,%rdx
    8103:	e8 68 bf ff ff       	call   4070 <buf_put>
    8108:	eb 8c                	jmp    8096 <fwp_write+0x96>
    810a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8110:	49 89 e9             	mov    %rbp,%r9
    8113:	4c 8d 05 38 60 00 00 	lea    0x6038(%rip),%r8        # e152 <_IO_stdin_used+0x152>
    811a:	eb ae                	jmp    80ca <fwp_write+0xca>
    811c:	0f 1f 40 00          	nopl   0x0(%rax)
    8120:	83 fa 13             	cmp    $0x13,%edx
    8123:	48 8d 05 1e 60 00 00 	lea    0x601e(%rip),%rax        # e148 <_IO_stdin_used+0x148>
    812a:	48 8d 35 1c 60 00 00 	lea    0x601c(%rip),%rsi        # e14d <_IO_stdin_used+0x14d>
    8131:	ba 04 00 00 00       	mov    $0x4,%edx
    8136:	48 0f 44 f0          	cmove  %rax,%rsi
    813a:	45 31 ed             	xor    %r13d,%r13d
    813d:	e8 2e bf ff ff       	call   4070 <buf_put>
    8142:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8147:	0f 84 a3 08 00 00    	je     89f0 <fwp_write+0x9f0>
    814d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8152:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8157:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    815c:	48 89 df             	mov    %rbx,%rdi
    815f:	49 0f 44 c5          	cmove  %r13,%rax
    8163:	31 c9                	xor    %ecx,%ecx
    8165:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    816a:	e8 91 fe ff ff       	call   8000 <fwp_write>
    816f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8174:	0f 84 6e 09 00 00    	je     8ae8 <fwp_write+0xae8>
    817a:	49 83 c5 01          	add    $0x1,%r13
    817e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8182:	0f 83 68 08 00 00    	jae    89f0 <fwp_write+0x9f0>
    8188:	ba 02 00 00 00       	mov    $0x2,%edx
    818d:	48 8d 35 03 60 00 00 	lea    0x6003(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8194:	48 89 df             	mov    %rbx,%rdi
    8197:	e8 d4 be ff ff       	call   4070 <buf_put>
    819c:	eb af                	jmp    814d <fwp_write+0x14d>
    819e:	66 90                	xchg   %ax,%ax
    81a0:	ba 06 00 00 00       	mov    $0x6,%edx
    81a5:	48 8d 35 c4 5f 00 00 	lea    0x5fc4(%rip),%rsi        # e170 <_IO_stdin_used+0x170>
    81ac:	48 83 c5 10          	add    $0x10,%rbp
    81b0:	e8 bb be ff ff       	call   4070 <buf_put>
    81b5:	48 89 ef             	mov    %rbp,%rdi
    81b8:	e8 93 b2 ff ff       	call   3450 <strlen@plt>
    81bd:	48 89 ee             	mov    %rbp,%rsi
    81c0:	48 89 df             	mov    %rbx,%rdi
    81c3:	48 89 c2             	mov    %rax,%rdx
    81c6:	e8 a5 be ff ff       	call   4070 <buf_put>
    81cb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    81d0:	ba 01 00 00 00       	mov    $0x1,%edx
    81d5:	48 89 df             	mov    %rbx,%rdi
    81d8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    81dd:	e8 8e be ff ff       	call   4070 <buf_put>
    81e2:	e9 af fe ff ff       	jmp    8096 <fwp_write+0x96>
    81e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81ee:	00 00 
    81f0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    81f7:	00 
    81f8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    81ff:	00 00 
    8201:	0f 85 ce 02 00 00    	jne    84d5 <fwp_write+0x4d5>
    8207:	ba 0a 00 00 00       	mov    $0xa,%edx
    820c:	48 8d 35 49 5f 00 00 	lea    0x5f49(%rip),%rsi        # e15c <_IO_stdin_used+0x15c>
    8213:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    821a:	48 89 df             	mov    %rbx,%rdi
    821d:	5b                   	pop    %rbx
    821e:	5d                   	pop    %rbp
    821f:	41 5c                	pop    %r12
    8221:	41 5d                	pop    %r13
    8223:	41 5e                	pop    %r14
    8225:	41 5f                	pop    %r15
    8227:	e9 44 be ff ff       	jmp    4070 <buf_put>
    822c:	0f 1f 40 00          	nopl   0x0(%rax)
    8230:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8235:	4d 85 ed             	test   %r13,%r13
    8238:	0f 84 02 0c 00 00    	je     8e40 <fwp_write+0xe40>
    823e:	48 8d 35 5f 5f 00 00 	lea    0x5f5f(%rip),%rsi        # e1a4 <_IO_stdin_used+0x1a4>
    8245:	4c 89 ef             	mov    %r13,%rdi
    8248:	e8 e3 b2 ff ff       	call   3530 <strcmp@plt>
    824d:	41 89 c1             	mov    %eax,%r9d
    8250:	85 c0                	test   %eax,%eax
    8252:	0f 84 6c 0c 00 00    	je     8ec4 <fwp_write+0xec4>
    8258:	4c 89 ef             	mov    %r13,%rdi
    825b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8260:	e8 eb b1 ff ff       	call   3450 <strlen@plt>
    8265:	4c 89 ee             	mov    %r13,%rsi
    8268:	48 89 df             	mov    %rbx,%rdi
    826b:	48 89 c2             	mov    %rax,%rdx
    826e:	e8 fd bd ff ff       	call   4070 <buf_put>
    8273:	ba 01 00 00 00       	mov    $0x1,%edx
    8278:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    827d:	48 89 df             	mov    %rbx,%rdi
    8280:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8285:	e8 e6 bd ff ff       	call   4070 <buf_put>
    828a:	ba 01 00 00 00       	mov    $0x1,%edx
    828f:	4c 89 fe             	mov    %r15,%rsi
    8292:	48 89 df             	mov    %rbx,%rdi
    8295:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    829a:	e8 d1 bd ff ff       	call   4070 <buf_put>
    829f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    82a4:	45 31 f6             	xor    %r14d,%r14d
    82a7:	85 d2                	test   %edx,%edx
    82a9:	0f 8e 81 0a 00 00    	jle    8d30 <fwp_write+0xd30>
    82af:	45 31 ed             	xor    %r13d,%r13d
    82b2:	4d 85 ed             	test   %r13,%r13
    82b5:	0f 85 75 07 00 00    	jne    8a30 <fwp_write+0xa30>
    82bb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    82c2:	00 
    82c3:	45 85 f6             	test   %r14d,%r14d
    82c6:	0f 84 84 07 00 00    	je     8a50 <fwp_write+0xa50>
    82cc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    82d1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    82d6:	48 89 df             	mov    %rbx,%rdi
    82d9:	49 83 c5 01          	add    $0x1,%r13
    82dd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    82e1:	31 c9                	xor    %ecx,%ecx
    82e3:	e8 18 fd ff ff       	call   8000 <fwp_write>
    82e8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    82ed:	7f c3                	jg     82b2 <fwp_write+0x2b2>
    82ef:	45 85 f6             	test   %r14d,%r14d
    82f2:	0f 84 38 0a 00 00    	je     8d30 <fwp_write+0xd30>
    82f8:	b8 29 00 00 00       	mov    $0x29,%eax
    82fd:	ba 01 00 00 00       	mov    $0x1,%edx
    8302:	4c 89 fe             	mov    %r15,%rsi
    8305:	48 89 df             	mov    %rbx,%rdi
    8308:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    830c:	e8 5f bd ff ff       	call   4070 <buf_put>
    8311:	e9 80 fd ff ff       	jmp    8096 <fwp_write+0x96>
    8316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    831d:	00 00 00 
    8320:	ba 01 00 00 00       	mov    $0x1,%edx
    8325:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    832a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    832f:	e8 3c bd ff ff       	call   4070 <buf_put>
    8334:	48 85 ed             	test   %rbp,%rbp
    8337:	0f 84 93 06 00 00    	je     89d0 <fwp_write+0x9d0>
    833d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8341:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8346:	31 c9                	xor    %ecx,%ecx
    8348:	48 89 df             	mov    %rbx,%rdi
    834b:	e8 b0 fc ff ff       	call   8000 <fwp_write>
    8350:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8354:	48 85 ed             	test   %rbp,%rbp
    8357:	0f 84 73 06 00 00    	je     89d0 <fwp_write+0x9d0>
    835d:	ba 02 00 00 00       	mov    $0x2,%edx
    8362:	48 8d 35 2e 5e 00 00 	lea    0x5e2e(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8369:	48 89 df             	mov    %rbx,%rdi
    836c:	e8 ff bc ff ff       	call   4070 <buf_put>
    8371:	eb ca                	jmp    833d <fwp_write+0x33d>
    8373:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8378:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    837c:	85 f6                	test   %esi,%esi
    837e:	0f 84 fc 07 00 00    	je     8b80 <fwp_write+0xb80>
    8384:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    838b:	00 
    838c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8393:	00 00 
    8395:	0f 85 3a 01 00 00    	jne    84d5 <fwp_write+0x4d5>
    839b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    839f:	4c 89 ea             	mov    %r13,%rdx
    83a2:	e9 6c fe ff ff       	jmp    8213 <fwp_write+0x213>
    83a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    83ae:	00 00 
    83b0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    83b5:	ba 01 00 00 00       	mov    $0x1,%edx
    83ba:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    83bf:	48 89 ee             	mov    %rbp,%rsi
    83c2:	e8 a9 bc ff ff       	call   4070 <buf_put>
    83c7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    83cc:	4c 89 e7             	mov    %r12,%rdi
    83cf:	e8 7c b0 ff ff       	call   3450 <strlen@plt>
    83d4:	4c 89 e6             	mov    %r12,%rsi
    83d7:	48 89 df             	mov    %rbx,%rdi
    83da:	48 89 c2             	mov    %rax,%rdx
    83dd:	e8 8e bc ff ff       	call   4070 <buf_put>
    83e2:	ba 01 00 00 00       	mov    $0x1,%edx
    83e7:	48 89 ee             	mov    %rbp,%rsi
    83ea:	48 89 df             	mov    %rbx,%rdi
    83ed:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    83f2:	e8 79 bc ff ff       	call   4070 <buf_put>
    83f7:	e9 9a fc ff ff       	jmp    8096 <fwp_write+0x96>
    83fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8400:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8405:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8409:	0f 8a 8e 0b 00 00    	jp     8f9d <fwp_write+0xf9d>
    840f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8413:	66 0f 54 05 25 67 00 	andpd  0x6725(%rip),%xmm0        # eb40 <msg.4+0xc0>
    841a:	00 
    841b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8420:	66 0f 2e 05 90 66 00 	ucomisd 0x6690(%rip),%xmm0        # eab8 <msg.4+0x38>
    8427:	00 
    8428:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    842f:	00 
    8430:	0f 87 b2 09 00 00    	ja     8de8 <fwp_write+0xde8>
    8436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    843d:	00 00 00 
    8440:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8444:	89 ee                	mov    %ebp,%esi
    8446:	4c 89 e7             	mov    %r12,%rdi
    8449:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    844e:	e8 6d c0 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8453:	31 f6                	xor    %esi,%esi
    8455:	4c 89 e7             	mov    %r12,%rdi
    8458:	e8 b3 af ff ff       	call   3410 <strtod@plt>
    845d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8462:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8466:	7a 06                	jp     846e <fwp_write+0x46e>
    8468:	0f 84 e9 01 00 00    	je     8657 <fwp_write+0x657>
    846e:	83 c5 01             	add    $0x1,%ebp
    8471:	83 fd 12             	cmp    $0x12,%ebp
    8474:	75 ca                	jne    8440 <fwp_write+0x440>
    8476:	be 11 00 00 00       	mov    $0x11,%esi
    847b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    847f:	4c 89 e7             	mov    %r12,%rdi
    8482:	e8 39 c0 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8487:	e9 cb 01 00 00       	jmp    8657 <fwp_write+0x657>
    848c:	0f 1f 40 00          	nopl   0x0(%rax)
    8490:	48 83 fd 01          	cmp    $0x1,%rbp
    8494:	0f 84 e6 08 00 00    	je     8d80 <fwp_write+0xd80>
    849a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    849e:	b8 02 00 00 00       	mov    $0x2,%eax
    84a3:	ba 01 00 00 00       	mov    $0x1,%edx
    84a8:	48 0f 44 d0          	cmove  %rax,%rdx
    84ac:	48 8d 35 8d 5c 00 00 	lea    0x5c8d(%rip),%rsi        # e140 <_IO_stdin_used+0x140>
    84b3:	48 8d 05 8b 5c 00 00 	lea    0x5c8b(%rip),%rax        # e145 <_IO_stdin_used+0x145>
    84ba:	48 0f 44 f0          	cmove  %rax,%rsi
    84be:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    84c5:	00 
    84c6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    84cd:	00 00 
    84cf:	0f 84 3e fd ff ff    	je     8213 <fwp_write+0x213>
    84d5:	e8 86 af ff ff       	call   3460 <__stack_chk_fail@plt>
    84da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    84e0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    84e5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    84ea:	e8 c1 ba ff ff       	call   3fb0 <buf_grow>
    84ef:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    84f3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    84f9:	4c 03 0b             	add    (%rbx),%r9
    84fc:	66 45 89 11          	mov    %r10w,(%r9)
    8500:	45 85 e4             	test   %r12d,%r12d
    8503:	0f 8e 07 05 00 00    	jle    8a10 <fwp_write+0xa10>
    8509:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8510:	55 55 55 
    8513:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8518:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    851f:	aa aa aa 
    8522:	49 83 c1 01          	add    $0x1,%r9
    8526:	eb 45                	jmp    856d <fwp_write+0x56d>
    8528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    852f:	00 
    8530:	be 01 00 00 00       	mov    $0x1,%esi
    8535:	b8 2d 00 00 00       	mov    $0x2d,%eax
    853a:	88 07                	mov    %al,(%rdi)
    853c:	48 89 e8             	mov    %rbp,%rax
    853f:	49 f7 e8             	imul   %r8
    8542:	48 89 e8             	mov    %rbp,%rax
    8545:	48 c1 f8 3f          	sar    $0x3f,%rax
    8549:	48 29 c2             	sub    %rax,%rdx
    854c:	48 85 c9             	test   %rcx,%rcx
    854f:	0f 95 c0             	setne  %al
    8552:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8556:	48 83 ef 01          	sub    $0x1,%rdi
    855a:	48 21 c5             	and    %rax,%rbp
    855d:	48 29 ea             	sub    %rbp,%rdx
    8560:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8564:	49 39 f9             	cmp    %rdi,%r9
    8567:	0f 84 a3 04 00 00    	je     8a10 <fwp_write+0xa10>
    856d:	48 89 e8             	mov    %rbp,%rax
    8570:	49 f7 e8             	imul   %r8
    8573:	48 89 e8             	mov    %rbp,%rax
    8576:	48 c1 f8 3f          	sar    $0x3f,%rax
    857a:	48 89 d1             	mov    %rdx,%rcx
    857d:	48 29 c1             	sub    %rax,%rcx
    8580:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8584:	48 89 e9             	mov    %rbp,%rcx
    8587:	48 29 c1             	sub    %rax,%rcx
    858a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    858e:	49 f7 e2             	mul    %r10
    8591:	b8 30 00 00 00       	mov    $0x30,%eax
    8596:	48 89 d6             	mov    %rdx,%rsi
    8599:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    859d:	48 d1 ee             	shr    $1,%rsi
    85a0:	48 01 f2             	add    %rsi,%rdx
    85a3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    85a7:	48 29 d6             	sub    %rdx,%rsi
    85aa:	74 8e                	je     853a <fwp_write+0x53a>
    85ac:	48 83 fe 01          	cmp    $0x1,%rsi
    85b0:	0f 85 7a ff ff ff    	jne    8530 <fwp_write+0x530>
    85b6:	31 f6                	xor    %esi,%esi
    85b8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    85bd:	e9 78 ff ff ff       	jmp    853a <fwp_write+0x53a>
    85c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    85c8:	66 0f 6e cd          	movd   %ebp,%xmm1
    85cc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    85cf:	0f 8a c8 09 00 00    	jp     8f9d <fwp_write+0xf9d>
    85d5:	0f 28 c1             	movaps %xmm1,%xmm0
    85d8:	0f 54 05 51 65 00 00 	andps  0x6551(%rip),%xmm0        # eb30 <msg.4+0xb0>
    85df:	0f 2e 05 1e 5a 00 00 	ucomiss 0x5a1e(%rip),%xmm0        # e004 <_IO_stdin_used+0x4>
    85e6:	0f 87 24 08 00 00    	ja     8e10 <fwp_write+0xe10>
    85ec:	66 0f ef d2          	pxor   %xmm2,%xmm2
    85f0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    85f6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    85fd:	00 
    85fe:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8602:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8607:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    860e:	00 00 
    8610:	44 89 ee             	mov    %r13d,%esi
    8613:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8618:	4c 89 e7             	mov    %r12,%rdi
    861b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8620:	e8 9b be ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8625:	31 f6                	xor    %esi,%esi
    8627:	4c 89 e7             	mov    %r12,%rdi
    862a:	e8 81 ae ff ff       	call   34b0 <strtof@plt>
    862f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8634:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8637:	7a 02                	jp     863b <fwp_write+0x63b>
    8639:	74 1c                	je     8657 <fwp_write+0x657>
    863b:	41 83 c5 01          	add    $0x1,%r13d
    863f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8643:	75 cb                	jne    8610 <fwp_write+0x610>
    8645:	be 09 00 00 00       	mov    $0x9,%esi
    864a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    864f:	4c 89 e7             	mov    %r12,%rdi
    8652:	e8 69 be ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8657:	4c 89 e7             	mov    %r12,%rdi
    865a:	e8 d1 ba ff ff       	call   4130 <fwp_finish_float>
    865f:	e9 1c fa ff ff       	jmp    8080 <fwp_write+0x80>
    8664:	0f 1f 40 00          	nopl   0x0(%rax)
    8668:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    866c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8670:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8677:	00 
    8678:	48 89 ef             	mov    %rbp,%rdi
    867b:	e8 c0 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    8680:	48 89 ef             	mov    %rbp,%rdi
    8683:	e8 c8 ad ff ff       	call   3450 <strlen@plt>
    8688:	48 89 ee             	mov    %rbp,%rsi
    868b:	48 89 df             	mov    %rbx,%rdi
    868e:	48 89 c2             	mov    %rax,%rdx
    8691:	e8 da b9 ff ff       	call   4070 <buf_put>
    8696:	e9 fb f9 ff ff       	jmp    8096 <fwp_write+0x96>
    869b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    86a0:	ba 06 00 00 00       	mov    $0x6,%edx
    86a5:	48 8d 35 ee 5a 00 00 	lea    0x5aee(%rip),%rsi        # e19a <_IO_stdin_used+0x19a>
    86ac:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    86b2:	e8 b9 b9 ff ff       	call   4070 <buf_put>
    86b7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    86be:	ff ff 7f 
    86c1:	48 23 55 00          	and    0x0(%rbp),%rdx
    86c5:	0f 84 86 02 00 00    	je     8951 <fwp_write+0x951>
    86cb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    86d0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    86d4:	48 85 d2             	test   %rdx,%rdx
    86d7:	0f 84 ae 00 00 00    	je     878b <fwp_write+0x78b>
    86dd:	8b 0a                	mov    (%rdx),%ecx
    86df:	83 f9 1c             	cmp    $0x1c,%ecx
    86e2:	0f 84 58 06 00 00    	je     8d40 <fwp_write+0xd40>
    86e8:	83 f9 1b             	cmp    $0x1b,%ecx
    86eb:	0f 87 9a 00 00 00    	ja     878b <fwp_write+0x78b>
    86f1:	be 01 00 00 00       	mov    $0x1,%esi
    86f6:	48 d3 e6             	shl    %cl,%rsi
    86f9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    86ff:	0f 85 4b 04 00 00    	jne    8b50 <fwp_write+0xb50>
    8705:	f7 c6 84 04 00 00    	test   $0x484,%esi
    870b:	0f 85 0f 04 00 00    	jne    8b20 <fwp_write+0xb20>
    8711:	83 e6 21             	and    $0x21,%esi
    8714:	74 75                	je     878b <fwp_write+0x78b>
    8716:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    871b:	48 85 ff             	test   %rdi,%rdi
    871e:	79 07                	jns    8727 <fwp_write+0x727>
    8720:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8724:	4c 01 ee             	add    %r13,%rsi
    8727:	48 0f be 3e          	movsbq (%rsi),%rdi
    872b:	85 c9                	test   %ecx,%ecx
    872d:	40 0f b6 f7          	movzbl %dil,%esi
    8731:	48 0f 44 f7          	cmove  %rdi,%rsi
    8735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    873c:	00 00 00 00 
    8740:	31 c9                	xor    %ecx,%ecx
    8742:	48 89 df             	mov    %rbx,%rdi
    8745:	49 83 c5 01          	add    $0x1,%r13
    8749:	e8 b2 f8 ff ff       	call   8000 <fwp_write>
    874e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8755:	ff ff 7f 
    8758:	48 23 55 00          	and    0x0(%rbp),%rdx
    875c:	49 39 d5             	cmp    %rdx,%r13
    875f:	0f 83 ec 01 00 00    	jae    8951 <fwp_write+0x951>
    8765:	ba 02 00 00 00       	mov    $0x2,%edx
    876a:	48 89 df             	mov    %rbx,%rdi
    876d:	48 8d 35 23 5a 00 00 	lea    0x5a23(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8774:	e8 f7 b8 ff ff       	call   4070 <buf_put>
    8779:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    877e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8782:	48 85 d2             	test   %rdx,%rdx
    8785:	0f 85 52 ff ff ff    	jne    86dd <fwp_write+0x6dd>
    878b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8790:	48 85 ff             	test   %rdi,%rdi
    8793:	0f 88 cf 05 00 00    	js     8d68 <fwp_write+0xd68>
    8799:	48 8b 31             	mov    (%rcx),%rsi
    879c:	eb a2                	jmp    8740 <fwp_write+0x740>
    879e:	66 90                	xchg   %ax,%ax
    87a0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    87a7:	00 
    87a8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87af:	00 00 
    87b1:	0f 85 1e fd ff ff    	jne    84d5 <fwp_write+0x4d5>
    87b7:	ba 08 00 00 00       	mov    $0x8,%edx
    87bc:	48 8d 35 a4 59 00 00 	lea    0x59a4(%rip),%rsi        # e167 <_IO_stdin_used+0x167>
    87c3:	e9 4b fa ff ff       	jmp    8213 <fwp_write+0x213>
    87c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    87cf:	00 
    87d0:	89 e8                	mov    %ebp,%eax
    87d2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    87d9:	76 03                	jbe    87de <fwp_write+0x7de>
    87db:	8b 45 00             	mov    0x0(%rbp),%eax
    87de:	41 89 c6             	mov    %eax,%r14d
    87e1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    87e6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    87eb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    87ef:	4c 89 ef             	mov    %r13,%rdi
    87f2:	e8 59 ac ff ff       	call   3450 <strlen@plt>
    87f7:	4c 89 ee             	mov    %r13,%rsi
    87fa:	48 89 df             	mov    %rbx,%rdi
    87fd:	48 89 c2             	mov    %rax,%rdx
    8800:	e8 6b b8 ff ff       	call   4070 <buf_put>
    8805:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    880a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    880e:	85 f6                	test   %esi,%esi
    8810:	0f 8e 80 f8 ff ff    	jle    8096 <fwp_write+0x96>
    8816:	45 31 ed             	xor    %r13d,%r13d
    8819:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    881e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8823:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8828:	ba 01 00 00 00       	mov    $0x1,%edx
    882d:	4c 89 fe             	mov    %r15,%rsi
    8830:	48 89 04 24          	mov    %rax,(%rsp)
    8834:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8839:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    883d:	48 89 df             	mov    %rbx,%rdi
    8840:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8844:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8849:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    884e:	e8 1d b8 ff ff       	call   4070 <buf_put>
    8853:	41 8b 06             	mov    (%r14),%eax
    8856:	83 f8 0e             	cmp    $0xe,%eax
    8859:	0f 84 71 02 00 00    	je     8ad0 <fwp_write+0xad0>
    885f:	83 f8 10             	cmp    $0x10,%eax
    8862:	0f 84 38 02 00 00    	je     8aa0 <fwp_write+0xaa0>
    8868:	83 f8 0a             	cmp    $0xa,%eax
    886b:	0f 84 7f 04 00 00    	je     8cf0 <fwp_write+0xcf0>
    8871:	0f 8f f9 00 00 00    	jg     8970 <fwp_write+0x970>
    8877:	83 f8 03             	cmp    $0x3,%eax
    887a:	0f 8f 50 04 00 00    	jg     8cd0 <fwp_write+0xcd0>
    8880:	85 c0                	test   %eax,%eax
    8882:	78 10                	js     8894 <fwp_write+0x894>
    8884:	48 8b 04 24          	mov    (%rsp),%rax
    8888:	48 c1 e8 3f          	shr    $0x3f,%rax
    888c:	85 c0                	test   %eax,%eax
    888e:	0f 85 f9 00 00 00    	jne    898d <fwp_write+0x98d>
    8894:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8899:	48 8b 34 24          	mov    (%rsp),%rsi
    889d:	31 c9                	xor    %ecx,%ecx
    889f:	48 89 df             	mov    %rbx,%rdi
    88a2:	e8 59 f7 ff ff       	call   8000 <fwp_write>
    88a7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    88ac:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    88b1:	49 83 c5 01          	add    $0x1,%r13
    88b5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    88b9:	0f 8f 5f ff ff ff    	jg     881e <fwp_write+0x81e>
    88bf:	e9 d2 f7 ff ff       	jmp    8096 <fwp_write+0x96>
    88c4:	0f 1f 40 00          	nopl   0x0(%rax)
    88c8:	ba 06 00 00 00       	mov    $0x6,%edx
    88cd:	48 8d 35 b9 58 00 00 	lea    0x58b9(%rip),%rsi        # e18d <_IO_stdin_used+0x18d>
    88d4:	45 31 ed             	xor    %r13d,%r13d
    88d7:	e8 94 b7 ff ff       	call   4070 <buf_put>
    88dc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    88e1:	75 19                	jne    88fc <fwp_write+0x8fc>
    88e3:	eb 6c                	jmp    8951 <fwp_write+0x951>
    88e5:	0f 1f 00             	nopl   (%rax)
    88e8:	ba 02 00 00 00       	mov    $0x2,%edx
    88ed:	48 8d 35 a3 58 00 00 	lea    0x58a3(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    88f4:	48 89 df             	mov    %rbx,%rdi
    88f7:	e8 74 b7 ff ff       	call   4070 <buf_put>
    88fc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8902:	b9 00 02 00 00       	mov    $0x200,%ecx
    8907:	31 c0                	xor    %eax,%eax
    8909:	49 83 c5 01          	add    $0x1,%r13
    890d:	4c 8d 05 80 58 00 00 	lea    0x5880(%rip),%r8        # e194 <_IO_stdin_used+0x194>
    8914:	ba 02 00 00 00       	mov    $0x2,%edx
    8919:	be 00 02 00 00       	mov    $0x200,%esi
    891e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8925:	00 
    8926:	e8 85 aa ff ff       	call   33b0 <__snprintf_chk@plt>
    892b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8932:	00 
    8933:	e8 18 ab ff ff       	call   3450 <strlen@plt>
    8938:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    893f:	00 
    8940:	48 89 df             	mov    %rbx,%rdi
    8943:	48 89 c2             	mov    %rax,%rdx
    8946:	e8 25 b7 ff ff       	call   4070 <buf_put>
    894b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    894f:	72 97                	jb     88e8 <fwp_write+0x8e8>
    8951:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8956:	ba 01 00 00 00       	mov    $0x1,%edx
    895b:	48 89 df             	mov    %rbx,%rdi
    895e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8963:	e8 08 b7 ff ff       	call   4070 <buf_put>
    8968:	e9 29 f7 ff ff       	jmp    8096 <fwp_write+0x96>
    896d:	0f 1f 00             	nopl   (%rax)
    8970:	83 f8 0b             	cmp    $0xb,%eax
    8973:	0f 85 1b ff ff ff    	jne    8894 <fwp_write+0x894>
    8979:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    897e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8982:	83 e0 01             	and    $0x1,%eax
    8985:	85 c0                	test   %eax,%eax
    8987:	0f 84 07 ff ff ff    	je     8894 <fwp_write+0x894>
    898d:	4c 89 fe             	mov    %r15,%rsi
    8990:	48 89 df             	mov    %rbx,%rdi
    8993:	ba 01 00 00 00       	mov    $0x1,%edx
    8998:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    899d:	e8 ce b6 ff ff       	call   4070 <buf_put>
    89a2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    89a7:	48 8b 34 24          	mov    (%rsp),%rsi
    89ab:	31 c9                	xor    %ecx,%ecx
    89ad:	48 89 df             	mov    %rbx,%rdi
    89b0:	e8 4b f6 ff ff       	call   8000 <fwp_write>
    89b5:	ba 01 00 00 00       	mov    $0x1,%edx
    89ba:	4c 89 fe             	mov    %r15,%rsi
    89bd:	48 89 df             	mov    %rbx,%rdi
    89c0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    89c5:	e8 a6 b6 ff ff       	call   4070 <buf_put>
    89ca:	e9 d8 fe ff ff       	jmp    88a7 <fwp_write+0x8a7>
    89cf:	90                   	nop
    89d0:	ba 01 00 00 00       	mov    $0x1,%edx
    89d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89da:	48 89 df             	mov    %rbx,%rdi
    89dd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    89e2:	e8 89 b6 ff ff       	call   4070 <buf_put>
    89e7:	e9 aa f6 ff ff       	jmp    8096 <fwp_write+0x96>
    89ec:	0f 1f 40 00          	nopl   0x0(%rax)
    89f0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89f5:	ba 01 00 00 00       	mov    $0x1,%edx
    89fa:	48 89 df             	mov    %rbx,%rdi
    89fd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8a02:	e8 69 b6 ff ff       	call   4070 <buf_put>
    8a07:	e9 8a f6 ff ff       	jmp    8096 <fwp_write+0x96>
    8a0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a10:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8a14:	48 8b 13             	mov    (%rbx),%rdx
    8a17:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8a1c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8a20:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8a24:	e9 6d f6 ff ff       	jmp    8096 <fwp_write+0x96>
    8a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a30:	ba 02 00 00 00       	mov    $0x2,%edx
    8a35:	48 8d 35 5b 57 00 00 	lea    0x575b(%rip),%rsi        # e197 <_IO_stdin_used+0x197>
    8a3c:	48 89 df             	mov    %rbx,%rdi
    8a3f:	e8 2c b6 ff ff       	call   4070 <buf_put>
    8a44:	e9 72 f8 ff ff       	jmp    82bb <fwp_write+0x2bb>
    8a49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8a50:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8a55:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8a5a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8a5e:	48 89 f7             	mov    %rsi,%rdi
    8a61:	48 89 34 24          	mov    %rsi,(%rsp)
    8a65:	e8 e6 a9 ff ff       	call   3450 <strlen@plt>
    8a6a:	48 8b 34 24          	mov    (%rsp),%rsi
    8a6e:	48 89 df             	mov    %rbx,%rdi
    8a71:	48 89 c2             	mov    %rax,%rdx
    8a74:	e8 f7 b5 ff ff       	call   4070 <buf_put>
    8a79:	ba 03 00 00 00       	mov    $0x3,%edx
    8a7e:	48 8d 35 35 57 00 00 	lea    0x5735(%rip),%rsi        # e1ba <_IO_stdin_used+0x1ba>
    8a85:	48 89 df             	mov    %rbx,%rdi
    8a88:	e8 e3 b5 ff ff       	call   4070 <buf_put>
    8a8d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8a92:	e9 35 f8 ff ff       	jmp    82cc <fwp_write+0x2cc>
    8a97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a9e:	00 00 
    8aa0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8aa5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8aa9:	48 85 ff             	test   %rdi,%rdi
    8aac:	0f 84 e2 fd ff ff    	je     8894 <fwp_write+0x894>
    8ab2:	48 8d 35 eb 56 00 00 	lea    0x56eb(%rip),%rsi        # e1a4 <_IO_stdin_used+0x1a4>
    8ab9:	e8 72 aa ff ff       	call   3530 <strcmp@plt>
    8abe:	85 c0                	test   %eax,%eax
    8ac0:	0f 95 c0             	setne  %al
    8ac3:	0f b6 c0             	movzbl %al,%eax
    8ac6:	e9 c1 fd ff ff       	jmp    888c <fwp_write+0x88c>
    8acb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ad0:	31 c0                	xor    %eax,%eax
    8ad2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8ad9:	00 
    8ada:	0f 97 c0             	seta   %al
    8add:	e9 aa fd ff ff       	jmp    888c <fwp_write+0x88c>
    8ae2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ae8:	48 89 df             	mov    %rbx,%rdi
    8aeb:	ba 02 00 00 00       	mov    $0x2,%edx
    8af0:	48 8d 35 aa 56 00 00 	lea    0x56aa(%rip),%rsi        # e1a1 <_IO_stdin_used+0x1a1>
    8af7:	e8 74 b5 ff ff       	call   4070 <buf_put>
    8afc:	4c 89 e8             	mov    %r13,%rax
    8aff:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8b04:	31 c9                	xor    %ecx,%ecx
    8b06:	48 c1 e0 04          	shl    $0x4,%rax
    8b0a:	48 89 df             	mov    %rbx,%rdi
    8b0d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8b12:	e8 e9 f4 ff ff       	call   8000 <fwp_write>
    8b17:	e9 5e f6 ff ff       	jmp    817a <fwp_write+0x17a>
    8b1c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b20:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8b25:	48 85 ff             	test   %rdi,%rdi
    8b28:	79 0c                	jns    8b36 <fwp_write+0xb36>
    8b2a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8b31:	00 
    8b32:	48 03 75 10          	add    0x10(%rbp),%rsi
    8b36:	48 63 3e             	movslq (%rsi),%rdi
    8b39:	83 f9 02             	cmp    $0x2,%ecx
    8b3c:	89 fe                	mov    %edi,%esi
    8b3e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8b42:	e9 f9 fb ff ff       	jmp    8740 <fwp_write+0x740>
    8b47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b4e:	00 00 
    8b50:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8b55:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8b5a:	48 85 ff             	test   %rdi,%rdi
    8b5d:	0f 88 0f 03 00 00    	js     8e72 <fwp_write+0xe72>
    8b63:	49 0f bf 38          	movswq (%r8),%rdi
    8b67:	83 f9 01             	cmp    $0x1,%ecx
    8b6a:	0f b7 f7             	movzwl %di,%esi
    8b6d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8b71:	e9 ca fb ff ff       	jmp    8740 <fwp_write+0x740>
    8b76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b7d:	00 00 00 
    8b80:	ba 01 00 00 00       	mov    $0x1,%edx
    8b85:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b8a:	48 83 c5 08          	add    $0x8,%rbp
    8b8e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8b93:	e8 d8 b4 ff ff       	call   4070 <buf_put>
    8b98:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8b9d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8ba2:	4d 85 ed             	test   %r13,%r13
    8ba5:	75 46                	jne    8bed <fwp_write+0xbed>
    8ba7:	e9 04 01 00 00       	jmp    8cb0 <fwp_write+0xcb0>
    8bac:	0f 1f 40 00          	nopl   0x0(%rax)
    8bb0:	41 80 f9 09          	cmp    $0x9,%r9b
    8bb4:	0f 84 d6 00 00 00    	je     8c90 <fwp_write+0xc90>
    8bba:	41 80 f9 0a          	cmp    $0xa,%r9b
    8bbe:	0f 85 9c 00 00 00    	jne    8c60 <fwp_write+0xc60>
    8bc4:	ba 02 00 00 00       	mov    $0x2,%edx
    8bc9:	48 8d 35 ad 55 00 00 	lea    0x55ad(%rip),%rsi        # e17d <_IO_stdin_used+0x17d>
    8bd0:	48 89 df             	mov    %rbx,%rdi
    8bd3:	e8 98 b4 ff ff       	call   4070 <buf_put>
    8bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bdf:	00 
    8be0:	48 83 c5 01          	add    $0x1,%rbp
    8be4:	49 39 ec             	cmp    %rbp,%r12
    8be7:	0f 84 c3 00 00 00    	je     8cb0 <fwp_write+0xcb0>
    8bed:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8bf2:	41 80 f9 0d          	cmp    $0xd,%r9b
    8bf6:	74 28                	je     8c20 <fwp_write+0xc20>
    8bf8:	7e b6                	jle    8bb0 <fwp_write+0xbb0>
    8bfa:	41 80 f9 22          	cmp    $0x22,%r9b
    8bfe:	74 40                	je     8c40 <fwp_write+0xc40>
    8c00:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8c04:	75 5a                	jne    8c60 <fwp_write+0xc60>
    8c06:	ba 02 00 00 00       	mov    $0x2,%edx
    8c0b:	48 8d 35 68 55 00 00 	lea    0x5568(%rip),%rsi        # e17a <_IO_stdin_used+0x17a>
    8c12:	48 89 df             	mov    %rbx,%rdi
    8c15:	e8 56 b4 ff ff       	call   4070 <buf_put>
    8c1a:	eb c4                	jmp    8be0 <fwp_write+0xbe0>
    8c1c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c20:	ba 02 00 00 00       	mov    $0x2,%edx
    8c25:	48 8d 35 57 55 00 00 	lea    0x5557(%rip),%rsi        # e183 <_IO_stdin_used+0x183>
    8c2c:	48 89 df             	mov    %rbx,%rdi
    8c2f:	e8 3c b4 ff ff       	call   4070 <buf_put>
    8c34:	eb aa                	jmp    8be0 <fwp_write+0xbe0>
    8c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c3d:	00 00 00 
    8c40:	ba 02 00 00 00       	mov    $0x2,%edx
    8c45:	48 8d 35 2b 55 00 00 	lea    0x552b(%rip),%rsi        # e177 <_IO_stdin_used+0x177>
    8c4c:	48 89 df             	mov    %rbx,%rdi
    8c4f:	e8 1c b4 ff ff       	call   4070 <buf_put>
    8c54:	eb 8a                	jmp    8be0 <fwp_write+0xbe0>
    8c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c5d:	00 00 00 
    8c60:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8c64:	0f 86 2e 01 00 00    	jbe    8d98 <fwp_write+0xd98>
    8c6a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8c6e:	0f 84 24 01 00 00    	je     8d98 <fwp_write+0xd98>
    8c74:	ba 01 00 00 00       	mov    $0x1,%edx
    8c79:	4c 89 fe             	mov    %r15,%rsi
    8c7c:	48 89 df             	mov    %rbx,%rdi
    8c7f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8c84:	e8 e7 b3 ff ff       	call   4070 <buf_put>
    8c89:	e9 52 ff ff ff       	jmp    8be0 <fwp_write+0xbe0>
    8c8e:	66 90                	xchg   %ax,%ax
    8c90:	ba 02 00 00 00       	mov    $0x2,%edx
    8c95:	48 8d 35 e4 54 00 00 	lea    0x54e4(%rip),%rsi        # e180 <_IO_stdin_used+0x180>
    8c9c:	48 89 df             	mov    %rbx,%rdi
    8c9f:	e8 cc b3 ff ff       	call   4070 <buf_put>
    8ca4:	e9 37 ff ff ff       	jmp    8be0 <fwp_write+0xbe0>
    8ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8cb0:	ba 01 00 00 00       	mov    $0x1,%edx
    8cb5:	4c 89 fe             	mov    %r15,%rsi
    8cb8:	48 89 df             	mov    %rbx,%rdi
    8cbb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8cc0:	e8 ab b3 ff ff       	call   4070 <buf_put>
    8cc5:	e9 cc f3 ff ff       	jmp    8096 <fwp_write+0x96>
    8cca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8cd0:	83 f8 04             	cmp    $0x4,%eax
    8cd3:	0f 85 bb fb ff ff    	jne    8894 <fwp_write+0x894>
    8cd9:	48 8b 04 24          	mov    (%rsp),%rax
    8cdd:	48 8b 40 08          	mov    0x8(%rax),%rax
    8ce1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8ce6:	48 c1 e8 3f          	shr    $0x3f,%rax
    8cea:	e9 96 fc ff ff       	jmp    8985 <fwp_write+0x985>
    8cef:	90                   	nop
    8cf0:	8b 0c 24             	mov    (%rsp),%ecx
    8cf3:	31 c0                	xor    %eax,%eax
    8cf5:	85 c9                	test   %ecx,%ecx
    8cf7:	0f 98 c0             	sets   %al
    8cfa:	e9 86 fc ff ff       	jmp    8985 <fwp_write+0x985>
    8cff:	90                   	nop
    8d00:	48 f7 d8             	neg    %rax
    8d03:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8d0a:	00 
    8d0b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8d12:	2d 
    8d13:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8d1a:	00 
    8d1b:	48 83 d2 00          	adc    $0x0,%rdx
    8d1f:	48 89 c6             	mov    %rax,%rsi
    8d22:	48 f7 da             	neg    %rdx
    8d25:	e8 16 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8d2a:	e9 51 f3 ff ff       	jmp    8080 <fwp_write+0x80>
    8d2f:	90                   	nop
    8d30:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8d35:	e9 c3 f5 ff ff       	jmp    82fd <fwp_write+0x2fd>
    8d3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d40:	4c 89 e9             	mov    %r13,%rcx
    8d43:	48 c1 e1 04          	shl    $0x4,%rcx
    8d47:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8d4c:	48 85 ff             	test   %rdi,%rdi
    8d4f:	0f 89 eb f9 ff ff    	jns    8740 <fwp_write+0x740>
    8d55:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8d59:	48 89 ce             	mov    %rcx,%rsi
    8d5c:	e9 df f9 ff ff       	jmp    8740 <fwp_write+0x740>
    8d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d68:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8d6f:	00 
    8d70:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8d74:	e9 20 fa ff ff       	jmp    8799 <fwp_write+0x799>
    8d79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d80:	ba 02 00 00 00       	mov    $0x2,%edx
    8d85:	48 8d 35 b6 53 00 00 	lea    0x53b6(%rip),%rsi        # e142 <_IO_stdin_used+0x142>
    8d8c:	e9 2d f7 ff ff       	jmp    84be <fwp_write+0x4be>
    8d91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d98:	4c 8d 05 e7 53 00 00 	lea    0x53e7(%rip),%r8        # e186 <_IO_stdin_used+0x186>
    8d9f:	b9 10 00 00 00       	mov    $0x10,%ecx
    8da4:	31 c0                	xor    %eax,%eax
    8da6:	ba 02 00 00 00       	mov    $0x2,%edx
    8dab:	be 10 00 00 00       	mov    $0x10,%esi
    8db0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8db7:	00 
    8db8:	e8 f3 a5 ff ff       	call   33b0 <__snprintf_chk@plt>
    8dbd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8dc4:	00 
    8dc5:	e8 86 a6 ff ff       	call   3450 <strlen@plt>
    8dca:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8dd1:	00 
    8dd2:	48 89 df             	mov    %rbx,%rdi
    8dd5:	48 89 c2             	mov    %rax,%rdx
    8dd8:	e8 93 b2 ff ff       	call   4070 <buf_put>
    8ddd:	e9 fe fd ff ff       	jmp    8be0 <fwp_write+0xbe0>
    8de2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8de8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8dec:	48 8d 35 49 53 00 00 	lea    0x5349(%rip),%rsi        # e13c <_IO_stdin_used+0x13c>
    8df3:	48 8d 05 41 53 00 00 	lea    0x5341(%rip),%rax        # e13b <_IO_stdin_used+0x13b>
    8dfa:	4c 89 e7             	mov    %r12,%rdi
    8dfd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8e01:	48 0f 46 f0          	cmovbe %rax,%rsi
    8e05:	e8 e6 a5 ff ff       	call   33f0 <strcpy@plt>
    8e0a:	e9 71 f2 ff ff       	jmp    8080 <fwp_write+0x80>
    8e0f:	90                   	nop
    8e10:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8e14:	48 8d 35 21 53 00 00 	lea    0x5321(%rip),%rsi        # e13c <_IO_stdin_used+0x13c>
    8e1b:	48 8d 05 19 53 00 00 	lea    0x5319(%rip),%rax        # e13b <_IO_stdin_used+0x13b>
    8e22:	0f 2f c8             	comiss %xmm0,%xmm1
    8e25:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8e2c:	00 
    8e2d:	4c 89 e7             	mov    %r12,%rdi
    8e30:	48 0f 46 f0          	cmovbe %rax,%rsi
    8e34:	e8 b7 a5 ff ff       	call   33f0 <strcpy@plt>
    8e39:	e9 42 f2 ff ff       	jmp    8080 <fwp_write+0x80>
    8e3e:	66 90                	xchg   %ax,%ax
    8e40:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    8e45:	45 85 c0             	test   %r8d,%r8d
    8e48:	75 34                	jne    8e7e <fwp_write+0xe7e>
    8e4a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e51:	00 
    8e52:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e59:	00 00 
    8e5b:	0f 85 74 f6 ff ff    	jne    84d5 <fwp_write+0x4d5>
    8e61:	ba 02 00 00 00       	mov    $0x2,%edx
    8e66:	48 8d 35 4a 53 00 00 	lea    0x534a(%rip),%rsi        # e1b7 <_IO_stdin_used+0x1b7>
    8e6d:	e9 a1 f3 ff ff       	jmp    8213 <fwp_write+0x213>
    8e72:	48 03 75 10          	add    0x10(%rbp),%rsi
    8e76:	49 89 f0             	mov    %rsi,%r8
    8e79:	e9 e5 fc ff ff       	jmp    8b63 <fwp_write+0xb63>
    8e7e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    8e83:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e88:	85 ff                	test   %edi,%edi
    8e8a:	0f 84 fa f3 ff ff    	je     828a <fwp_write+0x28a>
    8e90:	ba 01 00 00 00       	mov    $0x1,%edx
    8e95:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e9a:	48 89 df             	mov    %rbx,%rdi
    8e9d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8ea2:	e8 c9 b1 ff ff       	call   4070 <buf_put>
    8ea7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    8eac:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8eb1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    8eb7:	85 c0                	test   %eax,%eax
    8eb9:	0f 8f f0 f3 ff ff    	jg     82af <fwp_write+0x2af>
    8ebf:	e9 34 f4 ff ff       	jmp    82f8 <fwp_write+0x2f8>
    8ec4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8ec8:	49 89 c5             	mov    %rax,%r13
    8ecb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8ed0:	49 89 c4             	mov    %rax,%r12
    8ed3:	49 c1 fd 3f          	sar    $0x3f,%r13
    8ed7:	4c 09 e8             	or     %r13,%rax
    8eda:	0f 84 a7 00 00 00    	je     8f87 <fwp_write+0xf87>
    8ee0:	48 8d 2d d9 73 00 00 	lea    0x73d9(%rip),%rbp        # 102c0 <units.0>
    8ee7:	4d 89 e7             	mov    %r12,%r15
    8eea:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8eee:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    8ef3:	4c 89 ff             	mov    %r15,%rdi
    8ef6:	4c 89 ee             	mov    %r13,%rsi
    8ef9:	44 89 0c 24          	mov    %r9d,(%rsp)
    8efd:	48 99                	cqto
    8eff:	48 89 d1             	mov    %rdx,%rcx
    8f02:	48 89 c2             	mov    %rax,%rdx
    8f05:	e8 26 4e 00 00       	call   dd30 <__divmodti4>
    8f0a:	44 8b 0c 24          	mov    (%rsp),%r9d
    8f0e:	48 89 c1             	mov    %rax,%rcx
    8f11:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    8f16:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    8f1b:	0f 84 94 00 00 00    	je     8fb5 <fwp_write+0xfb5>
    8f21:	41 83 c1 01          	add    $0x1,%r9d
    8f25:	48 83 c5 10          	add    $0x10,%rbp
    8f29:	41 83 f9 05          	cmp    $0x5,%r9d
    8f2d:	75 bb                	jne    8eea <fwp_write+0xeea>
    8f2f:	4d 85 ed             	test   %r13,%r13
    8f32:	79 53                	jns    8f87 <fwp_write+0xf87>
    8f34:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8f39:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8f3e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8f43:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f48:	48 99                	cqto
    8f4a:	48 f7 d8             	neg    %rax
    8f4d:	48 83 d2 00          	adc    $0x0,%rdx
    8f51:	48 89 c6             	mov    %rax,%rsi
    8f54:	48 f7 da             	neg    %rdx
    8f57:	e8 e4 aa ff ff       	call   3a40 <fwp_fmt_u128>
    8f5c:	49 89 e8             	mov    %rbp,%r8
    8f5f:	ba 00 02 00 00       	mov    $0x200,%edx
    8f64:	be 02 00 00 00       	mov    $0x2,%esi
    8f69:	31 c0                	xor    %eax,%eax
    8f6b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f72:	00 
    8f73:	48 8d 0d 38 52 00 00 	lea    0x5238(%rip),%rcx        # e1b2 <_IO_stdin_used+0x1b2>
    8f7a:	4c 89 e7             	mov    %r12,%rdi
    8f7d:	e8 5e a7 ff ff       	call   36e0 <__sprintf_chk@plt>
    8f82:	e9 f9 f0 ff ff       	jmp    8080 <fwp_write+0x80>
    8f87:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f8c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    8f91:	31 d2                	xor    %edx,%edx
    8f93:	48 89 ef             	mov    %rbp,%rdi
    8f96:	e8 a5 aa ff ff       	call   3a40 <fwp_fmt_u128>
    8f9b:	eb bf                	jmp    8f5c <fwp_write+0xf5c>
    8f9d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    8fa4:	4e 61 4e 00 
    8fa8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8faf:	00 
    8fb0:	e9 cb f0 ff ff       	jmp    8080 <fwp_write+0x80>
    8fb5:	44 89 0c 24          	mov    %r9d,(%rsp)
    8fb9:	48 89 c8             	mov    %rcx,%rax
    8fbc:	48 85 d2             	test   %rdx,%rdx
    8fbf:	78 51                	js     9012 <fwp_write+0x1012>
    8fc1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8fc6:	48 89 c6             	mov    %rax,%rsi
    8fc9:	48 89 ef             	mov    %rbp,%rdi
    8fcc:	e8 6f aa ff ff       	call   3a40 <fwp_fmt_u128>
    8fd1:	44 8b 0c 24          	mov    (%rsp),%r9d
    8fd5:	49 63 c1             	movslq %r9d,%rax
    8fd8:	49 89 e8             	mov    %rbp,%r8
    8fdb:	ba 00 02 00 00       	mov    $0x200,%edx
    8fe0:	be 02 00 00 00       	mov    $0x2,%esi
    8fe5:	48 c1 e0 04          	shl    $0x4,%rax
    8fe9:	48 8d 3d d0 72 00 00 	lea    0x72d0(%rip),%rdi        # 102c0 <units.0>
    8ff0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8ff7:	00 
    8ff8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    8ffc:	48 8d 0d aa 51 00 00 	lea    0x51aa(%rip),%rcx        # e1ad <_IO_stdin_used+0x1ad>
    9003:	4c 89 e7             	mov    %r12,%rdi
    9006:	31 c0                	xor    %eax,%eax
    9008:	e8 d3 a6 ff ff       	call   36e0 <__sprintf_chk@plt>
    900d:	e9 6e f0 ff ff       	jmp    8080 <fwp_write+0x80>
    9012:	48 f7 d8             	neg    %rax
    9015:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    901a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    901f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9024:	48 83 d2 00          	adc    $0x0,%rdx
    9028:	48 89 c6             	mov    %rax,%rsi
    902b:	48 f7 da             	neg    %rdx
    902e:	e8 0d aa ff ff       	call   3a40 <fwp_fmt_u128>
    9033:	44 8b 0c 24          	mov    (%rsp),%r9d
    9037:	eb 9c                	jmp    8fd5 <fwp_write+0xfd5>
    9039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009040 <fwp_hof0.constprop.0>:
    9040:	41 57                	push   %r15
    9042:	41 56                	push   %r14
    9044:	41 55                	push   %r13
    9046:	41 54                	push   %r12
    9048:	55                   	push   %rbp
    9049:	53                   	push   %rbx
    904a:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
    9051:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9058:	00 00 
    905a:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    9061:	00 
    9062:	31 c0                	xor    %eax,%eax
    9064:	48 85 f6             	test   %rsi,%rsi
    9067:	0f 84 6a 0f 00 00    	je     9fd7 <fwp_hof0.constprop.0+0xf97>
    906d:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
    9072:	4c 8d 2d e7 96 01 00 	lea    0x196e7(%rip),%r13        # 22760 <fwp_heap>
    9079:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    907e:	66 90                	xchg   %ax,%ax
    9080:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9087:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    908c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9093:	48 c1 e2 10          	shl    $0x10,%rdx
    9097:	48 39 d0             	cmp    %rdx,%rax
    909a:	73 5d                	jae    90f9 <fwp_hof0.constprop.0+0xb9>
    909c:	48 89 c2             	mov    %rax,%rdx
    909f:	48 c1 ea 10          	shr    $0x10,%rdx
    90a3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    90a7:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    90ae:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    90b2:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    90b6:	48 85 ff             	test   %rdi,%rdi
    90b9:	74 3e                	je     90f9 <fwp_hof0.constprop.0+0xb9>
    90bb:	0f b6 0a             	movzbl (%rdx),%ecx
    90be:	80 f9 02             	cmp    $0x2,%cl
    90c1:	0f 84 09 15 00 00    	je     a5d0 <fwp_hof0.constprop.0+0x1590>
    90c7:	80 f9 01             	cmp    $0x1,%cl
    90ca:	75 2d                	jne    90f9 <fwp_hof0.constprop.0+0xb9>
    90cc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    90cf:	0f b7 c0             	movzwl %ax,%eax
    90d2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    90d5:	48 0f af c1          	imul   %rcx,%rax
    90d9:	48 c1 e8 20          	shr    $0x20,%rax
    90dd:	48 39 d0             	cmp    %rdx,%rax
    90e0:	73 17                	jae    90f9 <fwp_hof0.constprop.0+0xb9>
    90e2:	48 01 c7             	add    %rax,%rdi
    90e5:	0f b6 07             	movzbl (%rdi),%eax
    90e8:	84 c0                	test   %al,%al
    90ea:	74 0d                	je     90f9 <fwp_hof0.constprop.0+0xb9>
    90ec:	3c fd                	cmp    $0xfd,%al
    90ee:	0f 87 e7 16 00 00    	ja     a7db <fwp_hof0.constprop.0+0x179b>
    90f4:	83 c0 01             	add    $0x1,%eax
    90f7:	88 07                	mov    %al,(%rdi)
    90f9:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    90fe:	45 31 c0             	xor    %r8d,%r8d
    9101:	48 c7 44 24 28 c6 00 	movq   $0xc6,0x28(%rsp)
    9108:	00 00 
    910a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    910f:	4d 89 c6             	mov    %r8,%r14
    9112:	4d 85 c0             	test   %r8,%r8
    9115:	0f 85 35 a6 ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    911b:	48 8b 05 d6 b2 01 00 	mov    0x1b2d6(%rip),%rax        # 243f8 <fwp_cleanups>
    9122:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9129:	4c 8d 25 50 d8 ff ff 	lea    -0x27b0(%rip),%r12        # 6980 <fwp_tape_scope_release>
    9130:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    9137:	ff ff ff ff 
    913b:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
    9142:	00 
    9143:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    914a:	00 
    914b:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    9152:	00 
    9153:	48 c1 e2 10          	shl    $0x10,%rdx
    9157:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    915c:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9163:	00 
    9164:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    916b:	00 
    916c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9171:	48 89 05 80 b2 01 00 	mov    %rax,0x1b280(%rip)        # 243f8 <fwp_cleanups>
    9178:	48 8d 05 91 8e 00 00 	lea    0x8e91(%rip),%rax        # 12010 <fc37>
    917f:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9186:	48 39 d0             	cmp    %rdx,%rax
    9189:	73 5d                	jae    91e8 <fwp_hof0.constprop.0+0x1a8>
    918b:	48 89 c2             	mov    %rax,%rdx
    918e:	48 c1 ea 10          	shr    $0x10,%rdx
    9192:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9196:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    919d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    91a1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    91a5:	48 85 ff             	test   %rdi,%rdi
    91a8:	74 3e                	je     91e8 <fwp_hof0.constprop.0+0x1a8>
    91aa:	0f b6 0a             	movzbl (%rdx),%ecx
    91ad:	80 f9 02             	cmp    $0x2,%cl
    91b0:	0f 84 aa 12 00 00    	je     a460 <fwp_hof0.constprop.0+0x1420>
    91b6:	80 f9 01             	cmp    $0x1,%cl
    91b9:	75 2d                	jne    91e8 <fwp_hof0.constprop.0+0x1a8>
    91bb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    91be:	0f b7 c0             	movzwl %ax,%eax
    91c1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    91c4:	48 0f af c1          	imul   %rcx,%rax
    91c8:	48 c1 e8 20          	shr    $0x20,%rax
    91cc:	48 39 d0             	cmp    %rdx,%rax
    91cf:	73 17                	jae    91e8 <fwp_hof0.constprop.0+0x1a8>
    91d1:	48 01 c7             	add    %rax,%rdi
    91d4:	0f b6 07             	movzbl (%rdi),%eax
    91d7:	84 c0                	test   %al,%al
    91d9:	74 0d                	je     91e8 <fwp_hof0.constprop.0+0x1a8>
    91db:	3c fd                	cmp    $0xfd,%al
    91dd:	0f 87 38 15 00 00    	ja     a71b <fwp_hof0.constprop.0+0x16db>
    91e3:	83 c0 01             	add    $0x1,%eax
    91e6:	88 07                	mov    %al,(%rdi)
    91e8:	48 8d 3d 21 8e 00 00 	lea    0x8e21(%rip),%rdi        # 12010 <fc37>
    91ef:	e8 5c d4 ff ff       	call   6650 <fwp_closure_drop>
    91f4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    91f9:	48 85 c0             	test   %rax,%rax
    91fc:	0f 84 2e 14 00 00    	je     a630 <fwp_hof0.constprop.0+0x15f0>
    9202:	31 d2                	xor    %edx,%edx
    9204:	90                   	nop
    9205:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    920c:	00 00 00 00 
    9210:	48 8b 40 10          	mov    0x10(%rax),%rax
    9214:	48 83 c2 01          	add    $0x1,%rdx
    9218:	48 85 c0             	test   %rax,%rax
    921b:	75 f3                	jne    9210 <fwp_hof0.constprop.0+0x1d0>
    921d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    9224:	0f 87 ef 15 00 00    	ja     a819 <fwp_hof0.constprop.0+0x17d9>
    922a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    922f:	8b 35 2b 8e 00 00    	mov    0x8e2b(%rip),%esi        # 12060 <registered_finish.1>
    9235:	85 f6                	test   %esi,%esi
    9237:	0f 84 e3 11 00 00    	je     a420 <fwp_hof0.constprop.0+0x13e0>
    923d:	4c 8b 3d 94 8e 01 00 	mov    0x18e94(%rip),%r15        # 220d8 <fwp_tape_next_slot>
    9244:	48 8b 2d 9d 8e 01 00 	mov    0x18e9d(%rip),%rbp        # 220e8 <fwp_ntapes>
    924b:	4c 39 fd             	cmp    %r15,%rbp
    924e:	0f 8e 5c 0e 00 00    	jle    a0b0 <fwp_hof0.constprop.0+0x1070>
    9254:	49 6b c7 68          	imul   $0x68,%r15,%rax
    9258:	48 03 05 91 8e 01 00 	add    0x18e91(%rip),%rax        # 220f0 <fwp_tapes>
    925f:	90                   	nop
    9260:	8b 48 04             	mov    0x4(%rax),%ecx
    9263:	85 c9                	test   %ecx,%ecx
    9265:	75 0c                	jne    9273 <fwp_hof0.constprop.0+0x233>
    9267:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    926d:	0f 86 3d 0e 00 00    	jbe    a0b0 <fwp_hof0.constprop.0+0x1070>
    9273:	49 83 c7 01          	add    $0x1,%r15
    9277:	48 83 c0 68          	add    $0x68,%rax
    927b:	4c 39 fd             	cmp    %r15,%rbp
    927e:	75 e0                	jne    9260 <fwp_hof0.constprop.0+0x220>
    9280:	48 81 fd fe ff 00 00 	cmp    $0xfffe,%rbp
    9287:	0f 8f 0f 16 00 00    	jg     a89c <fwp_hof0.constprop.0+0x185c>
    928d:	48 3b 2d 4c 8e 01 00 	cmp    0x18e4c(%rip),%rbp        # 220e0 <fwp_tapes_cap>
    9294:	48 8b 1d 55 8e 01 00 	mov    0x18e55(%rip),%rbx        # 220f0 <fwp_tapes>
    929b:	75 4c                	jne    92e9 <fwp_hof0.constprop.0+0x2a9>
    929d:	48 85 ed             	test   %rbp,%rbp
    92a0:	0f 84 f0 13 00 00    	je     a696 <fwp_hof0.constprop.0+0x1656>
    92a6:	4c 8d 7c 2d 00       	lea    0x0(%rbp,%rbp,1),%r15
    92ab:	b8 ff ff 00 00       	mov    $0xffff,%eax
    92b0:	49 39 c7             	cmp    %rax,%r15
    92b3:	4c 0f 4f f8          	cmovg  %rax,%r15
    92b7:	49 6b f7 68          	imul   $0x68,%r15,%rsi
    92bb:	48 89 df             	mov    %rbx,%rdi
    92be:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    92c4:	e8 07 a3 ff ff       	call   35d0 <realloc@plt>
    92c9:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    92cf:	48 85 c0             	test   %rax,%rax
    92d2:	48 89 c3             	mov    %rax,%rbx
    92d5:	0f 84 cd 15 00 00    	je     a8a8 <fwp_hof0.constprop.0+0x1868>
    92db:	48 89 05 0e 8e 01 00 	mov    %rax,0x18e0e(%rip)        # 220f0 <fwp_tapes>
    92e2:	4c 89 3d f7 8d 01 00 	mov    %r15,0x18df7(%rip)        # 220e0 <fwp_tapes_cap>
    92e9:	48 6b cd 68          	imul   $0x68,%rbp,%rcx
    92ed:	31 c0                	xor    %eax,%eax
    92ef:	49 89 ef             	mov    %rbp,%r15
    92f2:	48 01 d9             	add    %rbx,%rcx
    92f5:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    92f9:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    9300:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9304:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    930b:	00 
    930c:	48 29 f9             	sub    %rdi,%rcx
    930f:	83 c1 68             	add    $0x68,%ecx
    9312:	c1 e9 03             	shr    $0x3,%ecx
    9315:	f3 48 ab             	rep stos %rax,(%rdi)
    9318:	48 8d 45 01          	lea    0x1(%rbp),%rax
    931c:	48 89 05 c5 8d 01 00 	mov    %rax,0x18dc5(%rip)        # 220e8 <fwp_ntapes>
    9323:	49 6b ef 68          	imul   $0x68,%r15,%rbp
    9327:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    932b:	48 8d 3d 8d 4d 00 00 	lea    0x4d8d(%rip),%rdi        # e0bf <_IO_stdin_used+0xbf>
    9332:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9337:	48 01 dd             	add    %rbx,%rbp
    933a:	48 c7 45 60 00 00 00 	movq   $0x0,0x60(%rbp)
    9341:	00 
    9342:	e8 59 a0 ff ff       	call   33a0 <getenv@plt>
    9347:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    934d:	48 85 c0             	test   %rax,%rax
    9350:	0f 84 72 0d 00 00    	je     a0c8 <fwp_hof0.constprop.0+0x1088>
    9356:	80 38 30             	cmpb   $0x30,(%rax)
    9359:	0f 85 69 0d 00 00    	jne    a0c8 <fwp_hof0.constprop.0+0x1088>
    935f:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9363:	0f 85 5f 0d 00 00    	jne    a0c8 <fwp_hof0.constprop.0+0x1088>
    9369:	8b 45 00             	mov    0x0(%rbp),%eax
    936c:	49 8d 77 01          	lea    0x1(%r15),%rsi
    9370:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    9374:	c7 45 04 01 00 00 00 	movl   $0x1,0x4(%rbp)
    937b:	8d 48 01             	lea    0x1(%rax),%ecx
    937e:	48 8b 05 1b 57 00 00 	mov    0x571b(%rip),%rax        # eaa0 <msg.4+0x20>
    9385:	48 89 35 4c 8d 01 00 	mov    %rsi,0x18d4c(%rip)        # 220d8 <fwp_tape_next_slot>
    938c:	89 4d 00             	mov    %ecx,0x0(%rbp)
    938f:	48 89 45 58          	mov    %rax,0x58(%rbp)
    9393:	48 8b 05 5e b0 01 00 	mov    0x1b05e(%rip),%rax        # 243f8 <fwp_cleanups>
    939a:	48 c7 45 50 00 00 00 	movq   $0x0,0x50(%rbp)
    93a1:	00 
    93a2:	48 85 c0             	test   %rax,%rax
    93a5:	75 15                	jne    93bc <fwp_hof0.constprop.0+0x37c>
    93a7:	e9 94 14 00 00       	jmp    a840 <fwp_hof0.constprop.0+0x1800>
    93ac:	0f 1f 40 00          	nopl   0x0(%rax)
    93b0:	48 8b 00             	mov    (%rax),%rax
    93b3:	48 85 c0             	test   %rax,%rax
    93b6:	0f 84 84 14 00 00    	je     a840 <fwp_hof0.constprop.0+0x1800>
    93bc:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    93c0:	75 ee                	jne    93b0 <fwp_hof0.constprop.0+0x370>
    93c2:	4c 8b 48 10          	mov    0x10(%rax),%r9
    93c6:	44 89 ff             	mov    %r15d,%edi
    93c9:	49 63 01             	movslq (%r9),%rax
    93cc:	4c 89 4d 50          	mov    %r9,0x50(%rbp)
    93d0:	89 45 5c             	mov    %eax,0x5c(%rbp)
    93d3:	85 c0                	test   %eax,%eax
    93d5:	78 09                	js     93e0 <fwp_hof0.constprop.0+0x3a0>
    93d7:	48 6b c0 68          	imul   $0x68,%rax,%rax
    93db:	44 89 7c 03 58       	mov    %r15d,0x58(%rbx,%rax,1)
    93e0:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    93e5:	41 89 39             	mov    %edi,(%r9)
    93e8:	45 31 e4             	xor    %r12d,%r12d
    93eb:	48 89 d8             	mov    %rbx,%rax
    93ee:	48 85 db             	test   %rbx,%rbx
    93f1:	0f 84 39 0e 00 00    	je     a230 <fwp_hof0.constprop.0+0x11f0>
    93f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    93fe:	00 00 
    9400:	48 8b 40 10          	mov    0x10(%rax),%rax
    9404:	49 83 c4 01          	add    $0x1,%r12
    9408:	48 85 c0             	test   %rax,%rax
    940b:	75 f3                	jne    9400 <fwp_hof0.constprop.0+0x3c0>
    940d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9412:	0f 1f 00             	nopl   (%rax)
    9415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    941c:	00 00 00 00 
    9420:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9424:	48 83 c0 01          	add    $0x1,%rax
    9428:	48 85 d2             	test   %rdx,%rdx
    942b:	75 f3                	jne    9420 <fwp_hof0.constprop.0+0x3e0>
    942d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9434:	ff ff 1f 
    9437:	48 39 c2             	cmp    %rax,%rdx
    943a:	0f 82 f1 13 00 00    	jb     a831 <fwp_hof0.constprop.0+0x17f1>
    9440:	4d 85 e4             	test   %r12,%r12
    9443:	0f 8e e7 0d 00 00    	jle    a230 <fwp_hof0.constprop.0+0x11f0>
    9449:	49 39 c4             	cmp    %rax,%r12
    944c:	4c 0f 47 e0          	cmova  %rax,%r12
    9450:	4c 89 e0             	mov    %r12,%rax
    9453:	48 c1 e8 3c          	shr    $0x3c,%rax
    9457:	0f 85 d4 13 00 00    	jne    a831 <fwp_hof0.constprop.0+0x17f1>
    945d:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    9461:	48 c1 e1 10          	shl    $0x10,%rcx
    9465:	48 09 f1             	or     %rsi,%rcx
    9468:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    946f:	00 
    9470:	be 02 00 00 00       	mov    $0x2,%esi
    9475:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    947a:	e8 d1 c5 ff ff       	call   5a50 <fwp_heap_alloc>
    947f:	4c 89 38             	mov    %r15,(%rax)
    9482:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9489:	48 89 c5             	mov    %rax,%rbp
    948c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9493:	48 c1 e2 10          	shl    $0x10,%rdx
    9497:	48 39 d0             	cmp    %rdx,%rax
    949a:	0f 83 40 0e 00 00    	jae    a2e0 <fwp_hof0.constprop.0+0x12a0>
    94a0:	48 89 c2             	mov    %rax,%rdx
    94a3:	48 c1 ea 10          	shr    $0x10,%rdx
    94a7:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    94ab:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    94b2:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    94b6:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    94ba:	4d 85 ff             	test   %r15,%r15
    94bd:	74 3a                	je     94f9 <fwp_hof0.constprop.0+0x4b9>
    94bf:	0f b6 32             	movzbl (%rdx),%esi
    94c2:	40 80 fe 02          	cmp    $0x2,%sil
    94c6:	0f 84 d7 0d 00 00    	je     a2a3 <fwp_hof0.constprop.0+0x1263>
    94cc:	40 80 fe 01          	cmp    $0x1,%sil
    94d0:	75 27                	jne    94f9 <fwp_hof0.constprop.0+0x4b9>
    94d2:	8b 72 18             	mov    0x18(%rdx),%esi
    94d5:	0f b7 c0             	movzwl %ax,%eax
    94d8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94db:	48 0f af c6          	imul   %rsi,%rax
    94df:	48 c1 e8 20          	shr    $0x20,%rax
    94e3:	48 39 d0             	cmp    %rdx,%rax
    94e6:	73 11                	jae    94f9 <fwp_hof0.constprop.0+0x4b9>
    94e8:	49 01 c7             	add    %rax,%r15
    94eb:	41 80 3f ff          	cmpb   $0xff,(%r15)
    94ef:	0f 84 c1 0d 00 00    	je     a2b6 <fwp_hof0.constprop.0+0x1276>
    94f5:	41 c6 07 01          	movb   $0x1,(%r15)
    94f9:	4d 85 e4             	test   %r12,%r12
    94fc:	74 75                	je     9573 <fwp_hof0.constprop.0+0x533>
    94fe:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9503:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9508:	31 c0                	xor    %eax,%eax
    950a:	48 c1 e6 20          	shl    $0x20,%rsi
    950e:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9514:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    951b:	00 00 00 00 
    951f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9526:	00 00 00 00 
    952a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9531:	00 00 00 00 
    9535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    953c:	00 00 00 00 
    9540:	48 89 c1             	mov    %rax,%rcx
    9543:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9548:	48 01 f1             	add    %rsi,%rcx
    954b:	0f 80 ff a1 ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9551:	66 48 0f 6e e1       	movq   %rcx,%xmm4
    9556:	48 89 c1             	mov    %rax,%rcx
    9559:	48 83 c0 01          	add    $0x1,%rax
    955d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9561:	48 c1 e1 04          	shl    $0x4,%rcx
    9565:	0f 11 44 0d 08       	movups %xmm0,0x8(%rbp,%rcx,1)
    956a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    956e:	4c 39 e0             	cmp    %r12,%rax
    9571:	72 cd                	jb     9540 <fwp_hof0.constprop.0+0x500>
    9573:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9577:	48 d1 e8             	shr    $1,%rax
    957a:	0f 84 70 0d 00 00    	je     a2f0 <fwp_hof0.constprop.0+0x12b0>
    9580:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9584:	48 89 f3             	mov    %rsi,%rbx
    9587:	48 c1 eb 3c          	shr    $0x3c,%rbx
    958b:	0f 85 a0 12 00 00    	jne    a831 <fwp_hof0.constprop.0+0x17f1>
    9591:	48 8d 1c 36          	lea    (%rsi,%rsi,1),%rbx
    9595:	48 85 f6             	test   %rsi,%rsi
    9598:	74 44                	je     95de <fwp_hof0.constprop.0+0x59e>
    959a:	48 c1 e0 04          	shl    $0x4,%rax
    959e:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
    95a2:	4c 8d 64 05 f8       	lea    -0x8(%rbp,%rax,1),%r12
    95a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    95ae:	00 00 
    95b0:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    95b5:	49 8b 77 18          	mov    0x18(%r15),%rsi
    95b9:	49 83 c7 10          	add    $0x10,%r15
    95bd:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    95c1:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    95c6:	e8 55 ca ff ff       	call   6020 <w120>
    95cb:	66 48 0f 6e e8       	movq   %rax,%xmm5
    95d0:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    95d4:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    95d9:	4d 39 fc             	cmp    %r15,%r12
    95dc:	75 d2                	jne    95b0 <fwp_hof0.constprop.0+0x570>
    95de:	48 89 5d 00          	mov    %rbx,0x0(%rbp)
    95e2:	48 89 ef             	mov    %rbp,%rdi
    95e5:	e8 a6 cb ff ff       	call   6190 <w176.constprop.0>
    95ea:	48 89 ef             	mov    %rbp,%rdi
    95ed:	49 89 c4             	mov    %rax,%r12
    95f0:	e8 bb e2 ff ff       	call   78b0 <fwp_drop10>
    95f5:	4c 63 7c 24 10       	movslq 0x10(%rsp),%r15
    95fa:	4c 89 ff             	mov    %r15,%rdi
    95fd:	e8 7e ae ff ff       	call   4480 <fwp_tape_of>
    9602:	48 89 c6             	mov    %rax,%rsi
    9605:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    960a:	0f 85 c6 12 00 00    	jne    a8d6 <fwp_hof0.constprop.0+0x1896>
    9610:	48 89 c7             	mov    %rax,%rdi
    9613:	e8 e8 a5 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    9618:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    961c:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9621:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9628:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    962c:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    9630:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    9635:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    963a:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    963f:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    9643:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    9647:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    964d:	77 1a                	ja     9669 <fwp_hof0.constprop.0+0x629>
    964f:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
    9654:	83 e8 01             	sub    $0x1,%eax
    9657:	48 98                	cltq
    9659:	48 3b 05 78 8a 01 00 	cmp    0x18a78(%rip),%rax        # 220d8 <fwp_tape_next_slot>
    9660:	7d 07                	jge    9669 <fwp_hof0.constprop.0+0x629>
    9662:	48 89 05 6f 8a 01 00 	mov    %rax,0x18a6f(%rip)        # 220d8 <fwp_tape_next_slot>
    9669:	48 8b 05 88 ad 01 00 	mov    0x1ad88(%rip),%rax        # 243f8 <fwp_cleanups>
    9670:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9674:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    967b:	00 
    967c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9680:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9687:	00 
    9688:	48 8d 05 a1 b7 ff ff 	lea    -0x485f(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    968f:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    9696:	00 
    9697:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    969e:	00 
    969f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    96a4:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    96ab:	00 
    96ac:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    96b3:	00 
    96b4:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    96bb:	00 
    96bc:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    96c3:	00 
    96c4:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    96c8:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    96cc:	48 89 05 25 ad 01 00 	mov    %rax,0x1ad25(%rip)        # 243f8 <fwp_cleanups>
    96d3:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    96da:	00 
    96db:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
    96e2:	00 
    96e3:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
    96ea:	00 
    96eb:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    96f2:	00 
    96f3:	4d 85 e4             	test   %r12,%r12
    96f6:	0f 88 74 0d 00 00    	js     a470 <fwp_hof0.constprop.0+0x1430>
    96fc:	4c 89 e0             	mov    %r12,%rax
    96ff:	48 c1 f8 20          	sar    $0x20,%rax
    9703:	49 39 c7             	cmp    %rax,%r15
    9706:	0f 85 e1 10 00 00    	jne    a7ed <fwp_hof0.constprop.0+0x17ad>
    970c:	45 89 e7             	mov    %r12d,%r15d
    970f:	4c 89 fd             	mov    %r15,%rbp
    9712:	4c 39 ff             	cmp    %r15,%rdi
    9715:	0f 8e de 10 00 00    	jle    a7f9 <fwp_hof0.constprop.0+0x17b9>
    971b:	4c 39 fb             	cmp    %r15,%rbx
    971e:	0f 8e fc 0b 00 00    	jle    a320 <fwp_hof0.constprop.0+0x12e0>
    9724:	48 39 d3             	cmp    %rdx,%rbx
    9727:	0f 8f 3b 0c 00 00    	jg     a368 <fwp_hof0.constprop.0+0x1328>
    972d:	48 85 c9             	test   %rcx,%rcx
    9730:	0f 84 1f 11 00 00    	je     a855 <fwp_hof0.constprop.0+0x1815>
    9736:	48 89 cf             	mov    %rcx,%rdi
    9739:	31 f6                	xor    %esi,%esi
    973b:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    9740:	48 8d 6b ff          	lea    -0x1(%rbx),%rbp
    9744:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    974b:	00 
    974c:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    9751:	e8 6a 9d ff ff       	call   34c0 <memset@plt>
    9756:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    975c:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    9762:	48 89 c1             	mov    %rax,%rcx
    9765:	f2 0f 10 05 3b 53 00 	movsd  0x533b(%rip),%xmm0        # eaa8 <msg.4+0x28>
    976c:	00 
    976d:	f2 42 0f 58 04 f9    	addsd  (%rcx,%r15,8),%xmm0
    9773:	f2 42 0f 11 04 f9    	movsd  %xmm0,(%rcx,%r15,8)
    9779:	48 39 eb             	cmp    %rbp,%rbx
    977c:	0f 8f 90 00 00 00    	jg     9812 <fwp_hof0.constprop.0+0x7d2>
    9782:	0f 12 fb             	movhlps %xmm3,%xmm7
    9785:	66 49 0f 7e d2       	movq   %xmm2,%r10
    978a:	66 48 0f 7e de       	movq   %xmm3,%rsi
    978f:	48 29 dd             	sub    %rbx,%rbp
    9792:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    9797:	0f 12 fa             	movhlps %xmm2,%xmm7
    979a:	66 0f ef d2          	pxor   %xmm2,%xmm2
    979e:	66 49 0f 7e fb       	movq   %xmm7,%r11
    97a3:	48 8d 04 af          	lea    (%rdi,%rbp,4),%rax
    97a7:	48 29 fe             	sub    %rdi,%rsi
    97aa:	49 8d 14 eb          	lea    (%r11,%rbp,8),%rdx
    97ae:	48 8d 2c d9          	lea    (%rcx,%rbx,8),%rbp
    97b2:	4d 29 da             	sub    %r11,%r10
    97b5:	4c 29 dd             	sub    %r11,%rbp
    97b8:	eb 0a                	jmp    97c4 <fwp_hof0.constprop.0+0x784>
    97ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    97c0:	48 83 e8 04          	sub    $0x4,%rax
    97c4:	f2 0f 10 44 15 00    	movsd  0x0(%rbp,%rdx,1),%xmm0
    97ca:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    97ce:	7a 02                	jp     97d2 <fwp_hof0.constprop.0+0x792>
    97d0:	74 37                	je     9809 <fwp_hof0.constprop.0+0x7c9>
    97d2:	4c 63 04 06          	movslq (%rsi,%rax,1),%r8
    97d6:	45 85 c0             	test   %r8d,%r8d
    97d9:	78 16                	js     97f1 <fwp_hof0.constprop.0+0x7b1>
    97db:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    97e1:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    97e5:	f2 42 0f 58 0c c1    	addsd  (%rcx,%r8,8),%xmm1
    97eb:	f2 42 0f 11 0c c1    	movsd  %xmm1,(%rcx,%r8,8)
    97f1:	4c 63 00             	movslq (%rax),%r8
    97f4:	45 85 c0             	test   %r8d,%r8d
    97f7:	78 10                	js     9809 <fwp_hof0.constprop.0+0x7c9>
    97f9:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    97fd:	f2 42 0f 58 04 c1    	addsd  (%rcx,%r8,8),%xmm0
    9803:	f2 42 0f 11 04 c1    	movsd  %xmm0,(%rcx,%r8,8)
    9809:	48 83 ea 08          	sub    $0x8,%rdx
    980d:	48 39 c7             	cmp    %rax,%rdi
    9810:	75 ae                	jne    97c0 <fwp_hof0.constprop.0+0x780>
    9812:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9819:	ff ff 1f 
    981c:	48 39 d8             	cmp    %rbx,%rax
    981f:	0f 82 00 10 00 00    	jb     a825 <fwp_hof0.constprop.0+0x17e5>
    9825:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    982c:	00 
    982d:	be 02 00 00 00       	mov    $0x2,%esi
    9832:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    9837:	e8 14 c2 ff ff       	call   5a50 <fwp_heap_alloc>
    983c:	48 85 db             	test   %rbx,%rbx
    983f:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9844:	48 89 18             	mov    %rbx,(%rax)
    9847:	49 89 c7             	mov    %rax,%r15
    984a:	74 26                	je     9872 <fwp_hof0.constprop.0+0x832>
    984c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9853:	00 00 
    9855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    985c:	00 00 00 00 
    9860:	4a 8b 04 f1          	mov    (%rcx,%r14,8),%rax
    9864:	4b 89 44 f7 08       	mov    %rax,0x8(%r15,%r14,8)
    9869:	49 83 c6 01          	add    $0x1,%r14
    986d:	4c 39 f3             	cmp    %r14,%rbx
    9870:	75 ee                	jne    9860 <fwp_hof0.constprop.0+0x820>
    9872:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
    9879:	00 
    987a:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    987f:	4c 89 25 72 ab 01 00 	mov    %r12,0x1ab72(%rip)        # 243f8 <fwp_cleanups>
    9886:	e8 a5 b5 ff ff       	call   4e30 <fwp_tape_buffers_release>
    988b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9892:	4c 89 f8             	mov    %r15,%rax
    9895:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    989c:	48 c1 e2 10          	shl    $0x10,%rdx
    98a0:	48 39 d0             	cmp    %rdx,%rax
    98a3:	73 57                	jae    98fc <fwp_hof0.constprop.0+0x8bc>
    98a5:	48 89 c2             	mov    %rax,%rdx
    98a8:	48 c1 ea 10          	shr    $0x10,%rdx
    98ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    98b0:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    98b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    98bb:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    98bf:	48 85 ed             	test   %rbp,%rbp
    98c2:	74 38                	je     98fc <fwp_hof0.constprop.0+0x8bc>
    98c4:	0f b6 0a             	movzbl (%rdx),%ecx
    98c7:	80 f9 02             	cmp    $0x2,%cl
    98ca:	0f 84 d0 0b 00 00    	je     a4a0 <fwp_hof0.constprop.0+0x1460>
    98d0:	80 f9 01             	cmp    $0x1,%cl
    98d3:	75 27                	jne    98fc <fwp_hof0.constprop.0+0x8bc>
    98d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98d8:	0f b7 c0             	movzwl %ax,%eax
    98db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98de:	48 0f af c1          	imul   %rcx,%rax
    98e2:	48 c1 e8 20          	shr    $0x20,%rax
    98e6:	48 39 d0             	cmp    %rdx,%rax
    98e9:	73 11                	jae    98fc <fwp_hof0.constprop.0+0x8bc>
    98eb:	48 01 c5             	add    %rax,%rbp
    98ee:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    98f2:	0f 84 bb 0b 00 00    	je     a4b3 <fwp_hof0.constprop.0+0x1473>
    98f8:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    98fc:	4c 3b 64 24 38       	cmp    0x38(%rsp),%r12
    9901:	0f 85 44 9e ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9907:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    990e:	00 
    990f:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9914:	48 89 05 dd aa 01 00 	mov    %rax,0x1aadd(%rip)        # 243f8 <fwp_cleanups>
    991b:	e8 60 d0 ff ff       	call   6980 <fwp_tape_scope_release>
    9920:	49 8b 07             	mov    (%r15),%rax
    9923:	49 89 c6             	mov    %rax,%r14
    9926:	49 0f ba f6 3f       	btr    $0x3f,%r14
    992b:	48 85 c0             	test   %rax,%rax
    992e:	0f 88 2c 08 00 00    	js     a160 <fwp_hof0.constprop.0+0x1120>
    9934:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    993b:	4c 89 f8             	mov    %r15,%rax
    993e:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9945:	48 c1 e2 10          	shl    $0x10,%rdx
    9949:	48 39 d0             	cmp    %rdx,%rax
    994c:	0f 83 0e 08 00 00    	jae    a160 <fwp_hof0.constprop.0+0x1120>
    9952:	48 89 c2             	mov    %rax,%rdx
    9955:	48 c1 ea 10          	shr    $0x10,%rdx
    9959:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    995d:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9964:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9968:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    996c:	48 85 c9             	test   %rcx,%rcx
    996f:	0f 84 eb 07 00 00    	je     a160 <fwp_hof0.constprop.0+0x1120>
    9975:	0f b6 32             	movzbl (%rdx),%esi
    9978:	40 80 fe 02          	cmp    $0x2,%sil
    997c:	0f 84 c6 07 00 00    	je     a148 <fwp_hof0.constprop.0+0x1108>
    9982:	40 80 fe 01          	cmp    $0x1,%sil
    9986:	0f 85 d4 07 00 00    	jne    a160 <fwp_hof0.constprop.0+0x1120>
    998c:	8b 72 18             	mov    0x18(%rdx),%esi
    998f:	0f b7 c0             	movzwl %ax,%eax
    9992:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9995:	48 0f af c6          	imul   %rsi,%rax
    9999:	48 c1 e8 20          	shr    $0x20,%rax
    999d:	48 39 d0             	cmp    %rdx,%rax
    99a0:	0f 83 ba 07 00 00    	jae    a160 <fwp_hof0.constprop.0+0x1120>
    99a6:	48 01 c1             	add    %rax,%rcx
    99a9:	80 39 01             	cmpb   $0x1,(%rcx)
    99ac:	0f 85 ae 07 00 00    	jne    a160 <fwp_hof0.constprop.0+0x1120>
    99b2:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    99b7:	4c 89 fd             	mov    %r15,%rbp
    99ba:	31 ff                	xor    %edi,%edi
    99bc:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    99c1:	48 8d 50 08          	lea    0x8(%rax),%rdx
    99c5:	31 c0                	xor    %eax,%eax
    99c7:	4d 85 f6             	test   %r14,%r14
    99ca:	75 2e                	jne    99fa <fwp_hof0.constprop.0+0x9ba>
    99cc:	eb 42                	jmp    9a10 <fwp_hof0.constprop.0+0x9d0>
    99ce:	66 90                	xchg   %ax,%ax
    99d0:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    99d5:	0f 88 2a 0e 00 00    	js     a805 <fwp_hof0.constprop.0+0x17c5>
    99db:	f2 0f 10 05 dd 50 00 	movsd  0x50dd(%rip),%xmm0        # eac0 <msg.4+0x40>
    99e2:	00 
    99e3:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    99e8:	48 83 c0 01          	add    $0x1,%rax
    99ec:	48 83 c2 08          	add    $0x8,%rdx
    99f0:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    99f5:	49 39 c6             	cmp    %rax,%r14
    99f8:	74 16                	je     9a10 <fwp_hof0.constprop.0+0x9d0>
    99fa:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    99fe:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9a02:	79 cc                	jns    99d0 <fwp_hof0.constprop.0+0x990>
    9a04:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    9a08:	eb c6                	jmp    99d0 <fwp_hof0.constprop.0+0x990>
    9a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a10:	e8 9b de ff ff       	call   78b0 <fwp_drop10>
    9a15:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    9a1a:	31 d2                	xor    %edx,%edx
    9a1c:	48 89 d8             	mov    %rbx,%rax
    9a1f:	48 85 db             	test   %rbx,%rbx
    9a22:	0f 84 11 0c 00 00    	je     a639 <fwp_hof0.constprop.0+0x15f9>
    9a28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a2f:	00 
    9a30:	48 8b 40 10          	mov    0x10(%rax),%rax
    9a34:	48 83 c2 01          	add    $0x1,%rdx
    9a38:	48 85 c0             	test   %rax,%rax
    9a3b:	75 f3                	jne    9a30 <fwp_hof0.constprop.0+0x9f0>
    9a3d:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9a41:	49 89 c7             	mov    %rax,%r15
    9a44:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9a49:	48 85 c0             	test   %rax,%rax
    9a4c:	0f 88 cb 05 00 00    	js     a01d <fwp_hof0.constprop.0+0xfdd>
    9a52:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    9a59:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9a5e:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    9a65:	48 c1 e0 10          	shl    $0x10,%rax
    9a69:	48 39 c1             	cmp    %rax,%rcx
    9a6c:	0f 83 ab 05 00 00    	jae    a01d <fwp_hof0.constprop.0+0xfdd>
    9a72:	48 89 c8             	mov    %rcx,%rax
    9a75:	48 c1 e8 10          	shr    $0x10,%rax
    9a79:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    9a7d:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    9a84:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9a88:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9a8c:	48 85 ff             	test   %rdi,%rdi
    9a8f:	0f 84 88 05 00 00    	je     a01d <fwp_hof0.constprop.0+0xfdd>
    9a95:	0f b6 06             	movzbl (%rsi),%eax
    9a98:	3c 02                	cmp    $0x2,%al
    9a9a:	0f 84 68 05 00 00    	je     a008 <fwp_hof0.constprop.0+0xfc8>
    9aa0:	3c 01                	cmp    $0x1,%al
    9aa2:	0f 85 69 05 00 00    	jne    a011 <fwp_hof0.constprop.0+0xfd1>
    9aa8:	8b 46 18             	mov    0x18(%rsi),%eax
    9aab:	0f b7 c9             	movzwl %cx,%ecx
    9aae:	48 0f af c8          	imul   %rax,%rcx
    9ab2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9ab5:	48 c1 e9 20          	shr    $0x20,%rcx
    9ab9:	48 39 c1             	cmp    %rax,%rcx
    9abc:	0f 83 4f 05 00 00    	jae    a011 <fwp_hof0.constprop.0+0xfd1>
    9ac2:	48 01 cf             	add    %rcx,%rdi
    9ac5:	80 3f 01             	cmpb   $0x1,(%rdi)
    9ac8:	0f 85 43 05 00 00    	jne    a011 <fwp_hof0.constprop.0+0xfd1>
    9ace:	4c 39 fa             	cmp    %r15,%rdx
    9ad1:	4c 89 f8             	mov    %r15,%rax
    9ad4:	48 0f 46 c2          	cmovbe %rdx,%rax
    9ad8:	48 85 c0             	test   %rax,%rax
    9adb:	0f 84 30 0d 00 00    	je     a811 <fwp_hof0.constprop.0+0x17d1>
    9ae1:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
    9ae8:	00 
    9ae9:	4c 8d 65 08          	lea    0x8(%rbp),%r12
    9aed:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    9af2:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9af7:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    9afe:	00 
    9aff:	31 d2                	xor    %edx,%edx
    9b01:	49 8d 78 08          	lea    0x8(%r8),%rdi
    9b05:	eb 56                	jmp    9b5d <fwp_hof0.constprop.0+0xb1d>
    9b07:	66 90                	xchg   %ax,%ax
    9b09:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b10:	00 00 00 00 
    9b14:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b1b:	00 00 00 00 
    9b1f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b26:	00 00 00 00 
    9b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b31:	00 00 00 00 
    9b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b3c:	00 00 00 00 
    9b40:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9b45:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    9b4a:	f2 41 0f 11 04 14    	movsd  %xmm0,(%r12,%rdx,1)
    9b50:	48 83 c2 08          	add    $0x8,%rdx
    9b54:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9b58:	49 39 d1             	cmp    %rdx,%r9
    9b5b:	74 13                	je     9b70 <fwp_hof0.constprop.0+0xb30>
    9b5d:	48 89 fe             	mov    %rdi,%rsi
    9b60:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9b65:	79 d9                	jns    9b40 <fwp_hof0.constprop.0+0xb00>
    9b67:	49 8b 70 10          	mov    0x10(%r8),%rsi
    9b6b:	eb d3                	jmp    9b40 <fwp_hof0.constprop.0+0xb00>
    9b6d:	0f 1f 00             	nopl   (%rax)
    9b70:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9b75:	48 85 c9             	test   %rcx,%rcx
    9b78:	0f 84 67 0c 00 00    	je     a7e5 <fwp_hof0.constprop.0+0x17a5>
    9b7e:	4d 8b 8d d8 13 00 00 	mov    0x13d8(%r13),%r9
    9b85:	4d 8b 95 b0 13 00 00 	mov    0x13b0(%r13),%r10
    9b8c:	45 31 ff             	xor    %r15d,%r15d
    9b8f:	4d 8b 9d f8 13 00 00 	mov    0x13f8(%r13),%r11
    9b96:	49 c1 e1 10          	shl    $0x10,%r9
    9b9a:	eb 1a                	jmp    9bb6 <fwp_hof0.constprop.0+0xb76>
    9b9c:	0f 1f 40 00          	nopl   0x0(%rax)
    9ba0:	49 83 c7 01          	add    $0x1,%r15
    9ba4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9ba8:	49 39 c7             	cmp    %rax,%r15
    9bab:	0f 83 5f 01 00 00    	jae    9d10 <fwp_hof0.constprop.0+0xcd0>
    9bb1:	48 85 c9             	test   %rcx,%rcx
    9bb4:	74 56                	je     9c0c <fwp_hof0.constprop.0+0xbcc>
    9bb6:	48 89 ca             	mov    %rcx,%rdx
    9bb9:	4c 29 d2             	sub    %r10,%rdx
    9bbc:	4c 39 ca             	cmp    %r9,%rdx
    9bbf:	73 4b                	jae    9c0c <fwp_hof0.constprop.0+0xbcc>
    9bc1:	48 89 d6             	mov    %rdx,%rsi
    9bc4:	48 c1 ee 10          	shr    $0x10,%rsi
    9bc8:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9bcc:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    9bd0:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9bd4:	48 85 ff             	test   %rdi,%rdi
    9bd7:	74 33                	je     9c0c <fwp_hof0.constprop.0+0xbcc>
    9bd9:	44 0f b6 06          	movzbl (%rsi),%r8d
    9bdd:	41 80 f8 02          	cmp    $0x2,%r8b
    9be1:	0f 84 11 01 00 00    	je     9cf8 <fwp_hof0.constprop.0+0xcb8>
    9be7:	41 80 f8 01          	cmp    $0x1,%r8b
    9beb:	75 1f                	jne    9c0c <fwp_hof0.constprop.0+0xbcc>
    9bed:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9bf1:	0f b7 d2             	movzwl %dx,%edx
    9bf4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9bf7:	49 0f af d0          	imul   %r8,%rdx
    9bfb:	48 c1 ea 20          	shr    $0x20,%rdx
    9bff:	48 39 f2             	cmp    %rsi,%rdx
    9c02:	73 08                	jae    9c0c <fwp_hof0.constprop.0+0xbcc>
    9c04:	48 01 d7             	add    %rdx,%rdi
    9c07:	80 3f 01             	cmpb   $0x1,(%rdi)
    9c0a:	74 94                	je     9ba0 <fwp_hof0.constprop.0+0xb60>
    9c0c:	49 39 c7             	cmp    %rax,%r15
    9c0f:	0f 83 fb 00 00 00    	jae    9d10 <fwp_hof0.constprop.0+0xcd0>
    9c15:	48 89 c3             	mov    %rax,%rbx
    9c18:	45 31 f6             	xor    %r14d,%r14d
    9c1b:	48 8d ac 24 10 01 00 	lea    0x110(%rsp),%rbp
    9c22:	00 
    9c23:	eb 37                	jmp    9c5c <fwp_hof0.constprop.0+0xc1c>
    9c25:	0f 1f 00             	nopl   (%rax)
    9c28:	40 80 fe 01          	cmp    $0x1,%sil
    9c2c:	75 25                	jne    9c53 <fwp_hof0.constprop.0+0xc13>
    9c2e:	8b 71 18             	mov    0x18(%rcx),%esi
    9c31:	0f b7 c0             	movzwl %ax,%eax
    9c34:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9c37:	48 0f af c6          	imul   %rsi,%rax
    9c3b:	48 c1 e8 20          	shr    $0x20,%rax
    9c3f:	48 39 c8             	cmp    %rcx,%rax
    9c42:	73 0f                	jae    9c53 <fwp_hof0.constprop.0+0xc13>
    9c44:	48 01 c2             	add    %rax,%rdx
    9c47:	80 3a ff             	cmpb   $0xff,(%rdx)
    9c4a:	0f 84 c0 05 00 00    	je     a210 <fwp_hof0.constprop.0+0x11d0>
    9c50:	c6 02 01             	movb   $0x1,(%rdx)
    9c53:	49 39 df             	cmp    %rbx,%r15
    9c56:	0f 83 84 00 00 00    	jae    9ce0 <fwp_hof0.constprop.0+0xca0>
    9c5c:	48 83 eb 01          	sub    $0x1,%rbx
    9c60:	66 49 0f 6e f6       	movq   %r14,%xmm6
    9c65:	48 89 ee             	mov    %rbp,%rsi
    9c68:	bf 01 00 00 00       	mov    $0x1,%edi
    9c6d:	f3 41 0f 7e 04 dc    	movq   (%r12,%rbx,8),%xmm0
    9c73:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9c77:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
    9c7e:	00 
    9c7f:	e8 ec be ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9c84:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9c8b:	49 89 c6             	mov    %rax,%r14
    9c8e:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9c95:	48 c1 e2 10          	shl    $0x10,%rdx
    9c99:	48 39 d0             	cmp    %rdx,%rax
    9c9c:	73 b5                	jae    9c53 <fwp_hof0.constprop.0+0xc13>
    9c9e:	48 89 c2             	mov    %rax,%rdx
    9ca1:	48 c1 ea 10          	shr    $0x10,%rdx
    9ca5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ca9:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9cb0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9cb4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9cb8:	48 85 d2             	test   %rdx,%rdx
    9cbb:	74 96                	je     9c53 <fwp_hof0.constprop.0+0xc13>
    9cbd:	0f b6 31             	movzbl (%rcx),%esi
    9cc0:	40 80 fe 02          	cmp    $0x2,%sil
    9cc4:	0f 85 5e ff ff ff    	jne    9c28 <fwp_hof0.constprop.0+0xbe8>
    9cca:	66 85 c0             	test   %ax,%ax
    9ccd:	0f 84 74 ff ff ff    	je     9c47 <fwp_hof0.constprop.0+0xc07>
    9cd3:	49 39 df             	cmp    %rbx,%r15
    9cd6:	72 84                	jb     9c5c <fwp_hof0.constprop.0+0xc1c>
    9cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9cdf:	00 
    9ce0:	4d 85 ff             	test   %r15,%r15
    9ce3:	75 2e                	jne    9d13 <fwp_hof0.constprop.0+0xcd3>
    9ce5:	8b 44 24 30          	mov    0x30(%rsp),%eax
    9ce9:	85 c0                	test   %eax,%eax
    9ceb:	4d 0f 45 e7          	cmovne %r15,%r12
    9cef:	eb 63                	jmp    9d54 <fwp_hof0.constprop.0+0xd14>
    9cf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9cf8:	66 85 d2             	test   %dx,%dx
    9cfb:	0f 84 06 ff ff ff    	je     9c07 <fwp_hof0.constprop.0+0xbc7>
    9d01:	49 39 c7             	cmp    %rax,%r15
    9d04:	0f 82 0b ff ff ff    	jb     9c15 <fwp_hof0.constprop.0+0xbd5>
    9d0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9d10:	45 31 f6             	xor    %r14d,%r14d
    9d13:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9d18:	4c 89 e2             	mov    %r12,%rdx
    9d1b:	4f 8d 0c fc          	lea    (%r12,%r15,8),%r9
    9d1f:	90                   	nop
    9d20:	48 8b 0a             	mov    (%rdx),%rcx
    9d23:	48 83 c2 08          	add    $0x8,%rdx
    9d27:	48 89 c7             	mov    %rax,%rdi
    9d2a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    9d2e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9d32:	4c 39 ca             	cmp    %r9,%rdx
    9d35:	75 e9                	jne    9d20 <fwp_hof0.constprop.0+0xce0>
    9d37:	8b 54 24 30          	mov    0x30(%rsp),%edx
    9d3b:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    9d3f:	85 d2                	test   %edx,%edx
    9d41:	0f 84 79 07 00 00    	je     a4c0 <fwp_hof0.constprop.0+0x1480>
    9d47:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    9d4c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9d51:	45 31 e4             	xor    %r12d,%r12d
    9d54:	4c 89 e7             	mov    %r12,%rdi
    9d57:	e8 f4 b7 ff ff       	call   5550 <fwp_mem_free>
    9d5c:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    9d61:	e8 4a db ff ff       	call   78b0 <fwp_drop10>
    9d66:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9d6d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9d72:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9d79:	48 c1 e2 10          	shl    $0x10,%rdx
    9d7d:	48 39 d0             	cmp    %rdx,%rax
    9d80:	73 6e                	jae    9df0 <fwp_hof0.constprop.0+0xdb0>
    9d82:	48 89 c2             	mov    %rax,%rdx
    9d85:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    9d8c:	48 c1 ea 10          	shr    $0x10,%rdx
    9d90:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    9d94:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    9d98:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9d9c:	48 85 ed             	test   %rbp,%rbp
    9d9f:	74 4f                	je     9df0 <fwp_hof0.constprop.0+0xdb0>
    9da1:	0f b6 0a             	movzbl (%rdx),%ecx
    9da4:	80 f9 02             	cmp    $0x2,%cl
    9da7:	0f 84 a3 06 00 00    	je     a450 <fwp_hof0.constprop.0+0x1410>
    9dad:	80 f9 01             	cmp    $0x1,%cl
    9db0:	75 3e                	jne    9df0 <fwp_hof0.constprop.0+0xdb0>
    9db2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9db5:	0f b7 c0             	movzwl %ax,%eax
    9db8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9dbb:	48 0f af c1          	imul   %rcx,%rax
    9dbf:	48 c1 e8 20          	shr    $0x20,%rax
    9dc3:	48 39 d0             	cmp    %rdx,%rax
    9dc6:	73 28                	jae    9df0 <fwp_hof0.constprop.0+0xdb0>
    9dc8:	48 01 c5             	add    %rax,%rbp
    9dcb:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    9dcf:	84 c0                	test   %al,%al
    9dd1:	74 1d                	je     9df0 <fwp_hof0.constprop.0+0xdb0>
    9dd3:	3c 01                	cmp    $0x1,%al
    9dd5:	0f 84 f5 06 00 00    	je     a4d0 <fwp_hof0.constprop.0+0x1490>
    9ddb:	3c ff                	cmp    $0xff,%al
    9ddd:	0f 84 d1 08 00 00    	je     a6b4 <fwp_hof0.constprop.0+0x1674>
    9de3:	83 e8 01             	sub    $0x1,%eax
    9de6:	88 45 00             	mov    %al,0x0(%rbp)
    9de9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9df0:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    9df6:	0f 85 04 05 00 00    	jne    a300 <fwp_hof0.constprop.0+0x12c0>
    9dfc:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    9e01:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9e05:	4c 89 f6             	mov    %r14,%rsi
    9e08:	4c 89 f5             	mov    %r14,%rbp
    9e0b:	b9 01 00 00 00       	mov    $0x1,%ecx
    9e10:	48 8d 15 89 7d 00 00 	lea    0x7d89(%rip),%rdx        # 11ba0 <d0>
    9e17:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    9e1e:	00 00 00 00 00 
    9e23:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    9e2a:	00 
    9e2b:	e8 d0 e1 ff ff       	call   8000 <fwp_write>
    9e30:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
    9e37:	00 
    9e38:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    9e3f:	00 
    9e40:	48 8d 05 e7 41 00 00 	lea    0x41e7(%rip),%rax        # e02e <_IO_stdin_used+0x2e>
    9e47:	48 85 c9             	test   %rcx,%rcx
    9e4a:	48 0f 44 c8          	cmove  %rax,%rcx
    9e4e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    9e52:	0f 87 8f 0a 00 00    	ja     a8e7 <fwp_hof0.constprop.0+0x18a7>
    9e58:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    9e5c:	be 01 00 00 00       	mov    $0x1,%esi
    9e61:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9e66:	e8 e5 bb ff ff       	call   5a50 <fwp_heap_alloc>
    9e6b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9e70:	4c 89 fa             	mov    %r15,%rdx
    9e73:	4c 89 38             	mov    %r15,(%rax)
    9e76:	4c 8d 60 08          	lea    0x8(%rax),%r12
    9e7a:	48 89 c3             	mov    %rax,%rbx
    9e7d:	4c 89 e7             	mov    %r12,%rdi
    9e80:	e8 1b 97 ff ff       	call   35a0 <memcpy@plt>
    9e85:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    9e8b:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    9e92:	00 
    9e93:	e8 28 95 ff ff       	call   33c0 <free@plt>
    9e98:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9e9f:	48 89 d8             	mov    %rbx,%rax
    9ea2:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9ea9:	48 c1 e2 10          	shl    $0x10,%rdx
    9ead:	48 39 d0             	cmp    %rdx,%rax
    9eb0:	73 57                	jae    9f09 <fwp_hof0.constprop.0+0xec9>
    9eb2:	48 89 c2             	mov    %rax,%rdx
    9eb5:	48 c1 ea 10          	shr    $0x10,%rdx
    9eb9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ebd:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9ec4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ec8:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9ecc:	4d 85 ff             	test   %r15,%r15
    9ecf:	74 38                	je     9f09 <fwp_hof0.constprop.0+0xec9>
    9ed1:	0f b6 0a             	movzbl (%rdx),%ecx
    9ed4:	80 f9 02             	cmp    $0x2,%cl
    9ed7:	0f 84 33 07 00 00    	je     a610 <fwp_hof0.constprop.0+0x15d0>
    9edd:	80 f9 01             	cmp    $0x1,%cl
    9ee0:	75 27                	jne    9f09 <fwp_hof0.constprop.0+0xec9>
    9ee2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ee5:	0f b7 c0             	movzwl %ax,%eax
    9ee8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9eeb:	48 0f af c1          	imul   %rcx,%rax
    9eef:	48 c1 e8 20          	shr    $0x20,%rax
    9ef3:	48 39 d0             	cmp    %rdx,%rax
    9ef6:	73 11                	jae    9f09 <fwp_hof0.constprop.0+0xec9>
    9ef8:	49 01 c7             	add    %rax,%r15
    9efb:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9eff:	0f 84 1e 07 00 00    	je     a623 <fwp_hof0.constprop.0+0x15e3>
    9f05:	41 c6 07 01          	movb   $0x1,(%r15)
    9f09:	48 89 ef             	mov    %rbp,%rdi
    9f0c:	e8 af d5 ff ff       	call   74c0 <fwp_drop0>
    9f11:	48 8b 13             	mov    (%rbx),%rdx
    9f14:	be 01 00 00 00       	mov    $0x1,%esi
    9f19:	4c 89 e7             	mov    %r12,%rdi
    9f1c:	48 8b 0d 9d a4 01 00 	mov    0x1a49d(%rip),%rcx        # 243c0 <fwp_prog_out>
    9f23:	e8 58 97 ff ff       	call   3680 <fwrite@plt>
    9f28:	48 8b 35 91 a4 01 00 	mov    0x1a491(%rip),%rsi        # 243c0 <fwp_prog_out>
    9f2f:	bf 0a 00 00 00       	mov    $0xa,%edi
    9f34:	e8 a7 95 ff ff       	call   34e0 <fputc@plt>
    9f39:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9f40:	48 89 d8             	mov    %rbx,%rax
    9f43:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9f4a:	48 c1 e2 10          	shl    $0x10,%rdx
    9f4e:	48 39 d0             	cmp    %rdx,%rax
    9f51:	73 6d                	jae    9fc0 <fwp_hof0.constprop.0+0xf80>
    9f53:	48 89 c2             	mov    %rax,%rdx
    9f56:	48 c1 ea 10          	shr    $0x10,%rdx
    9f5a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f5e:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9f65:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f69:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9f6d:	48 85 ed             	test   %rbp,%rbp
    9f70:	74 4e                	je     9fc0 <fwp_hof0.constprop.0+0xf80>
    9f72:	0f b6 0a             	movzbl (%rdx),%ecx
    9f75:	80 f9 02             	cmp    $0x2,%cl
    9f78:	0f 84 62 06 00 00    	je     a5e0 <fwp_hof0.constprop.0+0x15a0>
    9f7e:	80 f9 01             	cmp    $0x1,%cl
    9f81:	75 3d                	jne    9fc0 <fwp_hof0.constprop.0+0xf80>
    9f83:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f86:	0f b7 c0             	movzwl %ax,%eax
    9f89:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f8c:	48 0f af c1          	imul   %rcx,%rax
    9f90:	48 c1 e8 20          	shr    $0x20,%rax
    9f94:	48 39 d0             	cmp    %rdx,%rax
    9f97:	73 27                	jae    9fc0 <fwp_hof0.constprop.0+0xf80>
    9f99:	48 01 c5             	add    %rax,%rbp
    9f9c:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    9fa0:	84 c0                	test   %al,%al
    9fa2:	74 1c                	je     9fc0 <fwp_hof0.constprop.0+0xf80>
    9fa4:	3c 01                	cmp    $0x1,%al
    9fa6:	0f 84 51 06 00 00    	je     a5fd <fwp_hof0.constprop.0+0x15bd>
    9fac:	3c ff                	cmp    $0xff,%al
    9fae:	0f 84 71 07 00 00    	je     a725 <fwp_hof0.constprop.0+0x16e5>
    9fb4:	83 e8 01             	sub    $0x1,%eax
    9fb7:	88 45 00             	mov    %al,0x0(%rbp)
    9fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9fc0:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    9fc5:	48 8b 40 10          	mov    0x10(%rax),%rax
    9fc9:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    9fce:	48 85 c0             	test   %rax,%rax
    9fd1:	0f 85 a9 f0 ff ff    	jne    9080 <fwp_hof0.constprop.0+0x40>
    9fd7:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    9fde:	00 
    9fdf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9fe6:	00 00 
    9fe8:	0f 85 f4 08 00 00    	jne    a8e2 <fwp_hof0.constprop.0+0x18a2>
    9fee:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
    9ff5:	31 c0                	xor    %eax,%eax
    9ff7:	5b                   	pop    %rbx
    9ff8:	5d                   	pop    %rbp
    9ff9:	41 5c                	pop    %r12
    9ffb:	41 5d                	pop    %r13
    9ffd:	41 5e                	pop    %r14
    9fff:	41 5f                	pop    %r15
    a001:	c3                   	ret
    a002:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a008:	66 85 c9             	test   %cx,%cx
    a00b:	0f 84 b4 fa ff ff    	je     9ac5 <fwp_hof0.constprop.0+0xa85>
    a011:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    a017:	0f 84 a6 02 00 00    	je     a2c3 <fwp_hof0.constprop.0+0x1283>
    a01d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a022:	45 31 f6             	xor    %r14d,%r14d
    a025:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a02c:	00 00 00 00 
    a030:	48 8b 40 10          	mov    0x10(%rax),%rax
    a034:	4c 89 f2             	mov    %r14,%rdx
    a037:	49 83 c6 01          	add    $0x1,%r14
    a03b:	48 85 c0             	test   %rax,%rax
    a03e:	75 f0                	jne    a030 <fwp_hof0.constprop.0+0xff0>
    a040:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a047:	ff ff 1f 
    a04a:	4c 39 f0             	cmp    %r14,%rax
    a04d:	0f 82 de 07 00 00    	jb     a831 <fwp_hof0.constprop.0+0x17f1>
    a053:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a05a:	00 
    a05b:	be 02 00 00 00       	mov    $0x2,%esi
    a060:	e8 eb b9 ff ff       	call   5a50 <fwp_heap_alloc>
    a065:	4d 39 f7             	cmp    %r14,%r15
    a068:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a06d:	49 89 c4             	mov    %rax,%r12
    a070:	4c 89 f0             	mov    %r14,%rax
    a073:	49 0f 46 c7          	cmovbe %r15,%rax
    a077:	4c 89 e1             	mov    %r12,%rcx
    a07a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a080:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a084:	48 83 c1 08          	add    $0x8,%rcx
    a088:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a08c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a090:	48 85 d2             	test   %rdx,%rdx
    a093:	75 eb                	jne    a080 <fwp_hof0.constprop.0+0x1040>
    a095:	48 85 c0             	test   %rax,%rax
    a098:	0f 84 37 02 00 00    	je     a2d5 <fwp_hof0.constprop.0+0x1295>
    a09e:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    a0a5:	00 
    a0a6:	e9 42 fa ff ff       	jmp    9aed <fwp_hof0.constprop.0+0xaad>
    a0ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a0b0:	4c 39 fd             	cmp    %r15,%rbp
    a0b3:	0f 84 c7 f1 ff ff    	je     9280 <fwp_hof0.constprop.0+0x240>
    a0b9:	48 8b 1d 30 80 01 00 	mov    0x18030(%rip),%rbx        # 220f0 <fwp_tapes>
    a0c0:	e9 5e f2 ff ff       	jmp    9323 <fwp_hof0.constprop.0+0x2e3>
    a0c5:	0f 1f 00             	nopl   (%rax)
    a0c8:	48 83 3d b8 7f 01 00 	cmpq   $0x0,0x17fb8(%rip)        # 22088 <fwp_tape_cached_bytes>
    a0cf:	00 
    a0d0:	0f 84 93 f2 ff ff    	je     9369 <fwp_hof0.constprop.0+0x329>
    a0d6:	66 0f 6f 0d c2 7f 01 	movdqa 0x17fc2(%rip),%xmm1        # 220a0 <fwp_tape_workspace>
    a0dd:	00 
    a0de:	48 c7 05 9f 7f 01 00 	movq   $0x0,0x17f9f(%rip)        # 22088 <fwp_tape_cached_bytes>
    a0e5:	00 00 00 00 
    a0e9:	0f 11 4d 20          	movups %xmm1,0x20(%rbp)
    a0ed:	48 8b 05 cc 7f 01 00 	mov    0x17fcc(%rip),%rax        # 220c0 <fwp_tape_workspace+0x20>
    a0f4:	66 0f 6f 0d b4 7f 01 	movdqa 0x17fb4(%rip),%xmm1        # 220b0 <fwp_tape_workspace+0x10>
    a0fb:	00 
    a0fc:	48 89 45 40          	mov    %rax,0x40(%rbp)
    a100:	48 8b 05 c1 7f 01 00 	mov    0x17fc1(%rip),%rax        # 220c8 <fwp_tape_workspace+0x28>
    a107:	0f 11 4d 30          	movups %xmm1,0x30(%rbp)
    a10b:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a10f:	48 89 45 18          	mov    %rax,0x18(%rbp)
    a113:	48 8b 05 b6 7f 01 00 	mov    0x17fb6(%rip),%rax        # 220d0 <fwp_tape_workspace+0x30>
    a11a:	0f 29 0d 7f 7f 01 00 	movaps %xmm1,0x17f7f(%rip)        # 220a0 <fwp_tape_workspace>
    a121:	48 89 45 48          	mov    %rax,0x48(%rbp)
    a125:	0f 29 0d 84 7f 01 00 	movaps %xmm1,0x17f84(%rip)        # 220b0 <fwp_tape_workspace+0x10>
    a12c:	48 c7 05 99 7f 01 00 	movq   $0x0,0x17f99(%rip)        # 220d0 <fwp_tape_workspace+0x30>
    a133:	00 00 00 00 
    a137:	0f 29 0d 82 7f 01 00 	movaps %xmm1,0x17f82(%rip)        # 220c0 <fwp_tape_workspace+0x20>
    a13e:	e9 26 f2 ff ff       	jmp    9369 <fwp_hof0.constprop.0+0x329>
    a143:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a148:	66 85 c0             	test   %ax,%ax
    a14b:	0f 84 58 f8 ff ff    	je     99a9 <fwp_hof0.constprop.0+0x969>
    a151:	0f 1f 40 00          	nopl   0x0(%rax)
    a155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a15c:	00 00 00 00 
    a160:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a167:	ff ff 1f 
    a16a:	4c 39 f0             	cmp    %r14,%rax
    a16d:	0f 82 b2 06 00 00    	jb     a825 <fwp_hof0.constprop.0+0x17e5>
    a173:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a17a:	00 
    a17b:	be 01 00 00 00       	mov    $0x1,%esi
    a180:	e8 cb b8 ff ff       	call   5a50 <fwp_heap_alloc>
    a185:	4c 89 30             	mov    %r14,(%rax)
    a188:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a18f:	48 89 c5             	mov    %rax,%rbp
    a192:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a197:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a19e:	48 c1 e2 10          	shl    $0x10,%rdx
    a1a2:	48 39 d0             	cmp    %rdx,%rax
    a1a5:	73 57                	jae    a1fe <fwp_hof0.constprop.0+0x11be>
    a1a7:	48 89 c2             	mov    %rax,%rdx
    a1aa:	48 c1 ea 10          	shr    $0x10,%rdx
    a1ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a1b2:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a1b9:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a1bd:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    a1c1:	48 85 db             	test   %rbx,%rbx
    a1c4:	74 38                	je     a1fe <fwp_hof0.constprop.0+0x11be>
    a1c6:	0f b6 31             	movzbl (%rcx),%esi
    a1c9:	40 80 fe 02          	cmp    $0x2,%sil
    a1cd:	0f 84 a5 03 00 00    	je     a578 <fwp_hof0.constprop.0+0x1538>
    a1d3:	40 80 fe 01          	cmp    $0x1,%sil
    a1d7:	75 25                	jne    a1fe <fwp_hof0.constprop.0+0x11be>
    a1d9:	8b 71 18             	mov    0x18(%rcx),%esi
    a1dc:	0f b7 c0             	movzwl %ax,%eax
    a1df:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a1e2:	48 0f af c6          	imul   %rsi,%rax
    a1e6:	48 c1 e8 20          	shr    $0x20,%rax
    a1ea:	48 39 c8             	cmp    %rcx,%rax
    a1ed:	73 0f                	jae    a1fe <fwp_hof0.constprop.0+0x11be>
    a1ef:	48 01 c3             	add    %rax,%rbx
    a1f2:	80 3b ff             	cmpb   $0xff,(%rbx)
    a1f5:	0f 84 8f 03 00 00    	je     a58a <fwp_hof0.constprop.0+0x154a>
    a1fb:	c6 03 01             	movb   $0x1,(%rbx)
    a1fe:	4c 89 ff             	mov    %r15,%rdi
    a201:	e9 b6 f7 ff ff       	jmp    99bc <fwp_hof0.constprop.0+0x97c>
    a206:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a20d:	00 00 00 
    a210:	48 89 d7             	mov    %rdx,%rdi
    a213:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    a218:	e8 f3 b0 ff ff       	call   5310 <fwp_rc_forget_slot>
    a21d:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    a222:	e9 29 fa ff ff       	jmp    9c50 <fwp_hof0.constprop.0+0xc10>
    a227:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a22e:	00 00 
    a230:	48 c1 e1 10          	shl    $0x10,%rcx
    a234:	bf 08 00 00 00       	mov    $0x8,%edi
    a239:	48 09 f1             	or     %rsi,%rcx
    a23c:	be 02 00 00 00       	mov    $0x2,%esi
    a241:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a246:	e8 05 b8 ff ff       	call   5a50 <fwp_heap_alloc>
    a24b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a252:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a259:	48 89 c5             	mov    %rax,%rbp
    a25c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a263:	48 c1 e2 10          	shl    $0x10,%rdx
    a267:	48 39 d0             	cmp    %rdx,%rax
    a26a:	0f 83 80 00 00 00    	jae    a2f0 <fwp_hof0.constprop.0+0x12b0>
    a270:	48 89 c2             	mov    %rax,%rdx
    a273:	48 c1 ea 10          	shr    $0x10,%rdx
    a277:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a27b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a282:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a286:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a28a:	4d 85 ff             	test   %r15,%r15
    a28d:	0f 84 e0 f2 ff ff    	je     9573 <fwp_hof0.constprop.0+0x533>
    a293:	0f b6 32             	movzbl (%rdx),%esi
    a296:	45 31 e4             	xor    %r12d,%r12d
    a299:	40 80 fe 02          	cmp    $0x2,%sil
    a29d:	0f 85 29 f2 ff ff    	jne    94cc <fwp_hof0.constprop.0+0x48c>
    a2a3:	66 85 c0             	test   %ax,%ax
    a2a6:	0f 85 4d f2 ff ff    	jne    94f9 <fwp_hof0.constprop.0+0x4b9>
    a2ac:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a2b0:	0f 85 3f f2 ff ff    	jne    94f5 <fwp_hof0.constprop.0+0x4b5>
    a2b6:	4c 89 ff             	mov    %r15,%rdi
    a2b9:	e8 52 b0 ff ff       	call   5310 <fwp_rc_forget_slot>
    a2be:	e9 32 f2 ff ff       	jmp    94f5 <fwp_hof0.constprop.0+0x4b5>
    a2c3:	be 02 00 00 00       	mov    $0x2,%esi
    a2c8:	bf 08 00 00 00       	mov    $0x8,%edi
    a2cd:	e8 7e b7 ff ff       	call   5a50 <fwp_heap_alloc>
    a2d2:	49 89 c4             	mov    %rax,%r12
    a2d5:	45 31 f6             	xor    %r14d,%r14d
    a2d8:	e9 77 fa ff ff       	jmp    9d54 <fwp_hof0.constprop.0+0xd14>
    a2dd:	0f 1f 00             	nopl   (%rax)
    a2e0:	4d 85 e4             	test   %r12,%r12
    a2e3:	0f 85 15 f2 ff ff    	jne    94fe <fwp_hof0.constprop.0+0x4be>
    a2e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a2f0:	31 db                	xor    %ebx,%ebx
    a2f2:	e9 e7 f2 ff ff       	jmp    95de <fwp_hof0.constprop.0+0x59e>
    a2f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2fe:	00 00 
    a300:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    a305:	45 31 c0             	xor    %r8d,%r8d
    a308:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a30d:	48 83 e8 01          	sub    $0x1,%rax
    a311:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    a316:	41 0f 90 c0          	seto   %r8b
    a31a:	e9 f0 ed ff ff       	jmp    910f <fwp_hof0.constprop.0+0xcf>
    a31f:	90                   	nop
    a320:	4d 8d 57 01          	lea    0x1(%r15),%r10
    a324:	4c 39 d2             	cmp    %r10,%rdx
    a327:	7c 42                	jl     a36b <fwp_hof0.constprop.0+0x132b>
    a329:	48 85 c9             	test   %rcx,%rcx
    a32c:	0f 84 23 05 00 00    	je     a855 <fwp_hof0.constprop.0+0x1815>
    a332:	48 89 cf             	mov    %rcx,%rdi
    a335:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    a33c:	00 
    a33d:	31 f6                	xor    %esi,%esi
    a33f:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    a344:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a349:	e8 72 91 ff ff       	call   34c0 <memset@plt>
    a34e:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    a354:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a35a:	48 89 c1             	mov    %rax,%rcx
    a35d:	e9 03 f4 ff ff       	jmp    9765 <fwp_hof0.constprop.0+0x725>
    a362:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a368:	49 89 da             	mov    %rbx,%r10
    a36b:	48 85 d2             	test   %rdx,%rdx
    a36e:	49 0f 44 d2          	cmove  %r10,%rdx
    a372:	eb 21                	jmp    a395 <fwp_hof0.constprop.0+0x1355>
    a374:	90                   	nop
    a375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a37c:	00 00 00 00 
    a380:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    a384:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    a38b:	4c 89 d0             	mov    %r10,%rax
    a38e:	48 0f 4c c6          	cmovl  %rsi,%rax
    a392:	48 89 c2             	mov    %rax,%rdx
    a395:	4c 39 d2             	cmp    %r10,%rdx
    a398:	7c e6                	jl     a380 <fwp_hof0.constprop.0+0x1340>
    a39a:	4c 89 54 24 50       	mov    %r10,0x50(%rsp)
    a39f:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    a3a4:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    a3a9:	48 85 c9             	test   %rcx,%rcx
    a3ac:	0f 84 ee 01 00 00    	je     a5a0 <fwp_hof0.constprop.0+0x1560>
    a3b2:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    a3b9:	00 
    a3ba:	48 89 cf             	mov    %rcx,%rdi
    a3bd:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a3c2:	e8 09 92 ff ff       	call   35d0 <realloc@plt>
    a3c7:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a3cc:	4c 8b 54 24 50       	mov    0x50(%rsp),%r10
    a3d1:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    a3d7:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    a3dd:	48 89 c1             	mov    %rax,%rcx
    a3e0:	48 85 c9             	test   %rcx,%rcx
    a3e3:	0f 84 63 04 00 00    	je     a84c <fwp_hof0.constprop.0+0x180c>
    a3e9:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    a3f0:	00 
    a3f1:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
    a3f8:	00 
    a3f9:	4d 85 d2             	test   %r10,%r10
    a3fc:	0f 85 56 03 00 00    	jne    a758 <fwp_hof0.constprop.0+0x1718>
    a402:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    a409:	4d 85 e4             	test   %r12,%r12
    a40c:	0f 88 67 f3 ff ff    	js     9779 <fwp_hof0.constprop.0+0x739>
    a412:	45 89 e7             	mov    %r12d,%r15d
    a415:	e9 4b f3 ff ff       	jmp    9765 <fwp_hof0.constprop.0+0x725>
    a41a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a420:	48 8d 3d 79 c4 ff ff 	lea    -0x3b87(%rip),%rdi        # 68a0 <fwp_tape_finish>
    a427:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    a42d:	e8 0e 3b 00 00       	call   df40 <atexit>
    a432:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    a438:	85 c0                	test   %eax,%eax
    a43a:	0f 85 b3 04 00 00    	jne    a8f3 <fwp_hof0.constprop.0+0x18b3>
    a440:	c7 05 16 7c 00 00 01 	movl   $0x1,0x7c16(%rip)        # 12060 <registered_finish.1>
    a447:	00 00 00 
    a44a:	e9 ee ed ff ff       	jmp    923d <fwp_hof0.constprop.0+0x1fd>
    a44f:	90                   	nop
    a450:	66 85 c0             	test   %ax,%ax
    a453:	0f 85 97 f9 ff ff    	jne    9df0 <fwp_hof0.constprop.0+0xdb0>
    a459:	e9 6d f9 ff ff       	jmp    9dcb <fwp_hof0.constprop.0+0xd8b>
    a45e:	66 90                	xchg   %ax,%ax
    a460:	66 85 c0             	test   %ax,%ax
    a463:	0f 85 7f ed ff ff    	jne    91e8 <fwp_hof0.constprop.0+0x1a8>
    a469:	e9 66 ed ff ff       	jmp    91d4 <fwp_hof0.constprop.0+0x194>
    a46e:	66 90                	xchg   %ax,%ax
    a470:	48 39 d3             	cmp    %rdx,%rbx
    a473:	0f 8f ef fe ff ff    	jg     a368 <fwp_hof0.constprop.0+0x1328>
    a479:	48 85 db             	test   %rbx,%rbx
    a47c:	74 12                	je     a490 <fwp_hof0.constprop.0+0x1450>
    a47e:	48 85 c9             	test   %rcx,%rcx
    a481:	0f 84 ce 03 00 00    	je     a855 <fwp_hof0.constprop.0+0x1815>
    a487:	48 85 db             	test   %rbx,%rbx
    a48a:	0f 85 c5 02 00 00    	jne    a755 <fwp_hof0.constprop.0+0x1715>
    a490:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    a497:	e9 dd f2 ff ff       	jmp    9779 <fwp_hof0.constprop.0+0x739>
    a49c:	0f 1f 40 00          	nopl   0x0(%rax)
    a4a0:	66 85 c0             	test   %ax,%ax
    a4a3:	0f 85 53 f4 ff ff    	jne    98fc <fwp_hof0.constprop.0+0x8bc>
    a4a9:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a4ad:	0f 85 45 f4 ff ff    	jne    98f8 <fwp_hof0.constprop.0+0x8b8>
    a4b3:	48 89 ef             	mov    %rbp,%rdi
    a4b6:	e8 55 ae ff ff       	call   5310 <fwp_rc_forget_slot>
    a4bb:	e9 38 f4 ff ff       	jmp    98f8 <fwp_hof0.constprop.0+0x8b8>
    a4c0:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    a4c5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a4ca:	e9 85 f8 ff ff       	jmp    9d54 <fwp_hof0.constprop.0+0xd14>
    a4cf:	90                   	nop
    a4d0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a4d5:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a4dc:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a4e3:	48 8b 58 10          	mov    0x10(%rax),%rbx
    a4e7:	48 29 c8             	sub    %rcx,%rax
    a4ea:	48 c1 e2 10          	shl    $0x10,%rdx
    a4ee:	48 39 d0             	cmp    %rdx,%rax
    a4f1:	73 67                	jae    a55a <fwp_hof0.constprop.0+0x151a>
    a4f3:	48 89 c7             	mov    %rax,%rdi
    a4f6:	48 c1 ef 10          	shr    $0x10,%rdi
    a4fa:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    a4fe:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a502:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a506:	48 85 ff             	test   %rdi,%rdi
    a509:	74 4f                	je     a55a <fwp_hof0.constprop.0+0x151a>
    a50b:	44 0f b6 06          	movzbl (%rsi),%r8d
    a50f:	41 80 f8 02          	cmp    $0x2,%r8b
    a513:	0f 84 8d 01 00 00    	je     a6a6 <fwp_hof0.constprop.0+0x1666>
    a519:	41 80 f8 01          	cmp    $0x1,%r8b
    a51d:	75 3b                	jne    a55a <fwp_hof0.constprop.0+0x151a>
    a51f:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a523:	0f b7 c0             	movzwl %ax,%eax
    a526:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a529:	49 0f af c0          	imul   %r8,%rax
    a52d:	48 c1 e8 20          	shr    $0x20,%rax
    a531:	48 39 f0             	cmp    %rsi,%rax
    a534:	73 24                	jae    a55a <fwp_hof0.constprop.0+0x151a>
    a536:	48 01 c7             	add    %rax,%rdi
    a539:	80 3f 01             	cmpb   $0x1,(%rdi)
    a53c:	75 1c                	jne    a55a <fwp_hof0.constprop.0+0x151a>
    a53e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a543:	e8 08 b0 ff ff       	call   5550 <fwp_mem_free>
    a548:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a54f:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a556:	48 c1 e2 10          	shl    $0x10,%rdx
    a55a:	48 89 d8             	mov    %rbx,%rax
    a55d:	48 29 c8             	sub    %rcx,%rax
    a560:	48 39 d0             	cmp    %rdx,%rax
    a563:	0f 83 87 f8 ff ff    	jae    9df0 <fwp_hof0.constprop.0+0xdb0>
    a569:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    a56e:	e9 0f f8 ff ff       	jmp    9d82 <fwp_hof0.constprop.0+0xd42>
    a573:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a578:	66 85 c0             	test   %ax,%ax
    a57b:	0f 85 7d fc ff ff    	jne    a1fe <fwp_hof0.constprop.0+0x11be>
    a581:	80 3b ff             	cmpb   $0xff,(%rbx)
    a584:	0f 85 71 fc ff ff    	jne    a1fb <fwp_hof0.constprop.0+0x11bb>
    a58a:	48 89 df             	mov    %rbx,%rdi
    a58d:	e8 7e ad ff ff       	call   5310 <fwp_rc_forget_slot>
    a592:	e9 64 fc ff ff       	jmp    a1fb <fwp_hof0.constprop.0+0x11bb>
    a597:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a59e:	00 00 
    a5a0:	48 89 d7             	mov    %rdx,%rdi
    a5a3:	be 08 00 00 00       	mov    $0x8,%esi
    a5a8:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a5ad:	e8 6e 8f ff ff       	call   3520 <calloc@plt>
    a5b2:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    a5b8:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    a5be:	4c 8b 54 24 50       	mov    0x50(%rsp),%r10
    a5c3:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a5c8:	48 89 c1             	mov    %rax,%rcx
    a5cb:	e9 10 fe ff ff       	jmp    a3e0 <fwp_hof0.constprop.0+0x13a0>
    a5d0:	66 85 c0             	test   %ax,%ax
    a5d3:	0f 85 20 eb ff ff    	jne    90f9 <fwp_hof0.constprop.0+0xb9>
    a5d9:	e9 07 eb ff ff       	jmp    90e5 <fwp_hof0.constprop.0+0xa5>
    a5de:	66 90                	xchg   %ax,%ax
    a5e0:	66 85 c0             	test   %ax,%ax
    a5e3:	0f 85 d7 f9 ff ff    	jne    9fc0 <fwp_hof0.constprop.0+0xf80>
    a5e9:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a5ed:	84 c0                	test   %al,%al
    a5ef:	0f 84 cb f9 ff ff    	je     9fc0 <fwp_hof0.constprop.0+0xf80>
    a5f5:	3c 01                	cmp    $0x1,%al
    a5f7:	0f 85 af f9 ff ff    	jne    9fac <fwp_hof0.constprop.0+0xf6c>
    a5fd:	48 89 df             	mov    %rbx,%rdi
    a600:	e8 4b af ff ff       	call   5550 <fwp_mem_free>
    a605:	e9 b6 f9 ff ff       	jmp    9fc0 <fwp_hof0.constprop.0+0xf80>
    a60a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a610:	66 85 c0             	test   %ax,%ax
    a613:	0f 85 f0 f8 ff ff    	jne    9f09 <fwp_hof0.constprop.0+0xec9>
    a619:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a61d:	0f 85 e2 f8 ff ff    	jne    9f05 <fwp_hof0.constprop.0+0xec5>
    a623:	4c 89 ff             	mov    %r15,%rdi
    a626:	e8 e5 ac ff ff       	call   5310 <fwp_rc_forget_slot>
    a62b:	e9 d5 f8 ff ff       	jmp    9f05 <fwp_hof0.constprop.0+0xec5>
    a630:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a634:	e9 f6 eb ff ff       	jmp    922f <fwp_hof0.constprop.0+0x1ef>
    a639:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a63d:	48 85 c0             	test   %rax,%rax
    a640:	0f 88 7d fc ff ff    	js     a2c3 <fwp_hof0.constprop.0+0x1283>
    a646:	49 8b b5 d8 13 00 00 	mov    0x13d8(%r13),%rsi
    a64d:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a652:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    a659:	48 c1 e6 10          	shl    $0x10,%rsi
    a65d:	48 39 f1             	cmp    %rsi,%rcx
    a660:	0f 83 5d fc ff ff    	jae    a2c3 <fwp_hof0.constprop.0+0x1283>
    a666:	48 89 ce             	mov    %rcx,%rsi
    a669:	48 c1 ee 10          	shr    $0x10,%rsi
    a66d:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a671:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    a678:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a67c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a680:	48 85 ff             	test   %rdi,%rdi
    a683:	0f 84 3a fc ff ff    	je     a2c3 <fwp_hof0.constprop.0+0x1283>
    a689:	48 0f ba f0 3f       	btr    $0x3f,%rax
    a68e:	49 89 c7             	mov    %rax,%r15
    a691:	e9 ff f3 ff ff       	jmp    9a95 <fwp_hof0.constprop.0+0xa55>
    a696:	be 68 00 00 00       	mov    $0x68,%esi
    a69b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    a6a1:	e9 15 ec ff ff       	jmp    92bb <fwp_hof0.constprop.0+0x27b>
    a6a6:	66 85 c0             	test   %ax,%ax
    a6a9:	0f 85 ab fe ff ff    	jne    a55a <fwp_hof0.constprop.0+0x151a>
    a6af:	e9 85 fe ff ff       	jmp    a539 <fwp_hof0.constprop.0+0x14f9>
    a6b4:	48 89 ea             	mov    %rbp,%rdx
    a6b7:	48 c1 ea 11          	shr    $0x11,%rdx
    a6bb:	48 31 ea             	xor    %rbp,%rdx
    a6be:	48 89 d0             	mov    %rdx,%rax
    a6c1:	48 c1 e8 09          	shr    $0x9,%rax
    a6c5:	48 31 c2             	xor    %rax,%rdx
    a6c8:	0f b6 d2             	movzbl %dl,%edx
    a6cb:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a6d2:	00 
    a6d3:	48 85 c0             	test   %rax,%rax
    a6d6:	75 11                	jne    a6e9 <fwp_hof0.constprop.0+0x16a9>
    a6d8:	eb 6f                	jmp    a749 <fwp_hof0.constprop.0+0x1709>
    a6da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a6e4:	48 85 c0             	test   %rax,%rax
    a6e7:	74 60                	je     a749 <fwp_hof0.constprop.0+0x1709>
    a6e9:	48 89 c2             	mov    %rax,%rdx
    a6ec:	48 39 28             	cmp    %rbp,(%rax)
    a6ef:	75 ef                	jne    a6e0 <fwp_hof0.constprop.0+0x16a0>
    a6f1:	48 8b 58 08          	mov    0x8(%rax),%rbx
    a6f5:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    a6f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a6fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a704:	0f 85 e6 f6 ff ff    	jne    9df0 <fwp_hof0.constprop.0+0xdb0>
    a70a:	48 89 ef             	mov    %rbp,%rdi
    a70d:	e8 fe ab ff ff       	call   5310 <fwp_rc_forget_slot>
    a712:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a716:	e9 d5 f6 ff ff       	jmp    9df0 <fwp_hof0.constprop.0+0xdb0>
    a71b:	e8 d0 aa ff ff       	call   51f0 <fwp_rc_wide_dup>
    a720:	e9 c3 ea ff ff       	jmp    91e8 <fwp_hof0.constprop.0+0x1a8>
    a725:	48 89 e8             	mov    %rbp,%rax
    a728:	48 c1 e8 11          	shr    $0x11,%rax
    a72c:	48 31 e8             	xor    %rbp,%rax
    a72f:	48 89 c2             	mov    %rax,%rdx
    a732:	48 c1 ea 09          	shr    $0x9,%rdx
    a736:	48 31 d0             	xor    %rdx,%rax
    a739:	0f b6 d0             	movzbl %al,%edx
    a73c:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a743:	00 
    a744:	48 85 c0             	test   %rax,%rax
    a747:	75 60                	jne    a7a9 <fwp_hof0.constprop.0+0x1769>
    a749:	48 8d 3d 50 40 00 00 	lea    0x4050(%rip),%rdi        # e7a0 <_IO_stdin_used+0x7a0>
    a750:	e8 4b 9a ff ff       	call   41a0 <fwp_trap>
    a755:	49 89 da             	mov    %rbx,%r10
    a758:	48 89 cf             	mov    %rcx,%rdi
    a75b:	31 f6                	xor    %esi,%esi
    a75d:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a762:	49 8d 6a ff          	lea    -0x1(%r10),%rbp
    a766:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    a76d:	00 
    a76e:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    a773:	e8 48 8d ff ff       	call   34c0 <memset@plt>
    a778:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    a77e:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a784:	48 89 c1             	mov    %rax,%rcx
    a787:	e9 7d fc ff ff       	jmp    a409 <fwp_hof0.constprop.0+0x13c9>
    a78c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a793:	00 00 
    a795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a79c:	00 00 00 00 
    a7a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a7a4:	48 85 c0             	test   %rax,%rax
    a7a7:	74 a0                	je     a749 <fwp_hof0.constprop.0+0x1709>
    a7a9:	48 89 c2             	mov    %rax,%rdx
    a7ac:	48 3b 28             	cmp    (%rax),%rbp
    a7af:	75 ef                	jne    a7a0 <fwp_hof0.constprop.0+0x1760>
    a7b1:	48 8b 58 08          	mov    0x8(%rax),%rbx
    a7b5:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    a7b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a7bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a7c4:	0f 85 f6 f7 ff ff    	jne    9fc0 <fwp_hof0.constprop.0+0xf80>
    a7ca:	48 89 ef             	mov    %rbp,%rdi
    a7cd:	e8 3e ab ff ff       	call   5310 <fwp_rc_forget_slot>
    a7d2:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a7d6:	e9 e5 f7 ff ff       	jmp    9fc0 <fwp_hof0.constprop.0+0xf80>
    a7db:	e8 10 aa ff ff       	call   51f0 <fwp_rc_wide_dup>
    a7e0:	e9 14 e9 ff ff       	jmp    90f9 <fwp_hof0.constprop.0+0xb9>
    a7e5:	45 31 ff             	xor    %r15d,%r15d
    a7e8:	e9 28 f4 ff ff       	jmp    9c15 <fwp_hof0.constprop.0+0xbd5>
    a7ed:	48 8d 3d d4 3f 00 00 	lea    0x3fd4(%rip),%rdi        # e7c8 <_IO_stdin_used+0x7c8>
    a7f4:	e8 a7 99 ff ff       	call   41a0 <fwp_trap>
    a7f9:	48 8d 3d 04 39 00 00 	lea    0x3904(%rip),%rdi        # e104 <_IO_stdin_used+0x104>
    a800:	e8 9b 99 ff ff       	call   41a0 <fwp_trap>
    a805:	48 8d 3d 94 40 00 00 	lea    0x4094(%rip),%rdi        # e8a0 <_IO_stdin_used+0x8a0>
    a80c:	e8 8f 99 ff ff       	call   41a0 <fwp_trap>
    a811:	45 31 e4             	xor    %r12d,%r12d
    a814:	e9 bc fa ff ff       	jmp    a2d5 <fwp_hof0.constprop.0+0x1295>
    a819:	48 8d 3d 9e 39 00 00 	lea    0x399e(%rip),%rdi        # e1be <_IO_stdin_used+0x1be>
    a820:	e8 7b 99 ff ff       	call   41a0 <fwp_trap>
    a825:	48 8d 3d ac 39 00 00 	lea    0x39ac(%rip),%rdi        # e1d8 <_IO_stdin_used+0x1d8>
    a82c:	e8 6f 99 ff ff       	call   41a0 <fwp_trap>
    a831:	48 8d 3d f5 38 00 00 	lea    0x38f5(%rip),%rdi        # e12d <_IO_stdin_used+0x12d>
    a838:	e8 63 99 ff ff       	call   41a0 <fwp_trap>
    a83d:	0f 1f 00             	nopl   (%rax)
    a840:	48 8d 3d 81 40 00 00 	lea    0x4081(%rip),%rdi        # e8c8 <_IO_stdin_used+0x8c8>
    a847:	e8 54 99 ff ff       	call   41a0 <fwp_trap>
    a84c:	4d 85 d2             	test   %r10,%r10
    a84f:	0f 84 ad fb ff ff    	je     a402 <fwp_hof0.constprop.0+0x13c2>
    a855:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    a85c:	00 
    a85d:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a862:	48 89 05 8f 9b 01 00 	mov    %rax,0x19b8f(%rip)        # 243f8 <fwp_cleanups>
    a869:	e8 c2 a5 ff ff       	call   4e30 <fwp_tape_buffers_release>
    a86e:	ba 13 00 00 00       	mov    $0x13,%edx
    a873:	48 8b 0d c6 77 00 00 	mov    0x77c6(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    a87a:	be 01 00 00 00       	mov    $0x1,%esi
    a87f:	48 8d 3d 82 37 00 00 	lea    0x3782(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    a886:	e8 f5 8d ff ff       	call   3680 <fwrite@plt>
    a88b:	31 ff                	xor    %edi,%edi
    a88d:	e8 2e 8d ff ff       	call   35c0 <fflush@plt>
    a892:	bf 66 00 00 00       	mov    $0x66,%edi
    a897:	e8 04 8e ff ff       	call   36a0 <_Exit@plt>
    a89c:	48 8d 3d cd 3f 00 00 	lea    0x3fcd(%rip),%rdi        # e870 <_IO_stdin_used+0x870>
    a8a3:	e8 f8 98 ff ff       	call   41a0 <fwp_trap>
    a8a8:	48 8b 0d 91 77 00 00 	mov    0x7791(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    a8af:	ba 13 00 00 00       	mov    $0x13,%edx
    a8b4:	be 01 00 00 00       	mov    $0x1,%esi
    a8b9:	48 8d 3d 48 37 00 00 	lea    0x3748(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    a8c0:	e8 bb 8d ff ff       	call   3680 <fwrite@plt>
    a8c5:	31 ff                	xor    %edi,%edi
    a8c7:	e8 f4 8c ff ff       	call   35c0 <fflush@plt>
    a8cc:	bf 66 00 00 00       	mov    $0x66,%edi
    a8d1:	e8 ca 8d ff ff       	call   36a0 <_Exit@plt>
    a8d6:	48 8d 3d 33 3f 00 00 	lea    0x3f33(%rip),%rdi        # e810 <_IO_stdin_used+0x810>
    a8dd:	e8 be 98 ff ff       	call   41a0 <fwp_trap>
    a8e2:	e8 79 8b ff ff       	call   3460 <__stack_chk_fail@plt>
    a8e7:	48 8d 3d fa 38 00 00 	lea    0x38fa(%rip),%rdi        # e1e8 <_IO_stdin_used+0x1e8>
    a8ee:	e8 ad 98 ff ff       	call   41a0 <fwp_trap>
    a8f3:	48 8b 0d 46 77 00 00 	mov    0x7746(%rip),%rcx        # 12040 <stderr@GLIBC_2.2.5>
    a8fa:	ba 13 00 00 00       	mov    $0x13,%edx
    a8ff:	be 01 00 00 00       	mov    $0x1,%esi
    a904:	48 8d 3d fd 36 00 00 	lea    0x36fd(%rip),%rdi        # e008 <_IO_stdin_used+0x8>
    a90b:	e8 70 8d ff ff       	call   3680 <fwrite@plt>
    a910:	31 ff                	xor    %edi,%edi
    a912:	e8 a9 8c ff ff       	call   35c0 <fflush@plt>
    a917:	bf 66 00 00 00       	mov    $0x66,%edi
    a91c:	e8 7f 8d ff ff       	call   36a0 <_Exit@plt>
    a921:	0f 1f 40 00          	nopl   0x0(%rax)
    a925:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a92c:	00 00 00 00 

000000000000a930 <f0>:
    a930:	41 56                	push   %r14
    a932:	4c 8d 35 27 7e 01 00 	lea    0x17e27(%rip),%r14        # 22760 <fwp_heap>
    a939:	41 55                	push   %r13
    a93b:	41 54                	push   %r12
    a93d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    a943:	55                   	push   %rbp
    a944:	53                   	push   %rbx
    a945:	31 db                	xor    %ebx,%ebx
    a947:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    a94e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a955:	00 00 
    a957:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    a95e:	00 
    a95f:	31 c0                	xor    %eax,%eax
    a961:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    a968:	00 
    a969:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    a970:	00 00 
    a972:	66 48 0f 6e c0       	movq   %rax,%xmm0
    a977:	48 8d 05 32 cd ff ff 	lea    -0x32ce(%rip),%rax        # 76b0 <fwp_drop1>
    a97e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    a983:	48 8b 05 6e 9a 01 00 	mov    0x19a6e(%rip),%rax        # 243f8 <fwp_cleanups>
    a98a:	48 89 25 67 9a 01 00 	mov    %rsp,0x19a67(%rip)        # 243f8 <fwp_cleanups>
    a991:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    a995:	48 89 04 24          	mov    %rax,(%rsp)
    a999:	48 8d 05 30 92 ff ff 	lea    -0x6dd0(%rip),%rax        # 3bd0 <fwp_range_release>
    a9a0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a9a5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    a9aa:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a9af:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    a9b4:	eb 47                	jmp    a9fd <f0+0xcd>
    a9b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a9bd:	00 00 00 
    a9c0:	80 f9 01             	cmp    $0x1,%cl
    a9c3:	75 29                	jne    a9ee <f0+0xbe>
    a9c5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a9c8:	0f b7 c0             	movzwl %ax,%eax
    a9cb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a9ce:	48 0f af c1          	imul   %rcx,%rax
    a9d2:	48 c1 e8 20          	shr    $0x20,%rax
    a9d6:	48 39 d0             	cmp    %rdx,%rax
    a9d9:	73 13                	jae    a9ee <f0+0xbe>
    a9db:	49 01 c5             	add    %rax,%r13
    a9de:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a9e3:	0f 84 c7 27 00 00    	je     d1b0 <f0+0x2880>
    a9e9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a9ee:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    a9f3:	49 83 ec 01          	sub    $0x1,%r12
    a9f7:	0f 82 83 00 00 00    	jb     aa80 <f0+0x150>
    a9fd:	48 89 ee             	mov    %rbp,%rsi
    aa00:	bf 01 00 00 00       	mov    $0x1,%edi
    aa05:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    aa0c:	00 
    aa0d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    aa12:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    aa19:	00 
    aa1a:	e8 51 b1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    aa1f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    aa26:	48 89 c3             	mov    %rax,%rbx
    aa29:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    aa30:	48 c1 e2 10          	shl    $0x10,%rdx
    aa34:	48 39 d0             	cmp    %rdx,%rax
    aa37:	73 b5                	jae    a9ee <f0+0xbe>
    aa39:	48 89 c2             	mov    %rax,%rdx
    aa3c:	48 c1 ea 10          	shr    $0x10,%rdx
    aa40:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa44:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    aa4b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aa4f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    aa53:	4d 85 ed             	test   %r13,%r13
    aa56:	74 96                	je     a9ee <f0+0xbe>
    aa58:	0f b6 0a             	movzbl (%rdx),%ecx
    aa5b:	80 f9 02             	cmp    $0x2,%cl
    aa5e:	0f 85 5c ff ff ff    	jne    a9c0 <f0+0x90>
    aa64:	66 85 c0             	test   %ax,%ax
    aa67:	0f 84 71 ff ff ff    	je     a9de <f0+0xae>
    aa6d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    aa72:	49 83 ec 01          	sub    $0x1,%r12
    aa76:	73 85                	jae    a9fd <f0+0xcd>
    aa78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aa7f:	00 
    aa80:	48 8b 04 24          	mov    (%rsp),%rax
    aa84:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    aa89:	bf 01 00 00 00       	mov    $0x1,%edi
    aa8e:	66 0f 6f 05 ba 40 00 	movdqa 0x40ba(%rip),%xmm0        # eb50 <msg.4+0xd0>
    aa95:	00 
    aa96:	48 89 05 5b 99 01 00 	mov    %rax,0x1995b(%rip)        # 243f8 <fwp_cleanups>
    aa9d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    aaa2:	e8 c9 b0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    aaa7:	48 8b 15 8a 90 01 00 	mov    0x1908a(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    aaae:	49 89 c5             	mov    %rax,%r13
    aab1:	48 2b 05 58 90 01 00 	sub    0x19058(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    aab8:	48 c1 e2 10          	shl    $0x10,%rdx
    aabc:	48 39 d0             	cmp    %rdx,%rax
    aabf:	73 59                	jae    ab1a <f0+0x1ea>
    aac1:	48 89 c2             	mov    %rax,%rdx
    aac4:	48 c1 ea 10          	shr    $0x10,%rdx
    aac8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aacc:	48 8b 15 85 90 01 00 	mov    0x19085(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    aad3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aad7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aadb:	4d 85 e4             	test   %r12,%r12
    aade:	74 3a                	je     ab1a <f0+0x1ea>
    aae0:	0f b6 0a             	movzbl (%rdx),%ecx
    aae3:	80 f9 02             	cmp    $0x2,%cl
    aae6:	0f 84 74 27 00 00    	je     d260 <f0+0x2930>
    aaec:	80 f9 01             	cmp    $0x1,%cl
    aaef:	75 29                	jne    ab1a <f0+0x1ea>
    aaf1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aaf4:	0f b7 c0             	movzwl %ax,%eax
    aaf7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aafa:	48 0f af c1          	imul   %rcx,%rax
    aafe:	48 c1 e8 20          	shr    $0x20,%rax
    ab02:	48 39 d0             	cmp    %rdx,%rax
    ab05:	73 13                	jae    ab1a <f0+0x1ea>
    ab07:	49 01 c4             	add    %rax,%r12
    ab0a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ab0f:	0f 84 26 29 00 00    	je     d43b <f0+0x2b0b>
    ab15:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ab1a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    ab1f:	bf 01 00 00 00       	mov    $0x1,%edi
    ab24:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    ab29:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ab30:	00 f0 3f 
    ab33:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    ab38:	e8 33 b0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ab3d:	48 8b 15 f4 8f 01 00 	mov    0x18ff4(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    ab44:	49 89 c5             	mov    %rax,%r13
    ab47:	48 2b 05 c2 8f 01 00 	sub    0x18fc2(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ab4e:	48 c1 e2 10          	shl    $0x10,%rdx
    ab52:	48 39 d0             	cmp    %rdx,%rax
    ab55:	73 59                	jae    abb0 <f0+0x280>
    ab57:	48 89 c2             	mov    %rax,%rdx
    ab5a:	48 c1 ea 10          	shr    $0x10,%rdx
    ab5e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ab62:	48 8b 15 ef 8f 01 00 	mov    0x18fef(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ab69:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ab6d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ab71:	4d 85 e4             	test   %r12,%r12
    ab74:	74 3a                	je     abb0 <f0+0x280>
    ab76:	0f b6 0a             	movzbl (%rdx),%ecx
    ab79:	80 f9 02             	cmp    $0x2,%cl
    ab7c:	0f 84 ce 26 00 00    	je     d250 <f0+0x2920>
    ab82:	80 f9 01             	cmp    $0x1,%cl
    ab85:	75 29                	jne    abb0 <f0+0x280>
    ab87:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ab8a:	0f b7 c0             	movzwl %ax,%eax
    ab8d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab90:	48 0f af c1          	imul   %rcx,%rax
    ab94:	48 c1 e8 20          	shr    $0x20,%rax
    ab98:	48 39 d0             	cmp    %rdx,%rax
    ab9b:	73 13                	jae    abb0 <f0+0x280>
    ab9d:	49 01 c4             	add    %rax,%r12
    aba0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    aba5:	0f 84 9d 28 00 00    	je     d448 <f0+0x2b18>
    abab:	41 c6 04 24 01       	movb   $0x1,(%r12)
    abb0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    abb5:	bf 01 00 00 00       	mov    $0x1,%edi
    abba:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    abbf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    abc6:	33 f3 bf 
    abc9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    abce:	e8 9d af ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    abd3:	48 8b 15 5e 8f 01 00 	mov    0x18f5e(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    abda:	49 89 c5             	mov    %rax,%r13
    abdd:	48 2b 05 2c 8f 01 00 	sub    0x18f2c(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    abe4:	48 c1 e2 10          	shl    $0x10,%rdx
    abe8:	48 39 d0             	cmp    %rdx,%rax
    abeb:	73 59                	jae    ac46 <f0+0x316>
    abed:	48 89 c2             	mov    %rax,%rdx
    abf0:	48 c1 ea 10          	shr    $0x10,%rdx
    abf4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    abf8:	48 8b 15 59 8f 01 00 	mov    0x18f59(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    abff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac03:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ac07:	4d 85 e4             	test   %r12,%r12
    ac0a:	74 3a                	je     ac46 <f0+0x316>
    ac0c:	0f b6 0a             	movzbl (%rdx),%ecx
    ac0f:	80 f9 02             	cmp    $0x2,%cl
    ac12:	0f 84 28 26 00 00    	je     d240 <f0+0x2910>
    ac18:	80 f9 01             	cmp    $0x1,%cl
    ac1b:	75 29                	jne    ac46 <f0+0x316>
    ac1d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac20:	0f b7 c0             	movzwl %ax,%eax
    ac23:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac26:	48 0f af c1          	imul   %rcx,%rax
    ac2a:	48 c1 e8 20          	shr    $0x20,%rax
    ac2e:	48 39 d0             	cmp    %rdx,%rax
    ac31:	73 13                	jae    ac46 <f0+0x316>
    ac33:	49 01 c4             	add    %rax,%r12
    ac36:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ac3b:	0f 84 14 28 00 00    	je     d455 <f0+0x2b25>
    ac41:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ac46:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    ac4b:	bf 01 00 00 00       	mov    $0x1,%edi
    ac50:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    ac55:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ac5c:	00 f0 3f 
    ac5f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    ac64:	e8 07 af ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ac69:	48 8b 15 c8 8e 01 00 	mov    0x18ec8(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    ac70:	49 89 c5             	mov    %rax,%r13
    ac73:	48 2b 05 96 8e 01 00 	sub    0x18e96(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ac7a:	48 c1 e2 10          	shl    $0x10,%rdx
    ac7e:	48 39 d0             	cmp    %rdx,%rax
    ac81:	73 59                	jae    acdc <f0+0x3ac>
    ac83:	48 89 c2             	mov    %rax,%rdx
    ac86:	48 c1 ea 10          	shr    $0x10,%rdx
    ac8a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac8e:	48 8b 15 c3 8e 01 00 	mov    0x18ec3(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ac95:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac99:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ac9d:	4d 85 e4             	test   %r12,%r12
    aca0:	74 3a                	je     acdc <f0+0x3ac>
    aca2:	0f b6 0a             	movzbl (%rdx),%ecx
    aca5:	80 f9 02             	cmp    $0x2,%cl
    aca8:	0f 84 f2 25 00 00    	je     d2a0 <f0+0x2970>
    acae:	80 f9 01             	cmp    $0x1,%cl
    acb1:	75 29                	jne    acdc <f0+0x3ac>
    acb3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    acb6:	0f b7 c0             	movzwl %ax,%eax
    acb9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    acbc:	48 0f af c1          	imul   %rcx,%rax
    acc0:	48 c1 e8 20          	shr    $0x20,%rax
    acc4:	48 39 d0             	cmp    %rdx,%rax
    acc7:	73 13                	jae    acdc <f0+0x3ac>
    acc9:	49 01 c4             	add    %rax,%r12
    accc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    acd1:	0f 84 8b 27 00 00    	je     d462 <f0+0x2b32>
    acd7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    acdc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ace3:	33 f3 bf 
    ace6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aced:	00 
    acee:	bf 01 00 00 00       	mov    $0x1,%edi
    acf3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    acfa:	00 
    acfb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    ad02:	00 
    ad03:	e8 68 ae ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ad08:	48 8b 15 29 8e 01 00 	mov    0x18e29(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    ad0f:	49 89 c5             	mov    %rax,%r13
    ad12:	48 2b 05 f7 8d 01 00 	sub    0x18df7(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ad19:	48 c1 e2 10          	shl    $0x10,%rdx
    ad1d:	48 39 d0             	cmp    %rdx,%rax
    ad20:	73 59                	jae    ad7b <f0+0x44b>
    ad22:	48 89 c2             	mov    %rax,%rdx
    ad25:	48 c1 ea 10          	shr    $0x10,%rdx
    ad29:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad2d:	48 8b 15 24 8e 01 00 	mov    0x18e24(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ad34:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad38:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ad3c:	4d 85 e4             	test   %r12,%r12
    ad3f:	74 3a                	je     ad7b <f0+0x44b>
    ad41:	0f b6 0a             	movzbl (%rdx),%ecx
    ad44:	80 f9 02             	cmp    $0x2,%cl
    ad47:	0f 84 43 25 00 00    	je     d290 <f0+0x2960>
    ad4d:	80 f9 01             	cmp    $0x1,%cl
    ad50:	75 29                	jne    ad7b <f0+0x44b>
    ad52:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad55:	0f b7 c0             	movzwl %ax,%eax
    ad58:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad5b:	48 0f af c1          	imul   %rcx,%rax
    ad5f:	48 c1 e8 20          	shr    $0x20,%rax
    ad63:	48 39 d0             	cmp    %rdx,%rax
    ad66:	73 13                	jae    ad7b <f0+0x44b>
    ad68:	49 01 c4             	add    %rax,%r12
    ad6b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ad70:	0f 84 f9 26 00 00    	je     d46f <f0+0x2b3f>
    ad76:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ad7b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    ad82:	00 f0 3f 
    ad85:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    ad8c:	00 
    ad8d:	bf 01 00 00 00       	mov    $0x1,%edi
    ad92:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    ad99:	00 
    ad9a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    ada1:	00 
    ada2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    ada9:	33 f3 bf 
    adac:	e8 bf ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    adb1:	48 89 c7             	mov    %rax,%rdi
    adb4:	e8 d7 b4 ff ff       	call   6290 <fwp_rc_fresh>
    adb9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    adc0:	00 
    adc1:	bf 01 00 00 00       	mov    $0x1,%edi
    adc6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    adcd:	00 
    adce:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    add5:	00 
    add6:	e8 95 ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    addb:	48 89 c7             	mov    %rax,%rdi
    adde:	e8 ad b4 ff ff       	call   6290 <fwp_rc_fresh>
    ade3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    adea:	00 
    adeb:	bf 01 00 00 00       	mov    $0x1,%edi
    adf0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    adf7:	00 
    adf8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    adff:	00 
    ae00:	e8 6b ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ae05:	48 89 c7             	mov    %rax,%rdi
    ae08:	e8 83 b4 ff ff       	call   6290 <fwp_rc_fresh>
    ae0d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    ae14:	00 
    ae15:	bf 01 00 00 00       	mov    $0x1,%edi
    ae1a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    ae21:	00 
    ae22:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    ae29:	00 
    ae2a:	e8 41 ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ae2f:	48 89 c7             	mov    %rax,%rdi
    ae32:	e8 59 b4 ff ff       	call   6290 <fwp_rc_fresh>
    ae37:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    ae3e:	00 
    ae3f:	bf 01 00 00 00       	mov    $0x1,%edi
    ae44:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    ae4b:	00 
    ae4c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    ae53:	00 
    ae54:	e8 17 ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ae59:	48 89 c7             	mov    %rax,%rdi
    ae5c:	e8 2f b4 ff ff       	call   6290 <fwp_rc_fresh>
    ae61:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    ae68:	00 
    ae69:	bf 01 00 00 00       	mov    $0x1,%edi
    ae6e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    ae75:	00 
    ae76:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    ae7d:	00 
    ae7e:	e8 ed ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ae83:	48 89 c7             	mov    %rax,%rdi
    ae86:	e8 05 b4 ff ff       	call   6290 <fwp_rc_fresh>
    ae8b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    ae92:	00 
    ae93:	bf 01 00 00 00       	mov    $0x1,%edi
    ae98:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    ae9f:	00 
    aea0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    aea7:	00 
    aea8:	e8 c3 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    aead:	48 89 c7             	mov    %rax,%rdi
    aeb0:	e8 db b3 ff ff       	call   6290 <fwp_rc_fresh>
    aeb5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    aebc:	00 
    aebd:	bf 01 00 00 00       	mov    $0x1,%edi
    aec2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    aec9:	00 
    aeca:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    aed1:	00 
    aed2:	e8 99 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    aed7:	48 89 c7             	mov    %rax,%rdi
    aeda:	e8 b1 b3 ff ff       	call   6290 <fwp_rc_fresh>
    aedf:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    aee6:	00 
    aee7:	bf 01 00 00 00       	mov    $0x1,%edi
    aeec:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    aef3:	00 
    aef4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    aefb:	00 
    aefc:	e8 6f ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af01:	48 89 c7             	mov    %rax,%rdi
    af04:	e8 87 b3 ff ff       	call   6290 <fwp_rc_fresh>
    af09:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    af10:	00 
    af11:	bf 01 00 00 00       	mov    $0x1,%edi
    af16:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    af1d:	00 
    af1e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    af25:	00 
    af26:	e8 45 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af2b:	48 89 c7             	mov    %rax,%rdi
    af2e:	e8 5d b3 ff ff       	call   6290 <fwp_rc_fresh>
    af33:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    af3a:	00 
    af3b:	bf 01 00 00 00       	mov    $0x1,%edi
    af40:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    af47:	00 
    af48:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    af4f:	00 
    af50:	e8 1b ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af55:	48 89 c7             	mov    %rax,%rdi
    af58:	e8 33 b3 ff ff       	call   6290 <fwp_rc_fresh>
    af5d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    af64:	00 
    af65:	bf 01 00 00 00       	mov    $0x1,%edi
    af6a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    af71:	00 
    af72:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    af79:	00 
    af7a:	e8 f1 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af7f:	48 89 c7             	mov    %rax,%rdi
    af82:	e8 09 b3 ff ff       	call   6290 <fwp_rc_fresh>
    af87:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    af8e:	00 
    af8f:	bf 01 00 00 00       	mov    $0x1,%edi
    af94:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    af9b:	00 
    af9c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    afa3:	00 
    afa4:	e8 c7 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    afa9:	48 89 c7             	mov    %rax,%rdi
    afac:	e8 df b2 ff ff       	call   6290 <fwp_rc_fresh>
    afb1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    afb8:	00 
    afb9:	bf 01 00 00 00       	mov    $0x1,%edi
    afbe:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    afc5:	00 
    afc6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    afcd:	00 
    afce:	e8 9d ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    afd3:	48 89 c7             	mov    %rax,%rdi
    afd6:	e8 b5 b2 ff ff       	call   6290 <fwp_rc_fresh>
    afdb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    afe2:	00 
    afe3:	bf 01 00 00 00       	mov    $0x1,%edi
    afe8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    afef:	00 
    aff0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    aff7:	00 
    aff8:	e8 73 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    affd:	48 89 c7             	mov    %rax,%rdi
    b000:	e8 8b b2 ff ff       	call   6290 <fwp_rc_fresh>
    b005:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b00c:	00 
    b00d:	bf 01 00 00 00       	mov    $0x1,%edi
    b012:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b019:	00 
    b01a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b021:	00 
    b022:	e8 49 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b027:	48 89 c7             	mov    %rax,%rdi
    b02a:	e8 61 b2 ff ff       	call   6290 <fwp_rc_fresh>
    b02f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b036:	00 
    b037:	bf 01 00 00 00       	mov    $0x1,%edi
    b03c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b043:	00 
    b044:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b04b:	00 
    b04c:	e8 1f ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b051:	48 89 c7             	mov    %rax,%rdi
    b054:	e8 37 b2 ff ff       	call   6290 <fwp_rc_fresh>
    b059:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b060:	00 
    b061:	bf 01 00 00 00       	mov    $0x1,%edi
    b066:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b06d:	00 
    b06e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b075:	00 
    b076:	e8 f5 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b07b:	48 89 c7             	mov    %rax,%rdi
    b07e:	e8 0d b2 ff ff       	call   6290 <fwp_rc_fresh>
    b083:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b08a:	00 
    b08b:	bf 01 00 00 00       	mov    $0x1,%edi
    b090:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b097:	00 
    b098:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b09f:	00 
    b0a0:	e8 cb aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b0a5:	48 89 c7             	mov    %rax,%rdi
    b0a8:	e8 e3 b1 ff ff       	call   6290 <fwp_rc_fresh>
    b0ad:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b0b4:	00 
    b0b5:	bf 01 00 00 00       	mov    $0x1,%edi
    b0ba:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b0c1:	00 
    b0c2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b0c9:	00 
    b0ca:	e8 a1 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b0cf:	48 89 c7             	mov    %rax,%rdi
    b0d2:	e8 b9 b1 ff ff       	call   6290 <fwp_rc_fresh>
    b0d7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b0de:	00 
    b0df:	bf 01 00 00 00       	mov    $0x1,%edi
    b0e4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b0eb:	00 
    b0ec:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b0f3:	00 
    b0f4:	e8 77 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b0f9:	48 89 c7             	mov    %rax,%rdi
    b0fc:	e8 8f b1 ff ff       	call   6290 <fwp_rc_fresh>
    b101:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b108:	00 
    b109:	bf 01 00 00 00       	mov    $0x1,%edi
    b10e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b115:	00 
    b116:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b11d:	00 
    b11e:	e8 4d aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b123:	48 89 c7             	mov    %rax,%rdi
    b126:	e8 65 b1 ff ff       	call   6290 <fwp_rc_fresh>
    b12b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b132:	00 
    b133:	bf 01 00 00 00       	mov    $0x1,%edi
    b138:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b13f:	00 
    b140:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b147:	00 
    b148:	e8 23 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b14d:	48 89 c7             	mov    %rax,%rdi
    b150:	e8 3b b1 ff ff       	call   6290 <fwp_rc_fresh>
    b155:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b15c:	00 
    b15d:	bf 01 00 00 00       	mov    $0x1,%edi
    b162:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b169:	00 
    b16a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b171:	00 
    b172:	e8 f9 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b177:	48 89 c7             	mov    %rax,%rdi
    b17a:	e8 11 b1 ff ff       	call   6290 <fwp_rc_fresh>
    b17f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b186:	00 
    b187:	bf 01 00 00 00       	mov    $0x1,%edi
    b18c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b193:	00 
    b194:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b19b:	00 
    b19c:	e8 cf a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b1a1:	48 89 c7             	mov    %rax,%rdi
    b1a4:	e8 e7 b0 ff ff       	call   6290 <fwp_rc_fresh>
    b1a9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b1b0:	00 
    b1b1:	bf 01 00 00 00       	mov    $0x1,%edi
    b1b6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b1bd:	00 
    b1be:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b1c5:	00 
    b1c6:	e8 a5 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b1cb:	48 89 c7             	mov    %rax,%rdi
    b1ce:	e8 bd b0 ff ff       	call   6290 <fwp_rc_fresh>
    b1d3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b1da:	00 
    b1db:	bf 01 00 00 00       	mov    $0x1,%edi
    b1e0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b1e7:	00 
    b1e8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b1ef:	00 
    b1f0:	e8 7b a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b1f5:	48 89 c7             	mov    %rax,%rdi
    b1f8:	e8 93 b0 ff ff       	call   6290 <fwp_rc_fresh>
    b1fd:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b204:	00 
    b205:	bf 01 00 00 00       	mov    $0x1,%edi
    b20a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b211:	00 
    b212:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b219:	00 
    b21a:	e8 51 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b21f:	48 89 c7             	mov    %rax,%rdi
    b222:	e8 69 b0 ff ff       	call   6290 <fwp_rc_fresh>
    b227:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b22e:	00 
    b22f:	bf 01 00 00 00       	mov    $0x1,%edi
    b234:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b23b:	00 
    b23c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b243:	00 
    b244:	e8 27 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b249:	48 89 c7             	mov    %rax,%rdi
    b24c:	e8 3f b0 ff ff       	call   6290 <fwp_rc_fresh>
    b251:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b258:	00 
    b259:	bf 01 00 00 00       	mov    $0x1,%edi
    b25e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b265:	00 
    b266:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b26d:	00 
    b26e:	e8 fd a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b273:	48 89 c7             	mov    %rax,%rdi
    b276:	e8 15 b0 ff ff       	call   6290 <fwp_rc_fresh>
    b27b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b282:	00 
    b283:	bf 01 00 00 00       	mov    $0x1,%edi
    b288:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b28f:	00 
    b290:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b297:	00 
    b298:	e8 d3 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b29d:	48 89 c7             	mov    %rax,%rdi
    b2a0:	e8 eb af ff ff       	call   6290 <fwp_rc_fresh>
    b2a5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b2ac:	00 
    b2ad:	bf 01 00 00 00       	mov    $0x1,%edi
    b2b2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b2b9:	00 
    b2ba:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b2c1:	00 
    b2c2:	e8 a9 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b2c7:	48 89 c7             	mov    %rax,%rdi
    b2ca:	e8 c1 af ff ff       	call   6290 <fwp_rc_fresh>
    b2cf:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b2d6:	00 
    b2d7:	bf 01 00 00 00       	mov    $0x1,%edi
    b2dc:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b2e3:	00 
    b2e4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b2eb:	00 
    b2ec:	e8 7f a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b2f1:	48 89 c7             	mov    %rax,%rdi
    b2f4:	e8 97 af ff ff       	call   6290 <fwp_rc_fresh>
    b2f9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b300:	00 
    b301:	bf 01 00 00 00       	mov    $0x1,%edi
    b306:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b30d:	00 
    b30e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b315:	00 
    b316:	e8 55 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b31b:	48 89 c7             	mov    %rax,%rdi
    b31e:	e8 6d af ff ff       	call   6290 <fwp_rc_fresh>
    b323:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b32a:	00 
    b32b:	bf 01 00 00 00       	mov    $0x1,%edi
    b330:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b337:	00 
    b338:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b33f:	00 
    b340:	e8 2b a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b345:	48 89 c7             	mov    %rax,%rdi
    b348:	e8 43 af ff ff       	call   6290 <fwp_rc_fresh>
    b34d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b354:	00 
    b355:	bf 01 00 00 00       	mov    $0x1,%edi
    b35a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b361:	00 
    b362:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b369:	00 
    b36a:	e8 01 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b36f:	48 89 c7             	mov    %rax,%rdi
    b372:	e8 19 af ff ff       	call   6290 <fwp_rc_fresh>
    b377:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b37e:	00 
    b37f:	bf 01 00 00 00       	mov    $0x1,%edi
    b384:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b38b:	00 
    b38c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b393:	00 
    b394:	e8 d7 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b399:	48 89 c7             	mov    %rax,%rdi
    b39c:	e8 ef ae ff ff       	call   6290 <fwp_rc_fresh>
    b3a1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b3a8:	00 
    b3a9:	bf 01 00 00 00       	mov    $0x1,%edi
    b3ae:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b3b5:	00 
    b3b6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b3bd:	00 
    b3be:	e8 ad a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b3c3:	48 89 c7             	mov    %rax,%rdi
    b3c6:	e8 c5 ae ff ff       	call   6290 <fwp_rc_fresh>
    b3cb:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b3d2:	00 
    b3d3:	bf 01 00 00 00       	mov    $0x1,%edi
    b3d8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b3df:	00 
    b3e0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b3e7:	00 
    b3e8:	e8 83 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b3ed:	48 89 c7             	mov    %rax,%rdi
    b3f0:	e8 9b ae ff ff       	call   6290 <fwp_rc_fresh>
    b3f5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b3fc:	00 
    b3fd:	bf 01 00 00 00       	mov    $0x1,%edi
    b402:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b409:	00 
    b40a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b411:	00 
    b412:	e8 59 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b417:	48 89 c7             	mov    %rax,%rdi
    b41a:	e8 71 ae ff ff       	call   6290 <fwp_rc_fresh>
    b41f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    b426:	00 
    b427:	bf 01 00 00 00       	mov    $0x1,%edi
    b42c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    b433:	00 
    b434:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    b43b:	00 
    b43c:	e8 2f a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b441:	48 89 c7             	mov    %rax,%rdi
    b444:	e8 47 ae ff ff       	call   6290 <fwp_rc_fresh>
    b449:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    b450:	00 
    b451:	bf 01 00 00 00       	mov    $0x1,%edi
    b456:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    b45d:	00 
    b45e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    b465:	00 
    b466:	e8 05 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b46b:	48 89 c7             	mov    %rax,%rdi
    b46e:	e8 1d ae ff ff       	call   6290 <fwp_rc_fresh>
    b473:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    b47a:	00 
    b47b:	bf 01 00 00 00       	mov    $0x1,%edi
    b480:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    b487:	00 
    b488:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    b48f:	00 
    b490:	e8 db a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b495:	48 89 c7             	mov    %rax,%rdi
    b498:	e8 f3 ad ff ff       	call   6290 <fwp_rc_fresh>
    b49d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    b4a4:	00 
    b4a5:	bf 01 00 00 00       	mov    $0x1,%edi
    b4aa:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    b4b1:	00 
    b4b2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    b4b9:	00 
    b4ba:	e8 b1 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b4bf:	48 89 c7             	mov    %rax,%rdi
    b4c2:	e8 c9 ad ff ff       	call   6290 <fwp_rc_fresh>
    b4c7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    b4ce:	00 
    b4cf:	bf 01 00 00 00       	mov    $0x1,%edi
    b4d4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    b4db:	00 
    b4dc:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    b4e3:	00 
    b4e4:	e8 87 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b4e9:	48 89 c7             	mov    %rax,%rdi
    b4ec:	e8 9f ad ff ff       	call   6290 <fwp_rc_fresh>
    b4f1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    b4f8:	00 
    b4f9:	bf 01 00 00 00       	mov    $0x1,%edi
    b4fe:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    b505:	00 
    b506:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    b50d:	00 
    b50e:	e8 5d a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b513:	48 89 c7             	mov    %rax,%rdi
    b516:	e8 75 ad ff ff       	call   6290 <fwp_rc_fresh>
    b51b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    b522:	00 
    b523:	bf 01 00 00 00       	mov    $0x1,%edi
    b528:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    b52f:	00 
    b530:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    b537:	00 
    b538:	e8 33 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b53d:	48 89 c7             	mov    %rax,%rdi
    b540:	e8 4b ad ff ff       	call   6290 <fwp_rc_fresh>
    b545:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    b54c:	00 
    b54d:	bf 01 00 00 00       	mov    $0x1,%edi
    b552:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    b559:	00 
    b55a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    b561:	00 
    b562:	e8 09 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b567:	48 89 c7             	mov    %rax,%rdi
    b56a:	e8 21 ad ff ff       	call   6290 <fwp_rc_fresh>
    b56f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    b576:	00 
    b577:	bf 01 00 00 00       	mov    $0x1,%edi
    b57c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    b583:	00 
    b584:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    b58b:	00 
    b58c:	e8 df a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b591:	48 89 c7             	mov    %rax,%rdi
    b594:	e8 f7 ac ff ff       	call   6290 <fwp_rc_fresh>
    b599:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    b5a0:	00 
    b5a1:	bf 01 00 00 00       	mov    $0x1,%edi
    b5a6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    b5ad:	00 
    b5ae:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    b5b5:	00 
    b5b6:	e8 b5 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b5bb:	48 89 c7             	mov    %rax,%rdi
    b5be:	e8 cd ac ff ff       	call   6290 <fwp_rc_fresh>
    b5c3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    b5ca:	00 
    b5cb:	bf 01 00 00 00       	mov    $0x1,%edi
    b5d0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    b5d7:	00 
    b5d8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    b5df:	00 
    b5e0:	e8 8b a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b5e5:	48 89 c7             	mov    %rax,%rdi
    b5e8:	e8 a3 ac ff ff       	call   6290 <fwp_rc_fresh>
    b5ed:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    b5f4:	00 
    b5f5:	bf 01 00 00 00       	mov    $0x1,%edi
    b5fa:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    b601:	00 
    b602:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    b609:	00 
    b60a:	e8 61 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b60f:	48 89 c7             	mov    %rax,%rdi
    b612:	e8 79 ac ff ff       	call   6290 <fwp_rc_fresh>
    b617:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    b61e:	00 
    b61f:	bf 01 00 00 00       	mov    $0x1,%edi
    b624:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    b62b:	00 
    b62c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    b633:	00 
    b634:	e8 37 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b639:	48 89 c7             	mov    %rax,%rdi
    b63c:	e8 4f ac ff ff       	call   6290 <fwp_rc_fresh>
    b641:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    b648:	00 
    b649:	bf 01 00 00 00       	mov    $0x1,%edi
    b64e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    b655:	00 
    b656:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    b65d:	00 
    b65e:	e8 0d a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b663:	48 89 c7             	mov    %rax,%rdi
    b666:	e8 25 ac ff ff       	call   6290 <fwp_rc_fresh>
    b66b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    b672:	00 
    b673:	bf 01 00 00 00       	mov    $0x1,%edi
    b678:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    b67f:	00 
    b680:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    b687:	00 
    b688:	e8 e3 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b68d:	48 89 c7             	mov    %rax,%rdi
    b690:	e8 fb ab ff ff       	call   6290 <fwp_rc_fresh>
    b695:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    b69c:	00 
    b69d:	bf 01 00 00 00       	mov    $0x1,%edi
    b6a2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    b6a9:	00 
    b6aa:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    b6b1:	00 
    b6b2:	e8 b9 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b6b7:	48 89 c7             	mov    %rax,%rdi
    b6ba:	e8 d1 ab ff ff       	call   6290 <fwp_rc_fresh>
    b6bf:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    b6c6:	00 
    b6c7:	bf 01 00 00 00       	mov    $0x1,%edi
    b6cc:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    b6d3:	00 
    b6d4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    b6db:	00 
    b6dc:	e8 8f a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b6e1:	48 89 c7             	mov    %rax,%rdi
    b6e4:	e8 a7 ab ff ff       	call   6290 <fwp_rc_fresh>
    b6e9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    b6f0:	00 
    b6f1:	bf 01 00 00 00       	mov    $0x1,%edi
    b6f6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    b6fd:	00 
    b6fe:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    b705:	00 
    b706:	e8 65 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b70b:	48 89 c7             	mov    %rax,%rdi
    b70e:	e8 7d ab ff ff       	call   6290 <fwp_rc_fresh>
    b713:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    b71a:	00 
    b71b:	bf 01 00 00 00       	mov    $0x1,%edi
    b720:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    b727:	00 
    b728:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    b72f:	00 
    b730:	e8 3b a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b735:	48 89 c7             	mov    %rax,%rdi
    b738:	e8 53 ab ff ff       	call   6290 <fwp_rc_fresh>
    b73d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    b744:	00 
    b745:	bf 01 00 00 00       	mov    $0x1,%edi
    b74a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    b751:	00 
    b752:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    b759:	00 
    b75a:	e8 11 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b75f:	48 89 c7             	mov    %rax,%rdi
    b762:	e8 29 ab ff ff       	call   6290 <fwp_rc_fresh>
    b767:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    b76e:	00 
    b76f:	bf 01 00 00 00       	mov    $0x1,%edi
    b774:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    b77b:	00 
    b77c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    b783:	00 
    b784:	e8 e7 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b789:	48 89 c7             	mov    %rax,%rdi
    b78c:	e8 ff aa ff ff       	call   6290 <fwp_rc_fresh>
    b791:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    b798:	00 
    b799:	bf 01 00 00 00       	mov    $0x1,%edi
    b79e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    b7a5:	00 
    b7a6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    b7ad:	00 
    b7ae:	e8 bd a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b7b3:	48 89 c7             	mov    %rax,%rdi
    b7b6:	e8 d5 aa ff ff       	call   6290 <fwp_rc_fresh>
    b7bb:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    b7c2:	00 
    b7c3:	bf 01 00 00 00       	mov    $0x1,%edi
    b7c8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    b7cf:	00 
    b7d0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    b7d7:	00 
    b7d8:	e8 93 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b7dd:	48 89 c7             	mov    %rax,%rdi
    b7e0:	e8 ab aa ff ff       	call   6290 <fwp_rc_fresh>
    b7e5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    b7ec:	00 
    b7ed:	bf 01 00 00 00       	mov    $0x1,%edi
    b7f2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    b7f9:	00 
    b7fa:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    b801:	00 
    b802:	e8 69 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b807:	48 89 c7             	mov    %rax,%rdi
    b80a:	e8 81 aa ff ff       	call   6290 <fwp_rc_fresh>
    b80f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    b816:	00 
    b817:	bf 01 00 00 00       	mov    $0x1,%edi
    b81c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    b823:	00 
    b824:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    b82b:	00 
    b82c:	e8 3f a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b831:	48 89 c7             	mov    %rax,%rdi
    b834:	e8 57 aa ff ff       	call   6290 <fwp_rc_fresh>
    b839:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    b840:	00 
    b841:	bf 01 00 00 00       	mov    $0x1,%edi
    b846:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    b84d:	00 
    b84e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    b855:	00 
    b856:	e8 15 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b85b:	48 89 c7             	mov    %rax,%rdi
    b85e:	e8 2d aa ff ff       	call   6290 <fwp_rc_fresh>
    b863:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    b86a:	00 
    b86b:	bf 01 00 00 00       	mov    $0x1,%edi
    b870:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    b877:	00 
    b878:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    b87f:	00 
    b880:	e8 eb a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b885:	48 89 c7             	mov    %rax,%rdi
    b888:	e8 03 aa ff ff       	call   6290 <fwp_rc_fresh>
    b88d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    b894:	00 
    b895:	bf 01 00 00 00       	mov    $0x1,%edi
    b89a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    b8a1:	00 
    b8a2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    b8a9:	00 
    b8aa:	e8 c1 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b8af:	48 89 c7             	mov    %rax,%rdi
    b8b2:	e8 d9 a9 ff ff       	call   6290 <fwp_rc_fresh>
    b8b7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    b8be:	00 
    b8bf:	bf 01 00 00 00       	mov    $0x1,%edi
    b8c4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    b8cb:	00 
    b8cc:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    b8d3:	00 
    b8d4:	e8 97 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b8d9:	48 89 c7             	mov    %rax,%rdi
    b8dc:	e8 af a9 ff ff       	call   6290 <fwp_rc_fresh>
    b8e1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    b8e8:	00 
    b8e9:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ee:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    b8f5:	00 
    b8f6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    b8fd:	00 
    b8fe:	e8 6d a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b903:	48 89 c7             	mov    %rax,%rdi
    b906:	e8 85 a9 ff ff       	call   6290 <fwp_rc_fresh>
    b90b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    b912:	00 
    b913:	bf 01 00 00 00       	mov    $0x1,%edi
    b918:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    b91f:	00 
    b920:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    b927:	00 
    b928:	e8 43 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b92d:	48 89 c7             	mov    %rax,%rdi
    b930:	e8 5b a9 ff ff       	call   6290 <fwp_rc_fresh>
    b935:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    b93c:	00 
    b93d:	bf 01 00 00 00       	mov    $0x1,%edi
    b942:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    b949:	00 
    b94a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    b951:	00 
    b952:	e8 19 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b957:	48 89 c7             	mov    %rax,%rdi
    b95a:	e8 31 a9 ff ff       	call   6290 <fwp_rc_fresh>
    b95f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    b966:	00 
    b967:	bf 01 00 00 00       	mov    $0x1,%edi
    b96c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    b973:	00 
    b974:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    b97b:	00 
    b97c:	e8 ef a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b981:	48 89 c7             	mov    %rax,%rdi
    b984:	e8 07 a9 ff ff       	call   6290 <fwp_rc_fresh>
    b989:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    b990:	00 
    b991:	bf 01 00 00 00       	mov    $0x1,%edi
    b996:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    b99d:	00 
    b99e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    b9a5:	00 
    b9a6:	e8 c5 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9ab:	48 89 c7             	mov    %rax,%rdi
    b9ae:	e8 dd a8 ff ff       	call   6290 <fwp_rc_fresh>
    b9b3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    b9ba:	00 
    b9bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b9c0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    b9c7:	00 
    b9c8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    b9cf:	00 
    b9d0:	e8 9b a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9d5:	48 89 c7             	mov    %rax,%rdi
    b9d8:	e8 b3 a8 ff ff       	call   6290 <fwp_rc_fresh>
    b9dd:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    b9e4:	00 
    b9e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b9ea:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    b9f1:	00 
    b9f2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    b9f9:	00 
    b9fa:	e8 71 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9ff:	48 89 c7             	mov    %rax,%rdi
    ba02:	e8 89 a8 ff ff       	call   6290 <fwp_rc_fresh>
    ba07:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    ba0e:	00 
    ba0f:	bf 01 00 00 00       	mov    $0x1,%edi
    ba14:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    ba1b:	00 
    ba1c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    ba23:	00 
    ba24:	e8 47 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba29:	48 89 c7             	mov    %rax,%rdi
    ba2c:	e8 5f a8 ff ff       	call   6290 <fwp_rc_fresh>
    ba31:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    ba38:	00 
    ba39:	bf 01 00 00 00       	mov    $0x1,%edi
    ba3e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    ba45:	00 
    ba46:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    ba4d:	00 
    ba4e:	e8 1d a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba53:	48 89 c7             	mov    %rax,%rdi
    ba56:	e8 35 a8 ff ff       	call   6290 <fwp_rc_fresh>
    ba5b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    ba62:	00 
    ba63:	bf 01 00 00 00       	mov    $0x1,%edi
    ba68:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    ba6f:	00 
    ba70:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    ba77:	00 
    ba78:	e8 f3 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba7d:	48 89 c7             	mov    %rax,%rdi
    ba80:	e8 0b a8 ff ff       	call   6290 <fwp_rc_fresh>
    ba85:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    ba8c:	00 
    ba8d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba92:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    ba99:	00 
    ba9a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    baa1:	00 
    baa2:	e8 c9 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    baa7:	48 89 c7             	mov    %rax,%rdi
    baaa:	e8 e1 a7 ff ff       	call   6290 <fwp_rc_fresh>
    baaf:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    bab6:	00 
    bab7:	bf 01 00 00 00       	mov    $0x1,%edi
    babc:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    bac3:	00 
    bac4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    bacb:	00 
    bacc:	e8 9f a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bad1:	48 89 c7             	mov    %rax,%rdi
    bad4:	e8 b7 a7 ff ff       	call   6290 <fwp_rc_fresh>
    bad9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    bae0:	00 
    bae1:	bf 01 00 00 00       	mov    $0x1,%edi
    bae6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    baed:	00 
    baee:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    baf5:	00 
    baf6:	e8 75 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bafb:	48 89 c7             	mov    %rax,%rdi
    bafe:	e8 8d a7 ff ff       	call   6290 <fwp_rc_fresh>
    bb03:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    bb0a:	00 
    bb0b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb10:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    bb17:	00 
    bb18:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    bb1f:	00 
    bb20:	e8 4b a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb25:	48 89 c7             	mov    %rax,%rdi
    bb28:	e8 63 a7 ff ff       	call   6290 <fwp_rc_fresh>
    bb2d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    bb34:	00 
    bb35:	bf 01 00 00 00       	mov    $0x1,%edi
    bb3a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    bb41:	00 
    bb42:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    bb49:	00 
    bb4a:	e8 21 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb4f:	48 89 c7             	mov    %rax,%rdi
    bb52:	e8 39 a7 ff ff       	call   6290 <fwp_rc_fresh>
    bb57:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    bb5e:	00 
    bb5f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb64:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    bb6b:	00 
    bb6c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    bb73:	00 
    bb74:	e8 f7 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb79:	48 89 c7             	mov    %rax,%rdi
    bb7c:	e8 0f a7 ff ff       	call   6290 <fwp_rc_fresh>
    bb81:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    bb88:	00 
    bb89:	bf 01 00 00 00       	mov    $0x1,%edi
    bb8e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    bb95:	00 
    bb96:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    bb9d:	00 
    bb9e:	e8 cd 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bba3:	48 89 c7             	mov    %rax,%rdi
    bba6:	e8 e5 a6 ff ff       	call   6290 <fwp_rc_fresh>
    bbab:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    bbb2:	00 
    bbb3:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    bbbf:	00 
    bbc0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    bbc7:	00 
    bbc8:	e8 a3 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bbcd:	48 89 c7             	mov    %rax,%rdi
    bbd0:	e8 bb a6 ff ff       	call   6290 <fwp_rc_fresh>
    bbd5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    bbdc:	00 
    bbdd:	bf 01 00 00 00       	mov    $0x1,%edi
    bbe2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    bbe9:	00 
    bbea:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    bbf1:	00 
    bbf2:	e8 79 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bbf7:	48 89 c7             	mov    %rax,%rdi
    bbfa:	e8 91 a6 ff ff       	call   6290 <fwp_rc_fresh>
    bbff:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    bc06:	00 
    bc07:	bf 01 00 00 00       	mov    $0x1,%edi
    bc0c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    bc13:	00 
    bc14:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    bc1b:	00 
    bc1c:	e8 4f 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc21:	48 89 c7             	mov    %rax,%rdi
    bc24:	e8 67 a6 ff ff       	call   6290 <fwp_rc_fresh>
    bc29:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    bc30:	00 
    bc31:	bf 01 00 00 00       	mov    $0x1,%edi
    bc36:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    bc3d:	00 
    bc3e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    bc45:	00 
    bc46:	e8 25 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc4b:	48 89 c7             	mov    %rax,%rdi
    bc4e:	e8 3d a6 ff ff       	call   6290 <fwp_rc_fresh>
    bc53:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    bc5a:	00 
    bc5b:	bf 01 00 00 00       	mov    $0x1,%edi
    bc60:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    bc67:	00 
    bc68:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    bc6f:	00 
    bc70:	e8 fb 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc75:	48 8b 15 bc 7e 01 00 	mov    0x17ebc(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bc7c:	49 89 c5             	mov    %rax,%r13
    bc7f:	48 2b 05 8a 7e 01 00 	sub    0x17e8a(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bc86:	48 c1 e2 10          	shl    $0x10,%rdx
    bc8a:	48 39 d0             	cmp    %rdx,%rax
    bc8d:	73 59                	jae    bce8 <f0+0x13b8>
    bc8f:	48 89 c2             	mov    %rax,%rdx
    bc92:	48 c1 ea 10          	shr    $0x10,%rdx
    bc96:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bc9a:	48 8b 15 b7 7e 01 00 	mov    0x17eb7(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    bca1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bca5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bca9:	4d 85 e4             	test   %r12,%r12
    bcac:	74 3a                	je     bce8 <f0+0x13b8>
    bcae:	0f b6 0a             	movzbl (%rdx),%ecx
    bcb1:	80 f9 02             	cmp    $0x2,%cl
    bcb4:	0f 84 c6 15 00 00    	je     d280 <f0+0x2950>
    bcba:	80 f9 01             	cmp    $0x1,%cl
    bcbd:	75 29                	jne    bce8 <f0+0x13b8>
    bcbf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bcc2:	0f b7 c0             	movzwl %ax,%eax
    bcc5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bcc8:	48 0f af c1          	imul   %rcx,%rax
    bccc:	48 c1 e8 20          	shr    $0x20,%rax
    bcd0:	48 39 d0             	cmp    %rdx,%rax
    bcd3:	73 13                	jae    bce8 <f0+0x13b8>
    bcd5:	49 01 c4             	add    %rax,%r12
    bcd8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bcdd:	0f 84 99 17 00 00    	je     d47c <f0+0x2b4c>
    bce3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bce8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bcef:	33 f3 bf 
    bcf2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    bcf9:	00 
    bcfa:	bf 01 00 00 00       	mov    $0x1,%edi
    bcff:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    bd06:	00 
    bd07:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    bd0e:	00 
    bd0f:	e8 5c 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd14:	48 8b 15 1d 7e 01 00 	mov    0x17e1d(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bd1b:	49 89 c5             	mov    %rax,%r13
    bd1e:	48 2b 05 eb 7d 01 00 	sub    0x17deb(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bd25:	48 c1 e2 10          	shl    $0x10,%rdx
    bd29:	48 39 d0             	cmp    %rdx,%rax
    bd2c:	73 59                	jae    bd87 <f0+0x1457>
    bd2e:	48 89 c2             	mov    %rax,%rdx
    bd31:	48 c1 ea 10          	shr    $0x10,%rdx
    bd35:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd39:	48 8b 15 18 7e 01 00 	mov    0x17e18(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    bd40:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd44:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bd48:	4d 85 e4             	test   %r12,%r12
    bd4b:	74 3a                	je     bd87 <f0+0x1457>
    bd4d:	0f b6 0a             	movzbl (%rdx),%ecx
    bd50:	80 f9 02             	cmp    $0x2,%cl
    bd53:	0f 84 17 15 00 00    	je     d270 <f0+0x2940>
    bd59:	80 f9 01             	cmp    $0x1,%cl
    bd5c:	75 29                	jne    bd87 <f0+0x1457>
    bd5e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bd61:	0f b7 c0             	movzwl %ax,%eax
    bd64:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bd67:	48 0f af c1          	imul   %rcx,%rax
    bd6b:	48 c1 e8 20          	shr    $0x20,%rax
    bd6f:	48 39 d0             	cmp    %rdx,%rax
    bd72:	73 13                	jae    bd87 <f0+0x1457>
    bd74:	49 01 c4             	add    %rax,%r12
    bd77:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bd7c:	0f 84 07 17 00 00    	je     d489 <f0+0x2b59>
    bd82:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bd87:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bd8e:	00 f0 3f 
    bd91:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    bd98:	00 
    bd99:	bf 01 00 00 00       	mov    $0x1,%edi
    bd9e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    bda5:	00 
    bda6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    bdad:	00 
    bdae:	e8 bd 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bdb3:	48 8b 15 7e 7d 01 00 	mov    0x17d7e(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bdba:	49 89 c5             	mov    %rax,%r13
    bdbd:	48 2b 05 4c 7d 01 00 	sub    0x17d4c(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bdc4:	48 c1 e2 10          	shl    $0x10,%rdx
    bdc8:	48 39 d0             	cmp    %rdx,%rax
    bdcb:	73 59                	jae    be26 <f0+0x14f6>
    bdcd:	48 89 c2             	mov    %rax,%rdx
    bdd0:	48 c1 ea 10          	shr    $0x10,%rdx
    bdd4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bdd8:	48 8b 15 79 7d 01 00 	mov    0x17d79(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    bddf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bde3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bde7:	4d 85 e4             	test   %r12,%r12
    bdea:	74 3a                	je     be26 <f0+0x14f6>
    bdec:	0f b6 0a             	movzbl (%rdx),%ecx
    bdef:	80 f9 02             	cmp    $0x2,%cl
    bdf2:	0f 84 28 15 00 00    	je     d320 <f0+0x29f0>
    bdf8:	80 f9 01             	cmp    $0x1,%cl
    bdfb:	75 29                	jne    be26 <f0+0x14f6>
    bdfd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be00:	0f b7 c0             	movzwl %ax,%eax
    be03:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be06:	48 0f af c1          	imul   %rcx,%rax
    be0a:	48 c1 e8 20          	shr    $0x20,%rax
    be0e:	48 39 d0             	cmp    %rdx,%rax
    be11:	73 13                	jae    be26 <f0+0x14f6>
    be13:	49 01 c4             	add    %rax,%r12
    be16:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    be1b:	0f 84 75 16 00 00    	je     d496 <f0+0x2b66>
    be21:	41 c6 04 24 01       	movb   $0x1,(%r12)
    be26:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    be2d:	33 f3 bf 
    be30:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    be37:	00 
    be38:	bf 01 00 00 00       	mov    $0x1,%edi
    be3d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    be44:	00 
    be45:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    be4c:	00 
    be4d:	e8 1e 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    be52:	48 8b 15 df 7c 01 00 	mov    0x17cdf(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    be59:	49 89 c5             	mov    %rax,%r13
    be5c:	48 2b 05 ad 7c 01 00 	sub    0x17cad(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    be63:	48 c1 e2 10          	shl    $0x10,%rdx
    be67:	48 39 d0             	cmp    %rdx,%rax
    be6a:	73 59                	jae    bec5 <f0+0x1595>
    be6c:	48 89 c2             	mov    %rax,%rdx
    be6f:	48 c1 ea 10          	shr    $0x10,%rdx
    be73:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be77:	48 8b 15 da 7c 01 00 	mov    0x17cda(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    be7e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be82:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    be86:	4d 85 e4             	test   %r12,%r12
    be89:	74 3a                	je     bec5 <f0+0x1595>
    be8b:	0f b6 0a             	movzbl (%rdx),%ecx
    be8e:	80 f9 02             	cmp    $0x2,%cl
    be91:	0f 84 79 14 00 00    	je     d310 <f0+0x29e0>
    be97:	80 f9 01             	cmp    $0x1,%cl
    be9a:	75 29                	jne    bec5 <f0+0x1595>
    be9c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be9f:	0f b7 c0             	movzwl %ax,%eax
    bea2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bea5:	48 0f af c1          	imul   %rcx,%rax
    bea9:	48 c1 e8 20          	shr    $0x20,%rax
    bead:	48 39 d0             	cmp    %rdx,%rax
    beb0:	73 13                	jae    bec5 <f0+0x1595>
    beb2:	49 01 c4             	add    %rax,%r12
    beb5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    beba:	0f 84 e3 15 00 00    	je     d4a3 <f0+0x2b73>
    bec0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bec5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    becc:	00 f0 3f 
    becf:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    bed6:	00 
    bed7:	bf 01 00 00 00       	mov    $0x1,%edi
    bedc:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    bee3:	00 
    bee4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    beeb:	00 
    beec:	e8 7f 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bef1:	48 8b 15 40 7c 01 00 	mov    0x17c40(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bef8:	49 89 c5             	mov    %rax,%r13
    befb:	48 2b 05 0e 7c 01 00 	sub    0x17c0e(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bf02:	48 c1 e2 10          	shl    $0x10,%rdx
    bf06:	48 39 d0             	cmp    %rdx,%rax
    bf09:	73 59                	jae    bf64 <f0+0x1634>
    bf0b:	48 89 c2             	mov    %rax,%rdx
    bf0e:	48 c1 ea 10          	shr    $0x10,%rdx
    bf12:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf16:	48 8b 15 3b 7c 01 00 	mov    0x17c3b(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    bf1d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf21:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf25:	4d 85 e4             	test   %r12,%r12
    bf28:	74 3a                	je     bf64 <f0+0x1634>
    bf2a:	0f b6 0a             	movzbl (%rdx),%ecx
    bf2d:	80 f9 02             	cmp    $0x2,%cl
    bf30:	0f 84 ca 13 00 00    	je     d300 <f0+0x29d0>
    bf36:	80 f9 01             	cmp    $0x1,%cl
    bf39:	75 29                	jne    bf64 <f0+0x1634>
    bf3b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf3e:	0f b7 c0             	movzwl %ax,%eax
    bf41:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf44:	48 0f af c1          	imul   %rcx,%rax
    bf48:	48 c1 e8 20          	shr    $0x20,%rax
    bf4c:	48 39 d0             	cmp    %rdx,%rax
    bf4f:	73 13                	jae    bf64 <f0+0x1634>
    bf51:	49 01 c4             	add    %rax,%r12
    bf54:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf59:	0f 84 51 15 00 00    	je     d4b0 <f0+0x2b80>
    bf5f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf64:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bf6b:	33 f3 bf 
    bf6e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    bf75:	00 
    bf76:	bf 01 00 00 00       	mov    $0x1,%edi
    bf7b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    bf82:	00 
    bf83:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    bf8a:	00 
    bf8b:	e8 e0 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bf90:	48 8b 15 a1 7b 01 00 	mov    0x17ba1(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    bf97:	49 89 c5             	mov    %rax,%r13
    bf9a:	48 2b 05 6f 7b 01 00 	sub    0x17b6f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    bfa1:	48 c1 e2 10          	shl    $0x10,%rdx
    bfa5:	48 39 d0             	cmp    %rdx,%rax
    bfa8:	73 59                	jae    c003 <f0+0x16d3>
    bfaa:	48 89 c2             	mov    %rax,%rdx
    bfad:	48 c1 ea 10          	shr    $0x10,%rdx
    bfb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bfb5:	48 8b 15 9c 7b 01 00 	mov    0x17b9c(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    bfbc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bfc0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bfc4:	4d 85 e4             	test   %r12,%r12
    bfc7:	74 3a                	je     c003 <f0+0x16d3>
    bfc9:	0f b6 0a             	movzbl (%rdx),%ecx
    bfcc:	80 f9 02             	cmp    $0x2,%cl
    bfcf:	0f 84 1b 13 00 00    	je     d2f0 <f0+0x29c0>
    bfd5:	80 f9 01             	cmp    $0x1,%cl
    bfd8:	75 29                	jne    c003 <f0+0x16d3>
    bfda:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bfdd:	0f b7 c0             	movzwl %ax,%eax
    bfe0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bfe3:	48 0f af c1          	imul   %rcx,%rax
    bfe7:	48 c1 e8 20          	shr    $0x20,%rax
    bfeb:	48 39 d0             	cmp    %rdx,%rax
    bfee:	73 13                	jae    c003 <f0+0x16d3>
    bff0:	49 01 c4             	add    %rax,%r12
    bff3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bff8:	0f 84 bf 14 00 00    	je     d4bd <f0+0x2b8d>
    bffe:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c003:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c00a:	00 f0 3f 
    c00d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c014:	00 
    c015:	bf 01 00 00 00       	mov    $0x1,%edi
    c01a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c021:	00 
    c022:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c029:	00 
    c02a:	e8 41 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c02f:	48 8b 15 02 7b 01 00 	mov    0x17b02(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c036:	49 89 c5             	mov    %rax,%r13
    c039:	48 2b 05 d0 7a 01 00 	sub    0x17ad0(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c040:	48 c1 e2 10          	shl    $0x10,%rdx
    c044:	48 39 d0             	cmp    %rdx,%rax
    c047:	73 59                	jae    c0a2 <f0+0x1772>
    c049:	48 89 c2             	mov    %rax,%rdx
    c04c:	48 c1 ea 10          	shr    $0x10,%rdx
    c050:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c054:	48 8b 15 fd 7a 01 00 	mov    0x17afd(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c05b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c05f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c063:	4d 85 e4             	test   %r12,%r12
    c066:	74 3a                	je     c0a2 <f0+0x1772>
    c068:	0f b6 0a             	movzbl (%rdx),%ecx
    c06b:	80 f9 02             	cmp    $0x2,%cl
    c06e:	0f 84 6c 12 00 00    	je     d2e0 <f0+0x29b0>
    c074:	80 f9 01             	cmp    $0x1,%cl
    c077:	75 29                	jne    c0a2 <f0+0x1772>
    c079:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c07c:	0f b7 c0             	movzwl %ax,%eax
    c07f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c082:	48 0f af c1          	imul   %rcx,%rax
    c086:	48 c1 e8 20          	shr    $0x20,%rax
    c08a:	48 39 d0             	cmp    %rdx,%rax
    c08d:	73 13                	jae    c0a2 <f0+0x1772>
    c08f:	49 01 c4             	add    %rax,%r12
    c092:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c097:	0f 84 2d 14 00 00    	je     d4ca <f0+0x2b9a>
    c09d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c0a2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c0a9:	33 f3 bf 
    c0ac:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c0b3:	00 
    c0b4:	bf 01 00 00 00       	mov    $0x1,%edi
    c0b9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c0c0:	00 
    c0c1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c0c8:	00 
    c0c9:	e8 a2 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c0ce:	48 8b 15 63 7a 01 00 	mov    0x17a63(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c0d5:	49 89 c5             	mov    %rax,%r13
    c0d8:	48 2b 05 31 7a 01 00 	sub    0x17a31(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c0df:	48 c1 e2 10          	shl    $0x10,%rdx
    c0e3:	48 39 d0             	cmp    %rdx,%rax
    c0e6:	73 59                	jae    c141 <f0+0x1811>
    c0e8:	48 89 c2             	mov    %rax,%rdx
    c0eb:	48 c1 ea 10          	shr    $0x10,%rdx
    c0ef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c0f3:	48 8b 15 5e 7a 01 00 	mov    0x17a5e(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c0fa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c0fe:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c102:	4d 85 e4             	test   %r12,%r12
    c105:	74 3a                	je     c141 <f0+0x1811>
    c107:	0f b6 0a             	movzbl (%rdx),%ecx
    c10a:	80 f9 02             	cmp    $0x2,%cl
    c10d:	0f 84 bd 11 00 00    	je     d2d0 <f0+0x29a0>
    c113:	80 f9 01             	cmp    $0x1,%cl
    c116:	75 29                	jne    c141 <f0+0x1811>
    c118:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c11b:	0f b7 c0             	movzwl %ax,%eax
    c11e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c121:	48 0f af c1          	imul   %rcx,%rax
    c125:	48 c1 e8 20          	shr    $0x20,%rax
    c129:	48 39 d0             	cmp    %rdx,%rax
    c12c:	73 13                	jae    c141 <f0+0x1811>
    c12e:	49 01 c4             	add    %rax,%r12
    c131:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c136:	0f 84 9b 13 00 00    	je     d4d7 <f0+0x2ba7>
    c13c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c141:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c148:	00 f0 3f 
    c14b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c152:	00 
    c153:	bf 01 00 00 00       	mov    $0x1,%edi
    c158:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c15f:	00 
    c160:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c167:	00 
    c168:	e8 03 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c16d:	48 8b 15 c4 79 01 00 	mov    0x179c4(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c174:	49 89 c5             	mov    %rax,%r13
    c177:	48 2b 05 92 79 01 00 	sub    0x17992(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c17e:	48 c1 e2 10          	shl    $0x10,%rdx
    c182:	48 39 d0             	cmp    %rdx,%rax
    c185:	73 59                	jae    c1e0 <f0+0x18b0>
    c187:	48 89 c2             	mov    %rax,%rdx
    c18a:	48 c1 ea 10          	shr    $0x10,%rdx
    c18e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c192:	48 8b 15 bf 79 01 00 	mov    0x179bf(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c199:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c19d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c1a1:	4d 85 e4             	test   %r12,%r12
    c1a4:	74 3a                	je     c1e0 <f0+0x18b0>
    c1a6:	0f b6 0a             	movzbl (%rdx),%ecx
    c1a9:	80 f9 02             	cmp    $0x2,%cl
    c1ac:	0f 84 0e 11 00 00    	je     d2c0 <f0+0x2990>
    c1b2:	80 f9 01             	cmp    $0x1,%cl
    c1b5:	75 29                	jne    c1e0 <f0+0x18b0>
    c1b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c1ba:	0f b7 c0             	movzwl %ax,%eax
    c1bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c1c0:	48 0f af c1          	imul   %rcx,%rax
    c1c4:	48 c1 e8 20          	shr    $0x20,%rax
    c1c8:	48 39 d0             	cmp    %rdx,%rax
    c1cb:	73 13                	jae    c1e0 <f0+0x18b0>
    c1cd:	49 01 c4             	add    %rax,%r12
    c1d0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c1d5:	0f 84 09 13 00 00    	je     d4e4 <f0+0x2bb4>
    c1db:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c1e0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c1e7:	33 f3 bf 
    c1ea:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c1f1:	00 
    c1f2:	bf 01 00 00 00       	mov    $0x1,%edi
    c1f7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c1fe:	00 
    c1ff:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c206:	00 
    c207:	e8 64 99 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c20c:	48 8b 15 25 79 01 00 	mov    0x17925(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c213:	49 89 c5             	mov    %rax,%r13
    c216:	48 2b 05 f3 78 01 00 	sub    0x178f3(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c21d:	48 c1 e2 10          	shl    $0x10,%rdx
    c221:	48 39 d0             	cmp    %rdx,%rax
    c224:	73 59                	jae    c27f <f0+0x194f>
    c226:	48 89 c2             	mov    %rax,%rdx
    c229:	48 c1 ea 10          	shr    $0x10,%rdx
    c22d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c231:	48 8b 15 20 79 01 00 	mov    0x17920(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c238:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c23c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c240:	4d 85 e4             	test   %r12,%r12
    c243:	74 3a                	je     c27f <f0+0x194f>
    c245:	0f b6 0a             	movzbl (%rdx),%ecx
    c248:	80 f9 02             	cmp    $0x2,%cl
    c24b:	0f 84 5f 10 00 00    	je     d2b0 <f0+0x2980>
    c251:	80 f9 01             	cmp    $0x1,%cl
    c254:	75 29                	jne    c27f <f0+0x194f>
    c256:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c259:	0f b7 c0             	movzwl %ax,%eax
    c25c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c25f:	48 0f af c1          	imul   %rcx,%rax
    c263:	48 c1 e8 20          	shr    $0x20,%rax
    c267:	48 39 d0             	cmp    %rdx,%rax
    c26a:	73 13                	jae    c27f <f0+0x194f>
    c26c:	49 01 c4             	add    %rax,%r12
    c26f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c274:	0f 84 77 12 00 00    	je     d4f1 <f0+0x2bc1>
    c27a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c27f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c286:	00 f0 3f 
    c289:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c290:	00 
    c291:	bf 01 00 00 00       	mov    $0x1,%edi
    c296:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c29d:	00 
    c29e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c2a5:	00 
    c2a6:	e8 c5 98 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c2ab:	48 8b 15 86 78 01 00 	mov    0x17886(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c2b2:	49 89 c5             	mov    %rax,%r13
    c2b5:	48 2b 05 54 78 01 00 	sub    0x17854(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c2bc:	48 c1 e2 10          	shl    $0x10,%rdx
    c2c0:	48 39 d0             	cmp    %rdx,%rax
    c2c3:	73 59                	jae    c31e <f0+0x19ee>
    c2c5:	48 89 c2             	mov    %rax,%rdx
    c2c8:	48 c1 ea 10          	shr    $0x10,%rdx
    c2cc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c2d0:	48 8b 15 81 78 01 00 	mov    0x17881(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c2d7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c2db:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c2df:	4d 85 e4             	test   %r12,%r12
    c2e2:	74 3a                	je     c31e <f0+0x19ee>
    c2e4:	0f b6 0a             	movzbl (%rdx),%ecx
    c2e7:	80 f9 02             	cmp    $0x2,%cl
    c2ea:	0f 84 40 0f 00 00    	je     d230 <f0+0x2900>
    c2f0:	80 f9 01             	cmp    $0x1,%cl
    c2f3:	75 29                	jne    c31e <f0+0x19ee>
    c2f5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c2f8:	0f b7 c0             	movzwl %ax,%eax
    c2fb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2fe:	48 0f af c1          	imul   %rcx,%rax
    c302:	48 c1 e8 20          	shr    $0x20,%rax
    c306:	48 39 d0             	cmp    %rdx,%rax
    c309:	73 13                	jae    c31e <f0+0x19ee>
    c30b:	49 01 c4             	add    %rax,%r12
    c30e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c313:	0f 84 e5 11 00 00    	je     d4fe <f0+0x2bce>
    c319:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c31e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c325:	33 f3 bf 
    c328:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c32f:	00 
    c330:	bf 01 00 00 00       	mov    $0x1,%edi
    c335:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c33c:	00 
    c33d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c344:	00 
    c345:	e8 26 98 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c34a:	48 8b 15 e7 77 01 00 	mov    0x177e7(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c351:	49 89 c5             	mov    %rax,%r13
    c354:	48 2b 05 b5 77 01 00 	sub    0x177b5(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c35b:	48 c1 e2 10          	shl    $0x10,%rdx
    c35f:	48 39 d0             	cmp    %rdx,%rax
    c362:	73 59                	jae    c3bd <f0+0x1a8d>
    c364:	48 89 c2             	mov    %rax,%rdx
    c367:	48 c1 ea 10          	shr    $0x10,%rdx
    c36b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c36f:	48 8b 15 e2 77 01 00 	mov    0x177e2(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c376:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c37a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c37e:	4d 85 e4             	test   %r12,%r12
    c381:	74 3a                	je     c3bd <f0+0x1a8d>
    c383:	0f b6 0a             	movzbl (%rdx),%ecx
    c386:	80 f9 02             	cmp    $0x2,%cl
    c389:	0f 84 91 0e 00 00    	je     d220 <f0+0x28f0>
    c38f:	80 f9 01             	cmp    $0x1,%cl
    c392:	75 29                	jne    c3bd <f0+0x1a8d>
    c394:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c397:	0f b7 c0             	movzwl %ax,%eax
    c39a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c39d:	48 0f af c1          	imul   %rcx,%rax
    c3a1:	48 c1 e8 20          	shr    $0x20,%rax
    c3a5:	48 39 d0             	cmp    %rdx,%rax
    c3a8:	73 13                	jae    c3bd <f0+0x1a8d>
    c3aa:	49 01 c4             	add    %rax,%r12
    c3ad:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c3b2:	0f 84 53 11 00 00    	je     d50b <f0+0x2bdb>
    c3b8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c3bd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c3c4:	00 f0 3f 
    c3c7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c3ce:	00 
    c3cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c3d4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c3db:	00 
    c3dc:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c3e3:	00 
    c3e4:	e8 87 97 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c3e9:	48 8b 15 48 77 01 00 	mov    0x17748(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c3f0:	49 89 c5             	mov    %rax,%r13
    c3f3:	48 2b 05 16 77 01 00 	sub    0x17716(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c3fa:	48 c1 e2 10          	shl    $0x10,%rdx
    c3fe:	48 39 d0             	cmp    %rdx,%rax
    c401:	73 59                	jae    c45c <f0+0x1b2c>
    c403:	48 89 c2             	mov    %rax,%rdx
    c406:	48 c1 ea 10          	shr    $0x10,%rdx
    c40a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c40e:	48 8b 15 43 77 01 00 	mov    0x17743(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c415:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c419:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c41d:	4d 85 e4             	test   %r12,%r12
    c420:	74 3a                	je     c45c <f0+0x1b2c>
    c422:	0f b6 0a             	movzbl (%rdx),%ecx
    c425:	80 f9 02             	cmp    $0x2,%cl
    c428:	0f 84 e2 0d 00 00    	je     d210 <f0+0x28e0>
    c42e:	80 f9 01             	cmp    $0x1,%cl
    c431:	75 29                	jne    c45c <f0+0x1b2c>
    c433:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c436:	0f b7 c0             	movzwl %ax,%eax
    c439:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c43c:	48 0f af c1          	imul   %rcx,%rax
    c440:	48 c1 e8 20          	shr    $0x20,%rax
    c444:	48 39 d0             	cmp    %rdx,%rax
    c447:	73 13                	jae    c45c <f0+0x1b2c>
    c449:	49 01 c4             	add    %rax,%r12
    c44c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c451:	0f 84 c1 10 00 00    	je     d518 <f0+0x2be8>
    c457:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c45c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c463:	33 f3 bf 
    c466:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    c46d:	00 
    c46e:	bf 01 00 00 00       	mov    $0x1,%edi
    c473:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    c47a:	00 
    c47b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    c482:	00 
    c483:	e8 e8 96 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c488:	48 8b 15 a9 76 01 00 	mov    0x176a9(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c48f:	49 89 c5             	mov    %rax,%r13
    c492:	48 2b 05 77 76 01 00 	sub    0x17677(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c499:	48 c1 e2 10          	shl    $0x10,%rdx
    c49d:	48 39 d0             	cmp    %rdx,%rax
    c4a0:	73 59                	jae    c4fb <f0+0x1bcb>
    c4a2:	48 89 c2             	mov    %rax,%rdx
    c4a5:	48 c1 ea 10          	shr    $0x10,%rdx
    c4a9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c4ad:	48 8b 15 a4 76 01 00 	mov    0x176a4(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c4b4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c4b8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c4bc:	4d 85 e4             	test   %r12,%r12
    c4bf:	74 3a                	je     c4fb <f0+0x1bcb>
    c4c1:	0f b6 0a             	movzbl (%rdx),%ecx
    c4c4:	80 f9 02             	cmp    $0x2,%cl
    c4c7:	0f 84 33 0d 00 00    	je     d200 <f0+0x28d0>
    c4cd:	80 f9 01             	cmp    $0x1,%cl
    c4d0:	75 29                	jne    c4fb <f0+0x1bcb>
    c4d2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c4d5:	0f b7 c0             	movzwl %ax,%eax
    c4d8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c4db:	48 0f af c1          	imul   %rcx,%rax
    c4df:	48 c1 e8 20          	shr    $0x20,%rax
    c4e3:	48 39 d0             	cmp    %rdx,%rax
    c4e6:	73 13                	jae    c4fb <f0+0x1bcb>
    c4e8:	49 01 c4             	add    %rax,%r12
    c4eb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c4f0:	0f 84 2f 10 00 00    	je     d525 <f0+0x2bf5>
    c4f6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4fb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c502:	00 f0 3f 
    c505:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    c50c:	00 
    c50d:	bf 01 00 00 00       	mov    $0x1,%edi
    c512:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    c519:	00 
    c51a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    c521:	00 
    c522:	e8 49 96 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c527:	48 8b 15 0a 76 01 00 	mov    0x1760a(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c52e:	49 89 c5             	mov    %rax,%r13
    c531:	48 2b 05 d8 75 01 00 	sub    0x175d8(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c538:	48 c1 e2 10          	shl    $0x10,%rdx
    c53c:	48 39 d0             	cmp    %rdx,%rax
    c53f:	73 59                	jae    c59a <f0+0x1c6a>
    c541:	48 89 c2             	mov    %rax,%rdx
    c544:	48 c1 ea 10          	shr    $0x10,%rdx
    c548:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c54c:	48 8b 15 05 76 01 00 	mov    0x17605(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c553:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c557:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c55b:	4d 85 e4             	test   %r12,%r12
    c55e:	74 3a                	je     c59a <f0+0x1c6a>
    c560:	0f b6 0a             	movzbl (%rdx),%ecx
    c563:	80 f9 02             	cmp    $0x2,%cl
    c566:	0f 84 84 0c 00 00    	je     d1f0 <f0+0x28c0>
    c56c:	80 f9 01             	cmp    $0x1,%cl
    c56f:	75 29                	jne    c59a <f0+0x1c6a>
    c571:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c574:	0f b7 c0             	movzwl %ax,%eax
    c577:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c57a:	48 0f af c1          	imul   %rcx,%rax
    c57e:	48 c1 e8 20          	shr    $0x20,%rax
    c582:	48 39 d0             	cmp    %rdx,%rax
    c585:	73 13                	jae    c59a <f0+0x1c6a>
    c587:	49 01 c4             	add    %rax,%r12
    c58a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c58f:	0f 84 9d 0f 00 00    	je     d532 <f0+0x2c02>
    c595:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c59a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c5a1:	33 f3 bf 
    c5a4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    c5ab:	00 
    c5ac:	bf 01 00 00 00       	mov    $0x1,%edi
    c5b1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    c5b8:	00 
    c5b9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    c5c0:	00 
    c5c1:	e8 aa 95 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c5c6:	48 8b 15 6b 75 01 00 	mov    0x1756b(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c5cd:	49 89 c5             	mov    %rax,%r13
    c5d0:	48 2b 05 39 75 01 00 	sub    0x17539(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c5d7:	48 c1 e2 10          	shl    $0x10,%rdx
    c5db:	48 39 d0             	cmp    %rdx,%rax
    c5de:	73 59                	jae    c639 <f0+0x1d09>
    c5e0:	48 89 c2             	mov    %rax,%rdx
    c5e3:	48 c1 ea 10          	shr    $0x10,%rdx
    c5e7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5eb:	48 8b 15 66 75 01 00 	mov    0x17566(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c5f2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5f6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5fa:	4d 85 e4             	test   %r12,%r12
    c5fd:	74 3a                	je     c639 <f0+0x1d09>
    c5ff:	0f b6 0a             	movzbl (%rdx),%ecx
    c602:	80 f9 02             	cmp    $0x2,%cl
    c605:	0f 84 d5 0b 00 00    	je     d1e0 <f0+0x28b0>
    c60b:	80 f9 01             	cmp    $0x1,%cl
    c60e:	75 29                	jne    c639 <f0+0x1d09>
    c610:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c613:	0f b7 c0             	movzwl %ax,%eax
    c616:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c619:	48 0f af c1          	imul   %rcx,%rax
    c61d:	48 c1 e8 20          	shr    $0x20,%rax
    c621:	48 39 d0             	cmp    %rdx,%rax
    c624:	73 13                	jae    c639 <f0+0x1d09>
    c626:	49 01 c4             	add    %rax,%r12
    c629:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c62e:	0f 84 0b 0f 00 00    	je     d53f <f0+0x2c0f>
    c634:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c639:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c640:	00 f0 3f 
    c643:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    c64a:	00 
    c64b:	bf 01 00 00 00       	mov    $0x1,%edi
    c650:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    c657:	00 
    c658:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    c65f:	00 
    c660:	e8 0b 95 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c665:	48 8b 15 cc 74 01 00 	mov    0x174cc(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c66c:	49 89 c5             	mov    %rax,%r13
    c66f:	48 2b 05 9a 74 01 00 	sub    0x1749a(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c676:	48 c1 e2 10          	shl    $0x10,%rdx
    c67a:	48 39 d0             	cmp    %rdx,%rax
    c67d:	73 59                	jae    c6d8 <f0+0x1da8>
    c67f:	48 89 c2             	mov    %rax,%rdx
    c682:	48 c1 ea 10          	shr    $0x10,%rdx
    c686:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c68a:	48 8b 15 c7 74 01 00 	mov    0x174c7(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c691:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c695:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c699:	4d 85 e4             	test   %r12,%r12
    c69c:	74 3a                	je     c6d8 <f0+0x1da8>
    c69e:	0f b6 0a             	movzbl (%rdx),%ecx
    c6a1:	80 f9 02             	cmp    $0x2,%cl
    c6a4:	0f 84 26 0b 00 00    	je     d1d0 <f0+0x28a0>
    c6aa:	80 f9 01             	cmp    $0x1,%cl
    c6ad:	75 29                	jne    c6d8 <f0+0x1da8>
    c6af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c6b2:	0f b7 c0             	movzwl %ax,%eax
    c6b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c6b8:	48 0f af c1          	imul   %rcx,%rax
    c6bc:	48 c1 e8 20          	shr    $0x20,%rax
    c6c0:	48 39 d0             	cmp    %rdx,%rax
    c6c3:	73 13                	jae    c6d8 <f0+0x1da8>
    c6c5:	49 01 c4             	add    %rax,%r12
    c6c8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6cd:	0f 84 79 0e 00 00    	je     d54c <f0+0x2c1c>
    c6d3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6d8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c6df:	33 f3 bf 
    c6e2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    c6e9:	00 
    c6ea:	bf 01 00 00 00       	mov    $0x1,%edi
    c6ef:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    c6f6:	00 
    c6f7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    c6fe:	00 
    c6ff:	e8 6c 94 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c704:	48 8b 15 2d 74 01 00 	mov    0x1742d(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c70b:	49 89 c5             	mov    %rax,%r13
    c70e:	48 2b 05 fb 73 01 00 	sub    0x173fb(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c715:	48 c1 e2 10          	shl    $0x10,%rdx
    c719:	48 39 d0             	cmp    %rdx,%rax
    c71c:	73 59                	jae    c777 <f0+0x1e47>
    c71e:	48 89 c2             	mov    %rax,%rdx
    c721:	48 c1 ea 10          	shr    $0x10,%rdx
    c725:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c729:	48 8b 15 28 74 01 00 	mov    0x17428(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c730:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c734:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c738:	4d 85 e4             	test   %r12,%r12
    c73b:	74 3a                	je     c777 <f0+0x1e47>
    c73d:	0f b6 0a             	movzbl (%rdx),%ecx
    c740:	80 f9 02             	cmp    $0x2,%cl
    c743:	0f 84 77 0a 00 00    	je     d1c0 <f0+0x2890>
    c749:	80 f9 01             	cmp    $0x1,%cl
    c74c:	75 29                	jne    c777 <f0+0x1e47>
    c74e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c751:	0f b7 c0             	movzwl %ax,%eax
    c754:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c757:	48 0f af c1          	imul   %rcx,%rax
    c75b:	48 c1 e8 20          	shr    $0x20,%rax
    c75f:	48 39 d0             	cmp    %rdx,%rax
    c762:	73 13                	jae    c777 <f0+0x1e47>
    c764:	49 01 c4             	add    %rax,%r12
    c767:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c76c:	0f 84 e7 0d 00 00    	je     d559 <f0+0x2c29>
    c772:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c777:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c77e:	00 f0 3f 
    c781:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    c788:	00 
    c789:	bf 01 00 00 00       	mov    $0x1,%edi
    c78e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    c795:	00 
    c796:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    c79d:	00 
    c79e:	e8 cd 93 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c7a3:	48 8b 15 8e 73 01 00 	mov    0x1738e(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c7aa:	49 89 c5             	mov    %rax,%r13
    c7ad:	48 2b 05 5c 73 01 00 	sub    0x1735c(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c7b4:	48 c1 e2 10          	shl    $0x10,%rdx
    c7b8:	48 39 d0             	cmp    %rdx,%rax
    c7bb:	73 59                	jae    c816 <f0+0x1ee6>
    c7bd:	48 89 c2             	mov    %rax,%rdx
    c7c0:	48 c1 ea 10          	shr    $0x10,%rdx
    c7c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7c8:	48 8b 15 89 73 01 00 	mov    0x17389(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c7cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7d3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7d7:	4d 85 e4             	test   %r12,%r12
    c7da:	74 3a                	je     c816 <f0+0x1ee6>
    c7dc:	0f b6 0a             	movzbl (%rdx),%ecx
    c7df:	80 f9 02             	cmp    $0x2,%cl
    c7e2:	0f 84 38 0c 00 00    	je     d420 <f0+0x2af0>
    c7e8:	80 f9 01             	cmp    $0x1,%cl
    c7eb:	75 29                	jne    c816 <f0+0x1ee6>
    c7ed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7f0:	0f b7 c0             	movzwl %ax,%eax
    c7f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7f6:	48 0f af c1          	imul   %rcx,%rax
    c7fa:	48 c1 e8 20          	shr    $0x20,%rax
    c7fe:	48 39 d0             	cmp    %rdx,%rax
    c801:	73 13                	jae    c816 <f0+0x1ee6>
    c803:	49 01 c4             	add    %rax,%r12
    c806:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c80b:	0f 84 55 0d 00 00    	je     d566 <f0+0x2c36>
    c811:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c816:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c81d:	33 f3 bf 
    c820:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    c827:	00 
    c828:	bf 01 00 00 00       	mov    $0x1,%edi
    c82d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    c834:	00 
    c835:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    c83c:	00 
    c83d:	e8 2e 93 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c842:	48 8b 15 ef 72 01 00 	mov    0x172ef(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c849:	49 89 c5             	mov    %rax,%r13
    c84c:	48 2b 05 bd 72 01 00 	sub    0x172bd(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c853:	48 c1 e2 10          	shl    $0x10,%rdx
    c857:	48 39 d0             	cmp    %rdx,%rax
    c85a:	73 59                	jae    c8b5 <f0+0x1f85>
    c85c:	48 89 c2             	mov    %rax,%rdx
    c85f:	48 c1 ea 10          	shr    $0x10,%rdx
    c863:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c867:	48 8b 15 ea 72 01 00 	mov    0x172ea(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c86e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c872:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c876:	4d 85 e4             	test   %r12,%r12
    c879:	74 3a                	je     c8b5 <f0+0x1f85>
    c87b:	0f b6 0a             	movzbl (%rdx),%ecx
    c87e:	80 f9 02             	cmp    $0x2,%cl
    c881:	0f 84 89 0b 00 00    	je     d410 <f0+0x2ae0>
    c887:	80 f9 01             	cmp    $0x1,%cl
    c88a:	75 29                	jne    c8b5 <f0+0x1f85>
    c88c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c88f:	0f b7 c0             	movzwl %ax,%eax
    c892:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c895:	48 0f af c1          	imul   %rcx,%rax
    c899:	48 c1 e8 20          	shr    $0x20,%rax
    c89d:	48 39 d0             	cmp    %rdx,%rax
    c8a0:	73 13                	jae    c8b5 <f0+0x1f85>
    c8a2:	49 01 c4             	add    %rax,%r12
    c8a5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8aa:	0f 84 c3 0c 00 00    	je     d573 <f0+0x2c43>
    c8b0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8b5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c8bc:	00 f0 3f 
    c8bf:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    c8c6:	00 
    c8c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c8cc:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    c8d3:	00 
    c8d4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    c8db:	00 
    c8dc:	e8 8f 92 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c8e1:	48 8b 15 50 72 01 00 	mov    0x17250(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c8e8:	49 89 c5             	mov    %rax,%r13
    c8eb:	48 2b 05 1e 72 01 00 	sub    0x1721e(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c8f2:	48 c1 e2 10          	shl    $0x10,%rdx
    c8f6:	48 39 d0             	cmp    %rdx,%rax
    c8f9:	73 59                	jae    c954 <f0+0x2024>
    c8fb:	48 89 c2             	mov    %rax,%rdx
    c8fe:	48 c1 ea 10          	shr    $0x10,%rdx
    c902:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c906:	48 8b 15 4b 72 01 00 	mov    0x1724b(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c90d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c911:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c915:	4d 85 e4             	test   %r12,%r12
    c918:	74 3a                	je     c954 <f0+0x2024>
    c91a:	0f b6 0a             	movzbl (%rdx),%ecx
    c91d:	80 f9 02             	cmp    $0x2,%cl
    c920:	0f 84 da 0a 00 00    	je     d400 <f0+0x2ad0>
    c926:	80 f9 01             	cmp    $0x1,%cl
    c929:	75 29                	jne    c954 <f0+0x2024>
    c92b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c92e:	0f b7 c0             	movzwl %ax,%eax
    c931:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c934:	48 0f af c1          	imul   %rcx,%rax
    c938:	48 c1 e8 20          	shr    $0x20,%rax
    c93c:	48 39 d0             	cmp    %rdx,%rax
    c93f:	73 13                	jae    c954 <f0+0x2024>
    c941:	49 01 c4             	add    %rax,%r12
    c944:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c949:	0f 84 31 0c 00 00    	je     d580 <f0+0x2c50>
    c94f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c954:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c95b:	33 f3 bf 
    c95e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    c965:	00 
    c966:	bf 01 00 00 00       	mov    $0x1,%edi
    c96b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    c972:	00 
    c973:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    c97a:	00 
    c97b:	e8 f0 91 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c980:	48 8b 15 b1 71 01 00 	mov    0x171b1(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    c987:	49 89 c5             	mov    %rax,%r13
    c98a:	48 2b 05 7f 71 01 00 	sub    0x1717f(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    c991:	48 c1 e2 10          	shl    $0x10,%rdx
    c995:	48 39 d0             	cmp    %rdx,%rax
    c998:	73 59                	jae    c9f3 <f0+0x20c3>
    c99a:	48 89 c2             	mov    %rax,%rdx
    c99d:	48 c1 ea 10          	shr    $0x10,%rdx
    c9a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9a5:	48 8b 15 ac 71 01 00 	mov    0x171ac(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    c9ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9b0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9b4:	4d 85 e4             	test   %r12,%r12
    c9b7:	74 3a                	je     c9f3 <f0+0x20c3>
    c9b9:	0f b6 0a             	movzbl (%rdx),%ecx
    c9bc:	80 f9 02             	cmp    $0x2,%cl
    c9bf:	0f 84 2b 0a 00 00    	je     d3f0 <f0+0x2ac0>
    c9c5:	80 f9 01             	cmp    $0x1,%cl
    c9c8:	75 29                	jne    c9f3 <f0+0x20c3>
    c9ca:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9cd:	0f b7 c0             	movzwl %ax,%eax
    c9d0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9d3:	48 0f af c1          	imul   %rcx,%rax
    c9d7:	48 c1 e8 20          	shr    $0x20,%rax
    c9db:	48 39 d0             	cmp    %rdx,%rax
    c9de:	73 13                	jae    c9f3 <f0+0x20c3>
    c9e0:	49 01 c4             	add    %rax,%r12
    c9e3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9e8:	0f 84 9f 0b 00 00    	je     d58d <f0+0x2c5d>
    c9ee:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9f3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9fa:	00 f0 3f 
    c9fd:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    ca04:	00 
    ca05:	bf 01 00 00 00       	mov    $0x1,%edi
    ca0a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    ca11:	00 
    ca12:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    ca19:	00 
    ca1a:	e8 51 91 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ca1f:	48 8b 15 12 71 01 00 	mov    0x17112(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    ca26:	49 89 c5             	mov    %rax,%r13
    ca29:	48 2b 05 e0 70 01 00 	sub    0x170e0(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ca30:	48 c1 e2 10          	shl    $0x10,%rdx
    ca34:	48 39 d0             	cmp    %rdx,%rax
    ca37:	73 59                	jae    ca92 <f0+0x2162>
    ca39:	48 89 c2             	mov    %rax,%rdx
    ca3c:	48 c1 ea 10          	shr    $0x10,%rdx
    ca40:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca44:	48 8b 15 0d 71 01 00 	mov    0x1710d(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ca4b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca4f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca53:	4d 85 e4             	test   %r12,%r12
    ca56:	74 3a                	je     ca92 <f0+0x2162>
    ca58:	0f b6 0a             	movzbl (%rdx),%ecx
    ca5b:	80 f9 02             	cmp    $0x2,%cl
    ca5e:	0f 84 7c 09 00 00    	je     d3e0 <f0+0x2ab0>
    ca64:	80 f9 01             	cmp    $0x1,%cl
    ca67:	75 29                	jne    ca92 <f0+0x2162>
    ca69:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca6c:	0f b7 c0             	movzwl %ax,%eax
    ca6f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca72:	48 0f af c1          	imul   %rcx,%rax
    ca76:	48 c1 e8 20          	shr    $0x20,%rax
    ca7a:	48 39 d0             	cmp    %rdx,%rax
    ca7d:	73 13                	jae    ca92 <f0+0x2162>
    ca7f:	49 01 c4             	add    %rax,%r12
    ca82:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca87:	0f 84 0d 0b 00 00    	je     d59a <f0+0x2c6a>
    ca8d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca92:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca99:	33 f3 bf 
    ca9c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    caa3:	00 
    caa4:	bf 01 00 00 00       	mov    $0x1,%edi
    caa9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    cab0:	00 
    cab1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    cab8:	00 
    cab9:	e8 b2 90 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cabe:	48 8b 15 73 70 01 00 	mov    0x17073(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cac5:	49 89 c5             	mov    %rax,%r13
    cac8:	48 2b 05 41 70 01 00 	sub    0x17041(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cacf:	48 c1 e2 10          	shl    $0x10,%rdx
    cad3:	48 39 d0             	cmp    %rdx,%rax
    cad6:	73 59                	jae    cb31 <f0+0x2201>
    cad8:	48 89 c2             	mov    %rax,%rdx
    cadb:	48 c1 ea 10          	shr    $0x10,%rdx
    cadf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cae3:	48 8b 15 6e 70 01 00 	mov    0x1706e(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    caea:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    caee:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    caf2:	4d 85 e4             	test   %r12,%r12
    caf5:	74 3a                	je     cb31 <f0+0x2201>
    caf7:	0f b6 0a             	movzbl (%rdx),%ecx
    cafa:	80 f9 02             	cmp    $0x2,%cl
    cafd:	0f 84 cd 08 00 00    	je     d3d0 <f0+0x2aa0>
    cb03:	80 f9 01             	cmp    $0x1,%cl
    cb06:	75 29                	jne    cb31 <f0+0x2201>
    cb08:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb0b:	0f b7 c0             	movzwl %ax,%eax
    cb0e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb11:	48 0f af c1          	imul   %rcx,%rax
    cb15:	48 c1 e8 20          	shr    $0x20,%rax
    cb19:	48 39 d0             	cmp    %rdx,%rax
    cb1c:	73 13                	jae    cb31 <f0+0x2201>
    cb1e:	49 01 c4             	add    %rax,%r12
    cb21:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb26:	0f 84 7b 0a 00 00    	je     d5a7 <f0+0x2c77>
    cb2c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb31:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb38:	00 f0 3f 
    cb3b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    cb42:	00 
    cb43:	bf 01 00 00 00       	mov    $0x1,%edi
    cb48:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    cb4f:	00 
    cb50:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    cb57:	00 
    cb58:	e8 13 90 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cb5d:	48 8b 15 d4 6f 01 00 	mov    0x16fd4(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cb64:	49 89 c5             	mov    %rax,%r13
    cb67:	48 2b 05 a2 6f 01 00 	sub    0x16fa2(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cb6e:	48 c1 e2 10          	shl    $0x10,%rdx
    cb72:	48 39 d0             	cmp    %rdx,%rax
    cb75:	73 59                	jae    cbd0 <f0+0x22a0>
    cb77:	48 89 c2             	mov    %rax,%rdx
    cb7a:	48 c1 ea 10          	shr    $0x10,%rdx
    cb7e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb82:	48 8b 15 cf 6f 01 00 	mov    0x16fcf(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cb89:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb8d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb91:	4d 85 e4             	test   %r12,%r12
    cb94:	74 3a                	je     cbd0 <f0+0x22a0>
    cb96:	0f b6 0a             	movzbl (%rdx),%ecx
    cb99:	80 f9 02             	cmp    $0x2,%cl
    cb9c:	0f 84 1e 08 00 00    	je     d3c0 <f0+0x2a90>
    cba2:	80 f9 01             	cmp    $0x1,%cl
    cba5:	75 29                	jne    cbd0 <f0+0x22a0>
    cba7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbaa:	0f b7 c0             	movzwl %ax,%eax
    cbad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbb0:	48 0f af c1          	imul   %rcx,%rax
    cbb4:	48 c1 e8 20          	shr    $0x20,%rax
    cbb8:	48 39 d0             	cmp    %rdx,%rax
    cbbb:	73 13                	jae    cbd0 <f0+0x22a0>
    cbbd:	49 01 c4             	add    %rax,%r12
    cbc0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cbc5:	0f 84 e9 09 00 00    	je     d5b4 <f0+0x2c84>
    cbcb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbd0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbd7:	33 f3 bf 
    cbda:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    cbe1:	00 
    cbe2:	bf 01 00 00 00       	mov    $0x1,%edi
    cbe7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    cbee:	00 
    cbef:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    cbf6:	00 
    cbf7:	e8 74 8f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cbfc:	48 8b 15 35 6f 01 00 	mov    0x16f35(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cc03:	49 89 c5             	mov    %rax,%r13
    cc06:	48 2b 05 03 6f 01 00 	sub    0x16f03(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cc0d:	48 c1 e2 10          	shl    $0x10,%rdx
    cc11:	48 39 d0             	cmp    %rdx,%rax
    cc14:	73 59                	jae    cc6f <f0+0x233f>
    cc16:	48 89 c2             	mov    %rax,%rdx
    cc19:	48 c1 ea 10          	shr    $0x10,%rdx
    cc1d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc21:	48 8b 15 30 6f 01 00 	mov    0x16f30(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cc28:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc2c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc30:	4d 85 e4             	test   %r12,%r12
    cc33:	74 3a                	je     cc6f <f0+0x233f>
    cc35:	0f b6 0a             	movzbl (%rdx),%ecx
    cc38:	80 f9 02             	cmp    $0x2,%cl
    cc3b:	0f 84 6f 07 00 00    	je     d3b0 <f0+0x2a80>
    cc41:	80 f9 01             	cmp    $0x1,%cl
    cc44:	75 29                	jne    cc6f <f0+0x233f>
    cc46:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc49:	0f b7 c0             	movzwl %ax,%eax
    cc4c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc4f:	48 0f af c1          	imul   %rcx,%rax
    cc53:	48 c1 e8 20          	shr    $0x20,%rax
    cc57:	48 39 d0             	cmp    %rdx,%rax
    cc5a:	73 13                	jae    cc6f <f0+0x233f>
    cc5c:	49 01 c4             	add    %rax,%r12
    cc5f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc64:	0f 84 57 09 00 00    	je     d5c1 <f0+0x2c91>
    cc6a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc6f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc76:	00 f0 3f 
    cc79:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    cc80:	00 
    cc81:	bf 01 00 00 00       	mov    $0x1,%edi
    cc86:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    cc8d:	00 
    cc8e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    cc95:	00 
    cc96:	e8 d5 8e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cc9b:	48 8b 15 96 6e 01 00 	mov    0x16e96(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cca2:	49 89 c5             	mov    %rax,%r13
    cca5:	48 2b 05 64 6e 01 00 	sub    0x16e64(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ccac:	48 c1 e2 10          	shl    $0x10,%rdx
    ccb0:	48 39 d0             	cmp    %rdx,%rax
    ccb3:	73 59                	jae    cd0e <f0+0x23de>
    ccb5:	48 89 c2             	mov    %rax,%rdx
    ccb8:	48 c1 ea 10          	shr    $0x10,%rdx
    ccbc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ccc0:	48 8b 15 91 6e 01 00 	mov    0x16e91(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ccc7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cccb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cccf:	4d 85 e4             	test   %r12,%r12
    ccd2:	74 3a                	je     cd0e <f0+0x23de>
    ccd4:	0f b6 0a             	movzbl (%rdx),%ecx
    ccd7:	80 f9 02             	cmp    $0x2,%cl
    ccda:	0f 84 c0 06 00 00    	je     d3a0 <f0+0x2a70>
    cce0:	80 f9 01             	cmp    $0x1,%cl
    cce3:	75 29                	jne    cd0e <f0+0x23de>
    cce5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cce8:	0f b7 c0             	movzwl %ax,%eax
    cceb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccee:	48 0f af c1          	imul   %rcx,%rax
    ccf2:	48 c1 e8 20          	shr    $0x20,%rax
    ccf6:	48 39 d0             	cmp    %rdx,%rax
    ccf9:	73 13                	jae    cd0e <f0+0x23de>
    ccfb:	49 01 c4             	add    %rax,%r12
    ccfe:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd03:	0f 84 c5 08 00 00    	je     d5ce <f0+0x2c9e>
    cd09:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd0e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd15:	33 f3 bf 
    cd18:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    cd1f:	00 
    cd20:	bf 01 00 00 00       	mov    $0x1,%edi
    cd25:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    cd2c:	00 
    cd2d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    cd34:	00 
    cd35:	e8 36 8e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cd3a:	48 8b 15 f7 6d 01 00 	mov    0x16df7(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cd41:	49 89 c5             	mov    %rax,%r13
    cd44:	48 2b 05 c5 6d 01 00 	sub    0x16dc5(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cd4b:	48 c1 e2 10          	shl    $0x10,%rdx
    cd4f:	48 39 d0             	cmp    %rdx,%rax
    cd52:	73 59                	jae    cdad <f0+0x247d>
    cd54:	48 89 c2             	mov    %rax,%rdx
    cd57:	48 c1 ea 10          	shr    $0x10,%rdx
    cd5b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd5f:	48 8b 15 f2 6d 01 00 	mov    0x16df2(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cd66:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd6a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd6e:	4d 85 e4             	test   %r12,%r12
    cd71:	74 3a                	je     cdad <f0+0x247d>
    cd73:	0f b6 0a             	movzbl (%rdx),%ecx
    cd76:	80 f9 02             	cmp    $0x2,%cl
    cd79:	0f 84 11 06 00 00    	je     d390 <f0+0x2a60>
    cd7f:	80 f9 01             	cmp    $0x1,%cl
    cd82:	75 29                	jne    cdad <f0+0x247d>
    cd84:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd87:	0f b7 c0             	movzwl %ax,%eax
    cd8a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd8d:	48 0f af c1          	imul   %rcx,%rax
    cd91:	48 c1 e8 20          	shr    $0x20,%rax
    cd95:	48 39 d0             	cmp    %rdx,%rax
    cd98:	73 13                	jae    cdad <f0+0x247d>
    cd9a:	49 01 c4             	add    %rax,%r12
    cd9d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cda2:	0f 84 33 08 00 00    	je     d5db <f0+0x2cab>
    cda8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdad:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdb4:	00 f0 3f 
    cdb7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    cdbe:	00 
    cdbf:	bf 01 00 00 00       	mov    $0x1,%edi
    cdc4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    cdcb:	00 
    cdcc:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    cdd3:	00 
    cdd4:	e8 97 8d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cdd9:	48 8b 15 58 6d 01 00 	mov    0x16d58(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cde0:	49 89 c5             	mov    %rax,%r13
    cde3:	48 2b 05 26 6d 01 00 	sub    0x16d26(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cdea:	48 c1 e2 10          	shl    $0x10,%rdx
    cdee:	48 39 d0             	cmp    %rdx,%rax
    cdf1:	73 59                	jae    ce4c <f0+0x251c>
    cdf3:	48 89 c2             	mov    %rax,%rdx
    cdf6:	48 c1 ea 10          	shr    $0x10,%rdx
    cdfa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdfe:	48 8b 15 53 6d 01 00 	mov    0x16d53(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    ce05:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce09:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce0d:	4d 85 e4             	test   %r12,%r12
    ce10:	74 3a                	je     ce4c <f0+0x251c>
    ce12:	0f b6 0a             	movzbl (%rdx),%ecx
    ce15:	80 f9 02             	cmp    $0x2,%cl
    ce18:	0f 84 62 05 00 00    	je     d380 <f0+0x2a50>
    ce1e:	80 f9 01             	cmp    $0x1,%cl
    ce21:	75 29                	jne    ce4c <f0+0x251c>
    ce23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce26:	0f b7 c0             	movzwl %ax,%eax
    ce29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce2c:	48 0f af c1          	imul   %rcx,%rax
    ce30:	48 c1 e8 20          	shr    $0x20,%rax
    ce34:	48 39 d0             	cmp    %rdx,%rax
    ce37:	73 13                	jae    ce4c <f0+0x251c>
    ce39:	49 01 c4             	add    %rax,%r12
    ce3c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce41:	0f 84 a1 07 00 00    	je     d5e8 <f0+0x2cb8>
    ce47:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce4c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce53:	33 f3 bf 
    ce56:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    ce5d:	00 
    ce5e:	bf 01 00 00 00       	mov    $0x1,%edi
    ce63:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    ce6a:	00 
    ce6b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    ce72:	00 
    ce73:	e8 f8 8c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ce78:	48 8b 15 b9 6c 01 00 	mov    0x16cb9(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    ce7f:	49 89 c5             	mov    %rax,%r13
    ce82:	48 2b 05 87 6c 01 00 	sub    0x16c87(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    ce89:	48 c1 e2 10          	shl    $0x10,%rdx
    ce8d:	48 39 d0             	cmp    %rdx,%rax
    ce90:	73 59                	jae    ceeb <f0+0x25bb>
    ce92:	48 89 c2             	mov    %rax,%rdx
    ce95:	48 c1 ea 10          	shr    $0x10,%rdx
    ce99:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce9d:	48 8b 15 b4 6c 01 00 	mov    0x16cb4(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cea4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cea8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ceac:	4d 85 e4             	test   %r12,%r12
    ceaf:	74 3a                	je     ceeb <f0+0x25bb>
    ceb1:	0f b6 0a             	movzbl (%rdx),%ecx
    ceb4:	80 f9 02             	cmp    $0x2,%cl
    ceb7:	0f 84 b3 04 00 00    	je     d370 <f0+0x2a40>
    cebd:	80 f9 01             	cmp    $0x1,%cl
    cec0:	75 29                	jne    ceeb <f0+0x25bb>
    cec2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cec5:	0f b7 c0             	movzwl %ax,%eax
    cec8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cecb:	48 0f af c1          	imul   %rcx,%rax
    cecf:	48 c1 e8 20          	shr    $0x20,%rax
    ced3:	48 39 d0             	cmp    %rdx,%rax
    ced6:	73 13                	jae    ceeb <f0+0x25bb>
    ced8:	49 01 c4             	add    %rax,%r12
    cedb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cee0:	0f 84 0f 07 00 00    	je     d5f5 <f0+0x2cc5>
    cee6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ceeb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cef2:	00 f0 3f 
    cef5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    cefc:	00 
    cefd:	bf 01 00 00 00       	mov    $0x1,%edi
    cf02:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    cf09:	00 
    cf0a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    cf11:	00 
    cf12:	e8 59 8c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cf17:	48 8b 15 1a 6c 01 00 	mov    0x16c1a(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cf1e:	49 89 c5             	mov    %rax,%r13
    cf21:	48 2b 05 e8 6b 01 00 	sub    0x16be8(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cf28:	48 c1 e2 10          	shl    $0x10,%rdx
    cf2c:	48 39 d0             	cmp    %rdx,%rax
    cf2f:	73 59                	jae    cf8a <f0+0x265a>
    cf31:	48 89 c2             	mov    %rax,%rdx
    cf34:	48 c1 ea 10          	shr    $0x10,%rdx
    cf38:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf3c:	48 8b 15 15 6c 01 00 	mov    0x16c15(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cf43:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf47:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf4b:	4d 85 e4             	test   %r12,%r12
    cf4e:	74 3a                	je     cf8a <f0+0x265a>
    cf50:	0f b6 0a             	movzbl (%rdx),%ecx
    cf53:	80 f9 02             	cmp    $0x2,%cl
    cf56:	0f 84 04 04 00 00    	je     d360 <f0+0x2a30>
    cf5c:	80 f9 01             	cmp    $0x1,%cl
    cf5f:	75 29                	jne    cf8a <f0+0x265a>
    cf61:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf64:	0f b7 c0             	movzwl %ax,%eax
    cf67:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf6a:	48 0f af c1          	imul   %rcx,%rax
    cf6e:	48 c1 e8 20          	shr    $0x20,%rax
    cf72:	48 39 d0             	cmp    %rdx,%rax
    cf75:	73 13                	jae    cf8a <f0+0x265a>
    cf77:	49 01 c4             	add    %rax,%r12
    cf7a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf7f:	0f 84 7d 06 00 00    	je     d602 <f0+0x2cd2>
    cf85:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf8a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf91:	33 f3 bf 
    cf94:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    cf9b:	00 
    cf9c:	bf 01 00 00 00       	mov    $0x1,%edi
    cfa1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    cfa8:	00 
    cfa9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    cfb0:	00 
    cfb1:	e8 ba 8b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cfb6:	48 8b 15 7b 6b 01 00 	mov    0x16b7b(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    cfbd:	49 89 c5             	mov    %rax,%r13
    cfc0:	48 2b 05 49 6b 01 00 	sub    0x16b49(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    cfc7:	48 c1 e2 10          	shl    $0x10,%rdx
    cfcb:	48 39 d0             	cmp    %rdx,%rax
    cfce:	73 59                	jae    d029 <f0+0x26f9>
    cfd0:	48 89 c2             	mov    %rax,%rdx
    cfd3:	48 c1 ea 10          	shr    $0x10,%rdx
    cfd7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfdb:	48 8b 15 76 6b 01 00 	mov    0x16b76(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    cfe2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfe6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfea:	4d 85 e4             	test   %r12,%r12
    cfed:	74 3a                	je     d029 <f0+0x26f9>
    cfef:	0f b6 0a             	movzbl (%rdx),%ecx
    cff2:	80 f9 02             	cmp    $0x2,%cl
    cff5:	0f 84 55 03 00 00    	je     d350 <f0+0x2a20>
    cffb:	80 f9 01             	cmp    $0x1,%cl
    cffe:	75 29                	jne    d029 <f0+0x26f9>
    d000:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d003:	0f b7 c0             	movzwl %ax,%eax
    d006:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d009:	48 0f af c1          	imul   %rcx,%rax
    d00d:	48 c1 e8 20          	shr    $0x20,%rax
    d011:	48 39 d0             	cmp    %rdx,%rax
    d014:	73 13                	jae    d029 <f0+0x26f9>
    d016:	49 01 c4             	add    %rax,%r12
    d019:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d01e:	0f 84 eb 05 00 00    	je     d60f <f0+0x2cdf>
    d024:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d029:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d030:	00 f0 3f 
    d033:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d03a:	00 
    d03b:	bf 01 00 00 00       	mov    $0x1,%edi
    d040:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d047:	00 
    d048:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d04f:	00 
    d050:	e8 1b 8b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d055:	48 8b 15 dc 6a 01 00 	mov    0x16adc(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    d05c:	49 89 c5             	mov    %rax,%r13
    d05f:	48 2b 05 aa 6a 01 00 	sub    0x16aaa(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    d066:	48 c1 e2 10          	shl    $0x10,%rdx
    d06a:	48 39 d0             	cmp    %rdx,%rax
    d06d:	73 59                	jae    d0c8 <f0+0x2798>
    d06f:	48 89 c2             	mov    %rax,%rdx
    d072:	48 c1 ea 10          	shr    $0x10,%rdx
    d076:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d07a:	48 8b 15 d7 6a 01 00 	mov    0x16ad7(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    d081:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d085:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d089:	4d 85 e4             	test   %r12,%r12
    d08c:	74 3a                	je     d0c8 <f0+0x2798>
    d08e:	0f b6 0a             	movzbl (%rdx),%ecx
    d091:	80 f9 02             	cmp    $0x2,%cl
    d094:	0f 84 a6 02 00 00    	je     d340 <f0+0x2a10>
    d09a:	80 f9 01             	cmp    $0x1,%cl
    d09d:	75 29                	jne    d0c8 <f0+0x2798>
    d09f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0a2:	0f b7 c0             	movzwl %ax,%eax
    d0a5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0a8:	48 0f af c1          	imul   %rcx,%rax
    d0ac:	48 c1 e8 20          	shr    $0x20,%rax
    d0b0:	48 39 d0             	cmp    %rdx,%rax
    d0b3:	73 13                	jae    d0c8 <f0+0x2798>
    d0b5:	49 01 c4             	add    %rax,%r12
    d0b8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0bd:	0f 84 59 05 00 00    	je     d61c <f0+0x2cec>
    d0c3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0c8:	48 89 ee             	mov    %rbp,%rsi
    d0cb:	bf 01 00 00 00       	mov    $0x1,%edi
    d0d0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0d7:	33 f3 bf 
    d0da:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d0e1:	00 
    d0e2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d0e9:	00 
    d0ea:	e8 81 8a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d0ef:	48 8b 15 42 6a 01 00 	mov    0x16a42(%rip),%rdx        # 23b38 <fwp_heap+0x13d8>
    d0f6:	48 89 c5             	mov    %rax,%rbp
    d0f9:	48 2b 05 10 6a 01 00 	sub    0x16a10(%rip),%rax        # 23b10 <fwp_heap+0x13b0>
    d100:	48 c1 e2 10          	shl    $0x10,%rdx
    d104:	48 39 d0             	cmp    %rdx,%rax
    d107:	73 59                	jae    d162 <f0+0x2832>
    d109:	48 89 c2             	mov    %rax,%rdx
    d10c:	48 c1 ea 10          	shr    $0x10,%rdx
    d110:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d114:	48 8b 15 3d 6a 01 00 	mov    0x16a3d(%rip),%rdx        # 23b58 <fwp_heap+0x13f8>
    d11b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d11f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d123:	4d 85 e4             	test   %r12,%r12
    d126:	74 3a                	je     d162 <f0+0x2832>
    d128:	0f b6 0a             	movzbl (%rdx),%ecx
    d12b:	80 f9 02             	cmp    $0x2,%cl
    d12e:	0f 84 fc 01 00 00    	je     d330 <f0+0x2a00>
    d134:	80 f9 01             	cmp    $0x1,%cl
    d137:	75 29                	jne    d162 <f0+0x2832>
    d139:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d13c:	0f b7 c0             	movzwl %ax,%eax
    d13f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d142:	48 0f af c1          	imul   %rcx,%rax
    d146:	48 c1 e8 20          	shr    $0x20,%rax
    d14a:	48 39 d0             	cmp    %rdx,%rax
    d14d:	73 13                	jae    d162 <f0+0x2832>
    d14f:	49 01 c4             	add    %rax,%r12
    d152:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d157:	0f 84 d1 02 00 00    	je     d42e <f0+0x2afe>
    d15d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d162:	48 89 de             	mov    %rbx,%rsi
    d165:	48 89 ef             	mov    %rbp,%rdi
    d168:	e8 d3 be ff ff       	call   9040 <fwp_hof0.constprop.0>
    d16d:	48 89 ef             	mov    %rbp,%rdi
    d170:	e8 4b a3 ff ff       	call   74c0 <fwp_drop0>
    d175:	48 89 df             	mov    %rbx,%rdi
    d178:	e8 43 a3 ff ff       	call   74c0 <fwp_drop0>
    d17d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d184:	00 
    d185:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d18c:	00 00 
    d18e:	0f 85 95 04 00 00    	jne    d629 <f0+0x2cf9>
    d194:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d19b:	31 c0                	xor    %eax,%eax
    d19d:	5b                   	pop    %rbx
    d19e:	5d                   	pop    %rbp
    d19f:	41 5c                	pop    %r12
    d1a1:	41 5d                	pop    %r13
    d1a3:	41 5e                	pop    %r14
    d1a5:	c3                   	ret
    d1a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d1ad:	00 00 00 
    d1b0:	4c 89 ef             	mov    %r13,%rdi
    d1b3:	e8 58 81 ff ff       	call   5310 <fwp_rc_forget_slot>
    d1b8:	e9 2c d8 ff ff       	jmp    a9e9 <f0+0xb9>
    d1bd:	0f 1f 00             	nopl   (%rax)
    d1c0:	66 85 c0             	test   %ax,%ax
    d1c3:	0f 85 ae f5 ff ff    	jne    c777 <f0+0x1e47>
    d1c9:	e9 99 f5 ff ff       	jmp    c767 <f0+0x1e37>
    d1ce:	66 90                	xchg   %ax,%ax
    d1d0:	66 85 c0             	test   %ax,%ax
    d1d3:	0f 85 ff f4 ff ff    	jne    c6d8 <f0+0x1da8>
    d1d9:	e9 ea f4 ff ff       	jmp    c6c8 <f0+0x1d98>
    d1de:	66 90                	xchg   %ax,%ax
    d1e0:	66 85 c0             	test   %ax,%ax
    d1e3:	0f 85 50 f4 ff ff    	jne    c639 <f0+0x1d09>
    d1e9:	e9 3b f4 ff ff       	jmp    c629 <f0+0x1cf9>
    d1ee:	66 90                	xchg   %ax,%ax
    d1f0:	66 85 c0             	test   %ax,%ax
    d1f3:	0f 85 a1 f3 ff ff    	jne    c59a <f0+0x1c6a>
    d1f9:	e9 8c f3 ff ff       	jmp    c58a <f0+0x1c5a>
    d1fe:	66 90                	xchg   %ax,%ax
    d200:	66 85 c0             	test   %ax,%ax
    d203:	0f 85 f2 f2 ff ff    	jne    c4fb <f0+0x1bcb>
    d209:	e9 dd f2 ff ff       	jmp    c4eb <f0+0x1bbb>
    d20e:	66 90                	xchg   %ax,%ax
    d210:	66 85 c0             	test   %ax,%ax
    d213:	0f 85 43 f2 ff ff    	jne    c45c <f0+0x1b2c>
    d219:	e9 2e f2 ff ff       	jmp    c44c <f0+0x1b1c>
    d21e:	66 90                	xchg   %ax,%ax
    d220:	66 85 c0             	test   %ax,%ax
    d223:	0f 85 94 f1 ff ff    	jne    c3bd <f0+0x1a8d>
    d229:	e9 7f f1 ff ff       	jmp    c3ad <f0+0x1a7d>
    d22e:	66 90                	xchg   %ax,%ax
    d230:	66 85 c0             	test   %ax,%ax
    d233:	0f 85 e5 f0 ff ff    	jne    c31e <f0+0x19ee>
    d239:	e9 d0 f0 ff ff       	jmp    c30e <f0+0x19de>
    d23e:	66 90                	xchg   %ax,%ax
    d240:	66 85 c0             	test   %ax,%ax
    d243:	0f 85 fd d9 ff ff    	jne    ac46 <f0+0x316>
    d249:	e9 e8 d9 ff ff       	jmp    ac36 <f0+0x306>
    d24e:	66 90                	xchg   %ax,%ax
    d250:	66 85 c0             	test   %ax,%ax
    d253:	0f 85 57 d9 ff ff    	jne    abb0 <f0+0x280>
    d259:	e9 42 d9 ff ff       	jmp    aba0 <f0+0x270>
    d25e:	66 90                	xchg   %ax,%ax
    d260:	66 85 c0             	test   %ax,%ax
    d263:	0f 85 b1 d8 ff ff    	jne    ab1a <f0+0x1ea>
    d269:	e9 9c d8 ff ff       	jmp    ab0a <f0+0x1da>
    d26e:	66 90                	xchg   %ax,%ax
    d270:	66 85 c0             	test   %ax,%ax
    d273:	0f 85 0e eb ff ff    	jne    bd87 <f0+0x1457>
    d279:	e9 f9 ea ff ff       	jmp    bd77 <f0+0x1447>
    d27e:	66 90                	xchg   %ax,%ax
    d280:	66 85 c0             	test   %ax,%ax
    d283:	0f 85 5f ea ff ff    	jne    bce8 <f0+0x13b8>
    d289:	e9 4a ea ff ff       	jmp    bcd8 <f0+0x13a8>
    d28e:	66 90                	xchg   %ax,%ax
    d290:	66 85 c0             	test   %ax,%ax
    d293:	0f 85 e2 da ff ff    	jne    ad7b <f0+0x44b>
    d299:	e9 cd da ff ff       	jmp    ad6b <f0+0x43b>
    d29e:	66 90                	xchg   %ax,%ax
    d2a0:	66 85 c0             	test   %ax,%ax
    d2a3:	0f 85 33 da ff ff    	jne    acdc <f0+0x3ac>
    d2a9:	e9 1e da ff ff       	jmp    accc <f0+0x39c>
    d2ae:	66 90                	xchg   %ax,%ax
    d2b0:	66 85 c0             	test   %ax,%ax
    d2b3:	0f 85 c6 ef ff ff    	jne    c27f <f0+0x194f>
    d2b9:	e9 b1 ef ff ff       	jmp    c26f <f0+0x193f>
    d2be:	66 90                	xchg   %ax,%ax
    d2c0:	66 85 c0             	test   %ax,%ax
    d2c3:	0f 85 17 ef ff ff    	jne    c1e0 <f0+0x18b0>
    d2c9:	e9 02 ef ff ff       	jmp    c1d0 <f0+0x18a0>
    d2ce:	66 90                	xchg   %ax,%ax
    d2d0:	66 85 c0             	test   %ax,%ax
    d2d3:	0f 85 68 ee ff ff    	jne    c141 <f0+0x1811>
    d2d9:	e9 53 ee ff ff       	jmp    c131 <f0+0x1801>
    d2de:	66 90                	xchg   %ax,%ax
    d2e0:	66 85 c0             	test   %ax,%ax
    d2e3:	0f 85 b9 ed ff ff    	jne    c0a2 <f0+0x1772>
    d2e9:	e9 a4 ed ff ff       	jmp    c092 <f0+0x1762>
    d2ee:	66 90                	xchg   %ax,%ax
    d2f0:	66 85 c0             	test   %ax,%ax
    d2f3:	0f 85 0a ed ff ff    	jne    c003 <f0+0x16d3>
    d2f9:	e9 f5 ec ff ff       	jmp    bff3 <f0+0x16c3>
    d2fe:	66 90                	xchg   %ax,%ax
    d300:	66 85 c0             	test   %ax,%ax
    d303:	0f 85 5b ec ff ff    	jne    bf64 <f0+0x1634>
    d309:	e9 46 ec ff ff       	jmp    bf54 <f0+0x1624>
    d30e:	66 90                	xchg   %ax,%ax
    d310:	66 85 c0             	test   %ax,%ax
    d313:	0f 85 ac eb ff ff    	jne    bec5 <f0+0x1595>
    d319:	e9 97 eb ff ff       	jmp    beb5 <f0+0x1585>
    d31e:	66 90                	xchg   %ax,%ax
    d320:	66 85 c0             	test   %ax,%ax
    d323:	0f 85 fd ea ff ff    	jne    be26 <f0+0x14f6>
    d329:	e9 e8 ea ff ff       	jmp    be16 <f0+0x14e6>
    d32e:	66 90                	xchg   %ax,%ax
    d330:	66 85 c0             	test   %ax,%ax
    d333:	0f 85 29 fe ff ff    	jne    d162 <f0+0x2832>
    d339:	e9 14 fe ff ff       	jmp    d152 <f0+0x2822>
    d33e:	66 90                	xchg   %ax,%ax
    d340:	66 85 c0             	test   %ax,%ax
    d343:	0f 85 7f fd ff ff    	jne    d0c8 <f0+0x2798>
    d349:	e9 6a fd ff ff       	jmp    d0b8 <f0+0x2788>
    d34e:	66 90                	xchg   %ax,%ax
    d350:	66 85 c0             	test   %ax,%ax
    d353:	0f 85 d0 fc ff ff    	jne    d029 <f0+0x26f9>
    d359:	e9 bb fc ff ff       	jmp    d019 <f0+0x26e9>
    d35e:	66 90                	xchg   %ax,%ax
    d360:	66 85 c0             	test   %ax,%ax
    d363:	0f 85 21 fc ff ff    	jne    cf8a <f0+0x265a>
    d369:	e9 0c fc ff ff       	jmp    cf7a <f0+0x264a>
    d36e:	66 90                	xchg   %ax,%ax
    d370:	66 85 c0             	test   %ax,%ax
    d373:	0f 85 72 fb ff ff    	jne    ceeb <f0+0x25bb>
    d379:	e9 5d fb ff ff       	jmp    cedb <f0+0x25ab>
    d37e:	66 90                	xchg   %ax,%ax
    d380:	66 85 c0             	test   %ax,%ax
    d383:	0f 85 c3 fa ff ff    	jne    ce4c <f0+0x251c>
    d389:	e9 ae fa ff ff       	jmp    ce3c <f0+0x250c>
    d38e:	66 90                	xchg   %ax,%ax
    d390:	66 85 c0             	test   %ax,%ax
    d393:	0f 85 14 fa ff ff    	jne    cdad <f0+0x247d>
    d399:	e9 ff f9 ff ff       	jmp    cd9d <f0+0x246d>
    d39e:	66 90                	xchg   %ax,%ax
    d3a0:	66 85 c0             	test   %ax,%ax
    d3a3:	0f 85 65 f9 ff ff    	jne    cd0e <f0+0x23de>
    d3a9:	e9 50 f9 ff ff       	jmp    ccfe <f0+0x23ce>
    d3ae:	66 90                	xchg   %ax,%ax
    d3b0:	66 85 c0             	test   %ax,%ax
    d3b3:	0f 85 b6 f8 ff ff    	jne    cc6f <f0+0x233f>
    d3b9:	e9 a1 f8 ff ff       	jmp    cc5f <f0+0x232f>
    d3be:	66 90                	xchg   %ax,%ax
    d3c0:	66 85 c0             	test   %ax,%ax
    d3c3:	0f 85 07 f8 ff ff    	jne    cbd0 <f0+0x22a0>
    d3c9:	e9 f2 f7 ff ff       	jmp    cbc0 <f0+0x2290>
    d3ce:	66 90                	xchg   %ax,%ax
    d3d0:	66 85 c0             	test   %ax,%ax
    d3d3:	0f 85 58 f7 ff ff    	jne    cb31 <f0+0x2201>
    d3d9:	e9 43 f7 ff ff       	jmp    cb21 <f0+0x21f1>
    d3de:	66 90                	xchg   %ax,%ax
    d3e0:	66 85 c0             	test   %ax,%ax
    d3e3:	0f 85 a9 f6 ff ff    	jne    ca92 <f0+0x2162>
    d3e9:	e9 94 f6 ff ff       	jmp    ca82 <f0+0x2152>
    d3ee:	66 90                	xchg   %ax,%ax
    d3f0:	66 85 c0             	test   %ax,%ax
    d3f3:	0f 85 fa f5 ff ff    	jne    c9f3 <f0+0x20c3>
    d3f9:	e9 e5 f5 ff ff       	jmp    c9e3 <f0+0x20b3>
    d3fe:	66 90                	xchg   %ax,%ax
    d400:	66 85 c0             	test   %ax,%ax
    d403:	0f 85 4b f5 ff ff    	jne    c954 <f0+0x2024>
    d409:	e9 36 f5 ff ff       	jmp    c944 <f0+0x2014>
    d40e:	66 90                	xchg   %ax,%ax
    d410:	66 85 c0             	test   %ax,%ax
    d413:	0f 85 9c f4 ff ff    	jne    c8b5 <f0+0x1f85>
    d419:	e9 87 f4 ff ff       	jmp    c8a5 <f0+0x1f75>
    d41e:	66 90                	xchg   %ax,%ax
    d420:	66 85 c0             	test   %ax,%ax
    d423:	0f 85 ed f3 ff ff    	jne    c816 <f0+0x1ee6>
    d429:	e9 d8 f3 ff ff       	jmp    c806 <f0+0x1ed6>
    d42e:	4c 89 e7             	mov    %r12,%rdi
    d431:	e8 da 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d436:	e9 22 fd ff ff       	jmp    d15d <f0+0x282d>
    d43b:	4c 89 e7             	mov    %r12,%rdi
    d43e:	e8 cd 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d443:	e9 cd d6 ff ff       	jmp    ab15 <f0+0x1e5>
    d448:	4c 89 e7             	mov    %r12,%rdi
    d44b:	e8 c0 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d450:	e9 56 d7 ff ff       	jmp    abab <f0+0x27b>
    d455:	4c 89 e7             	mov    %r12,%rdi
    d458:	e8 b3 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d45d:	e9 df d7 ff ff       	jmp    ac41 <f0+0x311>
    d462:	4c 89 e7             	mov    %r12,%rdi
    d465:	e8 a6 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d46a:	e9 68 d8 ff ff       	jmp    acd7 <f0+0x3a7>
    d46f:	4c 89 e7             	mov    %r12,%rdi
    d472:	e8 99 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d477:	e9 fa d8 ff ff       	jmp    ad76 <f0+0x446>
    d47c:	4c 89 e7             	mov    %r12,%rdi
    d47f:	e8 8c 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d484:	e9 5a e8 ff ff       	jmp    bce3 <f0+0x13b3>
    d489:	4c 89 e7             	mov    %r12,%rdi
    d48c:	e8 7f 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d491:	e9 ec e8 ff ff       	jmp    bd82 <f0+0x1452>
    d496:	4c 89 e7             	mov    %r12,%rdi
    d499:	e8 72 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d49e:	e9 7e e9 ff ff       	jmp    be21 <f0+0x14f1>
    d4a3:	4c 89 e7             	mov    %r12,%rdi
    d4a6:	e8 65 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4ab:	e9 10 ea ff ff       	jmp    bec0 <f0+0x1590>
    d4b0:	4c 89 e7             	mov    %r12,%rdi
    d4b3:	e8 58 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4b8:	e9 a2 ea ff ff       	jmp    bf5f <f0+0x162f>
    d4bd:	4c 89 e7             	mov    %r12,%rdi
    d4c0:	e8 4b 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4c5:	e9 34 eb ff ff       	jmp    bffe <f0+0x16ce>
    d4ca:	4c 89 e7             	mov    %r12,%rdi
    d4cd:	e8 3e 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4d2:	e9 c6 eb ff ff       	jmp    c09d <f0+0x176d>
    d4d7:	4c 89 e7             	mov    %r12,%rdi
    d4da:	e8 31 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4df:	e9 58 ec ff ff       	jmp    c13c <f0+0x180c>
    d4e4:	4c 89 e7             	mov    %r12,%rdi
    d4e7:	e8 24 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4ec:	e9 ea ec ff ff       	jmp    c1db <f0+0x18ab>
    d4f1:	4c 89 e7             	mov    %r12,%rdi
    d4f4:	e8 17 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d4f9:	e9 7c ed ff ff       	jmp    c27a <f0+0x194a>
    d4fe:	4c 89 e7             	mov    %r12,%rdi
    d501:	e8 0a 7e ff ff       	call   5310 <fwp_rc_forget_slot>
    d506:	e9 0e ee ff ff       	jmp    c319 <f0+0x19e9>
    d50b:	4c 89 e7             	mov    %r12,%rdi
    d50e:	e8 fd 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d513:	e9 a0 ee ff ff       	jmp    c3b8 <f0+0x1a88>
    d518:	4c 89 e7             	mov    %r12,%rdi
    d51b:	e8 f0 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d520:	e9 32 ef ff ff       	jmp    c457 <f0+0x1b27>
    d525:	4c 89 e7             	mov    %r12,%rdi
    d528:	e8 e3 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d52d:	e9 c4 ef ff ff       	jmp    c4f6 <f0+0x1bc6>
    d532:	4c 89 e7             	mov    %r12,%rdi
    d535:	e8 d6 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d53a:	e9 56 f0 ff ff       	jmp    c595 <f0+0x1c65>
    d53f:	4c 89 e7             	mov    %r12,%rdi
    d542:	e8 c9 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d547:	e9 e8 f0 ff ff       	jmp    c634 <f0+0x1d04>
    d54c:	4c 89 e7             	mov    %r12,%rdi
    d54f:	e8 bc 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d554:	e9 7a f1 ff ff       	jmp    c6d3 <f0+0x1da3>
    d559:	4c 89 e7             	mov    %r12,%rdi
    d55c:	e8 af 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d561:	e9 0c f2 ff ff       	jmp    c772 <f0+0x1e42>
    d566:	4c 89 e7             	mov    %r12,%rdi
    d569:	e8 a2 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d56e:	e9 9e f2 ff ff       	jmp    c811 <f0+0x1ee1>
    d573:	4c 89 e7             	mov    %r12,%rdi
    d576:	e8 95 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d57b:	e9 30 f3 ff ff       	jmp    c8b0 <f0+0x1f80>
    d580:	4c 89 e7             	mov    %r12,%rdi
    d583:	e8 88 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d588:	e9 c2 f3 ff ff       	jmp    c94f <f0+0x201f>
    d58d:	4c 89 e7             	mov    %r12,%rdi
    d590:	e8 7b 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d595:	e9 54 f4 ff ff       	jmp    c9ee <f0+0x20be>
    d59a:	4c 89 e7             	mov    %r12,%rdi
    d59d:	e8 6e 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5a2:	e9 e6 f4 ff ff       	jmp    ca8d <f0+0x215d>
    d5a7:	4c 89 e7             	mov    %r12,%rdi
    d5aa:	e8 61 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5af:	e9 78 f5 ff ff       	jmp    cb2c <f0+0x21fc>
    d5b4:	4c 89 e7             	mov    %r12,%rdi
    d5b7:	e8 54 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5bc:	e9 0a f6 ff ff       	jmp    cbcb <f0+0x229b>
    d5c1:	4c 89 e7             	mov    %r12,%rdi
    d5c4:	e8 47 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5c9:	e9 9c f6 ff ff       	jmp    cc6a <f0+0x233a>
    d5ce:	4c 89 e7             	mov    %r12,%rdi
    d5d1:	e8 3a 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5d6:	e9 2e f7 ff ff       	jmp    cd09 <f0+0x23d9>
    d5db:	4c 89 e7             	mov    %r12,%rdi
    d5de:	e8 2d 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5e3:	e9 c0 f7 ff ff       	jmp    cda8 <f0+0x2478>
    d5e8:	4c 89 e7             	mov    %r12,%rdi
    d5eb:	e8 20 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5f0:	e9 52 f8 ff ff       	jmp    ce47 <f0+0x2517>
    d5f5:	4c 89 e7             	mov    %r12,%rdi
    d5f8:	e8 13 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5fd:	e9 e4 f8 ff ff       	jmp    cee6 <f0+0x25b6>
    d602:	4c 89 e7             	mov    %r12,%rdi
    d605:	e8 06 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d60a:	e9 76 f9 ff ff       	jmp    cf85 <f0+0x2655>
    d60f:	4c 89 e7             	mov    %r12,%rdi
    d612:	e8 f9 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d617:	e9 08 fa ff ff       	jmp    d024 <f0+0x26f4>
    d61c:	4c 89 e7             	mov    %r12,%rdi
    d61f:	e8 ec 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d624:	e9 9a fa ff ff       	jmp    d0c3 <f0+0x2793>
    d629:	e8 32 5e ff ff       	call   3460 <__stack_chk_fail@plt>
    d62e:	66 90                	xchg   %ax,%ax

000000000000d630 <fwp_main_thread>:
    d630:	f3 0f 1e fa          	endbr64
    d634:	41 54                	push   %r12
    d636:	55                   	push   %rbp
    d637:	53                   	push   %rbx
    d638:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    d63f:	8b 0d bf 64 01 00    	mov    0x164bf(%rip),%ecx        # 23b04 <fwp_heap+0x13a4>
    d645:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    d64c:	00 00 
    d64e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    d655:	00 
    d656:	31 c0                	xor    %eax,%eax
    d658:	85 c9                	test   %ecx,%ecx
    d65a:	0f 84 68 06 00 00    	je     dcc8 <fwp_main_thread+0x698>
    d660:	8b 15 a2 64 01 00    	mov    0x164a2(%rip),%edx        # 23b08 <fwp_heap+0x13a8>
    d666:	85 d2                	test   %edx,%edx
    d668:	0f 85 42 06 00 00    	jne    dcb0 <fwp_main_thread+0x680>
    d66e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    d673:	31 f6                	xor    %esi,%esi
    d675:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    d67a:	48 c7 05 73 4a 01 00 	movq   $0x40000000,0x14a73(%rip)        # 220f8 <fwp_main_stack_size>
    d681:	00 00 00 40 
    d685:	48 89 05 74 4a 01 00 	mov    %rax,0x14a74(%rip)        # 22100 <fwp_main_stack_top>
    d68c:	48 8d 05 ed 49 00 00 	lea    0x49ed(%rip),%rax        # 12080 <alt.5>
    d693:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    d698:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    d69f:	01 00 
    d6a1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    d6a8:	00 
    d6a9:	e8 12 60 ff ff       	call   36c0 <sigaltstack@plt>
    d6ae:	85 c0                	test   %eax,%eax
    d6b0:	0f 85 4a 06 00 00    	jne    dd00 <fwp_main_thread+0x6d0>
    d6b6:	31 c0                	xor    %eax,%eax
    d6b8:	b9 12 00 00 00       	mov    $0x12,%ecx
    d6bd:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d6c2:	f3 48 ab             	rep stos %rax,(%rdi)
    d6c5:	48 8d 05 24 66 ff ff 	lea    -0x99dc(%rip),%rax        # 3cf0 <fwp_segv>
    d6cc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d6d1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    d6d8:	04 00 00 08 
    d6dc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    d6e1:	e8 9a 5e ff ff       	call   3580 <sigemptyset@plt>
    d6e6:	85 c0                	test   %eax,%eax
    d6e8:	0f 85 12 06 00 00    	jne    dd00 <fwp_main_thread+0x6d0>
    d6ee:	31 d2                	xor    %edx,%edx
    d6f0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d6f5:	bf 0b 00 00 00       	mov    $0xb,%edi
    d6fa:	e8 01 5d ff ff       	call   3400 <sigaction@plt>
    d6ff:	85 c0                	test   %eax,%eax
    d701:	0f 85 f9 05 00 00    	jne    dd00 <fwp_main_thread+0x6d0>
    d707:	31 d2                	xor    %edx,%edx
    d709:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d70e:	bf 07 00 00 00       	mov    $0x7,%edi
    d713:	e8 e8 5c ff ff       	call   3400 <sigaction@plt>
    d718:	85 c0                	test   %eax,%eax
    d71a:	0f 85 e0 05 00 00    	jne    dd00 <fwp_main_thread+0x6d0>
    d720:	8b 05 4a 49 00 00    	mov    0x494a(%rip),%eax        # 12070 <st.3>
    d726:	85 c0                	test   %eax,%eax
    d728:	0f 84 62 05 00 00    	je     dc90 <fwp_main_thread+0x660>
    d72e:	48 8b 2d 0b 50 01 00 	mov    0x1500b(%rip),%rbp        # 22740 <fwp_cur>
    d735:	48 85 ed             	test   %rbp,%rbp
    d738:	0f 84 72 03 00 00    	je     dab0 <fwp_main_thread+0x480>
    d73e:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    d743:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    d747:	48 89 eb             	mov    %rbp,%rbx
    d74a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d74f:	0f 84 41 01 00 00    	je     d896 <fwp_main_thread+0x266>
    d755:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    d75a:	0f 84 80 02 00 00    	je     d9e0 <fwp_main_thread+0x3b0>
    d760:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    d764:	0f 84 66 02 00 00    	je     d9d0 <fwp_main_thread+0x3a0>
    d76a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    d76e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    d772:	0f 85 e8 02 00 00    	jne    da60 <fwp_main_thread+0x430>
    d778:	48 8b 43 60          	mov    0x60(%rbx),%rax
    d77c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    d783:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    d787:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    d78e:	00 00 00 00 
    d792:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    d799:	48 85 d2             	test   %rdx,%rdx
    d79c:	74 07                	je     d7a5 <fwp_main_thread+0x175>
    d79e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    d7a5:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    d7a9:	48 85 c0             	test   %rax,%rax
    d7ac:	74 34                	je     d7e2 <fwp_main_thread+0x1b2>
    d7ae:	48 89 43 68          	mov    %rax,0x68(%rbx)
    d7b2:	48 8b 05 5f 4f 01 00 	mov    0x14f5f(%rip),%rax        # 22718 <fwp_timers>
    d7b9:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    d7bd:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    d7c4:	00 00 00 00 
    d7c8:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    d7cf:	48 85 c0             	test   %rax,%rax
    d7d2:	74 07                	je     d7db <fwp_main_thread+0x1ab>
    d7d4:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    d7db:	48 89 1d 36 4f 01 00 	mov    %rbx,0x14f36(%rip)        # 22718 <fwp_timers>
    d7e2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    d7e6:	e8 a5 98 ff ff       	call   7090 <fwp_block>
    d7eb:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    d7f2:	48 85 c9             	test   %rcx,%rcx
    d7f5:	74 47                	je     d83e <fwp_main_thread+0x20e>
    d7f7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    d7fe:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    d805:	48 85 d2             	test   %rdx,%rdx
    d808:	0f 84 92 02 00 00    	je     daa0 <fwp_main_thread+0x470>
    d80e:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    d815:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    d81c:	48 85 c0             	test   %rax,%rax
    d81f:	74 07                	je     d828 <fwp_main_thread+0x1f8>
    d821:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    d828:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    d82f:	00 00 00 00 
    d833:	66 0f ef c0          	pxor   %xmm0,%xmm0
    d837:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    d83e:	48 8b 0d fb 4e 01 00 	mov    0x14efb(%rip),%rcx        # 22740 <fwp_cur>
    d845:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    d849:	0f 84 01 02 00 00    	je     da50 <fwp_main_thread+0x420>
    d84f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    d856:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    d85d:	48 85 d2             	test   %rdx,%rdx
    d860:	0f 84 fa 03 00 00    	je     dc60 <fwp_main_thread+0x630>
    d866:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    d86d:	48 85 c0             	test   %rax,%rax
    d870:	74 07                	je     d879 <fwp_main_thread+0x249>
    d872:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    d879:	66 0f ef c9          	pxor   %xmm1,%xmm1
    d87d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    d881:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    d888:	48 89 cb             	mov    %rcx,%rbx
    d88b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d890:	0f 85 bf fe ff ff    	jne    d755 <fwp_main_thread+0x125>
    d896:	48 83 3d 3a 6b 01 00 	cmpq   $0x0,0x16b3a(%rip)        # 243d8 <fwp_state_len>
    d89d:	00 
    d89e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    d8a2:	0f 84 ba 00 00 00    	je     d962 <fwp_main_thread+0x332>
    d8a8:	48 39 1d 89 4e 01 00 	cmp    %rbx,0x14e89(%rip)        # 22738 <fwp_root>
    d8af:	c7 05 c7 47 01 00 00 	movl   $0x0,0x147c7(%rip)        # 22080 <fwp_exit_code>
    d8b6:	00 00 00 
    d8b9:	0f 85 5f 04 00 00    	jne    dd1e <fwp_main_thread+0x6ee>
    d8bf:	48 85 db             	test   %rbx,%rbx
    d8c2:	0f 84 0e 02 00 00    	je     dad6 <fwp_main_thread+0x4a6>
    d8c8:	48 8b 15 39 4e 01 00 	mov    0x14e39(%rip),%rdx        # 22708 <fwp_tasks_active>
    d8cf:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    d8d3:	48 85 d2             	test   %rdx,%rdx
    d8d6:	0f 84 fa 01 00 00    	je     dad6 <fwp_main_thread+0x4a6>
    d8dc:	0f 1f 40 00          	nopl   0x0(%rax)
    d8e0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    d8e4:	75 08                	jne    d8ee <fwp_main_thread+0x2be>
    d8e6:	48 89 d7             	mov    %rdx,%rdi
    d8e9:	e8 c2 67 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    d8ee:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    d8f5:	48 85 d2             	test   %rdx,%rdx
    d8f8:	75 e6                	jne    d8e0 <fwp_main_thread+0x2b0>
    d8fa:	eb 31                	jmp    d92d <fwp_main_thread+0x2fd>
    d8fc:	0f 1f 40 00          	nopl   0x0(%rax)
    d900:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    d907:	48 89 1d 12 4e 01 00 	mov    %rbx,0x14e12(%rip)        # 22720 <fwp_ready_tail>
    d90e:	e8 7d 97 ff ff       	call   7090 <fwp_block>
    d913:	e8 68 95 ff ff       	call   6e80 <fwp_free_zombie>
    d918:	48 83 3d e8 4d 01 00 	cmpq   $0x0,0x14de8(%rip)        # 22708 <fwp_tasks_active>
    d91f:	00 
    d920:	0f 84 b0 01 00 00    	je     dad6 <fwp_main_thread+0x4a6>
    d926:	48 8b 1d 0b 4e 01 00 	mov    0x14e0b(%rip),%rbx        # 22738 <fwp_root>
    d92d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    d931:	75 db                	jne    d90e <fwp_main_thread+0x2de>
    d933:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    d937:	75 d5                	jne    d90e <fwp_main_thread+0x2de>
    d939:	48 8b 05 e0 4d 01 00 	mov    0x14de0(%rip),%rax        # 22720 <fwp_ready_tail>
    d940:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    d944:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    d94b:	00 00 00 00 
    d94f:	48 85 c0             	test   %rax,%rax
    d952:	75 ac                	jne    d900 <fwp_main_thread+0x2d0>
    d954:	48 89 1d cd 4d 01 00 	mov    %rbx,0x14dcd(%rip)        # 22728 <fwp_ready_head>
    d95b:	eb aa                	jmp    d907 <fwp_main_thread+0x2d7>
    d95d:	0f 1f 00             	nopl   (%rax)
    d960:	31 db                	xor    %ebx,%ebx
    d962:	48 83 3d 5e 6a 01 00 	cmpq   $0x0,0x16a5e(%rip)        # 243c8 <fwp_state_owners>
    d969:	00 
    d96a:	0f 85 38 ff ff ff    	jne    d8a8 <fwp_main_thread+0x278>
    d970:	48 8b 3d 69 6a 01 00 	mov    0x16a69(%rip),%rdi        # 243e0 <fwp_state>
    d977:	e8 d4 7b ff ff       	call   5550 <fwp_mem_free>
    d97c:	48 c7 05 59 6a 01 00 	movq   $0x0,0x16a59(%rip)        # 243e0 <fwp_state>
    d983:	00 00 00 00 
    d987:	48 c7 05 3e 6a 01 00 	movq   $0x0,0x16a3e(%rip)        # 243d0 <fwp_state_cap>
    d98e:	00 00 00 00 
    d992:	48 85 db             	test   %rbx,%rbx
    d995:	0f 84 46 03 00 00    	je     dce1 <fwp_main_thread+0x6b1>
    d99b:	48 39 1d 96 4d 01 00 	cmp    %rbx,0x14d96(%rip)        # 22738 <fwp_root>
    d9a2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    d9a9:	00 00 00 00 
    d9ad:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    d9b4:	00 00 00 00 
    d9b8:	c7 05 be 46 01 00 00 	movl   $0x0,0x146be(%rip)        # 22080 <fwp_exit_code>
    d9bf:	00 00 00 
    d9c2:	0f 84 00 ff ff ff    	je     d8c8 <fwp_main_thread+0x298>
    d9c8:	e9 88 5d ff ff       	jmp    3755 <fwp_main_thread.cold>
    d9cd:	0f 1f 00             	nopl   (%rax)
    d9d0:	e8 3b 69 ff ff       	call   4310 <fwp_now_ns>
    d9d5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    d9d9:	0f 8d 91 02 00 00    	jge    dc70 <fwp_main_thread+0x640>
    d9df:	90                   	nop
    d9e0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    d9e4:	0f 85 80 fd ff ff    	jne    d76a <fwp_main_thread+0x13a>
    d9ea:	48 8b 45 60          	mov    0x60(%rbp),%rax
    d9ee:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    d9f2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    d9f6:	0f 85 80 fd ff ff    	jne    d77c <fwp_main_thread+0x14c>
    d9fc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    da00:	48 85 c9             	test   %rcx,%rcx
    da03:	0f 84 73 fd ff ff    	je     d77c <fwp_main_thread+0x14c>
    da09:	48 85 c0             	test   %rax,%rax
    da0c:	0f 84 ff 02 00 00    	je     dd11 <fwp_main_thread+0x6e1>
    da12:	48 39 c8             	cmp    %rcx,%rax
    da15:	48 0f 4f c1          	cmovg  %rcx,%rax
    da19:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    da20:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    da24:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    da2b:	00 00 00 00 
    da2f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    da36:	48 85 d2             	test   %rdx,%rdx
    da39:	74 07                	je     da42 <fwp_main_thread+0x412>
    da3b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    da42:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    da46:	e9 63 fd ff ff       	jmp    d7ae <fwp_main_thread+0x17e>
    da4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    da50:	48 89 cb             	mov    %rcx,%rbx
    da53:	e9 f2 fc ff ff       	jmp    d74a <fwp_main_thread+0x11a>
    da58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    da5f:	00 
    da60:	48 8b 45 40          	mov    0x40(%rbp),%rax
    da64:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    da6b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    da72:	00 00 00 00 
    da76:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    da7d:	48 85 c0             	test   %rax,%rax
    da80:	0f 84 52 02 00 00    	je     dcd8 <fwp_main_thread+0x6a8>
    da86:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    da8d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    da91:	e9 4c fd ff ff       	jmp    d7e2 <fwp_main_thread+0x1b2>
    da96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    da9d:	00 00 00 
    daa0:	48 89 01             	mov    %rax,(%rcx)
    daa3:	e9 74 fd ff ff       	jmp    d81c <fwp_main_thread+0x1ec>
    daa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    daaf:	00 
    dab0:	48 83 3d 20 69 01 00 	cmpq   $0x0,0x16920(%rip)        # 243d8 <fwp_state_len>
    dab7:	00 
    dab8:	0f 84 a2 fe ff ff    	je     d960 <fwp_main_thread+0x330>
    dabe:	48 83 3d 72 4c 01 00 	cmpq   $0x0,0x14c72(%rip)        # 22738 <fwp_root>
    dac5:	00 
    dac6:	c7 05 b0 45 01 00 00 	movl   $0x0,0x145b0(%rip)        # 22080 <fwp_exit_code>
    dacd:	00 00 00 
    dad0:	0f 85 43 02 00 00    	jne    dd19 <fwp_main_thread+0x6e9>
    dad6:	e8 a5 93 ff ff       	call   6e80 <fwp_free_zombie>
    dadb:	48 83 3d 45 4c 01 00 	cmpq   $0x0,0x14c45(%rip)        # 22728 <fwp_ready_head>
    dae2:	00 
    dae3:	0f 85 6c 5c ff ff    	jne    3755 <fwp_main_thread.cold>
    dae9:	48 83 3d 27 4c 01 00 	cmpq   $0x0,0x14c27(%rip)        # 22718 <fwp_timers>
    daf0:	00 
    daf1:	0f 85 5e 5c ff ff    	jne    3755 <fwp_main_thread.cold>
    daf7:	8b 1d 0f 46 01 00    	mov    0x1460f(%rip),%ebx        # 2210c <fwp_stack_pool_n>
    dafd:	85 db                	test   %ebx,%ebx
    daff:	74 36                	je     db37 <fwp_main_thread+0x507>
    db01:	83 eb 01             	sub    $0x1,%ebx
    db04:	48 8d 05 15 46 01 00 	lea    0x14615(%rip),%rax        # 22120 <fwp_stack_pool>
    db0b:	48 63 d3             	movslq %ebx,%rdx
    db0e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    db12:	eb 07                	jmp    db1b <fwp_main_thread+0x4eb>
    db14:	0f 1f 40 00          	nopl   0x0(%rax)
    db18:	83 eb 01             	sub    $0x1,%ebx
    db1b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    db1f:	be 00 00 00 10       	mov    $0x10000000,%esi
    db24:	89 1d e2 45 01 00    	mov    %ebx,0x145e2(%rip)        # 2210c <fwp_stack_pool_n>
    db2a:	48 83 ed 08          	sub    $0x8,%rbp
    db2e:	e8 ad 5a ff ff       	call   35e0 <munmap@plt>
    db33:	85 db                	test   %ebx,%ebx
    db35:	75 e1                	jne    db18 <fwp_main_thread+0x4e8>
    db37:	8b 3d db 44 00 00    	mov    0x44db(%rip),%edi        # 12018 <fwp_epfd>
    db3d:	85 ff                	test   %edi,%edi
    db3f:	78 05                	js     db46 <fwp_main_thread+0x516>
    db41:	e8 8a 59 ff ff       	call   34d0 <close@plt>
    db46:	4c 8b 25 d3 47 01 00 	mov    0x147d3(%rip),%r12        # 22320 <fwp_nfdws>
    db4d:	48 8b 2d d4 47 01 00 	mov    0x147d4(%rip),%rbp        # 22328 <fwp_fdws>
    db54:	31 db                	xor    %ebx,%ebx
    db56:	c7 05 b8 44 00 00 ff 	movl   $0xffffffff,0x44b8(%rip)        # 12018 <fwp_epfd>
    db5d:	ff ff ff 
    db60:	4d 85 e4             	test   %r12,%r12
    db63:	74 38                	je     db9d <fwp_main_thread+0x56d>
    db65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    db6c:	00 00 00 00 
    db70:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    db75:	48 85 ff             	test   %rdi,%rdi
    db78:	74 1a                	je     db94 <fwp_main_thread+0x564>
    db7a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    db7e:	0f 85 d1 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    db84:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    db89:	0f 85 c6 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    db8f:	e8 bc 79 ff ff       	call   5550 <fwp_mem_free>
    db94:	48 83 c3 01          	add    $0x1,%rbx
    db98:	4c 39 e3             	cmp    %r12,%rbx
    db9b:	75 d3                	jne    db70 <fwp_main_thread+0x540>
    db9d:	48 89 ef             	mov    %rbp,%rdi
    dba0:	e8 ab 79 ff ff       	call   5550 <fwp_mem_free>
    dba5:	48 8b 15 8c 4b 01 00 	mov    0x14b8c(%rip),%rdx        # 22738 <fwp_root>
    dbac:	48 c7 05 71 47 01 00 	movq   $0x0,0x14771(%rip)        # 22328 <fwp_fdws>
    dbb3:	00 00 00 00 
    dbb7:	48 c7 05 5e 47 01 00 	movq   $0x0,0x1475e(%rip)        # 22320 <fwp_nfdws>
    dbbe:	00 00 00 00 
    dbc2:	48 85 d2             	test   %rdx,%rdx
    dbc5:	74 4e                	je     dc15 <fwp_main_thread+0x5e5>
    dbc7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    dbcc:	0f 85 83 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dbd2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    dbd9:	00 
    dbda:	0f 85 75 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dbe0:	48 83 3d f0 67 01 00 	cmpq   $0x0,0x167f0(%rip)        # 243d8 <fwp_state_len>
    dbe7:	00 
    dbe8:	0f 85 67 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dbee:	48 83 3d d2 67 01 00 	cmpq   $0x0,0x167d2(%rip)        # 243c8 <fwp_state_owners>
    dbf5:	00 
    dbf6:	0f 85 59 5b ff ff    	jne    3755 <fwp_main_thread.cold>
    dbfc:	b9 79 00 00 00       	mov    $0x79,%ecx
    dc01:	31 c0                	xor    %eax,%eax
    dc03:	48 8d 3d 36 47 01 00 	lea    0x14736(%rip),%rdi        # 22340 <fwp_root_context>
    dc0a:	f3 48 ab             	rep stos %rax,(%rdi)
    dc0d:	48 89 d7             	mov    %rdx,%rdi
    dc10:	e8 3b 79 ff ff       	call   5550 <fwp_mem_free>
    dc15:	48 8b 3d 04 44 00 00 	mov    0x4404(%rip),%rdi        # 12020 <stdout@GLIBC_2.2.5>
    dc1c:	48 c7 05 19 4b 01 00 	movq   $0x0,0x14b19(%rip)        # 22740 <fwp_cur>
    dc23:	00 00 00 00 
    dc27:	48 c7 05 06 4b 01 00 	movq   $0x0,0x14b06(%rip)        # 22738 <fwp_root>
    dc2e:	00 00 00 00 
    dc32:	e8 89 59 ff ff       	call   35c0 <fflush@plt>
    dc37:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    dc3e:	00 
    dc3f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    dc46:	00 00 
    dc48:	0f 85 be 00 00 00    	jne    dd0c <fwp_main_thread+0x6dc>
    dc4e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    dc55:	31 c0                	xor    %eax,%eax
    dc57:	5b                   	pop    %rbx
    dc58:	5d                   	pop    %rbp
    dc59:	41 5c                	pop    %r12
    dc5b:	c3                   	ret
    dc5c:	0f 1f 40 00          	nopl   0x0(%rax)
    dc60:	48 89 05 b1 4a 01 00 	mov    %rax,0x14ab1(%rip)        # 22718 <fwp_timers>
    dc67:	e9 01 fc ff ff       	jmp    d86d <fwp_main_thread+0x23d>
    dc6c:	0f 1f 40 00          	nopl   0x0(%rax)
    dc70:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    dc74:	0f 85 66 fd ff ff    	jne    d9e0 <fwp_main_thread+0x3b0>
    dc7a:	48 89 ef             	mov    %rbp,%rdi
    dc7d:	e8 2e 64 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    dc82:	e9 59 fd ff ff       	jmp    d9e0 <fwp_main_thread+0x3b0>
    dc87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    dc8e:	00 00 
    dc90:	e8 9b cc ff ff       	call   a930 <f0>
    dc95:	48 c7 05 c8 43 00 00 	movq   $0x0,0x43c8(%rip)        # 12068 <v.2>
    dc9c:	00 00 00 00 
    dca0:	c7 05 c6 43 00 00 01 	movl   $0x1,0x43c6(%rip)        # 12070 <st.3>
    dca7:	00 00 00 
    dcaa:	e9 7f fa ff ff       	jmp    d72e <fwp_main_thread+0xfe>
    dcaf:	90                   	nop
    dcb0:	48 8d 3d 69 6d ff ff 	lea    -0x9297(%rip),%rdi        # 4a20 <fwp_heap_report>
    dcb7:	e8 84 02 00 00       	call   df40 <atexit>
    dcbc:	e9 ad f9 ff ff       	jmp    d66e <fwp_main_thread+0x3e>
    dcc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    dcc8:	e8 63 6e ff ff       	call   4b30 <fwp_heap_init>
    dccd:	e9 8e f9 ff ff       	jmp    d660 <fwp_main_thread+0x30>
    dcd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    dcd8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dcdc:	e9 01 fb ff ff       	jmp    d7e2 <fwp_main_thread+0x1b2>
    dce1:	48 83 3d 4f 4a 01 00 	cmpq   $0x0,0x14a4f(%rip)        # 22738 <fwp_root>
    dce8:	00 
    dce9:	c7 05 8d 43 01 00 00 	movl   $0x0,0x1438d(%rip)        # 22080 <fwp_exit_code>
    dcf0:	00 00 00 
    dcf3:	0f 84 dd fd ff ff    	je     dad6 <fwp_main_thread+0x4a6>
    dcf9:	e9 57 5a ff ff       	jmp    3755 <fwp_main_thread.cold>
    dcfe:	66 90                	xchg   %ax,%ax
    dd00:	48 8d 3d f1 0b 00 00 	lea    0xbf1(%rip),%rdi        # e8f8 <_IO_stdin_used+0x8f8>
    dd07:	e8 94 64 ff ff       	call   41a0 <fwp_trap>
    dd0c:	e8 4f 57 ff ff       	call   3460 <__stack_chk_fail@plt>
    dd11:	48 89 c8             	mov    %rcx,%rax
    dd14:	e9 00 fd ff ff       	jmp    da19 <fwp_main_thread+0x3e9>
    dd19:	e9 37 5a ff ff       	jmp    3755 <fwp_main_thread.cold>
    dd1e:	e9 32 5a ff ff       	jmp    3755 <fwp_main_thread.cold>
    dd23:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dd2a:	00 00 00 
    dd2d:	0f 1f 00             	nopl   (%rax)

000000000000dd30 <__divmodti4>:
    dd30:	f3 0f 1e fa          	endbr64
    dd34:	55                   	push   %rbp
    dd35:	49 89 f1             	mov    %rsi,%r9
    dd38:	49 89 d2             	mov    %rdx,%r10
    dd3b:	48 89 fe             	mov    %rdi,%rsi
    dd3e:	49 89 cb             	mov    %rcx,%r11
    dd41:	48 89 e5             	mov    %rsp,%rbp
    dd44:	41 57                	push   %r15
    dd46:	41 56                	push   %r14
    dd48:	41 55                	push   %r13
    dd4a:	41 54                	push   %r12
    dd4c:	53                   	push   %rbx
    dd4d:	4c 89 c3             	mov    %r8,%rbx
    dd50:	45 31 c0             	xor    %r8d,%r8d
    dd53:	4d 85 c9             	test   %r9,%r9
    dd56:	79 12                	jns    dd6a <__divmodti4+0x3a>
    dd58:	31 ff                	xor    %edi,%edi
    dd5a:	48 f7 de             	neg    %rsi
    dd5d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    dd64:	4c 19 cf             	sbb    %r9,%rdi
    dd67:	49 89 f9             	mov    %rdi,%r9
    dd6a:	4c 89 d8             	mov    %r11,%rax
    dd6d:	4d 85 db             	test   %r11,%r11
    dd70:	0f 88 1a 01 00 00    	js     de90 <__divmodti4+0x160>
    dd76:	4c 89 d9             	mov    %r11,%rcx
    dd79:	49 89 f3             	mov    %rsi,%r11
    dd7c:	75 62                	jne    dde0 <__divmodti4+0xb0>
    dd7e:	4d 89 c4             	mov    %r8,%r12
    dd81:	4d 39 d1             	cmp    %r10,%r9
    dd84:	0f 83 46 01 00 00    	jae    ded0 <__divmodti4+0x1a0>
    dd8a:	4c 89 d8             	mov    %r11,%rax
    dd8d:	4c 89 ca             	mov    %r9,%rdx
    dd90:	49 f7 f2             	div    %r10
    dd93:	49 89 c3             	mov    %rax,%r11
    dd96:	31 c0                	xor    %eax,%eax
    dd98:	48 89 d6             	mov    %rdx,%rsi
    dd9b:	31 ff                	xor    %edi,%edi
    dd9d:	4c 89 d9             	mov    %r11,%rcx
    dda0:	48 89 c2             	mov    %rax,%rdx
    dda3:	48 89 c8             	mov    %rcx,%rax
    dda6:	4d 85 e4             	test   %r12,%r12
    dda9:	74 0a                	je     ddb5 <__divmodti4+0x85>
    ddab:	48 f7 d8             	neg    %rax
    ddae:	48 83 d2 00          	adc    $0x0,%rdx
    ddb2:	48 f7 da             	neg    %rdx
    ddb5:	4d 85 c0             	test   %r8,%r8
    ddb8:	74 0a                	je     ddc4 <__divmodti4+0x94>
    ddba:	48 f7 de             	neg    %rsi
    ddbd:	48 83 d7 00          	adc    $0x0,%rdi
    ddc1:	48 f7 df             	neg    %rdi
    ddc4:	48 89 33             	mov    %rsi,(%rbx)
    ddc7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    ddcb:	5b                   	pop    %rbx
    ddcc:	41 5c                	pop    %r12
    ddce:	41 5d                	pop    %r13
    ddd0:	41 5e                	pop    %r14
    ddd2:	41 5f                	pop    %r15
    ddd4:	5d                   	pop    %rbp
    ddd5:	c3                   	ret
    ddd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dddd:	00 00 00 
    dde0:	4d 89 c4             	mov    %r8,%r12
    dde3:	49 39 c1             	cmp    %rax,%r9
    dde6:	0f 82 ce 00 00 00    	jb     deba <__divmodti4+0x18a>
    ddec:	31 ff                	xor    %edi,%edi
    ddee:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    ddf3:	48 63 c7             	movslq %edi,%rax
    ddf6:	be 40 00 00 00       	mov    $0x40,%esi
    ddfb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    de00:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    de05:	48 29 c6             	sub    %rax,%rsi
    de08:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    de0d:	48 09 c8             	or     %rcx,%rax
    de10:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    de15:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    de1a:	49 89 c6             	mov    %rax,%r14
    de1d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    de21:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    de26:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    de2b:	49 09 c1             	or     %rax,%r9
    de2e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    de32:	4c 89 c8             	mov    %r9,%rax
    de35:	49 f7 f6             	div    %r14
    de38:	48 89 d1             	mov    %rdx,%rcx
    de3b:	49 89 c3             	mov    %rax,%r11
    de3e:	49 89 c1             	mov    %rax,%r9
    de41:	49 f7 e2             	mul    %r10
    de44:	49 89 c6             	mov    %rax,%r14
    de47:	49 89 d2             	mov    %rdx,%r10
    de4a:	48 39 d1             	cmp    %rdx,%rcx
    de4d:	72 07                	jb     de56 <__divmodti4+0x126>
    de4f:	75 17                	jne    de68 <__divmodti4+0x138>
    de51:	49 39 c7             	cmp    %rax,%r15
    de54:	73 12                	jae    de68 <__divmodti4+0x138>
    de56:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    de5a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    de5e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    de62:	49 89 d2             	mov    %rdx,%r10
    de65:	49 89 c6             	mov    %rax,%r14
    de68:	4c 89 f8             	mov    %r15,%rax
    de6b:	4c 29 f0             	sub    %r14,%rax
    de6e:	4c 19 d1             	sbb    %r10,%rcx
    de71:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    de76:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    de7b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    de80:	48 09 c6             	or     %rax,%rsi
    de83:	48 89 cf             	mov    %rcx,%rdi
    de86:	31 c0                	xor    %eax,%eax
    de88:	4c 89 c9             	mov    %r9,%rcx
    de8b:	e9 10 ff ff ff       	jmp    dda0 <__divmodti4+0x70>
    de90:	4c 89 d0             	mov    %r10,%rax
    de93:	4c 89 da             	mov    %r11,%rdx
    de96:	4d 89 c4             	mov    %r8,%r12
    de99:	49 89 f3             	mov    %rsi,%r11
    de9c:	48 f7 d8             	neg    %rax
    de9f:	49 f7 d4             	not    %r12
    dea2:	48 83 d2 00          	adc    $0x0,%rdx
    dea6:	49 89 c2             	mov    %rax,%r10
    dea9:	48 f7 da             	neg    %rdx
    deac:	48 89 d1             	mov    %rdx,%rcx
    deaf:	0f 84 cc fe ff ff    	je     dd81 <__divmodti4+0x51>
    deb5:	49 39 d1             	cmp    %rdx,%r9
    deb8:	73 46                	jae    df00 <__divmodti4+0x1d0>
    deba:	4c 89 cf             	mov    %r9,%rdi
    debd:	31 c0                	xor    %eax,%eax
    debf:	31 c9                	xor    %ecx,%ecx
    dec1:	e9 da fe ff ff       	jmp    dda0 <__divmodti4+0x70>
    dec6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    decd:	00 00 00 
    ded0:	4d 85 d2             	test   %r10,%r10
    ded3:	75 0d                	jne    dee2 <__divmodti4+0x1b2>
    ded5:	b8 01 00 00 00       	mov    $0x1,%eax
    deda:	31 d2                	xor    %edx,%edx
    dedc:	49 f7 f2             	div    %r10
    dedf:	49 89 c2             	mov    %rax,%r10
    dee2:	4c 89 c8             	mov    %r9,%rax
    dee5:	31 d2                	xor    %edx,%edx
    dee7:	49 f7 f2             	div    %r10
    deea:	49 89 c1             	mov    %rax,%r9
    deed:	4c 89 d8             	mov    %r11,%rax
    def0:	49 f7 f2             	div    %r10
    def3:	49 89 c3             	mov    %rax,%r11
    def6:	4c 89 c8             	mov    %r9,%rax
    def9:	e9 9a fe ff ff       	jmp    dd98 <__divmodti4+0x68>
    defe:	66 90                	xchg   %ax,%ax
    df00:	45 31 f6             	xor    %r14d,%r14d
    df03:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    df08:	44 89 f7             	mov    %r14d,%edi
    df0b:	45 85 f6             	test   %r14d,%r14d
    df0e:	0f 85 df fe ff ff    	jne    ddf3 <__divmodti4+0xc3>
    df14:	4c 39 ca             	cmp    %r9,%rdx
    df17:	72 17                	jb     df30 <__divmodti4+0x200>
    df19:	31 c9                	xor    %ecx,%ecx
    df1b:	48 39 c6             	cmp    %rax,%rsi
    df1e:	73 10                	jae    df30 <__divmodti4+0x200>
    df20:	4c 89 cf             	mov    %r9,%rdi
    df23:	31 c0                	xor    %eax,%eax
    df25:	e9 76 fe ff ff       	jmp    dda0 <__divmodti4+0x70>
    df2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    df30:	4c 89 de             	mov    %r11,%rsi
    df33:	b9 01 00 00 00       	mov    $0x1,%ecx
    df38:	48 29 c6             	sub    %rax,%rsi
    df3b:	49 19 d1             	sbb    %rdx,%r9
    df3e:	eb e0                	jmp    df20 <__divmodti4+0x1f0>

000000000000df40 <atexit>:
    df40:	f3 0f 1e fa          	endbr64
    df44:	48 8b 15 bd 40 00 00 	mov    0x40bd(%rip),%rdx        # 12008 <__dso_handle>
    df4b:	31 f6                	xor    %esi,%esi
    df4d:	e9 0e 57 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000df54 <_fini>:
    df54:	f3 0f 1e fa          	endbr64
    df58:	48 83 ec 08          	sub    $0x8,%rsp
    df5c:	48 83 c4 08          	add    $0x8,%rsp
    df60:	c3                   	ret
