
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 ff 00 00 	mov    0xffd1(%rip),%rax        # 12fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 fd 00 00    	push   0xfdf2(%rip)        # 12e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 fd 00 00    	jmp    *0xfdf4(%rip)        # 12e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 fc 00 00    	jmp    *0xfc66(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e fa 00 00    	jmp    *0xfa8e(%rip)        # 12e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 fa 00 00    	jmp    *0xfa86(%rip)        # 12e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e fa 00 00    	jmp    *0xfa7e(%rip)        # 12e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 fa 00 00    	jmp    *0xfa76(%rip)        # 12e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 b9 00 00 	lea    0xb9b8(%rip),%r9        # f0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 b9 00 00 	lea    0xb9b5(%rip),%r8        # f0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 61 fc ff ff       	call   33c0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 db 00 00 	lea    0xdba1(%rip),%rax        # 11320 <fwp_fn_table>
    377f:	48 89 05 f2 9c 06 00 	mov    %rax,0x69cf2(%rip)        # 6d478 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 9c 06 00 	mov    %rax,0x69cec(%rip)        # 6d480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e bb 00 00 	lea    0xbb4e(%rip),%rdi        # f2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 3f a5 00 00 	lea    0xa53f(%rip),%rdx        # dda0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe b9 00 00 	lea    0xb9fe(%rip),%rdi        # f2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 c3 00 00 	lea    0xc356(%rip),%rdi        # fc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 10 c3 00 00 	lea    0xc310(%rip),%rdi        # fc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 c2 00 00 	lea    0xc2d4(%rip),%rdi        # fc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 c2 00 00 	lea    0xc2a0(%rip),%rdi        # fbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b f6 00 00    	call   *0xf65b(%rip)        # 12fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e f6 00 00 	mov    0xf63e(%rip),%rax        # 12fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d f6 00 00 	mov    0xf60d(%rip),%rax        # 12fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea f5 00 00 	cmpq   $0x0,0xf5ea(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 f5 04 00 	lea    0x4f597(%rip),%r8        # 531a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b f5 04 00 	lea    0x4f53b(%rip),%rcx        # 53160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f f5 04 00 	lea    0x4f50f(%rip),%rcx        # 53140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 f5 04 00 	lea    0x4f541(%rip),%rcx        # 53180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 f5 04 	movdqa 0x4f550(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 f5 04 	paddq  0x4f538(%rip),%xmm0        # 531a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f f4 04 00 	cmp    %rax,0x4f49f(%rip)        # 53120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 f4 04 	movq   %xmm0,0x4f495(%rip)        # 53120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e f4 01 00 	add    0x1f43e(%rip),%rdx        # 230f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c f4 01 00 	add    0x1f42c(%rip),%rax        # 230f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 97 06 00 	mov    0x69779(%rip),%rdi        # 6d480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 f3 00 00 	mov    0xf304(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 f2 00 00 	mov    0xf2f1(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 7a 06 00 	mov    0x67ab1(%rip),%rax        # 6b800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 73 06 00 	mov    0x673f9(%rip),%rax        # 6b1c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 73 06 00 	sub    0x673e5(%rip),%rax        # 6b1c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d bf 00 00 	lea    0xbf2d(%rip),%rsi        # fd40 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 b1 00 00 	lea    0xb1c5(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 f1 00 00 	mov    0xf1f2(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 8d 06 00 	mov    0x68d8b(%rip),%rax        # 6cc10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 8d 06 00 	lea    0x68d84(%rip),%r8        # 6cc10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 8d 06 00 	mov    0x68d65(%rip),%rbx        # 6cbf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 8d 06 00 	mov    0x68d75(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 8d 06 00 	mov    0x68d11(%rip),%rdi        # 6cc00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 8d 06 00 	sub    %rsi,0x68d5a(%rip)        # 6cc50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 8c 06 00 	mov    0x68cea(%rip),%rax        # 6cbf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 8c 06 00 	add    0x68ca0(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 8c 06 00 	mov    0x68cae(%rip),%rsi        # 6cc00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 8c 06 00 	mov    0x68cbc(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 8c 06 00 	mov    %r12,0x68c6b(%rip)        # 6cc00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 8c 06 00 	mov    %rbp,0x68c59(%rip)        # 6cbf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 8c 06 00 	cmp    %rdi,0x68c3e(%rip)        # 6cbe8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 8c 06 00 	mov    %rdi,0x68c35(%rip)        # 6cbe8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 8c 06 00 	sub    %rdi,0x68c79(%rip)        # 6cc50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 8c 06 00 	mov    0x68c21(%rip),%rax        # 6cc08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 8c 06 00 	lea    0x68c1a(%rip),%r8        # 6cc08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff b6 00 00 	lea    0xb6ff(%rip),%rdx        # f708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 f0 00 00 	mov    0xf022(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d ef 00 00 	mov    0xef7d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 af 00 00 	lea    0xaf34(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 76 06 00 	cmp    0x676c9(%rip),%rdi        # 6b800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 76 06 00 	mov    0x6768f(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 76 06 00 	mov    %rdi,0x6766d(%rip)        # 6b7e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 76 06 00 	mov    %rdi,0x67649(%rip)        # 6b7e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 b0 00 00 	lea    0xb019(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 ae 00 00 	lea    0xae27(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 ef 04 	movdqa 0x4ef76(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e ef 04 	paddq  0x4ef5e(%rip),%xmm0        # 531a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 ee 01 00 	mov    0x1ee84(%rip),%r8        # 230f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e ee 04 00 	mov    0x4ee9e(%rip),%rcx        # 53120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 ed 00 00 	mov    0xedb7(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 b4 00 00 	lea    0xb4c5(%rip),%rdx        # f758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 ee 04 00 	lea    0x4eee1(%rip),%r15        # 53180 <ad_raw_peak>
    429f:	4c 8d 35 9a ee 04 00 	lea    0x4ee9a(%rip),%r14        # 53140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 ad 00 00 	lea    0xad79(%rip),%rax        # f02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 e9 00 	movq   0xe956(%rip),%xmm0        # 12c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f ee 04 00 	lea    0x4ee9f(%rip),%r13        # 53160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f ad 00 00 	lea    0xad6f(%rip),%rax        # f03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 e9 00 	movq   0xe936(%rip),%xmm0        # 12c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 ed 00 00 	mov    0xed33(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c ad 00 00 	lea    0xad0c(%rip),%rcx        # f020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d b4 00 00 	lea    0xb49d(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 ed 00 00 	mov    0xed04(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 ac 00 00 	lea    0xacf8(%rip),%rdi        # f045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 ed 01 00 	cmpq   $0x0,0x1eda6(%rip)        # 23100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd ed 01 00 	mov    0x1edbd(%rip),%r8        # 23120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be ed 01 00 	mov    0x1edbe(%rip),%r9        # 23128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af ed 01 00 	lea    0x1edaf(%rip),%rbx        # 23120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 ac 00 00 	lea    0xacf4(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 ed 01 00 	mov    0x1edb1(%rip),%rax        # 23130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a ac 00 00 	lea    0xac9a(%rip),%r12        # f020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 ec 00 00 	mov    0xec89(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 b4 00 00 	lea    0xb439(%rip),%rdx        # f7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 ed 01 00 	cmp    0x1ed33(%rip),%rbp        # 23100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 ec 00 00 	mov    0xec58(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b ac 00 00 	lea    0xac5b(%rip),%rdi        # f059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 ec 00 00 	mov    0xec23(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 b3 00 00 	lea    0xb394(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 ac 00 00 	lea    0xac40(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea b2 00 00 	lea    0xb2ea(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 eb 00 00 	mov    0xebc8(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df ab 00 00 	lea    0xabdf(%rip),%rdx        # f05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 eb 00 00 	mov    0xebb0(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ea 00 00 	mov    0xeac1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 aa 00 00 	lea    0xaa78(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 aa 00 00 	lea    0xaac0(%rip),%rdi        # f06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 aa 00 00 	lea    0xaa48(%rip),%rdi        # f087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 b1 00 00 	lea    0xb1e8(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 b7 00 	movdqa 0xb720(%rip),%xmm0        # fd90 <msg.4+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 8d 06 00 	add    0x68daa(%rip),%rax        # 6d478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c b1 00 00 	lea    0xb13c(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 e9 01 00 	cmp    %rax,0x1e9a5(%rip)        # 230e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 e9 01 00 	add    0x1e9a0(%rip),%rax        # 230f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 b1 00 00 	lea    0xb125(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 a9 00 00 	lea    0xa920(%rip),%r8        # f0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 a7 00 00 	lea    0xa775(%rip),%r8        # f0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 a6 00 00 	lea    0xa612(%rip),%r8        # f0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea a3 00 00 	lea    0xa3ea(%rip),%rdi        # f0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 7e 06 00 	mov    0x67e85(%rip),%r9        # 6cbe8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 7e 06 00 	mov    0x67ede(%rip),%r8        # 6cc48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f ab 00 00 	lea    0xab6f(%rip),%rdx        # f8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 7e 06 00 	mov    0x67ec6(%rip),%rcx        # 6cc40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 7e 06 	movsd  0x67ed4(%rip),%xmm1        # 6cc60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 7e 06 	movsd  0x67ec4(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 e2 00 00 	mov    0xe2a5(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 af 00 	movdqa 0xafc8(%rip),%xmm0        # fda0 <msg.4+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 79 06 00 	lea    0x6797f(%rip),%rax        # 6c760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 af 00 	movdqa 0xaff1(%rip),%xmm2        # fde0 <msg.4+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 79 06 00 	movaps %xmm0,0x67925(%rip)        # 6c720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad af 00 	movdqa 0xafad(%rip),%xmm0        # fdb0 <msg.4+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 7d 06 00 01 	movl   $0x1,0x67db3(%rip)        # 6cbc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 79 06 00 	movaps %xmm0,0x67913(%rip)        # 6c730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b af 00 	movdqa 0xaf9b(%rip),%xmm0        # fdc0 <msg.4+0x80>
    4e24:	00 
    4e25:	0f 29 05 14 79 06 00 	movaps %xmm0,0x67914(%rip)        # 6c740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c af 00 	movdqa 0xaf9c(%rip),%xmm0        # fdd0 <msg.4+0x90>
    4e33:	00 
    4e34:	0f 29 05 15 79 06 00 	movaps %xmm0,0x67915(%rip)        # 6c750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 69 06 00 	lea    0x66995(%rip),%r8        # 6b820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 7c 06 00 	mov    %rax,0x67cb0(%rip)        # 6cbd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 7c 06 00 	mov    %r12,0x67c8e(%rip)        # 6cbe0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 7c 06 00 	mov    %rax,0x67c77(%rip)        # 6cbd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 7c 06 00 	mov    %rbx,0x67c90(%rip)        # 6cbf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 7c 06 00 	mov    %rsi,0x67cb9(%rip)        # 6cc20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 a1 00 00 	lea    0xa174(%rip),%rdi        # f0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 7c 06 00 	mov    %rax,0x67c98(%rip)        # 6cc18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 7c 06 00    	mov    %eax,0x67c1c(%rip)        # 6cbc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 68 06 00 	mov    0x6680c(%rip),%r8        # 6b7e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 67 06 00 	mov    %rbx,0x6673c(%rip)        # 6b7e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 67 06 00 	mov    %r8,0x66728(%rip)        # 6b7e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 e0 04 00 	lea    0x4e0e9(%rip),%rcx        # 531c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 e0 04 00 	lea    0x4e098(%rip),%rcx        # 531a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 9f 00 00 	lea    0x9fc2(%rip),%rdi        # f0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 e0 04 00 	lea    0x4e016(%rip),%r12        # 531c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 9e 00 00 	lea    0x9ee8(%rip),%rax        # f112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 9e 00 00 	lea    0x9ecc(%rip),%rdx        # f0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 9f 00 00 	lea    0x9f04(%rip),%rdi        # f148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 9e 00 00 	lea    0x9edd(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 9e 00 00 	lea    0x9eaa(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae dd 01 00 	lea    0x1ddae(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 dd 01 00 	movaps %xmm0,0x1dd96(%rip)        # 230a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 dd 01 00 	mov    %rsi,0x1dd72(%rip)        # 23088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 dd 01 00 	movaps %xmm0,0x1dd93(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 dd 01 00 	movaps %xmm0,0x1dd97(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 dd 01 00 	mov    %rax,0x1dd98(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 9e 00 00 	lea    0x9e09(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d dd 01 00 	mov    0x1dd1d(%rip),%rsi        # 23088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d dd 01 00 	imul   $0x68,0x1dd6d(%rip),%rdx        # 230e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 de 04 00 	cmp    0x4de26(%rip),%rdx        # 531a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 de 04 00 	mov    0x4de25(%rip),%rax        # 531a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f de 04 00 	add    0x4de1f(%rip),%rax        # 531b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 de 04 00 	add    0x4de20(%rip),%rax        # 531b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c dd 01 00 	mov    0x1dd5c(%rip),%rcx        # 23100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 dd 01 00 	mov    %rdi,0x1dd45(%rip)        # 23100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 dd 01 00 	lea    0x1dd57(%rip),%rcx        # 23120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 72 a5 00 00 	lea    0xa572(%rip),%rdi        # f968 <_IO_stdin_used+0x968>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 9d 00 00 	lea    0x9d6f(%rip),%rdi        # f171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 63 06 00 	mov    0x663a7(%rip),%rbx        # 6b7d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a db 00 00 	mov    0xdb0a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 5b a4 00 00 	lea    0xa45b(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 62 06 00 	mov    0x6626d(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 62 06 00 	mov    %rdx,0x66247(%rip)        # 6b7e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 61 06 00 	mov    0x66194(%rip),%rbx        # 6b7d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 61 06 00 	mov    %rbx,0x66151(%rip)        # 6b7d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 61 06 00 	mov    %rdx,0x66151(%rip)        # 6b7e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 61 06 00 	lea    0x66166(%rip),%rsi        # 6b820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 7c 06 00 	addq   $0x1,0x67ce5(%rip)        # 6d468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 2f a2 00 00 	lea    0xa22f(%rip),%rdi        # f9c8 <_IO_stdin_used+0x9c8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 40 a2 00 00 	lea    0xa240(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 99 00 00 	lea    0x99d2(%rip),%rdi        # f18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 60 06 00 	lea    0x6601e(%rip),%rcx        # 6b820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 7c 06 00 	subq   $0x1,0x67c1f(%rip)        # 6d468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 9b a1 00 00 	lea    0xa19b(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 7c 06 00 	cmpq   $0x0,0x67c00(%rip)        # 6d468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 7b 06 00 	sub    %rax,0x67b55(%rip)        # 6d470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 7b 06 00 	add    %r12,0x67b33(%rip)        # 6d470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 72 06 00 	mov    0x6728f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 5e 06 00 	lea    0x65e8c(%rip),%rax        # 6b820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 71 06 00 	add    0x671e3(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 71 06 00 	mov    0x671b0(%rip),%rsi        # 6cbd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 71 06 00 	mov    0x671d1(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 71 06 00 	add    0x671c5(%rip),%r8        # 6cc18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 71 06 	addsd  0x6718d(%rip),%xmm0        # 6cc60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 5d 06 00 	lea    0x65d42(%rip),%rax        # 6b820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 71 06 00 	sub    %rdi,0x6714c(%rip)        # 6cc40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 71 06 	movsd  %xmm0,0x67164(%rip)        # 6cc60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 71 06 00 	sub    %rdx,0x6711e(%rip)        # 6cc40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 71 06 	addsd  0x67124(%rip),%xmm0        # 6cc60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 71 06 	movsd  %xmm0,0x67118(%rip)        # 6cc60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 70 06 00 	mov    0x670af(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 70 06 00 	add    %rcx,0x670a9(%rip)        # 6cc50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 70 06 00 	cmp    0x67062(%rip),%r9        # 6cc10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 70 06 00 	mov    %r9,0x67059(%rip)        # 6cc10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 70 06 00 	cmp    0x6704a(%rip),%r9        # 6cc08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 70 06 00 	mov    %r9,0x6703d(%rip)        # 6cc08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 6f 06 00 	add    0x66f53(%rip),%rdi        # 6cc18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 5b 06 00 	lea    0x65b30(%rip),%r15        # 6b820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 6e 06 00 	add    0x66ea0(%rip),%r12        # 6cbd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 6e 06 00 	add    0x66ef9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 6e 06 00 	cmp    %rax,0x66ef8(%rip)        # 6cc48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 6e 06 00 	mov    %rax,0x66ee9(%rip)        # 6cc40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 6e 06 00 	mov    %rax,0x66ee8(%rip)        # 6cc48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 6e 06 	addsd  0x66ee4(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 6e 06 	movsd  %xmm0,0x66edc(%rip)        # 6cc58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 6e 06 00    	mov    0x66e23(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 5a 06 00 	lea    0x65a5f(%rip),%rdi        # 6b820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 6e 06 00 	add    0x66e18(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 6e 06 00 	cmp    %rax,0x66e13(%rip)        # 6cc48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 6e 06 00 	mov    %rax,0x66e04(%rip)        # 6cc40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 6e 06 00 	mov    %rax,0x66e03(%rip)        # 6cc48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 6d 06 	addsd  0x66dff(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 6d 06 	movsd  %xmm0,0x66df7(%rip)        # 6cc58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 75 06 00    	mov    0x675ca(%rip),%ebx        # 6d4e8 <iteration_active>
    5f1e:	8b 05 a0 6c 06 00    	mov    0x66ca0(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 58 06 00 	lea    0x658d4(%rip),%rax        # 6b820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 6c 06 00 	add    0x66c8e(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 6c 06 00 	cmp    %rax,0x66c89(%rip)        # 6cc48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 6c 06 00 	mov    %rax,0x66c7a(%rip)        # 6cc40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 6c 06 00 	mov    %rax,0x66c79(%rip)        # 6cc48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 6c 06 	addsd  0x66c78(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 6c 06 	movsd  %xmm0,0x66c70(%rip)        # 6cc58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 6c 06 00 	mov    0x66c4d(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 74 06 	subsd  0x674bb(%rip),%xmm0        # 6d4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 74 06 	comisd 0x674ab(%rip),%xmm0        # 6d4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 74 06 	movsd  %xmm0,0x674a1(%rip)        # 6d4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 74 06 00 	addq   $0x1,0x674a4(%rip)        # 6d4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 74 06 00 	add    %rdi,0x67495(%rip)        # 6d4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_data.part.0.constprop.0>:
    6100:	41 56                	push   %r14
    6102:	8b 05 bc 6a 06 00    	mov    0x66abc(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    6108:	41 89 fe             	mov    %edi,%r14d
    610b:	41 55                	push   %r13
    610d:	44 8b 2d d4 73 06 00 	mov    0x673d4(%rip),%r13d        # 6d4e8 <iteration_active>
    6114:	41 54                	push   %r12
    6116:	49 89 f4             	mov    %rsi,%r12
    6119:	55                   	push   %rbp
    611a:	53                   	push   %rbx
    611b:	45 85 ed             	test   %r13d,%r13d
    611e:	0f 84 1c 01 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x140>
    6124:	48 83 05 b4 73 06 00 	addq   $0x1,0x673b4(%rip)        # 6d4e0 <iteration_requests>
    612b:	01 
    612c:	48 83 05 a4 73 06 00 	addq   $0x18,0x673a4(%rip)        # 6d4d8 <iteration_bytes>
    6133:	18 
    6134:	85 c0                	test   %eax,%eax
    6136:	0f 84 8c 01 00 00    	je     62c8 <fwp_data.part.0.constprop.0+0x1c8>
    613c:	0f b6 05 7f 66 06 00 	movzbl 0x6667f(%rip),%eax        # 6c7c2 <fwp_heap+0xfa2>
    6143:	48 8d 15 d6 56 06 00 	lea    0x656d6(%rip),%rdx        # 6b820 <fwp_heap>
    614a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6151:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6155:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6159:	48 8b 18             	mov    (%rax),%rbx
    615c:	48 85 db             	test   %rbx,%rbx
    615f:	0f 84 fb 00 00 00    	je     6260 <fwp_data.part.0.constprop.0+0x160>
    6165:	48 8b 13             	mov    (%rbx),%rdx
    6168:	48 f7 d2             	not    %rdx
    616b:	48 89 10             	mov    %rdx,(%rax)
    616e:	48 83 fd 18          	cmp    $0x18,%rbp
    6172:	76 1b                	jbe    618f <fwp_data.part.0.constprop.0+0x8f>
    6174:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6178:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    617c:	31 f6                	xor    %esi,%esi
    617e:	48 c1 e8 03          	shr    $0x3,%rax
    6182:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6189:	00 
    618a:	e8 21 d3 ff ff       	call   34b0 <memset@plt>
    618f:	48 89 e8             	mov    %rbp,%rax
    6192:	48 03 05 a7 6a 06 00 	add    0x66aa7(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    6199:	0f 82 3d 01 00 00    	jb     62dc <fwp_data.part.0.constprop.0+0x1dc>
    619f:	48 39 05 a2 6a 06 00 	cmp    %rax,0x66aa2(%rip)        # 6cc48 <fwp_heap+0x1428>
    61a6:	48 89 05 93 6a 06 00 	mov    %rax,0x66a93(%rip)        # 6cc40 <fwp_heap+0x1420>
    61ad:	73 07                	jae    61b6 <fwp_data.part.0.constprop.0+0xb6>
    61af:	48 89 05 92 6a 06 00 	mov    %rax,0x66a92(%rip)        # 6cc48 <fwp_heap+0x1428>
    61b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61ba:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    61bf:	f2 0f 58 05 91 6a 06 	addsd  0x66a91(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    61c6:	00 
    61c7:	f2 0f 11 05 89 6a 06 	movsd  %xmm0,0x66a89(%rip)        # 6cc58 <fwp_heap+0x1438>
    61ce:	00 
    61cf:	45 85 ed             	test   %r13d,%r13d
    61d2:	74 33                	je     6207 <fwp_data.part.0.constprop.0+0x107>
    61d4:	48 8b 05 65 6a 06 00 	mov    0x66a65(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    61db:	48 85 c0             	test   %rax,%rax
    61de:	0f 88 a4 00 00 00    	js     6288 <fwp_data.part.0.constprop.0+0x188>
    61e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61e8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61ed:	f2 0f 5c 05 d3 72 06 	subsd  0x672d3(%rip),%xmm0        # 6d4c8 <iteration_start_charge>
    61f4:	00 
    61f5:	66 0f 2f 05 c3 72 06 	comisd 0x672c3(%rip),%xmm0        # 6d4c0 <iteration_peak>
    61fc:	00 
    61fd:	76 08                	jbe    6207 <fwp_data.part.0.constprop.0+0x107>
    61ff:	f2 0f 11 05 b9 72 06 	movsd  %xmm0,0x672b9(%rip)        # 6d4c0 <iteration_peak>
    6206:	00 
    6207:	b8 02 00 00 00       	mov    $0x2,%eax
    620c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6211:	66 0f 6e c8          	movd   %eax,%xmm1
    6215:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6219:	66 0f d6 03          	movq   %xmm0,(%rbx)
    621d:	49 8b 04 24          	mov    (%r12),%rax
    6221:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6225:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    622a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    622e:	48 89 d8             	mov    %rbx,%rax
    6231:	5b                   	pop    %rbx
    6232:	5d                   	pop    %rbp
    6233:	41 5c                	pop    %r12
    6235:	41 5d                	pop    %r13
    6237:	41 5e                	pop    %r14
    6239:	c3                   	ret
    623a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6240:	85 c0                	test   %eax,%eax
    6242:	0f 85 f4 fe ff ff    	jne    613c <fwp_data.part.0.constprop.0+0x3c>
    6248:	31 f6                	xor    %esi,%esi
    624a:	bf 18 00 00 00       	mov    $0x18,%edi
    624f:	e8 bc fc ff ff       	call   5f10 <fwp_heap_alloc>
    6254:	48 89 c3             	mov    %rax,%rbx
    6257:	eb ae                	jmp    6207 <fwp_data.part.0.constprop.0+0x107>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6260:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6264:	48 85 db             	test   %rbx,%rbx
    6267:	74 47                	je     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6269:	48 8b 50 10          	mov    0x10(%rax),%rdx
    626d:	48 29 da             	sub    %rbx,%rdx
    6270:	48 39 ea             	cmp    %rbp,%rdx
    6273:	72 3b                	jb     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6275:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    627d:	e9 ec fe ff ff       	jmp    616e <fwp_data.part.0.constprop.0+0x6e>
    6282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6288:	48 89 c2             	mov    %rax,%rdx
    628b:	83 e0 01             	and    $0x1,%eax
    628e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6292:	48 d1 ea             	shr    $1,%rdx
    6295:	48 09 c2             	or     %rax,%rdx
    6298:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    629d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    62a1:	e9 47 ff ff ff       	jmp    61ed <fwp_data.part.0.constprop.0+0xed>
    62a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ad:	00 00 00 
    62b0:	31 f6                	xor    %esi,%esi
    62b2:	bf 18 00 00 00       	mov    $0x18,%edi
    62b7:	e8 54 fc ff ff       	call   5f10 <fwp_heap_alloc>
    62bc:	48 89 c3             	mov    %rax,%rbx
    62bf:	e9 0b ff ff ff       	jmp    61cf <fwp_data.part.0.constprop.0+0xcf>
    62c4:	0f 1f 40 00          	nopl   0x0(%rax)
    62c8:	31 f6                	xor    %esi,%esi
    62ca:	bf 18 00 00 00       	mov    $0x18,%edi
    62cf:	e8 3c fc ff ff       	call   5f10 <fwp_heap_alloc>
    62d4:	48 89 c3             	mov    %rax,%rbx
    62d7:	e9 f8 fe ff ff       	jmp    61d4 <fwp_data.part.0.constprop.0+0xd4>
    62dc:	e8 4f db ff ff       	call   3e30 <fwp_heap_oom>
    62e1:	0f 1f 40 00          	nopl   0x0(%rax)
    62e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62ec:	00 00 00 00 

00000000000062f0 <fwp_p_ad_push.constprop.0>:
    62f0:	41 57                	push   %r15
    62f2:	41 56                	push   %r14
    62f4:	41 55                	push   %r13
    62f6:	49 89 d5             	mov    %rdx,%r13
    62f9:	41 54                	push   %r12
    62fb:	49 89 fc             	mov    %rdi,%r12
    62fe:	55                   	push   %rbp
    62ff:	53                   	push   %rbx
    6300:	48 83 ec 38          	sub    $0x38,%rsp
    6304:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6309:	48 85 ff             	test   %rdi,%rdi
    630c:	79 09                	jns    6317 <fwp_p_ad_push.constprop.0+0x27>
    630e:	48 85 d2             	test   %rdx,%rdx
    6311:	0f 88 a9 01 00 00    	js     64c0 <fwp_p_ad_push.constprop.0+0x1d0>
    6317:	48 89 f8             	mov    %rdi,%rax
    631a:	48 89 0c 24          	mov    %rcx,(%rsp)
    631e:	48 09 d0             	or     %rdx,%rax
    6321:	0f 89 79 01 00 00    	jns    64a0 <fwp_p_ad_push.constprop.0+0x1b0>
    6327:	48 89 f8             	mov    %rdi,%rax
    632a:	48 c1 f8 20          	sar    $0x20,%rax
    632e:	48 85 ff             	test   %rdi,%rdi
    6331:	79 24                	jns    6357 <fwp_p_ad_push.constprop.0+0x67>
    6333:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6338:	48 89 d0             	mov    %rdx,%rax
    633b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6342:	00 
    6343:	49 89 d4             	mov    %rdx,%r12
    6346:	48 c1 f8 20          	sar    $0x20,%rax
    634a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6351:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6357:	48 89 c7             	mov    %rax,%rdi
    635a:	e8 d1 e3 ff ff       	call   4730 <fwp_tape_of>
    635f:	48 89 c3             	mov    %rax,%rbx
    6362:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6367:	0f 85 f7 02 00 00    	jne    6664 <fwp_p_ad_push.constprop.0+0x374>
    636d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6371:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6378:	0f 8f 49 02 00 00    	jg     65c7 <fwp_p_ad_push.constprop.0+0x2d7>
    637e:	44 89 e0             	mov    %r12d,%eax
    6381:	49 39 c7             	cmp    %rax,%r15
    6384:	0f 8e 49 02 00 00    	jle    65d3 <fwp_p_ad_push.constprop.0+0x2e3>
    638a:	4d 85 ed             	test   %r13,%r13
    638d:	78 0c                	js     639b <fwp_p_ad_push.constprop.0+0xab>
    638f:	44 89 e8             	mov    %r13d,%eax
    6392:	49 39 c7             	cmp    %rax,%r15
    6395:	0f 8e 38 02 00 00    	jle    65d3 <fwp_p_ad_push.constprop.0+0x2e3>
    639b:	4d 89 fe             	mov    %r15,%r14
    639e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    63a2:	49 8d 46 01          	lea    0x1(%r14),%rax
    63a6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    63ac:	0f 87 15 02 00 00    	ja     65c7 <fwp_p_ad_push.constprop.0+0x2d7>
    63b2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    63b6:	48 39 e8             	cmp    %rbp,%rax
    63b9:	0f 8e 31 01 00 00    	jle    64f0 <fwp_p_ad_push.constprop.0+0x200>
    63bf:	48 85 ed             	test   %rbp,%rbp
    63c2:	ba 40 00 00 00       	mov    $0x40,%edx
    63c7:	48 0f 44 ea          	cmove  %rdx,%rbp
    63cb:	48 39 e8             	cmp    %rbp,%rax
    63ce:	7e 20                	jle    63f0 <fwp_p_ad_push.constprop.0+0x100>
    63d0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    63d7:	0f 8f 03 01 00 00    	jg     64e0 <fwp_p_ad_push.constprop.0+0x1f0>
    63dd:	48 01 ed             	add    %rbp,%rbp
    63e0:	48 39 e8             	cmp    %rbp,%rax
    63e3:	7f eb                	jg     63d0 <fwp_p_ad_push.constprop.0+0xe0>
    63e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63ec:	00 00 00 00 
    63f0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    63f7:	00 
    63f8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    63fc:	ba 01 00 00 00       	mov    $0x1,%edx
    6401:	48 89 c6             	mov    %rax,%rsi
    6404:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6409:	e8 82 ed ff ff       	call   5190 <ad_raw_realloc>
    640e:	48 85 c0             	test   %rax,%rax
    6411:	0f 84 c8 01 00 00    	je     65df <fwp_p_ad_push.constprop.0+0x2ef>
    6417:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    641b:	48 89 e9             	mov    %rbp,%rcx
    641e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6422:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6426:	48 c1 e1 04          	shl    $0x4,%rcx
    642a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    642e:	48 89 ce             	mov    %rcx,%rsi
    6431:	ba 02 00 00 00       	mov    $0x2,%edx
    6436:	48 89 43 28          	mov    %rax,0x28(%rbx)
    643a:	e8 51 ed ff ff       	call   5190 <ad_raw_realloc>
    643f:	48 85 c0             	test   %rax,%rax
    6442:	0f 84 97 01 00 00    	je     65df <fwp_p_ad_push.constprop.0+0x2ef>
    6448:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    644c:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6450:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6457:	00 
    6458:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    645f:	00 
    6460:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    6467:	00 
    6468:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    646c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6471:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6475:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    6479:	4d 85 f6             	test   %r14,%r14
    647c:	0f 85 e6 00 00 00    	jne    6568 <fwp_p_ad_push.constprop.0+0x278>
    6482:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6486:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    648a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    648e:	48 01 d1             	add    %rdx,%rcx
    6491:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    6495:	eb 79                	jmp    6510 <fwp_p_ad_push.constprop.0+0x220>
    6497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    649e:	00 00 
    64a0:	48 89 d0             	mov    %rdx,%rax
    64a3:	48 c1 ff 20          	sar    $0x20,%rdi
    64a7:	48 c1 f8 20          	sar    $0x20,%rax
    64ab:	48 39 c7             	cmp    %rax,%rdi
    64ae:	0f 84 a3 fe ff ff    	je     6357 <fwp_p_ad_push.constprop.0+0x67>
    64b4:	48 8d 3d 5d 95 00 00 	lea    0x955d(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    64bb:	e8 90 df ff ff       	call   4450 <fwp_trap>
    64c0:	48 83 c4 38          	add    $0x38,%rsp
    64c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    64cb:	5b                   	pop    %rbx
    64cc:	5d                   	pop    %rbp
    64cd:	41 5c                	pop    %r12
    64cf:	41 5d                	pop    %r13
    64d1:	41 5e                	pop    %r14
    64d3:	41 5f                	pop    %r15
    64d5:	c3                   	ret
    64d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64dd:	00 00 00 
    64e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    64e5:	e9 06 ff ff ff       	jmp    63f0 <fwp_p_ad_push.constprop.0+0x100>
    64ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64f0:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64f4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    64f8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64ff:	00 
    6500:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6507:	00 
    6508:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    650c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6510:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6516:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    651a:	4d 85 ed             	test   %r13,%r13
    651d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6522:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6528:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6533:	49 8d 47 01          	lea    0x1(%r15),%rax
    6537:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    653b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6541:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6545:	48 83 c4 38          	add    $0x38,%rsp
    6549:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6550:	ff ff ff 
    6553:	4c 21 e0             	and    %r12,%rax
    6556:	5b                   	pop    %rbx
    6557:	5d                   	pop    %rbp
    6558:	4c 09 f8             	or     %r15,%rax
    655b:	41 5c                	pop    %r12
    655d:	41 5d                	pop    %r13
    655f:	41 5e                	pop    %r14
    6561:	41 5f                	pop    %r15
    6563:	c3                   	ret
    6564:	0f 1f 40 00          	nopl   0x0(%rax)
    6568:	4c 89 ca             	mov    %r9,%rdx
    656b:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6570:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6575:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    657a:	e8 71 d0 ff ff       	call   35f0 <memmove@plt>
    657f:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    6584:	4c 03 73 30          	add    0x30(%rbx),%r14
    6588:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    658d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6591:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6595:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    659a:	48 03 7b 20          	add    0x20(%rbx),%rdi
    659e:	4c 89 d2             	mov    %r10,%rdx
    65a1:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    65a6:	e8 45 d0 ff ff       	call   35f0 <memmove@plt>
    65ab:	48 8b 43 30          	mov    0x30(%rbx),%rax
    65af:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65b3:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    65b8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    65bd:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    65c2:	e9 bf fe ff ff       	jmp    6486 <fwp_p_ad_push.constprop.0+0x196>
    65c7:	48 8d 3d d9 8b 00 00 	lea    0x8bd9(%rip),%rdi        # f1a7 <_IO_stdin_used+0x1a7>
    65ce:	e8 7d de ff ff       	call   4450 <fwp_trap>
    65d3:	48 8d 3d e8 8b 00 00 	lea    0x8be8(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    65da:	e8 71 de ff ff       	call   4450 <fwp_trap>
    65df:	48 89 df             	mov    %rbx,%rdi
    65e2:	e8 a9 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    65e7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    65eb:	48 85 ff             	test   %rdi,%rdi
    65ee:	74 05                	je     65f5 <fwp_p_ad_push.constprop.0+0x305>
    65f0:	e8 db ea ff ff       	call   50d0 <ad_raw_free.part.0>
    65f5:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    65f9:	48 85 ff             	test   %rdi,%rdi
    65fc:	74 05                	je     6603 <fwp_p_ad_push.constprop.0+0x313>
    65fe:	e8 cd ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6603:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6607:	48 85 ff             	test   %rdi,%rdi
    660a:	74 05                	je     6611 <fwp_p_ad_push.constprop.0+0x321>
    660c:	e8 bf ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6611:	31 c9                	xor    %ecx,%ecx
    6613:	31 c0                	xor    %eax,%eax
    6615:	31 d2                	xor    %edx,%edx
    6617:	be 01 00 00 00       	mov    $0x1,%esi
    661c:	89 53 04             	mov    %edx,0x4(%rbx)
    661f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6623:	ba 13 00 00 00       	mov    $0x13,%edx
    6628:	48 8d 3d d9 89 00 00 	lea    0x89d9(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    662f:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6633:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6637:	48 8b 0d 02 ca 00 00 	mov    0xca02(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    663e:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6642:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6646:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    664a:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    664e:	e8 0d d0 ff ff       	call   3660 <fwrite@plt>
    6653:	31 ff                	xor    %edi,%edi
    6655:	e8 46 cf ff ff       	call   35a0 <fflush@plt>
    665a:	bf 66 00 00 00       	mov    $0x66,%edi
    665f:	e8 1c d0 ff ff       	call   3680 <_Exit@plt>
    6664:	48 8d 3d f5 93 00 00 	lea    0x93f5(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    666b:	e8 e0 dd ff ff       	call   4450 <fwp_trap>

0000000000006670 <w120>:
    6670:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6674:	41 55                	push   %r13
    6676:	48 89 fa             	mov    %rdi,%rdx
    6679:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    667d:	41 54                	push   %r12
    667f:	49 89 fc             	mov    %rdi,%r12
    6682:	55                   	push   %rbp
    6683:	53                   	push   %rbx
    6684:	48 89 f3             	mov    %rsi,%rbx
    6687:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    668c:	48 89 f1             	mov    %rsi,%rcx
    668f:	48 83 ec 28          	sub    $0x28,%rsp
    6693:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6699:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    669f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    66a5:	e8 46 fc ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    66aa:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    66b0:	48 89 da             	mov    %rbx,%rdx
    66b3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    66b9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66c0:	00 f0 3f 
    66c3:	48 89 c7             	mov    %rax,%rdi
    66c6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    66cd:	00 f0 bf 
    66d0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    66d5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66db:	e8 10 fc ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    66e0:	f2 0f 10 05 80 96 00 	movsd  0x9680(%rip),%xmm0        # fd68 <msg.4+0x28>
    66e7:	00 
    66e8:	4c 89 e7             	mov    %r12,%rdi
    66eb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    66f1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66f8:	00 f0 3f 
    66fb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6702:	49 89 c5             	mov    %rax,%r13
    6705:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    670c:	00 f0 bf 
    670f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6714:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    671a:	e8 d1 fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    671f:	48 89 e9             	mov    %rbp,%rcx
    6722:	4c 89 ea             	mov    %r13,%rdx
    6725:	48 89 ee             	mov    %rbp,%rsi
    6728:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    672e:	4c 89 ef             	mov    %r13,%rdi
    6731:	49 89 c4             	mov    %rax,%r12
    6734:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6738:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    673e:	e8 ad fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    6743:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6749:	f2 0f 59 1d 1f 96 00 	mulsd  0x961f(%rip),%xmm3        # fd70 <msg.4+0x30>
    6750:	00 
    6751:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6758:	00 59 40 
    675b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6760:	48 89 c2             	mov    %rax,%rdx
    6763:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    676a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6770:	e8 7b fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    6775:	48 89 d9             	mov    %rbx,%rcx
    6778:	4c 89 e2             	mov    %r12,%rdx
    677b:	48 89 de             	mov    %rbx,%rsi
    677e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6784:	4c 89 e7             	mov    %r12,%rdi
    6787:	48 89 c5             	mov    %rax,%rbp
    678a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    678e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6794:	e8 57 fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    6799:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    679f:	48 89 ea             	mov    %rbp,%rdx
    67a2:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    67a8:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    67af:	00 f0 3f 
    67b2:	48 89 c7             	mov    %rax,%rdi
    67b5:	48 89 ce             	mov    %rcx,%rsi
    67b8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    67bd:	e8 2e fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    67c2:	48 83 c4 28          	add    $0x28,%rsp
    67c6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    67cb:	5b                   	pop    %rbx
    67cc:	5d                   	pop    %rbp
    67cd:	41 5c                	pop    %r12
    67cf:	41 5d                	pop    %r13
    67d1:	c3                   	ret
    67d2:	0f 1f 00             	nopl   (%rax)
    67d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67dc:	00 00 00 00 

00000000000067e0 <w176.constprop.0>:
    67e0:	41 54                	push   %r12
    67e2:	55                   	push   %rbp
    67e3:	53                   	push   %rbx
    67e4:	48 83 ec 10          	sub    $0x10,%rsp
    67e8:	4c 8b 27             	mov    (%rdi),%r12
    67eb:	4d 85 e4             	test   %r12,%r12
    67ee:	74 58                	je     6848 <w176.constprop.0+0x68>
    67f0:	48 89 fd             	mov    %rdi,%rbp
    67f3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67f7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67fe:	31 db                	xor    %ebx,%ebx
    6800:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6806:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    680b:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6812:	00 f0 3f 
    6815:	48 83 c3 02          	add    $0x2,%rbx
    6819:	48 89 ce             	mov    %rcx,%rsi
    681c:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6822:	e8 c9 fa ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    6827:	4c 39 e3             	cmp    %r12,%rbx
    682a:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6830:	48 89 c7             	mov    %rax,%rdi
    6833:	72 cb                	jb     6800 <w176.constprop.0+0x20>
    6835:	48 83 c4 10          	add    $0x10,%rsp
    6839:	48 89 f8             	mov    %rdi,%rax
    683c:	5b                   	pop    %rbx
    683d:	5d                   	pop    %rbp
    683e:	41 5c                	pop    %r12
    6840:	c3                   	ret
    6841:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6848:	48 83 c4 10          	add    $0x10,%rsp
    684c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6853:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6857:	5b                   	pop    %rbx
    6858:	48 89 f8             	mov    %rdi,%rax
    685b:	5d                   	pop    %rbp
    685c:	41 5c                	pop    %r12
    685e:	c3                   	ret
    685f:	90                   	nop

0000000000006860 <fwp_rc_share>:
    6860:	48 8b 05 91 63 06 00 	mov    0x66391(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    6867:	48 2b 3d 62 63 06 00 	sub    0x66362(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    686e:	48 c1 e0 10          	shl    $0x10,%rax
    6872:	48 39 c7             	cmp    %rax,%rdi
    6875:	73 4a                	jae    68c1 <fwp_rc_share+0x61>
    6877:	48 89 f8             	mov    %rdi,%rax
    687a:	48 c1 e8 10          	shr    $0x10,%rax
    687e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6882:	48 8b 05 8f 63 06 00 	mov    0x6638f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    6889:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    688d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6891:	48 85 d2             	test   %rdx,%rdx
    6894:	74 2b                	je     68c1 <fwp_rc_share+0x61>
    6896:	0f b6 08             	movzbl (%rax),%ecx
    6899:	80 f9 02             	cmp    $0x2,%cl
    689c:	74 2a                	je     68c8 <fwp_rc_share+0x68>
    689e:	80 f9 01             	cmp    $0x1,%cl
    68a1:	75 1e                	jne    68c1 <fwp_rc_share+0x61>
    68a3:	8b 48 18             	mov    0x18(%rax),%ecx
    68a6:	0f b7 ff             	movzwl %di,%edi
    68a9:	8b 40 1c             	mov    0x1c(%rax),%eax
    68ac:	48 0f af f9          	imul   %rcx,%rdi
    68b0:	48 c1 ef 20          	shr    $0x20,%rdi
    68b4:	48 39 c7             	cmp    %rax,%rdi
    68b7:	73 08                	jae    68c1 <fwp_rc_share+0x61>
    68b9:	48 01 fa             	add    %rdi,%rdx
    68bc:	80 3a 00             	cmpb   $0x0,(%rdx)
    68bf:	75 0d                	jne    68ce <fwp_rc_share+0x6e>
    68c1:	c3                   	ret
    68c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68c8:	66 85 ff             	test   %di,%di
    68cb:	74 ef                	je     68bc <fwp_rc_share+0x5c>
    68cd:	c3                   	ret
    68ce:	50                   	push   %rax
    68cf:	48 8d 3d ba 91 00 00 	lea    0x91ba(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    68d6:	e8 75 db ff ff       	call   4450 <fwp_trap>
    68db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000068e0 <fwp_rc_fresh>:
    68e0:	48 8b 15 11 63 06 00 	mov    0x66311(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    68e7:	48 89 f8             	mov    %rdi,%rax
    68ea:	48 89 fe             	mov    %rdi,%rsi
    68ed:	48 2b 05 dc 62 06 00 	sub    0x662dc(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    68f4:	48 c1 e2 10          	shl    $0x10,%rdx
    68f8:	48 39 d0             	cmp    %rdx,%rax
    68fb:	73 4f                	jae    694c <fwp_rc_fresh+0x6c>
    68fd:	48 89 c2             	mov    %rax,%rdx
    6900:	48 c1 ea 10          	shr    $0x10,%rdx
    6904:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6908:	48 8b 15 09 63 06 00 	mov    0x66309(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    690f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6913:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6917:	48 85 d2             	test   %rdx,%rdx
    691a:	74 30                	je     694c <fwp_rc_fresh+0x6c>
    691c:	0f b6 39             	movzbl (%rcx),%edi
    691f:	40 80 ff 02          	cmp    $0x2,%dil
    6923:	74 2b                	je     6950 <fwp_rc_fresh+0x70>
    6925:	40 80 ff 01          	cmp    $0x1,%dil
    6929:	75 21                	jne    694c <fwp_rc_fresh+0x6c>
    692b:	8b 79 18             	mov    0x18(%rcx),%edi
    692e:	0f b7 c0             	movzwl %ax,%eax
    6931:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6934:	48 0f af c7          	imul   %rdi,%rax
    6938:	48 c1 e8 20          	shr    $0x20,%rax
    693c:	48 39 c8             	cmp    %rcx,%rax
    693f:	73 0b                	jae    694c <fwp_rc_fresh+0x6c>
    6941:	48 01 c2             	add    %rax,%rdx
    6944:	80 3a ff             	cmpb   $0xff,(%rdx)
    6947:	74 17                	je     6960 <fwp_rc_fresh+0x80>
    6949:	c6 02 01             	movb   $0x1,(%rdx)
    694c:	48 89 f0             	mov    %rsi,%rax
    694f:	c3                   	ret
    6950:	66 85 c0             	test   %ax,%ax
    6953:	74 ef                	je     6944 <fwp_rc_fresh+0x64>
    6955:	48 89 f0             	mov    %rsi,%rax
    6958:	c3                   	ret
    6959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6960:	48 83 ec 18          	sub    $0x18,%rsp
    6964:	48 89 d7             	mov    %rdx,%rdi
    6967:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    696c:	48 89 14 24          	mov    %rdx,(%rsp)
    6970:	e8 5b ee ff ff       	call   57d0 <fwp_rc_forget_slot>
    6975:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    697a:	48 8b 14 24          	mov    (%rsp),%rdx
    697e:	48 89 f0             	mov    %rsi,%rax
    6981:	c6 02 01             	movb   $0x1,(%rdx)
    6984:	48 83 c4 18          	add    $0x18,%rsp
    6988:	c3                   	ret
    6989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006990 <fwp_rc_free_obj>:
    6990:	48 8b 15 61 62 06 00 	mov    0x66261(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6997:	48 89 f8             	mov    %rdi,%rax
    699a:	48 2b 05 2f 62 06 00 	sub    0x6622f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    69a1:	48 c1 e2 10          	shl    $0x10,%rdx
    69a5:	48 39 d0             	cmp    %rdx,%rax
    69a8:	73 5b                	jae    6a05 <fwp_rc_free_obj+0x75>
    69aa:	48 89 c2             	mov    %rax,%rdx
    69ad:	48 c1 ea 10          	shr    $0x10,%rdx
    69b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69b5:	48 8b 15 5c 62 06 00 	mov    0x6625c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    69bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    69c0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    69c4:	48 85 c9             	test   %rcx,%rcx
    69c7:	74 3c                	je     6a05 <fwp_rc_free_obj+0x75>
    69c9:	0f b6 32             	movzbl (%rdx),%esi
    69cc:	40 80 fe 02          	cmp    $0x2,%sil
    69d0:	74 2e                	je     6a00 <fwp_rc_free_obj+0x70>
    69d2:	40 80 fe 01          	cmp    $0x1,%sil
    69d6:	75 2d                	jne    6a05 <fwp_rc_free_obj+0x75>
    69d8:	8b 72 18             	mov    0x18(%rdx),%esi
    69db:	0f b7 c0             	movzwl %ax,%eax
    69de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69e1:	48 0f af c6          	imul   %rsi,%rax
    69e5:	48 c1 e8 20          	shr    $0x20,%rax
    69e9:	48 39 d0             	cmp    %rdx,%rax
    69ec:	73 17                	jae    6a05 <fwp_rc_free_obj+0x75>
    69ee:	48 01 c1             	add    %rax,%rcx
    69f1:	80 39 01             	cmpb   $0x1,(%rcx)
    69f4:	75 0f                	jne    6a05 <fwp_rc_free_obj+0x75>
    69f6:	e9 15 f0 ff ff       	jmp    5a10 <fwp_mem_free>
    69fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a00:	66 85 c0             	test   %ax,%ax
    6a03:	74 ec                	je     69f1 <fwp_rc_free_obj+0x61>
    6a05:	c3                   	ret
    6a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a0d:	00 00 00 

0000000000006a10 <fwp_rc_dup>:
    6a10:	f3 0f 1e fa          	endbr64
    6a14:	48 8b 05 dd 61 06 00 	mov    0x661dd(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    6a1b:	48 2b 3d ae 61 06 00 	sub    0x661ae(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    6a22:	48 c1 e0 10          	shl    $0x10,%rax
    6a26:	48 39 c7             	cmp    %rax,%rdi
    6a29:	73 60                	jae    6a8b <fwp_rc_dup+0x7b>
    6a2b:	48 89 f8             	mov    %rdi,%rax
    6a2e:	48 c1 e8 10          	shr    $0x10,%rax
    6a32:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a36:	48 8b 05 db 61 06 00 	mov    0x661db(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    6a3d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6a41:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6a45:	48 85 c0             	test   %rax,%rax
    6a48:	74 41                	je     6a8b <fwp_rc_dup+0x7b>
    6a4a:	0f b6 0a             	movzbl (%rdx),%ecx
    6a4d:	80 f9 02             	cmp    $0x2,%cl
    6a50:	74 3e                	je     6a90 <fwp_rc_dup+0x80>
    6a52:	80 f9 01             	cmp    $0x1,%cl
    6a55:	75 34                	jne    6a8b <fwp_rc_dup+0x7b>
    6a57:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6a5a:	0f b7 ff             	movzwl %di,%edi
    6a5d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a60:	48 0f af f9          	imul   %rcx,%rdi
    6a64:	48 c1 ef 20          	shr    $0x20,%rdi
    6a68:	48 39 d7             	cmp    %rdx,%rdi
    6a6b:	73 1e                	jae    6a8b <fwp_rc_dup+0x7b>
    6a6d:	48 01 f8             	add    %rdi,%rax
    6a70:	0f b6 10             	movzbl (%rax),%edx
    6a73:	84 d2                	test   %dl,%dl
    6a75:	74 14                	je     6a8b <fwp_rc_dup+0x7b>
    6a77:	8b 0d 6b 6a 06 00    	mov    0x66a6b(%rip),%ecx        # 6d4e8 <iteration_active>
    6a7d:	85 c9                	test   %ecx,%ecx
    6a7f:	75 1f                	jne    6aa0 <fwp_rc_dup+0x90>
    6a81:	80 fa fd             	cmp    $0xfd,%dl
    6a84:	77 2a                	ja     6ab0 <fwp_rc_dup+0xa0>
    6a86:	83 c2 01             	add    $0x1,%edx
    6a89:	88 10                	mov    %dl,(%rax)
    6a8b:	c3                   	ret
    6a8c:	0f 1f 40 00          	nopl   0x0(%rax)
    6a90:	66 85 ff             	test   %di,%di
    6a93:	74 db                	je     6a70 <fwp_rc_dup+0x60>
    6a95:	c3                   	ret
    6a96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a9d:	00 00 00 
    6aa0:	48 83 05 28 6a 06 00 	addq   $0x1,0x66a28(%rip)        # 6d4d0 <iteration_retains>
    6aa7:	01 
    6aa8:	eb d7                	jmp    6a81 <fwp_rc_dup+0x71>
    6aaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ab0:	48 89 c7             	mov    %rax,%rdi
    6ab3:	e9 f8 eb ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6ab8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6abf:	00 

0000000000006ac0 <fwp_owned_entry173>:
    6ac0:	f3 0f 1e fa          	endbr64
    6ac4:	48 83 ec 38          	sub    $0x38,%rsp
    6ac8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6acd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ad4:	00 00 
    6ad6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6adb:	31 c0                	xor    %eax,%eax
    6add:	48 8b 07             	mov    (%rdi),%rax
    6ae0:	48 03 47 10          	add    0x10(%rdi),%rax
    6ae4:	0f 80 c2 00 00 00    	jo     6bac <fwp_owned_entry173+0xec>
    6aea:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6aef:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6af4:	31 ff                	xor    %edi,%edi
    6af6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6afa:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6aff:	e8 fc f5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6b04:	48 8b 15 ed 60 06 00 	mov    0x660ed(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6b0b:	48 89 c6             	mov    %rax,%rsi
    6b0e:	48 2b 05 bb 60 06 00 	sub    0x660bb(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6b15:	48 c1 e2 10          	shl    $0x10,%rdx
    6b19:	48 39 d0             	cmp    %rdx,%rax
    6b1c:	73 4f                	jae    6b6d <fwp_owned_entry173+0xad>
    6b1e:	48 89 c2             	mov    %rax,%rdx
    6b21:	48 c1 ea 10          	shr    $0x10,%rdx
    6b25:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b29:	48 8b 15 e8 60 06 00 	mov    0x660e8(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6b30:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b34:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b38:	48 85 d2             	test   %rdx,%rdx
    6b3b:	74 30                	je     6b6d <fwp_owned_entry173+0xad>
    6b3d:	0f b6 39             	movzbl (%rcx),%edi
    6b40:	40 80 ff 02          	cmp    $0x2,%dil
    6b44:	74 42                	je     6b88 <fwp_owned_entry173+0xc8>
    6b46:	40 80 ff 01          	cmp    $0x1,%dil
    6b4a:	75 21                	jne    6b6d <fwp_owned_entry173+0xad>
    6b4c:	8b 79 18             	mov    0x18(%rcx),%edi
    6b4f:	0f b7 c0             	movzwl %ax,%eax
    6b52:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b55:	48 0f af c7          	imul   %rdi,%rax
    6b59:	48 c1 e8 20          	shr    $0x20,%rax
    6b5d:	48 39 c8             	cmp    %rcx,%rax
    6b60:	73 0b                	jae    6b6d <fwp_owned_entry173+0xad>
    6b62:	48 01 c2             	add    %rax,%rdx
    6b65:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b68:	74 26                	je     6b90 <fwp_owned_entry173+0xd0>
    6b6a:	c6 02 01             	movb   $0x1,(%rdx)
    6b6d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b72:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b79:	00 00 
    6b7b:	75 34                	jne    6bb1 <fwp_owned_entry173+0xf1>
    6b7d:	48 89 f0             	mov    %rsi,%rax
    6b80:	48 83 c4 38          	add    $0x38,%rsp
    6b84:	c3                   	ret
    6b85:	0f 1f 00             	nopl   (%rax)
    6b88:	66 85 c0             	test   %ax,%ax
    6b8b:	75 e0                	jne    6b6d <fwp_owned_entry173+0xad>
    6b8d:	eb d6                	jmp    6b65 <fwp_owned_entry173+0xa5>
    6b8f:	90                   	nop
    6b90:	48 89 d7             	mov    %rdx,%rdi
    6b93:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b98:	48 89 14 24          	mov    %rdx,(%rsp)
    6b9c:	e8 2f ec ff ff       	call   57d0 <fwp_rc_forget_slot>
    6ba1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6ba6:	48 8b 14 24          	mov    (%rsp),%rdx
    6baa:	eb be                	jmp    6b6a <fwp_owned_entry173+0xaa>
    6bac:	e8 4f cb ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6bb1:	e8 9a c8 ff ff       	call   3450 <__stack_chk_fail@plt>
    6bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bbd:	00 00 00 

0000000000006bc0 <e173>:
    6bc0:	f3 0f 1e fa          	endbr64
    6bc4:	53                   	push   %rbx
    6bc5:	48 83 ec 30          	sub    $0x30,%rsp
    6bc9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6bce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bd5:	00 00 
    6bd7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6bdc:	31 c0                	xor    %eax,%eax
    6bde:	48 8b 07             	mov    (%rdi),%rax
    6be1:	48 03 47 10          	add    0x10(%rdi),%rax
    6be5:	0f 80 c9 00 00 00    	jo     6cb4 <e173+0xf4>
    6beb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6bf0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6bf5:	31 ff                	xor    %edi,%edi
    6bf7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6bfb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c00:	e8 fb f4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6c05:	48 8b 15 ec 5f 06 00 	mov    0x65fec(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6c0c:	48 89 c3             	mov    %rax,%rbx
    6c0f:	48 2b 05 ba 5f 06 00 	sub    0x65fba(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6c16:	48 c1 e2 10          	shl    $0x10,%rdx
    6c1a:	48 39 d0             	cmp    %rdx,%rax
    6c1d:	73 4f                	jae    6c6e <e173+0xae>
    6c1f:	48 89 c2             	mov    %rax,%rdx
    6c22:	48 c1 ea 10          	shr    $0x10,%rdx
    6c26:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c2a:	48 8b 15 e7 5f 06 00 	mov    0x65fe7(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6c31:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c35:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c39:	48 85 d2             	test   %rdx,%rdx
    6c3c:	74 30                	je     6c6e <e173+0xae>
    6c3e:	0f b6 31             	movzbl (%rcx),%esi
    6c41:	40 80 fe 02          	cmp    $0x2,%sil
    6c45:	74 49                	je     6c90 <e173+0xd0>
    6c47:	40 80 fe 01          	cmp    $0x1,%sil
    6c4b:	75 21                	jne    6c6e <e173+0xae>
    6c4d:	8b 71 18             	mov    0x18(%rcx),%esi
    6c50:	0f b7 c0             	movzwl %ax,%eax
    6c53:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c56:	48 0f af c6          	imul   %rsi,%rax
    6c5a:	48 c1 e8 20          	shr    $0x20,%rax
    6c5e:	48 39 c8             	cmp    %rcx,%rax
    6c61:	73 0b                	jae    6c6e <e173+0xae>
    6c63:	48 01 c2             	add    %rax,%rdx
    6c66:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c69:	74 35                	je     6ca0 <e173+0xe0>
    6c6b:	c6 02 01             	movb   $0x1,(%rdx)
    6c6e:	48 89 df             	mov    %rbx,%rdi
    6c71:	e8 ea fb ff ff       	call   6860 <fwp_rc_share>
    6c76:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c7b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c82:	00 00 
    6c84:	75 33                	jne    6cb9 <e173+0xf9>
    6c86:	48 83 c4 30          	add    $0x30,%rsp
    6c8a:	48 89 d8             	mov    %rbx,%rax
    6c8d:	5b                   	pop    %rbx
    6c8e:	c3                   	ret
    6c8f:	90                   	nop
    6c90:	66 85 c0             	test   %ax,%ax
    6c93:	75 d9                	jne    6c6e <e173+0xae>
    6c95:	eb cf                	jmp    6c66 <e173+0xa6>
    6c97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c9e:	00 00 
    6ca0:	48 89 d7             	mov    %rdx,%rdi
    6ca3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ca8:	e8 23 eb ff ff       	call   57d0 <fwp_rc_forget_slot>
    6cad:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6cb2:	eb b7                	jmp    6c6b <e173+0xab>
    6cb4:	e8 47 ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6cb9:	e8 92 c7 ff ff       	call   3450 <__stack_chk_fail@plt>
    6cbe:	66 90                	xchg   %ax,%ax

0000000000006cc0 <fwp_closure_drop>:
    6cc0:	48 8b 15 31 5f 06 00 	mov    0x65f31(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6cc7:	48 89 f8             	mov    %rdi,%rax
    6cca:	48 2b 05 ff 5e 06 00 	sub    0x65eff(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6cd1:	48 c1 e2 10          	shl    $0x10,%rdx
    6cd5:	48 39 d0             	cmp    %rdx,%rax
    6cd8:	73 6b                	jae    6d45 <fwp_closure_drop+0x85>
    6cda:	48 89 c2             	mov    %rax,%rdx
    6cdd:	48 c1 ea 10          	shr    $0x10,%rdx
    6ce1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ce5:	48 8b 15 2c 5f 06 00 	mov    0x65f2c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6cec:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6cf0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6cf4:	48 85 d2             	test   %rdx,%rdx
    6cf7:	74 4c                	je     6d45 <fwp_closure_drop+0x85>
    6cf9:	0f b6 31             	movzbl (%rcx),%esi
    6cfc:	40 80 fe 02          	cmp    $0x2,%sil
    6d00:	74 3e                	je     6d40 <fwp_closure_drop+0x80>
    6d02:	40 80 fe 01          	cmp    $0x1,%sil
    6d06:	75 3d                	jne    6d45 <fwp_closure_drop+0x85>
    6d08:	8b 71 18             	mov    0x18(%rcx),%esi
    6d0b:	0f b7 c0             	movzwl %ax,%eax
    6d0e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d11:	48 0f af c6          	imul   %rsi,%rax
    6d15:	48 c1 e8 20          	shr    $0x20,%rax
    6d19:	48 39 c8             	cmp    %rcx,%rax
    6d1c:	73 27                	jae    6d45 <fwp_closure_drop+0x85>
    6d1e:	48 01 c2             	add    %rax,%rdx
    6d21:	0f b6 02             	movzbl (%rdx),%eax
    6d24:	84 c0                	test   %al,%al
    6d26:	74 1d                	je     6d45 <fwp_closure_drop+0x85>
    6d28:	3c 01                	cmp    $0x1,%al
    6d2a:	74 24                	je     6d50 <fwp_closure_drop+0x90>
    6d2c:	3c ff                	cmp    $0xff,%al
    6d2e:	74 48                	je     6d78 <fwp_closure_drop+0xb8>
    6d30:	83 e8 01             	sub    $0x1,%eax
    6d33:	88 02                	mov    %al,(%rdx)
    6d35:	c3                   	ret
    6d36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d3d:	00 00 00 
    6d40:	66 85 c0             	test   %ax,%ax
    6d43:	74 dc                	je     6d21 <fwp_closure_drop+0x61>
    6d45:	c3                   	ret
    6d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d4d:	00 00 00 
    6d50:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6d57:	ff ff 
    6d59:	48 85 c0             	test   %rax,%rax
    6d5c:	74 12                	je     6d70 <fwp_closure_drop+0xb0>
    6d5e:	48 89 fe             	mov    %rdi,%rsi
    6d61:	48 89 c7             	mov    %rax,%rdi
    6d64:	e9 47 d7 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    6d69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d70:	e9 eb d8 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    6d75:	0f 1f 00             	nopl   (%rax)
    6d78:	48 89 d0             	mov    %rdx,%rax
    6d7b:	48 8d 35 9e 4a 06 00 	lea    0x64a9e(%rip),%rsi        # 6b820 <fwp_heap>
    6d82:	48 83 ec 18          	sub    $0x18,%rsp
    6d86:	48 c1 e8 11          	shr    $0x11,%rax
    6d8a:	48 31 d0             	xor    %rdx,%rax
    6d8d:	48 89 c1             	mov    %rax,%rcx
    6d90:	48 c1 e9 09          	shr    $0x9,%rcx
    6d94:	48 31 c8             	xor    %rcx,%rax
    6d97:	0f b6 c8             	movzbl %al,%ecx
    6d9a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6da1:	00 
    6da2:	48 85 c0             	test   %rax,%rax
    6da5:	75 22                	jne    6dc9 <fwp_closure_drop+0x109>
    6da7:	eb 59                	jmp    6e02 <fwp_closure_drop+0x142>
    6da9:	90                   	nop
    6daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6db1:	00 00 00 00 
    6db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dbc:	00 00 00 00 
    6dc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6dc4:	48 85 c0             	test   %rax,%rax
    6dc7:	74 39                	je     6e02 <fwp_closure_drop+0x142>
    6dc9:	48 89 c1             	mov    %rax,%rcx
    6dcc:	48 39 10             	cmp    %rdx,(%rax)
    6dcf:	75 ef                	jne    6dc0 <fwp_closure_drop+0x100>
    6dd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6dd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6dd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6ddd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6de4:	74 05                	je     6deb <fwp_closure_drop+0x12b>
    6de6:	48 83 c4 18          	add    $0x18,%rsp
    6dea:	c3                   	ret
    6deb:	48 89 d7             	mov    %rdx,%rdi
    6dee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6df3:	e8 d8 e9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6df8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6dfd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6e00:	eb e4                	jmp    6de6 <fwp_closure_drop+0x126>
    6e02:	48 8d 3d e7 8b 00 00 	lea    0x8be7(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    6e09:	e8 42 d6 ff ff       	call   4450 <fwp_trap>
    6e0e:	66 90                	xchg   %ax,%ax

0000000000006e10 <fwp_owned_tape_release>:
    6e10:	48 85 ff             	test   %rdi,%rdi
    6e13:	0f 84 f7 00 00 00    	je     6f10 <fwp_owned_tape_release+0x100>
    6e19:	41 54                	push   %r12
    6e1b:	55                   	push   %rbp
    6e1c:	53                   	push   %rbx
    6e1d:	48 8b 07             	mov    (%rdi),%rax
    6e20:	48 85 c0             	test   %rax,%rax
    6e23:	74 08                	je     6e2d <fwp_owned_tape_release+0x1d>
    6e25:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e29:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6e2d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e31:	48 85 d2             	test   %rdx,%rdx
    6e34:	74 03                	je     6e39 <fwp_owned_tape_release+0x29>
    6e36:	48 89 02             	mov    %rax,(%rdx)
    6e39:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6e3d:	48 89 fb             	mov    %rdi,%rbx
    6e40:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6e44:	48 85 c0             	test   %rax,%rax
    6e47:	0f 84 89 00 00 00    	je     6ed6 <fwp_owned_tape_release+0xc6>
    6e4d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6e51:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6e55:	7e 47                	jle    6e9e <fwp_owned_tape_release+0x8e>
    6e57:	31 ed                	xor    %ebp,%ebp
    6e59:	eb 0d                	jmp    6e68 <fwp_owned_tape_release+0x58>
    6e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6e60:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e64:	48 8b 40 68          	mov    0x68(%rax),%rax
    6e68:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6e6c:	49 89 ec             	mov    %rbp,%r12
    6e6f:	48 83 c5 01          	add    $0x1,%rbp
    6e73:	49 c1 e4 04          	shl    $0x4,%r12
    6e77:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6e7b:	ff d0                	call   *%rax
    6e7d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6e81:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6e86:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e8a:	ff 50 68             	call   *0x68(%rax)
    6e8d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6e91:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6e95:	48 39 e8             	cmp    %rbp,%rax
    6e98:	7f c6                	jg     6e60 <fwp_owned_tape_release+0x50>
    6e9a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e9e:	31 ed                	xor    %ebp,%ebp
    6ea0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6ea5:	7e 28                	jle    6ecf <fwp_owned_tape_release+0xbf>
    6ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6eae:	00 00 
    6eb0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6eb4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6eb8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6ebc:	74 07                	je     6ec5 <fwp_owned_tape_release+0xb5>
    6ebe:	ff 52 68             	call   *0x68(%rdx)
    6ec1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6ec5:	48 83 c5 01          	add    $0x1,%rbp
    6ec9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6ecd:	7f e1                	jg     6eb0 <fwp_owned_tape_release+0xa0>
    6ecf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6ed3:	ff 52 68             	call   *0x68(%rdx)
    6ed6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6eda:	e8 e1 fd ff ff       	call   6cc0 <fwp_closure_drop>
    6edf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6ee3:	e8 d8 fd ff ff       	call   6cc0 <fwp_closure_drop>
    6ee8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6eec:	e8 cf fd ff ff       	call   6cc0 <fwp_closure_drop>
    6ef1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6ef5:	e8 16 eb ff ff       	call   5a10 <fwp_mem_free>
    6efa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6efe:	e8 0d eb ff ff       	call   5a10 <fwp_mem_free>
    6f03:	48 89 df             	mov    %rbx,%rdi
    6f06:	5b                   	pop    %rbx
    6f07:	5d                   	pop    %rbp
    6f08:	41 5c                	pop    %r12
    6f0a:	e9 01 eb ff ff       	jmp    5a10 <fwp_mem_free>
    6f0f:	90                   	nop
    6f10:	c3                   	ret
    6f11:	0f 1f 40 00          	nopl   0x0(%rax)
    6f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f1c:	00 00 00 00 

0000000000006f20 <fwp_tape_finish>:
    6f20:	f3 0f 1e fa          	endbr64
    6f24:	41 55                	push   %r13
    6f26:	41 54                	push   %r12
    6f28:	55                   	push   %rbp
    6f29:	53                   	push   %rbx
    6f2a:	48 83 ec 48          	sub    $0x48,%rsp
    6f2e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    6f35:	00 00 
    6f37:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    6f3c:	48 8d 3d 5d c1 01 00 	lea    0x1c15d(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    6f43:	e8 f8 e1 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6f48:	48 83 3d 98 c1 01 00 	cmpq   $0x0,0x1c198(%rip)        # 230e8 <fwp_ntapes>
    6f4f:	00 
    6f50:	48 c7 05 2d c1 01 00 	movq   $0x0,0x1c12d(%rip)        # 23088 <fwp_tape_cached_bytes>
    6f57:	00 00 00 00 
    6f5b:	7e 79                	jle    6fd6 <fwp_tape_finish+0xb6>
    6f5d:	45 31 e4             	xor    %r12d,%r12d
    6f60:	31 ed                	xor    %ebp,%ebp
    6f62:	0f 1f 00             	nopl   (%rax)
    6f65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f6c:	00 00 00 00 
    6f70:	48 8b 1d 79 c1 01 00 	mov    0x1c179(%rip),%rbx        # 230f0 <fwp_tapes>
    6f77:	48 83 c5 01          	add    $0x1,%rbp
    6f7b:	4c 01 e3             	add    %r12,%rbx
    6f7e:	49 83 c4 68          	add    $0x68,%r12
    6f82:	48 89 df             	mov    %rbx,%rdi
    6f85:	e8 06 cd ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6f8a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    6f8f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    6f94:	48 89 e7             	mov    %rsp,%rdi
    6f97:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6f9b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6f9f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6fa4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6fa9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    6fae:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    6fb2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6fb7:	e8 84 e1 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6fbc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6fc0:	e8 4b fe ff ff       	call   6e10 <fwp_owned_tape_release>
    6fc5:	48 39 2d 1c c1 01 00 	cmp    %rbp,0x1c11c(%rip)        # 230e8 <fwp_ntapes>
    6fcc:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6fd3:	00 
    6fd4:	7f 9a                	jg     6f70 <fwp_tape_finish+0x50>
    6fd6:	48 8b 3d 13 c1 01 00 	mov    0x1c113(%rip),%rdi        # 230f0 <fwp_tapes>
    6fdd:	48 85 ff             	test   %rdi,%rdi
    6fe0:	74 05                	je     6fe7 <fwp_tape_finish+0xc7>
    6fe2:	e8 e9 e0 ff ff       	call   50d0 <ad_raw_free.part.0>
    6fe7:	48 c7 05 fe c0 01 00 	movq   $0x0,0x1c0fe(%rip)        # 230f0 <fwp_tapes>
    6fee:	00 00 00 00 
    6ff2:	48 c7 05 e3 c0 01 00 	movq   $0x0,0x1c0e3(%rip)        # 230e0 <fwp_tapes_cap>
    6ff9:	00 00 00 00 
    6ffd:	48 c7 05 e0 c0 01 00 	movq   $0x0,0x1c0e0(%rip)        # 230e8 <fwp_ntapes>
    7004:	00 00 00 00 
    7008:	48 c7 05 c5 c0 01 00 	movq   $0x0,0x1c0c5(%rip)        # 230d8 <fwp_tape_next_slot>
    700f:	00 00 00 00 
    7013:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7018:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    701f:	00 00 
    7021:	75 0b                	jne    702e <fwp_tape_finish+0x10e>
    7023:	48 83 c4 48          	add    $0x48,%rsp
    7027:	5b                   	pop    %rbx
    7028:	5d                   	pop    %rbp
    7029:	41 5c                	pop    %r12
    702b:	41 5d                	pop    %r13
    702d:	c3                   	ret
    702e:	e8 1d c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    7033:	66 90                	xchg   %ax,%ax
    7035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    703c:	00 00 00 00 

0000000000007040 <fwp_tape_scope_release>:
    7040:	f3 0f 1e fa          	endbr64
    7044:	41 55                	push   %r13
    7046:	41 54                	push   %r12
    7048:	55                   	push   %rbp
    7049:	53                   	push   %rbx
    704a:	48 83 ec 48          	sub    $0x48,%rsp
    704e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7055:	00 00 
    7057:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    705c:	48 63 07             	movslq (%rdi),%rax
    705f:	85 c0                	test   %eax,%eax
    7061:	0f 88 e8 00 00 00    	js     714f <fwp_tape_scope_release+0x10f>
    7067:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    706e:	ec c4 4e 
    7071:	48 89 fb             	mov    %rdi,%rbx
    7074:	48 89 e5             	mov    %rsp,%rbp
    7077:	eb 1f                	jmp    7098 <fwp_tape_scope_release+0x58>
    7079:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7080:	e8 bb e0 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7085:	4c 89 ef             	mov    %r13,%rdi
    7088:	e8 83 fd ff ff       	call   6e10 <fwp_owned_tape_release>
    708d:	48 63 03             	movslq (%rbx),%rax
    7090:	85 c0                	test   %eax,%eax
    7092:	0f 88 b7 00 00 00    	js     714f <fwp_tape_scope_release+0x10f>
    7098:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    709c:	48 8b 35 4d c0 01 00 	mov    0x1c04d(%rip),%rsi        # 230f0 <fwp_tapes>
    70a3:	4c 01 c6             	add    %r8,%rsi
    70a6:	48 89 f7             	mov    %rsi,%rdi
    70a9:	e8 e2 cb ff ff       	call   3c90 <fwp_tape_unlink_scope>
    70ae:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    70b3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    70b8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    70bf:	48 8b 46 40          	mov    0x40(%rsi),%rax
    70c3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    70c7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    70ce:	00 
    70cf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    70d4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    70d9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    70dd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    70e2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70e6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    70eb:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    70f2:	00 
    70f3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    70fa:	00 
    70fb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7102:	00 
    7103:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7107:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    710b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    710f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7113:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7119:	77 18                	ja     7133 <fwp_tape_scope_release+0xf3>
    711b:	49 c1 f8 03          	sar    $0x3,%r8
    711f:	4d 0f af c4          	imul   %r12,%r8
    7123:	4c 3b 05 ae bf 01 00 	cmp    0x1bfae(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    712a:	7d 07                	jge    7133 <fwp_tape_scope_release+0xf3>
    712c:	4c 89 05 a5 bf 01 00 	mov    %r8,0x1bfa5(%rip)        # 230d8 <fwp_tape_next_slot>
    7133:	48 89 ef             	mov    %rbp,%rdi
    7136:	4d 85 ed             	test   %r13,%r13
    7139:	0f 85 41 ff ff ff    	jne    7080 <fwp_tape_scope_release+0x40>
    713f:	e8 1c e1 ff ff       	call   5260 <fwp_tape_buffers_release>
    7144:	48 63 03             	movslq (%rbx),%rax
    7147:	85 c0                	test   %eax,%eax
    7149:	0f 89 49 ff ff ff    	jns    7098 <fwp_tape_scope_release+0x58>
    714f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7154:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    715b:	00 00 
    715d:	75 0b                	jne    716a <fwp_tape_scope_release+0x12a>
    715f:	48 83 c4 48          	add    $0x48,%rsp
    7163:	5b                   	pop    %rbx
    7164:	5d                   	pop    %rbp
    7165:	41 5c                	pop    %r12
    7167:	41 5d                	pop    %r13
    7169:	c3                   	ret
    716a:	e8 e1 c2 ff ff       	call   3450 <__stack_chk_fail@plt>
    716f:	90                   	nop

0000000000007170 <fwp_drop4>:
    7170:	48 8b 0d 81 5a 06 00 	mov    0x65a81(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    7177:	48 89 f8             	mov    %rdi,%rax
    717a:	48 2b 05 4f 5a 06 00 	sub    0x65a4f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7181:	48 c1 e1 10          	shl    $0x10,%rcx
    7185:	48 39 c8             	cmp    %rcx,%rax
    7188:	0f 83 42 01 00 00    	jae    72d0 <fwp_drop4+0x160>
    718e:	48 83 ec 18          	sub    $0x18,%rsp
    7192:	48 89 fa             	mov    %rdi,%rdx
    7195:	4c 8d 05 84 46 06 00 	lea    0x64684(%rip),%r8        # 6b820 <fwp_heap>
    719c:	48 89 c1             	mov    %rax,%rcx
    719f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    71a6:	48 c1 e9 10          	shr    $0x10,%rcx
    71aa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    71ae:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    71b2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    71b6:	48 85 c9             	test   %rcx,%rcx
    71b9:	74 40                	je     71fb <fwp_drop4+0x8b>
    71bb:	0f b6 3e             	movzbl (%rsi),%edi
    71be:	40 80 ff 02          	cmp    $0x2,%dil
    71c2:	74 3c                	je     7200 <fwp_drop4+0x90>
    71c4:	40 80 ff 01          	cmp    $0x1,%dil
    71c8:	75 31                	jne    71fb <fwp_drop4+0x8b>
    71ca:	8b 7e 18             	mov    0x18(%rsi),%edi
    71cd:	0f b7 c0             	movzwl %ax,%eax
    71d0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71d3:	48 0f af c7          	imul   %rdi,%rax
    71d7:	48 c1 e8 20          	shr    $0x20,%rax
    71db:	48 39 f0             	cmp    %rsi,%rax
    71de:	73 1b                	jae    71fb <fwp_drop4+0x8b>
    71e0:	48 01 c1             	add    %rax,%rcx
    71e3:	0f b6 01             	movzbl (%rcx),%eax
    71e6:	84 c0                	test   %al,%al
    71e8:	74 11                	je     71fb <fwp_drop4+0x8b>
    71ea:	3c 01                	cmp    $0x1,%al
    71ec:	74 22                	je     7210 <fwp_drop4+0xa0>
    71ee:	3c ff                	cmp    $0xff,%al
    71f0:	0f 84 0a 01 00 00    	je     7300 <fwp_drop4+0x190>
    71f6:	83 e8 01             	sub    $0x1,%eax
    71f9:	88 01                	mov    %al,(%rcx)
    71fb:	48 83 c4 18          	add    $0x18,%rsp
    71ff:	c3                   	ret
    7200:	66 85 c0             	test   %ax,%ax
    7203:	74 de                	je     71e3 <fwp_drop4+0x73>
    7205:	48 83 c4 18          	add    $0x18,%rsp
    7209:	c3                   	ret
    720a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7210:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7214:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    721b:	48 89 f8             	mov    %rdi,%rax
    721e:	48 c1 e1 10          	shl    $0x10,%rcx
    7222:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7229:	48 39 c8             	cmp    %rcx,%rax
    722c:	73 62                	jae    7290 <fwp_drop4+0x120>
    722e:	48 89 c1             	mov    %rax,%rcx
    7231:	48 c1 e9 10          	shr    $0x10,%rcx
    7235:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7239:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    723d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7241:	48 85 c9             	test   %rcx,%rcx
    7244:	74 4a                	je     7290 <fwp_drop4+0x120>
    7246:	44 0f b6 0e          	movzbl (%rsi),%r9d
    724a:	41 80 f9 02          	cmp    $0x2,%r9b
    724e:	0f 84 9c 00 00 00    	je     72f0 <fwp_drop4+0x180>
    7254:	41 80 f9 01          	cmp    $0x1,%r9b
    7258:	75 36                	jne    7290 <fwp_drop4+0x120>
    725a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    725e:	0f b7 c0             	movzwl %ax,%eax
    7261:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7264:	49 0f af c1          	imul   %r9,%rax
    7268:	48 c1 e8 20          	shr    $0x20,%rax
    726c:	48 39 f0             	cmp    %rsi,%rax
    726f:	73 1f                	jae    7290 <fwp_drop4+0x120>
    7271:	48 01 c1             	add    %rax,%rcx
    7274:	0f b6 01             	movzbl (%rcx),%eax
    7277:	84 c0                	test   %al,%al
    7279:	74 15                	je     7290 <fwp_drop4+0x120>
    727b:	3c 01                	cmp    $0x1,%al
    727d:	74 59                	je     72d8 <fwp_drop4+0x168>
    727f:	3c ff                	cmp    $0xff,%al
    7281:	0f 84 ff 00 00 00    	je     7386 <fwp_drop4+0x216>
    7287:	83 e8 01             	sub    $0x1,%eax
    728a:	88 01                	mov    %al,(%rcx)
    728c:	0f 1f 40 00          	nopl   0x0(%rax)
    7290:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7294:	48 89 d7             	mov    %rdx,%rdi
    7297:	48 89 0c 24          	mov    %rcx,(%rsp)
    729b:	e8 f0 f6 ff ff       	call   6990 <fwp_rc_free_obj>
    72a0:	4c 8d 05 79 45 06 00 	lea    0x64579(%rip),%r8        # 6b820 <fwp_heap>
    72a7:	48 8b 04 24          	mov    (%rsp),%rax
    72ab:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    72b2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    72b9:	48 c1 e2 10          	shl    $0x10,%rdx
    72bd:	48 39 d0             	cmp    %rdx,%rax
    72c0:	0f 83 35 ff ff ff    	jae    71fb <fwp_drop4+0x8b>
    72c6:	48 8b 14 24          	mov    (%rsp),%rdx
    72ca:	e9 cd fe ff ff       	jmp    719c <fwp_drop4+0x2c>
    72cf:	90                   	nop
    72d0:	c3                   	ret
    72d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72d8:	48 89 14 24          	mov    %rdx,(%rsp)
    72dc:	e8 af f6 ff ff       	call   6990 <fwp_rc_free_obj>
    72e1:	48 8b 14 24          	mov    (%rsp),%rdx
    72e5:	eb a9                	jmp    7290 <fwp_drop4+0x120>
    72e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72ee:	00 00 
    72f0:	66 85 c0             	test   %ax,%ax
    72f3:	75 9b                	jne    7290 <fwp_drop4+0x120>
    72f5:	e9 7a ff ff ff       	jmp    7274 <fwp_drop4+0x104>
    72fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7300:	48 89 c8             	mov    %rcx,%rax
    7303:	48 c1 e8 11          	shr    $0x11,%rax
    7307:	48 31 c8             	xor    %rcx,%rax
    730a:	48 89 c2             	mov    %rax,%rdx
    730d:	48 c1 ea 09          	shr    $0x9,%rdx
    7311:	48 31 d0             	xor    %rdx,%rax
    7314:	0f b6 d0             	movzbl %al,%edx
    7317:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    731e:	00 
    731f:	48 85 c0             	test   %rax,%rax
    7322:	75 29                	jne    734d <fwp_drop4+0x1dd>
    7324:	e9 e3 00 00 00       	jmp    740c <fwp_drop4+0x29c>
    7329:	90                   	nop
    732a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7331:	00 00 00 00 
    7335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    733c:	00 00 00 00 
    7340:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7344:	48 85 c0             	test   %rax,%rax
    7347:	0f 84 bf 00 00 00    	je     740c <fwp_drop4+0x29c>
    734d:	48 89 c2             	mov    %rax,%rdx
    7350:	48 39 08             	cmp    %rcx,(%rax)
    7353:	75 eb                	jne    7340 <fwp_drop4+0x1d0>
    7355:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7359:	48 83 ea 01          	sub    $0x1,%rdx
    735d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7361:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7368:	0f 85 8d fe ff ff    	jne    71fb <fwp_drop4+0x8b>
    736e:	48 89 cf             	mov    %rcx,%rdi
    7371:	48 89 0c 24          	mov    %rcx,(%rsp)
    7375:	e8 56 e4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    737a:	48 8b 0c 24          	mov    (%rsp),%rcx
    737e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7381:	e9 75 fe ff ff       	jmp    71fb <fwp_drop4+0x8b>
    7386:	48 89 ce             	mov    %rcx,%rsi
    7389:	48 c1 ee 11          	shr    $0x11,%rsi
    738d:	48 31 ce             	xor    %rcx,%rsi
    7390:	48 89 f0             	mov    %rsi,%rax
    7393:	48 c1 e8 09          	shr    $0x9,%rax
    7397:	48 31 c6             	xor    %rax,%rsi
    739a:	40 0f b6 f6          	movzbl %sil,%esi
    739e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    73a5:	00 
    73a6:	48 85 c0             	test   %rax,%rax
    73a9:	75 1e                	jne    73c9 <fwp_drop4+0x259>
    73ab:	eb 5f                	jmp    740c <fwp_drop4+0x29c>
    73ad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    73b4:	00 
    73b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73bc:	00 00 00 00 
    73c0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    73c4:	48 85 c0             	test   %rax,%rax
    73c7:	74 43                	je     740c <fwp_drop4+0x29c>
    73c9:	48 89 c6             	mov    %rax,%rsi
    73cc:	48 39 08             	cmp    %rcx,(%rax)
    73cf:	75 ef                	jne    73c0 <fwp_drop4+0x250>
    73d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    73d5:	48 83 ee 01          	sub    $0x1,%rsi
    73d9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    73dd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    73e4:	0f 85 a6 fe ff ff    	jne    7290 <fwp_drop4+0x120>
    73ea:	48 89 cf             	mov    %rcx,%rdi
    73ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    73f2:	48 89 0c 24          	mov    %rcx,(%rsp)
    73f6:	e8 d5 e3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    73fb:	48 8b 0c 24          	mov    (%rsp),%rcx
    73ff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7404:	c6 01 fe             	movb   $0xfe,(%rcx)
    7407:	e9 84 fe ff ff       	jmp    7290 <fwp_drop4+0x120>
    740c:	48 8d 3d dd 85 00 00 	lea    0x85dd(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7413:	e8 38 d0 ff ff       	call   4450 <fwp_trap>
    7418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    741f:	00 

0000000000007420 <fwp_arg_drop37>:
    7420:	f3 0f 1e fa          	endbr64
    7424:	85 f6                	test   %esi,%esi
    7426:	75 04                	jne    742c <fwp_arg_drop37+0xc>
    7428:	85 d2                	test   %edx,%edx
    742a:	75 04                	jne    7430 <fwp_arg_drop37+0x10>
    742c:	c3                   	ret
    742d:	0f 1f 00             	nopl   (%rax)
    7430:	48 8b 3f             	mov    (%rdi),%rdi
    7433:	e9 38 fd ff ff       	jmp    7170 <fwp_drop4>
    7438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    743f:	00 

0000000000007440 <fwp_task_dispose>:
    7440:	53                   	push   %rbx
    7441:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7445:	0f 84 fb c2 ff ff    	je     3746 <fwp_task_dispose.cold>
    744b:	48 89 fb             	mov    %rdi,%rbx
    744e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7453:	0f 85 ed c2 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7459:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    745d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7464:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    746b:	00 
    746c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7470:	48 85 ff             	test   %rdi,%rdi
    7473:	74 07                	je     747c <fwp_task_dispose+0x3c>
    7475:	48 85 c0             	test   %rax,%rax
    7478:	74 02                	je     747c <fwp_task_dispose+0x3c>
    747a:	ff d0                	call   *%rax
    747c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7483:	e8 88 e5 ff ff       	call   5a10 <fwp_mem_free>
    7488:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    748f:	00 00 00 00 
    7493:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7497:	74 6f                	je     7508 <fwp_task_dispose+0xc8>
    7499:	48 8b 15 58 57 06 00 	mov    0x65758(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    74a0:	48 89 d8             	mov    %rbx,%rax
    74a3:	48 2b 05 26 57 06 00 	sub    0x65726(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    74aa:	48 c1 e2 10          	shl    $0x10,%rdx
    74ae:	48 39 d0             	cmp    %rdx,%rax
    74b1:	73 4c                	jae    74ff <fwp_task_dispose+0xbf>
    74b3:	48 89 c2             	mov    %rax,%rdx
    74b6:	48 c1 ea 10          	shr    $0x10,%rdx
    74ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74be:	48 8b 15 53 57 06 00 	mov    0x65753(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    74c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74c9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    74cd:	48 85 c9             	test   %rcx,%rcx
    74d0:	74 2d                	je     74ff <fwp_task_dispose+0xbf>
    74d2:	0f b6 32             	movzbl (%rdx),%esi
    74d5:	40 80 fe 02          	cmp    $0x2,%sil
    74d9:	74 3d                	je     7518 <fwp_task_dispose+0xd8>
    74db:	40 80 fe 01          	cmp    $0x1,%sil
    74df:	75 1e                	jne    74ff <fwp_task_dispose+0xbf>
    74e1:	8b 72 18             	mov    0x18(%rdx),%esi
    74e4:	0f b7 c0             	movzwl %ax,%eax
    74e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74ea:	48 0f af c6          	imul   %rsi,%rax
    74ee:	48 c1 e8 20          	shr    $0x20,%rax
    74f2:	48 39 d0             	cmp    %rdx,%rax
    74f5:	73 08                	jae    74ff <fwp_task_dispose+0xbf>
    74f7:	48 01 c1             	add    %rax,%rcx
    74fa:	80 39 01             	cmpb   $0x1,(%rcx)
    74fd:	74 09                	je     7508 <fwp_task_dispose+0xc8>
    74ff:	5b                   	pop    %rbx
    7500:	c3                   	ret
    7501:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7508:	48 89 df             	mov    %rbx,%rdi
    750b:	5b                   	pop    %rbx
    750c:	e9 ff e4 ff ff       	jmp    5a10 <fwp_mem_free>
    7511:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7518:	66 85 c0             	test   %ax,%ax
    751b:	74 dd                	je     74fa <fwp_task_dispose+0xba>
    751d:	5b                   	pop    %rbx
    751e:	c3                   	ret
    751f:	90                   	nop

0000000000007520 <fwp_free_zombie>:
    7520:	48 8b 15 c9 42 06 00 	mov    0x642c9(%rip),%rdx        # 6b7f0 <fwp_zombie>
    7527:	48 85 d2             	test   %rdx,%rdx
    752a:	0f 84 98 00 00 00    	je     75c8 <fwp_free_zombie+0xa8>
    7530:	48 3b 15 c9 42 06 00 	cmp    0x642c9(%rip),%rdx        # 6b800 <fwp_cur>
    7537:	0f 84 8b 00 00 00    	je     75c8 <fwp_free_zombie+0xa8>
    753d:	48 83 ec 18          	sub    $0x18,%rsp
    7541:	48 63 05 8c 3c 06 00 	movslq 0x63c8c(%rip),%rax        # 6b1d4 <fwp_stack_pool_n>
    7548:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    754c:	83 f8 3f             	cmp    $0x3f,%eax
    754f:	7f 7f                	jg     75d0 <fwp_free_zombie+0xb0>
    7551:	8d 48 01             	lea    0x1(%rax),%ecx
    7554:	89 0d 7a 3c 06 00    	mov    %ecx,0x63c7a(%rip)        # 6b1d4 <fwp_stack_pool_n>
    755a:	48 8d 0d 7f 3c 06 00 	lea    0x63c7f(%rip),%rcx        # 6b1e0 <fwp_stack_pool>
    7561:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7565:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    756c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7570:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7577:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    757b:	48 85 c9             	test   %rcx,%rcx
    757e:	0f 84 fc 00 00 00    	je     7680 <fwp_free_zombie+0x160>
    7584:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    758b:	48 85 c0             	test   %rax,%rax
    758e:	74 07                	je     7597 <fwp_free_zombie+0x77>
    7590:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7597:	8b 42 5c             	mov    0x5c(%rdx),%eax
    759a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    759e:	48 c7 05 47 42 06 00 	movq   $0x0,0x64247(%rip)        # 6b7f0 <fwp_zombie>
    75a5:	00 00 00 00 
    75a9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    75b0:	85 c0                	test   %eax,%eax
    75b2:	74 34                	je     75e8 <fwp_free_zombie+0xc8>
    75b4:	83 f8 01             	cmp    $0x1,%eax
    75b7:	0f 84 b3 00 00 00    	je     7670 <fwp_free_zombie+0x150>
    75bd:	48 83 c4 18          	add    $0x18,%rsp
    75c1:	c3                   	ret
    75c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75c8:	c3                   	ret
    75c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75d0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    75d4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    75d9:	e8 e2 bf ff ff       	call   35c0 <munmap@plt>
    75de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75e3:	eb 80                	jmp    7565 <fwp_free_zombie+0x45>
    75e5:	0f 1f 00             	nopl   (%rax)
    75e8:	48 8b 0d 09 56 06 00 	mov    0x65609(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    75ef:	48 89 d0             	mov    %rdx,%rax
    75f2:	48 2b 05 d7 55 06 00 	sub    0x655d7(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    75f9:	48 c1 e1 10          	shl    $0x10,%rcx
    75fd:	48 39 c8             	cmp    %rcx,%rax
    7600:	73 bb                	jae    75bd <fwp_free_zombie+0x9d>
    7602:	48 89 c1             	mov    %rax,%rcx
    7605:	48 c1 e9 10          	shr    $0x10,%rcx
    7609:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    760d:	48 8b 0d 04 56 06 00 	mov    0x65604(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    7614:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7618:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    761c:	48 85 c9             	test   %rcx,%rcx
    761f:	74 9c                	je     75bd <fwp_free_zombie+0x9d>
    7621:	0f b6 3e             	movzbl (%rsi),%edi
    7624:	40 80 ff 02          	cmp    $0x2,%dil
    7628:	74 66                	je     7690 <fwp_free_zombie+0x170>
    762a:	40 80 ff 01          	cmp    $0x1,%dil
    762e:	75 8d                	jne    75bd <fwp_free_zombie+0x9d>
    7630:	8b 7e 18             	mov    0x18(%rsi),%edi
    7633:	0f b7 c0             	movzwl %ax,%eax
    7636:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7639:	48 0f af c7          	imul   %rdi,%rax
    763d:	48 c1 e8 20          	shr    $0x20,%rax
    7641:	48 39 f0             	cmp    %rsi,%rax
    7644:	0f 83 73 ff ff ff    	jae    75bd <fwp_free_zombie+0x9d>
    764a:	48 01 c1             	add    %rax,%rcx
    764d:	0f b6 01             	movzbl (%rcx),%eax
    7650:	84 c0                	test   %al,%al
    7652:	0f 84 65 ff ff ff    	je     75bd <fwp_free_zombie+0x9d>
    7658:	3c 01                	cmp    $0x1,%al
    765a:	74 14                	je     7670 <fwp_free_zombie+0x150>
    765c:	3c ff                	cmp    $0xff,%al
    765e:	74 3b                	je     769b <fwp_free_zombie+0x17b>
    7660:	83 e8 01             	sub    $0x1,%eax
    7663:	88 01                	mov    %al,(%rcx)
    7665:	e9 53 ff ff ff       	jmp    75bd <fwp_free_zombie+0x9d>
    766a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7670:	48 89 d7             	mov    %rdx,%rdi
    7673:	48 83 c4 18          	add    $0x18,%rsp
    7677:	e9 c4 fd ff ff       	jmp    7440 <fwp_task_dispose>
    767c:	0f 1f 40 00          	nopl   0x0(%rax)
    7680:	48 89 05 41 41 06 00 	mov    %rax,0x64141(%rip)        # 6b7c8 <fwp_tasks_active>
    7687:	e9 ff fe ff ff       	jmp    758b <fwp_free_zombie+0x6b>
    768c:	0f 1f 40 00          	nopl   0x0(%rax)
    7690:	66 85 c0             	test   %ax,%ax
    7693:	0f 85 24 ff ff ff    	jne    75bd <fwp_free_zombie+0x9d>
    7699:	eb b2                	jmp    764d <fwp_free_zombie+0x12d>
    769b:	48 89 ca             	mov    %rcx,%rdx
    769e:	48 8d 35 7b 41 06 00 	lea    0x6417b(%rip),%rsi        # 6b820 <fwp_heap>
    76a5:	48 c1 ea 11          	shr    $0x11,%rdx
    76a9:	48 31 ca             	xor    %rcx,%rdx
    76ac:	48 89 d0             	mov    %rdx,%rax
    76af:	48 c1 e8 09          	shr    $0x9,%rax
    76b3:	48 31 c2             	xor    %rax,%rdx
    76b6:	0f b6 d2             	movzbl %dl,%edx
    76b9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    76c0:	00 
    76c1:	48 85 c0             	test   %rax,%rax
    76c4:	75 23                	jne    76e9 <fwp_free_zombie+0x1c9>
    76c6:	eb 5c                	jmp    7724 <fwp_free_zombie+0x204>
    76c8:	66 90                	xchg   %ax,%ax
    76ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76d1:	00 00 00 00 
    76d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76dc:	00 00 00 00 
    76e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    76e4:	48 85 c0             	test   %rax,%rax
    76e7:	74 3b                	je     7724 <fwp_free_zombie+0x204>
    76e9:	48 89 c2             	mov    %rax,%rdx
    76ec:	48 39 08             	cmp    %rcx,(%rax)
    76ef:	75 ef                	jne    76e0 <fwp_free_zombie+0x1c0>
    76f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76f5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    76f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    76fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7704:	0f 85 b3 fe ff ff    	jne    75bd <fwp_free_zombie+0x9d>
    770a:	48 89 cf             	mov    %rcx,%rdi
    770d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7712:	e8 b9 e0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7717:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    771c:	c6 01 fe             	movb   $0xfe,(%rcx)
    771f:	e9 99 fe ff ff       	jmp    75bd <fwp_free_zombie+0x9d>
    7724:	48 8d 3d c5 82 00 00 	lea    0x82c5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    772b:	e8 20 cd ff ff       	call   4450 <fwp_trap>

0000000000007730 <fwp_block>:
    7730:	48 83 ec 08          	sub    $0x8,%rsp
    7734:	48 8b 05 ad 40 06 00 	mov    0x640ad(%rip),%rax        # 6b7e8 <fwp_ready_head>
    773b:	48 85 c0             	test   %rax,%rax
    773e:	0f 84 1c 01 00 00    	je     7860 <fwp_block+0x130>
    7744:	90                   	nop
    7745:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    774c:	00 00 00 00 
    7750:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7757:	48 89 15 8a 40 06 00 	mov    %rdx,0x6408a(%rip)        # 6b7e8 <fwp_ready_head>
    775e:	48 85 d2             	test   %rdx,%rdx
    7761:	0f 84 19 01 00 00    	je     7880 <fwp_block+0x150>
    7767:	48 8b 15 92 40 06 00 	mov    0x64092(%rip),%rdx        # 6b800 <fwp_cur>
    776e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7772:	48 39 c2             	cmp    %rax,%rdx
    7775:	0f 84 d5 00 00 00    	je     7850 <fwp_block+0x120>
    777b:	48 8b 0d 06 5d 06 00 	mov    0x65d06(%rip),%rcx        # 6d488 <fwp_state_owners>
    7782:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7786:	48 89 05 73 40 06 00 	mov    %rax,0x64073(%rip)        # 6b800 <fwp_cur>
    778d:	f3 0f 7e 05 1b 5d 06 	movq   0x65d1b(%rip),%xmm0        # 6d4b0 <fwp_foreign_callbacks>
    7794:	00 
    7795:	0f 16 05 04 5d 06 00 	movhps 0x65d04(%rip),%xmm0        # 6d4a0 <fwp_state>
    779c:	f3 0f 7e 0d 04 5d 06 	movq   0x65d04(%rip),%xmm1        # 6d4a8 <fwp_handlers>
    77a3:	00 
    77a4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    77ab:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    77b2:	0f 16 0d ff 5c 06 00 	movhps 0x65cff(%rip),%xmm1        # 6d4b8 <fwp_cleanups>
    77b9:	f3 0f 7e 05 d7 5c 06 	movq   0x65cd7(%rip),%xmm0        # 6d498 <fwp_state_len>
    77c0:	00 
    77c1:	0f 16 05 c8 5c 06 00 	movhps 0x65cc8(%rip),%xmm0        # 6d490 <fwp_state_cap>
    77c8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    77cf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    77d6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77da:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    77e1:	48 89 0d c0 5c 06 00 	mov    %rcx,0x65cc0(%rip)        # 6d4a8 <fwp_handlers>
    77e8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    77ef:	48 89 0d c2 5c 06 00 	mov    %rcx,0x65cc2(%rip)        # 6d4b8 <fwp_cleanups>
    77f6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    77fd:	48 89 0d ac 5c 06 00 	mov    %rcx,0x65cac(%rip)        # 6d4b0 <fwp_foreign_callbacks>
    7804:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    780b:	48 89 0d 8e 5c 06 00 	mov    %rcx,0x65c8e(%rip)        # 6d4a0 <fwp_state>
    7812:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7819:	48 89 0d 78 5c 06 00 	mov    %rcx,0x65c78(%rip)        # 6d498 <fwp_state_len>
    7820:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7827:	48 89 0d 62 5c 06 00 	mov    %rcx,0x65c62(%rip)        # 6d490 <fwp_state_cap>
    782e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7835:	48 89 0d 4c 5c 06 00 	mov    %rcx,0x65c4c(%rip)        # 6d488 <fwp_state_owners>
    783c:	e8 3f bc ff ff       	call   3480 <swapcontext@plt>
    7841:	f3 0f 1e fa          	endbr64
    7845:	e8 d6 fc ff ff       	call   7520 <fwp_free_zombie>
    784a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7850:	8b 05 7a 39 06 00    	mov    0x6397a(%rip),%eax        # 6b1d0 <fwp_slice>
    7856:	85 c0                	test   %eax,%eax
    7858:	74 36                	je     7890 <fwp_block+0x160>
    785a:	48 83 c4 08          	add    $0x8,%rsp
    785e:	c3                   	ret
    785f:	90                   	nop
    7860:	e8 ab db ff ff       	call   5410 <fwp_poll_events>
    7865:	48 8b 05 7c 3f 06 00 	mov    0x63f7c(%rip),%rax        # 6b7e8 <fwp_ready_head>
    786c:	48 85 c0             	test   %rax,%rax
    786f:	0f 85 db fe ff ff    	jne    7750 <fwp_block+0x20>
    7875:	eb e9                	jmp    7860 <fwp_block+0x130>
    7877:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    787e:	00 00 
    7880:	48 c7 05 55 3f 06 00 	movq   $0x0,0x63f55(%rip)        # 6b7e0 <fwp_ready_tail>
    7887:	00 00 00 00 
    788b:	e9 d7 fe ff ff       	jmp    7767 <fwp_block+0x37>
    7890:	48 8d 3d 48 79 00 00 	lea    0x7948(%rip),%rdi        # f1df <_IO_stdin_used+0x1df>
    7897:	e8 f4 ba ff ff       	call   3390 <getenv@plt>
    789c:	ba 10 27 00 00       	mov    $0x2710,%edx
    78a1:	48 85 c0             	test   %rax,%rax
    78a4:	74 05                	je     78ab <fwp_block+0x17b>
    78a6:	80 38 00             	cmpb   $0x0,(%rax)
    78a9:	75 0b                	jne    78b6 <fwp_block+0x186>
    78ab:	89 15 1f 39 06 00    	mov    %edx,0x6391f(%rip)        # 6b1d0 <fwp_slice>
    78b1:	48 83 c4 08          	add    $0x8,%rsp
    78b5:	c3                   	ret
    78b6:	ba 0a 00 00 00       	mov    $0xa,%edx
    78bb:	31 f6                	xor    %esi,%esi
    78bd:	48 89 c7             	mov    %rax,%rdi
    78c0:	e8 7b bc ff ff       	call   3540 <strtoll@plt>
    78c5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    78c9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    78d0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    78d5:	0f 46 d0             	cmovbe %eax,%edx
    78d8:	eb d1                	jmp    78ab <fwp_block+0x17b>
    78da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000078e0 <fwp_caps173>:
    78e0:	f3 0f 1e fa          	endbr64
    78e4:	85 f6                	test   %esi,%esi
    78e6:	74 08                	je     78f0 <fwp_caps173+0x10>
    78e8:	c3                   	ret
    78e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78f0:	48 8b 15 01 53 06 00 	mov    0x65301(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    78f7:	48 89 f8             	mov    %rdi,%rax
    78fa:	48 2b 05 cf 52 06 00 	sub    0x652cf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7901:	48 c1 e2 10          	shl    $0x10,%rdx
    7905:	48 39 d0             	cmp    %rdx,%rax
    7908:	73 de                	jae    78e8 <fwp_caps173+0x8>
    790a:	48 89 c2             	mov    %rax,%rdx
    790d:	48 c1 ea 10          	shr    $0x10,%rdx
    7911:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7915:	48 8b 15 fc 52 06 00 	mov    0x652fc(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    791c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7920:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7924:	48 85 c9             	test   %rcx,%rcx
    7927:	74 bf                	je     78e8 <fwp_caps173+0x8>
    7929:	0f b6 32             	movzbl (%rdx),%esi
    792c:	40 80 fe 02          	cmp    $0x2,%sil
    7930:	74 2e                	je     7960 <fwp_caps173+0x80>
    7932:	40 80 fe 01          	cmp    $0x1,%sil
    7936:	75 b0                	jne    78e8 <fwp_caps173+0x8>
    7938:	8b 72 18             	mov    0x18(%rdx),%esi
    793b:	0f b7 c0             	movzwl %ax,%eax
    793e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7941:	48 0f af c6          	imul   %rsi,%rax
    7945:	48 c1 e8 20          	shr    $0x20,%rax
    7949:	48 39 d0             	cmp    %rdx,%rax
    794c:	73 9a                	jae    78e8 <fwp_caps173+0x8>
    794e:	48 01 c1             	add    %rax,%rcx
    7951:	80 39 01             	cmpb   $0x1,(%rcx)
    7954:	75 92                	jne    78e8 <fwp_caps173+0x8>
    7956:	e9 b5 e0 ff ff       	jmp    5a10 <fwp_mem_free>
    795b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7960:	66 85 c0             	test   %ax,%ax
    7963:	74 ec                	je     7951 <fwp_caps173+0x71>
    7965:	c3                   	ret
    7966:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    796d:	00 00 00 

0000000000007970 <fwp_args37>:
    7970:	f3 0f 1e fa          	endbr64
    7974:	85 d2                	test   %edx,%edx
    7976:	74 04                	je     797c <fwp_args37+0xc>
    7978:	85 f6                	test   %esi,%esi
    797a:	74 04                	je     7980 <fwp_args37+0x10>
    797c:	c3                   	ret
    797d:	0f 1f 00             	nopl   (%rax)
    7980:	48 8b 15 71 52 06 00 	mov    0x65271(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7987:	48 8b 07             	mov    (%rdi),%rax
    798a:	48 2b 05 3f 52 06 00 	sub    0x6523f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7991:	48 c1 e2 10          	shl    $0x10,%rdx
    7995:	48 39 d0             	cmp    %rdx,%rax
    7998:	73 e2                	jae    797c <fwp_args37+0xc>
    799a:	48 89 c2             	mov    %rax,%rdx
    799d:	48 c1 ea 10          	shr    $0x10,%rdx
    79a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    79a5:	48 8b 15 6c 52 06 00 	mov    0x6526c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    79ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    79b0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    79b4:	48 85 ff             	test   %rdi,%rdi
    79b7:	74 c3                	je     797c <fwp_args37+0xc>
    79b9:	0f b6 0a             	movzbl (%rdx),%ecx
    79bc:	80 f9 02             	cmp    $0x2,%cl
    79bf:	74 4f                	je     7a10 <fwp_args37+0xa0>
    79c1:	80 f9 01             	cmp    $0x1,%cl
    79c4:	75 b6                	jne    797c <fwp_args37+0xc>
    79c6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79c9:	0f b7 c0             	movzwl %ax,%eax
    79cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79cf:	48 0f af c1          	imul   %rcx,%rax
    79d3:	48 c1 e8 20          	shr    $0x20,%rax
    79d7:	48 39 d0             	cmp    %rdx,%rax
    79da:	73 a0                	jae    797c <fwp_args37+0xc>
    79dc:	48 01 c7             	add    %rax,%rdi
    79df:	0f b6 07             	movzbl (%rdi),%eax
    79e2:	84 c0                	test   %al,%al
    79e4:	74 96                	je     797c <fwp_args37+0xc>
    79e6:	8b 15 fc 5a 06 00    	mov    0x65afc(%rip),%edx        # 6d4e8 <iteration_active>
    79ec:	85 d2                	test   %edx,%edx
    79ee:	75 10                	jne    7a00 <fwp_args37+0x90>
    79f0:	3c fd                	cmp    $0xfd,%al
    79f2:	77 22                	ja     7a16 <fwp_args37+0xa6>
    79f4:	83 c0 01             	add    $0x1,%eax
    79f7:	88 07                	mov    %al,(%rdi)
    79f9:	c3                   	ret
    79fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a00:	48 83 05 c8 5a 06 00 	addq   $0x1,0x65ac8(%rip)        # 6d4d0 <iteration_retains>
    7a07:	01 
    7a08:	eb e6                	jmp    79f0 <fwp_args37+0x80>
    7a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a10:	66 85 c0             	test   %ax,%ax
    7a13:	74 ca                	je     79df <fwp_args37+0x6f>
    7a15:	c3                   	ret
    7a16:	e9 95 dc ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7a1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007a20 <fwp_caps37>:
    7a20:	f3 0f 1e fa          	endbr64
    7a24:	48 83 ec 18          	sub    $0x18,%rsp
    7a28:	48 89 f8             	mov    %rdi,%rax
    7a2b:	8b 7f 04             	mov    0x4(%rdi),%edi
    7a2e:	85 ff                	test   %edi,%edi
    7a30:	0f 84 9a 00 00 00    	je     7ad0 <fwp_caps37+0xb0>
    7a36:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7a3a:	85 f6                	test   %esi,%esi
    7a3c:	0f 85 9e 00 00 00    	jne    7ae0 <fwp_caps37+0xc0>
    7a42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7a47:	e8 24 f7 ff ff       	call   7170 <fwp_drop4>
    7a4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7a51:	48 8b 0d a0 51 06 00 	mov    0x651a0(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    7a58:	48 89 c2             	mov    %rax,%rdx
    7a5b:	48 2b 15 6e 51 06 00 	sub    0x6516e(%rip),%rdx        # 6cbd0 <fwp_heap+0x13b0>
    7a62:	48 c1 e1 10          	shl    $0x10,%rcx
    7a66:	48 39 ca             	cmp    %rcx,%rdx
    7a69:	73 6d                	jae    7ad8 <fwp_caps37+0xb8>
    7a6b:	48 89 d1             	mov    %rdx,%rcx
    7a6e:	48 c1 e9 10          	shr    $0x10,%rcx
    7a72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a76:	48 8b 0d 9b 51 06 00 	mov    0x6519b(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    7a7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7a81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7a85:	48 85 f6             	test   %rsi,%rsi
    7a88:	74 4e                	je     7ad8 <fwp_caps37+0xb8>
    7a8a:	0f b6 39             	movzbl (%rcx),%edi
    7a8d:	40 80 ff 02          	cmp    $0x2,%dil
    7a91:	0f 84 c9 00 00 00    	je     7b60 <fwp_caps37+0x140>
    7a97:	40 80 ff 01          	cmp    $0x1,%dil
    7a9b:	75 3b                	jne    7ad8 <fwp_caps37+0xb8>
    7a9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7aa0:	0f b7 d2             	movzwl %dx,%edx
    7aa3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7aa6:	48 0f af d7          	imul   %rdi,%rdx
    7aaa:	48 c1 ea 20          	shr    $0x20,%rdx
    7aae:	48 39 ca             	cmp    %rcx,%rdx
    7ab1:	73 25                	jae    7ad8 <fwp_caps37+0xb8>
    7ab3:	48 01 d6             	add    %rdx,%rsi
    7ab6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7ab9:	75 1d                	jne    7ad8 <fwp_caps37+0xb8>
    7abb:	48 89 c7             	mov    %rax,%rdi
    7abe:	48 83 c4 18          	add    $0x18,%rsp
    7ac2:	e9 49 df ff ff       	jmp    5a10 <fwp_mem_free>
    7ac7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ace:	00 00 
    7ad0:	85 f6                	test   %esi,%esi
    7ad2:	0f 84 79 ff ff ff    	je     7a51 <fwp_caps37+0x31>
    7ad8:	48 83 c4 18          	add    $0x18,%rsp
    7adc:	c3                   	ret
    7add:	0f 1f 00             	nopl   (%rax)
    7ae0:	48 8b 05 11 51 06 00 	mov    0x65111(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    7ae7:	48 2b 3d e2 50 06 00 	sub    0x650e2(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    7aee:	48 c1 e0 10          	shl    $0x10,%rax
    7af2:	48 39 c7             	cmp    %rax,%rdi
    7af5:	73 e1                	jae    7ad8 <fwp_caps37+0xb8>
    7af7:	48 89 f8             	mov    %rdi,%rax
    7afa:	48 c1 e8 10          	shr    $0x10,%rax
    7afe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7b02:	48 8b 05 0f 51 06 00 	mov    0x6510f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    7b09:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7b0d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7b11:	48 85 c0             	test   %rax,%rax
    7b14:	74 c2                	je     7ad8 <fwp_caps37+0xb8>
    7b16:	0f b6 0a             	movzbl (%rdx),%ecx
    7b19:	80 f9 02             	cmp    $0x2,%cl
    7b1c:	74 52                	je     7b70 <fwp_caps37+0x150>
    7b1e:	80 f9 01             	cmp    $0x1,%cl
    7b21:	75 b5                	jne    7ad8 <fwp_caps37+0xb8>
    7b23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b26:	0f b7 ff             	movzwl %di,%edi
    7b29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b2c:	48 0f af f9          	imul   %rcx,%rdi
    7b30:	48 c1 ef 20          	shr    $0x20,%rdi
    7b34:	48 39 d7             	cmp    %rdx,%rdi
    7b37:	73 9f                	jae    7ad8 <fwp_caps37+0xb8>
    7b39:	48 01 f8             	add    %rdi,%rax
    7b3c:	0f b6 10             	movzbl (%rax),%edx
    7b3f:	84 d2                	test   %dl,%dl
    7b41:	74 95                	je     7ad8 <fwp_caps37+0xb8>
    7b43:	8b 0d 9f 59 06 00    	mov    0x6599f(%rip),%ecx        # 6d4e8 <iteration_active>
    7b49:	85 c9                	test   %ecx,%ecx
    7b4b:	75 33                	jne    7b80 <fwp_caps37+0x160>
    7b4d:	80 fa fd             	cmp    $0xfd,%dl
    7b50:	77 38                	ja     7b8a <fwp_caps37+0x16a>
    7b52:	83 c2 01             	add    $0x1,%edx
    7b55:	88 10                	mov    %dl,(%rax)
    7b57:	e9 7c ff ff ff       	jmp    7ad8 <fwp_caps37+0xb8>
    7b5c:	0f 1f 40 00          	nopl   0x0(%rax)
    7b60:	66 85 d2             	test   %dx,%dx
    7b63:	0f 85 6f ff ff ff    	jne    7ad8 <fwp_caps37+0xb8>
    7b69:	e9 48 ff ff ff       	jmp    7ab6 <fwp_caps37+0x96>
    7b6e:	66 90                	xchg   %ax,%ax
    7b70:	66 85 ff             	test   %di,%di
    7b73:	0f 85 5f ff ff ff    	jne    7ad8 <fwp_caps37+0xb8>
    7b79:	eb c1                	jmp    7b3c <fwp_caps37+0x11c>
    7b7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b80:	48 83 05 48 59 06 00 	addq   $0x1,0x65948(%rip)        # 6d4d0 <iteration_retains>
    7b87:	01 
    7b88:	eb c3                	jmp    7b4d <fwp_caps37+0x12d>
    7b8a:	48 89 c7             	mov    %rax,%rdi
    7b8d:	48 83 c4 18          	add    $0x18,%rsp
    7b91:	e9 1a db ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b9d:	00 00 00 

0000000000007ba0 <fwp_drop0>:
    7ba0:	f3 0f 1e fa          	endbr64
    7ba4:	48 8b 15 4d 50 06 00 	mov    0x6504d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7bab:	48 89 f8             	mov    %rdi,%rax
    7bae:	48 2b 05 1b 50 06 00 	sub    0x6501b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7bb5:	48 c1 e2 10          	shl    $0x10,%rdx
    7bb9:	48 39 d0             	cmp    %rdx,%rax
    7bbc:	0f 83 36 01 00 00    	jae    7cf8 <fwp_drop0+0x158>
    7bc2:	48 83 ec 18          	sub    $0x18,%rsp
    7bc6:	48 8d 35 53 3c 06 00 	lea    0x63c53(%rip),%rsi        # 6b820 <fwp_heap>
    7bcd:	48 89 c2             	mov    %rax,%rdx
    7bd0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7bd7:	48 c1 ea 10          	shr    $0x10,%rdx
    7bdb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7bdf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7be3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7be7:	48 85 d2             	test   %rdx,%rdx
    7bea:	74 42                	je     7c2e <fwp_drop0+0x8e>
    7bec:	44 0f b6 01          	movzbl (%rcx),%r8d
    7bf0:	41 80 f8 02          	cmp    $0x2,%r8b
    7bf4:	74 42                	je     7c38 <fwp_drop0+0x98>
    7bf6:	41 80 f8 01          	cmp    $0x1,%r8b
    7bfa:	75 32                	jne    7c2e <fwp_drop0+0x8e>
    7bfc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7c00:	0f b7 c0             	movzwl %ax,%eax
    7c03:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c06:	49 0f af c0          	imul   %r8,%rax
    7c0a:	48 c1 e8 20          	shr    $0x20,%rax
    7c0e:	48 39 c8             	cmp    %rcx,%rax
    7c11:	73 1b                	jae    7c2e <fwp_drop0+0x8e>
    7c13:	48 01 c2             	add    %rax,%rdx
    7c16:	0f b6 02             	movzbl (%rdx),%eax
    7c19:	84 c0                	test   %al,%al
    7c1b:	74 11                	je     7c2e <fwp_drop0+0x8e>
    7c1d:	3c 01                	cmp    $0x1,%al
    7c1f:	74 27                	je     7c48 <fwp_drop0+0xa8>
    7c21:	3c ff                	cmp    $0xff,%al
    7c23:	0f 84 e7 00 00 00    	je     7d10 <fwp_drop0+0x170>
    7c29:	83 e8 01             	sub    $0x1,%eax
    7c2c:	88 02                	mov    %al,(%rdx)
    7c2e:	48 83 c4 18          	add    $0x18,%rsp
    7c32:	c3                   	ret
    7c33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c38:	66 85 c0             	test   %ax,%ax
    7c3b:	74 d9                	je     7c16 <fwp_drop0+0x76>
    7c3d:	48 83 c4 18          	add    $0x18,%rsp
    7c41:	c3                   	ret
    7c42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c48:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c4f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7c56:	48 89 f8             	mov    %rdi,%rax
    7c59:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7c5d:	48 29 c8             	sub    %rcx,%rax
    7c60:	48 c1 e2 10          	shl    $0x10,%rdx
    7c64:	48 39 d0             	cmp    %rdx,%rax
    7c67:	73 71                	jae    7cda <fwp_drop0+0x13a>
    7c69:	49 89 c2             	mov    %rax,%r10
    7c6c:	49 c1 ea 10          	shr    $0x10,%r10
    7c70:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7c74:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7c78:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7c7c:	4d 85 d2             	test   %r10,%r10
    7c7f:	74 59                	je     7cda <fwp_drop0+0x13a>
    7c81:	45 0f b6 19          	movzbl (%r9),%r11d
    7c85:	41 80 fb 02          	cmp    $0x2,%r11b
    7c89:	74 75                	je     7d00 <fwp_drop0+0x160>
    7c8b:	41 80 fb 01          	cmp    $0x1,%r11b
    7c8f:	75 49                	jne    7cda <fwp_drop0+0x13a>
    7c91:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7c95:	0f b7 c0             	movzwl %ax,%eax
    7c98:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7c9c:	49 0f af c3          	imul   %r11,%rax
    7ca0:	48 c1 e8 20          	shr    $0x20,%rax
    7ca4:	4c 39 c8             	cmp    %r9,%rax
    7ca7:	73 31                	jae    7cda <fwp_drop0+0x13a>
    7ca9:	49 01 c2             	add    %rax,%r10
    7cac:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7cb0:	75 28                	jne    7cda <fwp_drop0+0x13a>
    7cb2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7cb7:	e8 54 dd ff ff       	call   5a10 <fwp_mem_free>
    7cbc:	48 8d 35 5d 3b 06 00 	lea    0x63b5d(%rip),%rsi        # 6b820 <fwp_heap>
    7cc3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7cc8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7ccf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7cd6:	48 c1 e2 10          	shl    $0x10,%rdx
    7cda:	4c 89 c0             	mov    %r8,%rax
    7cdd:	48 29 c8             	sub    %rcx,%rax
    7ce0:	48 39 d0             	cmp    %rdx,%rax
    7ce3:	0f 83 45 ff ff ff    	jae    7c2e <fwp_drop0+0x8e>
    7ce9:	4c 89 c7             	mov    %r8,%rdi
    7cec:	e9 dc fe ff ff       	jmp    7bcd <fwp_drop0+0x2d>
    7cf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cf8:	c3                   	ret
    7cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d00:	66 85 c0             	test   %ax,%ax
    7d03:	75 d5                	jne    7cda <fwp_drop0+0x13a>
    7d05:	eb a5                	jmp    7cac <fwp_drop0+0x10c>
    7d07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d0e:	00 00 
    7d10:	48 89 d0             	mov    %rdx,%rax
    7d13:	48 c1 e8 11          	shr    $0x11,%rax
    7d17:	48 31 d0             	xor    %rdx,%rax
    7d1a:	48 89 c1             	mov    %rax,%rcx
    7d1d:	48 c1 e9 09          	shr    $0x9,%rcx
    7d21:	48 31 c8             	xor    %rcx,%rax
    7d24:	0f b6 c8             	movzbl %al,%ecx
    7d27:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7d2e:	00 
    7d2f:	48 85 c0             	test   %rax,%rax
    7d32:	75 15                	jne    7d49 <fwp_drop0+0x1a9>
    7d34:	eb 4e                	jmp    7d84 <fwp_drop0+0x1e4>
    7d36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d3d:	00 00 00 
    7d40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7d44:	48 85 c0             	test   %rax,%rax
    7d47:	74 3b                	je     7d84 <fwp_drop0+0x1e4>
    7d49:	48 89 c1             	mov    %rax,%rcx
    7d4c:	48 39 10             	cmp    %rdx,(%rax)
    7d4f:	75 ef                	jne    7d40 <fwp_drop0+0x1a0>
    7d51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7d55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7d59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7d5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7d64:	0f 85 c4 fe ff ff    	jne    7c2e <fwp_drop0+0x8e>
    7d6a:	48 89 d7             	mov    %rdx,%rdi
    7d6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7d72:	e8 59 da ff ff       	call   57d0 <fwp_rc_forget_slot>
    7d77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7d7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7d7f:	e9 aa fe ff ff       	jmp    7c2e <fwp_drop0+0x8e>
    7d84:	48 8d 3d 65 7c 00 00 	lea    0x7c65(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7d8b:	e8 c0 c6 ff ff       	call   4450 <fwp_trap>

0000000000007d90 <fwp_drop1>:
    7d90:	f3 0f 1e fa          	endbr64
    7d94:	48 8b 15 5d 4e 06 00 	mov    0x64e5d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7d9b:	48 89 f8             	mov    %rdi,%rax
    7d9e:	48 2b 05 2b 4e 06 00 	sub    0x64e2b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7da5:	48 c1 e2 10          	shl    $0x10,%rdx
    7da9:	48 39 d0             	cmp    %rdx,%rax
    7dac:	0f 83 36 01 00 00    	jae    7ee8 <fwp_drop1+0x158>
    7db2:	48 83 ec 18          	sub    $0x18,%rsp
    7db6:	48 8d 35 63 3a 06 00 	lea    0x63a63(%rip),%rsi        # 6b820 <fwp_heap>
    7dbd:	48 89 c2             	mov    %rax,%rdx
    7dc0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7dc7:	48 c1 ea 10          	shr    $0x10,%rdx
    7dcb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7dcf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7dd3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7dd7:	48 85 d2             	test   %rdx,%rdx
    7dda:	74 42                	je     7e1e <fwp_drop1+0x8e>
    7ddc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7de0:	41 80 f8 02          	cmp    $0x2,%r8b
    7de4:	74 42                	je     7e28 <fwp_drop1+0x98>
    7de6:	41 80 f8 01          	cmp    $0x1,%r8b
    7dea:	75 32                	jne    7e1e <fwp_drop1+0x8e>
    7dec:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7df0:	0f b7 c0             	movzwl %ax,%eax
    7df3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7df6:	49 0f af c0          	imul   %r8,%rax
    7dfa:	48 c1 e8 20          	shr    $0x20,%rax
    7dfe:	48 39 c8             	cmp    %rcx,%rax
    7e01:	73 1b                	jae    7e1e <fwp_drop1+0x8e>
    7e03:	48 01 c2             	add    %rax,%rdx
    7e06:	0f b6 02             	movzbl (%rdx),%eax
    7e09:	84 c0                	test   %al,%al
    7e0b:	74 11                	je     7e1e <fwp_drop1+0x8e>
    7e0d:	3c 01                	cmp    $0x1,%al
    7e0f:	74 27                	je     7e38 <fwp_drop1+0xa8>
    7e11:	3c ff                	cmp    $0xff,%al
    7e13:	0f 84 e7 00 00 00    	je     7f00 <fwp_drop1+0x170>
    7e19:	83 e8 01             	sub    $0x1,%eax
    7e1c:	88 02                	mov    %al,(%rdx)
    7e1e:	48 83 c4 18          	add    $0x18,%rsp
    7e22:	c3                   	ret
    7e23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7e28:	66 85 c0             	test   %ax,%ax
    7e2b:	74 d9                	je     7e06 <fwp_drop1+0x76>
    7e2d:	48 83 c4 18          	add    $0x18,%rsp
    7e31:	c3                   	ret
    7e32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e38:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e3f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e46:	48 89 f8             	mov    %rdi,%rax
    7e49:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7e4d:	48 29 c8             	sub    %rcx,%rax
    7e50:	48 c1 e2 10          	shl    $0x10,%rdx
    7e54:	48 39 d0             	cmp    %rdx,%rax
    7e57:	73 71                	jae    7eca <fwp_drop1+0x13a>
    7e59:	49 89 c2             	mov    %rax,%r10
    7e5c:	49 c1 ea 10          	shr    $0x10,%r10
    7e60:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7e64:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7e68:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7e6c:	4d 85 d2             	test   %r10,%r10
    7e6f:	74 59                	je     7eca <fwp_drop1+0x13a>
    7e71:	45 0f b6 19          	movzbl (%r9),%r11d
    7e75:	41 80 fb 02          	cmp    $0x2,%r11b
    7e79:	74 75                	je     7ef0 <fwp_drop1+0x160>
    7e7b:	41 80 fb 01          	cmp    $0x1,%r11b
    7e7f:	75 49                	jne    7eca <fwp_drop1+0x13a>
    7e81:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7e85:	0f b7 c0             	movzwl %ax,%eax
    7e88:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7e8c:	49 0f af c3          	imul   %r11,%rax
    7e90:	48 c1 e8 20          	shr    $0x20,%rax
    7e94:	4c 39 c8             	cmp    %r9,%rax
    7e97:	73 31                	jae    7eca <fwp_drop1+0x13a>
    7e99:	49 01 c2             	add    %rax,%r10
    7e9c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7ea0:	75 28                	jne    7eca <fwp_drop1+0x13a>
    7ea2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7ea7:	e8 64 db ff ff       	call   5a10 <fwp_mem_free>
    7eac:	48 8d 35 6d 39 06 00 	lea    0x6396d(%rip),%rsi        # 6b820 <fwp_heap>
    7eb3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7eb8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7ebf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7ec6:	48 c1 e2 10          	shl    $0x10,%rdx
    7eca:	4c 89 c0             	mov    %r8,%rax
    7ecd:	48 29 c8             	sub    %rcx,%rax
    7ed0:	48 39 d0             	cmp    %rdx,%rax
    7ed3:	0f 83 45 ff ff ff    	jae    7e1e <fwp_drop1+0x8e>
    7ed9:	4c 89 c7             	mov    %r8,%rdi
    7edc:	e9 dc fe ff ff       	jmp    7dbd <fwp_drop1+0x2d>
    7ee1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ee8:	c3                   	ret
    7ee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ef0:	66 85 c0             	test   %ax,%ax
    7ef3:	75 d5                	jne    7eca <fwp_drop1+0x13a>
    7ef5:	eb a5                	jmp    7e9c <fwp_drop1+0x10c>
    7ef7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7efe:	00 00 
    7f00:	48 89 d0             	mov    %rdx,%rax
    7f03:	48 c1 e8 11          	shr    $0x11,%rax
    7f07:	48 31 d0             	xor    %rdx,%rax
    7f0a:	48 89 c1             	mov    %rax,%rcx
    7f0d:	48 c1 e9 09          	shr    $0x9,%rcx
    7f11:	48 31 c8             	xor    %rcx,%rax
    7f14:	0f b6 c8             	movzbl %al,%ecx
    7f17:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7f1e:	00 
    7f1f:	48 85 c0             	test   %rax,%rax
    7f22:	75 25                	jne    7f49 <fwp_drop1+0x1b9>
    7f24:	eb 5e                	jmp    7f84 <fwp_drop1+0x1f4>
    7f26:	0f 1f 40 00          	nopl   0x0(%rax)
    7f2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f31:	00 00 00 00 
    7f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f3c:	00 00 00 00 
    7f40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7f44:	48 85 c0             	test   %rax,%rax
    7f47:	74 3b                	je     7f84 <fwp_drop1+0x1f4>
    7f49:	48 89 c1             	mov    %rax,%rcx
    7f4c:	48 39 10             	cmp    %rdx,(%rax)
    7f4f:	75 ef                	jne    7f40 <fwp_drop1+0x1b0>
    7f51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7f55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7f59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7f5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7f64:	0f 85 b4 fe ff ff    	jne    7e1e <fwp_drop1+0x8e>
    7f6a:	48 89 d7             	mov    %rdx,%rdi
    7f6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7f72:	e8 59 d8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7f77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7f7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7f7f:	e9 9a fe ff ff       	jmp    7e1e <fwp_drop1+0x8e>
    7f84:	48 8d 3d 65 7a 00 00 	lea    0x7a65(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7f8b:	e8 c0 c4 ff ff       	call   4450 <fwp_trap>

0000000000007f90 <fwp_drop10>:
    7f90:	48 8b 0d 61 4c 06 00 	mov    0x64c61(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    7f97:	48 89 f8             	mov    %rdi,%rax
    7f9a:	48 2b 05 2f 4c 06 00 	sub    0x64c2f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7fa1:	48 c1 e1 10          	shl    $0x10,%rcx
    7fa5:	48 39 c8             	cmp    %rcx,%rax
    7fa8:	0f 83 c2 01 00 00    	jae    8170 <fwp_drop10+0x1e0>
    7fae:	48 83 ec 18          	sub    $0x18,%rsp
    7fb2:	48 89 fa             	mov    %rdi,%rdx
    7fb5:	48 8d 35 64 38 06 00 	lea    0x63864(%rip),%rsi        # 6b820 <fwp_heap>
    7fbc:	48 89 c1             	mov    %rax,%rcx
    7fbf:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7fc6:	48 c1 e9 10          	shr    $0x10,%rcx
    7fca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7fce:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7fd2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7fd6:	48 85 c9             	test   %rcx,%rcx
    7fd9:	74 46                	je     8021 <fwp_drop10+0x91>
    7fdb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7fdf:	41 80 f9 02          	cmp    $0x2,%r9b
    7fe3:	0f 84 d7 00 00 00    	je     80c0 <fwp_drop10+0x130>
    7fe9:	41 80 f9 01          	cmp    $0x1,%r9b
    7fed:	75 32                	jne    8021 <fwp_drop10+0x91>
    7fef:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7ff3:	0f b7 c0             	movzwl %ax,%eax
    7ff6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7ff9:	49 0f af c1          	imul   %r9,%rax
    7ffd:	48 c1 e8 20          	shr    $0x20,%rax
    8001:	48 39 f8             	cmp    %rdi,%rax
    8004:	73 1b                	jae    8021 <fwp_drop10+0x91>
    8006:	48 01 c1             	add    %rax,%rcx
    8009:	0f b6 01             	movzbl (%rcx),%eax
    800c:	84 c0                	test   %al,%al
    800e:	74 11                	je     8021 <fwp_drop10+0x91>
    8010:	3c 01                	cmp    $0x1,%al
    8012:	74 1c                	je     8030 <fwp_drop10+0xa0>
    8014:	3c ff                	cmp    $0xff,%al
    8016:	0f 84 5c 01 00 00    	je     8178 <fwp_drop10+0x1e8>
    801c:	83 e8 01             	sub    $0x1,%eax
    801f:	88 01                	mov    %al,(%rcx)
    8021:	48 83 c4 18          	add    $0x18,%rsp
    8025:	c3                   	ret
    8026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    802d:	00 00 00 
    8030:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8037:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    803e:	48 89 d0             	mov    %rdx,%rax
    8041:	49 89 d1             	mov    %rdx,%r9
    8044:	48 c1 e1 10          	shl    $0x10,%rcx
    8048:	48 29 f8             	sub    %rdi,%rax
    804b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    804f:	78 7f                	js     80d0 <fwp_drop10+0x140>
    8051:	48 39 c8             	cmp    %rcx,%rax
    8054:	73 cb                	jae    8021 <fwp_drop10+0x91>
    8056:	48 89 c1             	mov    %rax,%rcx
    8059:	48 c1 e9 10          	shr    $0x10,%rcx
    805d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8061:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8065:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8069:	48 85 f6             	test   %rsi,%rsi
    806c:	74 b3                	je     8021 <fwp_drop10+0x91>
    806e:	0f b6 39             	movzbl (%rcx),%edi
    8071:	40 80 ff 02          	cmp    $0x2,%dil
    8075:	74 39                	je     80b0 <fwp_drop10+0x120>
    8077:	40 80 ff 01          	cmp    $0x1,%dil
    807b:	75 a4                	jne    8021 <fwp_drop10+0x91>
    807d:	8b 79 18             	mov    0x18(%rcx),%edi
    8080:	0f b7 c0             	movzwl %ax,%eax
    8083:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8086:	48 0f af c7          	imul   %rdi,%rax
    808a:	48 c1 e8 20          	shr    $0x20,%rax
    808e:	48 39 c8             	cmp    %rcx,%rax
    8091:	73 8e                	jae    8021 <fwp_drop10+0x91>
    8093:	48 01 c6             	add    %rax,%rsi
    8096:	80 3e 01             	cmpb   $0x1,(%rsi)
    8099:	75 86                	jne    8021 <fwp_drop10+0x91>
    809b:	48 89 d7             	mov    %rdx,%rdi
    809e:	48 83 c4 18          	add    $0x18,%rsp
    80a2:	e9 69 d9 ff ff       	jmp    5a10 <fwp_mem_free>
    80a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    80ae:	00 00 
    80b0:	66 85 c0             	test   %ax,%ax
    80b3:	74 e1                	je     8096 <fwp_drop10+0x106>
    80b5:	48 83 c4 18          	add    $0x18,%rsp
    80b9:	c3                   	ret
    80ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80c0:	66 85 c0             	test   %ax,%ax
    80c3:	0f 84 40 ff ff ff    	je     8009 <fwp_drop10+0x79>
    80c9:	48 83 c4 18          	add    $0x18,%rsp
    80cd:	c3                   	ret
    80ce:	66 90                	xchg   %ax,%ax
    80d0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    80d4:	48 39 c8             	cmp    %rcx,%rax
    80d7:	73 74                	jae    814d <fwp_drop10+0x1bd>
    80d9:	49 89 c2             	mov    %rax,%r10
    80dc:	49 c1 ea 10          	shr    $0x10,%r10
    80e0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    80e4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    80e8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    80ec:	4d 85 d2             	test   %r10,%r10
    80ef:	74 5c                	je     814d <fwp_drop10+0x1bd>
    80f1:	45 0f b6 18          	movzbl (%r8),%r11d
    80f5:	41 80 fb 02          	cmp    $0x2,%r11b
    80f9:	74 6d                	je     8168 <fwp_drop10+0x1d8>
    80fb:	41 80 fb 01          	cmp    $0x1,%r11b
    80ff:	75 4c                	jne    814d <fwp_drop10+0x1bd>
    8101:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8105:	0f b7 c0             	movzwl %ax,%eax
    8108:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    810c:	49 0f af c3          	imul   %r11,%rax
    8110:	48 c1 e8 20          	shr    $0x20,%rax
    8114:	4c 39 c0             	cmp    %r8,%rax
    8117:	73 34                	jae    814d <fwp_drop10+0x1bd>
    8119:	49 01 c2             	add    %rax,%r10
    811c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8120:	75 2b                	jne    814d <fwp_drop10+0x1bd>
    8122:	4c 89 cf             	mov    %r9,%rdi
    8125:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    812a:	e8 e1 d8 ff ff       	call   5a10 <fwp_mem_free>
    812f:	48 8d 35 ea 36 06 00 	lea    0x636ea(%rip),%rsi        # 6b820 <fwp_heap>
    8136:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    813b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8142:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8149:	48 c1 e1 10          	shl    $0x10,%rcx
    814d:	48 89 d0             	mov    %rdx,%rax
    8150:	48 29 f8             	sub    %rdi,%rax
    8153:	48 39 c8             	cmp    %rcx,%rax
    8156:	0f 82 60 fe ff ff    	jb     7fbc <fwp_drop10+0x2c>
    815c:	e9 c0 fe ff ff       	jmp    8021 <fwp_drop10+0x91>
    8161:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8168:	66 85 c0             	test   %ax,%ax
    816b:	75 e0                	jne    814d <fwp_drop10+0x1bd>
    816d:	eb ad                	jmp    811c <fwp_drop10+0x18c>
    816f:	90                   	nop
    8170:	c3                   	ret
    8171:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8178:	48 89 c8             	mov    %rcx,%rax
    817b:	48 c1 e8 11          	shr    $0x11,%rax
    817f:	48 31 c8             	xor    %rcx,%rax
    8182:	48 89 c2             	mov    %rax,%rdx
    8185:	48 c1 ea 09          	shr    $0x9,%rdx
    8189:	48 31 d0             	xor    %rdx,%rax
    818c:	0f b6 d0             	movzbl %al,%edx
    818f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8196:	00 
    8197:	48 85 c0             	test   %rax,%rax
    819a:	75 0d                	jne    81a9 <fwp_drop10+0x219>
    819c:	eb 46                	jmp    81e4 <fwp_drop10+0x254>
    819e:	66 90                	xchg   %ax,%ax
    81a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    81a4:	48 85 c0             	test   %rax,%rax
    81a7:	74 3b                	je     81e4 <fwp_drop10+0x254>
    81a9:	48 89 c2             	mov    %rax,%rdx
    81ac:	48 39 08             	cmp    %rcx,(%rax)
    81af:	75 ef                	jne    81a0 <fwp_drop10+0x210>
    81b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    81b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    81b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    81bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    81c4:	0f 85 57 fe ff ff    	jne    8021 <fwp_drop10+0x91>
    81ca:	48 89 cf             	mov    %rcx,%rdi
    81cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    81d2:	e8 f9 d5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    81d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    81dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    81df:	e9 3d fe ff ff       	jmp    8021 <fwp_drop10+0x91>
    81e4:	48 8d 3d 05 78 00 00 	lea    0x7805(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    81eb:	e8 60 c2 ff ff       	call   4450 <fwp_trap>

00000000000081f0 <f37>:
    81f0:	41 57                	push   %r15
    81f2:	41 56                	push   %r14
    81f4:	41 55                	push   %r13
    81f6:	41 54                	push   %r12
    81f8:	55                   	push   %rbp
    81f9:	53                   	push   %rbx
    81fa:	48 83 ec 38          	sub    $0x38,%rsp
    81fe:	48 8b 15 f3 49 06 00 	mov    0x649f3(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    8205:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    820a:	48 c1 e2 10          	shl    $0x10,%rdx
    820e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8215:	00 00 
    8217:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    821c:	48 8b 0d ad 49 06 00 	mov    0x649ad(%rip),%rcx        # 6cbd0 <fwp_heap+0x13b0>
    8223:	48 85 ff             	test   %rdi,%rdi
    8226:	0f 84 1e 03 00 00    	je     854a <f37+0x35a>
    822c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8231:	4c 8b 68 10          	mov    0x10(%rax),%r13
    8235:	4c 89 e8             	mov    %r13,%rax
    8238:	48 29 c8             	sub    %rcx,%rax
    823b:	48 39 d0             	cmp    %rdx,%rax
    823e:	0f 83 ec 02 00 00    	jae    8530 <f37+0x340>
    8244:	48 89 c2             	mov    %rax,%rdx
    8247:	48 c1 ea 10          	shr    $0x10,%rdx
    824b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    824f:	48 8b 15 c2 49 06 00 	mov    0x649c2(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    8256:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    825a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    825e:	48 85 ff             	test   %rdi,%rdi
    8261:	0f 84 c9 02 00 00    	je     8530 <f37+0x340>
    8267:	0f b6 0a             	movzbl (%rdx),%ecx
    826a:	80 f9 02             	cmp    $0x2,%cl
    826d:	0f 84 4d 02 00 00    	je     84c0 <f37+0x2d0>
    8273:	80 f9 01             	cmp    $0x1,%cl
    8276:	75 24                	jne    829c <f37+0xac>
    8278:	8b 4a 18             	mov    0x18(%rdx),%ecx
    827b:	0f b7 c0             	movzwl %ax,%eax
    827e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8281:	48 0f af c1          	imul   %rcx,%rax
    8285:	48 c1 e8 20          	shr    $0x20,%rax
    8289:	48 39 d0             	cmp    %rdx,%rax
    828c:	73 0e                	jae    829c <f37+0xac>
    828e:	48 01 c7             	add    %rax,%rdi
    8291:	0f b6 07             	movzbl (%rdi),%eax
    8294:	84 c0                	test   %al,%al
    8296:	0f 85 44 02 00 00    	jne    84e0 <f37+0x2f0>
    829c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    82a1:	48 8b 40 10          	mov    0x10(%rax),%rax
    82a5:	ba 01 00 00 00       	mov    $0x1,%edx
    82aa:	48 85 c0             	test   %rax,%rax
    82ad:	74 0e                	je     82bd <f37+0xcd>
    82af:	90                   	nop
    82b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    82b4:	48 83 c2 01          	add    $0x1,%rdx
    82b8:	48 85 c0             	test   %rax,%rax
    82bb:	75 f3                	jne    82b0 <f37+0xc0>
    82bd:	4d 85 ed             	test   %r13,%r13
    82c0:	0f 84 9a 02 00 00    	je     8560 <f37+0x370>
    82c6:	4c 89 e8             	mov    %r13,%rax
    82c9:	31 db                	xor    %ebx,%ebx
    82cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    82d0:	48 8b 40 10          	mov    0x10(%rax),%rax
    82d4:	48 83 c3 01          	add    $0x1,%rbx
    82d8:	48 85 c0             	test   %rax,%rax
    82db:	75 f3                	jne    82d0 <f37+0xe0>
    82dd:	48 39 d3             	cmp    %rdx,%rbx
    82e0:	48 0f 47 da          	cmova  %rdx,%rbx
    82e4:	48 89 d8             	mov    %rbx,%rax
    82e7:	48 c1 e8 3c          	shr    $0x3c,%rax
    82eb:	0f 85 7d 03 00 00    	jne    866e <f37+0x47e>
    82f1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    82f5:	be 02 00 00 00       	mov    $0x2,%esi
    82fa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8301:	00 
    8302:	e8 09 dc ff ff       	call   5f10 <fwp_heap_alloc>
    8307:	48 89 28             	mov    %rbp,(%rax)
    830a:	48 8b 15 e7 48 06 00 	mov    0x648e7(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    8311:	49 89 c4             	mov    %rax,%r12
    8314:	48 2b 05 b5 48 06 00 	sub    0x648b5(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    831b:	48 c1 e2 10          	shl    $0x10,%rdx
    831f:	48 39 d0             	cmp    %rdx,%rax
    8322:	73 57                	jae    837b <f37+0x18b>
    8324:	48 89 c2             	mov    %rax,%rdx
    8327:	48 c1 ea 10          	shr    $0x10,%rdx
    832b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    832f:	48 8b 15 e2 48 06 00 	mov    0x648e2(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    8336:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    833a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    833e:	48 85 ed             	test   %rbp,%rbp
    8341:	74 38                	je     837b <f37+0x18b>
    8343:	0f b6 0a             	movzbl (%rdx),%ecx
    8346:	80 f9 02             	cmp    $0x2,%cl
    8349:	0f 84 d1 01 00 00    	je     8520 <f37+0x330>
    834f:	80 f9 01             	cmp    $0x1,%cl
    8352:	75 27                	jne    837b <f37+0x18b>
    8354:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8357:	0f b7 c0             	movzwl %ax,%eax
    835a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    835d:	48 0f af c1          	imul   %rcx,%rax
    8361:	48 c1 e8 20          	shr    $0x20,%rax
    8365:	48 39 d0             	cmp    %rdx,%rax
    8368:	73 11                	jae    837b <f37+0x18b>
    836a:	48 01 c5             	add    %rax,%rbp
    836d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8371:	0f 84 57 02 00 00    	je     85ce <f37+0x3de>
    8377:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    837b:	48 85 db             	test   %rbx,%rbx
    837e:	74 5d                	je     83dd <f37+0x1ed>
    8380:	48 c1 e3 04          	shl    $0x4,%rbx
    8384:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8389:	4c 89 e5             	mov    %r12,%rbp
    838c:	4d 89 ef             	mov    %r13,%r15
    838f:	4c 01 e3             	add    %r12,%rbx
    8392:	0f 1f 00             	nopl   (%rax)
    8395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    839c:	00 00 00 00 
    83a0:	49 8b 46 08          	mov    0x8(%r14),%rax
    83a4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    83a8:	48 83 c5 10          	add    $0x10,%rbp
    83ac:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    83b1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    83b5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    83b9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    83be:	e8 ad e2 ff ff       	call   6670 <w120>
    83c3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    83c8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    83cc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    83d0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    83d4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    83d8:	48 39 dd             	cmp    %rbx,%rbp
    83db:	75 c3                	jne    83a0 <f37+0x1b0>
    83dd:	4c 89 ef             	mov    %r13,%rdi
    83e0:	e8 8b ed ff ff       	call   7170 <fwp_drop4>
    83e5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    83ea:	e8 81 ed ff ff       	call   7170 <fwp_drop4>
    83ef:	4c 89 e7             	mov    %r12,%rdi
    83f2:	e8 e9 e3 ff ff       	call   67e0 <w176.constprop.0>
    83f7:	4c 89 e7             	mov    %r12,%rdi
    83fa:	48 89 c3             	mov    %rax,%rbx
    83fd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8403:	e8 88 fb ff ff       	call   7f90 <fwp_drop10>
    8408:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    840e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8413:	31 ff                	xor    %edi,%edi
    8415:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    841a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    841e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8423:	e8 d8 dc ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    8428:	48 8b 15 c9 47 06 00 	mov    0x647c9(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    842f:	48 89 c5             	mov    %rax,%rbp
    8432:	48 2b 05 97 47 06 00 	sub    0x64797(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8439:	48 c1 e2 10          	shl    $0x10,%rdx
    843d:	48 39 d0             	cmp    %rdx,%rax
    8440:	73 55                	jae    8497 <f37+0x2a7>
    8442:	48 89 c2             	mov    %rax,%rdx
    8445:	48 c1 ea 10          	shr    $0x10,%rdx
    8449:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    844d:	48 8b 15 c4 47 06 00 	mov    0x647c4(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    8454:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8458:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    845c:	48 85 db             	test   %rbx,%rbx
    845f:	74 36                	je     8497 <f37+0x2a7>
    8461:	0f b6 0a             	movzbl (%rdx),%ecx
    8464:	80 f9 02             	cmp    $0x2,%cl
    8467:	0f 84 a3 00 00 00    	je     8510 <f37+0x320>
    846d:	80 f9 01             	cmp    $0x1,%cl
    8470:	75 25                	jne    8497 <f37+0x2a7>
    8472:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8475:	0f b7 c0             	movzwl %ax,%eax
    8478:	8b 52 1c             	mov    0x1c(%rdx),%edx
    847b:	48 0f af c1          	imul   %rcx,%rax
    847f:	48 c1 e8 20          	shr    $0x20,%rax
    8483:	48 39 d0             	cmp    %rdx,%rax
    8486:	73 0f                	jae    8497 <f37+0x2a7>
    8488:	48 01 c3             	add    %rax,%rbx
    848b:	80 3b ff             	cmpb   $0xff,(%rbx)
    848e:	0f 84 2d 01 00 00    	je     85c1 <f37+0x3d1>
    8494:	c6 03 01             	movb   $0x1,(%rbx)
    8497:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    849c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    84a3:	00 00 
    84a5:	0f 85 cf 01 00 00    	jne    867a <f37+0x48a>
    84ab:	48 83 c4 38          	add    $0x38,%rsp
    84af:	48 89 e8             	mov    %rbp,%rax
    84b2:	5b                   	pop    %rbx
    84b3:	5d                   	pop    %rbp
    84b4:	41 5c                	pop    %r12
    84b6:	41 5d                	pop    %r13
    84b8:	41 5e                	pop    %r14
    84ba:	41 5f                	pop    %r15
    84bc:	c3                   	ret
    84bd:	0f 1f 00             	nopl   (%rax)
    84c0:	66 85 c0             	test   %ax,%ax
    84c3:	0f 85 d3 fd ff ff    	jne    829c <f37+0xac>
    84c9:	0f b6 07             	movzbl (%rdi),%eax
    84cc:	84 c0                	test   %al,%al
    84ce:	0f 84 c8 fd ff ff    	je     829c <f37+0xac>
    84d4:	90                   	nop
    84d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    84dc:	00 00 00 00 
    84e0:	8b 15 02 50 06 00    	mov    0x65002(%rip),%edx        # 6d4e8 <iteration_active>
    84e6:	85 d2                	test   %edx,%edx
    84e8:	75 56                	jne    8540 <f37+0x350>
    84ea:	3c fd                	cmp    $0xfd,%al
    84ec:	0f 87 4b 01 00 00    	ja     863d <f37+0x44d>
    84f2:	83 c0 01             	add    $0x1,%eax
    84f5:	88 07                	mov    %al,(%rdi)
    84f7:	31 d2                	xor    %edx,%edx
    84f9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    84ff:	0f 85 97 fd ff ff    	jne    829c <f37+0xac>
    8505:	e9 b3 fd ff ff       	jmp    82bd <f37+0xcd>
    850a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8510:	66 85 c0             	test   %ax,%ax
    8513:	0f 85 7e ff ff ff    	jne    8497 <f37+0x2a7>
    8519:	e9 6d ff ff ff       	jmp    848b <f37+0x29b>
    851e:	66 90                	xchg   %ax,%ax
    8520:	66 85 c0             	test   %ax,%ax
    8523:	0f 85 52 fe ff ff    	jne    837b <f37+0x18b>
    8529:	e9 3f fe ff ff       	jmp    836d <f37+0x17d>
    852e:	66 90                	xchg   %ax,%ax
    8530:	4c 89 e8             	mov    %r13,%rax
    8533:	e9 6d fd ff ff       	jmp    82a5 <f37+0xb5>
    8538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    853f:	00 
    8540:	48 83 05 88 4f 06 00 	addq   $0x1,0x64f88(%rip)        # 6d4d0 <iteration_retains>
    8547:	01 
    8548:	eb a0                	jmp    84ea <f37+0x2fa>
    854a:	48 f7 d9             	neg    %rcx
    854d:	48 39 d1             	cmp    %rdx,%rcx
    8550:	0f 82 85 00 00 00    	jb     85db <f37+0x3eb>
    8556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    855d:	00 00 00 
    8560:	be 02 00 00 00       	mov    $0x2,%esi
    8565:	bf 08 00 00 00       	mov    $0x8,%edi
    856a:	e8 a1 d9 ff ff       	call   5f10 <fwp_heap_alloc>
    856f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8576:	48 8b 15 7b 46 06 00 	mov    0x6467b(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    857d:	49 89 c4             	mov    %rax,%r12
    8580:	48 2b 05 49 46 06 00 	sub    0x64649(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8587:	48 c1 e2 10          	shl    $0x10,%rdx
    858b:	48 39 d0             	cmp    %rdx,%rax
    858e:	0f 83 b3 00 00 00    	jae    8647 <f37+0x457>
    8594:	48 89 c2             	mov    %rax,%rdx
    8597:	48 c1 ea 10          	shr    $0x10,%rdx
    859b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    859f:	48 8b 15 72 46 06 00 	mov    0x64672(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    85a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85aa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    85ae:	48 85 ed             	test   %rbp,%rbp
    85b1:	0f 84 90 00 00 00    	je     8647 <f37+0x457>
    85b7:	31 db                	xor    %ebx,%ebx
    85b9:	45 31 ed             	xor    %r13d,%r13d
    85bc:	e9 82 fd ff ff       	jmp    8343 <f37+0x153>
    85c1:	48 89 df             	mov    %rbx,%rdi
    85c4:	e8 07 d2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    85c9:	e9 c6 fe ff ff       	jmp    8494 <f37+0x2a4>
    85ce:	48 89 ef             	mov    %rbp,%rdi
    85d1:	e8 fa d1 ff ff       	call   57d0 <fwp_rc_forget_slot>
    85d6:	e9 9c fd ff ff       	jmp    8377 <f37+0x187>
    85db:	48 89 c8             	mov    %rcx,%rax
    85de:	48 c1 e8 10          	shr    $0x10,%rax
    85e2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    85e6:	48 8b 05 2b 46 06 00 	mov    0x6462b(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    85ed:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    85f1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    85f5:	48 85 ff             	test   %rdi,%rdi
    85f8:	0f 84 62 ff ff ff    	je     8560 <f37+0x370>
    85fe:	0f b6 02             	movzbl (%rdx),%eax
    8601:	3c 02                	cmp    $0x2,%al
    8603:	74 4a                	je     864f <f37+0x45f>
    8605:	3c 01                	cmp    $0x1,%al
    8607:	0f 85 53 ff ff ff    	jne    8560 <f37+0x370>
    860d:	0f b7 c1             	movzwl %cx,%eax
    8610:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8613:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8616:	48 0f af c1          	imul   %rcx,%rax
    861a:	48 c1 e8 20          	shr    $0x20,%rax
    861e:	48 39 d0             	cmp    %rdx,%rax
    8621:	0f 83 39 ff ff ff    	jae    8560 <f37+0x370>
    8627:	48 01 c7             	add    %rax,%rdi
    862a:	0f b6 07             	movzbl (%rdi),%eax
    862d:	84 c0                	test   %al,%al
    862f:	0f 84 2b ff ff ff    	je     8560 <f37+0x370>
    8635:	45 31 ed             	xor    %r13d,%r13d
    8638:	e9 a3 fe ff ff       	jmp    84e0 <f37+0x2f0>
    863d:	e8 6e d0 ff ff       	call   56b0 <fwp_rc_wide_dup>
    8642:	e9 b0 fe ff ff       	jmp    84f7 <f37+0x307>
    8647:	45 31 ed             	xor    %r13d,%r13d
    864a:	e9 8e fd ff ff       	jmp    83dd <f37+0x1ed>
    864f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8655:	49 89 cd             	mov    %rcx,%r13
    8658:	0f 85 02 ff ff ff    	jne    8560 <f37+0x370>
    865e:	0f b6 07             	movzbl (%rdi),%eax
    8661:	84 c0                	test   %al,%al
    8663:	0f 85 77 fe ff ff    	jne    84e0 <f37+0x2f0>
    8669:	e9 f2 fe ff ff       	jmp    8560 <f37+0x370>
    866e:	48 8d 3d 76 6b 00 00 	lea    0x6b76(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    8675:	e8 d6 bd ff ff       	call   4450 <fwp_trap>
    867a:	e8 d1 ad ff ff       	call   3450 <__stack_chk_fail@plt>
    867f:	90                   	nop

0000000000008680 <fwp_owned_entry37>:
    8680:	f3 0f 1e fa          	endbr64
    8684:	48 8b 3f             	mov    (%rdi),%rdi
    8687:	e9 64 fb ff ff       	jmp    81f0 <f37>
    868c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008690 <e37>:
    8690:	f3 0f 1e fa          	endbr64
    8694:	53                   	push   %rbx
    8695:	48 8b 1f             	mov    (%rdi),%rbx
    8698:	48 89 df             	mov    %rbx,%rdi
    869b:	e8 c0 e1 ff ff       	call   6860 <fwp_rc_share>
    86a0:	48 89 df             	mov    %rbx,%rdi
    86a3:	e8 48 fb ff ff       	call   81f0 <f37>
    86a8:	48 89 c3             	mov    %rax,%rbx
    86ab:	48 89 c7             	mov    %rax,%rdi
    86ae:	e8 ad e1 ff ff       	call   6860 <fwp_rc_share>
    86b3:	48 89 d8             	mov    %rbx,%rax
    86b6:	5b                   	pop    %rbx
    86b7:	c3                   	ret
    86b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    86bf:	00 

00000000000086c0 <fwp_write>:
    86c0:	41 57                	push   %r15
    86c2:	41 56                	push   %r14
    86c4:	41 55                	push   %r13
    86c6:	41 54                	push   %r12
    86c8:	55                   	push   %rbp
    86c9:	53                   	push   %rbx
    86ca:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    86d1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    86d8:	00 00 
    86da:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    86e1:	00 
    86e2:	49 89 d4             	mov    %rdx,%r12
    86e5:	8b 12                	mov    (%rdx),%edx
    86e7:	83 fa 19             	cmp    $0x19,%edx
    86ea:	77 6a                	ja     8756 <fwp_write+0x96>
    86ec:	48 89 f5             	mov    %rsi,%rbp
    86ef:	89 d0                	mov    %edx,%eax
    86f1:	89 ce                	mov    %ecx,%esi
    86f3:	48 89 fb             	mov    %rdi,%rbx
    86f6:	48 8d 0d d3 75 00 00 	lea    0x75d3(%rip),%rcx        # fcd0 <_IO_stdin_used+0xcd0>
    86fd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8701:	48 01 c8             	add    %rcx,%rax
    8704:	3e ff e0             	notrack jmp *%rax
    8707:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    870e:	00 00 
    8710:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8714:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8718:	48 89 ca             	mov    %rcx,%rdx
    871b:	48 85 c9             	test   %rcx,%rcx
    871e:	0f 88 9c 0c 00 00    	js     93c0 <fwp_write+0xd00>
    8724:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    872b:	00 
    872c:	48 89 c6             	mov    %rax,%rsi
    872f:	4c 89 e7             	mov    %r12,%rdi
    8732:	e8 09 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    8737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    873e:	00 00 
    8740:	4c 89 e7             	mov    %r12,%rdi
    8743:	e8 f8 ac ff ff       	call   3440 <strlen@plt>
    8748:	4c 89 e6             	mov    %r12,%rsi
    874b:	48 89 df             	mov    %rbx,%rdi
    874e:	48 89 c2             	mov    %rax,%rdx
    8751:	e8 9a b9 ff ff       	call   40f0 <buf_put>
    8756:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    875d:	00 
    875e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8765:	00 00 
    8767:	0f 85 28 04 00 00    	jne    8b95 <fwp_write+0x4d5>
    876d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8774:	5b                   	pop    %rbx
    8775:	5d                   	pop    %rbp
    8776:	41 5c                	pop    %r12
    8778:	41 5d                	pop    %r13
    877a:	41 5e                	pop    %r14
    877c:	41 5f                	pop    %r15
    877e:	c3                   	ret
    877f:	90                   	nop
    8780:	49 89 e9             	mov    %rbp,%r9
    8783:	4c 8d 05 8b 6a 00 00 	lea    0x6a8b(%rip),%r8        # f215 <_IO_stdin_used+0x215>
    878a:	b9 00 02 00 00       	mov    $0x200,%ecx
    878f:	ba 02 00 00 00       	mov    $0x2,%edx
    8794:	be 00 02 00 00       	mov    $0x200,%esi
    8799:	31 c0                	xor    %eax,%eax
    879b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    87a2:	00 
    87a3:	e8 f8 ab ff ff       	call   33a0 <__snprintf_chk@plt>
    87a8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    87af:	00 
    87b0:	e8 8b ac ff ff       	call   3440 <strlen@plt>
    87b5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    87bc:	00 
    87bd:	48 89 df             	mov    %rbx,%rdi
    87c0:	48 89 c2             	mov    %rax,%rdx
    87c3:	e8 28 b9 ff ff       	call   40f0 <buf_put>
    87c8:	eb 8c                	jmp    8756 <fwp_write+0x96>
    87ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87d0:	49 89 e9             	mov    %rbp,%r9
    87d3:	4c 8d 05 36 6a 00 00 	lea    0x6a36(%rip),%r8        # f210 <_IO_stdin_used+0x210>
    87da:	eb ae                	jmp    878a <fwp_write+0xca>
    87dc:	0f 1f 40 00          	nopl   0x0(%rax)
    87e0:	83 fa 13             	cmp    $0x13,%edx
    87e3:	48 8d 05 1c 6a 00 00 	lea    0x6a1c(%rip),%rax        # f206 <_IO_stdin_used+0x206>
    87ea:	48 8d 35 1a 6a 00 00 	lea    0x6a1a(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    87f1:	ba 04 00 00 00       	mov    $0x4,%edx
    87f6:	48 0f 44 f0          	cmove  %rax,%rsi
    87fa:	45 31 ed             	xor    %r13d,%r13d
    87fd:	e8 ee b8 ff ff       	call   40f0 <buf_put>
    8802:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8807:	0f 84 a3 08 00 00    	je     90b0 <fwp_write+0x9f0>
    880d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8812:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8817:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    881c:	48 89 df             	mov    %rbx,%rdi
    881f:	49 0f 44 c5          	cmove  %r13,%rax
    8823:	31 c9                	xor    %ecx,%ecx
    8825:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    882a:	e8 91 fe ff ff       	call   86c0 <fwp_write>
    882f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8834:	0f 84 6e 09 00 00    	je     91a8 <fwp_write+0xae8>
    883a:	49 83 c5 01          	add    $0x1,%r13
    883e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8842:	0f 83 68 08 00 00    	jae    90b0 <fwp_write+0x9f0>
    8848:	ba 02 00 00 00       	mov    $0x2,%edx
    884d:	48 8d 35 01 6a 00 00 	lea    0x6a01(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8854:	48 89 df             	mov    %rbx,%rdi
    8857:	e8 94 b8 ff ff       	call   40f0 <buf_put>
    885c:	eb af                	jmp    880d <fwp_write+0x14d>
    885e:	66 90                	xchg   %ax,%ax
    8860:	ba 06 00 00 00       	mov    $0x6,%edx
    8865:	48 8d 35 c2 69 00 00 	lea    0x69c2(%rip),%rsi        # f22e <_IO_stdin_used+0x22e>
    886c:	48 83 c5 10          	add    $0x10,%rbp
    8870:	e8 7b b8 ff ff       	call   40f0 <buf_put>
    8875:	48 89 ef             	mov    %rbp,%rdi
    8878:	e8 c3 ab ff ff       	call   3440 <strlen@plt>
    887d:	48 89 ee             	mov    %rbp,%rsi
    8880:	48 89 df             	mov    %rbx,%rdi
    8883:	48 89 c2             	mov    %rax,%rdx
    8886:	e8 65 b8 ff ff       	call   40f0 <buf_put>
    888b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8890:	ba 01 00 00 00       	mov    $0x1,%edx
    8895:	48 89 df             	mov    %rbx,%rdi
    8898:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    889d:	e8 4e b8 ff ff       	call   40f0 <buf_put>
    88a2:	e9 af fe ff ff       	jmp    8756 <fwp_write+0x96>
    88a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    88ae:	00 00 
    88b0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    88b7:	00 
    88b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88bf:	00 00 
    88c1:	0f 85 ce 02 00 00    	jne    8b95 <fwp_write+0x4d5>
    88c7:	ba 0a 00 00 00       	mov    $0xa,%edx
    88cc:	48 8d 35 47 69 00 00 	lea    0x6947(%rip),%rsi        # f21a <_IO_stdin_used+0x21a>
    88d3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    88da:	48 89 df             	mov    %rbx,%rdi
    88dd:	5b                   	pop    %rbx
    88de:	5d                   	pop    %rbp
    88df:	41 5c                	pop    %r12
    88e1:	41 5d                	pop    %r13
    88e3:	41 5e                	pop    %r14
    88e5:	41 5f                	pop    %r15
    88e7:	e9 04 b8 ff ff       	jmp    40f0 <buf_put>
    88ec:	0f 1f 40 00          	nopl   0x0(%rax)
    88f0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    88f5:	4d 85 ed             	test   %r13,%r13
    88f8:	0f 84 02 0c 00 00    	je     9500 <fwp_write+0xe40>
    88fe:	48 8d 35 5d 69 00 00 	lea    0x695d(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    8905:	4c 89 ef             	mov    %r13,%rdi
    8908:	e8 13 ac ff ff       	call   3520 <strcmp@plt>
    890d:	41 89 c1             	mov    %eax,%r9d
    8910:	85 c0                	test   %eax,%eax
    8912:	0f 84 6c 0c 00 00    	je     9584 <fwp_write+0xec4>
    8918:	4c 89 ef             	mov    %r13,%rdi
    891b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8920:	e8 1b ab ff ff       	call   3440 <strlen@plt>
    8925:	4c 89 ee             	mov    %r13,%rsi
    8928:	48 89 df             	mov    %rbx,%rdi
    892b:	48 89 c2             	mov    %rax,%rdx
    892e:	e8 bd b7 ff ff       	call   40f0 <buf_put>
    8933:	ba 01 00 00 00       	mov    $0x1,%edx
    8938:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    893d:	48 89 df             	mov    %rbx,%rdi
    8940:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8945:	e8 a6 b7 ff ff       	call   40f0 <buf_put>
    894a:	ba 01 00 00 00       	mov    $0x1,%edx
    894f:	4c 89 fe             	mov    %r15,%rsi
    8952:	48 89 df             	mov    %rbx,%rdi
    8955:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    895a:	e8 91 b7 ff ff       	call   40f0 <buf_put>
    895f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8964:	45 31 f6             	xor    %r14d,%r14d
    8967:	85 d2                	test   %edx,%edx
    8969:	0f 8e 81 0a 00 00    	jle    93f0 <fwp_write+0xd30>
    896f:	45 31 ed             	xor    %r13d,%r13d
    8972:	4d 85 ed             	test   %r13,%r13
    8975:	0f 85 75 07 00 00    	jne    90f0 <fwp_write+0xa30>
    897b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8982:	00 
    8983:	45 85 f6             	test   %r14d,%r14d
    8986:	0f 84 84 07 00 00    	je     9110 <fwp_write+0xa50>
    898c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8991:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8996:	48 89 df             	mov    %rbx,%rdi
    8999:	49 83 c5 01          	add    $0x1,%r13
    899d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    89a1:	31 c9                	xor    %ecx,%ecx
    89a3:	e8 18 fd ff ff       	call   86c0 <fwp_write>
    89a8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    89ad:	7f c3                	jg     8972 <fwp_write+0x2b2>
    89af:	45 85 f6             	test   %r14d,%r14d
    89b2:	0f 84 38 0a 00 00    	je     93f0 <fwp_write+0xd30>
    89b8:	b8 29 00 00 00       	mov    $0x29,%eax
    89bd:	ba 01 00 00 00       	mov    $0x1,%edx
    89c2:	4c 89 fe             	mov    %r15,%rsi
    89c5:	48 89 df             	mov    %rbx,%rdi
    89c8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    89cc:	e8 1f b7 ff ff       	call   40f0 <buf_put>
    89d1:	e9 80 fd ff ff       	jmp    8756 <fwp_write+0x96>
    89d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    89dd:	00 00 00 
    89e0:	ba 01 00 00 00       	mov    $0x1,%edx
    89e5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89ea:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    89ef:	e8 fc b6 ff ff       	call   40f0 <buf_put>
    89f4:	48 85 ed             	test   %rbp,%rbp
    89f7:	0f 84 93 06 00 00    	je     9090 <fwp_write+0x9d0>
    89fd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8a01:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8a06:	31 c9                	xor    %ecx,%ecx
    8a08:	48 89 df             	mov    %rbx,%rdi
    8a0b:	e8 b0 fc ff ff       	call   86c0 <fwp_write>
    8a10:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8a14:	48 85 ed             	test   %rbp,%rbp
    8a17:	0f 84 73 06 00 00    	je     9090 <fwp_write+0x9d0>
    8a1d:	ba 02 00 00 00       	mov    $0x2,%edx
    8a22:	48 8d 35 2c 68 00 00 	lea    0x682c(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8a29:	48 89 df             	mov    %rbx,%rdi
    8a2c:	e8 bf b6 ff ff       	call   40f0 <buf_put>
    8a31:	eb ca                	jmp    89fd <fwp_write+0x33d>
    8a33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a38:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8a3c:	85 f6                	test   %esi,%esi
    8a3e:	0f 84 fc 07 00 00    	je     9240 <fwp_write+0xb80>
    8a44:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a4b:	00 
    8a4c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a53:	00 00 
    8a55:	0f 85 3a 01 00 00    	jne    8b95 <fwp_write+0x4d5>
    8a5b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8a5f:	4c 89 ea             	mov    %r13,%rdx
    8a62:	e9 6c fe ff ff       	jmp    88d3 <fwp_write+0x213>
    8a67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a6e:	00 00 
    8a70:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8a75:	ba 01 00 00 00       	mov    $0x1,%edx
    8a7a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8a7f:	48 89 ee             	mov    %rbp,%rsi
    8a82:	e8 69 b6 ff ff       	call   40f0 <buf_put>
    8a87:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8a8c:	4c 89 e7             	mov    %r12,%rdi
    8a8f:	e8 ac a9 ff ff       	call   3440 <strlen@plt>
    8a94:	4c 89 e6             	mov    %r12,%rsi
    8a97:	48 89 df             	mov    %rbx,%rdi
    8a9a:	48 89 c2             	mov    %rax,%rdx
    8a9d:	e8 4e b6 ff ff       	call   40f0 <buf_put>
    8aa2:	ba 01 00 00 00       	mov    $0x1,%edx
    8aa7:	48 89 ee             	mov    %rbp,%rsi
    8aaa:	48 89 df             	mov    %rbx,%rdi
    8aad:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8ab2:	e8 39 b6 ff ff       	call   40f0 <buf_put>
    8ab7:	e9 9a fc ff ff       	jmp    8756 <fwp_write+0x96>
    8abc:	0f 1f 40 00          	nopl   0x0(%rax)
    8ac0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8ac5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8ac9:	0f 8a 8e 0b 00 00    	jp     965d <fwp_write+0xf9d>
    8acf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8ad3:	66 0f 54 05 25 73 00 	andpd  0x7325(%rip),%xmm0        # fe00 <msg.4+0xc0>
    8ada:	00 
    8adb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8ae0:	66 0f 2e 05 90 72 00 	ucomisd 0x7290(%rip),%xmm0        # fd78 <msg.4+0x38>
    8ae7:	00 
    8ae8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8aef:	00 
    8af0:	0f 87 b2 09 00 00    	ja     94a8 <fwp_write+0xde8>
    8af6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8afd:	00 00 00 
    8b00:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8b04:	89 ee                	mov    %ebp,%esi
    8b06:	4c 89 e7             	mov    %r12,%rdi
    8b09:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8b0e:	e8 5d bc ff ff       	call   4770 <fwp_format_g.constprop.0>
    8b13:	31 f6                	xor    %esi,%esi
    8b15:	4c 89 e7             	mov    %r12,%rdi
    8b18:	e8 e3 a8 ff ff       	call   3400 <strtod@plt>
    8b1d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8b22:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8b26:	7a 06                	jp     8b2e <fwp_write+0x46e>
    8b28:	0f 84 e9 01 00 00    	je     8d17 <fwp_write+0x657>
    8b2e:	83 c5 01             	add    $0x1,%ebp
    8b31:	83 fd 12             	cmp    $0x12,%ebp
    8b34:	75 ca                	jne    8b00 <fwp_write+0x440>
    8b36:	be 11 00 00 00       	mov    $0x11,%esi
    8b3b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8b3f:	4c 89 e7             	mov    %r12,%rdi
    8b42:	e8 29 bc ff ff       	call   4770 <fwp_format_g.constprop.0>
    8b47:	e9 cb 01 00 00       	jmp    8d17 <fwp_write+0x657>
    8b4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b50:	48 83 fd 01          	cmp    $0x1,%rbp
    8b54:	0f 84 e6 08 00 00    	je     9440 <fwp_write+0xd80>
    8b5a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8b5e:	b8 02 00 00 00       	mov    $0x2,%eax
    8b63:	ba 01 00 00 00       	mov    $0x1,%edx
    8b68:	48 0f 44 d0          	cmove  %rax,%rdx
    8b6c:	48 8d 35 8b 66 00 00 	lea    0x668b(%rip),%rsi        # f1fe <_IO_stdin_used+0x1fe>
    8b73:	48 8d 05 89 66 00 00 	lea    0x6689(%rip),%rax        # f203 <_IO_stdin_used+0x203>
    8b7a:	48 0f 44 f0          	cmove  %rax,%rsi
    8b7e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b85:	00 
    8b86:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b8d:	00 00 
    8b8f:	0f 84 3e fd ff ff    	je     88d3 <fwp_write+0x213>
    8b95:	e8 b6 a8 ff ff       	call   3450 <__stack_chk_fail@plt>
    8b9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ba0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8ba5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8baa:	e8 81 b4 ff ff       	call   4030 <buf_grow>
    8baf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8bb3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8bb9:	4c 03 0b             	add    (%rbx),%r9
    8bbc:	66 45 89 11          	mov    %r10w,(%r9)
    8bc0:	45 85 e4             	test   %r12d,%r12d
    8bc3:	0f 8e 07 05 00 00    	jle    90d0 <fwp_write+0xa10>
    8bc9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8bd0:	55 55 55 
    8bd3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8bd8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8bdf:	aa aa aa 
    8be2:	49 83 c1 01          	add    $0x1,%r9
    8be6:	eb 45                	jmp    8c2d <fwp_write+0x56d>
    8be8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bef:	00 
    8bf0:	be 01 00 00 00       	mov    $0x1,%esi
    8bf5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8bfa:	88 07                	mov    %al,(%rdi)
    8bfc:	48 89 e8             	mov    %rbp,%rax
    8bff:	49 f7 e8             	imul   %r8
    8c02:	48 89 e8             	mov    %rbp,%rax
    8c05:	48 c1 f8 3f          	sar    $0x3f,%rax
    8c09:	48 29 c2             	sub    %rax,%rdx
    8c0c:	48 85 c9             	test   %rcx,%rcx
    8c0f:	0f 95 c0             	setne  %al
    8c12:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8c16:	48 83 ef 01          	sub    $0x1,%rdi
    8c1a:	48 21 c5             	and    %rax,%rbp
    8c1d:	48 29 ea             	sub    %rbp,%rdx
    8c20:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8c24:	49 39 f9             	cmp    %rdi,%r9
    8c27:	0f 84 a3 04 00 00    	je     90d0 <fwp_write+0xa10>
    8c2d:	48 89 e8             	mov    %rbp,%rax
    8c30:	49 f7 e8             	imul   %r8
    8c33:	48 89 e8             	mov    %rbp,%rax
    8c36:	48 c1 f8 3f          	sar    $0x3f,%rax
    8c3a:	48 89 d1             	mov    %rdx,%rcx
    8c3d:	48 29 c1             	sub    %rax,%rcx
    8c40:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8c44:	48 89 e9             	mov    %rbp,%rcx
    8c47:	48 29 c1             	sub    %rax,%rcx
    8c4a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8c4e:	49 f7 e2             	mul    %r10
    8c51:	b8 30 00 00 00       	mov    $0x30,%eax
    8c56:	48 89 d6             	mov    %rdx,%rsi
    8c59:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8c5d:	48 d1 ee             	shr    $1,%rsi
    8c60:	48 01 f2             	add    %rsi,%rdx
    8c63:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8c67:	48 29 d6             	sub    %rdx,%rsi
    8c6a:	74 8e                	je     8bfa <fwp_write+0x53a>
    8c6c:	48 83 fe 01          	cmp    $0x1,%rsi
    8c70:	0f 85 7a ff ff ff    	jne    8bf0 <fwp_write+0x530>
    8c76:	31 f6                	xor    %esi,%esi
    8c78:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8c7d:	e9 78 ff ff ff       	jmp    8bfa <fwp_write+0x53a>
    8c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c88:	66 0f 6e cd          	movd   %ebp,%xmm1
    8c8c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8c8f:	0f 8a c8 09 00 00    	jp     965d <fwp_write+0xf9d>
    8c95:	0f 28 c1             	movaps %xmm1,%xmm0
    8c98:	0f 54 05 51 71 00 00 	andps  0x7151(%rip),%xmm0        # fdf0 <msg.4+0xb0>
    8c9f:	0f 2e 05 5e 63 00 00 	ucomiss 0x635e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8ca6:	0f 87 24 08 00 00    	ja     94d0 <fwp_write+0xe10>
    8cac:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8cb0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8cb6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8cbd:	00 
    8cbe:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8cc2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cce:	00 00 
    8cd0:	44 89 ee             	mov    %r13d,%esi
    8cd3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8cd8:	4c 89 e7             	mov    %r12,%rdi
    8cdb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8ce0:	e8 8b ba ff ff       	call   4770 <fwp_format_g.constprop.0>
    8ce5:	31 f6                	xor    %esi,%esi
    8ce7:	4c 89 e7             	mov    %r12,%rdi
    8cea:	e8 b1 a7 ff ff       	call   34a0 <strtof@plt>
    8cef:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8cf4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8cf7:	7a 02                	jp     8cfb <fwp_write+0x63b>
    8cf9:	74 1c                	je     8d17 <fwp_write+0x657>
    8cfb:	41 83 c5 01          	add    $0x1,%r13d
    8cff:	41 83 fd 0a          	cmp    $0xa,%r13d
    8d03:	75 cb                	jne    8cd0 <fwp_write+0x610>
    8d05:	be 09 00 00 00       	mov    $0x9,%esi
    8d0a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8d0f:	4c 89 e7             	mov    %r12,%rdi
    8d12:	e8 59 ba ff ff       	call   4770 <fwp_format_g.constprop.0>
    8d17:	4c 89 e7             	mov    %r12,%rdi
    8d1a:	e8 91 b4 ff ff       	call   41b0 <fwp_finish_float>
    8d1f:	e9 1c fa ff ff       	jmp    8740 <fwp_write+0x80>
    8d24:	0f 1f 40 00          	nopl   0x0(%rax)
    8d28:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8d2c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8d30:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8d37:	00 
    8d38:	48 89 ef             	mov    %rbp,%rdi
    8d3b:	e8 00 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8d40:	48 89 ef             	mov    %rbp,%rdi
    8d43:	e8 f8 a6 ff ff       	call   3440 <strlen@plt>
    8d48:	48 89 ee             	mov    %rbp,%rsi
    8d4b:	48 89 df             	mov    %rbx,%rdi
    8d4e:	48 89 c2             	mov    %rax,%rdx
    8d51:	e8 9a b3 ff ff       	call   40f0 <buf_put>
    8d56:	e9 fb f9 ff ff       	jmp    8756 <fwp_write+0x96>
    8d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8d60:	ba 06 00 00 00       	mov    $0x6,%edx
    8d65:	48 8d 35 ec 64 00 00 	lea    0x64ec(%rip),%rsi        # f258 <_IO_stdin_used+0x258>
    8d6c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8d72:	e8 79 b3 ff ff       	call   40f0 <buf_put>
    8d77:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d7e:	ff ff 7f 
    8d81:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d85:	0f 84 86 02 00 00    	je     9011 <fwp_write+0x951>
    8d8b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d90:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d94:	48 85 d2             	test   %rdx,%rdx
    8d97:	0f 84 ae 00 00 00    	je     8e4b <fwp_write+0x78b>
    8d9d:	8b 0a                	mov    (%rdx),%ecx
    8d9f:	83 f9 1c             	cmp    $0x1c,%ecx
    8da2:	0f 84 58 06 00 00    	je     9400 <fwp_write+0xd40>
    8da8:	83 f9 1b             	cmp    $0x1b,%ecx
    8dab:	0f 87 9a 00 00 00    	ja     8e4b <fwp_write+0x78b>
    8db1:	be 01 00 00 00       	mov    $0x1,%esi
    8db6:	48 d3 e6             	shl    %cl,%rsi
    8db9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8dbf:	0f 85 4b 04 00 00    	jne    9210 <fwp_write+0xb50>
    8dc5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8dcb:	0f 85 0f 04 00 00    	jne    91e0 <fwp_write+0xb20>
    8dd1:	83 e6 21             	and    $0x21,%esi
    8dd4:	74 75                	je     8e4b <fwp_write+0x78b>
    8dd6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8ddb:	48 85 ff             	test   %rdi,%rdi
    8dde:	79 07                	jns    8de7 <fwp_write+0x727>
    8de0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8de4:	4c 01 ee             	add    %r13,%rsi
    8de7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8deb:	85 c9                	test   %ecx,%ecx
    8ded:	40 0f b6 f7          	movzbl %dil,%esi
    8df1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dfc:	00 00 00 00 
    8e00:	31 c9                	xor    %ecx,%ecx
    8e02:	48 89 df             	mov    %rbx,%rdi
    8e05:	49 83 c5 01          	add    $0x1,%r13
    8e09:	e8 b2 f8 ff ff       	call   86c0 <fwp_write>
    8e0e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8e15:	ff ff 7f 
    8e18:	48 23 55 00          	and    0x0(%rbp),%rdx
    8e1c:	49 39 d5             	cmp    %rdx,%r13
    8e1f:	0f 83 ec 01 00 00    	jae    9011 <fwp_write+0x951>
    8e25:	ba 02 00 00 00       	mov    $0x2,%edx
    8e2a:	48 89 df             	mov    %rbx,%rdi
    8e2d:	48 8d 35 21 64 00 00 	lea    0x6421(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8e34:	e8 b7 b2 ff ff       	call   40f0 <buf_put>
    8e39:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e3e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8e42:	48 85 d2             	test   %rdx,%rdx
    8e45:	0f 85 52 ff ff ff    	jne    8d9d <fwp_write+0x6dd>
    8e4b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8e50:	48 85 ff             	test   %rdi,%rdi
    8e53:	0f 88 cf 05 00 00    	js     9428 <fwp_write+0xd68>
    8e59:	48 8b 31             	mov    (%rcx),%rsi
    8e5c:	eb a2                	jmp    8e00 <fwp_write+0x740>
    8e5e:	66 90                	xchg   %ax,%ax
    8e60:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e67:	00 
    8e68:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e6f:	00 00 
    8e71:	0f 85 1e fd ff ff    	jne    8b95 <fwp_write+0x4d5>
    8e77:	ba 08 00 00 00       	mov    $0x8,%edx
    8e7c:	48 8d 35 a2 63 00 00 	lea    0x63a2(%rip),%rsi        # f225 <_IO_stdin_used+0x225>
    8e83:	e9 4b fa ff ff       	jmp    88d3 <fwp_write+0x213>
    8e88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e8f:	00 
    8e90:	89 e8                	mov    %ebp,%eax
    8e92:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8e99:	76 03                	jbe    8e9e <fwp_write+0x7de>
    8e9b:	8b 45 00             	mov    0x0(%rbp),%eax
    8e9e:	41 89 c6             	mov    %eax,%r14d
    8ea1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8ea6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8eab:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8eaf:	4c 89 ef             	mov    %r13,%rdi
    8eb2:	e8 89 a5 ff ff       	call   3440 <strlen@plt>
    8eb7:	4c 89 ee             	mov    %r13,%rsi
    8eba:	48 89 df             	mov    %rbx,%rdi
    8ebd:	48 89 c2             	mov    %rax,%rdx
    8ec0:	e8 2b b2 ff ff       	call   40f0 <buf_put>
    8ec5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8eca:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8ece:	85 f6                	test   %esi,%esi
    8ed0:	0f 8e 80 f8 ff ff    	jle    8756 <fwp_write+0x96>
    8ed6:	45 31 ed             	xor    %r13d,%r13d
    8ed9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8ede:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8ee3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8ee8:	ba 01 00 00 00       	mov    $0x1,%edx
    8eed:	4c 89 fe             	mov    %r15,%rsi
    8ef0:	48 89 04 24          	mov    %rax,(%rsp)
    8ef4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8ef9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8efd:	48 89 df             	mov    %rbx,%rdi
    8f00:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8f04:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8f09:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8f0e:	e8 dd b1 ff ff       	call   40f0 <buf_put>
    8f13:	41 8b 06             	mov    (%r14),%eax
    8f16:	83 f8 0e             	cmp    $0xe,%eax
    8f19:	0f 84 71 02 00 00    	je     9190 <fwp_write+0xad0>
    8f1f:	83 f8 10             	cmp    $0x10,%eax
    8f22:	0f 84 38 02 00 00    	je     9160 <fwp_write+0xaa0>
    8f28:	83 f8 0a             	cmp    $0xa,%eax
    8f2b:	0f 84 7f 04 00 00    	je     93b0 <fwp_write+0xcf0>
    8f31:	0f 8f f9 00 00 00    	jg     9030 <fwp_write+0x970>
    8f37:	83 f8 03             	cmp    $0x3,%eax
    8f3a:	0f 8f 50 04 00 00    	jg     9390 <fwp_write+0xcd0>
    8f40:	85 c0                	test   %eax,%eax
    8f42:	78 10                	js     8f54 <fwp_write+0x894>
    8f44:	48 8b 04 24          	mov    (%rsp),%rax
    8f48:	48 c1 e8 3f          	shr    $0x3f,%rax
    8f4c:	85 c0                	test   %eax,%eax
    8f4e:	0f 85 f9 00 00 00    	jne    904d <fwp_write+0x98d>
    8f54:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f59:	48 8b 34 24          	mov    (%rsp),%rsi
    8f5d:	31 c9                	xor    %ecx,%ecx
    8f5f:	48 89 df             	mov    %rbx,%rdi
    8f62:	e8 59 f7 ff ff       	call   86c0 <fwp_write>
    8f67:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8f6c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8f71:	49 83 c5 01          	add    $0x1,%r13
    8f75:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8f79:	0f 8f 5f ff ff ff    	jg     8ede <fwp_write+0x81e>
    8f7f:	e9 d2 f7 ff ff       	jmp    8756 <fwp_write+0x96>
    8f84:	0f 1f 40 00          	nopl   0x0(%rax)
    8f88:	ba 06 00 00 00       	mov    $0x6,%edx
    8f8d:	48 8d 35 b7 62 00 00 	lea    0x62b7(%rip),%rsi        # f24b <_IO_stdin_used+0x24b>
    8f94:	45 31 ed             	xor    %r13d,%r13d
    8f97:	e8 54 b1 ff ff       	call   40f0 <buf_put>
    8f9c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8fa1:	75 19                	jne    8fbc <fwp_write+0x8fc>
    8fa3:	eb 6c                	jmp    9011 <fwp_write+0x951>
    8fa5:	0f 1f 00             	nopl   (%rax)
    8fa8:	ba 02 00 00 00       	mov    $0x2,%edx
    8fad:	48 8d 35 a1 62 00 00 	lea    0x62a1(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8fb4:	48 89 df             	mov    %rbx,%rdi
    8fb7:	e8 34 b1 ff ff       	call   40f0 <buf_put>
    8fbc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8fc2:	b9 00 02 00 00       	mov    $0x200,%ecx
    8fc7:	31 c0                	xor    %eax,%eax
    8fc9:	49 83 c5 01          	add    $0x1,%r13
    8fcd:	4c 8d 05 7e 62 00 00 	lea    0x627e(%rip),%r8        # f252 <_IO_stdin_used+0x252>
    8fd4:	ba 02 00 00 00       	mov    $0x2,%edx
    8fd9:	be 00 02 00 00       	mov    $0x200,%esi
    8fde:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fe5:	00 
    8fe6:	e8 b5 a3 ff ff       	call   33a0 <__snprintf_chk@plt>
    8feb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ff2:	00 
    8ff3:	e8 48 a4 ff ff       	call   3440 <strlen@plt>
    8ff8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8fff:	00 
    9000:	48 89 df             	mov    %rbx,%rdi
    9003:	48 89 c2             	mov    %rax,%rdx
    9006:	e8 e5 b0 ff ff       	call   40f0 <buf_put>
    900b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    900f:	72 97                	jb     8fa8 <fwp_write+0x8e8>
    9011:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9016:	ba 01 00 00 00       	mov    $0x1,%edx
    901b:	48 89 df             	mov    %rbx,%rdi
    901e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9023:	e8 c8 b0 ff ff       	call   40f0 <buf_put>
    9028:	e9 29 f7 ff ff       	jmp    8756 <fwp_write+0x96>
    902d:	0f 1f 00             	nopl   (%rax)
    9030:	83 f8 0b             	cmp    $0xb,%eax
    9033:	0f 85 1b ff ff ff    	jne    8f54 <fwp_write+0x894>
    9039:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    903e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9042:	83 e0 01             	and    $0x1,%eax
    9045:	85 c0                	test   %eax,%eax
    9047:	0f 84 07 ff ff ff    	je     8f54 <fwp_write+0x894>
    904d:	4c 89 fe             	mov    %r15,%rsi
    9050:	48 89 df             	mov    %rbx,%rdi
    9053:	ba 01 00 00 00       	mov    $0x1,%edx
    9058:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    905d:	e8 8e b0 ff ff       	call   40f0 <buf_put>
    9062:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9067:	48 8b 34 24          	mov    (%rsp),%rsi
    906b:	31 c9                	xor    %ecx,%ecx
    906d:	48 89 df             	mov    %rbx,%rdi
    9070:	e8 4b f6 ff ff       	call   86c0 <fwp_write>
    9075:	ba 01 00 00 00       	mov    $0x1,%edx
    907a:	4c 89 fe             	mov    %r15,%rsi
    907d:	48 89 df             	mov    %rbx,%rdi
    9080:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9085:	e8 66 b0 ff ff       	call   40f0 <buf_put>
    908a:	e9 d8 fe ff ff       	jmp    8f67 <fwp_write+0x8a7>
    908f:	90                   	nop
    9090:	ba 01 00 00 00       	mov    $0x1,%edx
    9095:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    909a:	48 89 df             	mov    %rbx,%rdi
    909d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    90a2:	e8 49 b0 ff ff       	call   40f0 <buf_put>
    90a7:	e9 aa f6 ff ff       	jmp    8756 <fwp_write+0x96>
    90ac:	0f 1f 40 00          	nopl   0x0(%rax)
    90b0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    90b5:	ba 01 00 00 00       	mov    $0x1,%edx
    90ba:	48 89 df             	mov    %rbx,%rdi
    90bd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    90c2:	e8 29 b0 ff ff       	call   40f0 <buf_put>
    90c7:	e9 8a f6 ff ff       	jmp    8756 <fwp_write+0x96>
    90cc:	0f 1f 40 00          	nopl   0x0(%rax)
    90d0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    90d4:	48 8b 13             	mov    (%rbx),%rdx
    90d7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    90dc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    90e0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    90e4:	e9 6d f6 ff ff       	jmp    8756 <fwp_write+0x96>
    90e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90f0:	ba 02 00 00 00       	mov    $0x2,%edx
    90f5:	48 8d 35 59 61 00 00 	lea    0x6159(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    90fc:	48 89 df             	mov    %rbx,%rdi
    90ff:	e8 ec af ff ff       	call   40f0 <buf_put>
    9104:	e9 72 f8 ff ff       	jmp    897b <fwp_write+0x2bb>
    9109:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9110:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9115:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    911a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    911e:	48 89 f7             	mov    %rsi,%rdi
    9121:	48 89 34 24          	mov    %rsi,(%rsp)
    9125:	e8 16 a3 ff ff       	call   3440 <strlen@plt>
    912a:	48 8b 34 24          	mov    (%rsp),%rsi
    912e:	48 89 df             	mov    %rbx,%rdi
    9131:	48 89 c2             	mov    %rax,%rdx
    9134:	e8 b7 af ff ff       	call   40f0 <buf_put>
    9139:	ba 03 00 00 00       	mov    $0x3,%edx
    913e:	48 8d 35 33 61 00 00 	lea    0x6133(%rip),%rsi        # f278 <_IO_stdin_used+0x278>
    9145:	48 89 df             	mov    %rbx,%rdi
    9148:	e8 a3 af ff ff       	call   40f0 <buf_put>
    914d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9152:	e9 35 f8 ff ff       	jmp    898c <fwp_write+0x2cc>
    9157:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    915e:	00 00 
    9160:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9165:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9169:	48 85 ff             	test   %rdi,%rdi
    916c:	0f 84 e2 fd ff ff    	je     8f54 <fwp_write+0x894>
    9172:	48 8d 35 e9 60 00 00 	lea    0x60e9(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    9179:	e8 a2 a3 ff ff       	call   3520 <strcmp@plt>
    917e:	85 c0                	test   %eax,%eax
    9180:	0f 95 c0             	setne  %al
    9183:	0f b6 c0             	movzbl %al,%eax
    9186:	e9 c1 fd ff ff       	jmp    8f4c <fwp_write+0x88c>
    918b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9190:	31 c0                	xor    %eax,%eax
    9192:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9199:	00 
    919a:	0f 97 c0             	seta   %al
    919d:	e9 aa fd ff ff       	jmp    8f4c <fwp_write+0x88c>
    91a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    91a8:	48 89 df             	mov    %rbx,%rdi
    91ab:	ba 02 00 00 00       	mov    $0x2,%edx
    91b0:	48 8d 35 a8 60 00 00 	lea    0x60a8(%rip),%rsi        # f25f <_IO_stdin_used+0x25f>
    91b7:	e8 34 af ff ff       	call   40f0 <buf_put>
    91bc:	4c 89 e8             	mov    %r13,%rax
    91bf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    91c4:	31 c9                	xor    %ecx,%ecx
    91c6:	48 c1 e0 04          	shl    $0x4,%rax
    91ca:	48 89 df             	mov    %rbx,%rdi
    91cd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    91d2:	e8 e9 f4 ff ff       	call   86c0 <fwp_write>
    91d7:	e9 5e f6 ff ff       	jmp    883a <fwp_write+0x17a>
    91dc:	0f 1f 40 00          	nopl   0x0(%rax)
    91e0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    91e5:	48 85 ff             	test   %rdi,%rdi
    91e8:	79 0c                	jns    91f6 <fwp_write+0xb36>
    91ea:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    91f1:	00 
    91f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    91f6:	48 63 3e             	movslq (%rsi),%rdi
    91f9:	83 f9 02             	cmp    $0x2,%ecx
    91fc:	89 fe                	mov    %edi,%esi
    91fe:	48 0f 44 f7          	cmove  %rdi,%rsi
    9202:	e9 f9 fb ff ff       	jmp    8e00 <fwp_write+0x740>
    9207:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    920e:	00 00 
    9210:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9215:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    921a:	48 85 ff             	test   %rdi,%rdi
    921d:	0f 88 0f 03 00 00    	js     9532 <fwp_write+0xe72>
    9223:	49 0f bf 38          	movswq (%r8),%rdi
    9227:	83 f9 01             	cmp    $0x1,%ecx
    922a:	0f b7 f7             	movzwl %di,%esi
    922d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9231:	e9 ca fb ff ff       	jmp    8e00 <fwp_write+0x740>
    9236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    923d:	00 00 00 
    9240:	ba 01 00 00 00       	mov    $0x1,%edx
    9245:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    924a:	48 83 c5 08          	add    $0x8,%rbp
    924e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9253:	e8 98 ae ff ff       	call   40f0 <buf_put>
    9258:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    925d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9262:	4d 85 ed             	test   %r13,%r13
    9265:	75 46                	jne    92ad <fwp_write+0xbed>
    9267:	e9 04 01 00 00       	jmp    9370 <fwp_write+0xcb0>
    926c:	0f 1f 40 00          	nopl   0x0(%rax)
    9270:	41 80 f9 09          	cmp    $0x9,%r9b
    9274:	0f 84 d6 00 00 00    	je     9350 <fwp_write+0xc90>
    927a:	41 80 f9 0a          	cmp    $0xa,%r9b
    927e:	0f 85 9c 00 00 00    	jne    9320 <fwp_write+0xc60>
    9284:	ba 02 00 00 00       	mov    $0x2,%edx
    9289:	48 8d 35 ab 5f 00 00 	lea    0x5fab(%rip),%rsi        # f23b <_IO_stdin_used+0x23b>
    9290:	48 89 df             	mov    %rbx,%rdi
    9293:	e8 58 ae ff ff       	call   40f0 <buf_put>
    9298:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    929f:	00 
    92a0:	48 83 c5 01          	add    $0x1,%rbp
    92a4:	49 39 ec             	cmp    %rbp,%r12
    92a7:	0f 84 c3 00 00 00    	je     9370 <fwp_write+0xcb0>
    92ad:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    92b2:	41 80 f9 0d          	cmp    $0xd,%r9b
    92b6:	74 28                	je     92e0 <fwp_write+0xc20>
    92b8:	7e b6                	jle    9270 <fwp_write+0xbb0>
    92ba:	41 80 f9 22          	cmp    $0x22,%r9b
    92be:	74 40                	je     9300 <fwp_write+0xc40>
    92c0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    92c4:	75 5a                	jne    9320 <fwp_write+0xc60>
    92c6:	ba 02 00 00 00       	mov    $0x2,%edx
    92cb:	48 8d 35 66 5f 00 00 	lea    0x5f66(%rip),%rsi        # f238 <_IO_stdin_used+0x238>
    92d2:	48 89 df             	mov    %rbx,%rdi
    92d5:	e8 16 ae ff ff       	call   40f0 <buf_put>
    92da:	eb c4                	jmp    92a0 <fwp_write+0xbe0>
    92dc:	0f 1f 40 00          	nopl   0x0(%rax)
    92e0:	ba 02 00 00 00       	mov    $0x2,%edx
    92e5:	48 8d 35 55 5f 00 00 	lea    0x5f55(%rip),%rsi        # f241 <_IO_stdin_used+0x241>
    92ec:	48 89 df             	mov    %rbx,%rdi
    92ef:	e8 fc ad ff ff       	call   40f0 <buf_put>
    92f4:	eb aa                	jmp    92a0 <fwp_write+0xbe0>
    92f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92fd:	00 00 00 
    9300:	ba 02 00 00 00       	mov    $0x2,%edx
    9305:	48 8d 35 29 5f 00 00 	lea    0x5f29(%rip),%rsi        # f235 <_IO_stdin_used+0x235>
    930c:	48 89 df             	mov    %rbx,%rdi
    930f:	e8 dc ad ff ff       	call   40f0 <buf_put>
    9314:	eb 8a                	jmp    92a0 <fwp_write+0xbe0>
    9316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    931d:	00 00 00 
    9320:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9324:	0f 86 2e 01 00 00    	jbe    9458 <fwp_write+0xd98>
    932a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    932e:	0f 84 24 01 00 00    	je     9458 <fwp_write+0xd98>
    9334:	ba 01 00 00 00       	mov    $0x1,%edx
    9339:	4c 89 fe             	mov    %r15,%rsi
    933c:	48 89 df             	mov    %rbx,%rdi
    933f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9344:	e8 a7 ad ff ff       	call   40f0 <buf_put>
    9349:	e9 52 ff ff ff       	jmp    92a0 <fwp_write+0xbe0>
    934e:	66 90                	xchg   %ax,%ax
    9350:	ba 02 00 00 00       	mov    $0x2,%edx
    9355:	48 8d 35 e2 5e 00 00 	lea    0x5ee2(%rip),%rsi        # f23e <_IO_stdin_used+0x23e>
    935c:	48 89 df             	mov    %rbx,%rdi
    935f:	e8 8c ad ff ff       	call   40f0 <buf_put>
    9364:	e9 37 ff ff ff       	jmp    92a0 <fwp_write+0xbe0>
    9369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9370:	ba 01 00 00 00       	mov    $0x1,%edx
    9375:	4c 89 fe             	mov    %r15,%rsi
    9378:	48 89 df             	mov    %rbx,%rdi
    937b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9380:	e8 6b ad ff ff       	call   40f0 <buf_put>
    9385:	e9 cc f3 ff ff       	jmp    8756 <fwp_write+0x96>
    938a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9390:	83 f8 04             	cmp    $0x4,%eax
    9393:	0f 85 bb fb ff ff    	jne    8f54 <fwp_write+0x894>
    9399:	48 8b 04 24          	mov    (%rsp),%rax
    939d:	48 8b 40 08          	mov    0x8(%rax),%rax
    93a1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    93a6:	48 c1 e8 3f          	shr    $0x3f,%rax
    93aa:	e9 96 fc ff ff       	jmp    9045 <fwp_write+0x985>
    93af:	90                   	nop
    93b0:	8b 0c 24             	mov    (%rsp),%ecx
    93b3:	31 c0                	xor    %eax,%eax
    93b5:	85 c9                	test   %ecx,%ecx
    93b7:	0f 98 c0             	sets   %al
    93ba:	e9 86 fc ff ff       	jmp    9045 <fwp_write+0x985>
    93bf:	90                   	nop
    93c0:	48 f7 d8             	neg    %rax
    93c3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    93ca:	00 
    93cb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    93d2:	2d 
    93d3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    93da:	00 
    93db:	48 83 d2 00          	adc    $0x0,%rdx
    93df:	48 89 c6             	mov    %rax,%rsi
    93e2:	48 f7 da             	neg    %rdx
    93e5:	e8 56 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    93ea:	e9 51 f3 ff ff       	jmp    8740 <fwp_write+0x80>
    93ef:	90                   	nop
    93f0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    93f5:	e9 c3 f5 ff ff       	jmp    89bd <fwp_write+0x2fd>
    93fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9400:	4c 89 e9             	mov    %r13,%rcx
    9403:	48 c1 e1 04          	shl    $0x4,%rcx
    9407:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    940c:	48 85 ff             	test   %rdi,%rdi
    940f:	0f 89 eb f9 ff ff    	jns    8e00 <fwp_write+0x740>
    9415:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9419:	48 89 ce             	mov    %rcx,%rsi
    941c:	e9 df f9 ff ff       	jmp    8e00 <fwp_write+0x740>
    9421:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9428:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    942f:	00 
    9430:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9434:	e9 20 fa ff ff       	jmp    8e59 <fwp_write+0x799>
    9439:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9440:	ba 02 00 00 00       	mov    $0x2,%edx
    9445:	48 8d 35 b4 5d 00 00 	lea    0x5db4(%rip),%rsi        # f200 <_IO_stdin_used+0x200>
    944c:	e9 2d f7 ff ff       	jmp    8b7e <fwp_write+0x4be>
    9451:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9458:	4c 8d 05 e5 5d 00 00 	lea    0x5de5(%rip),%r8        # f244 <_IO_stdin_used+0x244>
    945f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9464:	31 c0                	xor    %eax,%eax
    9466:	ba 02 00 00 00       	mov    $0x2,%edx
    946b:	be 10 00 00 00       	mov    $0x10,%esi
    9470:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9477:	00 
    9478:	e8 23 9f ff ff       	call   33a0 <__snprintf_chk@plt>
    947d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9484:	00 
    9485:	e8 b6 9f ff ff       	call   3440 <strlen@plt>
    948a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9491:	00 
    9492:	48 89 df             	mov    %rbx,%rdi
    9495:	48 89 c2             	mov    %rax,%rdx
    9498:	e8 53 ac ff ff       	call   40f0 <buf_put>
    949d:	e9 fe fd ff ff       	jmp    92a0 <fwp_write+0xbe0>
    94a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    94a8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    94ac:	48 8d 35 47 5d 00 00 	lea    0x5d47(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    94b3:	48 8d 05 3f 5d 00 00 	lea    0x5d3f(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    94ba:	4c 89 e7             	mov    %r12,%rdi
    94bd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    94c1:	48 0f 46 f0          	cmovbe %rax,%rsi
    94c5:	e8 16 9f ff ff       	call   33e0 <strcpy@plt>
    94ca:	e9 71 f2 ff ff       	jmp    8740 <fwp_write+0x80>
    94cf:	90                   	nop
    94d0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    94d4:	48 8d 35 1f 5d 00 00 	lea    0x5d1f(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    94db:	48 8d 05 17 5d 00 00 	lea    0x5d17(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    94e2:	0f 2f c8             	comiss %xmm0,%xmm1
    94e5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    94ec:	00 
    94ed:	4c 89 e7             	mov    %r12,%rdi
    94f0:	48 0f 46 f0          	cmovbe %rax,%rsi
    94f4:	e8 e7 9e ff ff       	call   33e0 <strcpy@plt>
    94f9:	e9 42 f2 ff ff       	jmp    8740 <fwp_write+0x80>
    94fe:	66 90                	xchg   %ax,%ax
    9500:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9505:	45 85 c0             	test   %r8d,%r8d
    9508:	75 34                	jne    953e <fwp_write+0xe7e>
    950a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9511:	00 
    9512:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9519:	00 00 
    951b:	0f 85 74 f6 ff ff    	jne    8b95 <fwp_write+0x4d5>
    9521:	ba 02 00 00 00       	mov    $0x2,%edx
    9526:	48 8d 35 48 5d 00 00 	lea    0x5d48(%rip),%rsi        # f275 <_IO_stdin_used+0x275>
    952d:	e9 a1 f3 ff ff       	jmp    88d3 <fwp_write+0x213>
    9532:	48 03 75 10          	add    0x10(%rbp),%rsi
    9536:	49 89 f0             	mov    %rsi,%r8
    9539:	e9 e5 fc ff ff       	jmp    9223 <fwp_write+0xb63>
    953e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9543:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9548:	85 ff                	test   %edi,%edi
    954a:	0f 84 fa f3 ff ff    	je     894a <fwp_write+0x28a>
    9550:	ba 01 00 00 00       	mov    $0x1,%edx
    9555:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    955a:	48 89 df             	mov    %rbx,%rdi
    955d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9562:	e8 89 ab ff ff       	call   40f0 <buf_put>
    9567:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    956c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9571:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9577:	85 c0                	test   %eax,%eax
    9579:	0f 8f f0 f3 ff ff    	jg     896f <fwp_write+0x2af>
    957f:	e9 34 f4 ff ff       	jmp    89b8 <fwp_write+0x2f8>
    9584:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9588:	49 89 c5             	mov    %rax,%r13
    958b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9590:	49 89 c4             	mov    %rax,%r12
    9593:	49 c1 fd 3f          	sar    $0x3f,%r13
    9597:	4c 09 e8             	or     %r13,%rax
    959a:	0f 84 a7 00 00 00    	je     9647 <fwp_write+0xf87>
    95a0:	48 8d 2d 19 7d 00 00 	lea    0x7d19(%rip),%rbp        # 112c0 <units.0>
    95a7:	4d 89 e7             	mov    %r12,%r15
    95aa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    95ae:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    95b3:	4c 89 ff             	mov    %r15,%rdi
    95b6:	4c 89 ee             	mov    %r13,%rsi
    95b9:	44 89 0c 24          	mov    %r9d,(%rsp)
    95bd:	48 99                	cqto
    95bf:	48 89 d1             	mov    %rdx,%rcx
    95c2:	48 89 c2             	mov    %rax,%rdx
    95c5:	e8 f6 4f 00 00       	call   e5c0 <__divmodti4>
    95ca:	44 8b 0c 24          	mov    (%rsp),%r9d
    95ce:	48 89 c1             	mov    %rax,%rcx
    95d1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    95d6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    95db:	0f 84 94 00 00 00    	je     9675 <fwp_write+0xfb5>
    95e1:	41 83 c1 01          	add    $0x1,%r9d
    95e5:	48 83 c5 10          	add    $0x10,%rbp
    95e9:	41 83 f9 05          	cmp    $0x5,%r9d
    95ed:	75 bb                	jne    95aa <fwp_write+0xeea>
    95ef:	4d 85 ed             	test   %r13,%r13
    95f2:	79 53                	jns    9647 <fwp_write+0xf87>
    95f4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    95f9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    95fe:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9603:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9608:	48 99                	cqto
    960a:	48 f7 d8             	neg    %rax
    960d:	48 83 d2 00          	adc    $0x0,%rdx
    9611:	48 89 c6             	mov    %rax,%rsi
    9614:	48 f7 da             	neg    %rdx
    9617:	e8 24 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    961c:	49 89 e8             	mov    %rbp,%r8
    961f:	ba 00 02 00 00       	mov    $0x200,%edx
    9624:	be 02 00 00 00       	mov    $0x2,%esi
    9629:	31 c0                	xor    %eax,%eax
    962b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9632:	00 
    9633:	48 8d 0d 36 5c 00 00 	lea    0x5c36(%rip),%rcx        # f270 <_IO_stdin_used+0x270>
    963a:	4c 89 e7             	mov    %r12,%rdi
    963d:	e8 7e a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    9642:	e9 f9 f0 ff ff       	jmp    8740 <fwp_write+0x80>
    9647:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    964c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9651:	31 d2                	xor    %edx,%edx
    9653:	48 89 ef             	mov    %rbp,%rdi
    9656:	e8 e5 a3 ff ff       	call   3a40 <fwp_fmt_u128>
    965b:	eb bf                	jmp    961c <fwp_write+0xf5c>
    965d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9664:	4e 61 4e 00 
    9668:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    966f:	00 
    9670:	e9 cb f0 ff ff       	jmp    8740 <fwp_write+0x80>
    9675:	44 89 0c 24          	mov    %r9d,(%rsp)
    9679:	48 89 c8             	mov    %rcx,%rax
    967c:	48 85 d2             	test   %rdx,%rdx
    967f:	78 51                	js     96d2 <fwp_write+0x1012>
    9681:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9686:	48 89 c6             	mov    %rax,%rsi
    9689:	48 89 ef             	mov    %rbp,%rdi
    968c:	e8 af a3 ff ff       	call   3a40 <fwp_fmt_u128>
    9691:	44 8b 0c 24          	mov    (%rsp),%r9d
    9695:	49 63 c1             	movslq %r9d,%rax
    9698:	49 89 e8             	mov    %rbp,%r8
    969b:	ba 00 02 00 00       	mov    $0x200,%edx
    96a0:	be 02 00 00 00       	mov    $0x2,%esi
    96a5:	48 c1 e0 04          	shl    $0x4,%rax
    96a9:	48 8d 3d 10 7c 00 00 	lea    0x7c10(%rip),%rdi        # 112c0 <units.0>
    96b0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    96b7:	00 
    96b8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    96bc:	48 8d 0d a8 5b 00 00 	lea    0x5ba8(%rip),%rcx        # f26b <_IO_stdin_used+0x26b>
    96c3:	4c 89 e7             	mov    %r12,%rdi
    96c6:	31 c0                	xor    %eax,%eax
    96c8:	e8 f3 9f ff ff       	call   36c0 <__sprintf_chk@plt>
    96cd:	e9 6e f0 ff ff       	jmp    8740 <fwp_write+0x80>
    96d2:	48 f7 d8             	neg    %rax
    96d5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    96da:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    96df:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    96e4:	48 83 d2 00          	adc    $0x0,%rdx
    96e8:	48 89 c6             	mov    %rax,%rsi
    96eb:	48 f7 da             	neg    %rdx
    96ee:	e8 4d a3 ff ff       	call   3a40 <fwp_fmt_u128>
    96f3:	44 8b 0c 24          	mov    (%rsp),%r9d
    96f7:	eb 9c                	jmp    9695 <fwp_write+0xfd5>
    96f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009700 <fwp_hof0.constprop.0>:
    9700:	41 57                	push   %r15
    9702:	41 56                	push   %r14
    9704:	41 55                	push   %r13
    9706:	41 54                	push   %r12
    9708:	55                   	push   %rbp
    9709:	53                   	push   %rbx
    970a:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9711:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    9716:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    971d:	00 00 
    971f:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    9726:	00 
    9727:	31 c0                	xor    %eax,%eax
    9729:	48 85 f6             	test   %rsi,%rsi
    972c:	0f 84 65 0f 00 00    	je     a697 <fwp_hof0.constprop.0+0xf97>
    9732:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
    9737:	48 8d 2d e2 20 06 00 	lea    0x620e2(%rip),%rbp        # 6b820 <fwp_heap>
    973e:	66 90                	xchg   %ax,%ax
    9740:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9747:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    974c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9753:	48 c1 e2 10          	shl    $0x10,%rdx
    9757:	48 39 d0             	cmp    %rdx,%rax
    975a:	73 71                	jae    97cd <fwp_hof0.constprop.0+0xcd>
    975c:	48 89 c2             	mov    %rax,%rdx
    975f:	48 c1 ea 10          	shr    $0x10,%rdx
    9763:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9767:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    976e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9772:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9776:	48 85 ff             	test   %rdi,%rdi
    9779:	74 52                	je     97cd <fwp_hof0.constprop.0+0xcd>
    977b:	0f b6 0a             	movzbl (%rdx),%ecx
    977e:	80 f9 02             	cmp    $0x2,%cl
    9781:	0f 84 81 15 00 00    	je     ad08 <fwp_hof0.constprop.0+0x1608>
    9787:	80 f9 01             	cmp    $0x1,%cl
    978a:	75 41                	jne    97cd <fwp_hof0.constprop.0+0xcd>
    978c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    978f:	0f b7 c0             	movzwl %ax,%eax
    9792:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9795:	48 0f af c1          	imul   %rcx,%rax
    9799:	48 c1 e8 20          	shr    $0x20,%rax
    979d:	48 39 d0             	cmp    %rdx,%rax
    97a0:	73 2b                	jae    97cd <fwp_hof0.constprop.0+0xcd>
    97a2:	48 01 c7             	add    %rax,%rdi
    97a5:	0f b6 07             	movzbl (%rdi),%eax
    97a8:	84 c0                	test   %al,%al
    97aa:	74 21                	je     97cd <fwp_hof0.constprop.0+0xcd>
    97ac:	44 8b 0d 35 3d 06 00 	mov    0x63d35(%rip),%r9d        # 6d4e8 <iteration_active>
    97b3:	45 85 c9             	test   %r9d,%r9d
    97b6:	74 08                	je     97c0 <fwp_hof0.constprop.0+0xc0>
    97b8:	48 83 05 10 3d 06 00 	addq   $0x1,0x63d10(%rip)        # 6d4d0 <iteration_retains>
    97bf:	01 
    97c0:	3c fd                	cmp    $0xfd,%al
    97c2:	0f 87 0e 17 00 00    	ja     aed6 <fwp_hof0.constprop.0+0x17d6>
    97c8:	83 c0 01             	add    $0x1,%eax
    97cb:	88 07                	mov    %al,(%rdi)
    97cd:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    97d2:	45 31 c9             	xor    %r9d,%r9d
    97d5:	48 c7 44 24 28 c6 00 	movq   $0xc6,0x28(%rsp)
    97dc:	00 00 
    97de:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    97e3:	4c 89 cb             	mov    %r9,%rbx
    97e6:	4d 85 c9             	test   %r9,%r9
    97e9:	0f 85 61 9f ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    97ef:	48 8b 05 c2 3c 06 00 	mov    0x63cc2(%rip),%rax        # 6d4b8 <fwp_cleanups>
    97f6:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    97fd:	4c 8d 2d 3c d8 ff ff 	lea    -0x27c4(%rip),%r13        # 7040 <fwp_tape_scope_release>
    9804:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    980b:	ff 
    980c:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    9813:	00 
    9814:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    981b:	00 
    981c:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    9821:	48 c1 e2 10          	shl    $0x10,%rdx
    9825:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    982a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    9831:	00 
    9832:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9839:	00 
    983a:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    983f:	48 89 05 72 3c 06 00 	mov    %rax,0x63c72(%rip)        # 6d4b8 <fwp_cleanups>
    9846:	48 8d 05 c3 97 00 00 	lea    0x97c3(%rip),%rax        # 13010 <fc37>
    984d:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9854:	48 39 d0             	cmp    %rdx,%rax
    9857:	73 71                	jae    98ca <fwp_hof0.constprop.0+0x1ca>
    9859:	48 89 c2             	mov    %rax,%rdx
    985c:	48 c1 ea 10          	shr    $0x10,%rdx
    9860:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9864:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    986b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    986f:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9873:	48 85 ff             	test   %rdi,%rdi
    9876:	74 52                	je     98ca <fwp_hof0.constprop.0+0x1ca>
    9878:	0f b6 0a             	movzbl (%rdx),%ecx
    987b:	80 f9 02             	cmp    $0x2,%cl
    987e:	0f 84 7c 12 00 00    	je     ab00 <fwp_hof0.constprop.0+0x1400>
    9884:	80 f9 01             	cmp    $0x1,%cl
    9887:	75 41                	jne    98ca <fwp_hof0.constprop.0+0x1ca>
    9889:	8b 4a 18             	mov    0x18(%rdx),%ecx
    988c:	0f b7 c0             	movzwl %ax,%eax
    988f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9892:	48 0f af c1          	imul   %rcx,%rax
    9896:	48 c1 e8 20          	shr    $0x20,%rax
    989a:	48 39 d0             	cmp    %rdx,%rax
    989d:	73 2b                	jae    98ca <fwp_hof0.constprop.0+0x1ca>
    989f:	48 01 c7             	add    %rax,%rdi
    98a2:	0f b6 07             	movzbl (%rdi),%eax
    98a5:	84 c0                	test   %al,%al
    98a7:	74 21                	je     98ca <fwp_hof0.constprop.0+0x1ca>
    98a9:	44 8b 05 38 3c 06 00 	mov    0x63c38(%rip),%r8d        # 6d4e8 <iteration_active>
    98b0:	45 85 c0             	test   %r8d,%r8d
    98b3:	74 08                	je     98bd <fwp_hof0.constprop.0+0x1bd>
    98b5:	48 83 05 13 3c 06 00 	addq   $0x1,0x63c13(%rip)        # 6d4d0 <iteration_retains>
    98bc:	01 
    98bd:	3c fd                	cmp    $0xfd,%al
    98bf:	0f 87 b7 15 00 00    	ja     ae7c <fwp_hof0.constprop.0+0x177c>
    98c5:	83 c0 01             	add    $0x1,%eax
    98c8:	88 07                	mov    %al,(%rdi)
    98ca:	48 8d 3d 3f 97 00 00 	lea    0x973f(%rip),%rdi        # 13010 <fc37>
    98d1:	e8 ea d3 ff ff       	call   6cc0 <fwp_closure_drop>
    98d6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    98db:	48 85 c0             	test   %rax,%rax
    98de:	0f 84 a7 14 00 00    	je     ad8b <fwp_hof0.constprop.0+0x168b>
    98e4:	31 d2                	xor    %edx,%edx
    98e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    98ed:	00 00 00 
    98f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    98f4:	48 83 c2 01          	add    $0x1,%rdx
    98f8:	48 85 c0             	test   %rax,%rax
    98fb:	75 f3                	jne    98f0 <fwp_hof0.constprop.0+0x1f0>
    98fd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    9904:	0f 87 95 16 00 00    	ja     af9f <fwp_hof0.constprop.0+0x189f>
    990a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    990f:	8b 35 4b 97 00 00    	mov    0x974b(%rip),%esi        # 13060 <registered_finish.1>
    9915:	85 f6                	test   %esi,%esi
    9917:	0f 84 a3 11 00 00    	je     aac0 <fwp_hof0.constprop.0+0x13c0>
    991d:	4c 8b 35 b4 97 01 00 	mov    0x197b4(%rip),%r14        # 230d8 <fwp_tape_next_slot>
    9924:	4c 8b 25 bd 97 01 00 	mov    0x197bd(%rip),%r12        # 230e8 <fwp_ntapes>
    992b:	4d 39 f4             	cmp    %r14,%r12
    992e:	0f 8e 3c 0e 00 00    	jle    a770 <fwp_hof0.constprop.0+0x1070>
    9934:	49 6b c6 68          	imul   $0x68,%r14,%rax
    9938:	48 03 05 b1 97 01 00 	add    0x197b1(%rip),%rax        # 230f0 <fwp_tapes>
    993f:	90                   	nop
    9940:	8b 48 04             	mov    0x4(%rax),%ecx
    9943:	85 c9                	test   %ecx,%ecx
    9945:	75 0c                	jne    9953 <fwp_hof0.constprop.0+0x253>
    9947:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    994d:	0f 86 1d 0e 00 00    	jbe    a770 <fwp_hof0.constprop.0+0x1070>
    9953:	49 83 c6 01          	add    $0x1,%r14
    9957:	48 83 c0 68          	add    $0x68,%rax
    995b:	4d 39 f4             	cmp    %r14,%r12
    995e:	75 e0                	jne    9940 <fwp_hof0.constprop.0+0x240>
    9960:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    9967:	0f 8f 4a 16 00 00    	jg     afb7 <fwp_hof0.constprop.0+0x18b7>
    996d:	4c 3b 25 6c 97 01 00 	cmp    0x1976c(%rip),%r12        # 230e0 <fwp_tapes_cap>
    9974:	4c 8b 3d 75 97 01 00 	mov    0x19775(%rip),%r15        # 230f0 <fwp_tapes>
    997b:	75 4d                	jne    99ca <fwp_hof0.constprop.0+0x2ca>
    997d:	4d 85 e4             	test   %r12,%r12
    9980:	0f 84 6b 14 00 00    	je     adf1 <fwp_hof0.constprop.0+0x16f1>
    9986:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    998a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    998f:	49 39 c6             	cmp    %rax,%r14
    9992:	4c 0f 4f f0          	cmovg  %rax,%r14
    9996:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    999a:	31 d2                	xor    %edx,%edx
    999c:	4c 89 ff             	mov    %r15,%rdi
    999f:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    99a5:	e8 e6 b7 ff ff       	call   5190 <ad_raw_realloc>
    99aa:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    99b0:	48 85 c0             	test   %rax,%rax
    99b3:	49 89 c7             	mov    %rax,%r15
    99b6:	0f 84 50 16 00 00    	je     b00c <fwp_hof0.constprop.0+0x190c>
    99bc:	48 89 05 2d 97 01 00 	mov    %rax,0x1972d(%rip)        # 230f0 <fwp_tapes>
    99c3:	4c 89 35 16 97 01 00 	mov    %r14,0x19716(%rip)        # 230e0 <fwp_tapes_cap>
    99ca:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    99ce:	31 c0                	xor    %eax,%eax
    99d0:	4d 89 e6             	mov    %r12,%r14
    99d3:	4c 01 f9             	add    %r15,%rcx
    99d6:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    99da:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    99e1:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    99e5:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    99ec:	00 
    99ed:	48 29 f9             	sub    %rdi,%rcx
    99f0:	83 c1 68             	add    $0x68,%ecx
    99f3:	c1 e9 03             	shr    $0x3,%ecx
    99f6:	f3 48 ab             	rep stos %rax,(%rdi)
    99f9:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    99fe:	48 89 05 e3 96 01 00 	mov    %rax,0x196e3(%rip)        # 230e8 <fwp_ntapes>
    9a05:	4d 6b e6 68          	imul   $0x68,%r14,%r12
    9a09:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9a0d:	48 8d 3d 4c 57 00 00 	lea    0x574c(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    9a14:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9a19:	4d 01 fc             	add    %r15,%r12
    9a1c:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    9a23:	00 00 
    9a25:	e8 66 99 ff ff       	call   3390 <getenv@plt>
    9a2a:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    9a30:	48 85 c0             	test   %rax,%rax
    9a33:	0f 84 4f 0d 00 00    	je     a788 <fwp_hof0.constprop.0+0x1088>
    9a39:	80 38 30             	cmpb   $0x30,(%rax)
    9a3c:	0f 85 46 0d 00 00    	jne    a788 <fwp_hof0.constprop.0+0x1088>
    9a42:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9a46:	0f 85 3c 0d 00 00    	jne    a788 <fwp_hof0.constprop.0+0x1088>
    9a4c:	41 8b 04 24          	mov    (%r12),%eax
    9a50:	49 8d 76 01          	lea    0x1(%r14),%rsi
    9a54:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    9a5b:	00 00 
    9a5d:	48 89 35 74 96 01 00 	mov    %rsi,0x19674(%rip)        # 230d8 <fwp_tape_next_slot>
    9a64:	8d 48 01             	lea    0x1(%rax),%ecx
    9a67:	48 8b 05 f2 62 00 00 	mov    0x62f2(%rip),%rax        # fd60 <msg.4+0x20>
    9a6e:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    9a75:	00 00 
    9a77:	41 89 0c 24          	mov    %ecx,(%r12)
    9a7b:	49 89 44 24 58       	mov    %rax,0x58(%r12)
    9a80:	48 8b 05 31 3a 06 00 	mov    0x63a31(%rip),%rax        # 6d4b8 <fwp_cleanups>
    9a87:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    9a8d:	48 85 c0             	test   %rax,%rax
    9a90:	75 1a                	jne    9aac <fwp_hof0.constprop.0+0x3ac>
    9a92:	e9 69 15 00 00       	jmp    b000 <fwp_hof0.constprop.0+0x1900>
    9a97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a9e:	00 00 
    9aa0:	48 8b 00             	mov    (%rax),%rax
    9aa3:	48 85 c0             	test   %rax,%rax
    9aa6:	0f 84 54 15 00 00    	je     b000 <fwp_hof0.constprop.0+0x1900>
    9aac:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    9ab0:	75 ee                	jne    9aa0 <fwp_hof0.constprop.0+0x3a0>
    9ab2:	4c 8b 40 10          	mov    0x10(%rax),%r8
    9ab6:	44 89 f7             	mov    %r14d,%edi
    9ab9:	49 63 00             	movslq (%r8),%rax
    9abc:	4d 89 44 24 50       	mov    %r8,0x50(%r12)
    9ac1:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    9ac6:	85 c0                	test   %eax,%eax
    9ac8:	78 09                	js     9ad3 <fwp_hof0.constprop.0+0x3d3>
    9aca:	48 6b c0 68          	imul   $0x68,%rax,%rax
    9ace:	45 89 74 07 58       	mov    %r14d,0x58(%r15,%rax,1)
    9ad3:	41 89 38             	mov    %edi,(%r8)
    9ad6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9adb:	45 31 ed             	xor    %r13d,%r13d
    9ade:	48 89 f8             	mov    %rdi,%rax
    9ae1:	48 85 ff             	test   %rdi,%rdi
    9ae4:	0f 84 e6 0d 00 00    	je     a8d0 <fwp_hof0.constprop.0+0x11d0>
    9aea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9af0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9af4:	49 83 c5 01          	add    $0x1,%r13
    9af8:	48 85 c0             	test   %rax,%rax
    9afb:	75 f3                	jne    9af0 <fwp_hof0.constprop.0+0x3f0>
    9afd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9b02:	0f 1f 00             	nopl   (%rax)
    9b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b0c:	00 00 00 00 
    9b10:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9b14:	48 83 c0 01          	add    $0x1,%rax
    9b18:	48 85 d2             	test   %rdx,%rdx
    9b1b:	75 f3                	jne    9b10 <fwp_hof0.constprop.0+0x410>
    9b1d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9b24:	ff ff 1f 
    9b27:	48 39 c2             	cmp    %rax,%rdx
    9b2a:	0f 82 63 14 00 00    	jb     af93 <fwp_hof0.constprop.0+0x1893>
    9b30:	4d 85 ed             	test   %r13,%r13
    9b33:	0f 8e 97 0d 00 00    	jle    a8d0 <fwp_hof0.constprop.0+0x11d0>
    9b39:	49 39 c5             	cmp    %rax,%r13
    9b3c:	4c 0f 47 e8          	cmova  %rax,%r13
    9b40:	4c 89 e8             	mov    %r13,%rax
    9b43:	48 c1 e8 3c          	shr    $0x3c,%rax
    9b47:	0f 85 46 14 00 00    	jne    af93 <fwp_hof0.constprop.0+0x1893>
    9b4d:	4f 8d 7c 2d 00       	lea    0x0(%r13,%r13,1),%r15
    9b52:	48 c1 e1 10          	shl    $0x10,%rcx
    9b56:	48 09 f1             	or     %rsi,%rcx
    9b59:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    9b60:	00 
    9b61:	be 02 00 00 00       	mov    $0x2,%esi
    9b66:	49 89 cc             	mov    %rcx,%r12
    9b69:	e8 a2 c3 ff ff       	call   5f10 <fwp_heap_alloc>
    9b6e:	4c 89 38             	mov    %r15,(%rax)
    9b71:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9b78:	49 89 c6             	mov    %rax,%r14
    9b7b:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9b82:	48 c1 e2 10          	shl    $0x10,%rdx
    9b86:	48 39 d0             	cmp    %rdx,%rax
    9b89:	0f 83 f1 0d 00 00    	jae    a980 <fwp_hof0.constprop.0+0x1280>
    9b8f:	48 89 c2             	mov    %rax,%rdx
    9b92:	48 c1 ea 10          	shr    $0x10,%rdx
    9b96:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    9b9a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9ba1:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    9ba5:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9ba9:	4d 85 ff             	test   %r15,%r15
    9bac:	74 3a                	je     9be8 <fwp_hof0.constprop.0+0x4e8>
    9bae:	0f b6 32             	movzbl (%rdx),%esi
    9bb1:	40 80 fe 02          	cmp    $0x2,%sil
    9bb5:	0f 84 86 0d 00 00    	je     a941 <fwp_hof0.constprop.0+0x1241>
    9bbb:	40 80 fe 01          	cmp    $0x1,%sil
    9bbf:	75 27                	jne    9be8 <fwp_hof0.constprop.0+0x4e8>
    9bc1:	8b 72 18             	mov    0x18(%rdx),%esi
    9bc4:	0f b7 c0             	movzwl %ax,%eax
    9bc7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bca:	48 0f af c6          	imul   %rsi,%rax
    9bce:	48 c1 e8 20          	shr    $0x20,%rax
    9bd2:	48 39 d0             	cmp    %rdx,%rax
    9bd5:	73 11                	jae    9be8 <fwp_hof0.constprop.0+0x4e8>
    9bd7:	49 01 c7             	add    %rax,%r15
    9bda:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9bde:	0f 84 70 0d 00 00    	je     a954 <fwp_hof0.constprop.0+0x1254>
    9be4:	41 c6 07 01          	movb   $0x1,(%r15)
    9be8:	4d 85 ed             	test   %r13,%r13
    9beb:	74 47                	je     9c34 <fwp_hof0.constprop.0+0x534>
    9bed:	4c 89 e6             	mov    %r12,%rsi
    9bf0:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9bf5:	31 c0                	xor    %eax,%eax
    9bf7:	48 c1 e6 20          	shl    $0x20,%rsi
    9bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c00:	48 89 c1             	mov    %rax,%rcx
    9c03:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9c08:	48 01 f1             	add    %rsi,%rcx
    9c0b:	0f 80 3f 9b ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9c11:	66 48 0f 6e e1       	movq   %rcx,%xmm4
    9c16:	48 89 c1             	mov    %rax,%rcx
    9c19:	48 83 c0 01          	add    $0x1,%rax
    9c1d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9c21:	48 c1 e1 04          	shl    $0x4,%rcx
    9c25:	41 0f 11 44 0e 08    	movups %xmm0,0x8(%r14,%rcx,1)
    9c2b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9c2f:	4c 39 e8             	cmp    %r13,%rax
    9c32:	72 cc                	jb     9c00 <fwp_hof0.constprop.0+0x500>
    9c34:	49 8b 06             	mov    (%r14),%rax
    9c37:	48 d1 e8             	shr    $1,%rax
    9c3a:	0f 84 50 0d 00 00    	je     a990 <fwp_hof0.constprop.0+0x1290>
    9c40:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9c44:	48 89 f7             	mov    %rsi,%rdi
    9c47:	48 c1 ef 3c          	shr    $0x3c,%rdi
    9c4b:	0f 85 42 13 00 00    	jne    af93 <fwp_hof0.constprop.0+0x1893>
    9c51:	48 8d 14 36          	lea    (%rsi,%rsi,1),%rdx
    9c55:	48 85 f6             	test   %rsi,%rsi
    9c58:	74 49                	je     9ca3 <fwp_hof0.constprop.0+0x5a3>
    9c5a:	48 c1 e0 04          	shl    $0x4,%rax
    9c5e:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    9c63:	49 89 d7             	mov    %rdx,%r15
    9c66:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    9c6a:	4d 8d 6c 06 f8       	lea    -0x8(%r14,%rax,1),%r13
    9c6f:	90                   	nop
    9c70:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    9c74:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    9c78:	48 83 c3 10          	add    $0x10,%rbx
    9c7c:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    9c80:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    9c84:	e8 e7 c9 ff ff       	call   6670 <w120>
    9c89:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9c8e:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9c92:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    9c96:	49 39 dd             	cmp    %rbx,%r13
    9c99:	75 d5                	jne    9c70 <fwp_hof0.constprop.0+0x570>
    9c9b:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    9ca0:	4c 89 fa             	mov    %r15,%rdx
    9ca3:	49 89 16             	mov    %rdx,(%r14)
    9ca6:	4c 89 f7             	mov    %r14,%rdi
    9ca9:	4d 63 fc             	movslq %r12d,%r15
    9cac:	e8 2f cb ff ff       	call   67e0 <w176.constprop.0>
    9cb1:	4c 89 f7             	mov    %r14,%rdi
    9cb4:	49 89 c5             	mov    %rax,%r13
    9cb7:	e8 d4 e2 ff ff       	call   7f90 <fwp_drop10>
    9cbc:	4c 89 ff             	mov    %r15,%rdi
    9cbf:	e8 6c aa ff ff       	call   4730 <fwp_tape_of>
    9cc4:	48 89 c6             	mov    %rax,%rsi
    9cc7:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9ccc:	0f 85 af 13 00 00    	jne    b081 <fwp_hof0.constprop.0+0x1981>
    9cd2:	48 89 c7             	mov    %rax,%rdi
    9cd5:	e8 b6 9f ff ff       	call   3c90 <fwp_tape_unlink_scope>
    9cda:	4c 8b 46 48          	mov    0x48(%rsi),%r8
    9cde:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9ce3:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9cea:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    9cee:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    9cf2:	66 49 0f 6e f8       	movq   %r8,%xmm7
    9cf7:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    9cfc:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    9d01:	4c 8b 56 40          	mov    0x40(%rsi),%r10
    9d05:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    9d09:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    9d0f:	77 19                	ja     9d2a <fwp_hof0.constprop.0+0x62a>
    9d11:	41 0f b7 c4          	movzwl %r12w,%eax
    9d15:	83 e8 01             	sub    $0x1,%eax
    9d18:	48 98                	cltq
    9d1a:	48 3b 05 b7 93 01 00 	cmp    0x193b7(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    9d21:	7d 07                	jge    9d2a <fwp_hof0.constprop.0+0x62a>
    9d23:	48 89 05 ae 93 01 00 	mov    %rax,0x193ae(%rip)        # 230d8 <fwp_tape_next_slot>
    9d2a:	48 8b 05 87 37 06 00 	mov    0x63787(%rip),%rax        # 6d4b8 <fwp_cleanups>
    9d31:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9d35:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9d3c:	00 
    9d3d:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9d41:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9d48:	00 
    9d49:	48 8d 05 10 b5 ff ff 	lea    -0x4af0(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    9d50:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9d57:	00 
    9d58:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    9d5f:	00 
    9d60:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9d65:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9d6c:	00 
    9d6d:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    9d74:	00 
    9d75:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9d7c:	00 
    9d7d:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9d84:	00 
    9d85:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9d89:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9d8d:	48 89 05 24 37 06 00 	mov    %rax,0x63724(%rip)        # 6d4b8 <fwp_cleanups>
    9d94:	4c 89 94 24 e0 00 00 	mov    %r10,0xe0(%rsp)
    9d9b:	00 
    9d9c:	0f 29 9c 24 c0 00 00 	movaps %xmm3,0xc0(%rsp)
    9da3:	00 
    9da4:	0f 29 94 24 d0 00 00 	movaps %xmm2,0xd0(%rsp)
    9dab:	00 
    9dac:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    9db3:	00 
    9db4:	4d 85 ed             	test   %r13,%r13
    9db7:	0f 88 53 0d 00 00    	js     ab10 <fwp_hof0.constprop.0+0x1410>
    9dbd:	4c 89 e8             	mov    %r13,%rax
    9dc0:	48 c1 f8 20          	sar    $0x20,%rax
    9dc4:	49 39 c7             	cmp    %rax,%r15
    9dc7:	0f 85 9b 11 00 00    	jne    af68 <fwp_hof0.constprop.0+0x1868>
    9dcd:	44 89 e9             	mov    %r13d,%ecx
    9dd0:	49 89 cf             	mov    %rcx,%r15
    9dd3:	48 39 ca             	cmp    %rcx,%rdx
    9dd6:	0f 8e 98 11 00 00    	jle    af74 <fwp_hof0.constprop.0+0x1874>
    9ddc:	49 39 ce             	cmp    %rcx,%r14
    9ddf:	0f 8e d3 0b 00 00    	jle    a9b8 <fwp_hof0.constprop.0+0x12b8>
    9de5:	4d 39 c6             	cmp    %r8,%r14
    9de8:	0f 8f 02 0c 00 00    	jg     a9f0 <fwp_hof0.constprop.0+0x12f0>
    9dee:	4d 85 d2             	test   %r10,%r10
    9df1:	0f 84 43 12 00 00    	je     b03a <fwp_hof0.constprop.0+0x193a>
    9df7:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
    9dfc:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    9e00:	31 f6                	xor    %esi,%esi
    9e02:	4c 89 d7             	mov    %r10,%rdi
    9e05:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    9e0a:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9e11:	00 
    9e12:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    9e17:	e8 94 96 ff ff       	call   34b0 <memset@plt>
    9e1c:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    9e22:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    9e28:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
    9e2d:	49 89 c2             	mov    %rax,%r10
    9e30:	f2 0f 10 05 30 5f 00 	movsd  0x5f30(%rip),%xmm0        # fd68 <msg.4+0x28>
    9e37:	00 
    9e38:	f2 41 0f 58 04 ca    	addsd  (%r10,%rcx,8),%xmm0
    9e3e:	f2 41 0f 11 04 ca    	movsd  %xmm0,(%r10,%rcx,8)
    9e44:	4d 39 fe             	cmp    %r15,%r14
    9e47:	0f 8f 8c 00 00 00    	jg     9ed9 <fwp_hof0.constprop.0+0x7d9>
    9e4d:	0f 12 fb             	movhlps %xmm3,%xmm7
    9e50:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    9e55:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    9e5a:	4d 29 f7             	sub    %r14,%r15
    9e5d:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    9e62:	0f 12 fa             	movhlps %xmm2,%xmm7
    9e65:	4f 8d 24 f2          	lea    (%r10,%r14,8),%r12
    9e69:	66 49 0f 7e f8       	movq   %xmm7,%r8
    9e6e:	4a 8d 04 be          	lea    (%rsi,%r15,4),%rax
    9e72:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9e76:	48 29 f1             	sub    %rsi,%rcx
    9e79:	4b 8d 14 f8          	lea    (%r8,%r15,8),%rdx
    9e7d:	4d 29 c4             	sub    %r8,%r12
    9e80:	4c 29 c7             	sub    %r8,%rdi
    9e83:	eb 07                	jmp    9e8c <fwp_hof0.constprop.0+0x78c>
    9e85:	0f 1f 00             	nopl   (%rax)
    9e88:	48 83 e8 04          	sub    $0x4,%rax
    9e8c:	f2 41 0f 10 04 14    	movsd  (%r12,%rdx,1),%xmm0
    9e92:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9e96:	7a 02                	jp     9e9a <fwp_hof0.constprop.0+0x79a>
    9e98:	74 36                	je     9ed0 <fwp_hof0.constprop.0+0x7d0>
    9e9a:	4c 63 04 01          	movslq (%rcx,%rax,1),%r8
    9e9e:	45 85 c0             	test   %r8d,%r8d
    9ea1:	78 15                	js     9eb8 <fwp_hof0.constprop.0+0x7b8>
    9ea3:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    9ea8:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9eac:	f2 43 0f 58 0c c2    	addsd  (%r10,%r8,8),%xmm1
    9eb2:	f2 43 0f 11 0c c2    	movsd  %xmm1,(%r10,%r8,8)
    9eb8:	4c 63 00             	movslq (%rax),%r8
    9ebb:	45 85 c0             	test   %r8d,%r8d
    9ebe:	78 10                	js     9ed0 <fwp_hof0.constprop.0+0x7d0>
    9ec0:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9ec4:	f2 43 0f 58 04 c2    	addsd  (%r10,%r8,8),%xmm0
    9eca:	f2 43 0f 11 04 c2    	movsd  %xmm0,(%r10,%r8,8)
    9ed0:	48 83 ea 08          	sub    $0x8,%rdx
    9ed4:	48 39 c6             	cmp    %rax,%rsi
    9ed7:	75 af                	jne    9e88 <fwp_hof0.constprop.0+0x788>
    9ed9:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9ee0:	ff ff 1f 
    9ee3:	4c 39 f0             	cmp    %r14,%rax
    9ee6:	0f 82 bf 10 00 00    	jb     afab <fwp_hof0.constprop.0+0x18ab>
    9eec:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9ef3:	00 
    9ef4:	be 02 00 00 00       	mov    $0x2,%esi
    9ef9:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    9efe:	e8 0d c0 ff ff       	call   5f10 <fwp_heap_alloc>
    9f03:	4d 85 f6             	test   %r14,%r14
    9f06:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    9f0b:	4c 89 30             	mov    %r14,(%rax)
    9f0e:	49 89 c7             	mov    %rax,%r15
    9f11:	74 1f                	je     9f32 <fwp_hof0.constprop.0+0x832>
    9f13:	66 90                	xchg   %ax,%ax
    9f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f1c:	00 00 00 00 
    9f20:	49 8b 04 da          	mov    (%r10,%rbx,8),%rax
    9f24:	49 89 44 df 08       	mov    %rax,0x8(%r15,%rbx,8)
    9f29:	48 83 c3 01          	add    $0x1,%rbx
    9f2d:	49 39 de             	cmp    %rbx,%r14
    9f30:	75 ee                	jne    9f20 <fwp_hof0.constprop.0+0x820>
    9f32:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
    9f39:	00 
    9f3a:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    9f3f:	4c 89 2d 72 35 06 00 	mov    %r13,0x63572(%rip)        # 6d4b8 <fwp_cleanups>
    9f46:	e8 15 b3 ff ff       	call   5260 <fwp_tape_buffers_release>
    9f4b:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9f52:	4c 89 f8             	mov    %r15,%rax
    9f55:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9f5c:	48 c1 e2 10          	shl    $0x10,%rdx
    9f60:	48 39 d0             	cmp    %rdx,%rax
    9f63:	73 59                	jae    9fbe <fwp_hof0.constprop.0+0x8be>
    9f65:	48 89 c2             	mov    %rax,%rdx
    9f68:	48 c1 ea 10          	shr    $0x10,%rdx
    9f6c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f70:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9f77:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f7b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9f7f:	4d 85 e4             	test   %r12,%r12
    9f82:	74 3a                	je     9fbe <fwp_hof0.constprop.0+0x8be>
    9f84:	0f b6 0a             	movzbl (%rdx),%ecx
    9f87:	80 f9 02             	cmp    $0x2,%cl
    9f8a:	0f 84 b0 0b 00 00    	je     ab40 <fwp_hof0.constprop.0+0x1440>
    9f90:	80 f9 01             	cmp    $0x1,%cl
    9f93:	75 29                	jne    9fbe <fwp_hof0.constprop.0+0x8be>
    9f95:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f98:	0f b7 c0             	movzwl %ax,%eax
    9f9b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f9e:	48 0f af c1          	imul   %rcx,%rax
    9fa2:	48 c1 e8 20          	shr    $0x20,%rax
    9fa6:	48 39 d0             	cmp    %rdx,%rax
    9fa9:	73 13                	jae    9fbe <fwp_hof0.constprop.0+0x8be>
    9fab:	49 01 c4             	add    %rax,%r12
    9fae:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9fb3:	0f 84 9b 0b 00 00    	je     ab54 <fwp_hof0.constprop.0+0x1454>
    9fb9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9fbe:	4c 3b 6c 24 38       	cmp    0x38(%rsp),%r13
    9fc3:	0f 85 82 97 ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9fc9:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9fd0:	00 
    9fd1:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9fd6:	48 89 05 db 34 06 00 	mov    %rax,0x634db(%rip)        # 6d4b8 <fwp_cleanups>
    9fdd:	e8 5e d0 ff ff       	call   7040 <fwp_tape_scope_release>
    9fe2:	49 8b 07             	mov    (%r15),%rax
    9fe5:	49 89 c6             	mov    %rax,%r14
    9fe8:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9fed:	48 85 c0             	test   %rax,%rax
    9ff0:	0f 88 2a 08 00 00    	js     a820 <fwp_hof0.constprop.0+0x1120>
    9ff6:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9ffd:	4c 89 f8             	mov    %r15,%rax
    a000:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a007:	48 c1 e2 10          	shl    $0x10,%rdx
    a00b:	48 39 d0             	cmp    %rdx,%rax
    a00e:	0f 83 0c 08 00 00    	jae    a820 <fwp_hof0.constprop.0+0x1120>
    a014:	48 89 c2             	mov    %rax,%rdx
    a017:	48 c1 ea 10          	shr    $0x10,%rdx
    a01b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a01f:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a026:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a02a:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a02e:	48 85 c9             	test   %rcx,%rcx
    a031:	0f 84 e9 07 00 00    	je     a820 <fwp_hof0.constprop.0+0x1120>
    a037:	0f b6 32             	movzbl (%rdx),%esi
    a03a:	40 80 fe 02          	cmp    $0x2,%sil
    a03e:	0f 84 cc 07 00 00    	je     a810 <fwp_hof0.constprop.0+0x1110>
    a044:	40 80 fe 01          	cmp    $0x1,%sil
    a048:	0f 85 d2 07 00 00    	jne    a820 <fwp_hof0.constprop.0+0x1120>
    a04e:	8b 72 18             	mov    0x18(%rdx),%esi
    a051:	0f b7 c0             	movzwl %ax,%eax
    a054:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a057:	48 0f af c6          	imul   %rsi,%rax
    a05b:	48 c1 e8 20          	shr    $0x20,%rax
    a05f:	48 39 d0             	cmp    %rdx,%rax
    a062:	0f 83 b8 07 00 00    	jae    a820 <fwp_hof0.constprop.0+0x1120>
    a068:	48 01 c1             	add    %rax,%rcx
    a06b:	80 39 01             	cmpb   $0x1,(%rcx)
    a06e:	0f 85 ac 07 00 00    	jne    a820 <fwp_hof0.constprop.0+0x1120>
    a074:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    a079:	4d 89 fc             	mov    %r15,%r12
    a07c:	31 ff                	xor    %edi,%edi
    a07e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a083:	48 8d 50 08          	lea    0x8(%rax),%rdx
    a087:	31 c0                	xor    %eax,%eax
    a089:	4d 85 f6             	test   %r14,%r14
    a08c:	75 2c                	jne    a0ba <fwp_hof0.constprop.0+0x9ba>
    a08e:	eb 40                	jmp    a0d0 <fwp_hof0.constprop.0+0x9d0>
    a090:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a095:	0f 88 e5 0e 00 00    	js     af80 <fwp_hof0.constprop.0+0x1880>
    a09b:	f2 0f 10 05 dd 5c 00 	movsd  0x5cdd(%rip),%xmm0        # fd80 <msg.4+0x40>
    a0a2:	00 
    a0a3:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    a0a8:	48 83 c0 01          	add    $0x1,%rax
    a0ac:	48 83 c2 08          	add    $0x8,%rdx
    a0b0:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    a0b5:	49 39 c6             	cmp    %rax,%r14
    a0b8:	74 16                	je     a0d0 <fwp_hof0.constprop.0+0x9d0>
    a0ba:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    a0be:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a0c2:	79 cc                	jns    a090 <fwp_hof0.constprop.0+0x990>
    a0c4:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    a0c8:	eb c6                	jmp    a090 <fwp_hof0.constprop.0+0x990>
    a0ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a0d0:	e8 bb de ff ff       	call   7f90 <fwp_drop10>
    a0d5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a0da:	31 d2                	xor    %edx,%edx
    a0dc:	48 89 f8             	mov    %rdi,%rax
    a0df:	48 85 ff             	test   %rdi,%rdi
    a0e2:	0f 84 ac 0c 00 00    	je     ad94 <fwp_hof0.constprop.0+0x1694>
    a0e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a0ef:	00 
    a0f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a0f4:	48 83 c2 01          	add    $0x1,%rdx
    a0f8:	48 85 c0             	test   %rax,%rax
    a0fb:	75 f3                	jne    a0f0 <fwp_hof0.constprop.0+0x9f0>
    a0fd:	49 8b 04 24          	mov    (%r12),%rax
    a101:	49 89 c7             	mov    %rax,%r15
    a104:	49 0f ba f7 3f       	btr    $0x3f,%r15
    a109:	48 85 c0             	test   %rax,%rax
    a10c:	0f 88 cb 05 00 00    	js     a6dd <fwp_hof0.constprop.0+0xfdd>
    a112:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    a119:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a11e:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    a125:	48 c1 e0 10          	shl    $0x10,%rax
    a129:	48 39 c1             	cmp    %rax,%rcx
    a12c:	0f 83 ab 05 00 00    	jae    a6dd <fwp_hof0.constprop.0+0xfdd>
    a132:	48 89 c8             	mov    %rcx,%rax
    a135:	48 c1 e8 10          	shr    $0x10,%rax
    a139:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    a13d:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    a144:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    a148:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a14c:	48 85 ff             	test   %rdi,%rdi
    a14f:	0f 84 88 05 00 00    	je     a6dd <fwp_hof0.constprop.0+0xfdd>
    a155:	0f b6 06             	movzbl (%rsi),%eax
    a158:	3c 02                	cmp    $0x2,%al
    a15a:	0f 84 68 05 00 00    	je     a6c8 <fwp_hof0.constprop.0+0xfc8>
    a160:	3c 01                	cmp    $0x1,%al
    a162:	0f 85 69 05 00 00    	jne    a6d1 <fwp_hof0.constprop.0+0xfd1>
    a168:	8b 46 18             	mov    0x18(%rsi),%eax
    a16b:	0f b7 c9             	movzwl %cx,%ecx
    a16e:	48 0f af c8          	imul   %rax,%rcx
    a172:	8b 46 1c             	mov    0x1c(%rsi),%eax
    a175:	48 c1 e9 20          	shr    $0x20,%rcx
    a179:	48 39 c1             	cmp    %rax,%rcx
    a17c:	0f 83 4f 05 00 00    	jae    a6d1 <fwp_hof0.constprop.0+0xfd1>
    a182:	48 01 cf             	add    %rcx,%rdi
    a185:	80 3f 01             	cmpb   $0x1,(%rdi)
    a188:	0f 85 43 05 00 00    	jne    a6d1 <fwp_hof0.constprop.0+0xfd1>
    a18e:	49 39 d7             	cmp    %rdx,%r15
    a191:	48 89 d0             	mov    %rdx,%rax
    a194:	49 0f 46 c7          	cmovbe %r15,%rax
    a198:	48 85 c0             	test   %rax,%rax
    a19b:	0f 84 eb 0d 00 00    	je     af8c <fwp_hof0.constprop.0+0x188c>
    a1a1:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
    a1a8:	00 
    a1a9:	49 8d 5c 24 08       	lea    0x8(%r12),%rbx
    a1ae:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a1b3:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a1b8:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    a1bf:	00 
    a1c0:	31 d2                	xor    %edx,%edx
    a1c2:	49 8d 78 08          	lea    0x8(%r8),%rdi
    a1c6:	eb 54                	jmp    a21c <fwp_hof0.constprop.0+0xb1c>
    a1c8:	90                   	nop
    a1c9:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1d0:	00 00 00 00 
    a1d4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1db:	00 00 00 00 
    a1df:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1e6:	00 00 00 00 
    a1ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1f1:	00 00 00 00 
    a1f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1fc:	00 00 00 00 
    a200:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a205:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a20a:	f2 0f 11 04 13       	movsd  %xmm0,(%rbx,%rdx,1)
    a20f:	48 83 c2 08          	add    $0x8,%rdx
    a213:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a217:	49 39 d1             	cmp    %rdx,%r9
    a21a:	74 14                	je     a230 <fwp_hof0.constprop.0+0xb30>
    a21c:	48 89 fe             	mov    %rdi,%rsi
    a21f:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a224:	79 da                	jns    a200 <fwp_hof0.constprop.0+0xb00>
    a226:	49 8b 70 10          	mov    0x10(%r8),%rsi
    a22a:	eb d4                	jmp    a200 <fwp_hof0.constprop.0+0xb00>
    a22c:	0f 1f 40 00          	nopl   0x0(%rax)
    a230:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a235:	48 85 c9             	test   %rcx,%rcx
    a238:	0f 84 22 0d 00 00    	je     af60 <fwp_hof0.constprop.0+0x1860>
    a23e:	4c 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%r9
    a245:	4c 8b 95 b0 13 00 00 	mov    0x13b0(%rbp),%r10
    a24c:	45 31 ff             	xor    %r15d,%r15d
    a24f:	4c 8b 9d f8 13 00 00 	mov    0x13f8(%rbp),%r11
    a256:	49 c1 e1 10          	shl    $0x10,%r9
    a25a:	eb 1a                	jmp    a276 <fwp_hof0.constprop.0+0xb76>
    a25c:	0f 1f 40 00          	nopl   0x0(%rax)
    a260:	49 83 c7 01          	add    $0x1,%r15
    a264:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a268:	49 39 c7             	cmp    %rax,%r15
    a26b:	0f 83 5f 01 00 00    	jae    a3d0 <fwp_hof0.constprop.0+0xcd0>
    a271:	48 85 c9             	test   %rcx,%rcx
    a274:	74 56                	je     a2cc <fwp_hof0.constprop.0+0xbcc>
    a276:	48 89 ca             	mov    %rcx,%rdx
    a279:	4c 29 d2             	sub    %r10,%rdx
    a27c:	4c 39 ca             	cmp    %r9,%rdx
    a27f:	73 4b                	jae    a2cc <fwp_hof0.constprop.0+0xbcc>
    a281:	48 89 d6             	mov    %rdx,%rsi
    a284:	48 c1 ee 10          	shr    $0x10,%rsi
    a288:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a28c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a290:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a294:	48 85 ff             	test   %rdi,%rdi
    a297:	74 33                	je     a2cc <fwp_hof0.constprop.0+0xbcc>
    a299:	44 0f b6 06          	movzbl (%rsi),%r8d
    a29d:	41 80 f8 02          	cmp    $0x2,%r8b
    a2a1:	0f 84 11 01 00 00    	je     a3b8 <fwp_hof0.constprop.0+0xcb8>
    a2a7:	41 80 f8 01          	cmp    $0x1,%r8b
    a2ab:	75 1f                	jne    a2cc <fwp_hof0.constprop.0+0xbcc>
    a2ad:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a2b1:	0f b7 d2             	movzwl %dx,%edx
    a2b4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a2b7:	49 0f af d0          	imul   %r8,%rdx
    a2bb:	48 c1 ea 20          	shr    $0x20,%rdx
    a2bf:	48 39 f2             	cmp    %rsi,%rdx
    a2c2:	73 08                	jae    a2cc <fwp_hof0.constprop.0+0xbcc>
    a2c4:	48 01 d7             	add    %rdx,%rdi
    a2c7:	80 3f 01             	cmpb   $0x1,(%rdi)
    a2ca:	74 94                	je     a260 <fwp_hof0.constprop.0+0xb60>
    a2cc:	49 39 c7             	cmp    %rax,%r15
    a2cf:	0f 83 fb 00 00 00    	jae    a3d0 <fwp_hof0.constprop.0+0xcd0>
    a2d5:	49 89 c5             	mov    %rax,%r13
    a2d8:	45 31 f6             	xor    %r14d,%r14d
    a2db:	eb 37                	jmp    a314 <fwp_hof0.constprop.0+0xc14>
    a2dd:	0f 1f 00             	nopl   (%rax)
    a2e0:	40 80 fe 01          	cmp    $0x1,%sil
    a2e4:	75 25                	jne    a30b <fwp_hof0.constprop.0+0xc0b>
    a2e6:	8b 71 18             	mov    0x18(%rcx),%esi
    a2e9:	0f b7 c0             	movzwl %ax,%eax
    a2ec:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a2ef:	48 0f af c6          	imul   %rsi,%rax
    a2f3:	48 c1 e8 20          	shr    $0x20,%rax
    a2f7:	48 39 c8             	cmp    %rcx,%rax
    a2fa:	73 0f                	jae    a30b <fwp_hof0.constprop.0+0xc0b>
    a2fc:	48 01 c2             	add    %rax,%rdx
    a2ff:	80 3a ff             	cmpb   $0xff,(%rdx)
    a302:	0f 84 60 06 00 00    	je     a968 <fwp_hof0.constprop.0+0x1268>
    a308:	c6 02 01             	movb   $0x1,(%rdx)
    a30b:	4d 39 ef             	cmp    %r13,%r15
    a30e:	0f 83 8c 00 00 00    	jae    a3a0 <fwp_hof0.constprop.0+0xca0>
    a314:	49 83 ed 01          	sub    $0x1,%r13
    a318:	66 49 0f 6e f6       	movq   %r14,%xmm6
    a31d:	bf 01 00 00 00       	mov    $0x1,%edi
    a322:	f3 42 0f 7e 04 eb    	movq   (%rbx,%r13,8),%xmm0
    a328:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    a32f:	00 
    a330:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a334:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    a33b:	00 
    a33c:	e8 bf bd ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a341:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a348:	49 89 c6             	mov    %rax,%r14
    a34b:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a352:	48 c1 e2 10          	shl    $0x10,%rdx
    a356:	48 39 d0             	cmp    %rdx,%rax
    a359:	73 b0                	jae    a30b <fwp_hof0.constprop.0+0xc0b>
    a35b:	48 89 c2             	mov    %rax,%rdx
    a35e:	48 c1 ea 10          	shr    $0x10,%rdx
    a362:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a366:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a36d:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a371:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a375:	48 85 d2             	test   %rdx,%rdx
    a378:	74 91                	je     a30b <fwp_hof0.constprop.0+0xc0b>
    a37a:	0f b6 31             	movzbl (%rcx),%esi
    a37d:	40 80 fe 02          	cmp    $0x2,%sil
    a381:	0f 85 59 ff ff ff    	jne    a2e0 <fwp_hof0.constprop.0+0xbe0>
    a387:	66 85 c0             	test   %ax,%ax
    a38a:	0f 84 6f ff ff ff    	je     a2ff <fwp_hof0.constprop.0+0xbff>
    a390:	4d 39 ef             	cmp    %r13,%r15
    a393:	0f 82 7b ff ff ff    	jb     a314 <fwp_hof0.constprop.0+0xc14>
    a399:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3a0:	4d 85 ff             	test   %r15,%r15
    a3a3:	75 2e                	jne    a3d3 <fwp_hof0.constprop.0+0xcd3>
    a3a5:	8b 44 24 30          	mov    0x30(%rsp),%eax
    a3a9:	85 c0                	test   %eax,%eax
    a3ab:	49 0f 45 df          	cmovne %r15,%rbx
    a3af:	eb 62                	jmp    a413 <fwp_hof0.constprop.0+0xd13>
    a3b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3b8:	66 85 d2             	test   %dx,%dx
    a3bb:	0f 84 06 ff ff ff    	je     a2c7 <fwp_hof0.constprop.0+0xbc7>
    a3c1:	49 39 c7             	cmp    %rax,%r15
    a3c4:	0f 82 0b ff ff ff    	jb     a2d5 <fwp_hof0.constprop.0+0xbd5>
    a3ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3d0:	45 31 f6             	xor    %r14d,%r14d
    a3d3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a3d8:	48 89 da             	mov    %rbx,%rdx
    a3db:	4e 8d 0c fb          	lea    (%rbx,%r15,8),%r9
    a3df:	90                   	nop
    a3e0:	48 8b 0a             	mov    (%rdx),%rcx
    a3e3:	48 83 c2 08          	add    $0x8,%rdx
    a3e7:	48 89 c7             	mov    %rax,%rdi
    a3ea:	48 89 48 08          	mov    %rcx,0x8(%rax)
    a3ee:	48 8b 40 10          	mov    0x10(%rax),%rax
    a3f2:	49 39 d1             	cmp    %rdx,%r9
    a3f5:	75 e9                	jne    a3e0 <fwp_hof0.constprop.0+0xce0>
    a3f7:	8b 54 24 30          	mov    0x30(%rsp),%edx
    a3fb:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    a3ff:	85 d2                	test   %edx,%edx
    a401:	0f 84 61 07 00 00    	je     ab68 <fwp_hof0.constprop.0+0x1468>
    a407:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    a40c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a411:	31 db                	xor    %ebx,%ebx
    a413:	48 89 df             	mov    %rbx,%rdi
    a416:	e8 f5 b5 ff ff       	call   5a10 <fwp_mem_free>
    a41b:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a420:	e8 6b db ff ff       	call   7f90 <fwp_drop10>
    a425:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a42c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a431:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a438:	48 c1 e2 10          	shl    $0x10,%rdx
    a43c:	48 39 d0             	cmp    %rdx,%rax
    a43f:	73 6f                	jae    a4b0 <fwp_hof0.constprop.0+0xdb0>
    a441:	48 89 c2             	mov    %rax,%rdx
    a444:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a44b:	48 c1 ea 10          	shr    $0x10,%rdx
    a44f:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a453:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a457:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a45b:	4d 85 e4             	test   %r12,%r12
    a45e:	74 50                	je     a4b0 <fwp_hof0.constprop.0+0xdb0>
    a460:	0f b6 0a             	movzbl (%rdx),%ecx
    a463:	80 f9 02             	cmp    $0x2,%cl
    a466:	0f 84 84 06 00 00    	je     aaf0 <fwp_hof0.constprop.0+0x13f0>
    a46c:	80 f9 01             	cmp    $0x1,%cl
    a46f:	75 3f                	jne    a4b0 <fwp_hof0.constprop.0+0xdb0>
    a471:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a474:	0f b7 c0             	movzwl %ax,%eax
    a477:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a47a:	48 0f af c1          	imul   %rcx,%rax
    a47e:	48 c1 e8 20          	shr    $0x20,%rax
    a482:	48 39 d0             	cmp    %rdx,%rax
    a485:	73 29                	jae    a4b0 <fwp_hof0.constprop.0+0xdb0>
    a487:	49 01 c4             	add    %rax,%r12
    a48a:	41 0f b6 04 24       	movzbl (%r12),%eax
    a48f:	84 c0                	test   %al,%al
    a491:	74 1d                	je     a4b0 <fwp_hof0.constprop.0+0xdb0>
    a493:	3c 01                	cmp    $0x1,%al
    a495:	0f 84 e5 06 00 00    	je     ab80 <fwp_hof0.constprop.0+0x1480>
    a49b:	3c ff                	cmp    $0xff,%al
    a49d:	0f 84 6c 09 00 00    	je     ae0f <fwp_hof0.constprop.0+0x170f>
    a4a3:	83 e8 01             	sub    $0x1,%eax
    a4a6:	41 88 04 24          	mov    %al,(%r12)
    a4aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4b0:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    a4b6:	0f 85 dc 05 00 00    	jne    aa98 <fwp_hof0.constprop.0+0x1398>
    a4bc:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a4c1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a4c5:	4c 89 f6             	mov    %r14,%rsi
    a4c8:	4d 89 f4             	mov    %r14,%r12
    a4cb:	b9 01 00 00 00       	mov    $0x1,%ecx
    a4d0:	48 8d 15 c9 86 00 00 	lea    0x86c9(%rip),%rdx        # 12ba0 <d0>
    a4d7:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a4de:	00 00 00 00 00 
    a4e3:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    a4ea:	00 
    a4eb:	e8 d0 e1 ff ff       	call   86c0 <fwp_write>
    a4f0:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
    a4f7:	00 
    a4f8:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
    a4ff:	00 
    a500:	48 8d 05 65 4b 00 00 	lea    0x4b65(%rip),%rax        # f06c <_IO_stdin_used+0x6c>
    a507:	4d 85 f6             	test   %r14,%r14
    a50a:	4c 0f 44 f0          	cmove  %rax,%r14
    a50e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a512:	0f 87 d9 0a 00 00    	ja     aff1 <fwp_hof0.constprop.0+0x18f1>
    a518:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a51c:	be 01 00 00 00       	mov    $0x1,%esi
    a521:	e8 ea b9 ff ff       	call   5f10 <fwp_heap_alloc>
    a526:	4c 89 fa             	mov    %r15,%rdx
    a529:	4c 89 f6             	mov    %r14,%rsi
    a52c:	4c 89 38             	mov    %r15,(%rax)
    a52f:	48 89 c3             	mov    %rax,%rbx
    a532:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a536:	4c 8d 68 08          	lea    0x8(%rax),%r13
    a53a:	e8 41 90 ff ff       	call   3580 <memcpy@plt>
    a53f:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a545:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    a54c:	00 
    a54d:	e8 5e 8e ff ff       	call   33b0 <free@plt>
    a552:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a559:	48 89 d8             	mov    %rbx,%rax
    a55c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a563:	48 c1 e2 10          	shl    $0x10,%rdx
    a567:	48 39 d0             	cmp    %rdx,%rax
    a56a:	73 57                	jae    a5c3 <fwp_hof0.constprop.0+0xec3>
    a56c:	48 89 c2             	mov    %rax,%rdx
    a56f:	48 c1 ea 10          	shr    $0x10,%rdx
    a573:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a577:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a57e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a582:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a586:	4d 85 ff             	test   %r15,%r15
    a589:	74 38                	je     a5c3 <fwp_hof0.constprop.0+0xec3>
    a58b:	0f b6 0a             	movzbl (%rdx),%ecx
    a58e:	80 f9 02             	cmp    $0x2,%cl
    a591:	0f 84 a1 07 00 00    	je     ad38 <fwp_hof0.constprop.0+0x1638>
    a597:	80 f9 01             	cmp    $0x1,%cl
    a59a:	75 27                	jne    a5c3 <fwp_hof0.constprop.0+0xec3>
    a59c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a59f:	0f b7 c0             	movzwl %ax,%eax
    a5a2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a5a5:	48 0f af c1          	imul   %rcx,%rax
    a5a9:	48 c1 e8 20          	shr    $0x20,%rax
    a5ad:	48 39 d0             	cmp    %rdx,%rax
    a5b0:	73 11                	jae    a5c3 <fwp_hof0.constprop.0+0xec3>
    a5b2:	49 01 c7             	add    %rax,%r15
    a5b5:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a5b9:	0f 84 8c 07 00 00    	je     ad4b <fwp_hof0.constprop.0+0x164b>
    a5bf:	41 c6 07 01          	movb   $0x1,(%r15)
    a5c3:	4c 89 e7             	mov    %r12,%rdi
    a5c6:	e8 d5 d5 ff ff       	call   7ba0 <fwp_drop0>
    a5cb:	48 8b 13             	mov    (%rbx),%rdx
    a5ce:	be 01 00 00 00       	mov    $0x1,%esi
    a5d3:	4c 89 ef             	mov    %r13,%rdi
    a5d6:	48 8b 0d a3 2e 06 00 	mov    0x62ea3(%rip),%rcx        # 6d480 <fwp_prog_out>
    a5dd:	e8 7e 90 ff ff       	call   3660 <fwrite@plt>
    a5e2:	48 8b 35 97 2e 06 00 	mov    0x62e97(%rip),%rsi        # 6d480 <fwp_prog_out>
    a5e9:	bf 0a 00 00 00       	mov    $0xa,%edi
    a5ee:	e8 dd 8e ff ff       	call   34d0 <fputc@plt>
    a5f3:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a5fa:	48 89 d8             	mov    %rbx,%rax
    a5fd:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a604:	48 c1 e2 10          	shl    $0x10,%rdx
    a608:	48 39 d0             	cmp    %rdx,%rax
    a60b:	73 73                	jae    a680 <fwp_hof0.constprop.0+0xf80>
    a60d:	48 89 c2             	mov    %rax,%rdx
    a610:	48 c1 ea 10          	shr    $0x10,%rdx
    a614:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a618:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a61f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a623:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a627:	4d 85 e4             	test   %r12,%r12
    a62a:	74 54                	je     a680 <fwp_hof0.constprop.0+0xf80>
    a62c:	0f b6 0a             	movzbl (%rdx),%ecx
    a62f:	80 f9 02             	cmp    $0x2,%cl
    a632:	0f 84 28 07 00 00    	je     ad60 <fwp_hof0.constprop.0+0x1660>
    a638:	80 f9 01             	cmp    $0x1,%cl
    a63b:	75 43                	jne    a680 <fwp_hof0.constprop.0+0xf80>
    a63d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a640:	0f b7 c0             	movzwl %ax,%eax
    a643:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a646:	48 0f af c1          	imul   %rcx,%rax
    a64a:	48 c1 e8 20          	shr    $0x20,%rax
    a64e:	48 39 d0             	cmp    %rdx,%rax
    a651:	73 2d                	jae    a680 <fwp_hof0.constprop.0+0xf80>
    a653:	49 01 c4             	add    %rax,%r12
    a656:	41 0f b6 04 24       	movzbl (%r12),%eax
    a65b:	84 c0                	test   %al,%al
    a65d:	74 21                	je     a680 <fwp_hof0.constprop.0+0xf80>
    a65f:	3c 01                	cmp    $0x1,%al
    a661:	0f 84 17 07 00 00    	je     ad7e <fwp_hof0.constprop.0+0x167e>
    a667:	3c ff                	cmp    $0xff,%al
    a669:	0f 84 71 08 00 00    	je     aee0 <fwp_hof0.constprop.0+0x17e0>
    a66f:	83 e8 01             	sub    $0x1,%eax
    a672:	41 88 04 24          	mov    %al,(%r12)
    a676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a67d:	00 00 00 
    a680:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a685:	48 8b 40 10          	mov    0x10(%rax),%rax
    a689:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a68e:	48 85 c0             	test   %rax,%rax
    a691:	0f 85 a9 f0 ff ff    	jne    9740 <fwp_hof0.constprop.0+0x40>
    a697:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    a69e:	00 
    a69f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a6a6:	00 00 
    a6a8:	0f 85 eb 09 00 00    	jne    b099 <fwp_hof0.constprop.0+0x1999>
    a6ae:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    a6b5:	31 c0                	xor    %eax,%eax
    a6b7:	5b                   	pop    %rbx
    a6b8:	5d                   	pop    %rbp
    a6b9:	41 5c                	pop    %r12
    a6bb:	41 5d                	pop    %r13
    a6bd:	41 5e                	pop    %r14
    a6bf:	41 5f                	pop    %r15
    a6c1:	c3                   	ret
    a6c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6c8:	66 85 c9             	test   %cx,%cx
    a6cb:	0f 84 b4 fa ff ff    	je     a185 <fwp_hof0.constprop.0+0xa85>
    a6d1:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    a6d7:	0f 84 ba 02 00 00    	je     a997 <fwp_hof0.constprop.0+0x1297>
    a6dd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a6e2:	45 31 f6             	xor    %r14d,%r14d
    a6e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a6ec:	00 00 00 00 
    a6f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a6f4:	4c 89 f2             	mov    %r14,%rdx
    a6f7:	49 83 c6 01          	add    $0x1,%r14
    a6fb:	48 85 c0             	test   %rax,%rax
    a6fe:	75 f0                	jne    a6f0 <fwp_hof0.constprop.0+0xff0>
    a700:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a707:	ff ff 1f 
    a70a:	4c 39 f0             	cmp    %r14,%rax
    a70d:	0f 82 80 08 00 00    	jb     af93 <fwp_hof0.constprop.0+0x1893>
    a713:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a71a:	00 
    a71b:	be 02 00 00 00       	mov    $0x2,%esi
    a720:	e8 eb b7 ff ff       	call   5f10 <fwp_heap_alloc>
    a725:	4d 39 f7             	cmp    %r14,%r15
    a728:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a72d:	48 89 c3             	mov    %rax,%rbx
    a730:	4c 89 f0             	mov    %r14,%rax
    a733:	49 0f 46 c7          	cmovbe %r15,%rax
    a737:	48 89 d9             	mov    %rbx,%rcx
    a73a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a740:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a744:	48 83 c1 08          	add    $0x8,%rcx
    a748:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a74c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a750:	48 85 d2             	test   %rdx,%rdx
    a753:	75 eb                	jne    a740 <fwp_hof0.constprop.0+0x1040>
    a755:	48 85 c0             	test   %rax,%rax
    a758:	0f 84 4b 02 00 00    	je     a9a9 <fwp_hof0.constprop.0+0x12a9>
    a75e:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    a765:	00 
    a766:	e9 43 fa ff ff       	jmp    a1ae <fwp_hof0.constprop.0+0xaae>
    a76b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a770:	4d 39 f4             	cmp    %r14,%r12
    a773:	0f 84 e7 f1 ff ff    	je     9960 <fwp_hof0.constprop.0+0x260>
    a779:	4c 8b 3d 70 89 01 00 	mov    0x18970(%rip),%r15        # 230f0 <fwp_tapes>
    a780:	e9 80 f2 ff ff       	jmp    9a05 <fwp_hof0.constprop.0+0x305>
    a785:	0f 1f 00             	nopl   (%rax)
    a788:	48 83 3d f8 88 01 00 	cmpq   $0x0,0x188f8(%rip)        # 23088 <fwp_tape_cached_bytes>
    a78f:	00 
    a790:	0f 84 b6 f2 ff ff    	je     9a4c <fwp_hof0.constprop.0+0x34c>
    a796:	66 0f 6f 0d 02 89 01 	movdqa 0x18902(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a79d:	00 
    a79e:	48 c7 05 df 88 01 00 	movq   $0x0,0x188df(%rip)        # 23088 <fwp_tape_cached_bytes>
    a7a5:	00 00 00 00 
    a7a9:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    a7af:	48 8b 05 0a 89 01 00 	mov    0x1890a(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a7b6:	66 0f 6f 0d f2 88 01 	movdqa 0x188f2(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    a7bd:	00 
    a7be:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    a7c3:	48 8b 05 fe 88 01 00 	mov    0x188fe(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    a7ca:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    a7d0:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a7d4:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    a7d9:	48 8b 05 f0 88 01 00 	mov    0x188f0(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    a7e0:	0f 29 0d b9 88 01 00 	movaps %xmm1,0x188b9(%rip)        # 230a0 <fwp_tape_workspace>
    a7e7:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    a7ec:	0f 29 0d bd 88 01 00 	movaps %xmm1,0x188bd(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a7f3:	48 c7 05 d2 88 01 00 	movq   $0x0,0x188d2(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    a7fa:	00 00 00 00 
    a7fe:	0f 29 0d bb 88 01 00 	movaps %xmm1,0x188bb(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a805:	e9 42 f2 ff ff       	jmp    9a4c <fwp_hof0.constprop.0+0x34c>
    a80a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a810:	66 85 c0             	test   %ax,%ax
    a813:	0f 84 52 f8 ff ff    	je     a06b <fwp_hof0.constprop.0+0x96b>
    a819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a820:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a827:	ff ff 1f 
    a82a:	4c 39 f0             	cmp    %r14,%rax
    a82d:	0f 82 78 07 00 00    	jb     afab <fwp_hof0.constprop.0+0x18ab>
    a833:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a83a:	00 
    a83b:	be 01 00 00 00       	mov    $0x1,%esi
    a840:	e8 cb b6 ff ff       	call   5f10 <fwp_heap_alloc>
    a845:	4c 89 30             	mov    %r14,(%rax)
    a848:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a84f:	49 89 c4             	mov    %rax,%r12
    a852:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a857:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a85e:	48 c1 e2 10          	shl    $0x10,%rdx
    a862:	48 39 d0             	cmp    %rdx,%rax
    a865:	73 57                	jae    a8be <fwp_hof0.constprop.0+0x11be>
    a867:	48 89 c2             	mov    %rax,%rdx
    a86a:	48 c1 ea 10          	shr    $0x10,%rdx
    a86e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a872:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a879:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a87d:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    a881:	48 85 db             	test   %rbx,%rbx
    a884:	74 38                	je     a8be <fwp_hof0.constprop.0+0x11be>
    a886:	0f b6 31             	movzbl (%rcx),%esi
    a889:	40 80 fe 02          	cmp    $0x2,%sil
    a88d:	0f 84 95 03 00 00    	je     ac28 <fwp_hof0.constprop.0+0x1528>
    a893:	40 80 fe 01          	cmp    $0x1,%sil
    a897:	75 25                	jne    a8be <fwp_hof0.constprop.0+0x11be>
    a899:	8b 71 18             	mov    0x18(%rcx),%esi
    a89c:	0f b7 c0             	movzwl %ax,%eax
    a89f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a8a2:	48 0f af c6          	imul   %rsi,%rax
    a8a6:	48 c1 e8 20          	shr    $0x20,%rax
    a8aa:	48 39 c8             	cmp    %rcx,%rax
    a8ad:	73 0f                	jae    a8be <fwp_hof0.constprop.0+0x11be>
    a8af:	48 01 c3             	add    %rax,%rbx
    a8b2:	80 3b ff             	cmpb   $0xff,(%rbx)
    a8b5:	0f 84 7f 03 00 00    	je     ac3a <fwp_hof0.constprop.0+0x153a>
    a8bb:	c6 03 01             	movb   $0x1,(%rbx)
    a8be:	4c 89 ff             	mov    %r15,%rdi
    a8c1:	e9 b8 f7 ff ff       	jmp    a07e <fwp_hof0.constprop.0+0x97e>
    a8c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8cd:	00 00 00 
    a8d0:	48 c1 e1 10          	shl    $0x10,%rcx
    a8d4:	bf 08 00 00 00       	mov    $0x8,%edi
    a8d9:	48 09 f1             	or     %rsi,%rcx
    a8dc:	be 02 00 00 00       	mov    $0x2,%esi
    a8e1:	49 89 cc             	mov    %rcx,%r12
    a8e4:	e8 27 b6 ff ff       	call   5f10 <fwp_heap_alloc>
    a8e9:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a8f0:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a8f7:	49 89 c6             	mov    %rax,%r14
    a8fa:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a901:	48 c1 e2 10          	shl    $0x10,%rdx
    a905:	48 39 d0             	cmp    %rdx,%rax
    a908:	0f 83 82 00 00 00    	jae    a990 <fwp_hof0.constprop.0+0x1290>
    a90e:	48 89 c2             	mov    %rax,%rdx
    a911:	48 c1 ea 10          	shr    $0x10,%rdx
    a915:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a919:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a920:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a924:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a928:	4d 85 ff             	test   %r15,%r15
    a92b:	0f 84 03 f3 ff ff    	je     9c34 <fwp_hof0.constprop.0+0x534>
    a931:	0f b6 32             	movzbl (%rdx),%esi
    a934:	45 31 ed             	xor    %r13d,%r13d
    a937:	40 80 fe 02          	cmp    $0x2,%sil
    a93b:	0f 85 7a f2 ff ff    	jne    9bbb <fwp_hof0.constprop.0+0x4bb>
    a941:	66 85 c0             	test   %ax,%ax
    a944:	0f 85 9e f2 ff ff    	jne    9be8 <fwp_hof0.constprop.0+0x4e8>
    a94a:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a94e:	0f 85 90 f2 ff ff    	jne    9be4 <fwp_hof0.constprop.0+0x4e4>
    a954:	4c 89 ff             	mov    %r15,%rdi
    a957:	e8 74 ae ff ff       	call   57d0 <fwp_rc_forget_slot>
    a95c:	e9 83 f2 ff ff       	jmp    9be4 <fwp_hof0.constprop.0+0x4e4>
    a961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a968:	48 89 d7             	mov    %rdx,%rdi
    a96b:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    a970:	e8 5b ae ff ff       	call   57d0 <fwp_rc_forget_slot>
    a975:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    a97a:	e9 89 f9 ff ff       	jmp    a308 <fwp_hof0.constprop.0+0xc08>
    a97f:	90                   	nop
    a980:	4d 85 ed             	test   %r13,%r13
    a983:	0f 85 64 f2 ff ff    	jne    9bed <fwp_hof0.constprop.0+0x4ed>
    a989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a990:	31 d2                	xor    %edx,%edx
    a992:	e9 0c f3 ff ff       	jmp    9ca3 <fwp_hof0.constprop.0+0x5a3>
    a997:	be 02 00 00 00       	mov    $0x2,%esi
    a99c:	bf 08 00 00 00       	mov    $0x8,%edi
    a9a1:	e8 6a b5 ff ff       	call   5f10 <fwp_heap_alloc>
    a9a6:	48 89 c3             	mov    %rax,%rbx
    a9a9:	45 31 f6             	xor    %r14d,%r14d
    a9ac:	e9 62 fa ff ff       	jmp    a413 <fwp_hof0.constprop.0+0xd13>
    a9b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9b8:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    a9bc:	4d 39 e0             	cmp    %r12,%r8
    a9bf:	7c 32                	jl     a9f3 <fwp_hof0.constprop.0+0x12f3>
    a9c1:	4d 85 d2             	test   %r10,%r10
    a9c4:	0f 84 70 06 00 00    	je     b03a <fwp_hof0.constprop.0+0x193a>
    a9ca:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
    a9cf:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    a9d6:	00 
    a9d7:	31 f6                	xor    %esi,%esi
    a9d9:	4c 89 d7             	mov    %r10,%rdi
    a9dc:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    a9e1:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a9e6:	e9 2c f4 ff ff       	jmp    9e17 <fwp_hof0.constprop.0+0x717>
    a9eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a9f0:	4d 89 f4             	mov    %r14,%r12
    a9f3:	4d 85 c0             	test   %r8,%r8
    a9f6:	4d 0f 44 c4          	cmove  %r12,%r8
    a9fa:	eb 19                	jmp    aa15 <fwp_hof0.constprop.0+0x1315>
    a9fc:	0f 1f 40 00          	nopl   0x0(%rax)
    aa00:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    aa04:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    aa0b:	4c 89 e0             	mov    %r12,%rax
    aa0e:	48 0f 4c c2          	cmovl  %rdx,%rax
    aa12:	49 89 c0             	mov    %rax,%r8
    aa15:	4d 39 e0             	cmp    %r12,%r8
    aa18:	7c e6                	jl     aa00 <fwp_hof0.constprop.0+0x1300>
    aa1a:	4d 85 d2             	test   %r10,%r10
    aa1d:	0f 84 2d 02 00 00    	je     ac50 <fwp_hof0.constprop.0+0x1550>
    aa23:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    aa2a:	00 
    aa2b:	4c 89 d7             	mov    %r10,%rdi
    aa2e:	ba 03 00 00 00       	mov    $0x3,%edx
    aa33:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    aa38:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    aa3d:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    aa42:	e8 49 a7 ff ff       	call   5190 <ad_raw_realloc>
    aa47:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    aa4c:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    aa52:	48 85 c0             	test   %rax,%rax
    aa55:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    aa5b:	49 89 c2             	mov    %rax,%r10
    aa5e:	0f 84 bc 02 00 00    	je     ad20 <fwp_hof0.constprop.0+0x1620>
    aa64:	4c 89 94 24 e0 00 00 	mov    %r10,0xe0(%rsp)
    aa6b:	00 
    aa6c:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    aa73:	00 
    aa74:	4d 85 e4             	test   %r12,%r12
    aa77:	0f 85 18 04 00 00    	jne    ae95 <fwp_hof0.constprop.0+0x1795>
    aa7d:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    aa84:	4d 85 ed             	test   %r13,%r13
    aa87:	0f 88 b7 f3 ff ff    	js     9e44 <fwp_hof0.constprop.0+0x744>
    aa8d:	44 89 e9             	mov    %r13d,%ecx
    aa90:	e9 9b f3 ff ff       	jmp    9e30 <fwp_hof0.constprop.0+0x730>
    aa95:	0f 1f 00             	nopl   (%rax)
    aa98:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    aa9d:	45 31 c9             	xor    %r9d,%r9d
    aaa0:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    aaa5:	48 83 e8 01          	sub    $0x1,%rax
    aaa9:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    aaae:	41 0f 90 c1          	seto   %r9b
    aab2:	e9 2c ed ff ff       	jmp    97e3 <fwp_hof0.constprop.0+0xe3>
    aab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    aabe:	00 00 
    aac0:	48 8d 3d 59 c4 ff ff 	lea    -0x3ba7(%rip),%rdi        # 6f20 <fwp_tape_finish>
    aac7:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    aacd:	e8 fe 3c 00 00       	call   e7d0 <atexit>
    aad2:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    aad8:	85 c0                	test   %eax,%eax
    aada:	0f 85 e3 04 00 00    	jne    afc3 <fwp_hof0.constprop.0+0x18c3>
    aae0:	c7 05 76 85 00 00 01 	movl   $0x1,0x8576(%rip)        # 13060 <registered_finish.1>
    aae7:	00 00 00 
    aaea:	e9 2e ee ff ff       	jmp    991d <fwp_hof0.constprop.0+0x21d>
    aaef:	90                   	nop
    aaf0:	66 85 c0             	test   %ax,%ax
    aaf3:	0f 85 b7 f9 ff ff    	jne    a4b0 <fwp_hof0.constprop.0+0xdb0>
    aaf9:	e9 8c f9 ff ff       	jmp    a48a <fwp_hof0.constprop.0+0xd8a>
    aafe:	66 90                	xchg   %ax,%ax
    ab00:	66 85 c0             	test   %ax,%ax
    ab03:	0f 85 c1 ed ff ff    	jne    98ca <fwp_hof0.constprop.0+0x1ca>
    ab09:	e9 94 ed ff ff       	jmp    98a2 <fwp_hof0.constprop.0+0x1a2>
    ab0e:	66 90                	xchg   %ax,%ax
    ab10:	4d 39 c6             	cmp    %r8,%r14
    ab13:	0f 8f d7 fe ff ff    	jg     a9f0 <fwp_hof0.constprop.0+0x12f0>
    ab19:	4d 85 f6             	test   %r14,%r14
    ab1c:	74 12                	je     ab30 <fwp_hof0.constprop.0+0x1430>
    ab1e:	4d 85 d2             	test   %r10,%r10
    ab21:	0f 84 13 05 00 00    	je     b03a <fwp_hof0.constprop.0+0x193a>
    ab27:	4d 85 f6             	test   %r14,%r14
    ab2a:	0f 85 62 03 00 00    	jne    ae92 <fwp_hof0.constprop.0+0x1792>
    ab30:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    ab37:	e9 08 f3 ff ff       	jmp    9e44 <fwp_hof0.constprop.0+0x744>
    ab3c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab40:	66 85 c0             	test   %ax,%ax
    ab43:	0f 85 75 f4 ff ff    	jne    9fbe <fwp_hof0.constprop.0+0x8be>
    ab49:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ab4e:	0f 85 65 f4 ff ff    	jne    9fb9 <fwp_hof0.constprop.0+0x8b9>
    ab54:	4c 89 e7             	mov    %r12,%rdi
    ab57:	e8 74 ac ff ff       	call   57d0 <fwp_rc_forget_slot>
    ab5c:	e9 58 f4 ff ff       	jmp    9fb9 <fwp_hof0.constprop.0+0x8b9>
    ab61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab68:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    ab6d:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ab72:	e9 9c f8 ff ff       	jmp    a413 <fwp_hof0.constprop.0+0xd13>
    ab77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ab7e:	00 00 
    ab80:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ab85:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ab8c:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ab93:	48 8b 58 10          	mov    0x10(%rax),%rbx
    ab97:	48 29 c8             	sub    %rcx,%rax
    ab9a:	48 c1 e2 10          	shl    $0x10,%rdx
    ab9e:	48 39 d0             	cmp    %rdx,%rax
    aba1:	73 67                	jae    ac0a <fwp_hof0.constprop.0+0x150a>
    aba3:	48 89 c7             	mov    %rax,%rdi
    aba6:	48 c1 ef 10          	shr    $0x10,%rdi
    abaa:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    abae:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    abb2:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    abb6:	48 85 ff             	test   %rdi,%rdi
    abb9:	74 4f                	je     ac0a <fwp_hof0.constprop.0+0x150a>
    abbb:	44 0f b6 06          	movzbl (%rsi),%r8d
    abbf:	41 80 f8 02          	cmp    $0x2,%r8b
    abc3:	0f 84 38 02 00 00    	je     ae01 <fwp_hof0.constprop.0+0x1701>
    abc9:	41 80 f8 01          	cmp    $0x1,%r8b
    abcd:	75 3b                	jne    ac0a <fwp_hof0.constprop.0+0x150a>
    abcf:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    abd3:	0f b7 c0             	movzwl %ax,%eax
    abd6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    abd9:	49 0f af c0          	imul   %r8,%rax
    abdd:	48 c1 e8 20          	shr    $0x20,%rax
    abe1:	48 39 f0             	cmp    %rsi,%rax
    abe4:	73 24                	jae    ac0a <fwp_hof0.constprop.0+0x150a>
    abe6:	48 01 c7             	add    %rax,%rdi
    abe9:	80 3f 01             	cmpb   $0x1,(%rdi)
    abec:	75 1c                	jne    ac0a <fwp_hof0.constprop.0+0x150a>
    abee:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    abf3:	e8 18 ae ff ff       	call   5a10 <fwp_mem_free>
    abf8:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    abff:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ac06:	48 c1 e2 10          	shl    $0x10,%rdx
    ac0a:	48 89 d8             	mov    %rbx,%rax
    ac0d:	48 29 c8             	sub    %rcx,%rax
    ac10:	48 39 d0             	cmp    %rdx,%rax
    ac13:	0f 83 97 f8 ff ff    	jae    a4b0 <fwp_hof0.constprop.0+0xdb0>
    ac19:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    ac1e:	e9 1e f8 ff ff       	jmp    a441 <fwp_hof0.constprop.0+0xd41>
    ac23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ac28:	66 85 c0             	test   %ax,%ax
    ac2b:	0f 85 8d fc ff ff    	jne    a8be <fwp_hof0.constprop.0+0x11be>
    ac31:	80 3b ff             	cmpb   $0xff,(%rbx)
    ac34:	0f 85 81 fc ff ff    	jne    a8bb <fwp_hof0.constprop.0+0x11bb>
    ac3a:	48 89 df             	mov    %rbx,%rdi
    ac3d:	e8 8e ab ff ff       	call   57d0 <fwp_rc_forget_slot>
    ac42:	e9 74 fc ff ff       	jmp    a8bb <fwp_hof0.constprop.0+0x11bb>
    ac47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac4e:	00 00 
    ac50:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    ac57:	ff ff 1f 
    ac5a:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    ac5e:	48 39 c2             	cmp    %rax,%rdx
    ac61:	0f 82 26 04 00 00    	jb     b08d <fwp_hof0.constprop.0+0x198d>
    ac67:	48 8d 05 52 85 04 00 	lea    0x48552(%rip),%rax        # 531c0 <ad_raw_blocks>
    ac6e:	45 31 ff             	xor    %r15d,%r15d
    ac71:	eb 22                	jmp    ac95 <fwp_hof0.constprop.0+0x1595>
    ac73:	66 90                	xchg   %ax,%ax
    ac75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac7c:	00 00 00 00 
    ac80:	49 83 c7 01          	add    $0x1,%r15
    ac84:	48 83 c0 18          	add    $0x18,%rax
    ac88:	49 81 ff 00 10 00 00 	cmp    $0x1000,%r15
    ac8f:	0f 84 35 02 00 00    	je     aeca <fwp_hof0.constprop.0+0x17ca>
    ac95:	48 83 38 00          	cmpq   $0x0,(%rax)
    ac99:	75 e5                	jne    ac80 <fwp_hof0.constprop.0+0x1580>
    ac9b:	4c 89 c7             	mov    %r8,%rdi
    ac9e:	be 08 00 00 00       	mov    $0x8,%esi
    aca3:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    aca8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    acad:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    acb2:	e8 59 88 ff ff       	call   3510 <calloc@plt>
    acb7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    acbc:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    acc2:	48 8d 15 f7 84 04 00 	lea    0x484f7(%rip),%rdx        # 531c0 <ad_raw_blocks>
    acc9:	48 85 c0             	test   %rax,%rax
    accc:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    acd2:	49 89 c2             	mov    %rax,%r10
    acd5:	74 49                	je     ad20 <fwp_hof0.constprop.0+0x1620>
    acd7:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
    acdb:	48 89 c6             	mov    %rax,%rsi
    acde:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    ace3:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    ace7:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    acee:	00 
    acef:	b9 03 00 00 00       	mov    $0x3,%ecx
    acf4:	e8 07 8f ff ff       	call   3c00 <ad_raw_record>
    acf9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    acfe:	e9 61 fd ff ff       	jmp    aa64 <fwp_hof0.constprop.0+0x1364>
    ad03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad08:	66 85 c0             	test   %ax,%ax
    ad0b:	0f 85 bc ea ff ff    	jne    97cd <fwp_hof0.constprop.0+0xcd>
    ad11:	e9 8f ea ff ff       	jmp    97a5 <fwp_hof0.constprop.0+0xa5>
    ad16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ad1d:	00 00 00 
    ad20:	4d 85 e4             	test   %r12,%r12
    ad23:	0f 85 11 03 00 00    	jne    b03a <fwp_hof0.constprop.0+0x193a>
    ad29:	45 31 d2             	xor    %r10d,%r10d
    ad2c:	e9 4c fd ff ff       	jmp    aa7d <fwp_hof0.constprop.0+0x137d>
    ad31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ad38:	66 85 c0             	test   %ax,%ax
    ad3b:	0f 85 82 f8 ff ff    	jne    a5c3 <fwp_hof0.constprop.0+0xec3>
    ad41:	41 80 3f ff          	cmpb   $0xff,(%r15)
    ad45:	0f 85 74 f8 ff ff    	jne    a5bf <fwp_hof0.constprop.0+0xebf>
    ad4b:	4c 89 ff             	mov    %r15,%rdi
    ad4e:	e8 7d aa ff ff       	call   57d0 <fwp_rc_forget_slot>
    ad53:	e9 67 f8 ff ff       	jmp    a5bf <fwp_hof0.constprop.0+0xebf>
    ad58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ad5f:	00 
    ad60:	66 85 c0             	test   %ax,%ax
    ad63:	0f 85 17 f9 ff ff    	jne    a680 <fwp_hof0.constprop.0+0xf80>
    ad69:	41 0f b6 04 24       	movzbl (%r12),%eax
    ad6e:	84 c0                	test   %al,%al
    ad70:	0f 84 0a f9 ff ff    	je     a680 <fwp_hof0.constprop.0+0xf80>
    ad76:	3c 01                	cmp    $0x1,%al
    ad78:	0f 85 e9 f8 ff ff    	jne    a667 <fwp_hof0.constprop.0+0xf67>
    ad7e:	48 89 df             	mov    %rbx,%rdi
    ad81:	e8 8a ac ff ff       	call   5a10 <fwp_mem_free>
    ad86:	e9 f5 f8 ff ff       	jmp    a680 <fwp_hof0.constprop.0+0xf80>
    ad8b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ad8f:	e9 7b eb ff ff       	jmp    990f <fwp_hof0.constprop.0+0x20f>
    ad94:	49 8b 04 24          	mov    (%r12),%rax
    ad98:	48 85 c0             	test   %rax,%rax
    ad9b:	0f 88 f6 fb ff ff    	js     a997 <fwp_hof0.constprop.0+0x1297>
    ada1:	48 8b b5 d8 13 00 00 	mov    0x13d8(%rbp),%rsi
    ada8:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    adad:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    adb4:	48 c1 e6 10          	shl    $0x10,%rsi
    adb8:	48 39 f1             	cmp    %rsi,%rcx
    adbb:	0f 83 d6 fb ff ff    	jae    a997 <fwp_hof0.constprop.0+0x1297>
    adc1:	48 89 ce             	mov    %rcx,%rsi
    adc4:	48 c1 ee 10          	shr    $0x10,%rsi
    adc8:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    adcc:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    add3:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    add7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    addb:	48 85 ff             	test   %rdi,%rdi
    adde:	0f 84 b3 fb ff ff    	je     a997 <fwp_hof0.constprop.0+0x1297>
    ade4:	48 0f ba f0 3f       	btr    $0x3f,%rax
    ade9:	49 89 c7             	mov    %rax,%r15
    adec:	e9 64 f3 ff ff       	jmp    a155 <fwp_hof0.constprop.0+0xa55>
    adf1:	be 68 00 00 00       	mov    $0x68,%esi
    adf6:	41 be 01 00 00 00    	mov    $0x1,%r14d
    adfc:	e9 99 eb ff ff       	jmp    999a <fwp_hof0.constprop.0+0x29a>
    ae01:	66 85 c0             	test   %ax,%ax
    ae04:	0f 85 00 fe ff ff    	jne    ac0a <fwp_hof0.constprop.0+0x150a>
    ae0a:	e9 da fd ff ff       	jmp    abe9 <fwp_hof0.constprop.0+0x14e9>
    ae0f:	4c 89 e2             	mov    %r12,%rdx
    ae12:	48 c1 ea 11          	shr    $0x11,%rdx
    ae16:	4c 31 e2             	xor    %r12,%rdx
    ae19:	48 89 d0             	mov    %rdx,%rax
    ae1c:	48 c1 e8 09          	shr    $0x9,%rax
    ae20:	48 31 c2             	xor    %rax,%rdx
    ae23:	0f b6 d2             	movzbl %dl,%edx
    ae26:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    ae2d:	00 
    ae2e:	48 85 c0             	test   %rax,%rax
    ae31:	75 16                	jne    ae49 <fwp_hof0.constprop.0+0x1749>
    ae33:	eb 51                	jmp    ae86 <fwp_hof0.constprop.0+0x1786>
    ae35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ae3c:	00 00 00 00 
    ae40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    ae44:	48 85 c0             	test   %rax,%rax
    ae47:	74 3d                	je     ae86 <fwp_hof0.constprop.0+0x1786>
    ae49:	48 89 c2             	mov    %rax,%rdx
    ae4c:	4c 39 20             	cmp    %r12,(%rax)
    ae4f:	75 ef                	jne    ae40 <fwp_hof0.constprop.0+0x1740>
    ae51:	48 8b 78 08          	mov    0x8(%rax),%rdi
    ae55:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    ae59:	48 89 50 08          	mov    %rdx,0x8(%rax)
    ae5d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    ae64:	0f 85 46 f6 ff ff    	jne    a4b0 <fwp_hof0.constprop.0+0xdb0>
    ae6a:	4c 89 e7             	mov    %r12,%rdi
    ae6d:	e8 5e a9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    ae72:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    ae77:	e9 34 f6 ff ff       	jmp    a4b0 <fwp_hof0.constprop.0+0xdb0>
    ae7c:	e8 2f a8 ff ff       	call   56b0 <fwp_rc_wide_dup>
    ae81:	e9 44 ea ff ff       	jmp    98ca <fwp_hof0.constprop.0+0x1ca>
    ae86:	48 8d 3d 63 4b 00 00 	lea    0x4b63(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    ae8d:	e8 be 95 ff ff       	call   4450 <fwp_trap>
    ae92:	4d 89 f4             	mov    %r14,%r12
    ae95:	4c 89 d7             	mov    %r10,%rdi
    ae98:	31 f6                	xor    %esi,%esi
    ae9a:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    ae9f:	4d 8d 7c 24 ff       	lea    -0x1(%r12),%r15
    aea4:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    aeab:	00 
    aeac:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    aeb1:	e8 fa 85 ff ff       	call   34b0 <memset@plt>
    aeb6:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    aebc:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    aec2:	49 89 c2             	mov    %rax,%r10
    aec5:	e9 ba fb ff ff       	jmp    aa84 <fwp_hof0.constprop.0+0x1384>
    aeca:	48 8d 3d 41 42 00 00 	lea    0x4241(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    aed1:	e8 2a 91 ff ff       	call   4000 <ad_raw_fail>
    aed6:	e8 d5 a7 ff ff       	call   56b0 <fwp_rc_wide_dup>
    aedb:	e9 ed e8 ff ff       	jmp    97cd <fwp_hof0.constprop.0+0xcd>
    aee0:	4c 89 e0             	mov    %r12,%rax
    aee3:	48 c1 e8 11          	shr    $0x11,%rax
    aee7:	4c 31 e0             	xor    %r12,%rax
    aeea:	48 89 c2             	mov    %rax,%rdx
    aeed:	48 c1 ea 09          	shr    $0x9,%rdx
    aef1:	48 31 d0             	xor    %rdx,%rax
    aef4:	0f b6 d0             	movzbl %al,%edx
    aef7:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    aefe:	00 
    aeff:	48 85 c0             	test   %rax,%rax
    af02:	75 29                	jne    af2d <fwp_hof0.constprop.0+0x182d>
    af04:	eb 80                	jmp    ae86 <fwp_hof0.constprop.0+0x1786>
    af06:	0f 1f 40 00          	nopl   0x0(%rax)
    af0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af11:	00 00 00 00 
    af15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af1c:	00 00 00 00 
    af20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    af24:	48 85 c0             	test   %rax,%rax
    af27:	0f 84 59 ff ff ff    	je     ae86 <fwp_hof0.constprop.0+0x1786>
    af2d:	48 89 c2             	mov    %rax,%rdx
    af30:	4c 3b 20             	cmp    (%rax),%r12
    af33:	75 eb                	jne    af20 <fwp_hof0.constprop.0+0x1820>
    af35:	48 8b 78 08          	mov    0x8(%rax),%rdi
    af39:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    af3d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    af41:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    af48:	0f 85 32 f7 ff ff    	jne    a680 <fwp_hof0.constprop.0+0xf80>
    af4e:	4c 89 e7             	mov    %r12,%rdi
    af51:	e8 7a a8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    af56:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    af5b:	e9 20 f7 ff ff       	jmp    a680 <fwp_hof0.constprop.0+0xf80>
    af60:	45 31 ff             	xor    %r15d,%r15d
    af63:	e9 6d f3 ff ff       	jmp    a2d5 <fwp_hof0.constprop.0+0xbd5>
    af68:	48 8d 3d a9 4a 00 00 	lea    0x4aa9(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    af6f:	e8 dc 94 ff ff       	call   4450 <fwp_trap>
    af74:	48 8d 3d 47 42 00 00 	lea    0x4247(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    af7b:	e8 d0 94 ff ff       	call   4450 <fwp_trap>
    af80:	48 8d 3d 69 4b 00 00 	lea    0x4b69(%rip),%rdi        # faf0 <_IO_stdin_used+0xaf0>
    af87:	e8 c4 94 ff ff       	call   4450 <fwp_trap>
    af8c:	31 db                	xor    %ebx,%ebx
    af8e:	e9 16 fa ff ff       	jmp    a9a9 <fwp_hof0.constprop.0+0x12a9>
    af93:	48 8d 3d 51 42 00 00 	lea    0x4251(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    af9a:	e8 b1 94 ff ff       	call   4450 <fwp_trap>
    af9f:	48 8d 3d d6 42 00 00 	lea    0x42d6(%rip),%rdi        # f27c <_IO_stdin_used+0x27c>
    afa6:	e8 a5 94 ff ff       	call   4450 <fwp_trap>
    afab:	48 8d 3d 00 43 00 00 	lea    0x4300(%rip),%rdi        # f2b2 <_IO_stdin_used+0x2b2>
    afb2:	e8 99 94 ff ff       	call   4450 <fwp_trap>
    afb7:	48 8d 3d 02 4b 00 00 	lea    0x4b02(%rip),%rdi        # fac0 <_IO_stdin_used+0xac0>
    afbe:	e8 8d 94 ff ff       	call   4450 <fwp_trap>
    afc3:	48 8b 0d 76 80 00 00 	mov    0x8076(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    afca:	ba 13 00 00 00       	mov    $0x13,%edx
    afcf:	be 01 00 00 00       	mov    $0x1,%esi
    afd4:	48 8d 3d 2d 40 00 00 	lea    0x402d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    afdb:	e8 80 86 ff ff       	call   3660 <fwrite@plt>
    afe0:	31 ff                	xor    %edi,%edi
    afe2:	e8 b9 85 ff ff       	call   35a0 <fflush@plt>
    afe7:	bf 66 00 00 00       	mov    $0x66,%edi
    afec:	e8 8f 86 ff ff       	call   3680 <_Exit@plt>
    aff1:	48 8d 3d ca 42 00 00 	lea    0x42ca(%rip),%rdi        # f2c2 <_IO_stdin_used+0x2c2>
    aff8:	e8 53 94 ff ff       	call   4450 <fwp_trap>
    affd:	0f 1f 00             	nopl   (%rax)
    b000:	48 8d 3d 11 4b 00 00 	lea    0x4b11(%rip),%rdi        # fb18 <_IO_stdin_used+0xb18>
    b007:	e8 44 94 ff ff       	call   4450 <fwp_trap>
    b00c:	48 8b 0d 2d 80 00 00 	mov    0x802d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b013:	ba 13 00 00 00       	mov    $0x13,%edx
    b018:	be 01 00 00 00       	mov    $0x1,%esi
    b01d:	48 8d 3d e4 3f 00 00 	lea    0x3fe4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b024:	e8 37 86 ff ff       	call   3660 <fwrite@plt>
    b029:	31 ff                	xor    %edi,%edi
    b02b:	e8 70 85 ff ff       	call   35a0 <fflush@plt>
    b030:	bf 66 00 00 00       	mov    $0x66,%edi
    b035:	e8 46 86 ff ff       	call   3680 <_Exit@plt>
    b03a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    b041:	00 
    b042:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    b047:	48 89 05 6a 24 06 00 	mov    %rax,0x6246a(%rip)        # 6d4b8 <fwp_cleanups>
    b04e:	e8 0d a2 ff ff       	call   5260 <fwp_tape_buffers_release>
    b053:	ba 13 00 00 00       	mov    $0x13,%edx
    b058:	48 8b 0d e1 7f 00 00 	mov    0x7fe1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b05f:	be 01 00 00 00       	mov    $0x1,%esi
    b064:	48 8d 3d 9d 3f 00 00 	lea    0x3f9d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b06b:	e8 f0 85 ff ff       	call   3660 <fwrite@plt>
    b070:	31 ff                	xor    %edi,%edi
    b072:	e8 29 85 ff ff       	call   35a0 <fflush@plt>
    b077:	bf 66 00 00 00       	mov    $0x66,%edi
    b07c:	e8 ff 85 ff ff       	call   3680 <_Exit@plt>
    b081:	48 8d 3d d8 49 00 00 	lea    0x49d8(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    b088:	e8 c3 93 ff ff       	call   4450 <fwp_trap>
    b08d:	48 8d 3d 02 42 00 00 	lea    0x4202(%rip),%rdi        # f296 <_IO_stdin_used+0x296>
    b094:	e8 67 8f ff ff       	call   4000 <ad_raw_fail>
    b099:	e8 b2 83 ff ff       	call   3450 <__stack_chk_fail@plt>
    b09e:	66 90                	xchg   %ax,%ax

000000000000b0a0 <f0>:
    b0a0:	41 56                	push   %r14
    b0a2:	4c 8d 35 77 07 06 00 	lea    0x60777(%rip),%r14        # 6b820 <fwp_heap>
    b0a9:	41 55                	push   %r13
    b0ab:	41 54                	push   %r12
    b0ad:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b0b3:	55                   	push   %rbp
    b0b4:	53                   	push   %rbx
    b0b5:	31 db                	xor    %ebx,%ebx
    b0b7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b0be:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b0c5:	00 00 
    b0c7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b0ce:	00 
    b0cf:	31 c0                	xor    %eax,%eax
    b0d1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b0d8:	00 
    b0d9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b0e0:	00 00 
    b0e2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b0e7:	48 8d 05 a2 cc ff ff 	lea    -0x335e(%rip),%rax        # 7d90 <fwp_drop1>
    b0ee:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b0f3:	48 8b 05 be 23 06 00 	mov    0x623be(%rip),%rax        # 6d4b8 <fwp_cleanups>
    b0fa:	48 89 25 b7 23 06 00 	mov    %rsp,0x623b7(%rip)        # 6d4b8 <fwp_cleanups>
    b101:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b105:	48 89 04 24          	mov    %rax,(%rsp)
    b109:	48 8d 05 c0 8a ff ff 	lea    -0x7540(%rip),%rax        # 3bd0 <fwp_range_release>
    b110:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b115:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b11a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b11f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b124:	eb 47                	jmp    b16d <f0+0xcd>
    b126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b12d:	00 00 00 
    b130:	80 f9 01             	cmp    $0x1,%cl
    b133:	75 29                	jne    b15e <f0+0xbe>
    b135:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b138:	0f b7 c0             	movzwl %ax,%eax
    b13b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b13e:	48 0f af c1          	imul   %rcx,%rax
    b142:	48 c1 e8 20          	shr    $0x20,%rax
    b146:	48 39 d0             	cmp    %rdx,%rax
    b149:	73 13                	jae    b15e <f0+0xbe>
    b14b:	49 01 c5             	add    %rax,%r13
    b14e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b153:	0f 84 c7 27 00 00    	je     d920 <f0+0x2880>
    b159:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b15e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b163:	49 83 ec 01          	sub    $0x1,%r12
    b167:	0f 82 83 00 00 00    	jb     b1f0 <f0+0x150>
    b16d:	48 89 ee             	mov    %rbp,%rsi
    b170:	bf 01 00 00 00       	mov    $0x1,%edi
    b175:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b17c:	00 
    b17d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b182:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b189:	00 
    b18a:	e8 71 af ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b18f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b196:	48 89 c3             	mov    %rax,%rbx
    b199:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b1a0:	48 c1 e2 10          	shl    $0x10,%rdx
    b1a4:	48 39 d0             	cmp    %rdx,%rax
    b1a7:	73 b5                	jae    b15e <f0+0xbe>
    b1a9:	48 89 c2             	mov    %rax,%rdx
    b1ac:	48 c1 ea 10          	shr    $0x10,%rdx
    b1b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b1b4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b1bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b1bf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b1c3:	4d 85 ed             	test   %r13,%r13
    b1c6:	74 96                	je     b15e <f0+0xbe>
    b1c8:	0f b6 0a             	movzbl (%rdx),%ecx
    b1cb:	80 f9 02             	cmp    $0x2,%cl
    b1ce:	0f 85 5c ff ff ff    	jne    b130 <f0+0x90>
    b1d4:	66 85 c0             	test   %ax,%ax
    b1d7:	0f 84 71 ff ff ff    	je     b14e <f0+0xae>
    b1dd:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b1e2:	49 83 ec 01          	sub    $0x1,%r12
    b1e6:	73 85                	jae    b16d <f0+0xcd>
    b1e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b1ef:	00 
    b1f0:	48 8b 04 24          	mov    (%rsp),%rax
    b1f4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b1f9:	bf 01 00 00 00       	mov    $0x1,%edi
    b1fe:	66 0f 6f 05 0a 4c 00 	movdqa 0x4c0a(%rip),%xmm0        # fe10 <msg.4+0xd0>
    b205:	00 
    b206:	48 89 05 ab 22 06 00 	mov    %rax,0x622ab(%rip)        # 6d4b8 <fwp_cleanups>
    b20d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b212:	e8 e9 ae ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b217:	48 8b 15 da 19 06 00 	mov    0x619da(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b21e:	49 89 c5             	mov    %rax,%r13
    b221:	48 2b 05 a8 19 06 00 	sub    0x619a8(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b228:	48 c1 e2 10          	shl    $0x10,%rdx
    b22c:	48 39 d0             	cmp    %rdx,%rax
    b22f:	73 59                	jae    b28a <f0+0x1ea>
    b231:	48 89 c2             	mov    %rax,%rdx
    b234:	48 c1 ea 10          	shr    $0x10,%rdx
    b238:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b23c:	48 8b 15 d5 19 06 00 	mov    0x619d5(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b243:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b247:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b24b:	4d 85 e4             	test   %r12,%r12
    b24e:	74 3a                	je     b28a <f0+0x1ea>
    b250:	0f b6 0a             	movzbl (%rdx),%ecx
    b253:	80 f9 02             	cmp    $0x2,%cl
    b256:	0f 84 74 27 00 00    	je     d9d0 <f0+0x2930>
    b25c:	80 f9 01             	cmp    $0x1,%cl
    b25f:	75 29                	jne    b28a <f0+0x1ea>
    b261:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b264:	0f b7 c0             	movzwl %ax,%eax
    b267:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b26a:	48 0f af c1          	imul   %rcx,%rax
    b26e:	48 c1 e8 20          	shr    $0x20,%rax
    b272:	48 39 d0             	cmp    %rdx,%rax
    b275:	73 13                	jae    b28a <f0+0x1ea>
    b277:	49 01 c4             	add    %rax,%r12
    b27a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b27f:	0f 84 26 29 00 00    	je     dbab <f0+0x2b0b>
    b285:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b28a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b28f:	bf 01 00 00 00       	mov    $0x1,%edi
    b294:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b299:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b2a0:	00 f0 3f 
    b2a3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b2a8:	e8 53 ae ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b2ad:	48 8b 15 44 19 06 00 	mov    0x61944(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b2b4:	49 89 c5             	mov    %rax,%r13
    b2b7:	48 2b 05 12 19 06 00 	sub    0x61912(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b2be:	48 c1 e2 10          	shl    $0x10,%rdx
    b2c2:	48 39 d0             	cmp    %rdx,%rax
    b2c5:	73 59                	jae    b320 <f0+0x280>
    b2c7:	48 89 c2             	mov    %rax,%rdx
    b2ca:	48 c1 ea 10          	shr    $0x10,%rdx
    b2ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2d2:	48 8b 15 3f 19 06 00 	mov    0x6193f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b2d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2dd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b2e1:	4d 85 e4             	test   %r12,%r12
    b2e4:	74 3a                	je     b320 <f0+0x280>
    b2e6:	0f b6 0a             	movzbl (%rdx),%ecx
    b2e9:	80 f9 02             	cmp    $0x2,%cl
    b2ec:	0f 84 ce 26 00 00    	je     d9c0 <f0+0x2920>
    b2f2:	80 f9 01             	cmp    $0x1,%cl
    b2f5:	75 29                	jne    b320 <f0+0x280>
    b2f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b2fa:	0f b7 c0             	movzwl %ax,%eax
    b2fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b300:	48 0f af c1          	imul   %rcx,%rax
    b304:	48 c1 e8 20          	shr    $0x20,%rax
    b308:	48 39 d0             	cmp    %rdx,%rax
    b30b:	73 13                	jae    b320 <f0+0x280>
    b30d:	49 01 c4             	add    %rax,%r12
    b310:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b315:	0f 84 9d 28 00 00    	je     dbb8 <f0+0x2b18>
    b31b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b320:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b325:	bf 01 00 00 00       	mov    $0x1,%edi
    b32a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b32f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b336:	33 f3 bf 
    b339:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b33e:	e8 bd ad ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b343:	48 8b 15 ae 18 06 00 	mov    0x618ae(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b34a:	49 89 c5             	mov    %rax,%r13
    b34d:	48 2b 05 7c 18 06 00 	sub    0x6187c(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b354:	48 c1 e2 10          	shl    $0x10,%rdx
    b358:	48 39 d0             	cmp    %rdx,%rax
    b35b:	73 59                	jae    b3b6 <f0+0x316>
    b35d:	48 89 c2             	mov    %rax,%rdx
    b360:	48 c1 ea 10          	shr    $0x10,%rdx
    b364:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b368:	48 8b 15 a9 18 06 00 	mov    0x618a9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b36f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b373:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b377:	4d 85 e4             	test   %r12,%r12
    b37a:	74 3a                	je     b3b6 <f0+0x316>
    b37c:	0f b6 0a             	movzbl (%rdx),%ecx
    b37f:	80 f9 02             	cmp    $0x2,%cl
    b382:	0f 84 28 26 00 00    	je     d9b0 <f0+0x2910>
    b388:	80 f9 01             	cmp    $0x1,%cl
    b38b:	75 29                	jne    b3b6 <f0+0x316>
    b38d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b390:	0f b7 c0             	movzwl %ax,%eax
    b393:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b396:	48 0f af c1          	imul   %rcx,%rax
    b39a:	48 c1 e8 20          	shr    $0x20,%rax
    b39e:	48 39 d0             	cmp    %rdx,%rax
    b3a1:	73 13                	jae    b3b6 <f0+0x316>
    b3a3:	49 01 c4             	add    %rax,%r12
    b3a6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b3ab:	0f 84 14 28 00 00    	je     dbc5 <f0+0x2b25>
    b3b1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b3b6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b3bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b3c0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b3c5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b3cc:	00 f0 3f 
    b3cf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b3d4:	e8 27 ad ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b3d9:	48 8b 15 18 18 06 00 	mov    0x61818(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b3e0:	49 89 c5             	mov    %rax,%r13
    b3e3:	48 2b 05 e6 17 06 00 	sub    0x617e6(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b3ea:	48 c1 e2 10          	shl    $0x10,%rdx
    b3ee:	48 39 d0             	cmp    %rdx,%rax
    b3f1:	73 59                	jae    b44c <f0+0x3ac>
    b3f3:	48 89 c2             	mov    %rax,%rdx
    b3f6:	48 c1 ea 10          	shr    $0x10,%rdx
    b3fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3fe:	48 8b 15 13 18 06 00 	mov    0x61813(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b405:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b409:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b40d:	4d 85 e4             	test   %r12,%r12
    b410:	74 3a                	je     b44c <f0+0x3ac>
    b412:	0f b6 0a             	movzbl (%rdx),%ecx
    b415:	80 f9 02             	cmp    $0x2,%cl
    b418:	0f 84 f2 25 00 00    	je     da10 <f0+0x2970>
    b41e:	80 f9 01             	cmp    $0x1,%cl
    b421:	75 29                	jne    b44c <f0+0x3ac>
    b423:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b426:	0f b7 c0             	movzwl %ax,%eax
    b429:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b42c:	48 0f af c1          	imul   %rcx,%rax
    b430:	48 c1 e8 20          	shr    $0x20,%rax
    b434:	48 39 d0             	cmp    %rdx,%rax
    b437:	73 13                	jae    b44c <f0+0x3ac>
    b439:	49 01 c4             	add    %rax,%r12
    b43c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b441:	0f 84 8b 27 00 00    	je     dbd2 <f0+0x2b32>
    b447:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b44c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b453:	33 f3 bf 
    b456:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b45d:	00 
    b45e:	bf 01 00 00 00       	mov    $0x1,%edi
    b463:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b46a:	00 
    b46b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b472:	00 
    b473:	e8 88 ac ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b478:	48 8b 15 79 17 06 00 	mov    0x61779(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b47f:	49 89 c5             	mov    %rax,%r13
    b482:	48 2b 05 47 17 06 00 	sub    0x61747(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b489:	48 c1 e2 10          	shl    $0x10,%rdx
    b48d:	48 39 d0             	cmp    %rdx,%rax
    b490:	73 59                	jae    b4eb <f0+0x44b>
    b492:	48 89 c2             	mov    %rax,%rdx
    b495:	48 c1 ea 10          	shr    $0x10,%rdx
    b499:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b49d:	48 8b 15 74 17 06 00 	mov    0x61774(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b4a4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b4a8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b4ac:	4d 85 e4             	test   %r12,%r12
    b4af:	74 3a                	je     b4eb <f0+0x44b>
    b4b1:	0f b6 0a             	movzbl (%rdx),%ecx
    b4b4:	80 f9 02             	cmp    $0x2,%cl
    b4b7:	0f 84 43 25 00 00    	je     da00 <f0+0x2960>
    b4bd:	80 f9 01             	cmp    $0x1,%cl
    b4c0:	75 29                	jne    b4eb <f0+0x44b>
    b4c2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b4c5:	0f b7 c0             	movzwl %ax,%eax
    b4c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4cb:	48 0f af c1          	imul   %rcx,%rax
    b4cf:	48 c1 e8 20          	shr    $0x20,%rax
    b4d3:	48 39 d0             	cmp    %rdx,%rax
    b4d6:	73 13                	jae    b4eb <f0+0x44b>
    b4d8:	49 01 c4             	add    %rax,%r12
    b4db:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b4e0:	0f 84 f9 26 00 00    	je     dbdf <f0+0x2b3f>
    b4e6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b4eb:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b4f2:	00 f0 3f 
    b4f5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b4fc:	00 
    b4fd:	bf 01 00 00 00       	mov    $0x1,%edi
    b502:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b509:	00 
    b50a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b511:	00 
    b512:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b519:	33 f3 bf 
    b51c:	e8 df ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b521:	48 89 c7             	mov    %rax,%rdi
    b524:	e8 b7 b3 ff ff       	call   68e0 <fwp_rc_fresh>
    b529:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b530:	00 
    b531:	bf 01 00 00 00       	mov    $0x1,%edi
    b536:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b53d:	00 
    b53e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b545:	00 
    b546:	e8 b5 ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b54b:	48 89 c7             	mov    %rax,%rdi
    b54e:	e8 8d b3 ff ff       	call   68e0 <fwp_rc_fresh>
    b553:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b55a:	00 
    b55b:	bf 01 00 00 00       	mov    $0x1,%edi
    b560:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b567:	00 
    b568:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b56f:	00 
    b570:	e8 8b ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b575:	48 89 c7             	mov    %rax,%rdi
    b578:	e8 63 b3 ff ff       	call   68e0 <fwp_rc_fresh>
    b57d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b584:	00 
    b585:	bf 01 00 00 00       	mov    $0x1,%edi
    b58a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b591:	00 
    b592:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b599:	00 
    b59a:	e8 61 ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b59f:	48 89 c7             	mov    %rax,%rdi
    b5a2:	e8 39 b3 ff ff       	call   68e0 <fwp_rc_fresh>
    b5a7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b5ae:	00 
    b5af:	bf 01 00 00 00       	mov    $0x1,%edi
    b5b4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b5bb:	00 
    b5bc:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b5c3:	00 
    b5c4:	e8 37 ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b5c9:	48 89 c7             	mov    %rax,%rdi
    b5cc:	e8 0f b3 ff ff       	call   68e0 <fwp_rc_fresh>
    b5d1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b5d8:	00 
    b5d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b5de:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b5e5:	00 
    b5e6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b5ed:	00 
    b5ee:	e8 0d ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b5f3:	48 89 c7             	mov    %rax,%rdi
    b5f6:	e8 e5 b2 ff ff       	call   68e0 <fwp_rc_fresh>
    b5fb:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b602:	00 
    b603:	bf 01 00 00 00       	mov    $0x1,%edi
    b608:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b60f:	00 
    b610:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b617:	00 
    b618:	e8 e3 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b61d:	48 89 c7             	mov    %rax,%rdi
    b620:	e8 bb b2 ff ff       	call   68e0 <fwp_rc_fresh>
    b625:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b62c:	00 
    b62d:	bf 01 00 00 00       	mov    $0x1,%edi
    b632:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b639:	00 
    b63a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b641:	00 
    b642:	e8 b9 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b647:	48 89 c7             	mov    %rax,%rdi
    b64a:	e8 91 b2 ff ff       	call   68e0 <fwp_rc_fresh>
    b64f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b656:	00 
    b657:	bf 01 00 00 00       	mov    $0x1,%edi
    b65c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b663:	00 
    b664:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b66b:	00 
    b66c:	e8 8f aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b671:	48 89 c7             	mov    %rax,%rdi
    b674:	e8 67 b2 ff ff       	call   68e0 <fwp_rc_fresh>
    b679:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b680:	00 
    b681:	bf 01 00 00 00       	mov    $0x1,%edi
    b686:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b68d:	00 
    b68e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b695:	00 
    b696:	e8 65 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b69b:	48 89 c7             	mov    %rax,%rdi
    b69e:	e8 3d b2 ff ff       	call   68e0 <fwp_rc_fresh>
    b6a3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b6aa:	00 
    b6ab:	bf 01 00 00 00       	mov    $0x1,%edi
    b6b0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b6b7:	00 
    b6b8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b6bf:	00 
    b6c0:	e8 3b aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b6c5:	48 89 c7             	mov    %rax,%rdi
    b6c8:	e8 13 b2 ff ff       	call   68e0 <fwp_rc_fresh>
    b6cd:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b6d4:	00 
    b6d5:	bf 01 00 00 00       	mov    $0x1,%edi
    b6da:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b6e1:	00 
    b6e2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b6e9:	00 
    b6ea:	e8 11 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b6ef:	48 89 c7             	mov    %rax,%rdi
    b6f2:	e8 e9 b1 ff ff       	call   68e0 <fwp_rc_fresh>
    b6f7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b6fe:	00 
    b6ff:	bf 01 00 00 00       	mov    $0x1,%edi
    b704:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b70b:	00 
    b70c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b713:	00 
    b714:	e8 e7 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b719:	48 89 c7             	mov    %rax,%rdi
    b71c:	e8 bf b1 ff ff       	call   68e0 <fwp_rc_fresh>
    b721:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b728:	00 
    b729:	bf 01 00 00 00       	mov    $0x1,%edi
    b72e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b735:	00 
    b736:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b73d:	00 
    b73e:	e8 bd a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b743:	48 89 c7             	mov    %rax,%rdi
    b746:	e8 95 b1 ff ff       	call   68e0 <fwp_rc_fresh>
    b74b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b752:	00 
    b753:	bf 01 00 00 00       	mov    $0x1,%edi
    b758:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b75f:	00 
    b760:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b767:	00 
    b768:	e8 93 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b76d:	48 89 c7             	mov    %rax,%rdi
    b770:	e8 6b b1 ff ff       	call   68e0 <fwp_rc_fresh>
    b775:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b77c:	00 
    b77d:	bf 01 00 00 00       	mov    $0x1,%edi
    b782:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b789:	00 
    b78a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b791:	00 
    b792:	e8 69 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b797:	48 89 c7             	mov    %rax,%rdi
    b79a:	e8 41 b1 ff ff       	call   68e0 <fwp_rc_fresh>
    b79f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b7a6:	00 
    b7a7:	bf 01 00 00 00       	mov    $0x1,%edi
    b7ac:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b7b3:	00 
    b7b4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b7bb:	00 
    b7bc:	e8 3f a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b7c1:	48 89 c7             	mov    %rax,%rdi
    b7c4:	e8 17 b1 ff ff       	call   68e0 <fwp_rc_fresh>
    b7c9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b7d0:	00 
    b7d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b7d6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b7dd:	00 
    b7de:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b7e5:	00 
    b7e6:	e8 15 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b7eb:	48 89 c7             	mov    %rax,%rdi
    b7ee:	e8 ed b0 ff ff       	call   68e0 <fwp_rc_fresh>
    b7f3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b7fa:	00 
    b7fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b800:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b807:	00 
    b808:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b80f:	00 
    b810:	e8 eb a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b815:	48 89 c7             	mov    %rax,%rdi
    b818:	e8 c3 b0 ff ff       	call   68e0 <fwp_rc_fresh>
    b81d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b824:	00 
    b825:	bf 01 00 00 00       	mov    $0x1,%edi
    b82a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b831:	00 
    b832:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b839:	00 
    b83a:	e8 c1 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b83f:	48 89 c7             	mov    %rax,%rdi
    b842:	e8 99 b0 ff ff       	call   68e0 <fwp_rc_fresh>
    b847:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b84e:	00 
    b84f:	bf 01 00 00 00       	mov    $0x1,%edi
    b854:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b85b:	00 
    b85c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b863:	00 
    b864:	e8 97 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b869:	48 89 c7             	mov    %rax,%rdi
    b86c:	e8 6f b0 ff ff       	call   68e0 <fwp_rc_fresh>
    b871:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b878:	00 
    b879:	bf 01 00 00 00       	mov    $0x1,%edi
    b87e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b885:	00 
    b886:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b88d:	00 
    b88e:	e8 6d a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b893:	48 89 c7             	mov    %rax,%rdi
    b896:	e8 45 b0 ff ff       	call   68e0 <fwp_rc_fresh>
    b89b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b8a2:	00 
    b8a3:	bf 01 00 00 00       	mov    $0x1,%edi
    b8a8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b8af:	00 
    b8b0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b8b7:	00 
    b8b8:	e8 43 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b8bd:	48 89 c7             	mov    %rax,%rdi
    b8c0:	e8 1b b0 ff ff       	call   68e0 <fwp_rc_fresh>
    b8c5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b8cc:	00 
    b8cd:	bf 01 00 00 00       	mov    $0x1,%edi
    b8d2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b8d9:	00 
    b8da:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b8e1:	00 
    b8e2:	e8 19 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b8e7:	48 89 c7             	mov    %rax,%rdi
    b8ea:	e8 f1 af ff ff       	call   68e0 <fwp_rc_fresh>
    b8ef:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b8f6:	00 
    b8f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b8fc:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b903:	00 
    b904:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b90b:	00 
    b90c:	e8 ef a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b911:	48 89 c7             	mov    %rax,%rdi
    b914:	e8 c7 af ff ff       	call   68e0 <fwp_rc_fresh>
    b919:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b920:	00 
    b921:	bf 01 00 00 00       	mov    $0x1,%edi
    b926:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b92d:	00 
    b92e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b935:	00 
    b936:	e8 c5 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b93b:	48 89 c7             	mov    %rax,%rdi
    b93e:	e8 9d af ff ff       	call   68e0 <fwp_rc_fresh>
    b943:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b94a:	00 
    b94b:	bf 01 00 00 00       	mov    $0x1,%edi
    b950:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b957:	00 
    b958:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b95f:	00 
    b960:	e8 9b a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b965:	48 89 c7             	mov    %rax,%rdi
    b968:	e8 73 af ff ff       	call   68e0 <fwp_rc_fresh>
    b96d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b974:	00 
    b975:	bf 01 00 00 00       	mov    $0x1,%edi
    b97a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b981:	00 
    b982:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b989:	00 
    b98a:	e8 71 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b98f:	48 89 c7             	mov    %rax,%rdi
    b992:	e8 49 af ff ff       	call   68e0 <fwp_rc_fresh>
    b997:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b99e:	00 
    b99f:	bf 01 00 00 00       	mov    $0x1,%edi
    b9a4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b9ab:	00 
    b9ac:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b9b3:	00 
    b9b4:	e8 47 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b9b9:	48 89 c7             	mov    %rax,%rdi
    b9bc:	e8 1f af ff ff       	call   68e0 <fwp_rc_fresh>
    b9c1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b9c8:	00 
    b9c9:	bf 01 00 00 00       	mov    $0x1,%edi
    b9ce:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b9d5:	00 
    b9d6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b9dd:	00 
    b9de:	e8 1d a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b9e3:	48 89 c7             	mov    %rax,%rdi
    b9e6:	e8 f5 ae ff ff       	call   68e0 <fwp_rc_fresh>
    b9eb:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b9f2:	00 
    b9f3:	bf 01 00 00 00       	mov    $0x1,%edi
    b9f8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b9ff:	00 
    ba00:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    ba07:	00 
    ba08:	e8 f3 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba0d:	48 89 c7             	mov    %rax,%rdi
    ba10:	e8 cb ae ff ff       	call   68e0 <fwp_rc_fresh>
    ba15:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    ba1c:	00 
    ba1d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba22:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    ba29:	00 
    ba2a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    ba31:	00 
    ba32:	e8 c9 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba37:	48 89 c7             	mov    %rax,%rdi
    ba3a:	e8 a1 ae ff ff       	call   68e0 <fwp_rc_fresh>
    ba3f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    ba46:	00 
    ba47:	bf 01 00 00 00       	mov    $0x1,%edi
    ba4c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    ba53:	00 
    ba54:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    ba5b:	00 
    ba5c:	e8 9f a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba61:	48 89 c7             	mov    %rax,%rdi
    ba64:	e8 77 ae ff ff       	call   68e0 <fwp_rc_fresh>
    ba69:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    ba70:	00 
    ba71:	bf 01 00 00 00       	mov    $0x1,%edi
    ba76:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    ba7d:	00 
    ba7e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    ba85:	00 
    ba86:	e8 75 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba8b:	48 89 c7             	mov    %rax,%rdi
    ba8e:	e8 4d ae ff ff       	call   68e0 <fwp_rc_fresh>
    ba93:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    ba9a:	00 
    ba9b:	bf 01 00 00 00       	mov    $0x1,%edi
    baa0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    baa7:	00 
    baa8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    baaf:	00 
    bab0:	e8 4b a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bab5:	48 89 c7             	mov    %rax,%rdi
    bab8:	e8 23 ae ff ff       	call   68e0 <fwp_rc_fresh>
    babd:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bac4:	00 
    bac5:	bf 01 00 00 00       	mov    $0x1,%edi
    baca:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bad1:	00 
    bad2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bad9:	00 
    bada:	e8 21 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    badf:	48 89 c7             	mov    %rax,%rdi
    bae2:	e8 f9 ad ff ff       	call   68e0 <fwp_rc_fresh>
    bae7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    baee:	00 
    baef:	bf 01 00 00 00       	mov    $0x1,%edi
    baf4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bafb:	00 
    bafc:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bb03:	00 
    bb04:	e8 f7 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb09:	48 89 c7             	mov    %rax,%rdi
    bb0c:	e8 cf ad ff ff       	call   68e0 <fwp_rc_fresh>
    bb11:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bb18:	00 
    bb19:	bf 01 00 00 00       	mov    $0x1,%edi
    bb1e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bb25:	00 
    bb26:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bb2d:	00 
    bb2e:	e8 cd a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb33:	48 89 c7             	mov    %rax,%rdi
    bb36:	e8 a5 ad ff ff       	call   68e0 <fwp_rc_fresh>
    bb3b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bb42:	00 
    bb43:	bf 01 00 00 00       	mov    $0x1,%edi
    bb48:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bb4f:	00 
    bb50:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bb57:	00 
    bb58:	e8 a3 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb5d:	48 89 c7             	mov    %rax,%rdi
    bb60:	e8 7b ad ff ff       	call   68e0 <fwp_rc_fresh>
    bb65:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bb6c:	00 
    bb6d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb72:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bb79:	00 
    bb7a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bb81:	00 
    bb82:	e8 79 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb87:	48 89 c7             	mov    %rax,%rdi
    bb8a:	e8 51 ad ff ff       	call   68e0 <fwp_rc_fresh>
    bb8f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bb96:	00 
    bb97:	bf 01 00 00 00       	mov    $0x1,%edi
    bb9c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bba3:	00 
    bba4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bbab:	00 
    bbac:	e8 4f a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bbb1:	48 89 c7             	mov    %rax,%rdi
    bbb4:	e8 27 ad ff ff       	call   68e0 <fwp_rc_fresh>
    bbb9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bbc0:	00 
    bbc1:	bf 01 00 00 00       	mov    $0x1,%edi
    bbc6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bbcd:	00 
    bbce:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bbd5:	00 
    bbd6:	e8 25 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bbdb:	48 89 c7             	mov    %rax,%rdi
    bbde:	e8 fd ac ff ff       	call   68e0 <fwp_rc_fresh>
    bbe3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bbea:	00 
    bbeb:	bf 01 00 00 00       	mov    $0x1,%edi
    bbf0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bbf7:	00 
    bbf8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bbff:	00 
    bc00:	e8 fb a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc05:	48 89 c7             	mov    %rax,%rdi
    bc08:	e8 d3 ac ff ff       	call   68e0 <fwp_rc_fresh>
    bc0d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bc14:	00 
    bc15:	bf 01 00 00 00       	mov    $0x1,%edi
    bc1a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    bc21:	00 
    bc22:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    bc29:	00 
    bc2a:	e8 d1 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc2f:	48 89 c7             	mov    %rax,%rdi
    bc32:	e8 a9 ac ff ff       	call   68e0 <fwp_rc_fresh>
    bc37:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    bc3e:	00 
    bc3f:	bf 01 00 00 00       	mov    $0x1,%edi
    bc44:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    bc4b:	00 
    bc4c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    bc53:	00 
    bc54:	e8 a7 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc59:	48 89 c7             	mov    %rax,%rdi
    bc5c:	e8 7f ac ff ff       	call   68e0 <fwp_rc_fresh>
    bc61:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    bc68:	00 
    bc69:	bf 01 00 00 00       	mov    $0x1,%edi
    bc6e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    bc75:	00 
    bc76:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    bc7d:	00 
    bc7e:	e8 7d a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc83:	48 89 c7             	mov    %rax,%rdi
    bc86:	e8 55 ac ff ff       	call   68e0 <fwp_rc_fresh>
    bc8b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    bc92:	00 
    bc93:	bf 01 00 00 00       	mov    $0x1,%edi
    bc98:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    bc9f:	00 
    bca0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    bca7:	00 
    bca8:	e8 53 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bcad:	48 89 c7             	mov    %rax,%rdi
    bcb0:	e8 2b ac ff ff       	call   68e0 <fwp_rc_fresh>
    bcb5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    bcbc:	00 
    bcbd:	bf 01 00 00 00       	mov    $0x1,%edi
    bcc2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    bcc9:	00 
    bcca:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    bcd1:	00 
    bcd2:	e8 29 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bcd7:	48 89 c7             	mov    %rax,%rdi
    bcda:	e8 01 ac ff ff       	call   68e0 <fwp_rc_fresh>
    bcdf:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    bce6:	00 
    bce7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcec:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    bcf3:	00 
    bcf4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    bcfb:	00 
    bcfc:	e8 ff a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd01:	48 89 c7             	mov    %rax,%rdi
    bd04:	e8 d7 ab ff ff       	call   68e0 <fwp_rc_fresh>
    bd09:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    bd10:	00 
    bd11:	bf 01 00 00 00       	mov    $0x1,%edi
    bd16:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    bd1d:	00 
    bd1e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    bd25:	00 
    bd26:	e8 d5 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd2b:	48 89 c7             	mov    %rax,%rdi
    bd2e:	e8 ad ab ff ff       	call   68e0 <fwp_rc_fresh>
    bd33:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    bd3a:	00 
    bd3b:	bf 01 00 00 00       	mov    $0x1,%edi
    bd40:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    bd47:	00 
    bd48:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    bd4f:	00 
    bd50:	e8 ab a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd55:	48 89 c7             	mov    %rax,%rdi
    bd58:	e8 83 ab ff ff       	call   68e0 <fwp_rc_fresh>
    bd5d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bd64:	00 
    bd65:	bf 01 00 00 00       	mov    $0x1,%edi
    bd6a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bd71:	00 
    bd72:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bd79:	00 
    bd7a:	e8 81 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd7f:	48 89 c7             	mov    %rax,%rdi
    bd82:	e8 59 ab ff ff       	call   68e0 <fwp_rc_fresh>
    bd87:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    bd8e:	00 
    bd8f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd94:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    bd9b:	00 
    bd9c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    bda3:	00 
    bda4:	e8 57 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bda9:	48 89 c7             	mov    %rax,%rdi
    bdac:	e8 2f ab ff ff       	call   68e0 <fwp_rc_fresh>
    bdb1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    bdb8:	00 
    bdb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bdbe:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    bdc5:	00 
    bdc6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    bdcd:	00 
    bdce:	e8 2d a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bdd3:	48 89 c7             	mov    %rax,%rdi
    bdd6:	e8 05 ab ff ff       	call   68e0 <fwp_rc_fresh>
    bddb:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    bde2:	00 
    bde3:	bf 01 00 00 00       	mov    $0x1,%edi
    bde8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    bdef:	00 
    bdf0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    bdf7:	00 
    bdf8:	e8 03 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bdfd:	48 89 c7             	mov    %rax,%rdi
    be00:	e8 db aa ff ff       	call   68e0 <fwp_rc_fresh>
    be05:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    be0c:	00 
    be0d:	bf 01 00 00 00       	mov    $0x1,%edi
    be12:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    be19:	00 
    be1a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    be21:	00 
    be22:	e8 d9 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be27:	48 89 c7             	mov    %rax,%rdi
    be2a:	e8 b1 aa ff ff       	call   68e0 <fwp_rc_fresh>
    be2f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    be36:	00 
    be37:	bf 01 00 00 00       	mov    $0x1,%edi
    be3c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    be43:	00 
    be44:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    be4b:	00 
    be4c:	e8 af a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be51:	48 89 c7             	mov    %rax,%rdi
    be54:	e8 87 aa ff ff       	call   68e0 <fwp_rc_fresh>
    be59:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    be60:	00 
    be61:	bf 01 00 00 00       	mov    $0x1,%edi
    be66:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    be6d:	00 
    be6e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    be75:	00 
    be76:	e8 85 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be7b:	48 89 c7             	mov    %rax,%rdi
    be7e:	e8 5d aa ff ff       	call   68e0 <fwp_rc_fresh>
    be83:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    be8a:	00 
    be8b:	bf 01 00 00 00       	mov    $0x1,%edi
    be90:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    be97:	00 
    be98:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    be9f:	00 
    bea0:	e8 5b a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bea5:	48 89 c7             	mov    %rax,%rdi
    bea8:	e8 33 aa ff ff       	call   68e0 <fwp_rc_fresh>
    bead:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    beb4:	00 
    beb5:	bf 01 00 00 00       	mov    $0x1,%edi
    beba:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    bec1:	00 
    bec2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    bec9:	00 
    beca:	e8 31 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    becf:	48 89 c7             	mov    %rax,%rdi
    bed2:	e8 09 aa ff ff       	call   68e0 <fwp_rc_fresh>
    bed7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    bede:	00 
    bedf:	bf 01 00 00 00       	mov    $0x1,%edi
    bee4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    beeb:	00 
    beec:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    bef3:	00 
    bef4:	e8 07 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bef9:	48 89 c7             	mov    %rax,%rdi
    befc:	e8 df a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bf01:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    bf08:	00 
    bf09:	bf 01 00 00 00       	mov    $0x1,%edi
    bf0e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    bf15:	00 
    bf16:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    bf1d:	00 
    bf1e:	e8 dd a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf23:	48 89 c7             	mov    %rax,%rdi
    bf26:	e8 b5 a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bf2b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    bf32:	00 
    bf33:	bf 01 00 00 00       	mov    $0x1,%edi
    bf38:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    bf3f:	00 
    bf40:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    bf47:	00 
    bf48:	e8 b3 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf4d:	48 89 c7             	mov    %rax,%rdi
    bf50:	e8 8b a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bf55:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    bf5c:	00 
    bf5d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf62:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    bf69:	00 
    bf6a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    bf71:	00 
    bf72:	e8 89 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf77:	48 89 c7             	mov    %rax,%rdi
    bf7a:	e8 61 a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bf7f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    bf86:	00 
    bf87:	bf 01 00 00 00       	mov    $0x1,%edi
    bf8c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    bf93:	00 
    bf94:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    bf9b:	00 
    bf9c:	e8 5f a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bfa1:	48 89 c7             	mov    %rax,%rdi
    bfa4:	e8 37 a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bfa9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    bfb0:	00 
    bfb1:	bf 01 00 00 00       	mov    $0x1,%edi
    bfb6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    bfbd:	00 
    bfbe:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    bfc5:	00 
    bfc6:	e8 35 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bfcb:	48 89 c7             	mov    %rax,%rdi
    bfce:	e8 0d a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bfd3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    bfda:	00 
    bfdb:	bf 01 00 00 00       	mov    $0x1,%edi
    bfe0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    bfe7:	00 
    bfe8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    bfef:	00 
    bff0:	e8 0b a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bff5:	48 89 c7             	mov    %rax,%rdi
    bff8:	e8 e3 a8 ff ff       	call   68e0 <fwp_rc_fresh>
    bffd:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c004:	00 
    c005:	bf 01 00 00 00       	mov    $0x1,%edi
    c00a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c011:	00 
    c012:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c019:	00 
    c01a:	e8 e1 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c01f:	48 89 c7             	mov    %rax,%rdi
    c022:	e8 b9 a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c027:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c02e:	00 
    c02f:	bf 01 00 00 00       	mov    $0x1,%edi
    c034:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c03b:	00 
    c03c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c043:	00 
    c044:	e8 b7 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c049:	48 89 c7             	mov    %rax,%rdi
    c04c:	e8 8f a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c051:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c058:	00 
    c059:	bf 01 00 00 00       	mov    $0x1,%edi
    c05e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c065:	00 
    c066:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c06d:	00 
    c06e:	e8 8d a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c073:	48 89 c7             	mov    %rax,%rdi
    c076:	e8 65 a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c07b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c082:	00 
    c083:	bf 01 00 00 00       	mov    $0x1,%edi
    c088:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c08f:	00 
    c090:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c097:	00 
    c098:	e8 63 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c09d:	48 89 c7             	mov    %rax,%rdi
    c0a0:	e8 3b a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c0a5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c0ac:	00 
    c0ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c0b2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c0b9:	00 
    c0ba:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c0c1:	00 
    c0c2:	e8 39 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c0c7:	48 89 c7             	mov    %rax,%rdi
    c0ca:	e8 11 a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c0cf:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c0d6:	00 
    c0d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c0dc:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c0e3:	00 
    c0e4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c0eb:	00 
    c0ec:	e8 0f a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c0f1:	48 89 c7             	mov    %rax,%rdi
    c0f4:	e8 e7 a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c0f9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c100:	00 
    c101:	bf 01 00 00 00       	mov    $0x1,%edi
    c106:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c10d:	00 
    c10e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c115:	00 
    c116:	e8 e5 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c11b:	48 89 c7             	mov    %rax,%rdi
    c11e:	e8 bd a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c123:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c12a:	00 
    c12b:	bf 01 00 00 00       	mov    $0x1,%edi
    c130:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c137:	00 
    c138:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c13f:	00 
    c140:	e8 bb 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c145:	48 89 c7             	mov    %rax,%rdi
    c148:	e8 93 a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c14d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c154:	00 
    c155:	bf 01 00 00 00       	mov    $0x1,%edi
    c15a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c161:	00 
    c162:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c169:	00 
    c16a:	e8 91 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c16f:	48 89 c7             	mov    %rax,%rdi
    c172:	e8 69 a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c177:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c17e:	00 
    c17f:	bf 01 00 00 00       	mov    $0x1,%edi
    c184:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c18b:	00 
    c18c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c193:	00 
    c194:	e8 67 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c199:	48 89 c7             	mov    %rax,%rdi
    c19c:	e8 3f a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c1a1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c1a8:	00 
    c1a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c1ae:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c1b5:	00 
    c1b6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c1bd:	00 
    c1be:	e8 3d 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c1c3:	48 89 c7             	mov    %rax,%rdi
    c1c6:	e8 15 a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c1cb:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c1d2:	00 
    c1d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c1d8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c1df:	00 
    c1e0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c1e7:	00 
    c1e8:	e8 13 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c1ed:	48 89 c7             	mov    %rax,%rdi
    c1f0:	e8 eb a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c1f5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c1fc:	00 
    c1fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c202:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c209:	00 
    c20a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c211:	00 
    c212:	e8 e9 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c217:	48 89 c7             	mov    %rax,%rdi
    c21a:	e8 c1 a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c21f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c226:	00 
    c227:	bf 01 00 00 00       	mov    $0x1,%edi
    c22c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c233:	00 
    c234:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c23b:	00 
    c23c:	e8 bf 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c241:	48 89 c7             	mov    %rax,%rdi
    c244:	e8 97 a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c249:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c250:	00 
    c251:	bf 01 00 00 00       	mov    $0x1,%edi
    c256:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c25d:	00 
    c25e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c265:	00 
    c266:	e8 95 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c26b:	48 89 c7             	mov    %rax,%rdi
    c26e:	e8 6d a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c273:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c27a:	00 
    c27b:	bf 01 00 00 00       	mov    $0x1,%edi
    c280:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c287:	00 
    c288:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c28f:	00 
    c290:	e8 6b 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c295:	48 89 c7             	mov    %rax,%rdi
    c298:	e8 43 a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c29d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c2a4:	00 
    c2a5:	bf 01 00 00 00       	mov    $0x1,%edi
    c2aa:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c2b1:	00 
    c2b2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c2b9:	00 
    c2ba:	e8 41 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c2bf:	48 89 c7             	mov    %rax,%rdi
    c2c2:	e8 19 a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c2c7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c2ce:	00 
    c2cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c2db:	00 
    c2dc:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c2e3:	00 
    c2e4:	e8 17 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c2e9:	48 89 c7             	mov    %rax,%rdi
    c2ec:	e8 ef a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c2f1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c2f8:	00 
    c2f9:	bf 01 00 00 00       	mov    $0x1,%edi
    c2fe:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c305:	00 
    c306:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c30d:	00 
    c30e:	e8 ed 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c313:	48 89 c7             	mov    %rax,%rdi
    c316:	e8 c5 a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c31b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c322:	00 
    c323:	bf 01 00 00 00       	mov    $0x1,%edi
    c328:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c32f:	00 
    c330:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c337:	00 
    c338:	e8 c3 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c33d:	48 89 c7             	mov    %rax,%rdi
    c340:	e8 9b a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c345:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c34c:	00 
    c34d:	bf 01 00 00 00       	mov    $0x1,%edi
    c352:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c359:	00 
    c35a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c361:	00 
    c362:	e8 99 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c367:	48 89 c7             	mov    %rax,%rdi
    c36a:	e8 71 a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c36f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c376:	00 
    c377:	bf 01 00 00 00       	mov    $0x1,%edi
    c37c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c383:	00 
    c384:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c38b:	00 
    c38c:	e8 6f 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c391:	48 89 c7             	mov    %rax,%rdi
    c394:	e8 47 a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c399:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c3a0:	00 
    c3a1:	bf 01 00 00 00       	mov    $0x1,%edi
    c3a6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c3ad:	00 
    c3ae:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c3b5:	00 
    c3b6:	e8 45 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c3bb:	48 89 c7             	mov    %rax,%rdi
    c3be:	e8 1d a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c3c3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c3ca:	00 
    c3cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c3d0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c3d7:	00 
    c3d8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c3df:	00 
    c3e0:	e8 1b 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c3e5:	48 8b 15 0c 08 06 00 	mov    0x6080c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c3ec:	49 89 c5             	mov    %rax,%r13
    c3ef:	48 2b 05 da 07 06 00 	sub    0x607da(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c3f6:	48 c1 e2 10          	shl    $0x10,%rdx
    c3fa:	48 39 d0             	cmp    %rdx,%rax
    c3fd:	73 59                	jae    c458 <f0+0x13b8>
    c3ff:	48 89 c2             	mov    %rax,%rdx
    c402:	48 c1 ea 10          	shr    $0x10,%rdx
    c406:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c40a:	48 8b 15 07 08 06 00 	mov    0x60807(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c411:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c415:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c419:	4d 85 e4             	test   %r12,%r12
    c41c:	74 3a                	je     c458 <f0+0x13b8>
    c41e:	0f b6 0a             	movzbl (%rdx),%ecx
    c421:	80 f9 02             	cmp    $0x2,%cl
    c424:	0f 84 c6 15 00 00    	je     d9f0 <f0+0x2950>
    c42a:	80 f9 01             	cmp    $0x1,%cl
    c42d:	75 29                	jne    c458 <f0+0x13b8>
    c42f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c432:	0f b7 c0             	movzwl %ax,%eax
    c435:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c438:	48 0f af c1          	imul   %rcx,%rax
    c43c:	48 c1 e8 20          	shr    $0x20,%rax
    c440:	48 39 d0             	cmp    %rdx,%rax
    c443:	73 13                	jae    c458 <f0+0x13b8>
    c445:	49 01 c4             	add    %rax,%r12
    c448:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c44d:	0f 84 99 17 00 00    	je     dbec <f0+0x2b4c>
    c453:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c458:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c45f:	33 f3 bf 
    c462:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c469:	00 
    c46a:	bf 01 00 00 00       	mov    $0x1,%edi
    c46f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c476:	00 
    c477:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c47e:	00 
    c47f:	e8 7c 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c484:	48 8b 15 6d 07 06 00 	mov    0x6076d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c48b:	49 89 c5             	mov    %rax,%r13
    c48e:	48 2b 05 3b 07 06 00 	sub    0x6073b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c495:	48 c1 e2 10          	shl    $0x10,%rdx
    c499:	48 39 d0             	cmp    %rdx,%rax
    c49c:	73 59                	jae    c4f7 <f0+0x1457>
    c49e:	48 89 c2             	mov    %rax,%rdx
    c4a1:	48 c1 ea 10          	shr    $0x10,%rdx
    c4a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c4a9:	48 8b 15 68 07 06 00 	mov    0x60768(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c4b0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c4b4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c4b8:	4d 85 e4             	test   %r12,%r12
    c4bb:	74 3a                	je     c4f7 <f0+0x1457>
    c4bd:	0f b6 0a             	movzbl (%rdx),%ecx
    c4c0:	80 f9 02             	cmp    $0x2,%cl
    c4c3:	0f 84 17 15 00 00    	je     d9e0 <f0+0x2940>
    c4c9:	80 f9 01             	cmp    $0x1,%cl
    c4cc:	75 29                	jne    c4f7 <f0+0x1457>
    c4ce:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c4d1:	0f b7 c0             	movzwl %ax,%eax
    c4d4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c4d7:	48 0f af c1          	imul   %rcx,%rax
    c4db:	48 c1 e8 20          	shr    $0x20,%rax
    c4df:	48 39 d0             	cmp    %rdx,%rax
    c4e2:	73 13                	jae    c4f7 <f0+0x1457>
    c4e4:	49 01 c4             	add    %rax,%r12
    c4e7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c4ec:	0f 84 07 17 00 00    	je     dbf9 <f0+0x2b59>
    c4f2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4f7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c4fe:	00 f0 3f 
    c501:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c508:	00 
    c509:	bf 01 00 00 00       	mov    $0x1,%edi
    c50e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c515:	00 
    c516:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c51d:	00 
    c51e:	e8 dd 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c523:	48 8b 15 ce 06 06 00 	mov    0x606ce(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c52a:	49 89 c5             	mov    %rax,%r13
    c52d:	48 2b 05 9c 06 06 00 	sub    0x6069c(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c534:	48 c1 e2 10          	shl    $0x10,%rdx
    c538:	48 39 d0             	cmp    %rdx,%rax
    c53b:	73 59                	jae    c596 <f0+0x14f6>
    c53d:	48 89 c2             	mov    %rax,%rdx
    c540:	48 c1 ea 10          	shr    $0x10,%rdx
    c544:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c548:	48 8b 15 c9 06 06 00 	mov    0x606c9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c54f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c553:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c557:	4d 85 e4             	test   %r12,%r12
    c55a:	74 3a                	je     c596 <f0+0x14f6>
    c55c:	0f b6 0a             	movzbl (%rdx),%ecx
    c55f:	80 f9 02             	cmp    $0x2,%cl
    c562:	0f 84 28 15 00 00    	je     da90 <f0+0x29f0>
    c568:	80 f9 01             	cmp    $0x1,%cl
    c56b:	75 29                	jne    c596 <f0+0x14f6>
    c56d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c570:	0f b7 c0             	movzwl %ax,%eax
    c573:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c576:	48 0f af c1          	imul   %rcx,%rax
    c57a:	48 c1 e8 20          	shr    $0x20,%rax
    c57e:	48 39 d0             	cmp    %rdx,%rax
    c581:	73 13                	jae    c596 <f0+0x14f6>
    c583:	49 01 c4             	add    %rax,%r12
    c586:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c58b:	0f 84 75 16 00 00    	je     dc06 <f0+0x2b66>
    c591:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c596:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c59d:	33 f3 bf 
    c5a0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c5a7:	00 
    c5a8:	bf 01 00 00 00       	mov    $0x1,%edi
    c5ad:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c5b4:	00 
    c5b5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c5bc:	00 
    c5bd:	e8 3e 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c5c2:	48 8b 15 2f 06 06 00 	mov    0x6062f(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c5c9:	49 89 c5             	mov    %rax,%r13
    c5cc:	48 2b 05 fd 05 06 00 	sub    0x605fd(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c5d3:	48 c1 e2 10          	shl    $0x10,%rdx
    c5d7:	48 39 d0             	cmp    %rdx,%rax
    c5da:	73 59                	jae    c635 <f0+0x1595>
    c5dc:	48 89 c2             	mov    %rax,%rdx
    c5df:	48 c1 ea 10          	shr    $0x10,%rdx
    c5e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5e7:	48 8b 15 2a 06 06 00 	mov    0x6062a(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c5ee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5f2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5f6:	4d 85 e4             	test   %r12,%r12
    c5f9:	74 3a                	je     c635 <f0+0x1595>
    c5fb:	0f b6 0a             	movzbl (%rdx),%ecx
    c5fe:	80 f9 02             	cmp    $0x2,%cl
    c601:	0f 84 79 14 00 00    	je     da80 <f0+0x29e0>
    c607:	80 f9 01             	cmp    $0x1,%cl
    c60a:	75 29                	jne    c635 <f0+0x1595>
    c60c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c60f:	0f b7 c0             	movzwl %ax,%eax
    c612:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c615:	48 0f af c1          	imul   %rcx,%rax
    c619:	48 c1 e8 20          	shr    $0x20,%rax
    c61d:	48 39 d0             	cmp    %rdx,%rax
    c620:	73 13                	jae    c635 <f0+0x1595>
    c622:	49 01 c4             	add    %rax,%r12
    c625:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c62a:	0f 84 e3 15 00 00    	je     dc13 <f0+0x2b73>
    c630:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c635:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c63c:	00 f0 3f 
    c63f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c646:	00 
    c647:	bf 01 00 00 00       	mov    $0x1,%edi
    c64c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c653:	00 
    c654:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c65b:	00 
    c65c:	e8 9f 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c661:	48 8b 15 90 05 06 00 	mov    0x60590(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c668:	49 89 c5             	mov    %rax,%r13
    c66b:	48 2b 05 5e 05 06 00 	sub    0x6055e(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c672:	48 c1 e2 10          	shl    $0x10,%rdx
    c676:	48 39 d0             	cmp    %rdx,%rax
    c679:	73 59                	jae    c6d4 <f0+0x1634>
    c67b:	48 89 c2             	mov    %rax,%rdx
    c67e:	48 c1 ea 10          	shr    $0x10,%rdx
    c682:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c686:	48 8b 15 8b 05 06 00 	mov    0x6058b(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c68d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c691:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c695:	4d 85 e4             	test   %r12,%r12
    c698:	74 3a                	je     c6d4 <f0+0x1634>
    c69a:	0f b6 0a             	movzbl (%rdx),%ecx
    c69d:	80 f9 02             	cmp    $0x2,%cl
    c6a0:	0f 84 ca 13 00 00    	je     da70 <f0+0x29d0>
    c6a6:	80 f9 01             	cmp    $0x1,%cl
    c6a9:	75 29                	jne    c6d4 <f0+0x1634>
    c6ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c6ae:	0f b7 c0             	movzwl %ax,%eax
    c6b1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c6b4:	48 0f af c1          	imul   %rcx,%rax
    c6b8:	48 c1 e8 20          	shr    $0x20,%rax
    c6bc:	48 39 d0             	cmp    %rdx,%rax
    c6bf:	73 13                	jae    c6d4 <f0+0x1634>
    c6c1:	49 01 c4             	add    %rax,%r12
    c6c4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6c9:	0f 84 51 15 00 00    	je     dc20 <f0+0x2b80>
    c6cf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6d4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c6db:	33 f3 bf 
    c6de:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c6e5:	00 
    c6e6:	bf 01 00 00 00       	mov    $0x1,%edi
    c6eb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c6f2:	00 
    c6f3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c6fa:	00 
    c6fb:	e8 00 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c700:	48 8b 15 f1 04 06 00 	mov    0x604f1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c707:	49 89 c5             	mov    %rax,%r13
    c70a:	48 2b 05 bf 04 06 00 	sub    0x604bf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c711:	48 c1 e2 10          	shl    $0x10,%rdx
    c715:	48 39 d0             	cmp    %rdx,%rax
    c718:	73 59                	jae    c773 <f0+0x16d3>
    c71a:	48 89 c2             	mov    %rax,%rdx
    c71d:	48 c1 ea 10          	shr    $0x10,%rdx
    c721:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c725:	48 8b 15 ec 04 06 00 	mov    0x604ec(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c72c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c730:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c734:	4d 85 e4             	test   %r12,%r12
    c737:	74 3a                	je     c773 <f0+0x16d3>
    c739:	0f b6 0a             	movzbl (%rdx),%ecx
    c73c:	80 f9 02             	cmp    $0x2,%cl
    c73f:	0f 84 1b 13 00 00    	je     da60 <f0+0x29c0>
    c745:	80 f9 01             	cmp    $0x1,%cl
    c748:	75 29                	jne    c773 <f0+0x16d3>
    c74a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c74d:	0f b7 c0             	movzwl %ax,%eax
    c750:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c753:	48 0f af c1          	imul   %rcx,%rax
    c757:	48 c1 e8 20          	shr    $0x20,%rax
    c75b:	48 39 d0             	cmp    %rdx,%rax
    c75e:	73 13                	jae    c773 <f0+0x16d3>
    c760:	49 01 c4             	add    %rax,%r12
    c763:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c768:	0f 84 bf 14 00 00    	je     dc2d <f0+0x2b8d>
    c76e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c773:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c77a:	00 f0 3f 
    c77d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c784:	00 
    c785:	bf 01 00 00 00       	mov    $0x1,%edi
    c78a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c791:	00 
    c792:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c799:	00 
    c79a:	e8 61 99 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c79f:	48 8b 15 52 04 06 00 	mov    0x60452(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c7a6:	49 89 c5             	mov    %rax,%r13
    c7a9:	48 2b 05 20 04 06 00 	sub    0x60420(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c7b0:	48 c1 e2 10          	shl    $0x10,%rdx
    c7b4:	48 39 d0             	cmp    %rdx,%rax
    c7b7:	73 59                	jae    c812 <f0+0x1772>
    c7b9:	48 89 c2             	mov    %rax,%rdx
    c7bc:	48 c1 ea 10          	shr    $0x10,%rdx
    c7c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7c4:	48 8b 15 4d 04 06 00 	mov    0x6044d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c7cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7cf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7d3:	4d 85 e4             	test   %r12,%r12
    c7d6:	74 3a                	je     c812 <f0+0x1772>
    c7d8:	0f b6 0a             	movzbl (%rdx),%ecx
    c7db:	80 f9 02             	cmp    $0x2,%cl
    c7de:	0f 84 6c 12 00 00    	je     da50 <f0+0x29b0>
    c7e4:	80 f9 01             	cmp    $0x1,%cl
    c7e7:	75 29                	jne    c812 <f0+0x1772>
    c7e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7ec:	0f b7 c0             	movzwl %ax,%eax
    c7ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7f2:	48 0f af c1          	imul   %rcx,%rax
    c7f6:	48 c1 e8 20          	shr    $0x20,%rax
    c7fa:	48 39 d0             	cmp    %rdx,%rax
    c7fd:	73 13                	jae    c812 <f0+0x1772>
    c7ff:	49 01 c4             	add    %rax,%r12
    c802:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c807:	0f 84 2d 14 00 00    	je     dc3a <f0+0x2b9a>
    c80d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c812:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c819:	33 f3 bf 
    c81c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c823:	00 
    c824:	bf 01 00 00 00       	mov    $0x1,%edi
    c829:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c830:	00 
    c831:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c838:	00 
    c839:	e8 c2 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c83e:	48 8b 15 b3 03 06 00 	mov    0x603b3(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c845:	49 89 c5             	mov    %rax,%r13
    c848:	48 2b 05 81 03 06 00 	sub    0x60381(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c84f:	48 c1 e2 10          	shl    $0x10,%rdx
    c853:	48 39 d0             	cmp    %rdx,%rax
    c856:	73 59                	jae    c8b1 <f0+0x1811>
    c858:	48 89 c2             	mov    %rax,%rdx
    c85b:	48 c1 ea 10          	shr    $0x10,%rdx
    c85f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c863:	48 8b 15 ae 03 06 00 	mov    0x603ae(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c86a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c86e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c872:	4d 85 e4             	test   %r12,%r12
    c875:	74 3a                	je     c8b1 <f0+0x1811>
    c877:	0f b6 0a             	movzbl (%rdx),%ecx
    c87a:	80 f9 02             	cmp    $0x2,%cl
    c87d:	0f 84 bd 11 00 00    	je     da40 <f0+0x29a0>
    c883:	80 f9 01             	cmp    $0x1,%cl
    c886:	75 29                	jne    c8b1 <f0+0x1811>
    c888:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c88b:	0f b7 c0             	movzwl %ax,%eax
    c88e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c891:	48 0f af c1          	imul   %rcx,%rax
    c895:	48 c1 e8 20          	shr    $0x20,%rax
    c899:	48 39 d0             	cmp    %rdx,%rax
    c89c:	73 13                	jae    c8b1 <f0+0x1811>
    c89e:	49 01 c4             	add    %rax,%r12
    c8a1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8a6:	0f 84 9b 13 00 00    	je     dc47 <f0+0x2ba7>
    c8ac:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8b1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c8b8:	00 f0 3f 
    c8bb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c8c2:	00 
    c8c3:	bf 01 00 00 00       	mov    $0x1,%edi
    c8c8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c8cf:	00 
    c8d0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c8d7:	00 
    c8d8:	e8 23 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c8dd:	48 8b 15 14 03 06 00 	mov    0x60314(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c8e4:	49 89 c5             	mov    %rax,%r13
    c8e7:	48 2b 05 e2 02 06 00 	sub    0x602e2(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c8ee:	48 c1 e2 10          	shl    $0x10,%rdx
    c8f2:	48 39 d0             	cmp    %rdx,%rax
    c8f5:	73 59                	jae    c950 <f0+0x18b0>
    c8f7:	48 89 c2             	mov    %rax,%rdx
    c8fa:	48 c1 ea 10          	shr    $0x10,%rdx
    c8fe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c902:	48 8b 15 0f 03 06 00 	mov    0x6030f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c909:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c90d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c911:	4d 85 e4             	test   %r12,%r12
    c914:	74 3a                	je     c950 <f0+0x18b0>
    c916:	0f b6 0a             	movzbl (%rdx),%ecx
    c919:	80 f9 02             	cmp    $0x2,%cl
    c91c:	0f 84 0e 11 00 00    	je     da30 <f0+0x2990>
    c922:	80 f9 01             	cmp    $0x1,%cl
    c925:	75 29                	jne    c950 <f0+0x18b0>
    c927:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c92a:	0f b7 c0             	movzwl %ax,%eax
    c92d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c930:	48 0f af c1          	imul   %rcx,%rax
    c934:	48 c1 e8 20          	shr    $0x20,%rax
    c938:	48 39 d0             	cmp    %rdx,%rax
    c93b:	73 13                	jae    c950 <f0+0x18b0>
    c93d:	49 01 c4             	add    %rax,%r12
    c940:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c945:	0f 84 09 13 00 00    	je     dc54 <f0+0x2bb4>
    c94b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c950:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c957:	33 f3 bf 
    c95a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c961:	00 
    c962:	bf 01 00 00 00       	mov    $0x1,%edi
    c967:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c96e:	00 
    c96f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c976:	00 
    c977:	e8 84 97 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c97c:	48 8b 15 75 02 06 00 	mov    0x60275(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c983:	49 89 c5             	mov    %rax,%r13
    c986:	48 2b 05 43 02 06 00 	sub    0x60243(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c98d:	48 c1 e2 10          	shl    $0x10,%rdx
    c991:	48 39 d0             	cmp    %rdx,%rax
    c994:	73 59                	jae    c9ef <f0+0x194f>
    c996:	48 89 c2             	mov    %rax,%rdx
    c999:	48 c1 ea 10          	shr    $0x10,%rdx
    c99d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9a1:	48 8b 15 70 02 06 00 	mov    0x60270(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c9a8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9ac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9b0:	4d 85 e4             	test   %r12,%r12
    c9b3:	74 3a                	je     c9ef <f0+0x194f>
    c9b5:	0f b6 0a             	movzbl (%rdx),%ecx
    c9b8:	80 f9 02             	cmp    $0x2,%cl
    c9bb:	0f 84 5f 10 00 00    	je     da20 <f0+0x2980>
    c9c1:	80 f9 01             	cmp    $0x1,%cl
    c9c4:	75 29                	jne    c9ef <f0+0x194f>
    c9c6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9c9:	0f b7 c0             	movzwl %ax,%eax
    c9cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9cf:	48 0f af c1          	imul   %rcx,%rax
    c9d3:	48 c1 e8 20          	shr    $0x20,%rax
    c9d7:	48 39 d0             	cmp    %rdx,%rax
    c9da:	73 13                	jae    c9ef <f0+0x194f>
    c9dc:	49 01 c4             	add    %rax,%r12
    c9df:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9e4:	0f 84 77 12 00 00    	je     dc61 <f0+0x2bc1>
    c9ea:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9ef:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9f6:	00 f0 3f 
    c9f9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    ca00:	00 
    ca01:	bf 01 00 00 00       	mov    $0x1,%edi
    ca06:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    ca0d:	00 
    ca0e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    ca15:	00 
    ca16:	e8 e5 96 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ca1b:	48 8b 15 d6 01 06 00 	mov    0x601d6(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    ca22:	49 89 c5             	mov    %rax,%r13
    ca25:	48 2b 05 a4 01 06 00 	sub    0x601a4(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    ca2c:	48 c1 e2 10          	shl    $0x10,%rdx
    ca30:	48 39 d0             	cmp    %rdx,%rax
    ca33:	73 59                	jae    ca8e <f0+0x19ee>
    ca35:	48 89 c2             	mov    %rax,%rdx
    ca38:	48 c1 ea 10          	shr    $0x10,%rdx
    ca3c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca40:	48 8b 15 d1 01 06 00 	mov    0x601d1(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ca47:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca4b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca4f:	4d 85 e4             	test   %r12,%r12
    ca52:	74 3a                	je     ca8e <f0+0x19ee>
    ca54:	0f b6 0a             	movzbl (%rdx),%ecx
    ca57:	80 f9 02             	cmp    $0x2,%cl
    ca5a:	0f 84 40 0f 00 00    	je     d9a0 <f0+0x2900>
    ca60:	80 f9 01             	cmp    $0x1,%cl
    ca63:	75 29                	jne    ca8e <f0+0x19ee>
    ca65:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca68:	0f b7 c0             	movzwl %ax,%eax
    ca6b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca6e:	48 0f af c1          	imul   %rcx,%rax
    ca72:	48 c1 e8 20          	shr    $0x20,%rax
    ca76:	48 39 d0             	cmp    %rdx,%rax
    ca79:	73 13                	jae    ca8e <f0+0x19ee>
    ca7b:	49 01 c4             	add    %rax,%r12
    ca7e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca83:	0f 84 e5 11 00 00    	je     dc6e <f0+0x2bce>
    ca89:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca8e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca95:	33 f3 bf 
    ca98:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    ca9f:	00 
    caa0:	bf 01 00 00 00       	mov    $0x1,%edi
    caa5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    caac:	00 
    caad:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cab4:	00 
    cab5:	e8 46 96 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    caba:	48 8b 15 37 01 06 00 	mov    0x60137(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cac1:	49 89 c5             	mov    %rax,%r13
    cac4:	48 2b 05 05 01 06 00 	sub    0x60105(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cacb:	48 c1 e2 10          	shl    $0x10,%rdx
    cacf:	48 39 d0             	cmp    %rdx,%rax
    cad2:	73 59                	jae    cb2d <f0+0x1a8d>
    cad4:	48 89 c2             	mov    %rax,%rdx
    cad7:	48 c1 ea 10          	shr    $0x10,%rdx
    cadb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cadf:	48 8b 15 32 01 06 00 	mov    0x60132(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cae6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    caea:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    caee:	4d 85 e4             	test   %r12,%r12
    caf1:	74 3a                	je     cb2d <f0+0x1a8d>
    caf3:	0f b6 0a             	movzbl (%rdx),%ecx
    caf6:	80 f9 02             	cmp    $0x2,%cl
    caf9:	0f 84 91 0e 00 00    	je     d990 <f0+0x28f0>
    caff:	80 f9 01             	cmp    $0x1,%cl
    cb02:	75 29                	jne    cb2d <f0+0x1a8d>
    cb04:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb07:	0f b7 c0             	movzwl %ax,%eax
    cb0a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb0d:	48 0f af c1          	imul   %rcx,%rax
    cb11:	48 c1 e8 20          	shr    $0x20,%rax
    cb15:	48 39 d0             	cmp    %rdx,%rax
    cb18:	73 13                	jae    cb2d <f0+0x1a8d>
    cb1a:	49 01 c4             	add    %rax,%r12
    cb1d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb22:	0f 84 53 11 00 00    	je     dc7b <f0+0x2bdb>
    cb28:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb2d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb34:	00 f0 3f 
    cb37:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    cb3e:	00 
    cb3f:	bf 01 00 00 00       	mov    $0x1,%edi
    cb44:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cb4b:	00 
    cb4c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cb53:	00 
    cb54:	e8 a7 95 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cb59:	48 8b 15 98 00 06 00 	mov    0x60098(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cb60:	49 89 c5             	mov    %rax,%r13
    cb63:	48 2b 05 66 00 06 00 	sub    0x60066(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cb6a:	48 c1 e2 10          	shl    $0x10,%rdx
    cb6e:	48 39 d0             	cmp    %rdx,%rax
    cb71:	73 59                	jae    cbcc <f0+0x1b2c>
    cb73:	48 89 c2             	mov    %rax,%rdx
    cb76:	48 c1 ea 10          	shr    $0x10,%rdx
    cb7a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb7e:	48 8b 15 93 00 06 00 	mov    0x60093(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cb85:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb89:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb8d:	4d 85 e4             	test   %r12,%r12
    cb90:	74 3a                	je     cbcc <f0+0x1b2c>
    cb92:	0f b6 0a             	movzbl (%rdx),%ecx
    cb95:	80 f9 02             	cmp    $0x2,%cl
    cb98:	0f 84 e2 0d 00 00    	je     d980 <f0+0x28e0>
    cb9e:	80 f9 01             	cmp    $0x1,%cl
    cba1:	75 29                	jne    cbcc <f0+0x1b2c>
    cba3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cba6:	0f b7 c0             	movzwl %ax,%eax
    cba9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbac:	48 0f af c1          	imul   %rcx,%rax
    cbb0:	48 c1 e8 20          	shr    $0x20,%rax
    cbb4:	48 39 d0             	cmp    %rdx,%rax
    cbb7:	73 13                	jae    cbcc <f0+0x1b2c>
    cbb9:	49 01 c4             	add    %rax,%r12
    cbbc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cbc1:	0f 84 c1 10 00 00    	je     dc88 <f0+0x2be8>
    cbc7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbcc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbd3:	33 f3 bf 
    cbd6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cbdd:	00 
    cbde:	bf 01 00 00 00       	mov    $0x1,%edi
    cbe3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    cbea:	00 
    cbeb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cbf2:	00 
    cbf3:	e8 08 95 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cbf8:	48 8b 15 f9 ff 05 00 	mov    0x5fff9(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cbff:	49 89 c5             	mov    %rax,%r13
    cc02:	48 2b 05 c7 ff 05 00 	sub    0x5ffc7(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cc09:	48 c1 e2 10          	shl    $0x10,%rdx
    cc0d:	48 39 d0             	cmp    %rdx,%rax
    cc10:	73 59                	jae    cc6b <f0+0x1bcb>
    cc12:	48 89 c2             	mov    %rax,%rdx
    cc15:	48 c1 ea 10          	shr    $0x10,%rdx
    cc19:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc1d:	48 8b 15 f4 ff 05 00 	mov    0x5fff4(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cc24:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc28:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc2c:	4d 85 e4             	test   %r12,%r12
    cc2f:	74 3a                	je     cc6b <f0+0x1bcb>
    cc31:	0f b6 0a             	movzbl (%rdx),%ecx
    cc34:	80 f9 02             	cmp    $0x2,%cl
    cc37:	0f 84 33 0d 00 00    	je     d970 <f0+0x28d0>
    cc3d:	80 f9 01             	cmp    $0x1,%cl
    cc40:	75 29                	jne    cc6b <f0+0x1bcb>
    cc42:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc45:	0f b7 c0             	movzwl %ax,%eax
    cc48:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc4b:	48 0f af c1          	imul   %rcx,%rax
    cc4f:	48 c1 e8 20          	shr    $0x20,%rax
    cc53:	48 39 d0             	cmp    %rdx,%rax
    cc56:	73 13                	jae    cc6b <f0+0x1bcb>
    cc58:	49 01 c4             	add    %rax,%r12
    cc5b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc60:	0f 84 2f 10 00 00    	je     dc95 <f0+0x2bf5>
    cc66:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc6b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc72:	00 f0 3f 
    cc75:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    cc7c:	00 
    cc7d:	bf 01 00 00 00       	mov    $0x1,%edi
    cc82:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    cc89:	00 
    cc8a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    cc91:	00 
    cc92:	e8 69 94 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cc97:	48 8b 15 5a ff 05 00 	mov    0x5ff5a(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cc9e:	49 89 c5             	mov    %rax,%r13
    cca1:	48 2b 05 28 ff 05 00 	sub    0x5ff28(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cca8:	48 c1 e2 10          	shl    $0x10,%rdx
    ccac:	48 39 d0             	cmp    %rdx,%rax
    ccaf:	73 59                	jae    cd0a <f0+0x1c6a>
    ccb1:	48 89 c2             	mov    %rax,%rdx
    ccb4:	48 c1 ea 10          	shr    $0x10,%rdx
    ccb8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ccbc:	48 8b 15 55 ff 05 00 	mov    0x5ff55(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ccc3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccc7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cccb:	4d 85 e4             	test   %r12,%r12
    ccce:	74 3a                	je     cd0a <f0+0x1c6a>
    ccd0:	0f b6 0a             	movzbl (%rdx),%ecx
    ccd3:	80 f9 02             	cmp    $0x2,%cl
    ccd6:	0f 84 84 0c 00 00    	je     d960 <f0+0x28c0>
    ccdc:	80 f9 01             	cmp    $0x1,%cl
    ccdf:	75 29                	jne    cd0a <f0+0x1c6a>
    cce1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cce4:	0f b7 c0             	movzwl %ax,%eax
    cce7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccea:	48 0f af c1          	imul   %rcx,%rax
    ccee:	48 c1 e8 20          	shr    $0x20,%rax
    ccf2:	48 39 d0             	cmp    %rdx,%rax
    ccf5:	73 13                	jae    cd0a <f0+0x1c6a>
    ccf7:	49 01 c4             	add    %rax,%r12
    ccfa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ccff:	0f 84 9d 0f 00 00    	je     dca2 <f0+0x2c02>
    cd05:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd0a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd11:	33 f3 bf 
    cd14:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    cd1b:	00 
    cd1c:	bf 01 00 00 00       	mov    $0x1,%edi
    cd21:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    cd28:	00 
    cd29:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    cd30:	00 
    cd31:	e8 ca 93 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cd36:	48 8b 15 bb fe 05 00 	mov    0x5febb(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cd3d:	49 89 c5             	mov    %rax,%r13
    cd40:	48 2b 05 89 fe 05 00 	sub    0x5fe89(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cd47:	48 c1 e2 10          	shl    $0x10,%rdx
    cd4b:	48 39 d0             	cmp    %rdx,%rax
    cd4e:	73 59                	jae    cda9 <f0+0x1d09>
    cd50:	48 89 c2             	mov    %rax,%rdx
    cd53:	48 c1 ea 10          	shr    $0x10,%rdx
    cd57:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd5b:	48 8b 15 b6 fe 05 00 	mov    0x5feb6(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cd62:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd66:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd6a:	4d 85 e4             	test   %r12,%r12
    cd6d:	74 3a                	je     cda9 <f0+0x1d09>
    cd6f:	0f b6 0a             	movzbl (%rdx),%ecx
    cd72:	80 f9 02             	cmp    $0x2,%cl
    cd75:	0f 84 d5 0b 00 00    	je     d950 <f0+0x28b0>
    cd7b:	80 f9 01             	cmp    $0x1,%cl
    cd7e:	75 29                	jne    cda9 <f0+0x1d09>
    cd80:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd83:	0f b7 c0             	movzwl %ax,%eax
    cd86:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd89:	48 0f af c1          	imul   %rcx,%rax
    cd8d:	48 c1 e8 20          	shr    $0x20,%rax
    cd91:	48 39 d0             	cmp    %rdx,%rax
    cd94:	73 13                	jae    cda9 <f0+0x1d09>
    cd96:	49 01 c4             	add    %rax,%r12
    cd99:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd9e:	0f 84 0b 0f 00 00    	je     dcaf <f0+0x2c0f>
    cda4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cda9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdb0:	00 f0 3f 
    cdb3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    cdba:	00 
    cdbb:	bf 01 00 00 00       	mov    $0x1,%edi
    cdc0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    cdc7:	00 
    cdc8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    cdcf:	00 
    cdd0:	e8 2b 93 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cdd5:	48 8b 15 1c fe 05 00 	mov    0x5fe1c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cddc:	49 89 c5             	mov    %rax,%r13
    cddf:	48 2b 05 ea fd 05 00 	sub    0x5fdea(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cde6:	48 c1 e2 10          	shl    $0x10,%rdx
    cdea:	48 39 d0             	cmp    %rdx,%rax
    cded:	73 59                	jae    ce48 <f0+0x1da8>
    cdef:	48 89 c2             	mov    %rax,%rdx
    cdf2:	48 c1 ea 10          	shr    $0x10,%rdx
    cdf6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdfa:	48 8b 15 17 fe 05 00 	mov    0x5fe17(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ce01:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce05:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce09:	4d 85 e4             	test   %r12,%r12
    ce0c:	74 3a                	je     ce48 <f0+0x1da8>
    ce0e:	0f b6 0a             	movzbl (%rdx),%ecx
    ce11:	80 f9 02             	cmp    $0x2,%cl
    ce14:	0f 84 26 0b 00 00    	je     d940 <f0+0x28a0>
    ce1a:	80 f9 01             	cmp    $0x1,%cl
    ce1d:	75 29                	jne    ce48 <f0+0x1da8>
    ce1f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce22:	0f b7 c0             	movzwl %ax,%eax
    ce25:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce28:	48 0f af c1          	imul   %rcx,%rax
    ce2c:	48 c1 e8 20          	shr    $0x20,%rax
    ce30:	48 39 d0             	cmp    %rdx,%rax
    ce33:	73 13                	jae    ce48 <f0+0x1da8>
    ce35:	49 01 c4             	add    %rax,%r12
    ce38:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce3d:	0f 84 79 0e 00 00    	je     dcbc <f0+0x2c1c>
    ce43:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce48:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce4f:	33 f3 bf 
    ce52:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    ce59:	00 
    ce5a:	bf 01 00 00 00       	mov    $0x1,%edi
    ce5f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    ce66:	00 
    ce67:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    ce6e:	00 
    ce6f:	e8 8c 92 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ce74:	48 8b 15 7d fd 05 00 	mov    0x5fd7d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    ce7b:	49 89 c5             	mov    %rax,%r13
    ce7e:	48 2b 05 4b fd 05 00 	sub    0x5fd4b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    ce85:	48 c1 e2 10          	shl    $0x10,%rdx
    ce89:	48 39 d0             	cmp    %rdx,%rax
    ce8c:	73 59                	jae    cee7 <f0+0x1e47>
    ce8e:	48 89 c2             	mov    %rax,%rdx
    ce91:	48 c1 ea 10          	shr    $0x10,%rdx
    ce95:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce99:	48 8b 15 78 fd 05 00 	mov    0x5fd78(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cea0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cea4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cea8:	4d 85 e4             	test   %r12,%r12
    ceab:	74 3a                	je     cee7 <f0+0x1e47>
    cead:	0f b6 0a             	movzbl (%rdx),%ecx
    ceb0:	80 f9 02             	cmp    $0x2,%cl
    ceb3:	0f 84 77 0a 00 00    	je     d930 <f0+0x2890>
    ceb9:	80 f9 01             	cmp    $0x1,%cl
    cebc:	75 29                	jne    cee7 <f0+0x1e47>
    cebe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cec1:	0f b7 c0             	movzwl %ax,%eax
    cec4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cec7:	48 0f af c1          	imul   %rcx,%rax
    cecb:	48 c1 e8 20          	shr    $0x20,%rax
    cecf:	48 39 d0             	cmp    %rdx,%rax
    ced2:	73 13                	jae    cee7 <f0+0x1e47>
    ced4:	49 01 c4             	add    %rax,%r12
    ced7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cedc:	0f 84 e7 0d 00 00    	je     dcc9 <f0+0x2c29>
    cee2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cee7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ceee:	00 f0 3f 
    cef1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    cef8:	00 
    cef9:	bf 01 00 00 00       	mov    $0x1,%edi
    cefe:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    cf05:	00 
    cf06:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    cf0d:	00 
    cf0e:	e8 ed 91 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cf13:	48 8b 15 de fc 05 00 	mov    0x5fcde(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cf1a:	49 89 c5             	mov    %rax,%r13
    cf1d:	48 2b 05 ac fc 05 00 	sub    0x5fcac(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cf24:	48 c1 e2 10          	shl    $0x10,%rdx
    cf28:	48 39 d0             	cmp    %rdx,%rax
    cf2b:	73 59                	jae    cf86 <f0+0x1ee6>
    cf2d:	48 89 c2             	mov    %rax,%rdx
    cf30:	48 c1 ea 10          	shr    $0x10,%rdx
    cf34:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf38:	48 8b 15 d9 fc 05 00 	mov    0x5fcd9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cf3f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf43:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf47:	4d 85 e4             	test   %r12,%r12
    cf4a:	74 3a                	je     cf86 <f0+0x1ee6>
    cf4c:	0f b6 0a             	movzbl (%rdx),%ecx
    cf4f:	80 f9 02             	cmp    $0x2,%cl
    cf52:	0f 84 38 0c 00 00    	je     db90 <f0+0x2af0>
    cf58:	80 f9 01             	cmp    $0x1,%cl
    cf5b:	75 29                	jne    cf86 <f0+0x1ee6>
    cf5d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf60:	0f b7 c0             	movzwl %ax,%eax
    cf63:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf66:	48 0f af c1          	imul   %rcx,%rax
    cf6a:	48 c1 e8 20          	shr    $0x20,%rax
    cf6e:	48 39 d0             	cmp    %rdx,%rax
    cf71:	73 13                	jae    cf86 <f0+0x1ee6>
    cf73:	49 01 c4             	add    %rax,%r12
    cf76:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf7b:	0f 84 55 0d 00 00    	je     dcd6 <f0+0x2c36>
    cf81:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf86:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf8d:	33 f3 bf 
    cf90:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    cf97:	00 
    cf98:	bf 01 00 00 00       	mov    $0x1,%edi
    cf9d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    cfa4:	00 
    cfa5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    cfac:	00 
    cfad:	e8 4e 91 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cfb2:	48 8b 15 3f fc 05 00 	mov    0x5fc3f(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cfb9:	49 89 c5             	mov    %rax,%r13
    cfbc:	48 2b 05 0d fc 05 00 	sub    0x5fc0d(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cfc3:	48 c1 e2 10          	shl    $0x10,%rdx
    cfc7:	48 39 d0             	cmp    %rdx,%rax
    cfca:	73 59                	jae    d025 <f0+0x1f85>
    cfcc:	48 89 c2             	mov    %rax,%rdx
    cfcf:	48 c1 ea 10          	shr    $0x10,%rdx
    cfd3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfd7:	48 8b 15 3a fc 05 00 	mov    0x5fc3a(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cfde:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfe2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfe6:	4d 85 e4             	test   %r12,%r12
    cfe9:	74 3a                	je     d025 <f0+0x1f85>
    cfeb:	0f b6 0a             	movzbl (%rdx),%ecx
    cfee:	80 f9 02             	cmp    $0x2,%cl
    cff1:	0f 84 89 0b 00 00    	je     db80 <f0+0x2ae0>
    cff7:	80 f9 01             	cmp    $0x1,%cl
    cffa:	75 29                	jne    d025 <f0+0x1f85>
    cffc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfff:	0f b7 c0             	movzwl %ax,%eax
    d002:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d005:	48 0f af c1          	imul   %rcx,%rax
    d009:	48 c1 e8 20          	shr    $0x20,%rax
    d00d:	48 39 d0             	cmp    %rdx,%rax
    d010:	73 13                	jae    d025 <f0+0x1f85>
    d012:	49 01 c4             	add    %rax,%r12
    d015:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d01a:	0f 84 c3 0c 00 00    	je     dce3 <f0+0x2c43>
    d020:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d025:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d02c:	00 f0 3f 
    d02f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d036:	00 
    d037:	bf 01 00 00 00       	mov    $0x1,%edi
    d03c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d043:	00 
    d044:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d04b:	00 
    d04c:	e8 af 90 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d051:	48 8b 15 a0 fb 05 00 	mov    0x5fba0(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d058:	49 89 c5             	mov    %rax,%r13
    d05b:	48 2b 05 6e fb 05 00 	sub    0x5fb6e(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d062:	48 c1 e2 10          	shl    $0x10,%rdx
    d066:	48 39 d0             	cmp    %rdx,%rax
    d069:	73 59                	jae    d0c4 <f0+0x2024>
    d06b:	48 89 c2             	mov    %rax,%rdx
    d06e:	48 c1 ea 10          	shr    $0x10,%rdx
    d072:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d076:	48 8b 15 9b fb 05 00 	mov    0x5fb9b(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d07d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d081:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d085:	4d 85 e4             	test   %r12,%r12
    d088:	74 3a                	je     d0c4 <f0+0x2024>
    d08a:	0f b6 0a             	movzbl (%rdx),%ecx
    d08d:	80 f9 02             	cmp    $0x2,%cl
    d090:	0f 84 da 0a 00 00    	je     db70 <f0+0x2ad0>
    d096:	80 f9 01             	cmp    $0x1,%cl
    d099:	75 29                	jne    d0c4 <f0+0x2024>
    d09b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d09e:	0f b7 c0             	movzwl %ax,%eax
    d0a1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0a4:	48 0f af c1          	imul   %rcx,%rax
    d0a8:	48 c1 e8 20          	shr    $0x20,%rax
    d0ac:	48 39 d0             	cmp    %rdx,%rax
    d0af:	73 13                	jae    d0c4 <f0+0x2024>
    d0b1:	49 01 c4             	add    %rax,%r12
    d0b4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0b9:	0f 84 31 0c 00 00    	je     dcf0 <f0+0x2c50>
    d0bf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0c4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0cb:	33 f3 bf 
    d0ce:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d0d5:	00 
    d0d6:	bf 01 00 00 00       	mov    $0x1,%edi
    d0db:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d0e2:	00 
    d0e3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d0ea:	00 
    d0eb:	e8 10 90 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d0f0:	48 8b 15 01 fb 05 00 	mov    0x5fb01(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d0f7:	49 89 c5             	mov    %rax,%r13
    d0fa:	48 2b 05 cf fa 05 00 	sub    0x5facf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d101:	48 c1 e2 10          	shl    $0x10,%rdx
    d105:	48 39 d0             	cmp    %rdx,%rax
    d108:	73 59                	jae    d163 <f0+0x20c3>
    d10a:	48 89 c2             	mov    %rax,%rdx
    d10d:	48 c1 ea 10          	shr    $0x10,%rdx
    d111:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d115:	48 8b 15 fc fa 05 00 	mov    0x5fafc(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d11c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d120:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d124:	4d 85 e4             	test   %r12,%r12
    d127:	74 3a                	je     d163 <f0+0x20c3>
    d129:	0f b6 0a             	movzbl (%rdx),%ecx
    d12c:	80 f9 02             	cmp    $0x2,%cl
    d12f:	0f 84 2b 0a 00 00    	je     db60 <f0+0x2ac0>
    d135:	80 f9 01             	cmp    $0x1,%cl
    d138:	75 29                	jne    d163 <f0+0x20c3>
    d13a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d13d:	0f b7 c0             	movzwl %ax,%eax
    d140:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d143:	48 0f af c1          	imul   %rcx,%rax
    d147:	48 c1 e8 20          	shr    $0x20,%rax
    d14b:	48 39 d0             	cmp    %rdx,%rax
    d14e:	73 13                	jae    d163 <f0+0x20c3>
    d150:	49 01 c4             	add    %rax,%r12
    d153:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d158:	0f 84 9f 0b 00 00    	je     dcfd <f0+0x2c5d>
    d15e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d163:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d16a:	00 f0 3f 
    d16d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d174:	00 
    d175:	bf 01 00 00 00       	mov    $0x1,%edi
    d17a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d181:	00 
    d182:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d189:	00 
    d18a:	e8 71 8f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d18f:	48 8b 15 62 fa 05 00 	mov    0x5fa62(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d196:	49 89 c5             	mov    %rax,%r13
    d199:	48 2b 05 30 fa 05 00 	sub    0x5fa30(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d1a0:	48 c1 e2 10          	shl    $0x10,%rdx
    d1a4:	48 39 d0             	cmp    %rdx,%rax
    d1a7:	73 59                	jae    d202 <f0+0x2162>
    d1a9:	48 89 c2             	mov    %rax,%rdx
    d1ac:	48 c1 ea 10          	shr    $0x10,%rdx
    d1b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1b4:	48 8b 15 5d fa 05 00 	mov    0x5fa5d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d1bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1bf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1c3:	4d 85 e4             	test   %r12,%r12
    d1c6:	74 3a                	je     d202 <f0+0x2162>
    d1c8:	0f b6 0a             	movzbl (%rdx),%ecx
    d1cb:	80 f9 02             	cmp    $0x2,%cl
    d1ce:	0f 84 7c 09 00 00    	je     db50 <f0+0x2ab0>
    d1d4:	80 f9 01             	cmp    $0x1,%cl
    d1d7:	75 29                	jne    d202 <f0+0x2162>
    d1d9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1dc:	0f b7 c0             	movzwl %ax,%eax
    d1df:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1e2:	48 0f af c1          	imul   %rcx,%rax
    d1e6:	48 c1 e8 20          	shr    $0x20,%rax
    d1ea:	48 39 d0             	cmp    %rdx,%rax
    d1ed:	73 13                	jae    d202 <f0+0x2162>
    d1ef:	49 01 c4             	add    %rax,%r12
    d1f2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1f7:	0f 84 0d 0b 00 00    	je     dd0a <f0+0x2c6a>
    d1fd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d202:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d209:	33 f3 bf 
    d20c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d213:	00 
    d214:	bf 01 00 00 00       	mov    $0x1,%edi
    d219:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d220:	00 
    d221:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d228:	00 
    d229:	e8 d2 8e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d22e:	48 8b 15 c3 f9 05 00 	mov    0x5f9c3(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d235:	49 89 c5             	mov    %rax,%r13
    d238:	48 2b 05 91 f9 05 00 	sub    0x5f991(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d23f:	48 c1 e2 10          	shl    $0x10,%rdx
    d243:	48 39 d0             	cmp    %rdx,%rax
    d246:	73 59                	jae    d2a1 <f0+0x2201>
    d248:	48 89 c2             	mov    %rax,%rdx
    d24b:	48 c1 ea 10          	shr    $0x10,%rdx
    d24f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d253:	48 8b 15 be f9 05 00 	mov    0x5f9be(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d25a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d25e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d262:	4d 85 e4             	test   %r12,%r12
    d265:	74 3a                	je     d2a1 <f0+0x2201>
    d267:	0f b6 0a             	movzbl (%rdx),%ecx
    d26a:	80 f9 02             	cmp    $0x2,%cl
    d26d:	0f 84 cd 08 00 00    	je     db40 <f0+0x2aa0>
    d273:	80 f9 01             	cmp    $0x1,%cl
    d276:	75 29                	jne    d2a1 <f0+0x2201>
    d278:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d27b:	0f b7 c0             	movzwl %ax,%eax
    d27e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d281:	48 0f af c1          	imul   %rcx,%rax
    d285:	48 c1 e8 20          	shr    $0x20,%rax
    d289:	48 39 d0             	cmp    %rdx,%rax
    d28c:	73 13                	jae    d2a1 <f0+0x2201>
    d28e:	49 01 c4             	add    %rax,%r12
    d291:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d296:	0f 84 7b 0a 00 00    	je     dd17 <f0+0x2c77>
    d29c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2a1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2a8:	00 f0 3f 
    d2ab:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d2b2:	00 
    d2b3:	bf 01 00 00 00       	mov    $0x1,%edi
    d2b8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d2bf:	00 
    d2c0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d2c7:	00 
    d2c8:	e8 33 8e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d2cd:	48 8b 15 24 f9 05 00 	mov    0x5f924(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d2d4:	49 89 c5             	mov    %rax,%r13
    d2d7:	48 2b 05 f2 f8 05 00 	sub    0x5f8f2(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d2de:	48 c1 e2 10          	shl    $0x10,%rdx
    d2e2:	48 39 d0             	cmp    %rdx,%rax
    d2e5:	73 59                	jae    d340 <f0+0x22a0>
    d2e7:	48 89 c2             	mov    %rax,%rdx
    d2ea:	48 c1 ea 10          	shr    $0x10,%rdx
    d2ee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2f2:	48 8b 15 1f f9 05 00 	mov    0x5f91f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d2f9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2fd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d301:	4d 85 e4             	test   %r12,%r12
    d304:	74 3a                	je     d340 <f0+0x22a0>
    d306:	0f b6 0a             	movzbl (%rdx),%ecx
    d309:	80 f9 02             	cmp    $0x2,%cl
    d30c:	0f 84 1e 08 00 00    	je     db30 <f0+0x2a90>
    d312:	80 f9 01             	cmp    $0x1,%cl
    d315:	75 29                	jne    d340 <f0+0x22a0>
    d317:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d31a:	0f b7 c0             	movzwl %ax,%eax
    d31d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d320:	48 0f af c1          	imul   %rcx,%rax
    d324:	48 c1 e8 20          	shr    $0x20,%rax
    d328:	48 39 d0             	cmp    %rdx,%rax
    d32b:	73 13                	jae    d340 <f0+0x22a0>
    d32d:	49 01 c4             	add    %rax,%r12
    d330:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d335:	0f 84 e9 09 00 00    	je     dd24 <f0+0x2c84>
    d33b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d340:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d347:	33 f3 bf 
    d34a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d351:	00 
    d352:	bf 01 00 00 00       	mov    $0x1,%edi
    d357:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d35e:	00 
    d35f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d366:	00 
    d367:	e8 94 8d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d36c:	48 8b 15 85 f8 05 00 	mov    0x5f885(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d373:	49 89 c5             	mov    %rax,%r13
    d376:	48 2b 05 53 f8 05 00 	sub    0x5f853(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d37d:	48 c1 e2 10          	shl    $0x10,%rdx
    d381:	48 39 d0             	cmp    %rdx,%rax
    d384:	73 59                	jae    d3df <f0+0x233f>
    d386:	48 89 c2             	mov    %rax,%rdx
    d389:	48 c1 ea 10          	shr    $0x10,%rdx
    d38d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d391:	48 8b 15 80 f8 05 00 	mov    0x5f880(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d398:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d39c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3a0:	4d 85 e4             	test   %r12,%r12
    d3a3:	74 3a                	je     d3df <f0+0x233f>
    d3a5:	0f b6 0a             	movzbl (%rdx),%ecx
    d3a8:	80 f9 02             	cmp    $0x2,%cl
    d3ab:	0f 84 6f 07 00 00    	je     db20 <f0+0x2a80>
    d3b1:	80 f9 01             	cmp    $0x1,%cl
    d3b4:	75 29                	jne    d3df <f0+0x233f>
    d3b6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3b9:	0f b7 c0             	movzwl %ax,%eax
    d3bc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3bf:	48 0f af c1          	imul   %rcx,%rax
    d3c3:	48 c1 e8 20          	shr    $0x20,%rax
    d3c7:	48 39 d0             	cmp    %rdx,%rax
    d3ca:	73 13                	jae    d3df <f0+0x233f>
    d3cc:	49 01 c4             	add    %rax,%r12
    d3cf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3d4:	0f 84 57 09 00 00    	je     dd31 <f0+0x2c91>
    d3da:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3df:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3e6:	00 f0 3f 
    d3e9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d3f0:	00 
    d3f1:	bf 01 00 00 00       	mov    $0x1,%edi
    d3f6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d3fd:	00 
    d3fe:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d405:	00 
    d406:	e8 f5 8c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d40b:	48 8b 15 e6 f7 05 00 	mov    0x5f7e6(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d412:	49 89 c5             	mov    %rax,%r13
    d415:	48 2b 05 b4 f7 05 00 	sub    0x5f7b4(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d41c:	48 c1 e2 10          	shl    $0x10,%rdx
    d420:	48 39 d0             	cmp    %rdx,%rax
    d423:	73 59                	jae    d47e <f0+0x23de>
    d425:	48 89 c2             	mov    %rax,%rdx
    d428:	48 c1 ea 10          	shr    $0x10,%rdx
    d42c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d430:	48 8b 15 e1 f7 05 00 	mov    0x5f7e1(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d437:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d43b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d43f:	4d 85 e4             	test   %r12,%r12
    d442:	74 3a                	je     d47e <f0+0x23de>
    d444:	0f b6 0a             	movzbl (%rdx),%ecx
    d447:	80 f9 02             	cmp    $0x2,%cl
    d44a:	0f 84 c0 06 00 00    	je     db10 <f0+0x2a70>
    d450:	80 f9 01             	cmp    $0x1,%cl
    d453:	75 29                	jne    d47e <f0+0x23de>
    d455:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d458:	0f b7 c0             	movzwl %ax,%eax
    d45b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d45e:	48 0f af c1          	imul   %rcx,%rax
    d462:	48 c1 e8 20          	shr    $0x20,%rax
    d466:	48 39 d0             	cmp    %rdx,%rax
    d469:	73 13                	jae    d47e <f0+0x23de>
    d46b:	49 01 c4             	add    %rax,%r12
    d46e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d473:	0f 84 c5 08 00 00    	je     dd3e <f0+0x2c9e>
    d479:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d47e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d485:	33 f3 bf 
    d488:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d48f:	00 
    d490:	bf 01 00 00 00       	mov    $0x1,%edi
    d495:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d49c:	00 
    d49d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d4a4:	00 
    d4a5:	e8 56 8c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d4aa:	48 8b 15 47 f7 05 00 	mov    0x5f747(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d4b1:	49 89 c5             	mov    %rax,%r13
    d4b4:	48 2b 05 15 f7 05 00 	sub    0x5f715(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d4bb:	48 c1 e2 10          	shl    $0x10,%rdx
    d4bf:	48 39 d0             	cmp    %rdx,%rax
    d4c2:	73 59                	jae    d51d <f0+0x247d>
    d4c4:	48 89 c2             	mov    %rax,%rdx
    d4c7:	48 c1 ea 10          	shr    $0x10,%rdx
    d4cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4cf:	48 8b 15 42 f7 05 00 	mov    0x5f742(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d4d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4da:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4de:	4d 85 e4             	test   %r12,%r12
    d4e1:	74 3a                	je     d51d <f0+0x247d>
    d4e3:	0f b6 0a             	movzbl (%rdx),%ecx
    d4e6:	80 f9 02             	cmp    $0x2,%cl
    d4e9:	0f 84 11 06 00 00    	je     db00 <f0+0x2a60>
    d4ef:	80 f9 01             	cmp    $0x1,%cl
    d4f2:	75 29                	jne    d51d <f0+0x247d>
    d4f4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4f7:	0f b7 c0             	movzwl %ax,%eax
    d4fa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4fd:	48 0f af c1          	imul   %rcx,%rax
    d501:	48 c1 e8 20          	shr    $0x20,%rax
    d505:	48 39 d0             	cmp    %rdx,%rax
    d508:	73 13                	jae    d51d <f0+0x247d>
    d50a:	49 01 c4             	add    %rax,%r12
    d50d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d512:	0f 84 33 08 00 00    	je     dd4b <f0+0x2cab>
    d518:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d51d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d524:	00 f0 3f 
    d527:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d52e:	00 
    d52f:	bf 01 00 00 00       	mov    $0x1,%edi
    d534:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d53b:	00 
    d53c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d543:	00 
    d544:	e8 b7 8b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d549:	48 8b 15 a8 f6 05 00 	mov    0x5f6a8(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d550:	49 89 c5             	mov    %rax,%r13
    d553:	48 2b 05 76 f6 05 00 	sub    0x5f676(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d55a:	48 c1 e2 10          	shl    $0x10,%rdx
    d55e:	48 39 d0             	cmp    %rdx,%rax
    d561:	73 59                	jae    d5bc <f0+0x251c>
    d563:	48 89 c2             	mov    %rax,%rdx
    d566:	48 c1 ea 10          	shr    $0x10,%rdx
    d56a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d56e:	48 8b 15 a3 f6 05 00 	mov    0x5f6a3(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d575:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d579:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d57d:	4d 85 e4             	test   %r12,%r12
    d580:	74 3a                	je     d5bc <f0+0x251c>
    d582:	0f b6 0a             	movzbl (%rdx),%ecx
    d585:	80 f9 02             	cmp    $0x2,%cl
    d588:	0f 84 62 05 00 00    	je     daf0 <f0+0x2a50>
    d58e:	80 f9 01             	cmp    $0x1,%cl
    d591:	75 29                	jne    d5bc <f0+0x251c>
    d593:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d596:	0f b7 c0             	movzwl %ax,%eax
    d599:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d59c:	48 0f af c1          	imul   %rcx,%rax
    d5a0:	48 c1 e8 20          	shr    $0x20,%rax
    d5a4:	48 39 d0             	cmp    %rdx,%rax
    d5a7:	73 13                	jae    d5bc <f0+0x251c>
    d5a9:	49 01 c4             	add    %rax,%r12
    d5ac:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5b1:	0f 84 a1 07 00 00    	je     dd58 <f0+0x2cb8>
    d5b7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5bc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d5c3:	33 f3 bf 
    d5c6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d5cd:	00 
    d5ce:	bf 01 00 00 00       	mov    $0x1,%edi
    d5d3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d5da:	00 
    d5db:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d5e2:	00 
    d5e3:	e8 18 8b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d5e8:	48 8b 15 09 f6 05 00 	mov    0x5f609(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d5ef:	49 89 c5             	mov    %rax,%r13
    d5f2:	48 2b 05 d7 f5 05 00 	sub    0x5f5d7(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d5f9:	48 c1 e2 10          	shl    $0x10,%rdx
    d5fd:	48 39 d0             	cmp    %rdx,%rax
    d600:	73 59                	jae    d65b <f0+0x25bb>
    d602:	48 89 c2             	mov    %rax,%rdx
    d605:	48 c1 ea 10          	shr    $0x10,%rdx
    d609:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d60d:	48 8b 15 04 f6 05 00 	mov    0x5f604(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d614:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d618:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d61c:	4d 85 e4             	test   %r12,%r12
    d61f:	74 3a                	je     d65b <f0+0x25bb>
    d621:	0f b6 0a             	movzbl (%rdx),%ecx
    d624:	80 f9 02             	cmp    $0x2,%cl
    d627:	0f 84 b3 04 00 00    	je     dae0 <f0+0x2a40>
    d62d:	80 f9 01             	cmp    $0x1,%cl
    d630:	75 29                	jne    d65b <f0+0x25bb>
    d632:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d635:	0f b7 c0             	movzwl %ax,%eax
    d638:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d63b:	48 0f af c1          	imul   %rcx,%rax
    d63f:	48 c1 e8 20          	shr    $0x20,%rax
    d643:	48 39 d0             	cmp    %rdx,%rax
    d646:	73 13                	jae    d65b <f0+0x25bb>
    d648:	49 01 c4             	add    %rax,%r12
    d64b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d650:	0f 84 0f 07 00 00    	je     dd65 <f0+0x2cc5>
    d656:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d65b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d662:	00 f0 3f 
    d665:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d66c:	00 
    d66d:	bf 01 00 00 00       	mov    $0x1,%edi
    d672:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d679:	00 
    d67a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d681:	00 
    d682:	e8 79 8a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d687:	48 8b 15 6a f5 05 00 	mov    0x5f56a(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d68e:	49 89 c5             	mov    %rax,%r13
    d691:	48 2b 05 38 f5 05 00 	sub    0x5f538(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d698:	48 c1 e2 10          	shl    $0x10,%rdx
    d69c:	48 39 d0             	cmp    %rdx,%rax
    d69f:	73 59                	jae    d6fa <f0+0x265a>
    d6a1:	48 89 c2             	mov    %rax,%rdx
    d6a4:	48 c1 ea 10          	shr    $0x10,%rdx
    d6a8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6ac:	48 8b 15 65 f5 05 00 	mov    0x5f565(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d6b3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6b7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6bb:	4d 85 e4             	test   %r12,%r12
    d6be:	74 3a                	je     d6fa <f0+0x265a>
    d6c0:	0f b6 0a             	movzbl (%rdx),%ecx
    d6c3:	80 f9 02             	cmp    $0x2,%cl
    d6c6:	0f 84 04 04 00 00    	je     dad0 <f0+0x2a30>
    d6cc:	80 f9 01             	cmp    $0x1,%cl
    d6cf:	75 29                	jne    d6fa <f0+0x265a>
    d6d1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6d4:	0f b7 c0             	movzwl %ax,%eax
    d6d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6da:	48 0f af c1          	imul   %rcx,%rax
    d6de:	48 c1 e8 20          	shr    $0x20,%rax
    d6e2:	48 39 d0             	cmp    %rdx,%rax
    d6e5:	73 13                	jae    d6fa <f0+0x265a>
    d6e7:	49 01 c4             	add    %rax,%r12
    d6ea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6ef:	0f 84 7d 06 00 00    	je     dd72 <f0+0x2cd2>
    d6f5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6fa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d701:	33 f3 bf 
    d704:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d70b:	00 
    d70c:	bf 01 00 00 00       	mov    $0x1,%edi
    d711:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d718:	00 
    d719:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d720:	00 
    d721:	e8 da 89 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d726:	48 8b 15 cb f4 05 00 	mov    0x5f4cb(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d72d:	49 89 c5             	mov    %rax,%r13
    d730:	48 2b 05 99 f4 05 00 	sub    0x5f499(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d737:	48 c1 e2 10          	shl    $0x10,%rdx
    d73b:	48 39 d0             	cmp    %rdx,%rax
    d73e:	73 59                	jae    d799 <f0+0x26f9>
    d740:	48 89 c2             	mov    %rax,%rdx
    d743:	48 c1 ea 10          	shr    $0x10,%rdx
    d747:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d74b:	48 8b 15 c6 f4 05 00 	mov    0x5f4c6(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d752:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d756:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d75a:	4d 85 e4             	test   %r12,%r12
    d75d:	74 3a                	je     d799 <f0+0x26f9>
    d75f:	0f b6 0a             	movzbl (%rdx),%ecx
    d762:	80 f9 02             	cmp    $0x2,%cl
    d765:	0f 84 55 03 00 00    	je     dac0 <f0+0x2a20>
    d76b:	80 f9 01             	cmp    $0x1,%cl
    d76e:	75 29                	jne    d799 <f0+0x26f9>
    d770:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d773:	0f b7 c0             	movzwl %ax,%eax
    d776:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d779:	48 0f af c1          	imul   %rcx,%rax
    d77d:	48 c1 e8 20          	shr    $0x20,%rax
    d781:	48 39 d0             	cmp    %rdx,%rax
    d784:	73 13                	jae    d799 <f0+0x26f9>
    d786:	49 01 c4             	add    %rax,%r12
    d789:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d78e:	0f 84 eb 05 00 00    	je     dd7f <f0+0x2cdf>
    d794:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d799:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d7a0:	00 f0 3f 
    d7a3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d7aa:	00 
    d7ab:	bf 01 00 00 00       	mov    $0x1,%edi
    d7b0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d7b7:	00 
    d7b8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d7bf:	00 
    d7c0:	e8 3b 89 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d7c5:	48 8b 15 2c f4 05 00 	mov    0x5f42c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d7cc:	49 89 c5             	mov    %rax,%r13
    d7cf:	48 2b 05 fa f3 05 00 	sub    0x5f3fa(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d7d6:	48 c1 e2 10          	shl    $0x10,%rdx
    d7da:	48 39 d0             	cmp    %rdx,%rax
    d7dd:	73 59                	jae    d838 <f0+0x2798>
    d7df:	48 89 c2             	mov    %rax,%rdx
    d7e2:	48 c1 ea 10          	shr    $0x10,%rdx
    d7e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7ea:	48 8b 15 27 f4 05 00 	mov    0x5f427(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d7f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7f5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7f9:	4d 85 e4             	test   %r12,%r12
    d7fc:	74 3a                	je     d838 <f0+0x2798>
    d7fe:	0f b6 0a             	movzbl (%rdx),%ecx
    d801:	80 f9 02             	cmp    $0x2,%cl
    d804:	0f 84 a6 02 00 00    	je     dab0 <f0+0x2a10>
    d80a:	80 f9 01             	cmp    $0x1,%cl
    d80d:	75 29                	jne    d838 <f0+0x2798>
    d80f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d812:	0f b7 c0             	movzwl %ax,%eax
    d815:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d818:	48 0f af c1          	imul   %rcx,%rax
    d81c:	48 c1 e8 20          	shr    $0x20,%rax
    d820:	48 39 d0             	cmp    %rdx,%rax
    d823:	73 13                	jae    d838 <f0+0x2798>
    d825:	49 01 c4             	add    %rax,%r12
    d828:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d82d:	0f 84 59 05 00 00    	je     dd8c <f0+0x2cec>
    d833:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d838:	48 89 ee             	mov    %rbp,%rsi
    d83b:	bf 01 00 00 00       	mov    $0x1,%edi
    d840:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d847:	33 f3 bf 
    d84a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d851:	00 
    d852:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d859:	00 
    d85a:	e8 a1 88 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d85f:	48 8b 15 92 f3 05 00 	mov    0x5f392(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d866:	48 89 c5             	mov    %rax,%rbp
    d869:	48 2b 05 60 f3 05 00 	sub    0x5f360(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d870:	48 c1 e2 10          	shl    $0x10,%rdx
    d874:	48 39 d0             	cmp    %rdx,%rax
    d877:	73 59                	jae    d8d2 <f0+0x2832>
    d879:	48 89 c2             	mov    %rax,%rdx
    d87c:	48 c1 ea 10          	shr    $0x10,%rdx
    d880:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d884:	48 8b 15 8d f3 05 00 	mov    0x5f38d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d88b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d88f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d893:	4d 85 e4             	test   %r12,%r12
    d896:	74 3a                	je     d8d2 <f0+0x2832>
    d898:	0f b6 0a             	movzbl (%rdx),%ecx
    d89b:	80 f9 02             	cmp    $0x2,%cl
    d89e:	0f 84 fc 01 00 00    	je     daa0 <f0+0x2a00>
    d8a4:	80 f9 01             	cmp    $0x1,%cl
    d8a7:	75 29                	jne    d8d2 <f0+0x2832>
    d8a9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8ac:	0f b7 c0             	movzwl %ax,%eax
    d8af:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8b2:	48 0f af c1          	imul   %rcx,%rax
    d8b6:	48 c1 e8 20          	shr    $0x20,%rax
    d8ba:	48 39 d0             	cmp    %rdx,%rax
    d8bd:	73 13                	jae    d8d2 <f0+0x2832>
    d8bf:	49 01 c4             	add    %rax,%r12
    d8c2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8c7:	0f 84 d1 02 00 00    	je     db9e <f0+0x2afe>
    d8cd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8d2:	48 89 de             	mov    %rbx,%rsi
    d8d5:	48 89 ef             	mov    %rbp,%rdi
    d8d8:	e8 23 be ff ff       	call   9700 <fwp_hof0.constprop.0>
    d8dd:	48 89 ef             	mov    %rbp,%rdi
    d8e0:	e8 bb a2 ff ff       	call   7ba0 <fwp_drop0>
    d8e5:	48 89 df             	mov    %rbx,%rdi
    d8e8:	e8 b3 a2 ff ff       	call   7ba0 <fwp_drop0>
    d8ed:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d8f4:	00 
    d8f5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d8fc:	00 00 
    d8fe:	0f 85 95 04 00 00    	jne    dd99 <f0+0x2cf9>
    d904:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d90b:	31 c0                	xor    %eax,%eax
    d90d:	5b                   	pop    %rbx
    d90e:	5d                   	pop    %rbp
    d90f:	41 5c                	pop    %r12
    d911:	41 5d                	pop    %r13
    d913:	41 5e                	pop    %r14
    d915:	c3                   	ret
    d916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d91d:	00 00 00 
    d920:	4c 89 ef             	mov    %r13,%rdi
    d923:	e8 a8 7e ff ff       	call   57d0 <fwp_rc_forget_slot>
    d928:	e9 2c d8 ff ff       	jmp    b159 <f0+0xb9>
    d92d:	0f 1f 00             	nopl   (%rax)
    d930:	66 85 c0             	test   %ax,%ax
    d933:	0f 85 ae f5 ff ff    	jne    cee7 <f0+0x1e47>
    d939:	e9 99 f5 ff ff       	jmp    ced7 <f0+0x1e37>
    d93e:	66 90                	xchg   %ax,%ax
    d940:	66 85 c0             	test   %ax,%ax
    d943:	0f 85 ff f4 ff ff    	jne    ce48 <f0+0x1da8>
    d949:	e9 ea f4 ff ff       	jmp    ce38 <f0+0x1d98>
    d94e:	66 90                	xchg   %ax,%ax
    d950:	66 85 c0             	test   %ax,%ax
    d953:	0f 85 50 f4 ff ff    	jne    cda9 <f0+0x1d09>
    d959:	e9 3b f4 ff ff       	jmp    cd99 <f0+0x1cf9>
    d95e:	66 90                	xchg   %ax,%ax
    d960:	66 85 c0             	test   %ax,%ax
    d963:	0f 85 a1 f3 ff ff    	jne    cd0a <f0+0x1c6a>
    d969:	e9 8c f3 ff ff       	jmp    ccfa <f0+0x1c5a>
    d96e:	66 90                	xchg   %ax,%ax
    d970:	66 85 c0             	test   %ax,%ax
    d973:	0f 85 f2 f2 ff ff    	jne    cc6b <f0+0x1bcb>
    d979:	e9 dd f2 ff ff       	jmp    cc5b <f0+0x1bbb>
    d97e:	66 90                	xchg   %ax,%ax
    d980:	66 85 c0             	test   %ax,%ax
    d983:	0f 85 43 f2 ff ff    	jne    cbcc <f0+0x1b2c>
    d989:	e9 2e f2 ff ff       	jmp    cbbc <f0+0x1b1c>
    d98e:	66 90                	xchg   %ax,%ax
    d990:	66 85 c0             	test   %ax,%ax
    d993:	0f 85 94 f1 ff ff    	jne    cb2d <f0+0x1a8d>
    d999:	e9 7f f1 ff ff       	jmp    cb1d <f0+0x1a7d>
    d99e:	66 90                	xchg   %ax,%ax
    d9a0:	66 85 c0             	test   %ax,%ax
    d9a3:	0f 85 e5 f0 ff ff    	jne    ca8e <f0+0x19ee>
    d9a9:	e9 d0 f0 ff ff       	jmp    ca7e <f0+0x19de>
    d9ae:	66 90                	xchg   %ax,%ax
    d9b0:	66 85 c0             	test   %ax,%ax
    d9b3:	0f 85 fd d9 ff ff    	jne    b3b6 <f0+0x316>
    d9b9:	e9 e8 d9 ff ff       	jmp    b3a6 <f0+0x306>
    d9be:	66 90                	xchg   %ax,%ax
    d9c0:	66 85 c0             	test   %ax,%ax
    d9c3:	0f 85 57 d9 ff ff    	jne    b320 <f0+0x280>
    d9c9:	e9 42 d9 ff ff       	jmp    b310 <f0+0x270>
    d9ce:	66 90                	xchg   %ax,%ax
    d9d0:	66 85 c0             	test   %ax,%ax
    d9d3:	0f 85 b1 d8 ff ff    	jne    b28a <f0+0x1ea>
    d9d9:	e9 9c d8 ff ff       	jmp    b27a <f0+0x1da>
    d9de:	66 90                	xchg   %ax,%ax
    d9e0:	66 85 c0             	test   %ax,%ax
    d9e3:	0f 85 0e eb ff ff    	jne    c4f7 <f0+0x1457>
    d9e9:	e9 f9 ea ff ff       	jmp    c4e7 <f0+0x1447>
    d9ee:	66 90                	xchg   %ax,%ax
    d9f0:	66 85 c0             	test   %ax,%ax
    d9f3:	0f 85 5f ea ff ff    	jne    c458 <f0+0x13b8>
    d9f9:	e9 4a ea ff ff       	jmp    c448 <f0+0x13a8>
    d9fe:	66 90                	xchg   %ax,%ax
    da00:	66 85 c0             	test   %ax,%ax
    da03:	0f 85 e2 da ff ff    	jne    b4eb <f0+0x44b>
    da09:	e9 cd da ff ff       	jmp    b4db <f0+0x43b>
    da0e:	66 90                	xchg   %ax,%ax
    da10:	66 85 c0             	test   %ax,%ax
    da13:	0f 85 33 da ff ff    	jne    b44c <f0+0x3ac>
    da19:	e9 1e da ff ff       	jmp    b43c <f0+0x39c>
    da1e:	66 90                	xchg   %ax,%ax
    da20:	66 85 c0             	test   %ax,%ax
    da23:	0f 85 c6 ef ff ff    	jne    c9ef <f0+0x194f>
    da29:	e9 b1 ef ff ff       	jmp    c9df <f0+0x193f>
    da2e:	66 90                	xchg   %ax,%ax
    da30:	66 85 c0             	test   %ax,%ax
    da33:	0f 85 17 ef ff ff    	jne    c950 <f0+0x18b0>
    da39:	e9 02 ef ff ff       	jmp    c940 <f0+0x18a0>
    da3e:	66 90                	xchg   %ax,%ax
    da40:	66 85 c0             	test   %ax,%ax
    da43:	0f 85 68 ee ff ff    	jne    c8b1 <f0+0x1811>
    da49:	e9 53 ee ff ff       	jmp    c8a1 <f0+0x1801>
    da4e:	66 90                	xchg   %ax,%ax
    da50:	66 85 c0             	test   %ax,%ax
    da53:	0f 85 b9 ed ff ff    	jne    c812 <f0+0x1772>
    da59:	e9 a4 ed ff ff       	jmp    c802 <f0+0x1762>
    da5e:	66 90                	xchg   %ax,%ax
    da60:	66 85 c0             	test   %ax,%ax
    da63:	0f 85 0a ed ff ff    	jne    c773 <f0+0x16d3>
    da69:	e9 f5 ec ff ff       	jmp    c763 <f0+0x16c3>
    da6e:	66 90                	xchg   %ax,%ax
    da70:	66 85 c0             	test   %ax,%ax
    da73:	0f 85 5b ec ff ff    	jne    c6d4 <f0+0x1634>
    da79:	e9 46 ec ff ff       	jmp    c6c4 <f0+0x1624>
    da7e:	66 90                	xchg   %ax,%ax
    da80:	66 85 c0             	test   %ax,%ax
    da83:	0f 85 ac eb ff ff    	jne    c635 <f0+0x1595>
    da89:	e9 97 eb ff ff       	jmp    c625 <f0+0x1585>
    da8e:	66 90                	xchg   %ax,%ax
    da90:	66 85 c0             	test   %ax,%ax
    da93:	0f 85 fd ea ff ff    	jne    c596 <f0+0x14f6>
    da99:	e9 e8 ea ff ff       	jmp    c586 <f0+0x14e6>
    da9e:	66 90                	xchg   %ax,%ax
    daa0:	66 85 c0             	test   %ax,%ax
    daa3:	0f 85 29 fe ff ff    	jne    d8d2 <f0+0x2832>
    daa9:	e9 14 fe ff ff       	jmp    d8c2 <f0+0x2822>
    daae:	66 90                	xchg   %ax,%ax
    dab0:	66 85 c0             	test   %ax,%ax
    dab3:	0f 85 7f fd ff ff    	jne    d838 <f0+0x2798>
    dab9:	e9 6a fd ff ff       	jmp    d828 <f0+0x2788>
    dabe:	66 90                	xchg   %ax,%ax
    dac0:	66 85 c0             	test   %ax,%ax
    dac3:	0f 85 d0 fc ff ff    	jne    d799 <f0+0x26f9>
    dac9:	e9 bb fc ff ff       	jmp    d789 <f0+0x26e9>
    dace:	66 90                	xchg   %ax,%ax
    dad0:	66 85 c0             	test   %ax,%ax
    dad3:	0f 85 21 fc ff ff    	jne    d6fa <f0+0x265a>
    dad9:	e9 0c fc ff ff       	jmp    d6ea <f0+0x264a>
    dade:	66 90                	xchg   %ax,%ax
    dae0:	66 85 c0             	test   %ax,%ax
    dae3:	0f 85 72 fb ff ff    	jne    d65b <f0+0x25bb>
    dae9:	e9 5d fb ff ff       	jmp    d64b <f0+0x25ab>
    daee:	66 90                	xchg   %ax,%ax
    daf0:	66 85 c0             	test   %ax,%ax
    daf3:	0f 85 c3 fa ff ff    	jne    d5bc <f0+0x251c>
    daf9:	e9 ae fa ff ff       	jmp    d5ac <f0+0x250c>
    dafe:	66 90                	xchg   %ax,%ax
    db00:	66 85 c0             	test   %ax,%ax
    db03:	0f 85 14 fa ff ff    	jne    d51d <f0+0x247d>
    db09:	e9 ff f9 ff ff       	jmp    d50d <f0+0x246d>
    db0e:	66 90                	xchg   %ax,%ax
    db10:	66 85 c0             	test   %ax,%ax
    db13:	0f 85 65 f9 ff ff    	jne    d47e <f0+0x23de>
    db19:	e9 50 f9 ff ff       	jmp    d46e <f0+0x23ce>
    db1e:	66 90                	xchg   %ax,%ax
    db20:	66 85 c0             	test   %ax,%ax
    db23:	0f 85 b6 f8 ff ff    	jne    d3df <f0+0x233f>
    db29:	e9 a1 f8 ff ff       	jmp    d3cf <f0+0x232f>
    db2e:	66 90                	xchg   %ax,%ax
    db30:	66 85 c0             	test   %ax,%ax
    db33:	0f 85 07 f8 ff ff    	jne    d340 <f0+0x22a0>
    db39:	e9 f2 f7 ff ff       	jmp    d330 <f0+0x2290>
    db3e:	66 90                	xchg   %ax,%ax
    db40:	66 85 c0             	test   %ax,%ax
    db43:	0f 85 58 f7 ff ff    	jne    d2a1 <f0+0x2201>
    db49:	e9 43 f7 ff ff       	jmp    d291 <f0+0x21f1>
    db4e:	66 90                	xchg   %ax,%ax
    db50:	66 85 c0             	test   %ax,%ax
    db53:	0f 85 a9 f6 ff ff    	jne    d202 <f0+0x2162>
    db59:	e9 94 f6 ff ff       	jmp    d1f2 <f0+0x2152>
    db5e:	66 90                	xchg   %ax,%ax
    db60:	66 85 c0             	test   %ax,%ax
    db63:	0f 85 fa f5 ff ff    	jne    d163 <f0+0x20c3>
    db69:	e9 e5 f5 ff ff       	jmp    d153 <f0+0x20b3>
    db6e:	66 90                	xchg   %ax,%ax
    db70:	66 85 c0             	test   %ax,%ax
    db73:	0f 85 4b f5 ff ff    	jne    d0c4 <f0+0x2024>
    db79:	e9 36 f5 ff ff       	jmp    d0b4 <f0+0x2014>
    db7e:	66 90                	xchg   %ax,%ax
    db80:	66 85 c0             	test   %ax,%ax
    db83:	0f 85 9c f4 ff ff    	jne    d025 <f0+0x1f85>
    db89:	e9 87 f4 ff ff       	jmp    d015 <f0+0x1f75>
    db8e:	66 90                	xchg   %ax,%ax
    db90:	66 85 c0             	test   %ax,%ax
    db93:	0f 85 ed f3 ff ff    	jne    cf86 <f0+0x1ee6>
    db99:	e9 d8 f3 ff ff       	jmp    cf76 <f0+0x1ed6>
    db9e:	4c 89 e7             	mov    %r12,%rdi
    dba1:	e8 2a 7c ff ff       	call   57d0 <fwp_rc_forget_slot>
    dba6:	e9 22 fd ff ff       	jmp    d8cd <f0+0x282d>
    dbab:	4c 89 e7             	mov    %r12,%rdi
    dbae:	e8 1d 7c ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbb3:	e9 cd d6 ff ff       	jmp    b285 <f0+0x1e5>
    dbb8:	4c 89 e7             	mov    %r12,%rdi
    dbbb:	e8 10 7c ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbc0:	e9 56 d7 ff ff       	jmp    b31b <f0+0x27b>
    dbc5:	4c 89 e7             	mov    %r12,%rdi
    dbc8:	e8 03 7c ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbcd:	e9 df d7 ff ff       	jmp    b3b1 <f0+0x311>
    dbd2:	4c 89 e7             	mov    %r12,%rdi
    dbd5:	e8 f6 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbda:	e9 68 d8 ff ff       	jmp    b447 <f0+0x3a7>
    dbdf:	4c 89 e7             	mov    %r12,%rdi
    dbe2:	e8 e9 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbe7:	e9 fa d8 ff ff       	jmp    b4e6 <f0+0x446>
    dbec:	4c 89 e7             	mov    %r12,%rdi
    dbef:	e8 dc 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbf4:	e9 5a e8 ff ff       	jmp    c453 <f0+0x13b3>
    dbf9:	4c 89 e7             	mov    %r12,%rdi
    dbfc:	e8 cf 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc01:	e9 ec e8 ff ff       	jmp    c4f2 <f0+0x1452>
    dc06:	4c 89 e7             	mov    %r12,%rdi
    dc09:	e8 c2 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc0e:	e9 7e e9 ff ff       	jmp    c591 <f0+0x14f1>
    dc13:	4c 89 e7             	mov    %r12,%rdi
    dc16:	e8 b5 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc1b:	e9 10 ea ff ff       	jmp    c630 <f0+0x1590>
    dc20:	4c 89 e7             	mov    %r12,%rdi
    dc23:	e8 a8 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc28:	e9 a2 ea ff ff       	jmp    c6cf <f0+0x162f>
    dc2d:	4c 89 e7             	mov    %r12,%rdi
    dc30:	e8 9b 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc35:	e9 34 eb ff ff       	jmp    c76e <f0+0x16ce>
    dc3a:	4c 89 e7             	mov    %r12,%rdi
    dc3d:	e8 8e 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc42:	e9 c6 eb ff ff       	jmp    c80d <f0+0x176d>
    dc47:	4c 89 e7             	mov    %r12,%rdi
    dc4a:	e8 81 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc4f:	e9 58 ec ff ff       	jmp    c8ac <f0+0x180c>
    dc54:	4c 89 e7             	mov    %r12,%rdi
    dc57:	e8 74 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc5c:	e9 ea ec ff ff       	jmp    c94b <f0+0x18ab>
    dc61:	4c 89 e7             	mov    %r12,%rdi
    dc64:	e8 67 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc69:	e9 7c ed ff ff       	jmp    c9ea <f0+0x194a>
    dc6e:	4c 89 e7             	mov    %r12,%rdi
    dc71:	e8 5a 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc76:	e9 0e ee ff ff       	jmp    ca89 <f0+0x19e9>
    dc7b:	4c 89 e7             	mov    %r12,%rdi
    dc7e:	e8 4d 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc83:	e9 a0 ee ff ff       	jmp    cb28 <f0+0x1a88>
    dc88:	4c 89 e7             	mov    %r12,%rdi
    dc8b:	e8 40 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc90:	e9 32 ef ff ff       	jmp    cbc7 <f0+0x1b27>
    dc95:	4c 89 e7             	mov    %r12,%rdi
    dc98:	e8 33 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc9d:	e9 c4 ef ff ff       	jmp    cc66 <f0+0x1bc6>
    dca2:	4c 89 e7             	mov    %r12,%rdi
    dca5:	e8 26 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcaa:	e9 56 f0 ff ff       	jmp    cd05 <f0+0x1c65>
    dcaf:	4c 89 e7             	mov    %r12,%rdi
    dcb2:	e8 19 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcb7:	e9 e8 f0 ff ff       	jmp    cda4 <f0+0x1d04>
    dcbc:	4c 89 e7             	mov    %r12,%rdi
    dcbf:	e8 0c 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcc4:	e9 7a f1 ff ff       	jmp    ce43 <f0+0x1da3>
    dcc9:	4c 89 e7             	mov    %r12,%rdi
    dccc:	e8 ff 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcd1:	e9 0c f2 ff ff       	jmp    cee2 <f0+0x1e42>
    dcd6:	4c 89 e7             	mov    %r12,%rdi
    dcd9:	e8 f2 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcde:	e9 9e f2 ff ff       	jmp    cf81 <f0+0x1ee1>
    dce3:	4c 89 e7             	mov    %r12,%rdi
    dce6:	e8 e5 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dceb:	e9 30 f3 ff ff       	jmp    d020 <f0+0x1f80>
    dcf0:	4c 89 e7             	mov    %r12,%rdi
    dcf3:	e8 d8 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcf8:	e9 c2 f3 ff ff       	jmp    d0bf <f0+0x201f>
    dcfd:	4c 89 e7             	mov    %r12,%rdi
    dd00:	e8 cb 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd05:	e9 54 f4 ff ff       	jmp    d15e <f0+0x20be>
    dd0a:	4c 89 e7             	mov    %r12,%rdi
    dd0d:	e8 be 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd12:	e9 e6 f4 ff ff       	jmp    d1fd <f0+0x215d>
    dd17:	4c 89 e7             	mov    %r12,%rdi
    dd1a:	e8 b1 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd1f:	e9 78 f5 ff ff       	jmp    d29c <f0+0x21fc>
    dd24:	4c 89 e7             	mov    %r12,%rdi
    dd27:	e8 a4 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd2c:	e9 0a f6 ff ff       	jmp    d33b <f0+0x229b>
    dd31:	4c 89 e7             	mov    %r12,%rdi
    dd34:	e8 97 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd39:	e9 9c f6 ff ff       	jmp    d3da <f0+0x233a>
    dd3e:	4c 89 e7             	mov    %r12,%rdi
    dd41:	e8 8a 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd46:	e9 2e f7 ff ff       	jmp    d479 <f0+0x23d9>
    dd4b:	4c 89 e7             	mov    %r12,%rdi
    dd4e:	e8 7d 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd53:	e9 c0 f7 ff ff       	jmp    d518 <f0+0x2478>
    dd58:	4c 89 e7             	mov    %r12,%rdi
    dd5b:	e8 70 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd60:	e9 52 f8 ff ff       	jmp    d5b7 <f0+0x2517>
    dd65:	4c 89 e7             	mov    %r12,%rdi
    dd68:	e8 63 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd6d:	e9 e4 f8 ff ff       	jmp    d656 <f0+0x25b6>
    dd72:	4c 89 e7             	mov    %r12,%rdi
    dd75:	e8 56 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd7a:	e9 76 f9 ff ff       	jmp    d6f5 <f0+0x2655>
    dd7f:	4c 89 e7             	mov    %r12,%rdi
    dd82:	e8 49 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd87:	e9 08 fa ff ff       	jmp    d794 <f0+0x26f4>
    dd8c:	4c 89 e7             	mov    %r12,%rdi
    dd8f:	e8 3c 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd94:	e9 9a fa ff ff       	jmp    d833 <f0+0x2793>
    dd99:	e8 b2 56 ff ff       	call   3450 <__stack_chk_fail@plt>
    dd9e:	66 90                	xchg   %ax,%ax

000000000000dda0 <fwp_main_thread>:
    dda0:	f3 0f 1e fa          	endbr64
    dda4:	41 54                	push   %r12
    dda6:	55                   	push   %rbp
    dda7:	53                   	push   %rbx
    dda8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    ddaf:	8b 0d 0f ee 05 00    	mov    0x5ee0f(%rip),%ecx        # 6cbc4 <fwp_heap+0x13a4>
    ddb5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ddbc:	00 00 
    ddbe:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    ddc5:	00 
    ddc6:	31 c0                	xor    %eax,%eax
    ddc8:	85 c9                	test   %ecx,%ecx
    ddca:	0f 84 58 07 00 00    	je     e528 <fwp_main_thread+0x788>
    ddd0:	8b 15 f2 ed 05 00    	mov    0x5edf2(%rip),%edx        # 6cbc8 <fwp_heap+0x13a8>
    ddd6:	85 d2                	test   %edx,%edx
    ddd8:	0f 85 32 07 00 00    	jne    e510 <fwp_main_thread+0x770>
    ddde:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    dde3:	31 f6                	xor    %esi,%esi
    dde5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    ddea:	48 c7 05 cb d3 05 00 	movq   $0x40000000,0x5d3cb(%rip)        # 6b1c0 <fwp_main_stack_size>
    ddf1:	00 00 00 40 
    ddf5:	48 89 05 cc d3 05 00 	mov    %rax,0x5d3cc(%rip)        # 6b1c8 <fwp_main_stack_top>
    ddfc:	48 8d 05 7d 52 00 00 	lea    0x527d(%rip),%rax        # 13080 <alt.5>
    de03:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    de08:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    de0f:	01 00 
    de11:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    de18:	00 
    de19:	e8 82 58 ff ff       	call   36a0 <sigaltstack@plt>
    de1e:	85 c0                	test   %eax,%eax
    de20:	0f 85 6a 07 00 00    	jne    e590 <fwp_main_thread+0x7f0>
    de26:	31 c0                	xor    %eax,%eax
    de28:	b9 12 00 00 00       	mov    $0x12,%ecx
    de2d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    de32:	f3 48 ab             	rep stos %rax,(%rdi)
    de35:	48 8d 05 04 5f ff ff 	lea    -0xa0fc(%rip),%rax        # 3d40 <fwp_segv>
    de3c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    de41:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    de48:	04 00 00 08 
    de4c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    de51:	e8 0a 57 ff ff       	call   3560 <sigemptyset@plt>
    de56:	85 c0                	test   %eax,%eax
    de58:	0f 85 32 07 00 00    	jne    e590 <fwp_main_thread+0x7f0>
    de5e:	31 d2                	xor    %edx,%edx
    de60:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    de65:	bf 0b 00 00 00       	mov    $0xb,%edi
    de6a:	e8 81 55 ff ff       	call   33f0 <sigaction@plt>
    de6f:	85 c0                	test   %eax,%eax
    de71:	0f 85 19 07 00 00    	jne    e590 <fwp_main_thread+0x7f0>
    de77:	31 d2                	xor    %edx,%edx
    de79:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    de7e:	bf 07 00 00 00       	mov    $0x7,%edi
    de83:	e8 68 55 ff ff       	call   33f0 <sigaction@plt>
    de88:	85 c0                	test   %eax,%eax
    de8a:	0f 85 00 07 00 00    	jne    e590 <fwp_main_thread+0x7f0>
    de90:	48 8b 05 a9 ed 05 00 	mov    0x5eda9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    de97:	48 85 c0             	test   %rax,%rax
    de9a:	0f 88 50 06 00 00    	js     e4f0 <fwp_main_thread+0x750>
    dea0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    dea4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    dea9:	48 8d 3d 70 63 ff ff 	lea    -0x9c90(%rip),%rdi        # 4220 <ad_raw_report>
    deb0:	f2 0f 11 05 10 f6 05 	movsd  %xmm0,0x5f610(%rip)        # 6d4c8 <iteration_start_charge>
    deb7:	00 
    deb8:	c7 05 26 f6 05 00 01 	movl   $0x1,0x5f626(%rip)        # 6d4e8 <iteration_active>
    debf:	00 00 00 
    dec2:	e8 09 09 00 00       	call   e7d0 <atexit>
    dec7:	85 c0                	test   %eax,%eax
    dec9:	0f 85 cd 06 00 00    	jne    e59c <fwp_main_thread+0x7fc>
    decf:	8b 05 9b 51 00 00    	mov    0x519b(%rip),%eax        # 13070 <st.3>
    ded5:	85 c0                	test   %eax,%eax
    ded7:	0f 84 5b 06 00 00    	je     e538 <fwp_main_thread+0x798>
    dedd:	48 8b 2d 1c d9 05 00 	mov    0x5d91c(%rip),%rbp        # 6b800 <fwp_cur>
    dee4:	48 85 ed             	test   %rbp,%rbp
    dee7:	0f 84 03 03 00 00    	je     e1f0 <fwp_main_thread+0x450>
    deed:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    def2:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    def6:	48 89 eb             	mov    %rbp,%rbx
    def9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    defe:	0f 84 41 01 00 00    	je     e045 <fwp_main_thread+0x2a5>
    df04:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    df09:	0f 84 11 02 00 00    	je     e120 <fwp_main_thread+0x380>
    df0f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    df13:	0f 84 f7 01 00 00    	je     e110 <fwp_main_thread+0x370>
    df19:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    df1d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    df21:	0f 85 79 02 00 00    	jne    e1a0 <fwp_main_thread+0x400>
    df27:	48 8b 43 60          	mov    0x60(%rbx),%rax
    df2b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    df32:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    df36:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    df3d:	00 00 00 00 
    df41:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    df48:	48 85 d2             	test   %rdx,%rdx
    df4b:	74 07                	je     df54 <fwp_main_thread+0x1b4>
    df4d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    df54:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    df58:	48 85 c0             	test   %rax,%rax
    df5b:	74 34                	je     df91 <fwp_main_thread+0x1f1>
    df5d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    df61:	48 8b 05 70 d8 05 00 	mov    0x5d870(%rip),%rax        # 6b7d8 <fwp_timers>
    df68:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    df6c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    df73:	00 00 00 00 
    df77:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    df7e:	48 85 c0             	test   %rax,%rax
    df81:	74 07                	je     df8a <fwp_main_thread+0x1ea>
    df83:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    df8a:	48 89 1d 47 d8 05 00 	mov    %rbx,0x5d847(%rip)        # 6b7d8 <fwp_timers>
    df91:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    df95:	e8 96 97 ff ff       	call   7730 <fwp_block>
    df9a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    dfa1:	48 85 c9             	test   %rcx,%rcx
    dfa4:	74 47                	je     dfed <fwp_main_thread+0x24d>
    dfa6:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    dfad:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dfb4:	48 85 d2             	test   %rdx,%rdx
    dfb7:	0f 84 23 02 00 00    	je     e1e0 <fwp_main_thread+0x440>
    dfbd:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    dfc4:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dfcb:	48 85 c0             	test   %rax,%rax
    dfce:	74 07                	je     dfd7 <fwp_main_thread+0x237>
    dfd0:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    dfd7:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    dfde:	00 00 00 00 
    dfe2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    dfe6:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    dfed:	48 8b 0d 0c d8 05 00 	mov    0x5d80c(%rip),%rcx        # 6b800 <fwp_cur>
    dff4:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    dff8:	0f 84 92 01 00 00    	je     e190 <fwp_main_thread+0x3f0>
    dffe:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e005:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e00c:	48 85 d2             	test   %rdx,%rdx
    e00f:	0f 84 1b 04 00 00    	je     e430 <fwp_main_thread+0x690>
    e015:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e01c:	48 85 c0             	test   %rax,%rax
    e01f:	74 07                	je     e028 <fwp_main_thread+0x288>
    e021:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e028:	66 0f ef db          	pxor   %xmm3,%xmm3
    e02c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e030:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    e037:	48 89 cb             	mov    %rcx,%rbx
    e03a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e03f:	0f 85 bf fe ff ff    	jne    df04 <fwp_main_thread+0x164>
    e045:	48 83 3d 4b f4 05 00 	cmpq   $0x0,0x5f44b(%rip)        # 6d498 <fwp_state_len>
    e04c:	00 
    e04d:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e051:	0f 84 0b 04 00 00    	je     e462 <fwp_main_thread+0x6c2>
    e057:	48 3b 1d 9a d7 05 00 	cmp    0x5d79a(%rip),%rbx        # 6b7f8 <fwp_root>
    e05e:	c7 05 18 50 01 00 00 	movl   $0x0,0x15018(%rip)        # 23080 <fwp_exit_code>
    e065:	00 00 00 
    e068:	0f 85 4c 05 00 00    	jne    e5ba <fwp_main_thread+0x81a>
    e06e:	48 85 db             	test   %rbx,%rbx
    e071:	0f 84 9f 01 00 00    	je     e216 <fwp_main_thread+0x476>
    e077:	48 8b 15 4a d7 05 00 	mov    0x5d74a(%rip),%rdx        # 6b7c8 <fwp_tasks_active>
    e07e:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e082:	48 85 d2             	test   %rdx,%rdx
    e085:	0f 84 8b 01 00 00    	je     e216 <fwp_main_thread+0x476>
    e08b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e090:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e094:	75 08                	jne    e09e <fwp_main_thread+0x2fe>
    e096:	48 89 d7             	mov    %rdx,%rdi
    e099:	e8 92 60 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e09e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e0a5:	48 85 d2             	test   %rdx,%rdx
    e0a8:	75 e6                	jne    e090 <fwp_main_thread+0x2f0>
    e0aa:	eb 31                	jmp    e0dd <fwp_main_thread+0x33d>
    e0ac:	0f 1f 40 00          	nopl   0x0(%rax)
    e0b0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e0b7:	48 89 1d 22 d7 05 00 	mov    %rbx,0x5d722(%rip)        # 6b7e0 <fwp_ready_tail>
    e0be:	e8 6d 96 ff ff       	call   7730 <fwp_block>
    e0c3:	e8 58 94 ff ff       	call   7520 <fwp_free_zombie>
    e0c8:	48 83 3d f8 d6 05 00 	cmpq   $0x0,0x5d6f8(%rip)        # 6b7c8 <fwp_tasks_active>
    e0cf:	00 
    e0d0:	0f 84 40 01 00 00    	je     e216 <fwp_main_thread+0x476>
    e0d6:	48 8b 1d 1b d7 05 00 	mov    0x5d71b(%rip),%rbx        # 6b7f8 <fwp_root>
    e0dd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e0e1:	75 db                	jne    e0be <fwp_main_thread+0x31e>
    e0e3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e0e7:	75 d5                	jne    e0be <fwp_main_thread+0x31e>
    e0e9:	48 8b 05 f0 d6 05 00 	mov    0x5d6f0(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    e0f0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e0f4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e0fb:	00 00 00 00 
    e0ff:	48 85 c0             	test   %rax,%rax
    e102:	75 ac                	jne    e0b0 <fwp_main_thread+0x310>
    e104:	48 89 1d dd d6 05 00 	mov    %rbx,0x5d6dd(%rip)        # 6b7e8 <fwp_ready_head>
    e10b:	eb aa                	jmp    e0b7 <fwp_main_thread+0x317>
    e10d:	0f 1f 00             	nopl   (%rax)
    e110:	e8 ab 64 ff ff       	call   45c0 <fwp_now_ns>
    e115:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e119:	0f 8d 21 03 00 00    	jge    e440 <fwp_main_thread+0x6a0>
    e11f:	90                   	nop
    e120:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e124:	0f 85 ef fd ff ff    	jne    df19 <fwp_main_thread+0x179>
    e12a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e12e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e132:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e136:	0f 85 ef fd ff ff    	jne    df2b <fwp_main_thread+0x18b>
    e13c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e140:	48 85 c9             	test   %rcx,%rcx
    e143:	0f 84 e2 fd ff ff    	je     df2b <fwp_main_thread+0x18b>
    e149:	48 85 c0             	test   %rax,%rax
    e14c:	0f 84 5b 04 00 00    	je     e5ad <fwp_main_thread+0x80d>
    e152:	48 39 c8             	cmp    %rcx,%rax
    e155:	48 0f 4f c1          	cmovg  %rcx,%rax
    e159:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e160:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e164:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e16b:	00 00 00 00 
    e16f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e176:	48 85 d2             	test   %rdx,%rdx
    e179:	74 07                	je     e182 <fwp_main_thread+0x3e2>
    e17b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e182:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e186:	e9 d2 fd ff ff       	jmp    df5d <fwp_main_thread+0x1bd>
    e18b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e190:	48 89 cb             	mov    %rcx,%rbx
    e193:	e9 61 fd ff ff       	jmp    def9 <fwp_main_thread+0x159>
    e198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e19f:	00 
    e1a0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e1a4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e1ab:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e1b2:	00 00 00 00 
    e1b6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e1bd:	48 85 c0             	test   %rax,%rax
    e1c0:	0f 84 9a 03 00 00    	je     e560 <fwp_main_thread+0x7c0>
    e1c6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e1cd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e1d1:	e9 bb fd ff ff       	jmp    df91 <fwp_main_thread+0x1f1>
    e1d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e1dd:	00 00 00 
    e1e0:	48 89 01             	mov    %rax,(%rcx)
    e1e3:	e9 e3 fd ff ff       	jmp    dfcb <fwp_main_thread+0x22b>
    e1e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e1ef:	00 
    e1f0:	48 83 3d a0 f2 05 00 	cmpq   $0x0,0x5f2a0(%rip)        # 6d498 <fwp_state_len>
    e1f7:	00 
    e1f8:	0f 84 62 02 00 00    	je     e460 <fwp_main_thread+0x6c0>
    e1fe:	48 83 3d f2 d5 05 00 	cmpq   $0x0,0x5d5f2(%rip)        # 6b7f8 <fwp_root>
    e205:	00 
    e206:	c7 05 70 4e 01 00 00 	movl   $0x0,0x14e70(%rip)        # 23080 <fwp_exit_code>
    e20d:	00 00 00 
    e210:	0f 85 9f 03 00 00    	jne    e5b5 <fwp_main_thread+0x815>
    e216:	e8 05 93 ff ff       	call   7520 <fwp_free_zombie>
    e21b:	48 83 3d c5 d5 05 00 	cmpq   $0x0,0x5d5c5(%rip)        # 6b7e8 <fwp_ready_head>
    e222:	00 
    e223:	0f 85 2c 55 ff ff    	jne    3755 <fwp_main_thread.cold>
    e229:	48 83 3d a7 d5 05 00 	cmpq   $0x0,0x5d5a7(%rip)        # 6b7d8 <fwp_timers>
    e230:	00 
    e231:	0f 85 1e 55 ff ff    	jne    3755 <fwp_main_thread.cold>
    e237:	8b 1d 97 cf 05 00    	mov    0x5cf97(%rip),%ebx        # 6b1d4 <fwp_stack_pool_n>
    e23d:	85 db                	test   %ebx,%ebx
    e23f:	74 36                	je     e277 <fwp_main_thread+0x4d7>
    e241:	83 eb 01             	sub    $0x1,%ebx
    e244:	48 8d 05 95 cf 05 00 	lea    0x5cf95(%rip),%rax        # 6b1e0 <fwp_stack_pool>
    e24b:	48 63 d3             	movslq %ebx,%rdx
    e24e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e252:	eb 07                	jmp    e25b <fwp_main_thread+0x4bb>
    e254:	0f 1f 40 00          	nopl   0x0(%rax)
    e258:	83 eb 01             	sub    $0x1,%ebx
    e25b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e25f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e264:	89 1d 6a cf 05 00    	mov    %ebx,0x5cf6a(%rip)        # 6b1d4 <fwp_stack_pool_n>
    e26a:	48 83 ed 08          	sub    $0x8,%rbp
    e26e:	e8 4d 53 ff ff       	call   35c0 <munmap@plt>
    e273:	85 db                	test   %ebx,%ebx
    e275:	75 e1                	jne    e258 <fwp_main_thread+0x4b8>
    e277:	8b 3d 9b 4d 00 00    	mov    0x4d9b(%rip),%edi        # 13018 <fwp_epfd>
    e27d:	85 ff                	test   %edi,%edi
    e27f:	78 05                	js     e286 <fwp_main_thread+0x4e6>
    e281:	e8 3a 52 ff ff       	call   34c0 <close@plt>
    e286:	4c 8b 25 53 d1 05 00 	mov    0x5d153(%rip),%r12        # 6b3e0 <fwp_nfdws>
    e28d:	48 8b 2d 54 d1 05 00 	mov    0x5d154(%rip),%rbp        # 6b3e8 <fwp_fdws>
    e294:	31 db                	xor    %ebx,%ebx
    e296:	c7 05 78 4d 00 00 ff 	movl   $0xffffffff,0x4d78(%rip)        # 13018 <fwp_epfd>
    e29d:	ff ff ff 
    e2a0:	4d 85 e4             	test   %r12,%r12
    e2a3:	74 38                	je     e2dd <fwp_main_thread+0x53d>
    e2a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e2ac:	00 00 00 00 
    e2b0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e2b5:	48 85 ff             	test   %rdi,%rdi
    e2b8:	74 1a                	je     e2d4 <fwp_main_thread+0x534>
    e2ba:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e2be:	0f 85 91 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e2c4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e2c9:	0f 85 86 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e2cf:	e8 3c 77 ff ff       	call   5a10 <fwp_mem_free>
    e2d4:	48 83 c3 01          	add    $0x1,%rbx
    e2d8:	49 39 dc             	cmp    %rbx,%r12
    e2db:	75 d3                	jne    e2b0 <fwp_main_thread+0x510>
    e2dd:	48 89 ef             	mov    %rbp,%rdi
    e2e0:	e8 2b 77 ff ff       	call   5a10 <fwp_mem_free>
    e2e5:	48 8b 15 0c d5 05 00 	mov    0x5d50c(%rip),%rdx        # 6b7f8 <fwp_root>
    e2ec:	48 c7 05 f1 d0 05 00 	movq   $0x0,0x5d0f1(%rip)        # 6b3e8 <fwp_fdws>
    e2f3:	00 00 00 00 
    e2f7:	48 c7 05 de d0 05 00 	movq   $0x0,0x5d0de(%rip)        # 6b3e0 <fwp_nfdws>
    e2fe:	00 00 00 00 
    e302:	48 85 d2             	test   %rdx,%rdx
    e305:	74 4e                	je     e355 <fwp_main_thread+0x5b5>
    e307:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e30c:	0f 85 43 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e312:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e319:	00 
    e31a:	0f 85 35 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e320:	48 83 3d 70 f1 05 00 	cmpq   $0x0,0x5f170(%rip)        # 6d498 <fwp_state_len>
    e327:	00 
    e328:	0f 85 27 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e32e:	48 83 3d 52 f1 05 00 	cmpq   $0x0,0x5f152(%rip)        # 6d488 <fwp_state_owners>
    e335:	00 
    e336:	0f 85 19 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e33c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e341:	31 c0                	xor    %eax,%eax
    e343:	48 8d 3d b6 d0 05 00 	lea    0x5d0b6(%rip),%rdi        # 6b400 <fwp_root_context>
    e34a:	f3 48 ab             	rep stos %rax,(%rdi)
    e34d:	48 89 d7             	mov    %rdx,%rdi
    e350:	e8 bb 76 ff ff       	call   5a10 <fwp_mem_free>
    e355:	66 0f 6f 05 53 4e 04 	movdqa 0x44e53(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    e35c:	00 
    e35d:	66 0f d4 05 3b 4e 04 	paddq  0x44e3b(%rip),%xmm0        # 531a0 <ad_raw_live>
    e364:	00 
    e365:	48 c7 05 90 d4 05 00 	movq   $0x0,0x5d490(%rip)        # 6b800 <fwp_cur>
    e36c:	00 00 00 00 
    e370:	48 8b 05 c9 e8 05 00 	mov    0x5e8c9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    e377:	48 c7 05 76 d4 05 00 	movq   $0x0,0x5d476(%rip)        # 6b7f8 <fwp_root>
    e37e:	00 00 00 00 
    e382:	c7 05 5c f1 05 00 00 	movl   $0x0,0x5f15c(%rip)        # 6d4e8 <iteration_active>
    e389:	00 00 00 
    e38c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    e390:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    e395:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    e399:	66 0f d6 05 57 4d 01 	movq   %xmm0,0x14d57(%rip)        # 230f8 <ad_raw_before_shutdown>
    e3a0:	00 
    e3a1:	48 85 c0             	test   %rax,%rax
    e3a4:	0f 88 26 01 00 00    	js     e4d0 <fwp_main_thread+0x730>
    e3aa:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e3ae:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    e3b3:	f2 0f 5c 0d 0d f1 05 	subsd  0x5f10d(%rip),%xmm1        # 6d4c8 <iteration_start_charge>
    e3ba:	00 
    e3bb:	48 8b 3d 7e 4c 00 00 	mov    0x4c7e(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    e3c2:	48 8d 15 a7 17 00 00 	lea    0x17a7(%rip),%rdx        # fb70 <_IO_stdin_used+0xb70>
    e3c9:	be 02 00 00 00       	mov    $0x2,%esi
    e3ce:	f2 0f 10 05 ea f0 05 	movsd  0x5f0ea(%rip),%xmm0        # 6d4c0 <iteration_peak>
    e3d5:	00 
    e3d6:	4c 8b 0d f3 f0 05 00 	mov    0x5f0f3(%rip),%r9        # 6d4d0 <iteration_retains>
    e3dd:	b8 02 00 00 00       	mov    $0x2,%eax
    e3e2:	4c 8b 05 ef f0 05 00 	mov    0x5f0ef(%rip),%r8        # 6d4d8 <iteration_bytes>
    e3e9:	48 8b 0d f0 f0 05 00 	mov    0x5f0f0(%rip),%rcx        # 6d4e0 <iteration_requests>
    e3f0:	e8 7b 52 ff ff       	call   3670 <__fprintf_chk@plt>
    e3f5:	48 8b 3d 24 4c 00 00 	mov    0x4c24(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e3fc:	e8 9f 51 ff ff       	call   35a0 <fflush@plt>
    e401:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e408:	00 
    e409:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e410:	00 00 
    e412:	0f 85 90 01 00 00    	jne    e5a8 <fwp_main_thread+0x808>
    e418:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e41f:	31 c0                	xor    %eax,%eax
    e421:	5b                   	pop    %rbx
    e422:	5d                   	pop    %rbp
    e423:	41 5c                	pop    %r12
    e425:	c3                   	ret
    e426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e42d:	00 00 00 
    e430:	48 89 05 a1 d3 05 00 	mov    %rax,0x5d3a1(%rip)        # 6b7d8 <fwp_timers>
    e437:	e9 e0 fb ff ff       	jmp    e01c <fwp_main_thread+0x27c>
    e43c:	0f 1f 40 00          	nopl   0x0(%rax)
    e440:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e444:	0f 85 d6 fc ff ff    	jne    e120 <fwp_main_thread+0x380>
    e44a:	48 89 ef             	mov    %rbp,%rdi
    e44d:	e8 de 5c ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e452:	e9 c9 fc ff ff       	jmp    e120 <fwp_main_thread+0x380>
    e457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e45e:	00 00 
    e460:	31 db                	xor    %ebx,%ebx
    e462:	48 83 3d 1e f0 05 00 	cmpq   $0x0,0x5f01e(%rip)        # 6d488 <fwp_state_owners>
    e469:	00 
    e46a:	0f 85 e7 fb ff ff    	jne    e057 <fwp_main_thread+0x2b7>
    e470:	48 8b 3d 29 f0 05 00 	mov    0x5f029(%rip),%rdi        # 6d4a0 <fwp_state>
    e477:	e8 94 75 ff ff       	call   5a10 <fwp_mem_free>
    e47c:	48 c7 05 19 f0 05 00 	movq   $0x0,0x5f019(%rip)        # 6d4a0 <fwp_state>
    e483:	00 00 00 00 
    e487:	48 c7 05 fe ef 05 00 	movq   $0x0,0x5effe(%rip)        # 6d490 <fwp_state_cap>
    e48e:	00 00 00 00 
    e492:	48 85 db             	test   %rbx,%rbx
    e495:	0f 84 ce 00 00 00    	je     e569 <fwp_main_thread+0x7c9>
    e49b:	48 39 1d 56 d3 05 00 	cmp    %rbx,0x5d356(%rip)        # 6b7f8 <fwp_root>
    e4a2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e4a9:	00 00 00 00 
    e4ad:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e4b4:	00 00 00 00 
    e4b8:	c7 05 be 4b 01 00 00 	movl   $0x0,0x14bbe(%rip)        # 23080 <fwp_exit_code>
    e4bf:	00 00 00 
    e4c2:	0f 84 af fb ff ff    	je     e077 <fwp_main_thread+0x2d7>
    e4c8:	e9 88 52 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e4cd:	0f 1f 00             	nopl   (%rax)
    e4d0:	48 89 c2             	mov    %rax,%rdx
    e4d3:	83 e0 01             	and    $0x1,%eax
    e4d6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e4da:	48 d1 ea             	shr    $1,%rdx
    e4dd:	48 09 c2             	or     %rax,%rdx
    e4e0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    e4e5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    e4e9:	e9 c5 fe ff ff       	jmp    e3b3 <fwp_main_thread+0x613>
    e4ee:	66 90                	xchg   %ax,%ax
    e4f0:	48 89 c2             	mov    %rax,%rdx
    e4f3:	83 e0 01             	and    $0x1,%eax
    e4f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e4fa:	48 d1 ea             	shr    $1,%rdx
    e4fd:	48 09 c2             	or     %rax,%rdx
    e500:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    e505:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    e509:	e9 9b f9 ff ff       	jmp    dea9 <fwp_main_thread+0x109>
    e50e:	66 90                	xchg   %ax,%ax
    e510:	48 8d 3d a9 67 ff ff 	lea    -0x9857(%rip),%rdi        # 4cc0 <fwp_heap_report>
    e517:	e8 b4 02 00 00       	call   e7d0 <atexit>
    e51c:	e9 bd f8 ff ff       	jmp    ddde <fwp_main_thread+0x3e>
    e521:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e528:	e8 a3 68 ff ff       	call   4dd0 <fwp_heap_init>
    e52d:	e9 9e f8 ff ff       	jmp    ddd0 <fwp_main_thread+0x30>
    e532:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e538:	e8 63 cb ff ff       	call   b0a0 <f0>
    e53d:	48 c7 05 20 4b 00 00 	movq   $0x0,0x4b20(%rip)        # 13068 <v.2>
    e544:	00 00 00 00 
    e548:	c7 05 1e 4b 00 00 01 	movl   $0x1,0x4b1e(%rip)        # 13070 <st.3>
    e54f:	00 00 00 
    e552:	e9 86 f9 ff ff       	jmp    dedd <fwp_main_thread+0x13d>
    e557:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e55e:	00 00 
    e560:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e564:	e9 28 fa ff ff       	jmp    df91 <fwp_main_thread+0x1f1>
    e569:	48 83 3d 87 d2 05 00 	cmpq   $0x0,0x5d287(%rip)        # 6b7f8 <fwp_root>
    e570:	00 
    e571:	c7 05 05 4b 01 00 00 	movl   $0x0,0x14b05(%rip)        # 23080 <fwp_exit_code>
    e578:	00 00 00 
    e57b:	0f 84 95 fc ff ff    	je     e216 <fwp_main_thread+0x476>
    e581:	e9 cf 51 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e586:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e58d:	00 00 00 
    e590:	48 8d 3d b1 15 00 00 	lea    0x15b1(%rip),%rdi        # fb48 <_IO_stdin_used+0xb48>
    e597:	e8 b4 5e ff ff       	call   4450 <fwp_trap>
    e59c:	48 8d 3d 30 0d 00 00 	lea    0xd30(%rip),%rdi        # f2d3 <_IO_stdin_used+0x2d3>
    e5a3:	e8 58 5a ff ff       	call   4000 <ad_raw_fail>
    e5a8:	e8 a3 4e ff ff       	call   3450 <__stack_chk_fail@plt>
    e5ad:	48 89 c8             	mov    %rcx,%rax
    e5b0:	e9 a4 fb ff ff       	jmp    e159 <fwp_main_thread+0x3b9>
    e5b5:	e9 9b 51 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e5ba:	e9 96 51 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e5bf:	90                   	nop

000000000000e5c0 <__divmodti4>:
    e5c0:	f3 0f 1e fa          	endbr64
    e5c4:	55                   	push   %rbp
    e5c5:	49 89 f1             	mov    %rsi,%r9
    e5c8:	49 89 d2             	mov    %rdx,%r10
    e5cb:	48 89 fe             	mov    %rdi,%rsi
    e5ce:	49 89 cb             	mov    %rcx,%r11
    e5d1:	48 89 e5             	mov    %rsp,%rbp
    e5d4:	41 57                	push   %r15
    e5d6:	41 56                	push   %r14
    e5d8:	41 55                	push   %r13
    e5da:	41 54                	push   %r12
    e5dc:	53                   	push   %rbx
    e5dd:	4c 89 c3             	mov    %r8,%rbx
    e5e0:	45 31 c0             	xor    %r8d,%r8d
    e5e3:	4d 85 c9             	test   %r9,%r9
    e5e6:	79 12                	jns    e5fa <__divmodti4+0x3a>
    e5e8:	31 ff                	xor    %edi,%edi
    e5ea:	48 f7 de             	neg    %rsi
    e5ed:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e5f4:	4c 19 cf             	sbb    %r9,%rdi
    e5f7:	49 89 f9             	mov    %rdi,%r9
    e5fa:	4c 89 d8             	mov    %r11,%rax
    e5fd:	4d 85 db             	test   %r11,%r11
    e600:	0f 88 1a 01 00 00    	js     e720 <__divmodti4+0x160>
    e606:	4c 89 d9             	mov    %r11,%rcx
    e609:	49 89 f3             	mov    %rsi,%r11
    e60c:	75 62                	jne    e670 <__divmodti4+0xb0>
    e60e:	4d 89 c4             	mov    %r8,%r12
    e611:	4d 39 d1             	cmp    %r10,%r9
    e614:	0f 83 46 01 00 00    	jae    e760 <__divmodti4+0x1a0>
    e61a:	4c 89 d8             	mov    %r11,%rax
    e61d:	4c 89 ca             	mov    %r9,%rdx
    e620:	49 f7 f2             	div    %r10
    e623:	49 89 c3             	mov    %rax,%r11
    e626:	31 c0                	xor    %eax,%eax
    e628:	48 89 d6             	mov    %rdx,%rsi
    e62b:	31 ff                	xor    %edi,%edi
    e62d:	4c 89 d9             	mov    %r11,%rcx
    e630:	48 89 c2             	mov    %rax,%rdx
    e633:	48 89 c8             	mov    %rcx,%rax
    e636:	4d 85 e4             	test   %r12,%r12
    e639:	74 0a                	je     e645 <__divmodti4+0x85>
    e63b:	48 f7 d8             	neg    %rax
    e63e:	48 83 d2 00          	adc    $0x0,%rdx
    e642:	48 f7 da             	neg    %rdx
    e645:	4d 85 c0             	test   %r8,%r8
    e648:	74 0a                	je     e654 <__divmodti4+0x94>
    e64a:	48 f7 de             	neg    %rsi
    e64d:	48 83 d7 00          	adc    $0x0,%rdi
    e651:	48 f7 df             	neg    %rdi
    e654:	48 89 33             	mov    %rsi,(%rbx)
    e657:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e65b:	5b                   	pop    %rbx
    e65c:	41 5c                	pop    %r12
    e65e:	41 5d                	pop    %r13
    e660:	41 5e                	pop    %r14
    e662:	41 5f                	pop    %r15
    e664:	5d                   	pop    %rbp
    e665:	c3                   	ret
    e666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e66d:	00 00 00 
    e670:	4d 89 c4             	mov    %r8,%r12
    e673:	49 39 c1             	cmp    %rax,%r9
    e676:	0f 82 ce 00 00 00    	jb     e74a <__divmodti4+0x18a>
    e67c:	31 ff                	xor    %edi,%edi
    e67e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e683:	48 63 c7             	movslq %edi,%rax
    e686:	be 40 00 00 00       	mov    $0x40,%esi
    e68b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e690:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e695:	48 29 c6             	sub    %rax,%rsi
    e698:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e69d:	48 09 c8             	or     %rcx,%rax
    e6a0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e6a5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e6aa:	49 89 c6             	mov    %rax,%r14
    e6ad:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e6b1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e6b6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e6bb:	49 09 c1             	or     %rax,%r9
    e6be:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e6c2:	4c 89 c8             	mov    %r9,%rax
    e6c5:	49 f7 f6             	div    %r14
    e6c8:	48 89 d1             	mov    %rdx,%rcx
    e6cb:	49 89 c3             	mov    %rax,%r11
    e6ce:	49 89 c1             	mov    %rax,%r9
    e6d1:	49 f7 e2             	mul    %r10
    e6d4:	49 89 c6             	mov    %rax,%r14
    e6d7:	49 89 d2             	mov    %rdx,%r10
    e6da:	48 39 d1             	cmp    %rdx,%rcx
    e6dd:	72 07                	jb     e6e6 <__divmodti4+0x126>
    e6df:	75 17                	jne    e6f8 <__divmodti4+0x138>
    e6e1:	49 39 c7             	cmp    %rax,%r15
    e6e4:	73 12                	jae    e6f8 <__divmodti4+0x138>
    e6e6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e6ea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e6ee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e6f2:	49 89 d2             	mov    %rdx,%r10
    e6f5:	49 89 c6             	mov    %rax,%r14
    e6f8:	4c 89 f8             	mov    %r15,%rax
    e6fb:	4c 29 f0             	sub    %r14,%rax
    e6fe:	4c 19 d1             	sbb    %r10,%rcx
    e701:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e706:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e70b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e710:	48 09 c6             	or     %rax,%rsi
    e713:	48 89 cf             	mov    %rcx,%rdi
    e716:	31 c0                	xor    %eax,%eax
    e718:	4c 89 c9             	mov    %r9,%rcx
    e71b:	e9 10 ff ff ff       	jmp    e630 <__divmodti4+0x70>
    e720:	4c 89 d0             	mov    %r10,%rax
    e723:	4c 89 da             	mov    %r11,%rdx
    e726:	4d 89 c4             	mov    %r8,%r12
    e729:	49 89 f3             	mov    %rsi,%r11
    e72c:	48 f7 d8             	neg    %rax
    e72f:	49 f7 d4             	not    %r12
    e732:	48 83 d2 00          	adc    $0x0,%rdx
    e736:	49 89 c2             	mov    %rax,%r10
    e739:	48 f7 da             	neg    %rdx
    e73c:	48 89 d1             	mov    %rdx,%rcx
    e73f:	0f 84 cc fe ff ff    	je     e611 <__divmodti4+0x51>
    e745:	49 39 d1             	cmp    %rdx,%r9
    e748:	73 46                	jae    e790 <__divmodti4+0x1d0>
    e74a:	4c 89 cf             	mov    %r9,%rdi
    e74d:	31 c0                	xor    %eax,%eax
    e74f:	31 c9                	xor    %ecx,%ecx
    e751:	e9 da fe ff ff       	jmp    e630 <__divmodti4+0x70>
    e756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e75d:	00 00 00 
    e760:	4d 85 d2             	test   %r10,%r10
    e763:	75 0d                	jne    e772 <__divmodti4+0x1b2>
    e765:	b8 01 00 00 00       	mov    $0x1,%eax
    e76a:	31 d2                	xor    %edx,%edx
    e76c:	49 f7 f2             	div    %r10
    e76f:	49 89 c2             	mov    %rax,%r10
    e772:	4c 89 c8             	mov    %r9,%rax
    e775:	31 d2                	xor    %edx,%edx
    e777:	49 f7 f2             	div    %r10
    e77a:	49 89 c1             	mov    %rax,%r9
    e77d:	4c 89 d8             	mov    %r11,%rax
    e780:	49 f7 f2             	div    %r10
    e783:	49 89 c3             	mov    %rax,%r11
    e786:	4c 89 c8             	mov    %r9,%rax
    e789:	e9 9a fe ff ff       	jmp    e628 <__divmodti4+0x68>
    e78e:	66 90                	xchg   %ax,%ax
    e790:	45 31 f6             	xor    %r14d,%r14d
    e793:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e798:	44 89 f7             	mov    %r14d,%edi
    e79b:	45 85 f6             	test   %r14d,%r14d
    e79e:	0f 85 df fe ff ff    	jne    e683 <__divmodti4+0xc3>
    e7a4:	4c 39 ca             	cmp    %r9,%rdx
    e7a7:	72 17                	jb     e7c0 <__divmodti4+0x200>
    e7a9:	31 c9                	xor    %ecx,%ecx
    e7ab:	48 39 c6             	cmp    %rax,%rsi
    e7ae:	73 10                	jae    e7c0 <__divmodti4+0x200>
    e7b0:	4c 89 cf             	mov    %r9,%rdi
    e7b3:	31 c0                	xor    %eax,%eax
    e7b5:	e9 76 fe ff ff       	jmp    e630 <__divmodti4+0x70>
    e7ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e7c0:	4c 89 de             	mov    %r11,%rsi
    e7c3:	b9 01 00 00 00       	mov    $0x1,%ecx
    e7c8:	48 29 c6             	sub    %rax,%rsi
    e7cb:	49 19 d1             	sbb    %rdx,%r9
    e7ce:	eb e0                	jmp    e7b0 <__divmodti4+0x1f0>

000000000000e7d0 <atexit>:
    e7d0:	f3 0f 1e fa          	endbr64
    e7d4:	48 8b 15 2d 48 00 00 	mov    0x482d(%rip),%rdx        # 13008 <__dso_handle>
    e7db:	31 f6                	xor    %esi,%esi
    e7dd:	e9 5e 4e ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e7e4 <_fini>:
    e7e4:	f3 0f 1e fa          	endbr64
    e7e8:	48 83 ec 08          	sub    $0x8,%rsp
    e7ec:	48 83 c4 08          	add    $0x8,%rsp
    e7f0:	c3                   	ret
