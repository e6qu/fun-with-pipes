
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 db 00 00 	lea    0xdb81(%rip),%rax        # 11300 <fwp_fn_table>
    377f:	48 89 05 92 1c 02 00 	mov    %rax,0x21c92(%rip)        # 25418 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c 1c 02 00 	mov    %rax,0x21c8c(%rip)        # 25420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ef 9f 00 00 	lea    0x9fef(%rip),%rdx        # d850 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 86 c1 00 00 	lea    0xc186(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 40 c1 00 00 	lea    0xc140(%rip),%rdi        # fa68 <_IO_stdin_used+0xa68>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 04 c1 00 00 	lea    0xc104(%rip),%rdi        # fa38 <_IO_stdin_used+0xa38>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d d0 c0 00 00 	lea    0xc0d0(%rip),%rdi        # fa10 <_IO_stdin_used+0xa10>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce f4 01 00 	add    0x1f4ce(%rip),%rdx        # 230f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc f4 01 00 	add    0x1f4bc(%rip),%rax        # 230f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 17 02 00 	mov    0x217a9(%rip),%rdi        # 25420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 f3 00 00 	mov    0xf394(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 f3 00 00 	mov    0xf381(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 f3 00 00 	mov    0xf372(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 fa 01 00 	mov    0x1faa1(%rip),%rax        # 237a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 f3 01 00 	mov    0x1f3d9(%rip),%rax        # 23158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 f3 01 00 	sub    0x1f3c5(%rip),%rax        # 23150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 87 b8 00 00 	lea    0xb887(%rip),%rdi        # f670 <_IO_stdin_used+0x670>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 f2 00 00 	mov    0xf242(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 f1 00 00 ff 	cmpl   $0xffffffff,0xf1e5(%rip)        # 13018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 f2 01 00 	mov    0x1f2c1(%rip),%r9        # 23108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c f2 01 00 	mov    0x1f29c(%rip),%r8        # 23100 <descent_inputs>
    3e64:	48 8b 0d a5 f2 01 00 	mov    0x1f2a5(%rip),%rcx        # 23110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 f1 00 00 	mov    0xf1c2(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 20 b8 00 00 	lea    0xb820(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 f2 01 00 	lea    0x1f271(%rip),%r12        # 23120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b f1 00 00 	mov    0xf15b(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 f1 00 00 	mov    0xf120(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 f0 00 00 	mov    0xf0f9(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b 0c 02 00 	mov    0x20c1b(%rip),%rax        # 24bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 0c 02 00 	lea    0x20c14(%rip),%r8        # 24bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 0b 02 00 	mov    0x20bf5(%rip),%rbx        # 24b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 0c 02 00 	mov    0x20c05(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 0b 02 00 	mov    0x20ba1(%rip),%rdi        # 24ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea 0b 02 00 	sub    %rsi,0x20bea(%rip)        # 24bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a 0b 02 00 	mov    0x20b7a(%rip),%rax        # 24b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 0b 02 00 	add    0x20b30(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e 0b 02 00 	mov    0x20b3e(%rip),%rsi        # 24ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c 0b 02 00 	mov    0x20b4c(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb 0a 02 00 	mov    %r12,0x20afb(%rip)        # 24ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 0a 02 00 	mov    %rbp,0x20ae9(%rip)        # 24b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce 0a 02 00 	cmp    %rdi,0x20ace(%rip)        # 24b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 0a 02 00 	mov    %rdi,0x20ac5(%rip)        # 24b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 0b 02 00 	sub    %rdi,0x20b09(%rip)        # 24bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 0a 02 00 	mov    0x20ab1(%rip),%rax        # 24ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa 0a 02 00 	lea    0x20aaa(%rip),%r8        # 24ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d ee 00 00 	mov    0xee5d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad ed 00 00 	movslq 0xedad(%rip),%rbp        # 13018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a ee 01 00 	mov    0x1ee7a(%rip),%rsi        # 23118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 ee 01 00 	lea    0x1ee76(%rip),%rcx        # 23120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b ee 01 00 	addq   $0x1,0x1ee4b(%rip)        # 23110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 ed 00 00    	mov    %ebx,0xed48(%rip)        # 13018 <descent_active_phase>
    42d0:	48 89 05 41 ee 01 00 	mov    %rax,0x1ee41(%rip)        # 23118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 f4 01 00 	cmp    0x1f499(%rip),%rdi        # 237a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f f4 01 00 	mov    0x1f45f(%rip),%rax        # 23780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d f4 01 00 	mov    %rdi,0x1f43d(%rip)        # 23780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 f4 01 00 	mov    %rdi,0x1f419(%rip)        # 23788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee ad 00 00 	lea    0xadee(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 ec 00 00 	mov    0xec28(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 ec 00 00 	mov    0xec10(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 eb 00 00 	mov    0xeb21(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 18 b1 00 00 	lea    0xb118(%rip),%rdi        # f708 <_IO_stdin_used+0x708>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 b0 b5 00 	movdqa 0xb5b0(%rip),%xmm0        # fbc0 <msg.4+0x50>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa 0d 02 00 	add    0x20daa(%rip),%rax        # 25418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 6c b0 00 00 	lea    0xb06c(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 ea 01 00 	cmp    %rax,0x1ea05(%rip)        # 230e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 ea 01 00 	add    0x1ea00(%rip),%rax        # 230f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 55 b0 00 00 	lea    0xb055(%rip),%rdi        # f760 <_IO_stdin_used+0x760>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 fe 01 00 	mov    0x1fe85(%rip),%r9        # 24b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de fe 01 00 	mov    0x1fede(%rip),%r8        # 24be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 9f aa 00 00 	lea    0xaa9f(%rip),%rdx        # f7b0 <_IO_stdin_used+0x7b0>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 fe 01 00 	mov    0x1fec6(%rip),%rcx        # 24be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 fe 01 	movsd  0x1fed4(%rip),%xmm1        # 24c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 fe 01 	movsd  0x1fec4(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 e3 00 00 	mov    0xe305(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 58 ae 00 	movdqa 0xae58(%rip),%xmm0        # fbd0 <msg.4+0x60>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f f9 01 00 	lea    0x1f97f(%rip),%rax        # 24700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 81 ae 00 	movdqa 0xae81(%rip),%xmm2        # fc10 <msg.4+0xa0>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 f9 01 00 	movaps %xmm0,0x1f925(%rip)        # 246c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 3d ae 00 	movdqa 0xae3d(%rip),%xmm0        # fbe0 <msg.4+0x70>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 fd 01 00 01 	movl   $0x1,0x1fdb3(%rip)        # 24b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 f9 01 00 	movaps %xmm0,0x1f913(%rip)        # 246d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 2b ae 00 	movdqa 0xae2b(%rip),%xmm0        # fbf0 <msg.4+0x80>
    4dc4:	00 
    4dc5:	0f 29 05 14 f9 01 00 	movaps %xmm0,0x1f914(%rip)        # 246e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 2c ae 00 	movdqa 0xae2c(%rip),%xmm0        # fc00 <msg.4+0x90>
    4dd3:	00 
    4dd4:	0f 29 05 15 f9 01 00 	movaps %xmm0,0x1f915(%rip)        # 246f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 e9 01 00 	lea    0x1e995(%rip),%r8        # 237c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 fc 01 00 	mov    %rax,0x1fcb0(%rip)        # 24b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e fc 01 00 	mov    %r12,0x1fc8e(%rip)        # 24b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 fc 01 00 	mov    %rax,0x1fc77(%rip)        # 24b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 fc 01 00 	mov    %rbx,0x1fc90(%rip)        # 24b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 fc 01 00 	mov    %rsi,0x1fcb9(%rip)        # 24bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 fc 01 00 	mov    %rax,0x1fc98(%rip)        # 24bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c fc 01 00    	mov    %eax,0x1fc1c(%rip)        # 24b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c e8 01 00 	mov    0x1e80c(%rip),%r8        # 23780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c e7 01 00 	mov    %rbx,0x1e73c(%rip)        # 23788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 e7 01 00 	mov    %r8,0x1e728(%rip)        # 23780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c a0 00 00 	lea    0xa05c(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d df 01 00 	lea    0x1df9d(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 df 01 00 	movaps %xmm0,0x1df85(%rip)        # 230a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 df 01 00 	mov    %rax,0x1df61(%rip)        # 23088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 df 01 00 	movaps %xmm0,0x1df82(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 df 01 00 	movaps %xmm0,0x1df86(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 df 01 00 	mov    %rdx,0x1df87(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 9f 00 00 	lea    0x9fb3(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 e5 01 00 	mov    0x1e5b7(%rip),%rbx        # 23778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a dd 00 00 	mov    0xdd8a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 7b a5 00 00 	lea    0xa57b(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d e4 01 00 	mov    0x1e48d(%rip),%rax        # 23780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 e4 01 00 	mov    %rdx,0x1e467(%rip)        # 23780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 e3 01 00 	mov    0x1e3b4(%rip),%rbx        # 23778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 e3 01 00 	mov    %rbx,0x1e371(%rip)        # 23778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 e3 01 00 	mov    %rdx,0x1e371(%rip)        # 23788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 e3 01 00 	lea    0x1e386(%rip),%rsi        # 237c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 ff 01 00 	addq   $0x1,0x1ff05(%rip)        # 25408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 4f a3 00 00 	lea    0xa34f(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 60 a3 00 00 	lea    0xa360(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 9b 00 00 	lea    0x9bf7(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e e2 01 00 	lea    0x1e23e(%rip),%rcx        # 237c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f fe 01 00 	subq   $0x1,0x1fe3f(%rip)        # 25408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d bb a2 00 00 	lea    0xa2bb(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 fe 01 00 	cmpq   $0x0,0x1fe20(%rip)        # 25408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 fd 01 00 	sub    %rax,0x1fd75(%rip)        # 25410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 fd 01 00 	add    %r12,0x1fd53(%rip)        # 25410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af f4 01 00 	mov    0x1f4af(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac e0 01 00 	lea    0x1e0ac(%rip),%rax        # 237c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 f4 01 00 	add    0x1f403(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 f3 01 00 	mov    0x1f3d0(%rip),%rsi        # 24b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 f3 01 00 	mov    0x1f3f1(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 f3 01 00 	add    0x1f3e5(%rip),%r8        # 24bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad f3 01 	addsd  0x1f3ad(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 df 01 00 	lea    0x1df62(%rip),%rax        # 237c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c f3 01 00 	sub    %rdi,0x1f36c(%rip)        # 24be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 f3 01 	movsd  %xmm0,0x1f384(%rip)        # 24c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e f3 01 00 	sub    %rdx,0x1f33e(%rip)        # 24be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 f3 01 	addsd  0x1f344(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 f3 01 	movsd  %xmm0,0x1f338(%rip)        # 24c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf f2 01 00 	mov    0x1f2cf(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 f2 01 00 	add    %rcx,0x1f2c9(%rip)        # 24bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 f2 01 00 	cmp    0x1f282(%rip),%r9        # 24bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 f2 01 00 	mov    %r9,0x1f279(%rip)        # 24bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a f2 01 00 	cmp    0x1f26a(%rip),%r9        # 24ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d f2 01 00 	mov    %r9,0x1f25d(%rip)        # 24ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 f1 01 00 	add    0x1f173(%rip),%rdi        # 24bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 dd 01 00 	lea    0x1dd50(%rip),%r15        # 237c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 f0 01 00 	add    0x1f0c0(%rip),%r12        # 24b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 f1 01 00 	add    0x1f119(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 f1 01 00 	cmp    %rax,0x1f118(%rip)        # 24be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 f1 01 00 	mov    %rax,0x1f109(%rip)        # 24be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 f1 01 00 	mov    %rax,0x1f108(%rip)        # 24be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 f1 01 	addsd  0x1f104(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc f0 01 	movsd  %xmm0,0x1f0fc(%rip)        # 24bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 f0 01 00    	mov    0x1f043(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f dc 01 00 	lea    0x1dc7f(%rip),%rdi        # 237c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 f0 01 00 	add    0x1f038(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 f0 01 00 	cmp    %rax,0x1f033(%rip)        # 24be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 f0 01 00 	mov    %rax,0x1f024(%rip)        # 24be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 f0 01 00 	mov    %rax,0x1f023(%rip)        # 24be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f f0 01 	addsd  0x1f01f(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 f0 01 	movsd  %xmm0,0x1f017(%rip)        # 24bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce ee 01 00    	mov    0x1eece(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 db 01 00 	lea    0x1db05(%rip),%rax        # 237c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb ee 01 00 	add    0x1eebb(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba ee 01 00 	cmp    %rax,0x1eeba(%rip)        # 24be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab ee 01 00 	mov    %rax,0x1eeab(%rip)        # 24be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa ee 01 00 	mov    %rax,0x1eeaa(%rip)        # 24be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 ee 01 	addsd  0x1eea6(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e ee 01 	movsd  %xmm0,0x1ee9e(%rip)        # 24bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_data.part.0.constprop.0>:
    5db0:	41 56                	push   %r14
    5db2:	41 89 fe             	mov    %edi,%r14d
    5db5:	41 54                	push   %r12
    5db7:	49 89 f4             	mov    %rsi,%r12
    5dba:	55                   	push   %rbp
    5dbb:	53                   	push   %rbx
    5dbc:	48 83 ec 08          	sub    $0x8,%rsp
    5dc0:	8b 05 9e ed 01 00    	mov    0x1ed9e(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5dc6:	85 c0                	test   %eax,%eax
    5dc8:	0f 84 fa 00 00 00    	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5dce:	0f b6 05 8d e9 01 00 	movzbl 0x1e98d(%rip),%eax        # 24762 <fwp_heap+0xfa2>
    5dd5:	48 8d 15 e4 d9 01 00 	lea    0x1d9e4(%rip),%rdx        # 237c0 <fwp_heap>
    5ddc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5de3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5de7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5deb:	48 8b 18             	mov    (%rax),%rbx
    5dee:	48 85 db             	test   %rbx,%rbx
    5df1:	0f 84 a9 00 00 00    	je     5ea0 <fwp_data.part.0.constprop.0+0xf0>
    5df7:	48 8b 13             	mov    (%rbx),%rdx
    5dfa:	48 f7 d2             	not    %rdx
    5dfd:	48 89 10             	mov    %rdx,(%rax)
    5e00:	48 83 fd 18          	cmp    $0x18,%rbp
    5e04:	76 1b                	jbe    5e21 <fwp_data.part.0.constprop.0+0x71>
    5e06:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e0a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e0e:	31 f6                	xor    %esi,%esi
    5e10:	48 c1 e8 03          	shr    $0x3,%rax
    5e14:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e1b:	00 
    5e1c:	e8 9f d6 ff ff       	call   34c0 <memset@plt>
    5e21:	48 89 e8             	mov    %rbp,%rax
    5e24:	48 03 05 b5 ed 01 00 	add    0x1edb5(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5e2b:	0f 82 a8 00 00 00    	jb     5ed9 <fwp_data.part.0.constprop.0+0x129>
    5e31:	48 39 05 b0 ed 01 00 	cmp    %rax,0x1edb0(%rip)        # 24be8 <fwp_heap+0x1428>
    5e38:	48 89 05 a1 ed 01 00 	mov    %rax,0x1eda1(%rip)        # 24be0 <fwp_heap+0x1420>
    5e3f:	73 07                	jae    5e48 <fwp_data.part.0.constprop.0+0x98>
    5e41:	48 89 05 a0 ed 01 00 	mov    %rax,0x1eda0(%rip)        # 24be8 <fwp_heap+0x1428>
    5e48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e4c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e51:	f2 0f 58 05 9f ed 01 	addsd  0x1ed9f(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 97 ed 01 	movsd  %xmm0,0x1ed97(%rip)        # 24bf8 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	b8 02 00 00 00       	mov    $0x2,%eax
    5e66:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e6b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e6f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e73:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e77:	49 8b 04 24          	mov    (%r12),%rax
    5e7b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e7f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e84:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e88:	48 83 c4 08          	add    $0x8,%rsp
    5e8c:	48 89 d8             	mov    %rbx,%rax
    5e8f:	5b                   	pop    %rbx
    5e90:	5d                   	pop    %rbp
    5e91:	41 5c                	pop    %r12
    5e93:	41 5e                	pop    %r14
    5e95:	c3                   	ret
    5e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e9d:	00 00 00 
    5ea0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5ea4:	48 85 db             	test   %rbx,%rbx
    5ea7:	74 1f                	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5ea9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ead:	48 29 da             	sub    %rbx,%rdx
    5eb0:	48 39 ea             	cmp    %rbp,%rdx
    5eb3:	72 13                	jb     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5eb5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5eb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ebd:	e9 3e ff ff ff       	jmp    5e00 <fwp_data.part.0.constprop.0+0x50>
    5ec2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ec8:	31 f6                	xor    %esi,%esi
    5eca:	bf 18 00 00 00       	mov    $0x18,%edi
    5ecf:	e8 bc fd ff ff       	call   5c90 <fwp_heap_alloc>
    5ed4:	48 89 c3             	mov    %rax,%rbx
    5ed7:	eb 88                	jmp    5e61 <fwp_data.part.0.constprop.0+0xb1>
    5ed9:	e8 d2 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5ede:	66 90                	xchg   %ax,%ax

0000000000005ee0 <fwp_p_ad_push.constprop.0>:
    5ee0:	41 57                	push   %r15
    5ee2:	41 56                	push   %r14
    5ee4:	41 55                	push   %r13
    5ee6:	49 89 d5             	mov    %rdx,%r13
    5ee9:	41 54                	push   %r12
    5eeb:	49 89 fc             	mov    %rdi,%r12
    5eee:	55                   	push   %rbp
    5eef:	53                   	push   %rbx
    5ef0:	48 83 ec 38          	sub    $0x38,%rsp
    5ef4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5ef9:	48 85 ff             	test   %rdi,%rdi
    5efc:	79 09                	jns    5f07 <fwp_p_ad_push.constprop.0+0x27>
    5efe:	48 85 d2             	test   %rdx,%rdx
    5f01:	0f 88 a9 01 00 00    	js     60b0 <fwp_p_ad_push.constprop.0+0x1d0>
    5f07:	48 89 f8             	mov    %rdi,%rax
    5f0a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f0e:	48 09 d0             	or     %rdx,%rax
    5f11:	0f 89 79 01 00 00    	jns    6090 <fwp_p_ad_push.constprop.0+0x1b0>
    5f17:	48 89 f8             	mov    %rdi,%rax
    5f1a:	48 c1 f8 20          	sar    $0x20,%rax
    5f1e:	48 85 ff             	test   %rdi,%rdi
    5f21:	79 24                	jns    5f47 <fwp_p_ad_push.constprop.0+0x67>
    5f23:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5f28:	48 89 d0             	mov    %rdx,%rax
    5f2b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5f32:	00 
    5f33:	49 89 d4             	mov    %rdx,%r12
    5f36:	48 c1 f8 20          	sar    $0x20,%rax
    5f3a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5f41:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5f47:	48 89 c7             	mov    %rax,%rdi
    5f4a:	e8 81 e7 ff ff       	call   46d0 <fwp_tape_of>
    5f4f:	48 89 c3             	mov    %rax,%rbx
    5f52:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5f57:	0f 85 f0 02 00 00    	jne    624d <fwp_p_ad_push.constprop.0+0x36d>
    5f5d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5f61:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5f68:	0f 8f 51 02 00 00    	jg     61bf <fwp_p_ad_push.constprop.0+0x2df>
    5f6e:	44 89 e0             	mov    %r12d,%eax
    5f71:	49 39 c7             	cmp    %rax,%r15
    5f74:	0f 8e 51 02 00 00    	jle    61cb <fwp_p_ad_push.constprop.0+0x2eb>
    5f7a:	4d 85 ed             	test   %r13,%r13
    5f7d:	78 0c                	js     5f8b <fwp_p_ad_push.constprop.0+0xab>
    5f7f:	44 89 e8             	mov    %r13d,%eax
    5f82:	49 39 c7             	cmp    %rax,%r15
    5f85:	0f 8e 40 02 00 00    	jle    61cb <fwp_p_ad_push.constprop.0+0x2eb>
    5f8b:	4d 89 fe             	mov    %r15,%r14
    5f8e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5f92:	49 8d 46 01          	lea    0x1(%r14),%rax
    5f96:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5f9c:	0f 87 1d 02 00 00    	ja     61bf <fwp_p_ad_push.constprop.0+0x2df>
    5fa2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5fa6:	48 39 e8             	cmp    %rbp,%rax
    5fa9:	0f 8e 31 01 00 00    	jle    60e0 <fwp_p_ad_push.constprop.0+0x200>
    5faf:	48 85 ed             	test   %rbp,%rbp
    5fb2:	b9 40 00 00 00       	mov    $0x40,%ecx
    5fb7:	48 0f 44 e9          	cmove  %rcx,%rbp
    5fbb:	48 39 e8             	cmp    %rbp,%rax
    5fbe:	7e 20                	jle    5fe0 <fwp_p_ad_push.constprop.0+0x100>
    5fc0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5fc7:	0f 8f 03 01 00 00    	jg     60d0 <fwp_p_ad_push.constprop.0+0x1f0>
    5fcd:	48 01 ed             	add    %rbp,%rbp
    5fd0:	48 39 e8             	cmp    %rbp,%rax
    5fd3:	7f eb                	jg     5fc0 <fwp_p_ad_push.constprop.0+0xe0>
    5fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fdc:	00 00 00 00 
    5fe0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5fe7:	00 
    5fe8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5fec:	48 89 c6             	mov    %rax,%rsi
    5fef:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5ff4:	e8 d7 d5 ff ff       	call   35d0 <realloc@plt>
    5ff9:	48 85 c0             	test   %rax,%rax
    5ffc:	0f 84 d5 01 00 00    	je     61d7 <fwp_p_ad_push.constprop.0+0x2f7>
    6002:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6006:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    600a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    600e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6012:	48 89 e9             	mov    %rbp,%rcx
    6015:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6019:	48 c1 e1 04          	shl    $0x4,%rcx
    601d:	48 89 ce             	mov    %rcx,%rsi
    6020:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6025:	e8 a6 d5 ff ff       	call   35d0 <realloc@plt>
    602a:	48 85 c0             	test   %rax,%rax
    602d:	0f 84 a4 01 00 00    	je     61d7 <fwp_p_ad_push.constprop.0+0x2f7>
    6033:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6037:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    603c:	4d 85 f6             	test   %r14,%r14
    603f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6043:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6048:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    604f:	00 
    6050:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    6057:	00 
    6058:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    605c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    6063:	00 
    6064:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6068:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    606c:	0f 85 e6 00 00 00    	jne    6158 <fwp_p_ad_push.constprop.0+0x278>
    6072:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6076:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    607a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    607e:	49 01 c8             	add    %rcx,%r8
    6081:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    6085:	eb 79                	jmp    6100 <fwp_p_ad_push.constprop.0+0x220>
    6087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    608e:	00 00 
    6090:	48 89 d0             	mov    %rdx,%rax
    6093:	48 c1 ff 20          	sar    $0x20,%rdi
    6097:	48 c1 f8 20          	sar    $0x20,%rax
    609b:	48 39 c7             	cmp    %rax,%rdi
    609e:	0f 84 a3 fe ff ff    	je     5f47 <fwp_p_ad_push.constprop.0+0x67>
    60a4:	48 8d 3d 0d 98 00 00 	lea    0x980d(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    60ab:	e8 40 e3 ff ff       	call   43f0 <fwp_trap>
    60b0:	48 83 c4 38          	add    $0x38,%rsp
    60b4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    60bb:	5b                   	pop    %rbx
    60bc:	5d                   	pop    %rbp
    60bd:	41 5c                	pop    %r12
    60bf:	41 5d                	pop    %r13
    60c1:	41 5e                	pop    %r14
    60c3:	41 5f                	pop    %r15
    60c5:	c3                   	ret
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    60d5:	e9 06 ff ff ff       	jmp    5fe0 <fwp_p_ad_push.constprop.0+0x100>
    60da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    60e0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    60e4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    60e8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    60ef:	00 
    60f0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    60f7:	00 
    60f8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    60fc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6100:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6106:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    610a:	4d 85 ed             	test   %r13,%r13
    610d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6112:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6118:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    611f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6123:	49 8d 47 01          	lea    0x1(%r15),%rax
    6127:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    612b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6131:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6135:	48 83 c4 38          	add    $0x38,%rsp
    6139:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6140:	ff ff ff 
    6143:	4c 21 e0             	and    %r12,%rax
    6146:	5b                   	pop    %rbx
    6147:	5d                   	pop    %rbp
    6148:	4c 09 f8             	or     %r15,%rax
    614b:	41 5c                	pop    %r12
    614d:	41 5d                	pop    %r13
    614f:	41 5e                	pop    %r14
    6151:	41 5f                	pop    %r15
    6153:	c3                   	ret
    6154:	0f 1f 40 00          	nopl   0x0(%rax)
    6158:	48 39 ca             	cmp    %rcx,%rdx
    615b:	49 89 d6             	mov    %rdx,%r14
    615e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    6163:	48 0f 43 ca          	cmovae %rdx,%rcx
    6167:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    616c:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6171:	48 29 d1             	sub    %rdx,%rcx
    6174:	4c 89 ca             	mov    %r9,%rdx
    6177:	e8 e4 d3 ff ff       	call   3560 <__memmove_chk@plt>
    617c:	4c 03 73 30          	add    0x30(%rbx),%r14
    6180:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6185:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6189:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    618e:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6192:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6196:	4c 89 d2             	mov    %r10,%rdx
    6199:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    619e:	e8 6d d4 ff ff       	call   3610 <memmove@plt>
    61a3:	48 8b 43 30          	mov    0x30(%rbx),%rax
    61a7:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    61ab:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    61b0:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    61b5:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    61ba:	e9 b7 fe ff ff       	jmp    6076 <fwp_p_ad_push.constprop.0+0x196>
    61bf:	48 8d 3d 86 8f 00 00 	lea    0x8f86(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    61c6:	e8 25 e2 ff ff       	call   43f0 <fwp_trap>
    61cb:	48 8d 3d 95 8f 00 00 	lea    0x8f95(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    61d2:	e8 19 e2 ff ff       	call   43f0 <fwp_trap>
    61d7:	48 89 df             	mov    %rbx,%rdi
    61da:	e8 21 da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    61df:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    61e3:	e8 d8 d1 ff ff       	call   33c0 <free@plt>
    61e8:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    61ec:	e8 cf d1 ff ff       	call   33c0 <free@plt>
    61f1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    61f5:	e8 c6 d1 ff ff       	call   33c0 <free@plt>
    61fa:	31 c9                	xor    %ecx,%ecx
    61fc:	31 c0                	xor    %eax,%eax
    61fe:	31 d2                	xor    %edx,%edx
    6200:	89 53 04             	mov    %edx,0x4(%rbx)
    6203:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6207:	ba 13 00 00 00       	mov    $0x13,%edx
    620c:	be 01 00 00 00       	mov    $0x1,%esi
    6211:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6215:	48 8d 3d ec 8d 00 00 	lea    0x8dec(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    621c:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6220:	48 8b 0d 19 ce 00 00 	mov    0xce19(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    6227:	48 89 43 40          	mov    %rax,0x40(%rbx)
    622b:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    622f:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6233:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6237:	e8 44 d4 ff ff       	call   3680 <fwrite@plt>
    623c:	31 ff                	xor    %edi,%edi
    623e:	e8 7d d3 ff ff       	call   35c0 <fflush@plt>
    6243:	bf 66 00 00 00       	mov    $0x66,%edi
    6248:	e8 53 d4 ff ff       	call   36a0 <_Exit@plt>
    624d:	48 8d 3d ac 96 00 00 	lea    0x96ac(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    6254:	e8 97 e1 ff ff       	call   43f0 <fwp_trap>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006260 <w120>:
    6260:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6264:	41 55                	push   %r13
    6266:	48 89 fa             	mov    %rdi,%rdx
    6269:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    626d:	41 54                	push   %r12
    626f:	49 89 fc             	mov    %rdi,%r12
    6272:	55                   	push   %rbp
    6273:	53                   	push   %rbx
    6274:	48 89 f3             	mov    %rsi,%rbx
    6277:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    627c:	48 89 f1             	mov    %rsi,%rcx
    627f:	48 83 ec 28          	sub    $0x28,%rsp
    6283:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6289:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    628f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6295:	e8 46 fc ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    629a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    62a0:	48 89 da             	mov    %rbx,%rdx
    62a3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    62a9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62b0:	00 f0 3f 
    62b3:	48 89 c7             	mov    %rax,%rdi
    62b6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    62bd:	00 f0 bf 
    62c0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    62c5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    62cb:	e8 10 fc ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    62d0:	f2 0f 10 05 c0 98 00 	movsd  0x98c0(%rip),%xmm0        # fb98 <msg.4+0x28>
    62d7:	00 
    62d8:	4c 89 e7             	mov    %r12,%rdi
    62db:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    62e1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62e8:	00 f0 3f 
    62eb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    62f2:	49 89 c5             	mov    %rax,%r13
    62f5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    62fc:	00 f0 bf 
    62ff:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6304:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    630a:	e8 d1 fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    630f:	48 89 e9             	mov    %rbp,%rcx
    6312:	4c 89 ea             	mov    %r13,%rdx
    6315:	48 89 ee             	mov    %rbp,%rsi
    6318:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    631e:	4c 89 ef             	mov    %r13,%rdi
    6321:	49 89 c4             	mov    %rax,%r12
    6324:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6328:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    632e:	e8 ad fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    6333:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6339:	f2 0f 59 1d 5f 98 00 	mulsd  0x985f(%rip),%xmm3        # fba0 <msg.4+0x30>
    6340:	00 
    6341:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6348:	00 59 40 
    634b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6350:	48 89 c2             	mov    %rax,%rdx
    6353:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    635a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6360:	e8 7b fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    6365:	48 89 d9             	mov    %rbx,%rcx
    6368:	4c 89 e2             	mov    %r12,%rdx
    636b:	48 89 de             	mov    %rbx,%rsi
    636e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6374:	4c 89 e7             	mov    %r12,%rdi
    6377:	48 89 c5             	mov    %rax,%rbp
    637a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    637e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6384:	e8 57 fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    6389:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    638f:	48 89 ea             	mov    %rbp,%rdx
    6392:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6398:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    639f:	00 f0 3f 
    63a2:	48 89 c7             	mov    %rax,%rdi
    63a5:	48 89 ce             	mov    %rcx,%rsi
    63a8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    63ad:	e8 2e fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    63b2:	48 83 c4 28          	add    $0x28,%rsp
    63b6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    63bb:	5b                   	pop    %rbx
    63bc:	5d                   	pop    %rbp
    63bd:	41 5c                	pop    %r12
    63bf:	41 5d                	pop    %r13
    63c1:	c3                   	ret
    63c2:	0f 1f 00             	nopl   (%rax)
    63c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63cc:	00 00 00 00 

00000000000063d0 <w176.constprop.0>:
    63d0:	41 54                	push   %r12
    63d2:	55                   	push   %rbp
    63d3:	53                   	push   %rbx
    63d4:	48 83 ec 10          	sub    $0x10,%rsp
    63d8:	4c 8b 27             	mov    (%rdi),%r12
    63db:	4d 85 e4             	test   %r12,%r12
    63de:	74 58                	je     6438 <w176.constprop.0+0x68>
    63e0:	48 89 fd             	mov    %rdi,%rbp
    63e3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    63e7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63ee:	31 db                	xor    %ebx,%ebx
    63f0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    63f6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    63fb:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6402:	00 f0 3f 
    6405:	48 83 c3 02          	add    $0x2,%rbx
    6409:	48 89 ce             	mov    %rcx,%rsi
    640c:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6412:	e8 c9 fa ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    6417:	4c 39 e3             	cmp    %r12,%rbx
    641a:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6420:	48 89 c7             	mov    %rax,%rdi
    6423:	72 cb                	jb     63f0 <w176.constprop.0+0x20>
    6425:	48 83 c4 10          	add    $0x10,%rsp
    6429:	48 89 f8             	mov    %rdi,%rax
    642c:	5b                   	pop    %rbx
    642d:	5d                   	pop    %rbp
    642e:	41 5c                	pop    %r12
    6430:	c3                   	ret
    6431:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6438:	48 83 c4 10          	add    $0x10,%rsp
    643c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6443:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6447:	5b                   	pop    %rbx
    6448:	48 89 f8             	mov    %rdi,%rax
    644b:	5d                   	pop    %rbp
    644c:	41 5c                	pop    %r12
    644e:	c3                   	ret
    644f:	90                   	nop

0000000000006450 <fwp_rc_share>:
    6450:	48 8b 05 41 e7 01 00 	mov    0x1e741(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    6457:	48 2b 3d 12 e7 01 00 	sub    0x1e712(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    645e:	48 c1 e0 10          	shl    $0x10,%rax
    6462:	48 39 c7             	cmp    %rax,%rdi
    6465:	73 4a                	jae    64b1 <fwp_rc_share+0x61>
    6467:	48 89 f8             	mov    %rdi,%rax
    646a:	48 c1 e8 10          	shr    $0x10,%rax
    646e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6472:	48 8b 05 3f e7 01 00 	mov    0x1e73f(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    6479:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    647d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6481:	48 85 d2             	test   %rdx,%rdx
    6484:	74 2b                	je     64b1 <fwp_rc_share+0x61>
    6486:	0f b6 08             	movzbl (%rax),%ecx
    6489:	80 f9 02             	cmp    $0x2,%cl
    648c:	74 2a                	je     64b8 <fwp_rc_share+0x68>
    648e:	80 f9 01             	cmp    $0x1,%cl
    6491:	75 1e                	jne    64b1 <fwp_rc_share+0x61>
    6493:	8b 48 18             	mov    0x18(%rax),%ecx
    6496:	0f b7 ff             	movzwl %di,%edi
    6499:	8b 40 1c             	mov    0x1c(%rax),%eax
    649c:	48 0f af f9          	imul   %rcx,%rdi
    64a0:	48 c1 ef 20          	shr    $0x20,%rdi
    64a4:	48 39 c7             	cmp    %rax,%rdi
    64a7:	73 08                	jae    64b1 <fwp_rc_share+0x61>
    64a9:	48 01 fa             	add    %rdi,%rdx
    64ac:	80 3a 00             	cmpb   $0x0,(%rdx)
    64af:	75 0d                	jne    64be <fwp_rc_share+0x6e>
    64b1:	c3                   	ret
    64b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64b8:	66 85 ff             	test   %di,%di
    64bb:	74 ef                	je     64ac <fwp_rc_share+0x5c>
    64bd:	c3                   	ret
    64be:	50                   	push   %rax
    64bf:	48 8d 3d 6a 94 00 00 	lea    0x946a(%rip),%rdi        # f930 <_IO_stdin_used+0x930>
    64c6:	e8 25 df ff ff       	call   43f0 <fwp_trap>
    64cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000064d0 <fwp_rc_fresh>:
    64d0:	48 8b 15 c1 e6 01 00 	mov    0x1e6c1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    64d7:	48 89 f8             	mov    %rdi,%rax
    64da:	48 89 fe             	mov    %rdi,%rsi
    64dd:	48 2b 05 8c e6 01 00 	sub    0x1e68c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    64e4:	48 c1 e2 10          	shl    $0x10,%rdx
    64e8:	48 39 d0             	cmp    %rdx,%rax
    64eb:	73 4f                	jae    653c <fwp_rc_fresh+0x6c>
    64ed:	48 89 c2             	mov    %rax,%rdx
    64f0:	48 c1 ea 10          	shr    $0x10,%rdx
    64f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    64f8:	48 8b 15 b9 e6 01 00 	mov    0x1e6b9(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    64ff:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6503:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6507:	48 85 d2             	test   %rdx,%rdx
    650a:	74 30                	je     653c <fwp_rc_fresh+0x6c>
    650c:	0f b6 39             	movzbl (%rcx),%edi
    650f:	40 80 ff 02          	cmp    $0x2,%dil
    6513:	74 2b                	je     6540 <fwp_rc_fresh+0x70>
    6515:	40 80 ff 01          	cmp    $0x1,%dil
    6519:	75 21                	jne    653c <fwp_rc_fresh+0x6c>
    651b:	8b 79 18             	mov    0x18(%rcx),%edi
    651e:	0f b7 c0             	movzwl %ax,%eax
    6521:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6524:	48 0f af c7          	imul   %rdi,%rax
    6528:	48 c1 e8 20          	shr    $0x20,%rax
    652c:	48 39 c8             	cmp    %rcx,%rax
    652f:	73 0b                	jae    653c <fwp_rc_fresh+0x6c>
    6531:	48 01 c2             	add    %rax,%rdx
    6534:	80 3a ff             	cmpb   $0xff,(%rdx)
    6537:	74 17                	je     6550 <fwp_rc_fresh+0x80>
    6539:	c6 02 01             	movb   $0x1,(%rdx)
    653c:	48 89 f0             	mov    %rsi,%rax
    653f:	c3                   	ret
    6540:	66 85 c0             	test   %ax,%ax
    6543:	74 ef                	je     6534 <fwp_rc_fresh+0x64>
    6545:	48 89 f0             	mov    %rsi,%rax
    6548:	c3                   	ret
    6549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6550:	48 83 ec 18          	sub    $0x18,%rsp
    6554:	48 89 d7             	mov    %rdx,%rdi
    6557:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    655c:	48 89 14 24          	mov    %rdx,(%rsp)
    6560:	e8 eb ef ff ff       	call   5550 <fwp_rc_forget_slot>
    6565:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    656a:	48 8b 14 24          	mov    (%rsp),%rdx
    656e:	48 89 f0             	mov    %rsi,%rax
    6571:	c6 02 01             	movb   $0x1,(%rdx)
    6574:	48 83 c4 18          	add    $0x18,%rsp
    6578:	c3                   	ret
    6579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006580 <fwp_rc_free_obj>:
    6580:	48 8b 15 11 e6 01 00 	mov    0x1e611(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6587:	48 89 f8             	mov    %rdi,%rax
    658a:	48 2b 05 df e5 01 00 	sub    0x1e5df(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6591:	48 c1 e2 10          	shl    $0x10,%rdx
    6595:	48 39 d0             	cmp    %rdx,%rax
    6598:	73 5b                	jae    65f5 <fwp_rc_free_obj+0x75>
    659a:	48 89 c2             	mov    %rax,%rdx
    659d:	48 c1 ea 10          	shr    $0x10,%rdx
    65a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    65a5:	48 8b 15 0c e6 01 00 	mov    0x1e60c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    65ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    65b0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    65b4:	48 85 c9             	test   %rcx,%rcx
    65b7:	74 3c                	je     65f5 <fwp_rc_free_obj+0x75>
    65b9:	0f b6 32             	movzbl (%rdx),%esi
    65bc:	40 80 fe 02          	cmp    $0x2,%sil
    65c0:	74 2e                	je     65f0 <fwp_rc_free_obj+0x70>
    65c2:	40 80 fe 01          	cmp    $0x1,%sil
    65c6:	75 2d                	jne    65f5 <fwp_rc_free_obj+0x75>
    65c8:	8b 72 18             	mov    0x18(%rdx),%esi
    65cb:	0f b7 c0             	movzwl %ax,%eax
    65ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65d1:	48 0f af c6          	imul   %rsi,%rax
    65d5:	48 c1 e8 20          	shr    $0x20,%rax
    65d9:	48 39 d0             	cmp    %rdx,%rax
    65dc:	73 17                	jae    65f5 <fwp_rc_free_obj+0x75>
    65de:	48 01 c1             	add    %rax,%rcx
    65e1:	80 39 01             	cmpb   $0x1,(%rcx)
    65e4:	75 0f                	jne    65f5 <fwp_rc_free_obj+0x75>
    65e6:	e9 a5 f1 ff ff       	jmp    5790 <fwp_mem_free>
    65eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    65f0:	66 85 c0             	test   %ax,%ax
    65f3:	74 ec                	je     65e1 <fwp_rc_free_obj+0x61>
    65f5:	c3                   	ret
    65f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65fd:	00 00 00 

0000000000006600 <fwp_rc_dup>:
    6600:	f3 0f 1e fa          	endbr64
    6604:	48 8b 05 8d e5 01 00 	mov    0x1e58d(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    660b:	48 2b 3d 5e e5 01 00 	sub    0x1e55e(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    6612:	48 c1 e0 10          	shl    $0x10,%rax
    6616:	48 39 c7             	cmp    %rax,%rdi
    6619:	73 56                	jae    6671 <fwp_rc_dup+0x71>
    661b:	48 89 f8             	mov    %rdi,%rax
    661e:	48 c1 e8 10          	shr    $0x10,%rax
    6622:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6626:	48 8b 05 8b e5 01 00 	mov    0x1e58b(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    662d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6631:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6635:	48 85 c0             	test   %rax,%rax
    6638:	74 37                	je     6671 <fwp_rc_dup+0x71>
    663a:	0f b6 0a             	movzbl (%rdx),%ecx
    663d:	80 f9 02             	cmp    $0x2,%cl
    6640:	74 36                	je     6678 <fwp_rc_dup+0x78>
    6642:	80 f9 01             	cmp    $0x1,%cl
    6645:	75 2a                	jne    6671 <fwp_rc_dup+0x71>
    6647:	8b 4a 18             	mov    0x18(%rdx),%ecx
    664a:	0f b7 ff             	movzwl %di,%edi
    664d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6650:	48 0f af f9          	imul   %rcx,%rdi
    6654:	48 c1 ef 20          	shr    $0x20,%rdi
    6658:	48 39 d7             	cmp    %rdx,%rdi
    665b:	73 14                	jae    6671 <fwp_rc_dup+0x71>
    665d:	48 01 f8             	add    %rdi,%rax
    6660:	0f b6 10             	movzbl (%rax),%edx
    6663:	84 d2                	test   %dl,%dl
    6665:	74 0a                	je     6671 <fwp_rc_dup+0x71>
    6667:	80 fa fd             	cmp    $0xfd,%dl
    666a:	77 14                	ja     6680 <fwp_rc_dup+0x80>
    666c:	83 c2 01             	add    $0x1,%edx
    666f:	88 10                	mov    %dl,(%rax)
    6671:	c3                   	ret
    6672:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6678:	66 85 ff             	test   %di,%di
    667b:	74 e3                	je     6660 <fwp_rc_dup+0x60>
    667d:	c3                   	ret
    667e:	66 90                	xchg   %ax,%ax
    6680:	48 89 c7             	mov    %rax,%rdi
    6683:	e9 a8 ed ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6688:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    668f:	00 

0000000000006690 <fwp_owned_entry173>:
    6690:	f3 0f 1e fa          	endbr64
    6694:	48 83 ec 38          	sub    $0x38,%rsp
    6698:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    669d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    66a4:	00 00 
    66a6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    66ab:	31 c0                	xor    %eax,%eax
    66ad:	48 8b 07             	mov    (%rdi),%rax
    66b0:	48 03 47 10          	add    0x10(%rdi),%rax
    66b4:	0f 80 c2 00 00 00    	jo     677c <fwp_owned_entry173+0xec>
    66ba:	66 48 0f 6e c8       	movq   %rax,%xmm1
    66bf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    66c4:	31 ff                	xor    %edi,%edi
    66c6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    66ca:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    66cf:	e8 dc f6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    66d4:	48 8b 15 bd e4 01 00 	mov    0x1e4bd(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    66db:	48 89 c6             	mov    %rax,%rsi
    66de:	48 2b 05 8b e4 01 00 	sub    0x1e48b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    66e5:	48 c1 e2 10          	shl    $0x10,%rdx
    66e9:	48 39 d0             	cmp    %rdx,%rax
    66ec:	73 4f                	jae    673d <fwp_owned_entry173+0xad>
    66ee:	48 89 c2             	mov    %rax,%rdx
    66f1:	48 c1 ea 10          	shr    $0x10,%rdx
    66f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66f9:	48 8b 15 b8 e4 01 00 	mov    0x1e4b8(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6700:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6704:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6708:	48 85 d2             	test   %rdx,%rdx
    670b:	74 30                	je     673d <fwp_owned_entry173+0xad>
    670d:	0f b6 39             	movzbl (%rcx),%edi
    6710:	40 80 ff 02          	cmp    $0x2,%dil
    6714:	74 42                	je     6758 <fwp_owned_entry173+0xc8>
    6716:	40 80 ff 01          	cmp    $0x1,%dil
    671a:	75 21                	jne    673d <fwp_owned_entry173+0xad>
    671c:	8b 79 18             	mov    0x18(%rcx),%edi
    671f:	0f b7 c0             	movzwl %ax,%eax
    6722:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6725:	48 0f af c7          	imul   %rdi,%rax
    6729:	48 c1 e8 20          	shr    $0x20,%rax
    672d:	48 39 c8             	cmp    %rcx,%rax
    6730:	73 0b                	jae    673d <fwp_owned_entry173+0xad>
    6732:	48 01 c2             	add    %rax,%rdx
    6735:	80 3a ff             	cmpb   $0xff,(%rdx)
    6738:	74 26                	je     6760 <fwp_owned_entry173+0xd0>
    673a:	c6 02 01             	movb   $0x1,(%rdx)
    673d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6742:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6749:	00 00 
    674b:	75 34                	jne    6781 <fwp_owned_entry173+0xf1>
    674d:	48 89 f0             	mov    %rsi,%rax
    6750:	48 83 c4 38          	add    $0x38,%rsp
    6754:	c3                   	ret
    6755:	0f 1f 00             	nopl   (%rax)
    6758:	66 85 c0             	test   %ax,%ax
    675b:	75 e0                	jne    673d <fwp_owned_entry173+0xad>
    675d:	eb d6                	jmp    6735 <fwp_owned_entry173+0xa5>
    675f:	90                   	nop
    6760:	48 89 d7             	mov    %rdx,%rdi
    6763:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6768:	48 89 14 24          	mov    %rdx,(%rsp)
    676c:	e8 df ed ff ff       	call   5550 <fwp_rc_forget_slot>
    6771:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6776:	48 8b 14 24          	mov    (%rsp),%rdx
    677a:	eb be                	jmp    673a <fwp_owned_entry173+0xaa>
    677c:	e8 7f cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6781:	e8 da cc ff ff       	call   3460 <__stack_chk_fail@plt>
    6786:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    678d:	00 00 00 

0000000000006790 <e173>:
    6790:	f3 0f 1e fa          	endbr64
    6794:	53                   	push   %rbx
    6795:	48 83 ec 30          	sub    $0x30,%rsp
    6799:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    679e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    67a5:	00 00 
    67a7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    67ac:	31 c0                	xor    %eax,%eax
    67ae:	48 8b 07             	mov    (%rdi),%rax
    67b1:	48 03 47 10          	add    0x10(%rdi),%rax
    67b5:	0f 80 c9 00 00 00    	jo     6884 <e173+0xf4>
    67bb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    67c0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    67c5:	31 ff                	xor    %edi,%edi
    67c7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    67cb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    67d0:	e8 db f5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    67d5:	48 8b 15 bc e3 01 00 	mov    0x1e3bc(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    67dc:	48 89 c3             	mov    %rax,%rbx
    67df:	48 2b 05 8a e3 01 00 	sub    0x1e38a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    67e6:	48 c1 e2 10          	shl    $0x10,%rdx
    67ea:	48 39 d0             	cmp    %rdx,%rax
    67ed:	73 4f                	jae    683e <e173+0xae>
    67ef:	48 89 c2             	mov    %rax,%rdx
    67f2:	48 c1 ea 10          	shr    $0x10,%rdx
    67f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67fa:	48 8b 15 b7 e3 01 00 	mov    0x1e3b7(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6801:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6805:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6809:	48 85 d2             	test   %rdx,%rdx
    680c:	74 30                	je     683e <e173+0xae>
    680e:	0f b6 31             	movzbl (%rcx),%esi
    6811:	40 80 fe 02          	cmp    $0x2,%sil
    6815:	74 49                	je     6860 <e173+0xd0>
    6817:	40 80 fe 01          	cmp    $0x1,%sil
    681b:	75 21                	jne    683e <e173+0xae>
    681d:	8b 71 18             	mov    0x18(%rcx),%esi
    6820:	0f b7 c0             	movzwl %ax,%eax
    6823:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6826:	48 0f af c6          	imul   %rsi,%rax
    682a:	48 c1 e8 20          	shr    $0x20,%rax
    682e:	48 39 c8             	cmp    %rcx,%rax
    6831:	73 0b                	jae    683e <e173+0xae>
    6833:	48 01 c2             	add    %rax,%rdx
    6836:	80 3a ff             	cmpb   $0xff,(%rdx)
    6839:	74 35                	je     6870 <e173+0xe0>
    683b:	c6 02 01             	movb   $0x1,(%rdx)
    683e:	48 89 df             	mov    %rbx,%rdi
    6841:	e8 0a fc ff ff       	call   6450 <fwp_rc_share>
    6846:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    684b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6852:	00 00 
    6854:	75 33                	jne    6889 <e173+0xf9>
    6856:	48 83 c4 30          	add    $0x30,%rsp
    685a:	48 89 d8             	mov    %rbx,%rax
    685d:	5b                   	pop    %rbx
    685e:	c3                   	ret
    685f:	90                   	nop
    6860:	66 85 c0             	test   %ax,%ax
    6863:	75 d9                	jne    683e <e173+0xae>
    6865:	eb cf                	jmp    6836 <e173+0xa6>
    6867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    686e:	00 00 
    6870:	48 89 d7             	mov    %rdx,%rdi
    6873:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6878:	e8 d3 ec ff ff       	call   5550 <fwp_rc_forget_slot>
    687d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6882:	eb b7                	jmp    683b <e173+0xab>
    6884:	e8 77 ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6889:	e8 d2 cb ff ff       	call   3460 <__stack_chk_fail@plt>
    688e:	66 90                	xchg   %ax,%ax

0000000000006890 <fwp_closure_drop>:
    6890:	48 8b 15 01 e3 01 00 	mov    0x1e301(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6897:	48 89 f8             	mov    %rdi,%rax
    689a:	48 2b 05 cf e2 01 00 	sub    0x1e2cf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    68a1:	48 c1 e2 10          	shl    $0x10,%rdx
    68a5:	48 39 d0             	cmp    %rdx,%rax
    68a8:	73 6b                	jae    6915 <fwp_closure_drop+0x85>
    68aa:	48 89 c2             	mov    %rax,%rdx
    68ad:	48 c1 ea 10          	shr    $0x10,%rdx
    68b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68b5:	48 8b 15 fc e2 01 00 	mov    0x1e2fc(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    68bc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    68c0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    68c4:	48 85 d2             	test   %rdx,%rdx
    68c7:	74 4c                	je     6915 <fwp_closure_drop+0x85>
    68c9:	0f b6 31             	movzbl (%rcx),%esi
    68cc:	40 80 fe 02          	cmp    $0x2,%sil
    68d0:	74 3e                	je     6910 <fwp_closure_drop+0x80>
    68d2:	40 80 fe 01          	cmp    $0x1,%sil
    68d6:	75 3d                	jne    6915 <fwp_closure_drop+0x85>
    68d8:	8b 71 18             	mov    0x18(%rcx),%esi
    68db:	0f b7 c0             	movzwl %ax,%eax
    68de:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68e1:	48 0f af c6          	imul   %rsi,%rax
    68e5:	48 c1 e8 20          	shr    $0x20,%rax
    68e9:	48 39 c8             	cmp    %rcx,%rax
    68ec:	73 27                	jae    6915 <fwp_closure_drop+0x85>
    68ee:	48 01 c2             	add    %rax,%rdx
    68f1:	0f b6 02             	movzbl (%rdx),%eax
    68f4:	84 c0                	test   %al,%al
    68f6:	74 1d                	je     6915 <fwp_closure_drop+0x85>
    68f8:	3c 01                	cmp    $0x1,%al
    68fa:	74 24                	je     6920 <fwp_closure_drop+0x90>
    68fc:	3c ff                	cmp    $0xff,%al
    68fe:	74 48                	je     6948 <fwp_closure_drop+0xb8>
    6900:	83 e8 01             	sub    $0x1,%eax
    6903:	88 02                	mov    %al,(%rdx)
    6905:	c3                   	ret
    6906:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    690d:	00 00 00 
    6910:	66 85 c0             	test   %ax,%ax
    6913:	74 dc                	je     68f1 <fwp_closure_drop+0x61>
    6915:	c3                   	ret
    6916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    691d:	00 00 00 
    6920:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6927:	ff ff 
    6929:	48 85 c0             	test   %rax,%rax
    692c:	74 12                	je     6940 <fwp_closure_drop+0xb0>
    692e:	48 89 fe             	mov    %rdi,%rsi
    6931:	48 89 c7             	mov    %rax,%rdi
    6934:	e9 17 db ff ff       	jmp    4450 <fwp_closure_drop_push>
    6939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6940:	e9 bb dc ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6945:	0f 1f 00             	nopl   (%rax)
    6948:	48 89 d0             	mov    %rdx,%rax
    694b:	48 8d 35 6e ce 01 00 	lea    0x1ce6e(%rip),%rsi        # 237c0 <fwp_heap>
    6952:	48 83 ec 18          	sub    $0x18,%rsp
    6956:	48 c1 e8 11          	shr    $0x11,%rax
    695a:	48 31 d0             	xor    %rdx,%rax
    695d:	48 89 c1             	mov    %rax,%rcx
    6960:	48 c1 e9 09          	shr    $0x9,%rcx
    6964:	48 31 c8             	xor    %rcx,%rax
    6967:	0f b6 c8             	movzbl %al,%ecx
    696a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6971:	00 
    6972:	48 85 c0             	test   %rax,%rax
    6975:	75 12                	jne    6989 <fwp_closure_drop+0xf9>
    6977:	eb 49                	jmp    69c2 <fwp_closure_drop+0x132>
    6979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6980:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6984:	48 85 c0             	test   %rax,%rax
    6987:	74 39                	je     69c2 <fwp_closure_drop+0x132>
    6989:	48 89 c1             	mov    %rax,%rcx
    698c:	48 39 10             	cmp    %rdx,(%rax)
    698f:	75 ef                	jne    6980 <fwp_closure_drop+0xf0>
    6991:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6995:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6999:	48 89 48 08          	mov    %rcx,0x8(%rax)
    699d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    69a4:	74 05                	je     69ab <fwp_closure_drop+0x11b>
    69a6:	48 83 c4 18          	add    $0x18,%rsp
    69aa:	c3                   	ret
    69ab:	48 89 d7             	mov    %rdx,%rdi
    69ae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    69b3:	e8 98 eb ff ff       	call   5550 <fwp_rc_forget_slot>
    69b8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    69bd:	c6 02 fe             	movb   $0xfe,(%rdx)
    69c0:	eb e4                	jmp    69a6 <fwp_closure_drop+0x116>
    69c2:	48 8d 3d c7 8e 00 00 	lea    0x8ec7(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    69c9:	e8 22 da ff ff       	call   43f0 <fwp_trap>
    69ce:	66 90                	xchg   %ax,%ax

00000000000069d0 <fwp_owned_tape_release>:
    69d0:	48 85 ff             	test   %rdi,%rdi
    69d3:	0f 84 f7 00 00 00    	je     6ad0 <fwp_owned_tape_release+0x100>
    69d9:	41 54                	push   %r12
    69db:	55                   	push   %rbp
    69dc:	53                   	push   %rbx
    69dd:	48 8b 07             	mov    (%rdi),%rax
    69e0:	48 85 c0             	test   %rax,%rax
    69e3:	74 08                	je     69ed <fwp_owned_tape_release+0x1d>
    69e5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    69e9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    69ed:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    69f1:	48 85 d2             	test   %rdx,%rdx
    69f4:	74 03                	je     69f9 <fwp_owned_tape_release+0x29>
    69f6:	48 89 02             	mov    %rax,(%rdx)
    69f9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    69fd:	48 89 fb             	mov    %rdi,%rbx
    6a00:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6a04:	48 85 c0             	test   %rax,%rax
    6a07:	0f 84 89 00 00 00    	je     6a96 <fwp_owned_tape_release+0xc6>
    6a0d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6a11:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6a15:	7e 47                	jle    6a5e <fwp_owned_tape_release+0x8e>
    6a17:	31 ed                	xor    %ebp,%ebp
    6a19:	eb 0d                	jmp    6a28 <fwp_owned_tape_release+0x58>
    6a1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a20:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a24:	48 8b 40 68          	mov    0x68(%rax),%rax
    6a28:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6a2c:	49 89 ec             	mov    %rbp,%r12
    6a2f:	48 83 c5 01          	add    $0x1,%rbp
    6a33:	49 c1 e4 04          	shl    $0x4,%r12
    6a37:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6a3b:	ff d0                	call   *%rax
    6a3d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6a41:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6a46:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a4a:	ff 50 68             	call   *0x68(%rax)
    6a4d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6a51:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6a55:	48 39 e8             	cmp    %rbp,%rax
    6a58:	7f c6                	jg     6a20 <fwp_owned_tape_release+0x50>
    6a5a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a5e:	31 ed                	xor    %ebp,%ebp
    6a60:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6a65:	7e 28                	jle    6a8f <fwp_owned_tape_release+0xbf>
    6a67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a6e:	00 00 
    6a70:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6a74:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6a78:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6a7c:	74 07                	je     6a85 <fwp_owned_tape_release+0xb5>
    6a7e:	ff 52 68             	call   *0x68(%rdx)
    6a81:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a85:	48 83 c5 01          	add    $0x1,%rbp
    6a89:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6a8d:	7f e1                	jg     6a70 <fwp_owned_tape_release+0xa0>
    6a8f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6a93:	ff 52 68             	call   *0x68(%rdx)
    6a96:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6a9a:	e8 f1 fd ff ff       	call   6890 <fwp_closure_drop>
    6a9f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6aa3:	e8 e8 fd ff ff       	call   6890 <fwp_closure_drop>
    6aa8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6aac:	e8 df fd ff ff       	call   6890 <fwp_closure_drop>
    6ab1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6ab5:	e8 d6 ec ff ff       	call   5790 <fwp_mem_free>
    6aba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6abe:	e8 cd ec ff ff       	call   5790 <fwp_mem_free>
    6ac3:	48 89 df             	mov    %rbx,%rdi
    6ac6:	5b                   	pop    %rbx
    6ac7:	5d                   	pop    %rbp
    6ac8:	41 5c                	pop    %r12
    6aca:	e9 c1 ec ff ff       	jmp    5790 <fwp_mem_free>
    6acf:	90                   	nop
    6ad0:	c3                   	ret
    6ad1:	0f 1f 40 00          	nopl   0x0(%rax)
    6ad5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6adc:	00 00 00 00 

0000000000006ae0 <fwp_tape_finish>:
    6ae0:	f3 0f 1e fa          	endbr64
    6ae4:	41 56                	push   %r14
    6ae6:	48 8d 3d b3 c5 01 00 	lea    0x1c5b3(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    6aed:	41 55                	push   %r13
    6aef:	41 54                	push   %r12
    6af1:	55                   	push   %rbp
    6af2:	53                   	push   %rbx
    6af3:	e8 18 d6 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6af8:	48 83 3d e8 c5 01 00 	cmpq   $0x0,0x1c5e8(%rip)        # 230e8 <fwp_ntapes>
    6aff:	00 
    6b00:	48 c7 05 7d c5 01 00 	movq   $0x0,0x1c57d(%rip)        # 23088 <fwp_tape_cached_bytes>
    6b07:	00 00 00 00 
    6b0b:	7e 68                	jle    6b75 <fwp_tape_finish+0x95>
    6b0d:	45 31 e4             	xor    %r12d,%r12d
    6b10:	31 ed                	xor    %ebp,%ebp
    6b12:	0f 1f 00             	nopl   (%rax)
    6b15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b1c:	00 00 00 00 
    6b20:	48 8b 1d c9 c5 01 00 	mov    0x1c5c9(%rip),%rbx        # 230f0 <fwp_tapes>
    6b27:	48 83 c5 01          	add    $0x1,%rbp
    6b2b:	4c 01 e3             	add    %r12,%rbx
    6b2e:	49 83 c4 68          	add    $0x68,%r12
    6b32:	48 89 df             	mov    %rbx,%rdi
    6b35:	e8 c6 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6b3a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6b3e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6b42:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6b46:	e8 75 c8 ff ff       	call   33c0 <free@plt>
    6b4b:	4c 89 f7             	mov    %r14,%rdi
    6b4e:	e8 6d c8 ff ff       	call   33c0 <free@plt>
    6b53:	4c 89 ef             	mov    %r13,%rdi
    6b56:	e8 65 c8 ff ff       	call   33c0 <free@plt>
    6b5b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6b5f:	e8 6c fe ff ff       	call   69d0 <fwp_owned_tape_release>
    6b64:	48 39 2d 7d c5 01 00 	cmp    %rbp,0x1c57d(%rip)        # 230e8 <fwp_ntapes>
    6b6b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6b72:	00 
    6b73:	7f ab                	jg     6b20 <fwp_tape_finish+0x40>
    6b75:	48 8b 3d 74 c5 01 00 	mov    0x1c574(%rip),%rdi        # 230f0 <fwp_tapes>
    6b7c:	e8 3f c8 ff ff       	call   33c0 <free@plt>
    6b81:	5b                   	pop    %rbx
    6b82:	5d                   	pop    %rbp
    6b83:	48 c7 05 62 c5 01 00 	movq   $0x0,0x1c562(%rip)        # 230f0 <fwp_tapes>
    6b8a:	00 00 00 00 
    6b8e:	48 c7 05 47 c5 01 00 	movq   $0x0,0x1c547(%rip)        # 230e0 <fwp_tapes_cap>
    6b95:	00 00 00 00 
    6b99:	41 5c                	pop    %r12
    6b9b:	48 c7 05 42 c5 01 00 	movq   $0x0,0x1c542(%rip)        # 230e8 <fwp_ntapes>
    6ba2:	00 00 00 00 
    6ba6:	41 5d                	pop    %r13
    6ba8:	48 c7 05 25 c5 01 00 	movq   $0x0,0x1c525(%rip)        # 230d8 <fwp_tape_next_slot>
    6baf:	00 00 00 00 
    6bb3:	41 5e                	pop    %r14
    6bb5:	c3                   	ret
    6bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bbd:	00 00 00 

0000000000006bc0 <fwp_tape_scope_release>:
    6bc0:	f3 0f 1e fa          	endbr64
    6bc4:	41 55                	push   %r13
    6bc6:	41 54                	push   %r12
    6bc8:	55                   	push   %rbp
    6bc9:	53                   	push   %rbx
    6bca:	48 83 ec 58          	sub    $0x58,%rsp
    6bce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bd5:	00 00 
    6bd7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6bdc:	48 63 07             	movslq (%rdi),%rax
    6bdf:	85 c0                	test   %eax,%eax
    6be1:	0f 88 05 01 00 00    	js     6cec <fwp_tape_scope_release+0x12c>
    6be7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6bee:	ec c4 4e 
    6bf1:	48 89 fb             	mov    %rdi,%rbx
    6bf4:	eb 3c                	jmp    6c32 <fwp_tape_scope_release+0x72>
    6bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bfd:	00 00 00 
    6c00:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6c05:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6c09:	e8 b2 c7 ff ff       	call   33c0 <free@plt>
    6c0e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6c12:	e8 a9 c7 ff ff       	call   33c0 <free@plt>
    6c17:	4c 89 ef             	mov    %r13,%rdi
    6c1a:	e8 a1 c7 ff ff       	call   33c0 <free@plt>
    6c1f:	4c 89 e7             	mov    %r12,%rdi
    6c22:	e8 a9 fd ff ff       	call   69d0 <fwp_owned_tape_release>
    6c27:	48 63 03             	movslq (%rbx),%rax
    6c2a:	85 c0                	test   %eax,%eax
    6c2c:	0f 88 ba 00 00 00    	js     6cec <fwp_tape_scope_release+0x12c>
    6c32:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6c36:	48 8b 35 b3 c4 01 00 	mov    0x1c4b3(%rip),%rsi        # 230f0 <fwp_tapes>
    6c3d:	4c 01 c6             	add    %r8,%rsi
    6c40:	48 89 f7             	mov    %rsi,%rdi
    6c43:	e8 b8 cf ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6c48:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6c4d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6c52:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6c59:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6c5d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6c61:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6c68:	00 
    6c69:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6c6e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6c72:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6c77:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6c7b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6c80:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6c87:	00 
    6c88:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6c8f:	00 
    6c90:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6c97:	00 
    6c98:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6c9d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6ca2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6ca6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6caa:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6cae:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6cb4:	77 18                	ja     6cce <fwp_tape_scope_release+0x10e>
    6cb6:	49 c1 f8 03          	sar    $0x3,%r8
    6cba:	4c 0f af c5          	imul   %rbp,%r8
    6cbe:	4c 3b 05 13 c4 01 00 	cmp    0x1c413(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    6cc5:	7d 07                	jge    6cce <fwp_tape_scope_release+0x10e>
    6cc7:	4c 89 05 0a c4 01 00 	mov    %r8,0x1c40a(%rip)        # 230d8 <fwp_tape_next_slot>
    6cce:	4d 85 e4             	test   %r12,%r12
    6cd1:	0f 85 29 ff ff ff    	jne    6c00 <fwp_tape_scope_release+0x40>
    6cd7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6cdc:	e8 8f e3 ff ff       	call   5070 <fwp_tape_buffers_release>
    6ce1:	48 63 03             	movslq (%rbx),%rax
    6ce4:	85 c0                	test   %eax,%eax
    6ce6:	0f 89 46 ff ff ff    	jns    6c32 <fwp_tape_scope_release+0x72>
    6cec:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6cf1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6cf8:	00 00 
    6cfa:	75 0b                	jne    6d07 <fwp_tape_scope_release+0x147>
    6cfc:	48 83 c4 58          	add    $0x58,%rsp
    6d00:	5b                   	pop    %rbx
    6d01:	5d                   	pop    %rbp
    6d02:	41 5c                	pop    %r12
    6d04:	41 5d                	pop    %r13
    6d06:	c3                   	ret
    6d07:	e8 54 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6d0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006d10 <fwp_drop4>:
    6d10:	48 8b 0d 81 de 01 00 	mov    0x1de81(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    6d17:	48 89 f8             	mov    %rdi,%rax
    6d1a:	48 2b 05 4f de 01 00 	sub    0x1de4f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6d21:	48 c1 e1 10          	shl    $0x10,%rcx
    6d25:	48 39 c8             	cmp    %rcx,%rax
    6d28:	0f 83 42 01 00 00    	jae    6e70 <fwp_drop4+0x160>
    6d2e:	48 83 ec 18          	sub    $0x18,%rsp
    6d32:	48 89 fa             	mov    %rdi,%rdx
    6d35:	4c 8d 05 84 ca 01 00 	lea    0x1ca84(%rip),%r8        # 237c0 <fwp_heap>
    6d3c:	48 89 c1             	mov    %rax,%rcx
    6d3f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6d46:	48 c1 e9 10          	shr    $0x10,%rcx
    6d4a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6d4e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6d52:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6d56:	48 85 c9             	test   %rcx,%rcx
    6d59:	74 40                	je     6d9b <fwp_drop4+0x8b>
    6d5b:	0f b6 3e             	movzbl (%rsi),%edi
    6d5e:	40 80 ff 02          	cmp    $0x2,%dil
    6d62:	74 3c                	je     6da0 <fwp_drop4+0x90>
    6d64:	40 80 ff 01          	cmp    $0x1,%dil
    6d68:	75 31                	jne    6d9b <fwp_drop4+0x8b>
    6d6a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6d6d:	0f b7 c0             	movzwl %ax,%eax
    6d70:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6d73:	48 0f af c7          	imul   %rdi,%rax
    6d77:	48 c1 e8 20          	shr    $0x20,%rax
    6d7b:	48 39 f0             	cmp    %rsi,%rax
    6d7e:	73 1b                	jae    6d9b <fwp_drop4+0x8b>
    6d80:	48 01 c1             	add    %rax,%rcx
    6d83:	0f b6 01             	movzbl (%rcx),%eax
    6d86:	84 c0                	test   %al,%al
    6d88:	74 11                	je     6d9b <fwp_drop4+0x8b>
    6d8a:	3c 01                	cmp    $0x1,%al
    6d8c:	74 22                	je     6db0 <fwp_drop4+0xa0>
    6d8e:	3c ff                	cmp    $0xff,%al
    6d90:	0f 84 0a 01 00 00    	je     6ea0 <fwp_drop4+0x190>
    6d96:	83 e8 01             	sub    $0x1,%eax
    6d99:	88 01                	mov    %al,(%rcx)
    6d9b:	48 83 c4 18          	add    $0x18,%rsp
    6d9f:	c3                   	ret
    6da0:	66 85 c0             	test   %ax,%ax
    6da3:	74 de                	je     6d83 <fwp_drop4+0x73>
    6da5:	48 83 c4 18          	add    $0x18,%rsp
    6da9:	c3                   	ret
    6daa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6db0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6db4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6dbb:	48 89 f8             	mov    %rdi,%rax
    6dbe:	48 c1 e1 10          	shl    $0x10,%rcx
    6dc2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6dc9:	48 39 c8             	cmp    %rcx,%rax
    6dcc:	73 62                	jae    6e30 <fwp_drop4+0x120>
    6dce:	48 89 c1             	mov    %rax,%rcx
    6dd1:	48 c1 e9 10          	shr    $0x10,%rcx
    6dd5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6dd9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6ddd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6de1:	48 85 c9             	test   %rcx,%rcx
    6de4:	74 4a                	je     6e30 <fwp_drop4+0x120>
    6de6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6dea:	41 80 f9 02          	cmp    $0x2,%r9b
    6dee:	0f 84 9c 00 00 00    	je     6e90 <fwp_drop4+0x180>
    6df4:	41 80 f9 01          	cmp    $0x1,%r9b
    6df8:	75 36                	jne    6e30 <fwp_drop4+0x120>
    6dfa:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6dfe:	0f b7 c0             	movzwl %ax,%eax
    6e01:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6e04:	49 0f af c1          	imul   %r9,%rax
    6e08:	48 c1 e8 20          	shr    $0x20,%rax
    6e0c:	48 39 f0             	cmp    %rsi,%rax
    6e0f:	73 1f                	jae    6e30 <fwp_drop4+0x120>
    6e11:	48 01 c1             	add    %rax,%rcx
    6e14:	0f b6 01             	movzbl (%rcx),%eax
    6e17:	84 c0                	test   %al,%al
    6e19:	74 15                	je     6e30 <fwp_drop4+0x120>
    6e1b:	3c 01                	cmp    $0x1,%al
    6e1d:	74 59                	je     6e78 <fwp_drop4+0x168>
    6e1f:	3c ff                	cmp    $0xff,%al
    6e21:	0f 84 ff 00 00 00    	je     6f26 <fwp_drop4+0x216>
    6e27:	83 e8 01             	sub    $0x1,%eax
    6e2a:	88 01                	mov    %al,(%rcx)
    6e2c:	0f 1f 40 00          	nopl   0x0(%rax)
    6e30:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6e34:	48 89 d7             	mov    %rdx,%rdi
    6e37:	48 89 0c 24          	mov    %rcx,(%rsp)
    6e3b:	e8 40 f7 ff ff       	call   6580 <fwp_rc_free_obj>
    6e40:	4c 8d 05 79 c9 01 00 	lea    0x1c979(%rip),%r8        # 237c0 <fwp_heap>
    6e47:	48 8b 04 24          	mov    (%rsp),%rax
    6e4b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6e52:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6e59:	48 c1 e2 10          	shl    $0x10,%rdx
    6e5d:	48 39 d0             	cmp    %rdx,%rax
    6e60:	0f 83 35 ff ff ff    	jae    6d9b <fwp_drop4+0x8b>
    6e66:	48 8b 14 24          	mov    (%rsp),%rdx
    6e6a:	e9 cd fe ff ff       	jmp    6d3c <fwp_drop4+0x2c>
    6e6f:	90                   	nop
    6e70:	c3                   	ret
    6e71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e78:	48 89 14 24          	mov    %rdx,(%rsp)
    6e7c:	e8 ff f6 ff ff       	call   6580 <fwp_rc_free_obj>
    6e81:	48 8b 14 24          	mov    (%rsp),%rdx
    6e85:	eb a9                	jmp    6e30 <fwp_drop4+0x120>
    6e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e8e:	00 00 
    6e90:	66 85 c0             	test   %ax,%ax
    6e93:	75 9b                	jne    6e30 <fwp_drop4+0x120>
    6e95:	e9 7a ff ff ff       	jmp    6e14 <fwp_drop4+0x104>
    6e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ea0:	48 89 c8             	mov    %rcx,%rax
    6ea3:	48 c1 e8 11          	shr    $0x11,%rax
    6ea7:	48 31 c8             	xor    %rcx,%rax
    6eaa:	48 89 c2             	mov    %rax,%rdx
    6ead:	48 c1 ea 09          	shr    $0x9,%rdx
    6eb1:	48 31 d0             	xor    %rdx,%rax
    6eb4:	0f b6 d0             	movzbl %al,%edx
    6eb7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6ebe:	00 
    6ebf:	48 85 c0             	test   %rax,%rax
    6ec2:	75 29                	jne    6eed <fwp_drop4+0x1dd>
    6ec4:	e9 e3 00 00 00       	jmp    6fac <fwp_drop4+0x29c>
    6ec9:	90                   	nop
    6eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ed1:	00 00 00 00 
    6ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6edc:	00 00 00 00 
    6ee0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6ee4:	48 85 c0             	test   %rax,%rax
    6ee7:	0f 84 bf 00 00 00    	je     6fac <fwp_drop4+0x29c>
    6eed:	48 89 c2             	mov    %rax,%rdx
    6ef0:	48 39 08             	cmp    %rcx,(%rax)
    6ef3:	75 eb                	jne    6ee0 <fwp_drop4+0x1d0>
    6ef5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6ef9:	48 83 ea 01          	sub    $0x1,%rdx
    6efd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6f01:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6f08:	0f 85 8d fe ff ff    	jne    6d9b <fwp_drop4+0x8b>
    6f0e:	48 89 cf             	mov    %rcx,%rdi
    6f11:	48 89 0c 24          	mov    %rcx,(%rsp)
    6f15:	e8 36 e6 ff ff       	call   5550 <fwp_rc_forget_slot>
    6f1a:	48 8b 0c 24          	mov    (%rsp),%rcx
    6f1e:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f21:	e9 75 fe ff ff       	jmp    6d9b <fwp_drop4+0x8b>
    6f26:	48 89 ce             	mov    %rcx,%rsi
    6f29:	48 c1 ee 11          	shr    $0x11,%rsi
    6f2d:	48 31 ce             	xor    %rcx,%rsi
    6f30:	48 89 f0             	mov    %rsi,%rax
    6f33:	48 c1 e8 09          	shr    $0x9,%rax
    6f37:	48 31 c6             	xor    %rax,%rsi
    6f3a:	40 0f b6 f6          	movzbl %sil,%esi
    6f3e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6f45:	00 
    6f46:	48 85 c0             	test   %rax,%rax
    6f49:	75 1e                	jne    6f69 <fwp_drop4+0x259>
    6f4b:	eb 5f                	jmp    6fac <fwp_drop4+0x29c>
    6f4d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f54:	00 
    6f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f5c:	00 00 00 00 
    6f60:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6f64:	48 85 c0             	test   %rax,%rax
    6f67:	74 43                	je     6fac <fwp_drop4+0x29c>
    6f69:	48 89 c6             	mov    %rax,%rsi
    6f6c:	48 39 08             	cmp    %rcx,(%rax)
    6f6f:	75 ef                	jne    6f60 <fwp_drop4+0x250>
    6f71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f75:	48 83 ee 01          	sub    $0x1,%rsi
    6f79:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6f7d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6f84:	0f 85 a6 fe ff ff    	jne    6e30 <fwp_drop4+0x120>
    6f8a:	48 89 cf             	mov    %rcx,%rdi
    6f8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f92:	48 89 0c 24          	mov    %rcx,(%rsp)
    6f96:	e8 b5 e5 ff ff       	call   5550 <fwp_rc_forget_slot>
    6f9b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6f9f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6fa4:	c6 01 fe             	movb   $0xfe,(%rcx)
    6fa7:	e9 84 fe ff ff       	jmp    6e30 <fwp_drop4+0x120>
    6fac:	48 8d 3d dd 88 00 00 	lea    0x88dd(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    6fb3:	e8 38 d4 ff ff       	call   43f0 <fwp_trap>
    6fb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6fbf:	00 

0000000000006fc0 <fwp_arg_drop37>:
    6fc0:	f3 0f 1e fa          	endbr64
    6fc4:	85 f6                	test   %esi,%esi
    6fc6:	75 04                	jne    6fcc <fwp_arg_drop37+0xc>
    6fc8:	85 d2                	test   %edx,%edx
    6fca:	75 04                	jne    6fd0 <fwp_arg_drop37+0x10>
    6fcc:	c3                   	ret
    6fcd:	0f 1f 00             	nopl   (%rax)
    6fd0:	48 8b 3f             	mov    (%rdi),%rdi
    6fd3:	e9 38 fd ff ff       	jmp    6d10 <fwp_drop4>
    6fd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6fdf:	00 

0000000000006fe0 <fwp_task_dispose>:
    6fe0:	53                   	push   %rbx
    6fe1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6fe5:	0f 84 5b c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    6feb:	48 89 fb             	mov    %rdi,%rbx
    6fee:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6ff3:	0f 85 4d c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6ff9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6ffd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7004:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    700b:	00 
    700c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7010:	48 85 ff             	test   %rdi,%rdi
    7013:	74 07                	je     701c <fwp_task_dispose+0x3c>
    7015:	48 85 c0             	test   %rax,%rax
    7018:	74 02                	je     701c <fwp_task_dispose+0x3c>
    701a:	ff d0                	call   *%rax
    701c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7023:	e8 68 e7 ff ff       	call   5790 <fwp_mem_free>
    7028:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    702f:	00 00 00 00 
    7033:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7037:	74 6f                	je     70a8 <fwp_task_dispose+0xc8>
    7039:	48 8b 15 58 db 01 00 	mov    0x1db58(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7040:	48 89 d8             	mov    %rbx,%rax
    7043:	48 2b 05 26 db 01 00 	sub    0x1db26(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    704a:	48 c1 e2 10          	shl    $0x10,%rdx
    704e:	48 39 d0             	cmp    %rdx,%rax
    7051:	73 4c                	jae    709f <fwp_task_dispose+0xbf>
    7053:	48 89 c2             	mov    %rax,%rdx
    7056:	48 c1 ea 10          	shr    $0x10,%rdx
    705a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    705e:	48 8b 15 53 db 01 00 	mov    0x1db53(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7065:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7069:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    706d:	48 85 c9             	test   %rcx,%rcx
    7070:	74 2d                	je     709f <fwp_task_dispose+0xbf>
    7072:	0f b6 32             	movzbl (%rdx),%esi
    7075:	40 80 fe 02          	cmp    $0x2,%sil
    7079:	74 3d                	je     70b8 <fwp_task_dispose+0xd8>
    707b:	40 80 fe 01          	cmp    $0x1,%sil
    707f:	75 1e                	jne    709f <fwp_task_dispose+0xbf>
    7081:	8b 72 18             	mov    0x18(%rdx),%esi
    7084:	0f b7 c0             	movzwl %ax,%eax
    7087:	8b 52 1c             	mov    0x1c(%rdx),%edx
    708a:	48 0f af c6          	imul   %rsi,%rax
    708e:	48 c1 e8 20          	shr    $0x20,%rax
    7092:	48 39 d0             	cmp    %rdx,%rax
    7095:	73 08                	jae    709f <fwp_task_dispose+0xbf>
    7097:	48 01 c1             	add    %rax,%rcx
    709a:	80 39 01             	cmpb   $0x1,(%rcx)
    709d:	74 09                	je     70a8 <fwp_task_dispose+0xc8>
    709f:	5b                   	pop    %rbx
    70a0:	c3                   	ret
    70a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70a8:	48 89 df             	mov    %rbx,%rdi
    70ab:	5b                   	pop    %rbx
    70ac:	e9 df e6 ff ff       	jmp    5790 <fwp_mem_free>
    70b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70b8:	66 85 c0             	test   %ax,%ax
    70bb:	74 dd                	je     709a <fwp_task_dispose+0xba>
    70bd:	5b                   	pop    %rbx
    70be:	c3                   	ret
    70bf:	90                   	nop

00000000000070c0 <fwp_free_zombie>:
    70c0:	48 8b 15 c9 c6 01 00 	mov    0x1c6c9(%rip),%rdx        # 23790 <fwp_zombie>
    70c7:	48 85 d2             	test   %rdx,%rdx
    70ca:	0f 84 98 00 00 00    	je     7168 <fwp_free_zombie+0xa8>
    70d0:	48 3b 15 c9 c6 01 00 	cmp    0x1c6c9(%rip),%rdx        # 237a0 <fwp_cur>
    70d7:	0f 84 8b 00 00 00    	je     7168 <fwp_free_zombie+0xa8>
    70dd:	48 83 ec 18          	sub    $0x18,%rsp
    70e1:	48 63 05 7c c0 01 00 	movslq 0x1c07c(%rip),%rax        # 23164 <fwp_stack_pool_n>
    70e8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    70ec:	83 f8 3f             	cmp    $0x3f,%eax
    70ef:	7f 7f                	jg     7170 <fwp_free_zombie+0xb0>
    70f1:	8d 48 01             	lea    0x1(%rax),%ecx
    70f4:	89 0d 6a c0 01 00    	mov    %ecx,0x1c06a(%rip)        # 23164 <fwp_stack_pool_n>
    70fa:	48 8d 0d 7f c0 01 00 	lea    0x1c07f(%rip),%rcx        # 23180 <fwp_stack_pool>
    7101:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7105:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    710c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7110:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7117:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    711b:	48 85 c9             	test   %rcx,%rcx
    711e:	0f 84 fc 00 00 00    	je     7220 <fwp_free_zombie+0x160>
    7124:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    712b:	48 85 c0             	test   %rax,%rax
    712e:	74 07                	je     7137 <fwp_free_zombie+0x77>
    7130:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7137:	8b 42 5c             	mov    0x5c(%rdx),%eax
    713a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    713e:	48 c7 05 47 c6 01 00 	movq   $0x0,0x1c647(%rip)        # 23790 <fwp_zombie>
    7145:	00 00 00 00 
    7149:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7150:	85 c0                	test   %eax,%eax
    7152:	74 34                	je     7188 <fwp_free_zombie+0xc8>
    7154:	83 f8 01             	cmp    $0x1,%eax
    7157:	0f 84 b3 00 00 00    	je     7210 <fwp_free_zombie+0x150>
    715d:	48 83 c4 18          	add    $0x18,%rsp
    7161:	c3                   	ret
    7162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7168:	c3                   	ret
    7169:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7170:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7174:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7179:	e8 62 c4 ff ff       	call   35e0 <munmap@plt>
    717e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7183:	eb 80                	jmp    7105 <fwp_free_zombie+0x45>
    7185:	0f 1f 00             	nopl   (%rax)
    7188:	48 8b 0d 09 da 01 00 	mov    0x1da09(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    718f:	48 89 d0             	mov    %rdx,%rax
    7192:	48 2b 05 d7 d9 01 00 	sub    0x1d9d7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7199:	48 c1 e1 10          	shl    $0x10,%rcx
    719d:	48 39 c8             	cmp    %rcx,%rax
    71a0:	73 bb                	jae    715d <fwp_free_zombie+0x9d>
    71a2:	48 89 c1             	mov    %rax,%rcx
    71a5:	48 c1 e9 10          	shr    $0x10,%rcx
    71a9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    71ad:	48 8b 0d 04 da 01 00 	mov    0x1da04(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    71b4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    71b8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    71bc:	48 85 c9             	test   %rcx,%rcx
    71bf:	74 9c                	je     715d <fwp_free_zombie+0x9d>
    71c1:	0f b6 3e             	movzbl (%rsi),%edi
    71c4:	40 80 ff 02          	cmp    $0x2,%dil
    71c8:	74 66                	je     7230 <fwp_free_zombie+0x170>
    71ca:	40 80 ff 01          	cmp    $0x1,%dil
    71ce:	75 8d                	jne    715d <fwp_free_zombie+0x9d>
    71d0:	8b 7e 18             	mov    0x18(%rsi),%edi
    71d3:	0f b7 c0             	movzwl %ax,%eax
    71d6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71d9:	48 0f af c7          	imul   %rdi,%rax
    71dd:	48 c1 e8 20          	shr    $0x20,%rax
    71e1:	48 39 f0             	cmp    %rsi,%rax
    71e4:	0f 83 73 ff ff ff    	jae    715d <fwp_free_zombie+0x9d>
    71ea:	48 01 c1             	add    %rax,%rcx
    71ed:	0f b6 01             	movzbl (%rcx),%eax
    71f0:	84 c0                	test   %al,%al
    71f2:	0f 84 65 ff ff ff    	je     715d <fwp_free_zombie+0x9d>
    71f8:	3c 01                	cmp    $0x1,%al
    71fa:	74 14                	je     7210 <fwp_free_zombie+0x150>
    71fc:	3c ff                	cmp    $0xff,%al
    71fe:	74 3b                	je     723b <fwp_free_zombie+0x17b>
    7200:	83 e8 01             	sub    $0x1,%eax
    7203:	88 01                	mov    %al,(%rcx)
    7205:	e9 53 ff ff ff       	jmp    715d <fwp_free_zombie+0x9d>
    720a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7210:	48 89 d7             	mov    %rdx,%rdi
    7213:	48 83 c4 18          	add    $0x18,%rsp
    7217:	e9 c4 fd ff ff       	jmp    6fe0 <fwp_task_dispose>
    721c:	0f 1f 40 00          	nopl   0x0(%rax)
    7220:	48 89 05 41 c5 01 00 	mov    %rax,0x1c541(%rip)        # 23768 <fwp_tasks_active>
    7227:	e9 ff fe ff ff       	jmp    712b <fwp_free_zombie+0x6b>
    722c:	0f 1f 40 00          	nopl   0x0(%rax)
    7230:	66 85 c0             	test   %ax,%ax
    7233:	0f 85 24 ff ff ff    	jne    715d <fwp_free_zombie+0x9d>
    7239:	eb b2                	jmp    71ed <fwp_free_zombie+0x12d>
    723b:	48 89 ca             	mov    %rcx,%rdx
    723e:	48 8d 35 7b c5 01 00 	lea    0x1c57b(%rip),%rsi        # 237c0 <fwp_heap>
    7245:	48 c1 ea 11          	shr    $0x11,%rdx
    7249:	48 31 ca             	xor    %rcx,%rdx
    724c:	48 89 d0             	mov    %rdx,%rax
    724f:	48 c1 e8 09          	shr    $0x9,%rax
    7253:	48 31 c2             	xor    %rax,%rdx
    7256:	0f b6 d2             	movzbl %dl,%edx
    7259:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7260:	00 
    7261:	48 85 c0             	test   %rax,%rax
    7264:	75 23                	jne    7289 <fwp_free_zombie+0x1c9>
    7266:	eb 5c                	jmp    72c4 <fwp_free_zombie+0x204>
    7268:	66 90                	xchg   %ax,%ax
    726a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7271:	00 00 00 00 
    7275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    727c:	00 00 00 00 
    7280:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7284:	48 85 c0             	test   %rax,%rax
    7287:	74 3b                	je     72c4 <fwp_free_zombie+0x204>
    7289:	48 89 c2             	mov    %rax,%rdx
    728c:	48 39 08             	cmp    %rcx,(%rax)
    728f:	75 ef                	jne    7280 <fwp_free_zombie+0x1c0>
    7291:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7295:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7299:	48 89 50 08          	mov    %rdx,0x8(%rax)
    729d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    72a4:	0f 85 b3 fe ff ff    	jne    715d <fwp_free_zombie+0x9d>
    72aa:	48 89 cf             	mov    %rcx,%rdi
    72ad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    72b2:	e8 99 e2 ff ff       	call   5550 <fwp_rc_forget_slot>
    72b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    72bc:	c6 01 fe             	movb   $0xfe,(%rcx)
    72bf:	e9 99 fe ff ff       	jmp    715d <fwp_free_zombie+0x9d>
    72c4:	48 8d 3d c5 85 00 00 	lea    0x85c5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    72cb:	e8 20 d1 ff ff       	call   43f0 <fwp_trap>

00000000000072d0 <fwp_block>:
    72d0:	48 83 ec 08          	sub    $0x8,%rsp
    72d4:	48 8b 05 ad c4 01 00 	mov    0x1c4ad(%rip),%rax        # 23788 <fwp_ready_head>
    72db:	48 85 c0             	test   %rax,%rax
    72de:	0f 84 1c 01 00 00    	je     7400 <fwp_block+0x130>
    72e4:	90                   	nop
    72e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72ec:	00 00 00 00 
    72f0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    72f7:	48 89 15 8a c4 01 00 	mov    %rdx,0x1c48a(%rip)        # 23788 <fwp_ready_head>
    72fe:	48 85 d2             	test   %rdx,%rdx
    7301:	0f 84 19 01 00 00    	je     7420 <fwp_block+0x150>
    7307:	48 8b 15 92 c4 01 00 	mov    0x1c492(%rip),%rdx        # 237a0 <fwp_cur>
    730e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7312:	48 39 c2             	cmp    %rax,%rdx
    7315:	0f 84 d5 00 00 00    	je     73f0 <fwp_block+0x120>
    731b:	48 8b 0d 06 e1 01 00 	mov    0x1e106(%rip),%rcx        # 25428 <fwp_state_owners>
    7322:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7326:	48 89 05 73 c4 01 00 	mov    %rax,0x1c473(%rip)        # 237a0 <fwp_cur>
    732d:	f3 0f 7e 05 1b e1 01 	movq   0x1e11b(%rip),%xmm0        # 25450 <fwp_foreign_callbacks>
    7334:	00 
    7335:	0f 16 05 04 e1 01 00 	movhps 0x1e104(%rip),%xmm0        # 25440 <fwp_state>
    733c:	f3 0f 7e 0d 04 e1 01 	movq   0x1e104(%rip),%xmm1        # 25448 <fwp_handlers>
    7343:	00 
    7344:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    734b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7352:	0f 16 0d ff e0 01 00 	movhps 0x1e0ff(%rip),%xmm1        # 25458 <fwp_cleanups>
    7359:	f3 0f 7e 05 d7 e0 01 	movq   0x1e0d7(%rip),%xmm0        # 25438 <fwp_state_len>
    7360:	00 
    7361:	0f 16 05 c8 e0 01 00 	movhps 0x1e0c8(%rip),%xmm0        # 25430 <fwp_state_cap>
    7368:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    736f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7376:	48 8b 70 08          	mov    0x8(%rax),%rsi
    737a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7381:	48 89 0d c0 e0 01 00 	mov    %rcx,0x1e0c0(%rip)        # 25448 <fwp_handlers>
    7388:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    738f:	48 89 0d c2 e0 01 00 	mov    %rcx,0x1e0c2(%rip)        # 25458 <fwp_cleanups>
    7396:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    739d:	48 89 0d ac e0 01 00 	mov    %rcx,0x1e0ac(%rip)        # 25450 <fwp_foreign_callbacks>
    73a4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    73ab:	48 89 0d 8e e0 01 00 	mov    %rcx,0x1e08e(%rip)        # 25440 <fwp_state>
    73b2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    73b9:	48 89 0d 78 e0 01 00 	mov    %rcx,0x1e078(%rip)        # 25438 <fwp_state_len>
    73c0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    73c7:	48 89 0d 62 e0 01 00 	mov    %rcx,0x1e062(%rip)        # 25430 <fwp_state_cap>
    73ce:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    73d5:	48 89 0d 4c e0 01 00 	mov    %rcx,0x1e04c(%rip)        # 25428 <fwp_state_owners>
    73dc:	e8 af c0 ff ff       	call   3490 <swapcontext@plt>
    73e1:	f3 0f 1e fa          	endbr64
    73e5:	e8 d6 fc ff ff       	call   70c0 <fwp_free_zombie>
    73ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73f0:	8b 05 6a bd 01 00    	mov    0x1bd6a(%rip),%eax        # 23160 <fwp_slice>
    73f6:	85 c0                	test   %eax,%eax
    73f8:	74 36                	je     7430 <fwp_block+0x160>
    73fa:	48 83 c4 08          	add    $0x8,%rsp
    73fe:	c3                   	ret
    73ff:	90                   	nop
    7400:	e8 9b dd ff ff       	call   51a0 <fwp_poll_events>
    7405:	48 8b 05 7c c3 01 00 	mov    0x1c37c(%rip),%rax        # 23788 <fwp_ready_head>
    740c:	48 85 c0             	test   %rax,%rax
    740f:	0f 85 db fe ff ff    	jne    72f0 <fwp_block+0x20>
    7415:	eb e9                	jmp    7400 <fwp_block+0x130>
    7417:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    741e:	00 00 
    7420:	48 c7 05 55 c3 01 00 	movq   $0x0,0x1c355(%rip)        # 23780 <fwp_ready_tail>
    7427:	00 00 00 00 
    742b:	e9 d7 fe ff ff       	jmp    7307 <fwp_block+0x37>
    7430:	48 8d 3d 4d 7d 00 00 	lea    0x7d4d(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    7437:	e8 64 bf ff ff       	call   33a0 <getenv@plt>
    743c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7441:	48 85 c0             	test   %rax,%rax
    7444:	74 05                	je     744b <fwp_block+0x17b>
    7446:	80 38 00             	cmpb   $0x0,(%rax)
    7449:	75 0b                	jne    7456 <fwp_block+0x186>
    744b:	89 15 0f bd 01 00    	mov    %edx,0x1bd0f(%rip)        # 23160 <fwp_slice>
    7451:	48 83 c4 08          	add    $0x8,%rsp
    7455:	c3                   	ret
    7456:	ba 0a 00 00 00       	mov    $0xa,%edx
    745b:	31 f6                	xor    %esi,%esi
    745d:	48 89 c7             	mov    %rax,%rdi
    7460:	e8 eb c0 ff ff       	call   3550 <strtoll@plt>
    7465:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7469:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7470:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7475:	0f 46 d0             	cmovbe %eax,%edx
    7478:	eb d1                	jmp    744b <fwp_block+0x17b>
    747a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007480 <fwp_caps173>:
    7480:	f3 0f 1e fa          	endbr64
    7484:	85 f6                	test   %esi,%esi
    7486:	74 08                	je     7490 <fwp_caps173+0x10>
    7488:	c3                   	ret
    7489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7490:	48 8b 15 01 d7 01 00 	mov    0x1d701(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7497:	48 89 f8             	mov    %rdi,%rax
    749a:	48 2b 05 cf d6 01 00 	sub    0x1d6cf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    74a1:	48 c1 e2 10          	shl    $0x10,%rdx
    74a5:	48 39 d0             	cmp    %rdx,%rax
    74a8:	73 de                	jae    7488 <fwp_caps173+0x8>
    74aa:	48 89 c2             	mov    %rax,%rdx
    74ad:	48 c1 ea 10          	shr    $0x10,%rdx
    74b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74b5:	48 8b 15 fc d6 01 00 	mov    0x1d6fc(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    74bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74c0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    74c4:	48 85 c9             	test   %rcx,%rcx
    74c7:	74 bf                	je     7488 <fwp_caps173+0x8>
    74c9:	0f b6 32             	movzbl (%rdx),%esi
    74cc:	40 80 fe 02          	cmp    $0x2,%sil
    74d0:	74 2e                	je     7500 <fwp_caps173+0x80>
    74d2:	40 80 fe 01          	cmp    $0x1,%sil
    74d6:	75 b0                	jne    7488 <fwp_caps173+0x8>
    74d8:	8b 72 18             	mov    0x18(%rdx),%esi
    74db:	0f b7 c0             	movzwl %ax,%eax
    74de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74e1:	48 0f af c6          	imul   %rsi,%rax
    74e5:	48 c1 e8 20          	shr    $0x20,%rax
    74e9:	48 39 d0             	cmp    %rdx,%rax
    74ec:	73 9a                	jae    7488 <fwp_caps173+0x8>
    74ee:	48 01 c1             	add    %rax,%rcx
    74f1:	80 39 01             	cmpb   $0x1,(%rcx)
    74f4:	75 92                	jne    7488 <fwp_caps173+0x8>
    74f6:	e9 95 e2 ff ff       	jmp    5790 <fwp_mem_free>
    74fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7500:	66 85 c0             	test   %ax,%ax
    7503:	74 ec                	je     74f1 <fwp_caps173+0x71>
    7505:	c3                   	ret
    7506:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    750d:	00 00 00 

0000000000007510 <fwp_args37>:
    7510:	f3 0f 1e fa          	endbr64
    7514:	85 d2                	test   %edx,%edx
    7516:	74 04                	je     751c <fwp_args37+0xc>
    7518:	85 f6                	test   %esi,%esi
    751a:	74 04                	je     7520 <fwp_args37+0x10>
    751c:	c3                   	ret
    751d:	0f 1f 00             	nopl   (%rax)
    7520:	48 8b 15 71 d6 01 00 	mov    0x1d671(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7527:	48 8b 07             	mov    (%rdi),%rax
    752a:	48 2b 05 3f d6 01 00 	sub    0x1d63f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7531:	48 c1 e2 10          	shl    $0x10,%rdx
    7535:	48 39 d0             	cmp    %rdx,%rax
    7538:	73 e2                	jae    751c <fwp_args37+0xc>
    753a:	48 89 c2             	mov    %rax,%rdx
    753d:	48 c1 ea 10          	shr    $0x10,%rdx
    7541:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7545:	48 8b 15 6c d6 01 00 	mov    0x1d66c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    754c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7550:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7554:	48 85 ff             	test   %rdi,%rdi
    7557:	74 c3                	je     751c <fwp_args37+0xc>
    7559:	0f b6 0a             	movzbl (%rdx),%ecx
    755c:	80 f9 02             	cmp    $0x2,%cl
    755f:	74 2f                	je     7590 <fwp_args37+0x80>
    7561:	80 f9 01             	cmp    $0x1,%cl
    7564:	75 b6                	jne    751c <fwp_args37+0xc>
    7566:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7569:	0f b7 c0             	movzwl %ax,%eax
    756c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    756f:	48 0f af c1          	imul   %rcx,%rax
    7573:	48 c1 e8 20          	shr    $0x20,%rax
    7577:	48 39 d0             	cmp    %rdx,%rax
    757a:	73 a0                	jae    751c <fwp_args37+0xc>
    757c:	48 01 c7             	add    %rax,%rdi
    757f:	0f b6 07             	movzbl (%rdi),%eax
    7582:	84 c0                	test   %al,%al
    7584:	74 96                	je     751c <fwp_args37+0xc>
    7586:	3c fd                	cmp    $0xfd,%al
    7588:	77 0c                	ja     7596 <fwp_args37+0x86>
    758a:	83 c0 01             	add    $0x1,%eax
    758d:	88 07                	mov    %al,(%rdi)
    758f:	c3                   	ret
    7590:	66 85 c0             	test   %ax,%ax
    7593:	74 ea                	je     757f <fwp_args37+0x6f>
    7595:	c3                   	ret
    7596:	e9 95 de ff ff       	jmp    5430 <fwp_rc_wide_dup>
    759b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000075a0 <fwp_caps37>:
    75a0:	f3 0f 1e fa          	endbr64
    75a4:	48 83 ec 18          	sub    $0x18,%rsp
    75a8:	8b 57 04             	mov    0x4(%rdi),%edx
    75ab:	48 89 f8             	mov    %rdi,%rax
    75ae:	85 d2                	test   %edx,%edx
    75b0:	0f 84 9a 00 00 00    	je     7650 <fwp_caps37+0xb0>
    75b6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    75ba:	85 f6                	test   %esi,%esi
    75bc:	0f 85 9e 00 00 00    	jne    7660 <fwp_caps37+0xc0>
    75c2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    75c7:	e8 44 f7 ff ff       	call   6d10 <fwp_drop4>
    75cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    75d1:	48 8b 0d c0 d5 01 00 	mov    0x1d5c0(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    75d8:	48 89 c2             	mov    %rax,%rdx
    75db:	48 2b 15 8e d5 01 00 	sub    0x1d58e(%rip),%rdx        # 24b70 <fwp_heap+0x13b0>
    75e2:	48 c1 e1 10          	shl    $0x10,%rcx
    75e6:	48 39 ca             	cmp    %rcx,%rdx
    75e9:	73 6d                	jae    7658 <fwp_caps37+0xb8>
    75eb:	48 89 d1             	mov    %rdx,%rcx
    75ee:	48 c1 e9 10          	shr    $0x10,%rcx
    75f2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    75f6:	48 8b 0d bb d5 01 00 	mov    0x1d5bb(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    75fd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7601:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7605:	48 85 f6             	test   %rsi,%rsi
    7608:	74 4e                	je     7658 <fwp_caps37+0xb8>
    760a:	0f b6 39             	movzbl (%rcx),%edi
    760d:	40 80 ff 02          	cmp    $0x2,%dil
    7611:	0f 84 b9 00 00 00    	je     76d0 <fwp_caps37+0x130>
    7617:	40 80 ff 01          	cmp    $0x1,%dil
    761b:	75 3b                	jne    7658 <fwp_caps37+0xb8>
    761d:	8b 79 18             	mov    0x18(%rcx),%edi
    7620:	0f b7 d2             	movzwl %dx,%edx
    7623:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7626:	48 0f af d7          	imul   %rdi,%rdx
    762a:	48 c1 ea 20          	shr    $0x20,%rdx
    762e:	48 39 ca             	cmp    %rcx,%rdx
    7631:	73 25                	jae    7658 <fwp_caps37+0xb8>
    7633:	48 01 d6             	add    %rdx,%rsi
    7636:	80 3e 01             	cmpb   $0x1,(%rsi)
    7639:	75 1d                	jne    7658 <fwp_caps37+0xb8>
    763b:	48 89 c7             	mov    %rax,%rdi
    763e:	48 83 c4 18          	add    $0x18,%rsp
    7642:	e9 49 e1 ff ff       	jmp    5790 <fwp_mem_free>
    7647:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    764e:	00 00 
    7650:	85 f6                	test   %esi,%esi
    7652:	0f 84 79 ff ff ff    	je     75d1 <fwp_caps37+0x31>
    7658:	48 83 c4 18          	add    $0x18,%rsp
    765c:	c3                   	ret
    765d:	0f 1f 00             	nopl   (%rax)
    7660:	48 8b 05 31 d5 01 00 	mov    0x1d531(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    7667:	48 2b 3d 02 d5 01 00 	sub    0x1d502(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    766e:	48 c1 e0 10          	shl    $0x10,%rax
    7672:	48 39 c7             	cmp    %rax,%rdi
    7675:	73 e1                	jae    7658 <fwp_caps37+0xb8>
    7677:	48 89 f8             	mov    %rdi,%rax
    767a:	48 c1 e8 10          	shr    $0x10,%rax
    767e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7682:	48 8b 05 2f d5 01 00 	mov    0x1d52f(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    7689:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    768d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7691:	48 85 c0             	test   %rax,%rax
    7694:	74 c2                	je     7658 <fwp_caps37+0xb8>
    7696:	0f b6 0a             	movzbl (%rdx),%ecx
    7699:	80 f9 02             	cmp    $0x2,%cl
    769c:	74 42                	je     76e0 <fwp_caps37+0x140>
    769e:	80 f9 01             	cmp    $0x1,%cl
    76a1:	75 b5                	jne    7658 <fwp_caps37+0xb8>
    76a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    76a6:	0f b7 ff             	movzwl %di,%edi
    76a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    76ac:	48 0f af f9          	imul   %rcx,%rdi
    76b0:	48 c1 ef 20          	shr    $0x20,%rdi
    76b4:	48 39 d7             	cmp    %rdx,%rdi
    76b7:	73 9f                	jae    7658 <fwp_caps37+0xb8>
    76b9:	48 01 f8             	add    %rdi,%rax
    76bc:	0f b6 10             	movzbl (%rax),%edx
    76bf:	84 d2                	test   %dl,%dl
    76c1:	74 95                	je     7658 <fwp_caps37+0xb8>
    76c3:	80 fa fd             	cmp    $0xfd,%dl
    76c6:	77 23                	ja     76eb <fwp_caps37+0x14b>
    76c8:	83 c2 01             	add    $0x1,%edx
    76cb:	88 10                	mov    %dl,(%rax)
    76cd:	eb 89                	jmp    7658 <fwp_caps37+0xb8>
    76cf:	90                   	nop
    76d0:	66 85 d2             	test   %dx,%dx
    76d3:	0f 85 7f ff ff ff    	jne    7658 <fwp_caps37+0xb8>
    76d9:	e9 58 ff ff ff       	jmp    7636 <fwp_caps37+0x96>
    76de:	66 90                	xchg   %ax,%ax
    76e0:	66 85 ff             	test   %di,%di
    76e3:	0f 85 6f ff ff ff    	jne    7658 <fwp_caps37+0xb8>
    76e9:	eb d1                	jmp    76bc <fwp_caps37+0x11c>
    76eb:	48 89 c7             	mov    %rax,%rdi
    76ee:	48 83 c4 18          	add    $0x18,%rsp
    76f2:	e9 39 dd ff ff       	jmp    5430 <fwp_rc_wide_dup>
    76f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76fe:	00 00 

0000000000007700 <fwp_drop0>:
    7700:	f3 0f 1e fa          	endbr64
    7704:	48 8b 15 8d d4 01 00 	mov    0x1d48d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    770b:	48 89 f8             	mov    %rdi,%rax
    770e:	48 2b 05 5b d4 01 00 	sub    0x1d45b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7715:	48 c1 e2 10          	shl    $0x10,%rdx
    7719:	48 39 d0             	cmp    %rdx,%rax
    771c:	0f 83 36 01 00 00    	jae    7858 <fwp_drop0+0x158>
    7722:	48 83 ec 18          	sub    $0x18,%rsp
    7726:	48 8d 35 93 c0 01 00 	lea    0x1c093(%rip),%rsi        # 237c0 <fwp_heap>
    772d:	48 89 c2             	mov    %rax,%rdx
    7730:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7737:	48 c1 ea 10          	shr    $0x10,%rdx
    773b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    773f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7743:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7747:	48 85 d2             	test   %rdx,%rdx
    774a:	74 42                	je     778e <fwp_drop0+0x8e>
    774c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7750:	41 80 f8 02          	cmp    $0x2,%r8b
    7754:	74 42                	je     7798 <fwp_drop0+0x98>
    7756:	41 80 f8 01          	cmp    $0x1,%r8b
    775a:	75 32                	jne    778e <fwp_drop0+0x8e>
    775c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7760:	0f b7 c0             	movzwl %ax,%eax
    7763:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7766:	49 0f af c0          	imul   %r8,%rax
    776a:	48 c1 e8 20          	shr    $0x20,%rax
    776e:	48 39 c8             	cmp    %rcx,%rax
    7771:	73 1b                	jae    778e <fwp_drop0+0x8e>
    7773:	48 01 c2             	add    %rax,%rdx
    7776:	0f b6 02             	movzbl (%rdx),%eax
    7779:	84 c0                	test   %al,%al
    777b:	74 11                	je     778e <fwp_drop0+0x8e>
    777d:	3c 01                	cmp    $0x1,%al
    777f:	74 27                	je     77a8 <fwp_drop0+0xa8>
    7781:	3c ff                	cmp    $0xff,%al
    7783:	0f 84 e7 00 00 00    	je     7870 <fwp_drop0+0x170>
    7789:	83 e8 01             	sub    $0x1,%eax
    778c:	88 02                	mov    %al,(%rdx)
    778e:	48 83 c4 18          	add    $0x18,%rsp
    7792:	c3                   	ret
    7793:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7798:	66 85 c0             	test   %ax,%ax
    779b:	74 d9                	je     7776 <fwp_drop0+0x76>
    779d:	48 83 c4 18          	add    $0x18,%rsp
    77a1:	c3                   	ret
    77a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77a8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    77af:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    77b6:	48 89 f8             	mov    %rdi,%rax
    77b9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    77bd:	48 29 c8             	sub    %rcx,%rax
    77c0:	48 c1 e2 10          	shl    $0x10,%rdx
    77c4:	48 39 d0             	cmp    %rdx,%rax
    77c7:	73 71                	jae    783a <fwp_drop0+0x13a>
    77c9:	49 89 c2             	mov    %rax,%r10
    77cc:	49 c1 ea 10          	shr    $0x10,%r10
    77d0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    77d4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    77d8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    77dc:	4d 85 d2             	test   %r10,%r10
    77df:	74 59                	je     783a <fwp_drop0+0x13a>
    77e1:	45 0f b6 19          	movzbl (%r9),%r11d
    77e5:	41 80 fb 02          	cmp    $0x2,%r11b
    77e9:	74 75                	je     7860 <fwp_drop0+0x160>
    77eb:	41 80 fb 01          	cmp    $0x1,%r11b
    77ef:	75 49                	jne    783a <fwp_drop0+0x13a>
    77f1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    77f5:	0f b7 c0             	movzwl %ax,%eax
    77f8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    77fc:	49 0f af c3          	imul   %r11,%rax
    7800:	48 c1 e8 20          	shr    $0x20,%rax
    7804:	4c 39 c8             	cmp    %r9,%rax
    7807:	73 31                	jae    783a <fwp_drop0+0x13a>
    7809:	49 01 c2             	add    %rax,%r10
    780c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7810:	75 28                	jne    783a <fwp_drop0+0x13a>
    7812:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7817:	e8 74 df ff ff       	call   5790 <fwp_mem_free>
    781c:	48 8d 35 9d bf 01 00 	lea    0x1bf9d(%rip),%rsi        # 237c0 <fwp_heap>
    7823:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7828:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    782f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7836:	48 c1 e2 10          	shl    $0x10,%rdx
    783a:	4c 89 c0             	mov    %r8,%rax
    783d:	48 29 c8             	sub    %rcx,%rax
    7840:	48 39 d0             	cmp    %rdx,%rax
    7843:	0f 83 45 ff ff ff    	jae    778e <fwp_drop0+0x8e>
    7849:	4c 89 c7             	mov    %r8,%rdi
    784c:	e9 dc fe ff ff       	jmp    772d <fwp_drop0+0x2d>
    7851:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7858:	c3                   	ret
    7859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7860:	66 85 c0             	test   %ax,%ax
    7863:	75 d5                	jne    783a <fwp_drop0+0x13a>
    7865:	eb a5                	jmp    780c <fwp_drop0+0x10c>
    7867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    786e:	00 00 
    7870:	48 89 d0             	mov    %rdx,%rax
    7873:	48 c1 e8 11          	shr    $0x11,%rax
    7877:	48 31 d0             	xor    %rdx,%rax
    787a:	48 89 c1             	mov    %rax,%rcx
    787d:	48 c1 e9 09          	shr    $0x9,%rcx
    7881:	48 31 c8             	xor    %rcx,%rax
    7884:	0f b6 c8             	movzbl %al,%ecx
    7887:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    788e:	00 
    788f:	48 85 c0             	test   %rax,%rax
    7892:	75 15                	jne    78a9 <fwp_drop0+0x1a9>
    7894:	eb 4e                	jmp    78e4 <fwp_drop0+0x1e4>
    7896:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    789d:	00 00 00 
    78a0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    78a4:	48 85 c0             	test   %rax,%rax
    78a7:	74 3b                	je     78e4 <fwp_drop0+0x1e4>
    78a9:	48 89 c1             	mov    %rax,%rcx
    78ac:	48 39 10             	cmp    %rdx,(%rax)
    78af:	75 ef                	jne    78a0 <fwp_drop0+0x1a0>
    78b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    78b5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    78b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    78bd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    78c4:	0f 85 c4 fe ff ff    	jne    778e <fwp_drop0+0x8e>
    78ca:	48 89 d7             	mov    %rdx,%rdi
    78cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    78d2:	e8 79 dc ff ff       	call   5550 <fwp_rc_forget_slot>
    78d7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    78dc:	c6 02 fe             	movb   $0xfe,(%rdx)
    78df:	e9 aa fe ff ff       	jmp    778e <fwp_drop0+0x8e>
    78e4:	48 8d 3d a5 7f 00 00 	lea    0x7fa5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    78eb:	e8 00 cb ff ff       	call   43f0 <fwp_trap>

00000000000078f0 <fwp_drop1>:
    78f0:	f3 0f 1e fa          	endbr64
    78f4:	48 8b 15 9d d2 01 00 	mov    0x1d29d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    78fb:	48 89 f8             	mov    %rdi,%rax
    78fe:	48 2b 05 6b d2 01 00 	sub    0x1d26b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7905:	48 c1 e2 10          	shl    $0x10,%rdx
    7909:	48 39 d0             	cmp    %rdx,%rax
    790c:	0f 83 36 01 00 00    	jae    7a48 <fwp_drop1+0x158>
    7912:	48 83 ec 18          	sub    $0x18,%rsp
    7916:	48 8d 35 a3 be 01 00 	lea    0x1bea3(%rip),%rsi        # 237c0 <fwp_heap>
    791d:	48 89 c2             	mov    %rax,%rdx
    7920:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7927:	48 c1 ea 10          	shr    $0x10,%rdx
    792b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    792f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7933:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7937:	48 85 d2             	test   %rdx,%rdx
    793a:	74 42                	je     797e <fwp_drop1+0x8e>
    793c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7940:	41 80 f8 02          	cmp    $0x2,%r8b
    7944:	74 42                	je     7988 <fwp_drop1+0x98>
    7946:	41 80 f8 01          	cmp    $0x1,%r8b
    794a:	75 32                	jne    797e <fwp_drop1+0x8e>
    794c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7950:	0f b7 c0             	movzwl %ax,%eax
    7953:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7956:	49 0f af c0          	imul   %r8,%rax
    795a:	48 c1 e8 20          	shr    $0x20,%rax
    795e:	48 39 c8             	cmp    %rcx,%rax
    7961:	73 1b                	jae    797e <fwp_drop1+0x8e>
    7963:	48 01 c2             	add    %rax,%rdx
    7966:	0f b6 02             	movzbl (%rdx),%eax
    7969:	84 c0                	test   %al,%al
    796b:	74 11                	je     797e <fwp_drop1+0x8e>
    796d:	3c 01                	cmp    $0x1,%al
    796f:	74 27                	je     7998 <fwp_drop1+0xa8>
    7971:	3c ff                	cmp    $0xff,%al
    7973:	0f 84 e7 00 00 00    	je     7a60 <fwp_drop1+0x170>
    7979:	83 e8 01             	sub    $0x1,%eax
    797c:	88 02                	mov    %al,(%rdx)
    797e:	48 83 c4 18          	add    $0x18,%rsp
    7982:	c3                   	ret
    7983:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7988:	66 85 c0             	test   %ax,%ax
    798b:	74 d9                	je     7966 <fwp_drop1+0x76>
    798d:	48 83 c4 18          	add    $0x18,%rsp
    7991:	c3                   	ret
    7992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7998:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    799f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    79a6:	48 89 f8             	mov    %rdi,%rax
    79a9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    79ad:	48 29 c8             	sub    %rcx,%rax
    79b0:	48 c1 e2 10          	shl    $0x10,%rdx
    79b4:	48 39 d0             	cmp    %rdx,%rax
    79b7:	73 71                	jae    7a2a <fwp_drop1+0x13a>
    79b9:	49 89 c2             	mov    %rax,%r10
    79bc:	49 c1 ea 10          	shr    $0x10,%r10
    79c0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    79c4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    79c8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    79cc:	4d 85 d2             	test   %r10,%r10
    79cf:	74 59                	je     7a2a <fwp_drop1+0x13a>
    79d1:	45 0f b6 19          	movzbl (%r9),%r11d
    79d5:	41 80 fb 02          	cmp    $0x2,%r11b
    79d9:	74 75                	je     7a50 <fwp_drop1+0x160>
    79db:	41 80 fb 01          	cmp    $0x1,%r11b
    79df:	75 49                	jne    7a2a <fwp_drop1+0x13a>
    79e1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    79e5:	0f b7 c0             	movzwl %ax,%eax
    79e8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    79ec:	49 0f af c3          	imul   %r11,%rax
    79f0:	48 c1 e8 20          	shr    $0x20,%rax
    79f4:	4c 39 c8             	cmp    %r9,%rax
    79f7:	73 31                	jae    7a2a <fwp_drop1+0x13a>
    79f9:	49 01 c2             	add    %rax,%r10
    79fc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7a00:	75 28                	jne    7a2a <fwp_drop1+0x13a>
    7a02:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7a07:	e8 84 dd ff ff       	call   5790 <fwp_mem_free>
    7a0c:	48 8d 35 ad bd 01 00 	lea    0x1bdad(%rip),%rsi        # 237c0 <fwp_heap>
    7a13:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7a18:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7a1f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7a26:	48 c1 e2 10          	shl    $0x10,%rdx
    7a2a:	4c 89 c0             	mov    %r8,%rax
    7a2d:	48 29 c8             	sub    %rcx,%rax
    7a30:	48 39 d0             	cmp    %rdx,%rax
    7a33:	0f 83 45 ff ff ff    	jae    797e <fwp_drop1+0x8e>
    7a39:	4c 89 c7             	mov    %r8,%rdi
    7a3c:	e9 dc fe ff ff       	jmp    791d <fwp_drop1+0x2d>
    7a41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a48:	c3                   	ret
    7a49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a50:	66 85 c0             	test   %ax,%ax
    7a53:	75 d5                	jne    7a2a <fwp_drop1+0x13a>
    7a55:	eb a5                	jmp    79fc <fwp_drop1+0x10c>
    7a57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a5e:	00 00 
    7a60:	48 89 d0             	mov    %rdx,%rax
    7a63:	48 c1 e8 11          	shr    $0x11,%rax
    7a67:	48 31 d0             	xor    %rdx,%rax
    7a6a:	48 89 c1             	mov    %rax,%rcx
    7a6d:	48 c1 e9 09          	shr    $0x9,%rcx
    7a71:	48 31 c8             	xor    %rcx,%rax
    7a74:	0f b6 c8             	movzbl %al,%ecx
    7a77:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7a7e:	00 
    7a7f:	48 85 c0             	test   %rax,%rax
    7a82:	75 25                	jne    7aa9 <fwp_drop1+0x1b9>
    7a84:	eb 5e                	jmp    7ae4 <fwp_drop1+0x1f4>
    7a86:	0f 1f 40 00          	nopl   0x0(%rax)
    7a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a91:	00 00 00 00 
    7a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a9c:	00 00 00 00 
    7aa0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7aa4:	48 85 c0             	test   %rax,%rax
    7aa7:	74 3b                	je     7ae4 <fwp_drop1+0x1f4>
    7aa9:	48 89 c1             	mov    %rax,%rcx
    7aac:	48 39 10             	cmp    %rdx,(%rax)
    7aaf:	75 ef                	jne    7aa0 <fwp_drop1+0x1b0>
    7ab1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ab5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7ab9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7abd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ac4:	0f 85 b4 fe ff ff    	jne    797e <fwp_drop1+0x8e>
    7aca:	48 89 d7             	mov    %rdx,%rdi
    7acd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ad2:	e8 79 da ff ff       	call   5550 <fwp_rc_forget_slot>
    7ad7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7adc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7adf:	e9 9a fe ff ff       	jmp    797e <fwp_drop1+0x8e>
    7ae4:	48 8d 3d a5 7d 00 00 	lea    0x7da5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7aeb:	e8 00 c9 ff ff       	call   43f0 <fwp_trap>

0000000000007af0 <fwp_drop10>:
    7af0:	48 8b 0d a1 d0 01 00 	mov    0x1d0a1(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    7af7:	48 89 f8             	mov    %rdi,%rax
    7afa:	48 2b 05 6f d0 01 00 	sub    0x1d06f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7b01:	48 c1 e1 10          	shl    $0x10,%rcx
    7b05:	48 39 c8             	cmp    %rcx,%rax
    7b08:	0f 83 c2 01 00 00    	jae    7cd0 <fwp_drop10+0x1e0>
    7b0e:	48 83 ec 18          	sub    $0x18,%rsp
    7b12:	48 89 fa             	mov    %rdi,%rdx
    7b15:	48 8d 35 a4 bc 01 00 	lea    0x1bca4(%rip),%rsi        # 237c0 <fwp_heap>
    7b1c:	48 89 c1             	mov    %rax,%rcx
    7b1f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7b26:	48 c1 e9 10          	shr    $0x10,%rcx
    7b2a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7b2e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7b32:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7b36:	48 85 c9             	test   %rcx,%rcx
    7b39:	74 46                	je     7b81 <fwp_drop10+0x91>
    7b3b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7b3f:	41 80 f9 02          	cmp    $0x2,%r9b
    7b43:	0f 84 d7 00 00 00    	je     7c20 <fwp_drop10+0x130>
    7b49:	41 80 f9 01          	cmp    $0x1,%r9b
    7b4d:	75 32                	jne    7b81 <fwp_drop10+0x91>
    7b4f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7b53:	0f b7 c0             	movzwl %ax,%eax
    7b56:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7b59:	49 0f af c1          	imul   %r9,%rax
    7b5d:	48 c1 e8 20          	shr    $0x20,%rax
    7b61:	48 39 f8             	cmp    %rdi,%rax
    7b64:	73 1b                	jae    7b81 <fwp_drop10+0x91>
    7b66:	48 01 c1             	add    %rax,%rcx
    7b69:	0f b6 01             	movzbl (%rcx),%eax
    7b6c:	84 c0                	test   %al,%al
    7b6e:	74 11                	je     7b81 <fwp_drop10+0x91>
    7b70:	3c 01                	cmp    $0x1,%al
    7b72:	74 1c                	je     7b90 <fwp_drop10+0xa0>
    7b74:	3c ff                	cmp    $0xff,%al
    7b76:	0f 84 5c 01 00 00    	je     7cd8 <fwp_drop10+0x1e8>
    7b7c:	83 e8 01             	sub    $0x1,%eax
    7b7f:	88 01                	mov    %al,(%rcx)
    7b81:	48 83 c4 18          	add    $0x18,%rsp
    7b85:	c3                   	ret
    7b86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b8d:	00 00 00 
    7b90:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7b97:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7b9e:	48 89 d0             	mov    %rdx,%rax
    7ba1:	49 89 d1             	mov    %rdx,%r9
    7ba4:	48 c1 e1 10          	shl    $0x10,%rcx
    7ba8:	48 29 f8             	sub    %rdi,%rax
    7bab:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7baf:	78 7f                	js     7c30 <fwp_drop10+0x140>
    7bb1:	48 39 c8             	cmp    %rcx,%rax
    7bb4:	73 cb                	jae    7b81 <fwp_drop10+0x91>
    7bb6:	48 89 c1             	mov    %rax,%rcx
    7bb9:	48 c1 e9 10          	shr    $0x10,%rcx
    7bbd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7bc1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7bc5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7bc9:	48 85 f6             	test   %rsi,%rsi
    7bcc:	74 b3                	je     7b81 <fwp_drop10+0x91>
    7bce:	0f b6 39             	movzbl (%rcx),%edi
    7bd1:	40 80 ff 02          	cmp    $0x2,%dil
    7bd5:	74 39                	je     7c10 <fwp_drop10+0x120>
    7bd7:	40 80 ff 01          	cmp    $0x1,%dil
    7bdb:	75 a4                	jne    7b81 <fwp_drop10+0x91>
    7bdd:	8b 79 18             	mov    0x18(%rcx),%edi
    7be0:	0f b7 c0             	movzwl %ax,%eax
    7be3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7be6:	48 0f af c7          	imul   %rdi,%rax
    7bea:	48 c1 e8 20          	shr    $0x20,%rax
    7bee:	48 39 c8             	cmp    %rcx,%rax
    7bf1:	73 8e                	jae    7b81 <fwp_drop10+0x91>
    7bf3:	48 01 c6             	add    %rax,%rsi
    7bf6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7bf9:	75 86                	jne    7b81 <fwp_drop10+0x91>
    7bfb:	48 89 d7             	mov    %rdx,%rdi
    7bfe:	48 83 c4 18          	add    $0x18,%rsp
    7c02:	e9 89 db ff ff       	jmp    5790 <fwp_mem_free>
    7c07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c0e:	00 00 
    7c10:	66 85 c0             	test   %ax,%ax
    7c13:	74 e1                	je     7bf6 <fwp_drop10+0x106>
    7c15:	48 83 c4 18          	add    $0x18,%rsp
    7c19:	c3                   	ret
    7c1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c20:	66 85 c0             	test   %ax,%ax
    7c23:	0f 84 40 ff ff ff    	je     7b69 <fwp_drop10+0x79>
    7c29:	48 83 c4 18          	add    $0x18,%rsp
    7c2d:	c3                   	ret
    7c2e:	66 90                	xchg   %ax,%ax
    7c30:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7c34:	48 39 c8             	cmp    %rcx,%rax
    7c37:	73 74                	jae    7cad <fwp_drop10+0x1bd>
    7c39:	49 89 c2             	mov    %rax,%r10
    7c3c:	49 c1 ea 10          	shr    $0x10,%r10
    7c40:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7c44:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7c48:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7c4c:	4d 85 d2             	test   %r10,%r10
    7c4f:	74 5c                	je     7cad <fwp_drop10+0x1bd>
    7c51:	45 0f b6 18          	movzbl (%r8),%r11d
    7c55:	41 80 fb 02          	cmp    $0x2,%r11b
    7c59:	74 6d                	je     7cc8 <fwp_drop10+0x1d8>
    7c5b:	41 80 fb 01          	cmp    $0x1,%r11b
    7c5f:	75 4c                	jne    7cad <fwp_drop10+0x1bd>
    7c61:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7c65:	0f b7 c0             	movzwl %ax,%eax
    7c68:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7c6c:	49 0f af c3          	imul   %r11,%rax
    7c70:	48 c1 e8 20          	shr    $0x20,%rax
    7c74:	4c 39 c0             	cmp    %r8,%rax
    7c77:	73 34                	jae    7cad <fwp_drop10+0x1bd>
    7c79:	49 01 c2             	add    %rax,%r10
    7c7c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c80:	75 2b                	jne    7cad <fwp_drop10+0x1bd>
    7c82:	4c 89 cf             	mov    %r9,%rdi
    7c85:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c8a:	e8 01 db ff ff       	call   5790 <fwp_mem_free>
    7c8f:	48 8d 35 2a bb 01 00 	lea    0x1bb2a(%rip),%rsi        # 237c0 <fwp_heap>
    7c96:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c9b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7ca2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7ca9:	48 c1 e1 10          	shl    $0x10,%rcx
    7cad:	48 89 d0             	mov    %rdx,%rax
    7cb0:	48 29 f8             	sub    %rdi,%rax
    7cb3:	48 39 c8             	cmp    %rcx,%rax
    7cb6:	0f 82 60 fe ff ff    	jb     7b1c <fwp_drop10+0x2c>
    7cbc:	e9 c0 fe ff ff       	jmp    7b81 <fwp_drop10+0x91>
    7cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cc8:	66 85 c0             	test   %ax,%ax
    7ccb:	75 e0                	jne    7cad <fwp_drop10+0x1bd>
    7ccd:	eb ad                	jmp    7c7c <fwp_drop10+0x18c>
    7ccf:	90                   	nop
    7cd0:	c3                   	ret
    7cd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cd8:	48 89 c8             	mov    %rcx,%rax
    7cdb:	48 c1 e8 11          	shr    $0x11,%rax
    7cdf:	48 31 c8             	xor    %rcx,%rax
    7ce2:	48 89 c2             	mov    %rax,%rdx
    7ce5:	48 c1 ea 09          	shr    $0x9,%rdx
    7ce9:	48 31 d0             	xor    %rdx,%rax
    7cec:	0f b6 d0             	movzbl %al,%edx
    7cef:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7cf6:	00 
    7cf7:	48 85 c0             	test   %rax,%rax
    7cfa:	75 0d                	jne    7d09 <fwp_drop10+0x219>
    7cfc:	eb 46                	jmp    7d44 <fwp_drop10+0x254>
    7cfe:	66 90                	xchg   %ax,%ax
    7d00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7d04:	48 85 c0             	test   %rax,%rax
    7d07:	74 3b                	je     7d44 <fwp_drop10+0x254>
    7d09:	48 89 c2             	mov    %rax,%rdx
    7d0c:	48 39 08             	cmp    %rcx,(%rax)
    7d0f:	75 ef                	jne    7d00 <fwp_drop10+0x210>
    7d11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7d15:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7d19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7d1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7d24:	0f 85 57 fe ff ff    	jne    7b81 <fwp_drop10+0x91>
    7d2a:	48 89 cf             	mov    %rcx,%rdi
    7d2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7d32:	e8 19 d8 ff ff       	call   5550 <fwp_rc_forget_slot>
    7d37:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7d3c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7d3f:	e9 3d fe ff ff       	jmp    7b81 <fwp_drop10+0x91>
    7d44:	48 8d 3d 45 7b 00 00 	lea    0x7b45(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7d4b:	e8 a0 c6 ff ff       	call   43f0 <fwp_trap>

0000000000007d50 <f37>:
    7d50:	41 57                	push   %r15
    7d52:	41 56                	push   %r14
    7d54:	41 55                	push   %r13
    7d56:	41 54                	push   %r12
    7d58:	55                   	push   %rbp
    7d59:	53                   	push   %rbx
    7d5a:	48 83 ec 38          	sub    $0x38,%rsp
    7d5e:	48 8b 15 33 ce 01 00 	mov    0x1ce33(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7d65:	48 8b 0d 04 ce 01 00 	mov    0x1ce04(%rip),%rcx        # 24b70 <fwp_heap+0x13b0>
    7d6c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7d73:	00 00 
    7d75:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7d7a:	49 89 fc             	mov    %rdi,%r12
    7d7d:	48 c1 e2 10          	shl    $0x10,%rdx
    7d81:	48 85 ff             	test   %rdi,%rdi
    7d84:	0f 84 bc 02 00 00    	je     8046 <f37+0x2f6>
    7d8a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7d8f:	48 89 d8             	mov    %rbx,%rax
    7d92:	48 29 c8             	sub    %rcx,%rax
    7d95:	48 39 d0             	cmp    %rdx,%rax
    7d98:	0f 83 72 03 00 00    	jae    8110 <f37+0x3c0>
    7d9e:	48 89 c2             	mov    %rax,%rdx
    7da1:	48 c1 ea 10          	shr    $0x10,%rdx
    7da5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7da9:	48 8b 15 08 ce 01 00 	mov    0x1ce08(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7db0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7db4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7db8:	48 85 ff             	test   %rdi,%rdi
    7dbb:	0f 84 4f 03 00 00    	je     8110 <f37+0x3c0>
    7dc1:	0f b6 0a             	movzbl (%rdx),%ecx
    7dc4:	80 f9 02             	cmp    $0x2,%cl
    7dc7:	0f 84 53 02 00 00    	je     8020 <f37+0x2d0>
    7dcd:	80 f9 01             	cmp    $0x1,%cl
    7dd0:	75 24                	jne    7df6 <f37+0xa6>
    7dd2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7dd5:	0f b7 c0             	movzwl %ax,%eax
    7dd8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ddb:	48 0f af c1          	imul   %rcx,%rax
    7ddf:	48 c1 e8 20          	shr    $0x20,%rax
    7de3:	48 39 d0             	cmp    %rdx,%rax
    7de6:	73 0e                	jae    7df6 <f37+0xa6>
    7de8:	48 01 c7             	add    %rax,%rdi
    7deb:	0f b6 07             	movzbl (%rdi),%eax
    7dee:	84 c0                	test   %al,%al
    7df0:	0f 85 ca 02 00 00    	jne    80c0 <f37+0x370>
    7df6:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7dfb:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7e00:	ba 01 00 00 00       	mov    $0x1,%edx
    7e05:	48 85 db             	test   %rbx,%rbx
    7e08:	74 13                	je     7e1d <f37+0xcd>
    7e0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e10:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7e14:	48 83 c2 01          	add    $0x1,%rdx
    7e18:	48 85 db             	test   %rbx,%rbx
    7e1b:	75 f3                	jne    7e10 <f37+0xc0>
    7e1d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e22:	48 85 c0             	test   %rax,%rax
    7e25:	0f 84 15 03 00 00    	je     8140 <f37+0x3f0>
    7e2b:	31 db                	xor    %ebx,%ebx
    7e2d:	0f 1f 00             	nopl   (%rax)
    7e30:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e34:	48 83 c3 01          	add    $0x1,%rbx
    7e38:	48 85 c0             	test   %rax,%rax
    7e3b:	75 f3                	jne    7e30 <f37+0xe0>
    7e3d:	48 39 d3             	cmp    %rdx,%rbx
    7e40:	48 0f 47 da          	cmova  %rdx,%rbx
    7e44:	48 89 d8             	mov    %rbx,%rax
    7e47:	48 c1 e8 3c          	shr    $0x3c,%rax
    7e4b:	0f 85 8f 03 00 00    	jne    81e0 <f37+0x490>
    7e51:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7e55:	be 02 00 00 00       	mov    $0x2,%esi
    7e5a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7e61:	00 
    7e62:	e8 29 de ff ff       	call   5c90 <fwp_heap_alloc>
    7e67:	48 89 28             	mov    %rbp,(%rax)
    7e6a:	48 8b 15 27 cd 01 00 	mov    0x1cd27(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7e71:	49 89 c6             	mov    %rax,%r14
    7e74:	48 2b 05 f5 cc 01 00 	sub    0x1ccf5(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7e7b:	48 c1 e2 10          	shl    $0x10,%rdx
    7e7f:	48 39 d0             	cmp    %rdx,%rax
    7e82:	73 57                	jae    7edb <f37+0x18b>
    7e84:	48 89 c2             	mov    %rax,%rdx
    7e87:	48 c1 ea 10          	shr    $0x10,%rdx
    7e8b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e8f:	48 8b 15 22 cd 01 00 	mov    0x1cd22(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7e96:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e9a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7e9e:	48 85 ed             	test   %rbp,%rbp
    7ea1:	74 38                	je     7edb <f37+0x18b>
    7ea3:	0f b6 0a             	movzbl (%rdx),%ecx
    7ea6:	80 f9 02             	cmp    $0x2,%cl
    7ea9:	0f 84 51 02 00 00    	je     8100 <f37+0x3b0>
    7eaf:	80 f9 01             	cmp    $0x1,%cl
    7eb2:	75 27                	jne    7edb <f37+0x18b>
    7eb4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7eb7:	0f b7 c0             	movzwl %ax,%eax
    7eba:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ebd:	48 0f af c1          	imul   %rcx,%rax
    7ec1:	48 c1 e8 20          	shr    $0x20,%rax
    7ec5:	48 39 d0             	cmp    %rdx,%rax
    7ec8:	73 11                	jae    7edb <f37+0x18b>
    7eca:	48 01 c5             	add    %rax,%rbp
    7ecd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7ed1:	0f 84 d5 02 00 00    	je     81ac <f37+0x45c>
    7ed7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7edb:	48 85 db             	test   %rbx,%rbx
    7ede:	74 5d                	je     7f3d <f37+0x1ed>
    7ee0:	48 c1 e3 04          	shl    $0x4,%rbx
    7ee4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7ee9:	4c 89 f5             	mov    %r14,%rbp
    7eec:	4d 89 e5             	mov    %r12,%r13
    7eef:	4c 01 f3             	add    %r14,%rbx
    7ef2:	0f 1f 00             	nopl   (%rax)
    7ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7efc:	00 00 00 00 
    7f00:	49 8b 45 08          	mov    0x8(%r13),%rax
    7f04:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7f08:	48 83 c5 10          	add    $0x10,%rbp
    7f0c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7f11:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7f15:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7f19:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7f1e:	e8 3d e3 ff ff       	call   6260 <w120>
    7f23:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7f28:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7f2c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7f30:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7f34:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7f38:	48 39 dd             	cmp    %rbx,%rbp
    7f3b:	75 c3                	jne    7f00 <f37+0x1b0>
    7f3d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7f42:	e8 c9 ed ff ff       	call   6d10 <fwp_drop4>
    7f47:	4c 89 e7             	mov    %r12,%rdi
    7f4a:	e8 c1 ed ff ff       	call   6d10 <fwp_drop4>
    7f4f:	4c 89 f7             	mov    %r14,%rdi
    7f52:	e8 79 e4 ff ff       	call   63d0 <w176.constprop.0>
    7f57:	4c 89 f7             	mov    %r14,%rdi
    7f5a:	48 89 c3             	mov    %rax,%rbx
    7f5d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7f63:	e8 88 fb ff ff       	call   7af0 <fwp_drop10>
    7f68:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7f6e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7f73:	31 ff                	xor    %edi,%edi
    7f75:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7f7a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7f7e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7f83:	e8 28 de ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    7f88:	48 8b 15 09 cc 01 00 	mov    0x1cc09(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7f8f:	48 89 c5             	mov    %rax,%rbp
    7f92:	48 2b 05 d7 cb 01 00 	sub    0x1cbd7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7f99:	48 c1 e2 10          	shl    $0x10,%rdx
    7f9d:	48 39 d0             	cmp    %rdx,%rax
    7fa0:	73 55                	jae    7ff7 <f37+0x2a7>
    7fa2:	48 89 c2             	mov    %rax,%rdx
    7fa5:	48 c1 ea 10          	shr    $0x10,%rdx
    7fa9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7fad:	48 8b 15 04 cc 01 00 	mov    0x1cc04(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7fb4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7fb8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7fbc:	48 85 db             	test   %rbx,%rbx
    7fbf:	74 36                	je     7ff7 <f37+0x2a7>
    7fc1:	0f b6 0a             	movzbl (%rdx),%ecx
    7fc4:	80 f9 02             	cmp    $0x2,%cl
    7fc7:	0f 84 1b 01 00 00    	je     80e8 <f37+0x398>
    7fcd:	80 f9 01             	cmp    $0x1,%cl
    7fd0:	75 25                	jne    7ff7 <f37+0x2a7>
    7fd2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fd5:	0f b7 c0             	movzwl %ax,%eax
    7fd8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fdb:	48 0f af c1          	imul   %rcx,%rax
    7fdf:	48 c1 e8 20          	shr    $0x20,%rax
    7fe3:	48 39 d0             	cmp    %rdx,%rax
    7fe6:	73 0f                	jae    7ff7 <f37+0x2a7>
    7fe8:	48 01 c3             	add    %rax,%rbx
    7feb:	80 3b ff             	cmpb   $0xff,(%rbx)
    7fee:	0f 84 ab 01 00 00    	je     819f <f37+0x44f>
    7ff4:	c6 03 01             	movb   $0x1,(%rbx)
    7ff7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7ffc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8003:	00 00 
    8005:	0f 85 d0 01 00 00    	jne    81db <f37+0x48b>
    800b:	48 83 c4 38          	add    $0x38,%rsp
    800f:	48 89 e8             	mov    %rbp,%rax
    8012:	5b                   	pop    %rbx
    8013:	5d                   	pop    %rbp
    8014:	41 5c                	pop    %r12
    8016:	41 5d                	pop    %r13
    8018:	41 5e                	pop    %r14
    801a:	41 5f                	pop    %r15
    801c:	c3                   	ret
    801d:	0f 1f 00             	nopl   (%rax)
    8020:	66 85 c0             	test   %ax,%ax
    8023:	0f 85 cd fd ff ff    	jne    7df6 <f37+0xa6>
    8029:	0f b6 07             	movzbl (%rdi),%eax
    802c:	84 c0                	test   %al,%al
    802e:	0f 84 c2 fd ff ff    	je     7df6 <f37+0xa6>
    8034:	3c fd                	cmp    $0xfd,%al
    8036:	0f 87 95 01 00 00    	ja     81d1 <f37+0x481>
    803c:	83 c0 01             	add    $0x1,%eax
    803f:	88 07                	mov    %al,(%rdi)
    8041:	e9 b0 fd ff ff       	jmp    7df6 <f37+0xa6>
    8046:	48 f7 d9             	neg    %rcx
    8049:	48 39 d1             	cmp    %rdx,%rcx
    804c:	0f 83 ee 00 00 00    	jae    8140 <f37+0x3f0>
    8052:	48 89 c8             	mov    %rcx,%rax
    8055:	48 c1 e8 10          	shr    $0x10,%rax
    8059:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    805d:	48 8b 05 54 cb 01 00 	mov    0x1cb54(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    8064:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8068:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    806c:	48 85 ff             	test   %rdi,%rdi
    806f:	0f 84 cb 00 00 00    	je     8140 <f37+0x3f0>
    8075:	0f b6 02             	movzbl (%rdx),%eax
    8078:	3c 02                	cmp    $0x2,%al
    807a:	0f 84 9a 00 00 00    	je     811a <f37+0x3ca>
    8080:	3c 01                	cmp    $0x1,%al
    8082:	0f 85 b8 00 00 00    	jne    8140 <f37+0x3f0>
    8088:	0f b7 c1             	movzwl %cx,%eax
    808b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    808e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8091:	48 0f af c1          	imul   %rcx,%rax
    8095:	48 c1 e8 20          	shr    $0x20,%rax
    8099:	48 39 d0             	cmp    %rdx,%rax
    809c:	0f 83 9e 00 00 00    	jae    8140 <f37+0x3f0>
    80a2:	48 01 c7             	add    %rax,%rdi
    80a5:	0f b6 07             	movzbl (%rdi),%eax
    80a8:	84 c0                	test   %al,%al
    80aa:	0f 84 90 00 00 00    	je     8140 <f37+0x3f0>
    80b0:	31 db                	xor    %ebx,%ebx
    80b2:	0f 1f 00             	nopl   (%rax)
    80b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80bc:	00 00 00 00 
    80c0:	3c fd                	cmp    $0xfd,%al
    80c2:	0f 87 f1 00 00 00    	ja     81b9 <f37+0x469>
    80c8:	83 c0 01             	add    $0x1,%eax
    80cb:	88 07                	mov    %al,(%rdi)
    80cd:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    80d2:	31 d2                	xor    %edx,%edx
    80d4:	4d 85 e4             	test   %r12,%r12
    80d7:	0f 85 1e fd ff ff    	jne    7dfb <f37+0xab>
    80dd:	e9 3b fd ff ff       	jmp    7e1d <f37+0xcd>
    80e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80e8:	66 85 c0             	test   %ax,%ax
    80eb:	0f 85 06 ff ff ff    	jne    7ff7 <f37+0x2a7>
    80f1:	e9 f5 fe ff ff       	jmp    7feb <f37+0x29b>
    80f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    80fd:	00 00 00 
    8100:	66 85 c0             	test   %ax,%ax
    8103:	0f 85 d2 fd ff ff    	jne    7edb <f37+0x18b>
    8109:	e9 bf fd ff ff       	jmp    7ecd <f37+0x17d>
    810e:	66 90                	xchg   %ax,%ax
    8110:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8115:	e9 e6 fc ff ff       	jmp    7e00 <f37+0xb0>
    811a:	66 85 c9             	test   %cx,%cx
    811d:	75 21                	jne    8140 <f37+0x3f0>
    811f:	0f b6 07             	movzbl (%rdi),%eax
    8122:	84 c0                	test   %al,%al
    8124:	74 1a                	je     8140 <f37+0x3f0>
    8126:	3c fd                	cmp    $0xfd,%al
    8128:	0f 87 be 00 00 00    	ja     81ec <f37+0x49c>
    812e:	83 c0 01             	add    $0x1,%eax
    8131:	88 07                	mov    %al,(%rdi)
    8133:	66 90                	xchg   %ax,%ax
    8135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    813c:	00 00 00 00 
    8140:	be 02 00 00 00       	mov    $0x2,%esi
    8145:	bf 08 00 00 00       	mov    $0x8,%edi
    814a:	e8 41 db ff ff       	call   5c90 <fwp_heap_alloc>
    814f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8156:	48 8b 15 3b ca 01 00 	mov    0x1ca3b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    815d:	49 89 c6             	mov    %rax,%r14
    8160:	48 2b 05 09 ca 01 00 	sub    0x1ca09(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    8167:	48 c1 e2 10          	shl    $0x10,%rdx
    816b:	48 39 d0             	cmp    %rdx,%rax
    816e:	73 53                	jae    81c3 <f37+0x473>
    8170:	48 89 c2             	mov    %rax,%rdx
    8173:	48 c1 ea 10          	shr    $0x10,%rdx
    8177:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    817b:	48 8b 15 36 ca 01 00 	mov    0x1ca36(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    8182:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8186:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    818a:	48 85 ed             	test   %rbp,%rbp
    818d:	74 34                	je     81c3 <f37+0x473>
    818f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8196:	00 00 
    8198:	31 db                	xor    %ebx,%ebx
    819a:	e9 04 fd ff ff       	jmp    7ea3 <f37+0x153>
    819f:	48 89 df             	mov    %rbx,%rdi
    81a2:	e8 a9 d3 ff ff       	call   5550 <fwp_rc_forget_slot>
    81a7:	e9 48 fe ff ff       	jmp    7ff4 <f37+0x2a4>
    81ac:	48 89 ef             	mov    %rbp,%rdi
    81af:	e8 9c d3 ff ff       	call   5550 <fwp_rc_forget_slot>
    81b4:	e9 1e fd ff ff       	jmp    7ed7 <f37+0x187>
    81b9:	e8 72 d2 ff ff       	call   5430 <fwp_rc_wide_dup>
    81be:	e9 0a ff ff ff       	jmp    80cd <f37+0x37d>
    81c3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    81ca:	00 00 
    81cc:	e9 6c fd ff ff       	jmp    7f3d <f37+0x1ed>
    81d1:	e8 5a d2 ff ff       	call   5430 <fwp_rc_wide_dup>
    81d6:	e9 1b fc ff ff       	jmp    7df6 <f37+0xa6>
    81db:	e8 80 b2 ff ff       	call   3460 <__stack_chk_fail@plt>
    81e0:	48 8d 3d a9 6f 00 00 	lea    0x6fa9(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    81e7:	e8 04 c2 ff ff       	call   43f0 <fwp_trap>
    81ec:	e8 3f d2 ff ff       	call   5430 <fwp_rc_wide_dup>
    81f1:	e9 4a ff ff ff       	jmp    8140 <f37+0x3f0>
    81f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    81fd:	00 00 00 

0000000000008200 <fwp_owned_entry37>:
    8200:	f3 0f 1e fa          	endbr64
    8204:	48 8b 3f             	mov    (%rdi),%rdi
    8207:	e9 44 fb ff ff       	jmp    7d50 <f37>
    820c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008210 <e37>:
    8210:	f3 0f 1e fa          	endbr64
    8214:	53                   	push   %rbx
    8215:	48 8b 1f             	mov    (%rdi),%rbx
    8218:	48 89 df             	mov    %rbx,%rdi
    821b:	e8 30 e2 ff ff       	call   6450 <fwp_rc_share>
    8220:	48 89 df             	mov    %rbx,%rdi
    8223:	e8 28 fb ff ff       	call   7d50 <f37>
    8228:	48 89 c3             	mov    %rax,%rbx
    822b:	48 89 c7             	mov    %rax,%rdi
    822e:	e8 1d e2 ff ff       	call   6450 <fwp_rc_share>
    8233:	48 89 d8             	mov    %rbx,%rax
    8236:	5b                   	pop    %rbx
    8237:	c3                   	ret
    8238:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    823f:	00 

0000000000008240 <fwp_write>:
    8240:	41 57                	push   %r15
    8242:	41 56                	push   %r14
    8244:	41 55                	push   %r13
    8246:	41 54                	push   %r12
    8248:	55                   	push   %rbp
    8249:	53                   	push   %rbx
    824a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8251:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8258:	00 00 
    825a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8261:	00 
    8262:	49 89 d4             	mov    %rdx,%r12
    8265:	8b 12                	mov    (%rdx),%edx
    8267:	83 fa 19             	cmp    $0x19,%edx
    826a:	77 6a                	ja     82d6 <fwp_write+0x96>
    826c:	48 89 f5             	mov    %rsi,%rbp
    826f:	89 d0                	mov    %edx,%eax
    8271:	89 ce                	mov    %ecx,%esi
    8273:	48 89 fb             	mov    %rdi,%rbx
    8276:	48 8d 0d 83 78 00 00 	lea    0x7883(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    827d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8281:	48 01 c8             	add    %rcx,%rax
    8284:	3e ff e0             	notrack jmp *%rax
    8287:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    828e:	00 00 
    8290:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8294:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8298:	48 89 ca             	mov    %rcx,%rdx
    829b:	48 85 c9             	test   %rcx,%rcx
    829e:	0f 88 9c 0c 00 00    	js     8f40 <fwp_write+0xd00>
    82a4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    82ab:	00 
    82ac:	48 89 c6             	mov    %rax,%rsi
    82af:	4c 89 e7             	mov    %r12,%rdi
    82b2:	e8 89 b7 ff ff       	call   3a40 <fwp_fmt_u128>
    82b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    82be:	00 00 
    82c0:	4c 89 e7             	mov    %r12,%rdi
    82c3:	e8 88 b1 ff ff       	call   3450 <strlen@plt>
    82c8:	4c 89 e6             	mov    %r12,%rsi
    82cb:	48 89 df             	mov    %rbx,%rdi
    82ce:	48 89 c2             	mov    %rax,%rdx
    82d1:	e8 3a bf ff ff       	call   4210 <buf_put>
    82d6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    82dd:	00 
    82de:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    82e5:	00 00 
    82e7:	0f 85 28 04 00 00    	jne    8715 <fwp_write+0x4d5>
    82ed:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    82f4:	5b                   	pop    %rbx
    82f5:	5d                   	pop    %rbp
    82f6:	41 5c                	pop    %r12
    82f8:	41 5d                	pop    %r13
    82fa:	41 5e                	pop    %r14
    82fc:	41 5f                	pop    %r15
    82fe:	c3                   	ret
    82ff:	90                   	nop
    8300:	49 89 e9             	mov    %rbp,%r9
    8303:	4c 8d 05 6b 6d 00 00 	lea    0x6d6b(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    830a:	b9 00 02 00 00       	mov    $0x200,%ecx
    830f:	ba 02 00 00 00       	mov    $0x2,%edx
    8314:	be 00 02 00 00       	mov    $0x200,%esi
    8319:	31 c0                	xor    %eax,%eax
    831b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8322:	00 
    8323:	e8 88 b0 ff ff       	call   33b0 <__snprintf_chk@plt>
    8328:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    832f:	00 
    8330:	e8 1b b1 ff ff       	call   3450 <strlen@plt>
    8335:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    833c:	00 
    833d:	48 89 df             	mov    %rbx,%rdi
    8340:	48 89 c2             	mov    %rax,%rdx
    8343:	e8 c8 be ff ff       	call   4210 <buf_put>
    8348:	eb 8c                	jmp    82d6 <fwp_write+0x96>
    834a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8350:	49 89 e9             	mov    %rbp,%r9
    8353:	4c 8d 05 5b 6e 00 00 	lea    0x6e5b(%rip),%r8        # f1b5 <_IO_stdin_used+0x1b5>
    835a:	eb ae                	jmp    830a <fwp_write+0xca>
    835c:	0f 1f 40 00          	nopl   0x0(%rax)
    8360:	83 fa 13             	cmp    $0x13,%edx
    8363:	48 8d 05 41 6e 00 00 	lea    0x6e41(%rip),%rax        # f1ab <_IO_stdin_used+0x1ab>
    836a:	48 8d 35 3f 6e 00 00 	lea    0x6e3f(%rip),%rsi        # f1b0 <_IO_stdin_used+0x1b0>
    8371:	ba 04 00 00 00       	mov    $0x4,%edx
    8376:	48 0f 44 f0          	cmove  %rax,%rsi
    837a:	45 31 ed             	xor    %r13d,%r13d
    837d:	e8 8e be ff ff       	call   4210 <buf_put>
    8382:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8387:	0f 84 a3 08 00 00    	je     8c30 <fwp_write+0x9f0>
    838d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8392:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8397:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    839c:	48 89 df             	mov    %rbx,%rdi
    839f:	49 0f 44 c5          	cmove  %r13,%rax
    83a3:	31 c9                	xor    %ecx,%ecx
    83a5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    83aa:	e8 91 fe ff ff       	call   8240 <fwp_write>
    83af:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    83b4:	0f 84 6e 09 00 00    	je     8d28 <fwp_write+0xae8>
    83ba:	49 83 c5 01          	add    $0x1,%r13
    83be:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    83c2:	0f 83 68 08 00 00    	jae    8c30 <fwp_write+0x9f0>
    83c8:	ba 02 00 00 00       	mov    $0x2,%edx
    83cd:	48 8d 35 21 6e 00 00 	lea    0x6e21(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    83d4:	48 89 df             	mov    %rbx,%rdi
    83d7:	e8 34 be ff ff       	call   4210 <buf_put>
    83dc:	eb af                	jmp    838d <fwp_write+0x14d>
    83de:	66 90                	xchg   %ax,%ax
    83e0:	ba 06 00 00 00       	mov    $0x6,%edx
    83e5:	48 8d 35 e2 6d 00 00 	lea    0x6de2(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    83ec:	48 83 c5 10          	add    $0x10,%rbp
    83f0:	e8 1b be ff ff       	call   4210 <buf_put>
    83f5:	48 89 ef             	mov    %rbp,%rdi
    83f8:	e8 53 b0 ff ff       	call   3450 <strlen@plt>
    83fd:	48 89 ee             	mov    %rbp,%rsi
    8400:	48 89 df             	mov    %rbx,%rdi
    8403:	48 89 c2             	mov    %rax,%rdx
    8406:	e8 05 be ff ff       	call   4210 <buf_put>
    840b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8410:	ba 01 00 00 00       	mov    $0x1,%edx
    8415:	48 89 df             	mov    %rbx,%rdi
    8418:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    841d:	e8 ee bd ff ff       	call   4210 <buf_put>
    8422:	e9 af fe ff ff       	jmp    82d6 <fwp_write+0x96>
    8427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    842e:	00 00 
    8430:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8437:	00 
    8438:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    843f:	00 00 
    8441:	0f 85 ce 02 00 00    	jne    8715 <fwp_write+0x4d5>
    8447:	ba 0a 00 00 00       	mov    $0xa,%edx
    844c:	48 8d 35 67 6d 00 00 	lea    0x6d67(%rip),%rsi        # f1ba <_IO_stdin_used+0x1ba>
    8453:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    845a:	48 89 df             	mov    %rbx,%rdi
    845d:	5b                   	pop    %rbx
    845e:	5d                   	pop    %rbp
    845f:	41 5c                	pop    %r12
    8461:	41 5d                	pop    %r13
    8463:	41 5e                	pop    %r14
    8465:	41 5f                	pop    %r15
    8467:	e9 a4 bd ff ff       	jmp    4210 <buf_put>
    846c:	0f 1f 40 00          	nopl   0x0(%rax)
    8470:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8475:	4d 85 ed             	test   %r13,%r13
    8478:	0f 84 02 0c 00 00    	je     9080 <fwp_write+0xe40>
    847e:	48 8d 35 7d 6d 00 00 	lea    0x6d7d(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8485:	4c 89 ef             	mov    %r13,%rdi
    8488:	e8 a3 b0 ff ff       	call   3530 <strcmp@plt>
    848d:	41 89 c1             	mov    %eax,%r9d
    8490:	85 c0                	test   %eax,%eax
    8492:	0f 84 6c 0c 00 00    	je     9104 <fwp_write+0xec4>
    8498:	4c 89 ef             	mov    %r13,%rdi
    849b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    84a0:	e8 ab af ff ff       	call   3450 <strlen@plt>
    84a5:	4c 89 ee             	mov    %r13,%rsi
    84a8:	48 89 df             	mov    %rbx,%rdi
    84ab:	48 89 c2             	mov    %rax,%rdx
    84ae:	e8 5d bd ff ff       	call   4210 <buf_put>
    84b3:	ba 01 00 00 00       	mov    $0x1,%edx
    84b8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    84bd:	48 89 df             	mov    %rbx,%rdi
    84c0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    84c5:	e8 46 bd ff ff       	call   4210 <buf_put>
    84ca:	ba 01 00 00 00       	mov    $0x1,%edx
    84cf:	4c 89 fe             	mov    %r15,%rsi
    84d2:	48 89 df             	mov    %rbx,%rdi
    84d5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    84da:	e8 31 bd ff ff       	call   4210 <buf_put>
    84df:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    84e4:	45 31 f6             	xor    %r14d,%r14d
    84e7:	85 d2                	test   %edx,%edx
    84e9:	0f 8e 81 0a 00 00    	jle    8f70 <fwp_write+0xd30>
    84ef:	45 31 ed             	xor    %r13d,%r13d
    84f2:	4d 85 ed             	test   %r13,%r13
    84f5:	0f 85 75 07 00 00    	jne    8c70 <fwp_write+0xa30>
    84fb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8502:	00 
    8503:	45 85 f6             	test   %r14d,%r14d
    8506:	0f 84 84 07 00 00    	je     8c90 <fwp_write+0xa50>
    850c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8511:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8516:	48 89 df             	mov    %rbx,%rdi
    8519:	49 83 c5 01          	add    $0x1,%r13
    851d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8521:	31 c9                	xor    %ecx,%ecx
    8523:	e8 18 fd ff ff       	call   8240 <fwp_write>
    8528:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    852d:	7f c3                	jg     84f2 <fwp_write+0x2b2>
    852f:	45 85 f6             	test   %r14d,%r14d
    8532:	0f 84 38 0a 00 00    	je     8f70 <fwp_write+0xd30>
    8538:	b8 29 00 00 00       	mov    $0x29,%eax
    853d:	ba 01 00 00 00       	mov    $0x1,%edx
    8542:	4c 89 fe             	mov    %r15,%rsi
    8545:	48 89 df             	mov    %rbx,%rdi
    8548:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    854c:	e8 bf bc ff ff       	call   4210 <buf_put>
    8551:	e9 80 fd ff ff       	jmp    82d6 <fwp_write+0x96>
    8556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    855d:	00 00 00 
    8560:	ba 01 00 00 00       	mov    $0x1,%edx
    8565:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    856a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    856f:	e8 9c bc ff ff       	call   4210 <buf_put>
    8574:	48 85 ed             	test   %rbp,%rbp
    8577:	0f 84 93 06 00 00    	je     8c10 <fwp_write+0x9d0>
    857d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8581:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8586:	31 c9                	xor    %ecx,%ecx
    8588:	48 89 df             	mov    %rbx,%rdi
    858b:	e8 b0 fc ff ff       	call   8240 <fwp_write>
    8590:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8594:	48 85 ed             	test   %rbp,%rbp
    8597:	0f 84 73 06 00 00    	je     8c10 <fwp_write+0x9d0>
    859d:	ba 02 00 00 00       	mov    $0x2,%edx
    85a2:	48 8d 35 4c 6c 00 00 	lea    0x6c4c(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    85a9:	48 89 df             	mov    %rbx,%rdi
    85ac:	e8 5f bc ff ff       	call   4210 <buf_put>
    85b1:	eb ca                	jmp    857d <fwp_write+0x33d>
    85b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    85b8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    85bc:	85 f6                	test   %esi,%esi
    85be:	0f 84 fc 07 00 00    	je     8dc0 <fwp_write+0xb80>
    85c4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    85cb:	00 
    85cc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    85d3:	00 00 
    85d5:	0f 85 3a 01 00 00    	jne    8715 <fwp_write+0x4d5>
    85db:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    85df:	4c 89 ea             	mov    %r13,%rdx
    85e2:	e9 6c fe ff ff       	jmp    8453 <fwp_write+0x213>
    85e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85ee:	00 00 
    85f0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    85f5:	ba 01 00 00 00       	mov    $0x1,%edx
    85fa:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    85ff:	48 89 ee             	mov    %rbp,%rsi
    8602:	e8 09 bc ff ff       	call   4210 <buf_put>
    8607:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    860c:	4c 89 e7             	mov    %r12,%rdi
    860f:	e8 3c ae ff ff       	call   3450 <strlen@plt>
    8614:	4c 89 e6             	mov    %r12,%rsi
    8617:	48 89 df             	mov    %rbx,%rdi
    861a:	48 89 c2             	mov    %rax,%rdx
    861d:	e8 ee bb ff ff       	call   4210 <buf_put>
    8622:	ba 01 00 00 00       	mov    $0x1,%edx
    8627:	48 89 ee             	mov    %rbp,%rsi
    862a:	48 89 df             	mov    %rbx,%rdi
    862d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8632:	e8 d9 bb ff ff       	call   4210 <buf_put>
    8637:	e9 9a fc ff ff       	jmp    82d6 <fwp_write+0x96>
    863c:	0f 1f 40 00          	nopl   0x0(%rax)
    8640:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8645:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8649:	0f 8a 8e 0b 00 00    	jp     91dd <fwp_write+0xf9d>
    864f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8653:	66 0f 54 05 d5 75 00 	andpd  0x75d5(%rip),%xmm0        # fc30 <msg.4+0xc0>
    865a:	00 
    865b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8660:	66 0f 2e 05 40 75 00 	ucomisd 0x7540(%rip),%xmm0        # fba8 <msg.4+0x38>
    8667:	00 
    8668:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    866f:	00 
    8670:	0f 87 b2 09 00 00    	ja     9028 <fwp_write+0xde8>
    8676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    867d:	00 00 00 
    8680:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8684:	89 ee                	mov    %ebp,%esi
    8686:	4c 89 e7             	mov    %r12,%rdi
    8689:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    868e:	e8 7d c0 ff ff       	call   4710 <fwp_format_g.constprop.0>
    8693:	31 f6                	xor    %esi,%esi
    8695:	4c 89 e7             	mov    %r12,%rdi
    8698:	e8 73 ad ff ff       	call   3410 <strtod@plt>
    869d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    86a2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    86a6:	7a 06                	jp     86ae <fwp_write+0x46e>
    86a8:	0f 84 e9 01 00 00    	je     8897 <fwp_write+0x657>
    86ae:	83 c5 01             	add    $0x1,%ebp
    86b1:	83 fd 12             	cmp    $0x12,%ebp
    86b4:	75 ca                	jne    8680 <fwp_write+0x440>
    86b6:	be 11 00 00 00       	mov    $0x11,%esi
    86bb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    86bf:	4c 89 e7             	mov    %r12,%rdi
    86c2:	e8 49 c0 ff ff       	call   4710 <fwp_format_g.constprop.0>
    86c7:	e9 cb 01 00 00       	jmp    8897 <fwp_write+0x657>
    86cc:	0f 1f 40 00          	nopl   0x0(%rax)
    86d0:	48 83 fd 01          	cmp    $0x1,%rbp
    86d4:	0f 84 e6 08 00 00    	je     8fc0 <fwp_write+0xd80>
    86da:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    86de:	b8 02 00 00 00       	mov    $0x2,%eax
    86e3:	ba 01 00 00 00       	mov    $0x1,%edx
    86e8:	48 0f 44 d0          	cmove  %rax,%rdx
    86ec:	48 8d 35 b0 6a 00 00 	lea    0x6ab0(%rip),%rsi        # f1a3 <_IO_stdin_used+0x1a3>
    86f3:	48 8d 05 ae 6a 00 00 	lea    0x6aae(%rip),%rax        # f1a8 <_IO_stdin_used+0x1a8>
    86fa:	48 0f 44 f0          	cmove  %rax,%rsi
    86fe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8705:	00 
    8706:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    870d:	00 00 
    870f:	0f 84 3e fd ff ff    	je     8453 <fwp_write+0x213>
    8715:	e8 46 ad ff ff       	call   3460 <__stack_chk_fail@plt>
    871a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8720:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8725:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    872a:	e8 21 ba ff ff       	call   4150 <buf_grow>
    872f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8733:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8739:	4c 03 0b             	add    (%rbx),%r9
    873c:	66 45 89 11          	mov    %r10w,(%r9)
    8740:	45 85 e4             	test   %r12d,%r12d
    8743:	0f 8e 07 05 00 00    	jle    8c50 <fwp_write+0xa10>
    8749:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8750:	55 55 55 
    8753:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8758:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    875f:	aa aa aa 
    8762:	49 83 c1 01          	add    $0x1,%r9
    8766:	eb 45                	jmp    87ad <fwp_write+0x56d>
    8768:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    876f:	00 
    8770:	be 01 00 00 00       	mov    $0x1,%esi
    8775:	b8 2d 00 00 00       	mov    $0x2d,%eax
    877a:	88 07                	mov    %al,(%rdi)
    877c:	48 89 e8             	mov    %rbp,%rax
    877f:	49 f7 e8             	imul   %r8
    8782:	48 89 e8             	mov    %rbp,%rax
    8785:	48 c1 f8 3f          	sar    $0x3f,%rax
    8789:	48 29 c2             	sub    %rax,%rdx
    878c:	48 85 c9             	test   %rcx,%rcx
    878f:	0f 95 c0             	setne  %al
    8792:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8796:	48 83 ef 01          	sub    $0x1,%rdi
    879a:	48 21 c5             	and    %rax,%rbp
    879d:	48 29 ea             	sub    %rbp,%rdx
    87a0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    87a4:	49 39 f9             	cmp    %rdi,%r9
    87a7:	0f 84 a3 04 00 00    	je     8c50 <fwp_write+0xa10>
    87ad:	48 89 e8             	mov    %rbp,%rax
    87b0:	49 f7 e8             	imul   %r8
    87b3:	48 89 e8             	mov    %rbp,%rax
    87b6:	48 c1 f8 3f          	sar    $0x3f,%rax
    87ba:	48 89 d1             	mov    %rdx,%rcx
    87bd:	48 29 c1             	sub    %rax,%rcx
    87c0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    87c4:	48 89 e9             	mov    %rbp,%rcx
    87c7:	48 29 c1             	sub    %rax,%rcx
    87ca:	48 8d 41 03          	lea    0x3(%rcx),%rax
    87ce:	49 f7 e2             	mul    %r10
    87d1:	b8 30 00 00 00       	mov    $0x30,%eax
    87d6:	48 89 d6             	mov    %rdx,%rsi
    87d9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    87dd:	48 d1 ee             	shr    $1,%rsi
    87e0:	48 01 f2             	add    %rsi,%rdx
    87e3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    87e7:	48 29 d6             	sub    %rdx,%rsi
    87ea:	74 8e                	je     877a <fwp_write+0x53a>
    87ec:	48 83 fe 01          	cmp    $0x1,%rsi
    87f0:	0f 85 7a ff ff ff    	jne    8770 <fwp_write+0x530>
    87f6:	31 f6                	xor    %esi,%esi
    87f8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    87fd:	e9 78 ff ff ff       	jmp    877a <fwp_write+0x53a>
    8802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8808:	66 0f 6e cd          	movd   %ebp,%xmm1
    880c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    880f:	0f 8a c8 09 00 00    	jp     91dd <fwp_write+0xf9d>
    8815:	0f 28 c1             	movaps %xmm1,%xmm0
    8818:	0f 54 05 01 74 00 00 	andps  0x7401(%rip),%xmm0        # fc20 <msg.4+0xb0>
    881f:	0f 2e 05 de 67 00 00 	ucomiss 0x67de(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8826:	0f 87 24 08 00 00    	ja     9050 <fwp_write+0xe10>
    882c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8830:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8836:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    883d:	00 
    883e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8842:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    884e:	00 00 
    8850:	44 89 ee             	mov    %r13d,%esi
    8853:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8858:	4c 89 e7             	mov    %r12,%rdi
    885b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8860:	e8 ab be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8865:	31 f6                	xor    %esi,%esi
    8867:	4c 89 e7             	mov    %r12,%rdi
    886a:	e8 41 ac ff ff       	call   34b0 <strtof@plt>
    886f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8874:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8877:	7a 02                	jp     887b <fwp_write+0x63b>
    8879:	74 1c                	je     8897 <fwp_write+0x657>
    887b:	41 83 c5 01          	add    $0x1,%r13d
    887f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8883:	75 cb                	jne    8850 <fwp_write+0x610>
    8885:	be 09 00 00 00       	mov    $0x9,%esi
    888a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    888f:	4c 89 e7             	mov    %r12,%rdi
    8892:	e8 79 be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8897:	4c 89 e7             	mov    %r12,%rdi
    889a:	e8 e1 ba ff ff       	call   4380 <fwp_finish_float>
    889f:	e9 1c fa ff ff       	jmp    82c0 <fwp_write+0x80>
    88a4:	0f 1f 40 00          	nopl   0x0(%rax)
    88a8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    88ac:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    88b0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    88b7:	00 
    88b8:	48 89 ef             	mov    %rbp,%rdi
    88bb:	e8 80 b1 ff ff       	call   3a40 <fwp_fmt_u128>
    88c0:	48 89 ef             	mov    %rbp,%rdi
    88c3:	e8 88 ab ff ff       	call   3450 <strlen@plt>
    88c8:	48 89 ee             	mov    %rbp,%rsi
    88cb:	48 89 df             	mov    %rbx,%rdi
    88ce:	48 89 c2             	mov    %rax,%rdx
    88d1:	e8 3a b9 ff ff       	call   4210 <buf_put>
    88d6:	e9 fb f9 ff ff       	jmp    82d6 <fwp_write+0x96>
    88db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    88e0:	ba 06 00 00 00       	mov    $0x6,%edx
    88e5:	48 8d 35 0c 69 00 00 	lea    0x690c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    88ec:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    88f2:	e8 19 b9 ff ff       	call   4210 <buf_put>
    88f7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    88fe:	ff ff 7f 
    8901:	48 23 55 00          	and    0x0(%rbp),%rdx
    8905:	0f 84 86 02 00 00    	je     8b91 <fwp_write+0x951>
    890b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8910:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8914:	48 85 d2             	test   %rdx,%rdx
    8917:	0f 84 ae 00 00 00    	je     89cb <fwp_write+0x78b>
    891d:	8b 0a                	mov    (%rdx),%ecx
    891f:	83 f9 1c             	cmp    $0x1c,%ecx
    8922:	0f 84 58 06 00 00    	je     8f80 <fwp_write+0xd40>
    8928:	83 f9 1b             	cmp    $0x1b,%ecx
    892b:	0f 87 9a 00 00 00    	ja     89cb <fwp_write+0x78b>
    8931:	be 01 00 00 00       	mov    $0x1,%esi
    8936:	48 d3 e6             	shl    %cl,%rsi
    8939:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    893f:	0f 85 4b 04 00 00    	jne    8d90 <fwp_write+0xb50>
    8945:	f7 c6 84 04 00 00    	test   $0x484,%esi
    894b:	0f 85 0f 04 00 00    	jne    8d60 <fwp_write+0xb20>
    8951:	83 e6 21             	and    $0x21,%esi
    8954:	74 75                	je     89cb <fwp_write+0x78b>
    8956:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    895b:	48 85 ff             	test   %rdi,%rdi
    895e:	79 07                	jns    8967 <fwp_write+0x727>
    8960:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8964:	4c 01 ee             	add    %r13,%rsi
    8967:	48 0f be 3e          	movsbq (%rsi),%rdi
    896b:	85 c9                	test   %ecx,%ecx
    896d:	40 0f b6 f7          	movzbl %dil,%esi
    8971:	48 0f 44 f7          	cmove  %rdi,%rsi
    8975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    897c:	00 00 00 00 
    8980:	31 c9                	xor    %ecx,%ecx
    8982:	48 89 df             	mov    %rbx,%rdi
    8985:	49 83 c5 01          	add    $0x1,%r13
    8989:	e8 b2 f8 ff ff       	call   8240 <fwp_write>
    898e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8995:	ff ff 7f 
    8998:	48 23 55 00          	and    0x0(%rbp),%rdx
    899c:	49 39 d5             	cmp    %rdx,%r13
    899f:	0f 83 ec 01 00 00    	jae    8b91 <fwp_write+0x951>
    89a5:	ba 02 00 00 00       	mov    $0x2,%edx
    89aa:	48 89 df             	mov    %rbx,%rdi
    89ad:	48 8d 35 41 68 00 00 	lea    0x6841(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    89b4:	e8 57 b8 ff ff       	call   4210 <buf_put>
    89b9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    89be:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    89c2:	48 85 d2             	test   %rdx,%rdx
    89c5:	0f 85 52 ff ff ff    	jne    891d <fwp_write+0x6dd>
    89cb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    89d0:	48 85 ff             	test   %rdi,%rdi
    89d3:	0f 88 cf 05 00 00    	js     8fa8 <fwp_write+0xd68>
    89d9:	48 8b 31             	mov    (%rcx),%rsi
    89dc:	eb a2                	jmp    8980 <fwp_write+0x740>
    89de:	66 90                	xchg   %ax,%ax
    89e0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    89e7:	00 
    89e8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89ef:	00 00 
    89f1:	0f 85 1e fd ff ff    	jne    8715 <fwp_write+0x4d5>
    89f7:	ba 08 00 00 00       	mov    $0x8,%edx
    89fc:	48 8d 35 c2 67 00 00 	lea    0x67c2(%rip),%rsi        # f1c5 <_IO_stdin_used+0x1c5>
    8a03:	e9 4b fa ff ff       	jmp    8453 <fwp_write+0x213>
    8a08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8a0f:	00 
    8a10:	89 e8                	mov    %ebp,%eax
    8a12:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8a19:	76 03                	jbe    8a1e <fwp_write+0x7de>
    8a1b:	8b 45 00             	mov    0x0(%rbp),%eax
    8a1e:	41 89 c6             	mov    %eax,%r14d
    8a21:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8a26:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8a2b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8a2f:	4c 89 ef             	mov    %r13,%rdi
    8a32:	e8 19 aa ff ff       	call   3450 <strlen@plt>
    8a37:	4c 89 ee             	mov    %r13,%rsi
    8a3a:	48 89 df             	mov    %rbx,%rdi
    8a3d:	48 89 c2             	mov    %rax,%rdx
    8a40:	e8 cb b7 ff ff       	call   4210 <buf_put>
    8a45:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8a4a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8a4e:	85 f6                	test   %esi,%esi
    8a50:	0f 8e 80 f8 ff ff    	jle    82d6 <fwp_write+0x96>
    8a56:	45 31 ed             	xor    %r13d,%r13d
    8a59:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8a5e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8a63:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8a68:	ba 01 00 00 00       	mov    $0x1,%edx
    8a6d:	4c 89 fe             	mov    %r15,%rsi
    8a70:	48 89 04 24          	mov    %rax,(%rsp)
    8a74:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8a79:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8a7d:	48 89 df             	mov    %rbx,%rdi
    8a80:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8a84:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8a89:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8a8e:	e8 7d b7 ff ff       	call   4210 <buf_put>
    8a93:	41 8b 06             	mov    (%r14),%eax
    8a96:	83 f8 0e             	cmp    $0xe,%eax
    8a99:	0f 84 71 02 00 00    	je     8d10 <fwp_write+0xad0>
    8a9f:	83 f8 10             	cmp    $0x10,%eax
    8aa2:	0f 84 38 02 00 00    	je     8ce0 <fwp_write+0xaa0>
    8aa8:	83 f8 0a             	cmp    $0xa,%eax
    8aab:	0f 84 7f 04 00 00    	je     8f30 <fwp_write+0xcf0>
    8ab1:	0f 8f f9 00 00 00    	jg     8bb0 <fwp_write+0x970>
    8ab7:	83 f8 03             	cmp    $0x3,%eax
    8aba:	0f 8f 50 04 00 00    	jg     8f10 <fwp_write+0xcd0>
    8ac0:	85 c0                	test   %eax,%eax
    8ac2:	78 10                	js     8ad4 <fwp_write+0x894>
    8ac4:	48 8b 04 24          	mov    (%rsp),%rax
    8ac8:	48 c1 e8 3f          	shr    $0x3f,%rax
    8acc:	85 c0                	test   %eax,%eax
    8ace:	0f 85 f9 00 00 00    	jne    8bcd <fwp_write+0x98d>
    8ad4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8ad9:	48 8b 34 24          	mov    (%rsp),%rsi
    8add:	31 c9                	xor    %ecx,%ecx
    8adf:	48 89 df             	mov    %rbx,%rdi
    8ae2:	e8 59 f7 ff ff       	call   8240 <fwp_write>
    8ae7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8aec:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8af1:	49 83 c5 01          	add    $0x1,%r13
    8af5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8af9:	0f 8f 5f ff ff ff    	jg     8a5e <fwp_write+0x81e>
    8aff:	e9 d2 f7 ff ff       	jmp    82d6 <fwp_write+0x96>
    8b04:	0f 1f 40 00          	nopl   0x0(%rax)
    8b08:	ba 06 00 00 00       	mov    $0x6,%edx
    8b0d:	48 8d 35 d7 66 00 00 	lea    0x66d7(%rip),%rsi        # f1eb <_IO_stdin_used+0x1eb>
    8b14:	45 31 ed             	xor    %r13d,%r13d
    8b17:	e8 f4 b6 ff ff       	call   4210 <buf_put>
    8b1c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8b21:	75 19                	jne    8b3c <fwp_write+0x8fc>
    8b23:	eb 6c                	jmp    8b91 <fwp_write+0x951>
    8b25:	0f 1f 00             	nopl   (%rax)
    8b28:	ba 02 00 00 00       	mov    $0x2,%edx
    8b2d:	48 8d 35 c1 66 00 00 	lea    0x66c1(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8b34:	48 89 df             	mov    %rbx,%rdi
    8b37:	e8 d4 b6 ff ff       	call   4210 <buf_put>
    8b3c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8b42:	b9 00 02 00 00       	mov    $0x200,%ecx
    8b47:	31 c0                	xor    %eax,%eax
    8b49:	49 83 c5 01          	add    $0x1,%r13
    8b4d:	4c 8d 05 9e 66 00 00 	lea    0x669e(%rip),%r8        # f1f2 <_IO_stdin_used+0x1f2>
    8b54:	ba 02 00 00 00       	mov    $0x2,%edx
    8b59:	be 00 02 00 00       	mov    $0x200,%esi
    8b5e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b65:	00 
    8b66:	e8 45 a8 ff ff       	call   33b0 <__snprintf_chk@plt>
    8b6b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b72:	00 
    8b73:	e8 d8 a8 ff ff       	call   3450 <strlen@plt>
    8b78:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8b7f:	00 
    8b80:	48 89 df             	mov    %rbx,%rdi
    8b83:	48 89 c2             	mov    %rax,%rdx
    8b86:	e8 85 b6 ff ff       	call   4210 <buf_put>
    8b8b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8b8f:	72 97                	jb     8b28 <fwp_write+0x8e8>
    8b91:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b96:	ba 01 00 00 00       	mov    $0x1,%edx
    8b9b:	48 89 df             	mov    %rbx,%rdi
    8b9e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8ba3:	e8 68 b6 ff ff       	call   4210 <buf_put>
    8ba8:	e9 29 f7 ff ff       	jmp    82d6 <fwp_write+0x96>
    8bad:	0f 1f 00             	nopl   (%rax)
    8bb0:	83 f8 0b             	cmp    $0xb,%eax
    8bb3:	0f 85 1b ff ff ff    	jne    8ad4 <fwp_write+0x894>
    8bb9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8bbe:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8bc2:	83 e0 01             	and    $0x1,%eax
    8bc5:	85 c0                	test   %eax,%eax
    8bc7:	0f 84 07 ff ff ff    	je     8ad4 <fwp_write+0x894>
    8bcd:	4c 89 fe             	mov    %r15,%rsi
    8bd0:	48 89 df             	mov    %rbx,%rdi
    8bd3:	ba 01 00 00 00       	mov    $0x1,%edx
    8bd8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8bdd:	e8 2e b6 ff ff       	call   4210 <buf_put>
    8be2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8be7:	48 8b 34 24          	mov    (%rsp),%rsi
    8beb:	31 c9                	xor    %ecx,%ecx
    8bed:	48 89 df             	mov    %rbx,%rdi
    8bf0:	e8 4b f6 ff ff       	call   8240 <fwp_write>
    8bf5:	ba 01 00 00 00       	mov    $0x1,%edx
    8bfa:	4c 89 fe             	mov    %r15,%rsi
    8bfd:	48 89 df             	mov    %rbx,%rdi
    8c00:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8c05:	e8 06 b6 ff ff       	call   4210 <buf_put>
    8c0a:	e9 d8 fe ff ff       	jmp    8ae7 <fwp_write+0x8a7>
    8c0f:	90                   	nop
    8c10:	ba 01 00 00 00       	mov    $0x1,%edx
    8c15:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8c1a:	48 89 df             	mov    %rbx,%rdi
    8c1d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8c22:	e8 e9 b5 ff ff       	call   4210 <buf_put>
    8c27:	e9 aa f6 ff ff       	jmp    82d6 <fwp_write+0x96>
    8c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c30:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8c35:	ba 01 00 00 00       	mov    $0x1,%edx
    8c3a:	48 89 df             	mov    %rbx,%rdi
    8c3d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8c42:	e8 c9 b5 ff ff       	call   4210 <buf_put>
    8c47:	e9 8a f6 ff ff       	jmp    82d6 <fwp_write+0x96>
    8c4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c50:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8c54:	48 8b 13             	mov    (%rbx),%rdx
    8c57:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8c5c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8c60:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8c64:	e9 6d f6 ff ff       	jmp    82d6 <fwp_write+0x96>
    8c69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c70:	ba 02 00 00 00       	mov    $0x2,%edx
    8c75:	48 8d 35 79 65 00 00 	lea    0x6579(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8c7c:	48 89 df             	mov    %rbx,%rdi
    8c7f:	e8 8c b5 ff ff       	call   4210 <buf_put>
    8c84:	e9 72 f8 ff ff       	jmp    84fb <fwp_write+0x2bb>
    8c89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c90:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8c95:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8c9a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8c9e:	48 89 f7             	mov    %rsi,%rdi
    8ca1:	48 89 34 24          	mov    %rsi,(%rsp)
    8ca5:	e8 a6 a7 ff ff       	call   3450 <strlen@plt>
    8caa:	48 8b 34 24          	mov    (%rsp),%rsi
    8cae:	48 89 df             	mov    %rbx,%rdi
    8cb1:	48 89 c2             	mov    %rax,%rdx
    8cb4:	e8 57 b5 ff ff       	call   4210 <buf_put>
    8cb9:	ba 03 00 00 00       	mov    $0x3,%edx
    8cbe:	48 8d 35 53 65 00 00 	lea    0x6553(%rip),%rsi        # f218 <_IO_stdin_used+0x218>
    8cc5:	48 89 df             	mov    %rbx,%rdi
    8cc8:	e8 43 b5 ff ff       	call   4210 <buf_put>
    8ccd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8cd2:	e9 35 f8 ff ff       	jmp    850c <fwp_write+0x2cc>
    8cd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cde:	00 00 
    8ce0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8ce5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8ce9:	48 85 ff             	test   %rdi,%rdi
    8cec:	0f 84 e2 fd ff ff    	je     8ad4 <fwp_write+0x894>
    8cf2:	48 8d 35 09 65 00 00 	lea    0x6509(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8cf9:	e8 32 a8 ff ff       	call   3530 <strcmp@plt>
    8cfe:	85 c0                	test   %eax,%eax
    8d00:	0f 95 c0             	setne  %al
    8d03:	0f b6 c0             	movzbl %al,%eax
    8d06:	e9 c1 fd ff ff       	jmp    8acc <fwp_write+0x88c>
    8d0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8d10:	31 c0                	xor    %eax,%eax
    8d12:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8d19:	00 
    8d1a:	0f 97 c0             	seta   %al
    8d1d:	e9 aa fd ff ff       	jmp    8acc <fwp_write+0x88c>
    8d22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d28:	48 89 df             	mov    %rbx,%rdi
    8d2b:	ba 02 00 00 00       	mov    $0x2,%edx
    8d30:	48 8d 35 c8 64 00 00 	lea    0x64c8(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    8d37:	e8 d4 b4 ff ff       	call   4210 <buf_put>
    8d3c:	4c 89 e8             	mov    %r13,%rax
    8d3f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8d44:	31 c9                	xor    %ecx,%ecx
    8d46:	48 c1 e0 04          	shl    $0x4,%rax
    8d4a:	48 89 df             	mov    %rbx,%rdi
    8d4d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8d52:	e8 e9 f4 ff ff       	call   8240 <fwp_write>
    8d57:	e9 5e f6 ff ff       	jmp    83ba <fwp_write+0x17a>
    8d5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d60:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8d65:	48 85 ff             	test   %rdi,%rdi
    8d68:	79 0c                	jns    8d76 <fwp_write+0xb36>
    8d6a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8d71:	00 
    8d72:	48 03 75 10          	add    0x10(%rbp),%rsi
    8d76:	48 63 3e             	movslq (%rsi),%rdi
    8d79:	83 f9 02             	cmp    $0x2,%ecx
    8d7c:	89 fe                	mov    %edi,%esi
    8d7e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d82:	e9 f9 fb ff ff       	jmp    8980 <fwp_write+0x740>
    8d87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d8e:	00 00 
    8d90:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8d95:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8d9a:	48 85 ff             	test   %rdi,%rdi
    8d9d:	0f 88 0f 03 00 00    	js     90b2 <fwp_write+0xe72>
    8da3:	49 0f bf 38          	movswq (%r8),%rdi
    8da7:	83 f9 01             	cmp    $0x1,%ecx
    8daa:	0f b7 f7             	movzwl %di,%esi
    8dad:	48 0f 44 f7          	cmove  %rdi,%rsi
    8db1:	e9 ca fb ff ff       	jmp    8980 <fwp_write+0x740>
    8db6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8dbd:	00 00 00 
    8dc0:	ba 01 00 00 00       	mov    $0x1,%edx
    8dc5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8dca:	48 83 c5 08          	add    $0x8,%rbp
    8dce:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8dd3:	e8 38 b4 ff ff       	call   4210 <buf_put>
    8dd8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8ddd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8de2:	4d 85 ed             	test   %r13,%r13
    8de5:	75 46                	jne    8e2d <fwp_write+0xbed>
    8de7:	e9 04 01 00 00       	jmp    8ef0 <fwp_write+0xcb0>
    8dec:	0f 1f 40 00          	nopl   0x0(%rax)
    8df0:	41 80 f9 09          	cmp    $0x9,%r9b
    8df4:	0f 84 d6 00 00 00    	je     8ed0 <fwp_write+0xc90>
    8dfa:	41 80 f9 0a          	cmp    $0xa,%r9b
    8dfe:	0f 85 9c 00 00 00    	jne    8ea0 <fwp_write+0xc60>
    8e04:	ba 02 00 00 00       	mov    $0x2,%edx
    8e09:	48 8d 35 cb 63 00 00 	lea    0x63cb(%rip),%rsi        # f1db <_IO_stdin_used+0x1db>
    8e10:	48 89 df             	mov    %rbx,%rdi
    8e13:	e8 f8 b3 ff ff       	call   4210 <buf_put>
    8e18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e1f:	00 
    8e20:	48 83 c5 01          	add    $0x1,%rbp
    8e24:	49 39 ec             	cmp    %rbp,%r12
    8e27:	0f 84 c3 00 00 00    	je     8ef0 <fwp_write+0xcb0>
    8e2d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8e32:	41 80 f9 0d          	cmp    $0xd,%r9b
    8e36:	74 28                	je     8e60 <fwp_write+0xc20>
    8e38:	7e b6                	jle    8df0 <fwp_write+0xbb0>
    8e3a:	41 80 f9 22          	cmp    $0x22,%r9b
    8e3e:	74 40                	je     8e80 <fwp_write+0xc40>
    8e40:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8e44:	75 5a                	jne    8ea0 <fwp_write+0xc60>
    8e46:	ba 02 00 00 00       	mov    $0x2,%edx
    8e4b:	48 8d 35 86 63 00 00 	lea    0x6386(%rip),%rsi        # f1d8 <_IO_stdin_used+0x1d8>
    8e52:	48 89 df             	mov    %rbx,%rdi
    8e55:	e8 b6 b3 ff ff       	call   4210 <buf_put>
    8e5a:	eb c4                	jmp    8e20 <fwp_write+0xbe0>
    8e5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e60:	ba 02 00 00 00       	mov    $0x2,%edx
    8e65:	48 8d 35 75 63 00 00 	lea    0x6375(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    8e6c:	48 89 df             	mov    %rbx,%rdi
    8e6f:	e8 9c b3 ff ff       	call   4210 <buf_put>
    8e74:	eb aa                	jmp    8e20 <fwp_write+0xbe0>
    8e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e7d:	00 00 00 
    8e80:	ba 02 00 00 00       	mov    $0x2,%edx
    8e85:	48 8d 35 49 63 00 00 	lea    0x6349(%rip),%rsi        # f1d5 <_IO_stdin_used+0x1d5>
    8e8c:	48 89 df             	mov    %rbx,%rdi
    8e8f:	e8 7c b3 ff ff       	call   4210 <buf_put>
    8e94:	eb 8a                	jmp    8e20 <fwp_write+0xbe0>
    8e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e9d:	00 00 00 
    8ea0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8ea4:	0f 86 2e 01 00 00    	jbe    8fd8 <fwp_write+0xd98>
    8eaa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8eae:	0f 84 24 01 00 00    	je     8fd8 <fwp_write+0xd98>
    8eb4:	ba 01 00 00 00       	mov    $0x1,%edx
    8eb9:	4c 89 fe             	mov    %r15,%rsi
    8ebc:	48 89 df             	mov    %rbx,%rdi
    8ebf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8ec4:	e8 47 b3 ff ff       	call   4210 <buf_put>
    8ec9:	e9 52 ff ff ff       	jmp    8e20 <fwp_write+0xbe0>
    8ece:	66 90                	xchg   %ax,%ax
    8ed0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ed5:	48 8d 35 02 63 00 00 	lea    0x6302(%rip),%rsi        # f1de <_IO_stdin_used+0x1de>
    8edc:	48 89 df             	mov    %rbx,%rdi
    8edf:	e8 2c b3 ff ff       	call   4210 <buf_put>
    8ee4:	e9 37 ff ff ff       	jmp    8e20 <fwp_write+0xbe0>
    8ee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ef0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ef5:	4c 89 fe             	mov    %r15,%rsi
    8ef8:	48 89 df             	mov    %rbx,%rdi
    8efb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8f00:	e8 0b b3 ff ff       	call   4210 <buf_put>
    8f05:	e9 cc f3 ff ff       	jmp    82d6 <fwp_write+0x96>
    8f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f10:	83 f8 04             	cmp    $0x4,%eax
    8f13:	0f 85 bb fb ff ff    	jne    8ad4 <fwp_write+0x894>
    8f19:	48 8b 04 24          	mov    (%rsp),%rax
    8f1d:	48 8b 40 08          	mov    0x8(%rax),%rax
    8f21:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8f26:	48 c1 e8 3f          	shr    $0x3f,%rax
    8f2a:	e9 96 fc ff ff       	jmp    8bc5 <fwp_write+0x985>
    8f2f:	90                   	nop
    8f30:	8b 0c 24             	mov    (%rsp),%ecx
    8f33:	31 c0                	xor    %eax,%eax
    8f35:	85 c9                	test   %ecx,%ecx
    8f37:	0f 98 c0             	sets   %al
    8f3a:	e9 86 fc ff ff       	jmp    8bc5 <fwp_write+0x985>
    8f3f:	90                   	nop
    8f40:	48 f7 d8             	neg    %rax
    8f43:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8f4a:	00 
    8f4b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8f52:	2d 
    8f53:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f5a:	00 
    8f5b:	48 83 d2 00          	adc    $0x0,%rdx
    8f5f:	48 89 c6             	mov    %rax,%rsi
    8f62:	48 f7 da             	neg    %rdx
    8f65:	e8 d6 aa ff ff       	call   3a40 <fwp_fmt_u128>
    8f6a:	e9 51 f3 ff ff       	jmp    82c0 <fwp_write+0x80>
    8f6f:	90                   	nop
    8f70:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8f75:	e9 c3 f5 ff ff       	jmp    853d <fwp_write+0x2fd>
    8f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f80:	4c 89 e9             	mov    %r13,%rcx
    8f83:	48 c1 e1 04          	shl    $0x4,%rcx
    8f87:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8f8c:	48 85 ff             	test   %rdi,%rdi
    8f8f:	0f 89 eb f9 ff ff    	jns    8980 <fwp_write+0x740>
    8f95:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f99:	48 89 ce             	mov    %rcx,%rsi
    8f9c:	e9 df f9 ff ff       	jmp    8980 <fwp_write+0x740>
    8fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fa8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8faf:	00 
    8fb0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8fb4:	e9 20 fa ff ff       	jmp    89d9 <fwp_write+0x799>
    8fb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fc0:	ba 02 00 00 00       	mov    $0x2,%edx
    8fc5:	48 8d 35 d9 61 00 00 	lea    0x61d9(%rip),%rsi        # f1a5 <_IO_stdin_used+0x1a5>
    8fcc:	e9 2d f7 ff ff       	jmp    86fe <fwp_write+0x4be>
    8fd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fd8:	4c 8d 05 05 62 00 00 	lea    0x6205(%rip),%r8        # f1e4 <_IO_stdin_used+0x1e4>
    8fdf:	b9 10 00 00 00       	mov    $0x10,%ecx
    8fe4:	31 c0                	xor    %eax,%eax
    8fe6:	ba 02 00 00 00       	mov    $0x2,%edx
    8feb:	be 10 00 00 00       	mov    $0x10,%esi
    8ff0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ff7:	00 
    8ff8:	e8 b3 a3 ff ff       	call   33b0 <__snprintf_chk@plt>
    8ffd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9004:	00 
    9005:	e8 46 a4 ff ff       	call   3450 <strlen@plt>
    900a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9011:	00 
    9012:	48 89 df             	mov    %rbx,%rdi
    9015:	48 89 c2             	mov    %rax,%rdx
    9018:	e8 f3 b1 ff ff       	call   4210 <buf_put>
    901d:	e9 fe fd ff ff       	jmp    8e20 <fwp_write+0xbe0>
    9022:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9028:	66 0f ef c0          	pxor   %xmm0,%xmm0
    902c:	48 8d 35 6c 61 00 00 	lea    0x616c(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    9033:	48 8d 05 64 61 00 00 	lea    0x6164(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    903a:	4c 89 e7             	mov    %r12,%rdi
    903d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9041:	48 0f 46 f0          	cmovbe %rax,%rsi
    9045:	e8 a6 a3 ff ff       	call   33f0 <strcpy@plt>
    904a:	e9 71 f2 ff ff       	jmp    82c0 <fwp_write+0x80>
    904f:	90                   	nop
    9050:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9054:	48 8d 35 44 61 00 00 	lea    0x6144(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    905b:	48 8d 05 3c 61 00 00 	lea    0x613c(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    9062:	0f 2f c8             	comiss %xmm0,%xmm1
    9065:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    906c:	00 
    906d:	4c 89 e7             	mov    %r12,%rdi
    9070:	48 0f 46 f0          	cmovbe %rax,%rsi
    9074:	e8 77 a3 ff ff       	call   33f0 <strcpy@plt>
    9079:	e9 42 f2 ff ff       	jmp    82c0 <fwp_write+0x80>
    907e:	66 90                	xchg   %ax,%ax
    9080:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9085:	45 85 c0             	test   %r8d,%r8d
    9088:	75 34                	jne    90be <fwp_write+0xe7e>
    908a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9091:	00 
    9092:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9099:	00 00 
    909b:	0f 85 74 f6 ff ff    	jne    8715 <fwp_write+0x4d5>
    90a1:	ba 02 00 00 00       	mov    $0x2,%edx
    90a6:	48 8d 35 68 61 00 00 	lea    0x6168(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    90ad:	e9 a1 f3 ff ff       	jmp    8453 <fwp_write+0x213>
    90b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    90b6:	49 89 f0             	mov    %rsi,%r8
    90b9:	e9 e5 fc ff ff       	jmp    8da3 <fwp_write+0xb63>
    90be:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    90c3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    90c8:	85 ff                	test   %edi,%edi
    90ca:	0f 84 fa f3 ff ff    	je     84ca <fwp_write+0x28a>
    90d0:	ba 01 00 00 00       	mov    $0x1,%edx
    90d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    90da:	48 89 df             	mov    %rbx,%rdi
    90dd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    90e2:	e8 29 b1 ff ff       	call   4210 <buf_put>
    90e7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    90ec:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    90f1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    90f7:	85 c0                	test   %eax,%eax
    90f9:	0f 8f f0 f3 ff ff    	jg     84ef <fwp_write+0x2af>
    90ff:	e9 34 f4 ff ff       	jmp    8538 <fwp_write+0x2f8>
    9104:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9108:	49 89 c5             	mov    %rax,%r13
    910b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9110:	49 89 c4             	mov    %rax,%r12
    9113:	49 c1 fd 3f          	sar    $0x3f,%r13
    9117:	4c 09 e8             	or     %r13,%rax
    911a:	0f 84 a7 00 00 00    	je     91c7 <fwp_write+0xf87>
    9120:	48 8d 2d 79 81 00 00 	lea    0x8179(%rip),%rbp        # 112a0 <units.0>
    9127:	4d 89 e7             	mov    %r12,%r15
    912a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    912e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9133:	4c 89 ff             	mov    %r15,%rdi
    9136:	4c 89 ee             	mov    %r13,%rsi
    9139:	44 89 0c 24          	mov    %r9d,(%rsp)
    913d:	48 99                	cqto
    913f:	48 89 d1             	mov    %rdx,%rcx
    9142:	48 89 c2             	mov    %rax,%rdx
    9145:	e8 46 4e 00 00       	call   df90 <__divmodti4>
    914a:	44 8b 0c 24          	mov    (%rsp),%r9d
    914e:	48 89 c1             	mov    %rax,%rcx
    9151:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9156:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    915b:	0f 84 94 00 00 00    	je     91f5 <fwp_write+0xfb5>
    9161:	41 83 c1 01          	add    $0x1,%r9d
    9165:	48 83 c5 10          	add    $0x10,%rbp
    9169:	41 83 f9 05          	cmp    $0x5,%r9d
    916d:	75 bb                	jne    912a <fwp_write+0xeea>
    916f:	4d 85 ed             	test   %r13,%r13
    9172:	79 53                	jns    91c7 <fwp_write+0xf87>
    9174:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9179:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    917e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9183:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9188:	48 99                	cqto
    918a:	48 f7 d8             	neg    %rax
    918d:	48 83 d2 00          	adc    $0x0,%rdx
    9191:	48 89 c6             	mov    %rax,%rsi
    9194:	48 f7 da             	neg    %rdx
    9197:	e8 a4 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    919c:	49 89 e8             	mov    %rbp,%r8
    919f:	ba 00 02 00 00       	mov    $0x200,%edx
    91a4:	be 02 00 00 00       	mov    $0x2,%esi
    91a9:	31 c0                	xor    %eax,%eax
    91ab:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    91b2:	00 
    91b3:	48 8d 0d 56 60 00 00 	lea    0x6056(%rip),%rcx        # f210 <_IO_stdin_used+0x210>
    91ba:	4c 89 e7             	mov    %r12,%rdi
    91bd:	e8 1e a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    91c2:	e9 f9 f0 ff ff       	jmp    82c0 <fwp_write+0x80>
    91c7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    91cc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    91d1:	31 d2                	xor    %edx,%edx
    91d3:	48 89 ef             	mov    %rbp,%rdi
    91d6:	e8 65 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91db:	eb bf                	jmp    919c <fwp_write+0xf5c>
    91dd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    91e4:	4e 61 4e 00 
    91e8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    91ef:	00 
    91f0:	e9 cb f0 ff ff       	jmp    82c0 <fwp_write+0x80>
    91f5:	44 89 0c 24          	mov    %r9d,(%rsp)
    91f9:	48 89 c8             	mov    %rcx,%rax
    91fc:	48 85 d2             	test   %rdx,%rdx
    91ff:	78 51                	js     9252 <fwp_write+0x1012>
    9201:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9206:	48 89 c6             	mov    %rax,%rsi
    9209:	48 89 ef             	mov    %rbp,%rdi
    920c:	e8 2f a8 ff ff       	call   3a40 <fwp_fmt_u128>
    9211:	44 8b 0c 24          	mov    (%rsp),%r9d
    9215:	49 63 c1             	movslq %r9d,%rax
    9218:	49 89 e8             	mov    %rbp,%r8
    921b:	ba 00 02 00 00       	mov    $0x200,%edx
    9220:	be 02 00 00 00       	mov    $0x2,%esi
    9225:	48 c1 e0 04          	shl    $0x4,%rax
    9229:	48 8d 3d 70 80 00 00 	lea    0x8070(%rip),%rdi        # 112a0 <units.0>
    9230:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9237:	00 
    9238:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    923c:	48 8d 0d c8 5f 00 00 	lea    0x5fc8(%rip),%rcx        # f20b <_IO_stdin_used+0x20b>
    9243:	4c 89 e7             	mov    %r12,%rdi
    9246:	31 c0                	xor    %eax,%eax
    9248:	e8 93 a4 ff ff       	call   36e0 <__sprintf_chk@plt>
    924d:	e9 6e f0 ff ff       	jmp    82c0 <fwp_write+0x80>
    9252:	48 f7 d8             	neg    %rax
    9255:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    925a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    925f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9264:	48 83 d2 00          	adc    $0x0,%rdx
    9268:	48 89 c6             	mov    %rax,%rsi
    926b:	48 f7 da             	neg    %rdx
    926e:	e8 cd a7 ff ff       	call   3a40 <fwp_fmt_u128>
    9273:	44 8b 0c 24          	mov    (%rsp),%r9d
    9277:	eb 9c                	jmp    9215 <fwp_write+0xfd5>
    9279:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009280 <fwp_hof0.constprop.0>:
    9280:	41 57                	push   %r15
    9282:	41 56                	push   %r14
    9284:	41 55                	push   %r13
    9286:	41 54                	push   %r12
    9288:	55                   	push   %rbp
    9289:	53                   	push   %rbx
    928a:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9291:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9298:	00 00 
    929a:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    92a1:	00 
    92a2:	31 c0                	xor    %eax,%eax
    92a4:	48 85 f6             	test   %rsi,%rsi
    92a7:	0f 84 6a 0f 00 00    	je     a217 <fwp_hof0.constprop.0+0xf97>
    92ad:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
    92b2:	4c 8d 2d 07 a5 01 00 	lea    0x1a507(%rip),%r13        # 237c0 <fwp_heap>
    92b9:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
    92be:	66 90                	xchg   %ax,%ax
    92c0:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    92c7:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    92cc:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    92d3:	48 c1 e2 10          	shl    $0x10,%rdx
    92d7:	48 39 d0             	cmp    %rdx,%rax
    92da:	73 5d                	jae    9339 <fwp_hof0.constprop.0+0xb9>
    92dc:	48 89 c2             	mov    %rax,%rdx
    92df:	48 c1 ea 10          	shr    $0x10,%rdx
    92e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    92e7:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    92ee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    92f2:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    92f6:	48 85 ff             	test   %rdi,%rdi
    92f9:	74 3e                	je     9339 <fwp_hof0.constprop.0+0xb9>
    92fb:	0f b6 0a             	movzbl (%rdx),%ecx
    92fe:	80 f9 02             	cmp    $0x2,%cl
    9301:	0f 84 e9 14 00 00    	je     a7f0 <fwp_hof0.constprop.0+0x1570>
    9307:	80 f9 01             	cmp    $0x1,%cl
    930a:	75 2d                	jne    9339 <fwp_hof0.constprop.0+0xb9>
    930c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    930f:	0f b7 c0             	movzwl %ax,%eax
    9312:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9315:	48 0f af c1          	imul   %rcx,%rax
    9319:	48 c1 e8 20          	shr    $0x20,%rax
    931d:	48 39 d0             	cmp    %rdx,%rax
    9320:	73 17                	jae    9339 <fwp_hof0.constprop.0+0xb9>
    9322:	48 01 c7             	add    %rax,%rdi
    9325:	0f b6 07             	movzbl (%rdi),%eax
    9328:	84 c0                	test   %al,%al
    932a:	74 0d                	je     9339 <fwp_hof0.constprop.0+0xb9>
    932c:	3c fd                	cmp    $0xfd,%al
    932e:	0f 87 c7 16 00 00    	ja     a9fb <fwp_hof0.constprop.0+0x177b>
    9334:	83 c0 01             	add    $0x1,%eax
    9337:	88 07                	mov    %al,(%rdi)
    9339:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    933e:	45 31 c0             	xor    %r8d,%r8d
    9341:	48 c7 44 24 40 c6 00 	movq   $0xc6,0x40(%rsp)
    9348:	00 00 
    934a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    934f:	4c 89 c3             	mov    %r8,%rbx
    9352:	4d 85 c0             	test   %r8,%r8
    9355:	0f 85 f5 a3 ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    935b:	48 8b 05 f6 c0 01 00 	mov    0x1c0f6(%rip),%rax        # 25458 <fwp_cleanups>
    9362:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9369:	4c 8d 3d 50 d8 ff ff 	lea    -0x27b0(%rip),%r15        # 6bc0 <fwp_tape_scope_release>
    9370:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    9377:	ff 
    9378:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
    937f:	00 
    9380:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9387:	00 
    9388:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    938d:	48 c1 e2 10          	shl    $0x10,%rdx
    9391:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    9396:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    939d:	00 
    939e:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    93a5:	00 
    93a6:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    93ab:	48 89 05 a6 c0 01 00 	mov    %rax,0x1c0a6(%rip)        # 25458 <fwp_cleanups>
    93b2:	48 8d 05 57 9c 00 00 	lea    0x9c57(%rip),%rax        # 13010 <fc37>
    93b9:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    93c0:	48 39 d0             	cmp    %rdx,%rax
    93c3:	73 5d                	jae    9422 <fwp_hof0.constprop.0+0x1a2>
    93c5:	48 89 c2             	mov    %rax,%rdx
    93c8:	48 c1 ea 10          	shr    $0x10,%rdx
    93cc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    93d0:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    93d7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    93db:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    93df:	48 85 ff             	test   %rdi,%rdi
    93e2:	74 3e                	je     9422 <fwp_hof0.constprop.0+0x1a2>
    93e4:	0f b6 0a             	movzbl (%rdx),%ecx
    93e7:	80 f9 02             	cmp    $0x2,%cl
    93ea:	0f 84 a0 12 00 00    	je     a690 <fwp_hof0.constprop.0+0x1410>
    93f0:	80 f9 01             	cmp    $0x1,%cl
    93f3:	75 2d                	jne    9422 <fwp_hof0.constprop.0+0x1a2>
    93f5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93f8:	0f b7 c0             	movzwl %ax,%eax
    93fb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93fe:	48 0f af c1          	imul   %rcx,%rax
    9402:	48 c1 e8 20          	shr    $0x20,%rax
    9406:	48 39 d0             	cmp    %rdx,%rax
    9409:	73 17                	jae    9422 <fwp_hof0.constprop.0+0x1a2>
    940b:	48 01 c7             	add    %rax,%rdi
    940e:	0f b6 07             	movzbl (%rdi),%eax
    9411:	84 c0                	test   %al,%al
    9413:	74 0d                	je     9422 <fwp_hof0.constprop.0+0x1a2>
    9415:	3c fd                	cmp    $0xfd,%al
    9417:	0f 87 1e 15 00 00    	ja     a93b <fwp_hof0.constprop.0+0x16bb>
    941d:	83 c0 01             	add    $0x1,%eax
    9420:	88 07                	mov    %al,(%rdi)
    9422:	48 8d 3d e7 9b 00 00 	lea    0x9be7(%rip),%rdi        # 13010 <fc37>
    9429:	e8 62 d4 ff ff       	call   6890 <fwp_closure_drop>
    942e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    9433:	48 85 c0             	test   %rax,%rax
    9436:	0f 84 23 14 00 00    	je     a85f <fwp_hof0.constprop.0+0x15df>
    943c:	31 ed                	xor    %ebp,%ebp
    943e:	66 90                	xchg   %ax,%ax
    9440:	48 8b 40 10          	mov    0x10(%rax),%rax
    9444:	48 83 c5 01          	add    $0x1,%rbp
    9448:	48 85 c0             	test   %rax,%rax
    944b:	75 f3                	jne    9440 <fwp_hof0.constprop.0+0x1c0>
    944d:	31 ff                	xor    %edi,%edi
    944f:	e8 fc ad ff ff       	call   4250 <descent_phase_step>
    9454:	48 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%rbp
    945b:	0f 87 d7 15 00 00    	ja     aa38 <fwp_hof0.constprop.0+0x17b8>
    9461:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    9466:	8b 35 f4 9b 00 00    	mov    0x9bf4(%rip),%esi        # 13060 <registered_finish.1>
    946c:	85 f6                	test   %esi,%esi
    946e:	0f 84 d4 11 00 00    	je     a648 <fwp_hof0.constprop.0+0x13c8>
    9474:	48 8b 15 5d 9c 01 00 	mov    0x19c5d(%rip),%rdx        # 230d8 <fwp_tape_next_slot>
    947b:	4c 8b 25 66 9c 01 00 	mov    0x19c66(%rip),%r12        # 230e8 <fwp_ntapes>
    9482:	49 39 d4             	cmp    %rdx,%r12
    9485:	0f 8e 85 10 00 00    	jle    a510 <fwp_hof0.constprop.0+0x1290>
    948b:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    948f:	48 03 05 5a 9c 01 00 	add    0x19c5a(%rip),%rax        # 230f0 <fwp_tapes>
    9496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    949d:	00 00 00 
    94a0:	8b 48 04             	mov    0x4(%rax),%ecx
    94a3:	85 c9                	test   %ecx,%ecx
    94a5:	75 0c                	jne    94b3 <fwp_hof0.constprop.0+0x233>
    94a7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    94ad:	0f 86 5d 10 00 00    	jbe    a510 <fwp_hof0.constprop.0+0x1290>
    94b3:	48 83 c2 01          	add    $0x1,%rdx
    94b7:	48 83 c0 68          	add    $0x68,%rax
    94bb:	49 39 d4             	cmp    %rdx,%r12
    94be:	75 e0                	jne    94a0 <fwp_hof0.constprop.0+0x220>
    94c0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    94c7:	0f 8f ef 15 00 00    	jg     aabc <fwp_hof0.constprop.0+0x183c>
    94cd:	4c 3b 25 0c 9c 01 00 	cmp    0x19c0c(%rip),%r12        # 230e0 <fwp_tapes_cap>
    94d4:	4c 8b 0d 15 9c 01 00 	mov    0x19c15(%rip),%r9        # 230f0 <fwp_tapes>
    94db:	75 49                	jne    9526 <fwp_hof0.constprop.0+0x2a6>
    94dd:	4d 85 e4             	test   %r12,%r12
    94e0:	0f 84 6a 13 00 00    	je     a850 <fwp_hof0.constprop.0+0x15d0>
    94e6:	4b 8d 2c 24          	lea    (%r12,%r12,1),%rbp
    94ea:	b8 ff ff 00 00       	mov    $0xffff,%eax
    94ef:	48 39 c5             	cmp    %rax,%rbp
    94f2:	48 0f 4f e8          	cmovg  %rax,%rbp
    94f6:	48 6b f5 68          	imul   $0x68,%rbp,%rsi
    94fa:	4c 89 cf             	mov    %r9,%rdi
    94fd:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9502:	e8 c9 a0 ff ff       	call   35d0 <realloc@plt>
    9507:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    950c:	48 85 c0             	test   %rax,%rax
    950f:	49 89 c1             	mov    %rax,%r9
    9512:	0f 84 b0 15 00 00    	je     aac8 <fwp_hof0.constprop.0+0x1848>
    9518:	48 89 05 d1 9b 01 00 	mov    %rax,0x19bd1(%rip)        # 230f0 <fwp_tapes>
    951f:	48 89 2d ba 9b 01 00 	mov    %rbp,0x19bba(%rip)        # 230e0 <fwp_tapes_cap>
    9526:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    952a:	31 c0                	xor    %eax,%eax
    952c:	49 8d 6c 24 01       	lea    0x1(%r12),%rbp
    9531:	4c 01 c9             	add    %r9,%rcx
    9534:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    9538:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    953f:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9543:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    954a:	00 
    954b:	48 29 f9             	sub    %rdi,%rcx
    954e:	83 c1 68             	add    $0x68,%ecx
    9551:	c1 e9 03             	shr    $0x3,%ecx
    9554:	f3 48 ab             	rep stos %rax,(%rdi)
    9557:	48 89 2d 8a 9b 01 00 	mov    %rbp,0x19b8a(%rip)        # 230e8 <fwp_ntapes>
    955e:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    9562:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9566:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    956b:	48 8d 3d b0 5b 00 00 	lea    0x5bb0(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    9572:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    9577:	4c 01 c9             	add    %r9,%rcx
    957a:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    9581:	00 
    9582:	48 89 0c 24          	mov    %rcx,(%rsp)
    9586:	e8 15 9e ff ff       	call   33a0 <getenv@plt>
    958b:	48 8b 0c 24          	mov    (%rsp),%rcx
    958f:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    9594:	48 85 c0             	test   %rax,%rax
    9597:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
    959d:	0f 84 4d 0d 00 00    	je     a2f0 <fwp_hof0.constprop.0+0x1070>
    95a3:	80 38 30             	cmpb   $0x30,(%rax)
    95a6:	0f 85 44 0d 00 00    	jne    a2f0 <fwp_hof0.constprop.0+0x1070>
    95ac:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    95b0:	0f 85 3a 0d 00 00    	jne    a2f0 <fwp_hof0.constprop.0+0x1070>
    95b6:	8b 01                	mov    (%rcx),%eax
    95b8:	c7 41 04 01 00 00 00 	movl   $0x1,0x4(%rcx)
    95bf:	48 89 2d 12 9b 01 00 	mov    %rbp,0x19b12(%rip)        # 230d8 <fwp_tape_next_slot>
    95c6:	44 8d 70 01          	lea    0x1(%rax),%r14d
    95ca:	48 8b 05 bf 65 00 00 	mov    0x65bf(%rip),%rax        # fb90 <msg.4+0x20>
    95d1:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    95d8:	00 
    95d9:	44 89 31             	mov    %r14d,(%rcx)
    95dc:	48 89 41 58          	mov    %rax,0x58(%rcx)
    95e0:	48 8b 05 71 be 01 00 	mov    0x1be71(%rip),%rax        # 25458 <fwp_cleanups>
    95e7:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
    95eb:	48 85 c0             	test   %rax,%rax
    95ee:	75 1c                	jne    960c <fwp_hof0.constprop.0+0x38c>
    95f0:	e9 6b 14 00 00       	jmp    aa60 <fwp_hof0.constprop.0+0x17e0>
    95f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    95fc:	00 00 00 00 
    9600:	48 8b 00             	mov    (%rax),%rax
    9603:	48 85 c0             	test   %rax,%rax
    9606:	0f 84 54 14 00 00    	je     aa60 <fwp_hof0.constprop.0+0x17e0>
    960c:	4c 39 78 08          	cmp    %r15,0x8(%rax)
    9610:	75 ee                	jne    9600 <fwp_hof0.constprop.0+0x380>
    9612:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9616:	44 89 e6             	mov    %r12d,%esi
    9619:	48 63 07             	movslq (%rdi),%rax
    961c:	48 89 79 50          	mov    %rdi,0x50(%rcx)
    9620:	89 41 5c             	mov    %eax,0x5c(%rcx)
    9623:	85 c0                	test   %eax,%eax
    9625:	78 09                	js     9630 <fwp_hof0.constprop.0+0x3b0>
    9627:	48 6b c0 68          	imul   $0x68,%rax,%rax
    962b:	45 89 64 01 58       	mov    %r12d,0x58(%r9,%rax,1)
    9630:	89 37                	mov    %esi,(%rdi)
    9632:	bf 01 00 00 00       	mov    $0x1,%edi
    9637:	45 31 e4             	xor    %r12d,%r12d
    963a:	e8 11 ac ff ff       	call   4250 <descent_phase_step>
    963f:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9644:	48 89 f8             	mov    %rdi,%rax
    9647:	48 85 ff             	test   %rdi,%rdi
    964a:	0f 84 f0 0d 00 00    	je     a440 <fwp_hof0.constprop.0+0x11c0>
    9650:	48 8b 40 10          	mov    0x10(%rax),%rax
    9654:	49 83 c4 01          	add    $0x1,%r12
    9658:	48 85 c0             	test   %rax,%rax
    965b:	75 f3                	jne    9650 <fwp_hof0.constprop.0+0x3d0>
    965d:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    9662:	0f 1f 00             	nopl   (%rax)
    9665:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    966c:	00 00 00 00 
    9670:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9674:	48 83 c0 01          	add    $0x1,%rax
    9678:	48 85 c9             	test   %rcx,%rcx
    967b:	75 f3                	jne    9670 <fwp_hof0.constprop.0+0x3f0>
    967d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    9684:	ff ff 1f 
    9687:	48 39 c1             	cmp    %rax,%rcx
    968a:	0f 82 c0 13 00 00    	jb     aa50 <fwp_hof0.constprop.0+0x17d0>
    9690:	4d 85 e4             	test   %r12,%r12
    9693:	0f 8e a7 0d 00 00    	jle    a440 <fwp_hof0.constprop.0+0x11c0>
    9699:	49 39 c4             	cmp    %rax,%r12
    969c:	4c 0f 47 e0          	cmova  %rax,%r12
    96a0:	4c 89 e0             	mov    %r12,%rax
    96a3:	48 c1 e8 3c          	shr    $0x3c,%rax
    96a7:	0f 85 a3 13 00 00    	jne    aa50 <fwp_hof0.constprop.0+0x17d0>
    96ad:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    96b1:	44 89 f2             	mov    %r14d,%edx
    96b4:	be 02 00 00 00       	mov    $0x2,%esi
    96b9:	48 c1 e2 10          	shl    $0x10,%rdx
    96bd:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    96c4:	00 
    96c5:	48 09 d5             	or     %rdx,%rbp
    96c8:	e8 c3 c5 ff ff       	call   5c90 <fwp_heap_alloc>
    96cd:	4c 89 38             	mov    %r15,(%rax)
    96d0:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    96d7:	49 89 c6             	mov    %rax,%r14
    96da:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    96e1:	48 c1 e2 10          	shl    $0x10,%rdx
    96e5:	48 39 d0             	cmp    %rdx,%rax
    96e8:	0f 83 02 0e 00 00    	jae    a4f0 <fwp_hof0.constprop.0+0x1270>
    96ee:	48 89 c2             	mov    %rax,%rdx
    96f1:	48 c1 ea 10          	shr    $0x10,%rdx
    96f5:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    96f9:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9700:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    9704:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9708:	4d 85 ff             	test   %r15,%r15
    970b:	74 3a                	je     9747 <fwp_hof0.constprop.0+0x4c7>
    970d:	0f b6 32             	movzbl (%rdx),%esi
    9710:	40 80 fe 02          	cmp    $0x2,%sil
    9714:	0f 84 97 0d 00 00    	je     a4b1 <fwp_hof0.constprop.0+0x1231>
    971a:	40 80 fe 01          	cmp    $0x1,%sil
    971e:	75 27                	jne    9747 <fwp_hof0.constprop.0+0x4c7>
    9720:	8b 72 18             	mov    0x18(%rdx),%esi
    9723:	0f b7 c0             	movzwl %ax,%eax
    9726:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9729:	48 0f af c6          	imul   %rsi,%rax
    972d:	48 c1 e8 20          	shr    $0x20,%rax
    9731:	48 39 d0             	cmp    %rdx,%rax
    9734:	73 11                	jae    9747 <fwp_hof0.constprop.0+0x4c7>
    9736:	49 01 c7             	add    %rax,%r15
    9739:	41 80 3f ff          	cmpb   $0xff,(%r15)
    973d:	0f 84 81 0d 00 00    	je     a4c4 <fwp_hof0.constprop.0+0x1244>
    9743:	41 c6 07 01          	movb   $0x1,(%r15)
    9747:	4d 85 e4             	test   %r12,%r12
    974a:	74 68                	je     97b4 <fwp_hof0.constprop.0+0x534>
    974c:	48 89 ee             	mov    %rbp,%rsi
    974f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    9754:	31 c0                	xor    %eax,%eax
    9756:	48 c1 e6 20          	shl    $0x20,%rsi
    975a:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    975f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9766:	00 00 00 00 
    976a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9771:	00 00 00 00 
    9775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    977c:	00 00 00 00 
    9780:	48 89 c1             	mov    %rax,%rcx
    9783:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9788:	48 01 f1             	add    %rsi,%rcx
    978b:	0f 80 bf 9f ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9791:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    9796:	48 89 c1             	mov    %rax,%rcx
    9799:	48 83 c0 01          	add    $0x1,%rax
    979d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    97a1:	48 c1 e1 04          	shl    $0x4,%rcx
    97a5:	41 0f 11 44 0e 08    	movups %xmm0,0x8(%r14,%rcx,1)
    97ab:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    97af:	4c 39 e0             	cmp    %r12,%rax
    97b2:	72 cc                	jb     9780 <fwp_hof0.constprop.0+0x500>
    97b4:	49 8b 06             	mov    (%r14),%rax
    97b7:	48 d1 e8             	shr    $1,%rax
    97ba:	0f 84 40 0d 00 00    	je     a500 <fwp_hof0.constprop.0+0x1280>
    97c0:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    97c4:	48 89 f7             	mov    %rsi,%rdi
    97c7:	48 c1 ef 3c          	shr    $0x3c,%rdi
    97cb:	0f 85 7f 12 00 00    	jne    aa50 <fwp_hof0.constprop.0+0x17d0>
    97d1:	48 8d 14 36          	lea    (%rsi,%rsi,1),%rdx
    97d5:	48 85 f6             	test   %rsi,%rsi
    97d8:	74 48                	je     9822 <fwp_hof0.constprop.0+0x5a2>
    97da:	48 c1 e0 04          	shl    $0x4,%rax
    97de:	48 89 1c 24          	mov    %rbx,(%rsp)
    97e2:	49 89 d7             	mov    %rdx,%r15
    97e5:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    97e9:	4d 8d 64 06 f8       	lea    -0x8(%r14,%rax,1),%r12
    97ee:	66 90                	xchg   %ax,%ax
    97f0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    97f4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    97f8:	48 83 c3 10          	add    $0x10,%rbx
    97fc:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    9800:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    9804:	e8 57 ca ff ff       	call   6260 <w120>
    9809:	66 48 0f 6e e0       	movq   %rax,%xmm4
    980e:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9812:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    9816:	49 39 dc             	cmp    %rbx,%r12
    9819:	75 d5                	jne    97f0 <fwp_hof0.constprop.0+0x570>
    981b:	48 8b 1c 24          	mov    (%rsp),%rbx
    981f:	4c 89 fa             	mov    %r15,%rdx
    9822:	49 89 16             	mov    %rdx,(%r14)
    9825:	4c 89 f7             	mov    %r14,%rdi
    9828:	4c 63 fd             	movslq %ebp,%r15
    982b:	e8 a0 cb ff ff       	call   63d0 <w176.constprop.0>
    9830:	4c 89 f7             	mov    %r14,%rdi
    9833:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9838:	e8 b3 e2 ff ff       	call   7af0 <fwp_drop10>
    983d:	bf 02 00 00 00       	mov    $0x2,%edi
    9842:	e8 09 aa ff ff       	call   4250 <descent_phase_step>
    9847:	4c 89 ff             	mov    %r15,%rdi
    984a:	e8 81 ae ff ff       	call   46d0 <fwp_tape_of>
    984f:	48 89 c6             	mov    %rax,%rsi
    9852:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9857:	0f 85 99 12 00 00    	jne    aaf6 <fwp_hof0.constprop.0+0x1876>
    985d:	48 89 c7             	mov    %rax,%rdi
    9860:	e8 9b a3 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    9865:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    986a:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    986e:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9875:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    987a:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    987f:	0f 29 74 24 10       	movaps %xmm6,0x10(%rsp)
    9884:	66 48 0f 6e f2       	movq   %rdx,%xmm6
    9889:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    988d:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    9891:	4c 8b 66 40          	mov    0x40(%rsi),%r12
    9895:	0f 29 3c 24          	movaps %xmm7,(%rsp)
    9899:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    989d:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    98a3:	77 18                	ja     98bd <fwp_hof0.constprop.0+0x63d>
    98a5:	0f b7 c5             	movzwl %bp,%eax
    98a8:	83 e8 01             	sub    $0x1,%eax
    98ab:	48 98                	cltq
    98ad:	48 3b 05 24 98 01 00 	cmp    0x19824(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    98b4:	7d 07                	jge    98bd <fwp_hof0.constprop.0+0x63d>
    98b6:	48 89 05 1b 98 01 00 	mov    %rax,0x1981b(%rip)        # 230d8 <fwp_tape_next_slot>
    98bd:	48 8b 05 94 bb 01 00 	mov    0x1bb94(%rip),%rax        # 25458 <fwp_cleanups>
    98c4:	66 0f ef c9          	pxor   %xmm1,%xmm1
    98c8:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    98cf:	00 
    98d0:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    98d4:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    98da:	66 0f 6f 34 24       	movdqa (%rsp),%xmm6
    98df:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    98e6:	00 
    98e7:	48 8d 05 82 b7 ff ff 	lea    -0x487e(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    98ee:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    98f5:	00 
    98f6:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    98fd:	00 
    98fe:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9902:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9906:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    990b:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9912:	00 
    9913:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    991a:	00 
    991b:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9920:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9927:	00 
    9928:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    992f:	00 
    9930:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    9937:	00 
    9938:	48 89 05 19 bb 01 00 	mov    %rax,0x1bb19(%rip)        # 25458 <fwp_cleanups>
    993f:	0f 29 bc 24 c0 00 00 	movaps %xmm7,0xc0(%rsp)
    9946:	00 
    9947:	0f 29 b4 24 d0 00 00 	movaps %xmm6,0xd0(%rsp)
    994e:	00 
    994f:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    9956:	00 
    9957:	48 85 f6             	test   %rsi,%rsi
    995a:	0f 88 40 0d 00 00    	js     a6a0 <fwp_hof0.constprop.0+0x1420>
    9960:	48 89 f0             	mov    %rsi,%rax
    9963:	48 c1 f8 20          	sar    $0x20,%rax
    9967:	49 39 c7             	cmp    %rax,%r15
    996a:	0f 85 9d 10 00 00    	jne    aa0d <fwp_hof0.constprop.0+0x178d>
    9970:	41 89 f2             	mov    %esi,%r10d
    9973:	4d 89 d7             	mov    %r10,%r15
    9976:	4c 39 d7             	cmp    %r10,%rdi
    9979:	0f 8e 9a 10 00 00    	jle    aa19 <fwp_hof0.constprop.0+0x1799>
    997f:	4d 39 d6             	cmp    %r10,%r14
    9982:	0f 8e c8 0b 00 00    	jle    a550 <fwp_hof0.constprop.0+0x12d0>
    9988:	49 39 d6             	cmp    %rdx,%r14
    998b:	0f 8f 07 0c 00 00    	jg     a598 <fwp_hof0.constprop.0+0x1318>
    9991:	4d 85 e4             	test   %r12,%r12
    9994:	0f 84 db 10 00 00    	je     aa75 <fwp_hof0.constprop.0+0x17f5>
    999a:	31 f6                	xor    %esi,%esi
    999c:	4c 89 e7             	mov    %r12,%rdi
    999f:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    99a4:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    99a8:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    99af:	00 
    99b0:	e8 0b 9b ff ff       	call   34c0 <memset@plt>
    99b5:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
    99ba:	45 31 db             	xor    %r11d,%r11d
    99bd:	f2 0f 10 05 d3 61 00 	movsd  0x61d3(%rip),%xmm0        # fb98 <msg.4+0x28>
    99c4:	00 
    99c5:	f2 43 0f 58 04 d4    	addsd  (%r12,%r10,8),%xmm0
    99cb:	f2 43 0f 11 04 d4    	movsd  %xmm0,(%r12,%r10,8)
    99d1:	bf 03 00 00 00       	mov    $0x3,%edi
    99d6:	4c 01 35 23 97 01 00 	add    %r14,0x19723(%rip)        # 23100 <descent_inputs>
    99dd:	4c 01 1d 24 97 01 00 	add    %r11,0x19724(%rip)        # 23108 <descent_nodes>
    99e4:	e8 67 a8 ff ff       	call   4250 <descent_phase_step>
    99e9:	4d 39 f7             	cmp    %r14,%r15
    99ec:	0f 8c 86 00 00 00    	jl     9a78 <fwp_hof0.constprop.0+0x7f8>
    99f2:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    99f7:	4c 8b 14 24          	mov    (%rsp),%r10
    99fb:	4d 29 f7             	sub    %r14,%r15
    99fe:	4b 8d 2c f4          	lea    (%r12,%r14,8),%rbp
    9a02:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9a07:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9a0c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9a10:	4b 8d 14 fb          	lea    (%r11,%r15,8),%rdx
    9a14:	4c 29 dd             	sub    %r11,%rbp
    9a17:	4d 29 da             	sub    %r11,%r10
    9a1a:	4a 8d 04 bf          	lea    (%rdi,%r15,4),%rax
    9a1e:	48 29 fe             	sub    %rdi,%rsi
    9a21:	eb 09                	jmp    9a2c <fwp_hof0.constprop.0+0x7ac>
    9a23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9a28:	48 83 e8 04          	sub    $0x4,%rax
    9a2c:	f2 0f 10 44 15 00    	movsd  0x0(%rbp,%rdx,1),%xmm0
    9a32:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9a36:	7a 02                	jp     9a3a <fwp_hof0.constprop.0+0x7ba>
    9a38:	74 35                	je     9a6f <fwp_hof0.constprop.0+0x7ef>
    9a3a:	48 63 0c 06          	movslq (%rsi,%rax,1),%rcx
    9a3e:	85 c9                	test   %ecx,%ecx
    9a40:	78 16                	js     9a58 <fwp_hof0.constprop.0+0x7d8>
    9a42:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    9a48:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9a4c:	f2 41 0f 58 0c cc    	addsd  (%r12,%rcx,8),%xmm1
    9a52:	f2 41 0f 11 0c cc    	movsd  %xmm1,(%r12,%rcx,8)
    9a58:	48 63 08             	movslq (%rax),%rcx
    9a5b:	85 c9                	test   %ecx,%ecx
    9a5d:	78 10                	js     9a6f <fwp_hof0.constprop.0+0x7ef>
    9a5f:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9a63:	f2 41 0f 58 04 cc    	addsd  (%r12,%rcx,8),%xmm0
    9a69:	f2 41 0f 11 04 cc    	movsd  %xmm0,(%r12,%rcx,8)
    9a6f:	48 83 ea 08          	sub    $0x8,%rdx
    9a73:	48 39 c7             	cmp    %rax,%rdi
    9a76:	75 b0                	jne    9a28 <fwp_hof0.constprop.0+0x7a8>
    9a78:	bf 04 00 00 00       	mov    $0x4,%edi
    9a7d:	e8 ce a7 ff ff       	call   4250 <descent_phase_step>
    9a82:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9a89:	ff ff 1f 
    9a8c:	4c 39 f0             	cmp    %r14,%rax
    9a8f:	0f 82 af 0f 00 00    	jb     aa44 <fwp_hof0.constprop.0+0x17c4>
    9a95:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9a9c:	00 
    9a9d:	be 02 00 00 00       	mov    $0x2,%esi
    9aa2:	e8 e9 c1 ff ff       	call   5c90 <fwp_heap_alloc>
    9aa7:	4c 89 30             	mov    %r14,(%rax)
    9aaa:	49 89 c7             	mov    %rax,%r15
    9aad:	4d 85 f6             	test   %r14,%r14
    9ab0:	74 20                	je     9ad2 <fwp_hof0.constprop.0+0x852>
    9ab2:	0f 1f 00             	nopl   (%rax)
    9ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9abc:	00 00 00 00 
    9ac0:	49 8b 04 dc          	mov    (%r12,%rbx,8),%rax
    9ac4:	49 89 44 df 08       	mov    %rax,0x8(%r15,%rbx,8)
    9ac9:	48 83 c3 01          	add    $0x1,%rbx
    9acd:	49 39 de             	cmp    %rbx,%r14
    9ad0:	75 ee                	jne    9ac0 <fwp_hof0.constprop.0+0x840>
    9ad2:	bf 05 00 00 00       	mov    $0x5,%edi
    9ad7:	e8 74 a7 ff ff       	call   4250 <descent_phase_step>
    9adc:	4c 8b a4 24 a0 00 00 	mov    0xa0(%rsp),%r12
    9ae3:	00 
    9ae4:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    9ae9:	4c 89 25 68 b9 01 00 	mov    %r12,0x1b968(%rip)        # 25458 <fwp_cleanups>
    9af0:	e8 7b b5 ff ff       	call   5070 <fwp_tape_buffers_release>
    9af5:	bf 06 00 00 00       	mov    $0x6,%edi
    9afa:	e8 51 a7 ff ff       	call   4250 <descent_phase_step>
    9aff:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9b06:	4c 89 f8             	mov    %r15,%rax
    9b09:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9b10:	48 c1 e2 10          	shl    $0x10,%rdx
    9b14:	48 39 d0             	cmp    %rdx,%rax
    9b17:	73 57                	jae    9b70 <fwp_hof0.constprop.0+0x8f0>
    9b19:	48 89 c2             	mov    %rax,%rdx
    9b1c:	48 c1 ea 10          	shr    $0x10,%rdx
    9b20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b24:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9b2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b2f:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9b33:	48 85 ed             	test   %rbp,%rbp
    9b36:	74 38                	je     9b70 <fwp_hof0.constprop.0+0x8f0>
    9b38:	0f b6 0a             	movzbl (%rdx),%ecx
    9b3b:	80 f9 02             	cmp    $0x2,%cl
    9b3e:	0f 84 8c 0b 00 00    	je     a6d0 <fwp_hof0.constprop.0+0x1450>
    9b44:	80 f9 01             	cmp    $0x1,%cl
    9b47:	75 27                	jne    9b70 <fwp_hof0.constprop.0+0x8f0>
    9b49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b4c:	0f b7 c0             	movzwl %ax,%eax
    9b4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b52:	48 0f af c1          	imul   %rcx,%rax
    9b56:	48 c1 e8 20          	shr    $0x20,%rax
    9b5a:	48 39 d0             	cmp    %rdx,%rax
    9b5d:	73 11                	jae    9b70 <fwp_hof0.constprop.0+0x8f0>
    9b5f:	48 01 c5             	add    %rax,%rbp
    9b62:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9b66:	0f 84 77 0b 00 00    	je     a6e3 <fwp_hof0.constprop.0+0x1463>
    9b6c:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9b70:	4c 3b 64 24 50       	cmp    0x50(%rsp),%r12
    9b75:	0f 85 d0 9b ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9b7b:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9b82:	00 
    9b83:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
    9b88:	48 89 05 c9 b8 01 00 	mov    %rax,0x1b8c9(%rip)        # 25458 <fwp_cleanups>
    9b8f:	e8 2c d0 ff ff       	call   6bc0 <fwp_tape_scope_release>
    9b94:	49 8b 07             	mov    (%r15),%rax
    9b97:	49 89 c6             	mov    %rax,%r14
    9b9a:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9b9f:	48 85 c0             	test   %rax,%rax
    9ba2:	0f 88 d8 07 00 00    	js     a380 <fwp_hof0.constprop.0+0x1100>
    9ba8:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9baf:	4c 89 f8             	mov    %r15,%rax
    9bb2:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9bb9:	48 c1 e2 10          	shl    $0x10,%rdx
    9bbd:	48 39 d0             	cmp    %rdx,%rax
    9bc0:	0f 83 ba 07 00 00    	jae    a380 <fwp_hof0.constprop.0+0x1100>
    9bc6:	48 89 c2             	mov    %rax,%rdx
    9bc9:	48 c1 ea 10          	shr    $0x10,%rdx
    9bcd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bd1:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9bd8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bdc:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9be0:	48 85 c9             	test   %rcx,%rcx
    9be3:	0f 84 97 07 00 00    	je     a380 <fwp_hof0.constprop.0+0x1100>
    9be9:	0f b6 32             	movzbl (%rdx),%esi
    9bec:	40 80 fe 02          	cmp    $0x2,%sil
    9bf0:	0f 84 7a 07 00 00    	je     a370 <fwp_hof0.constprop.0+0x10f0>
    9bf6:	40 80 fe 01          	cmp    $0x1,%sil
    9bfa:	0f 85 80 07 00 00    	jne    a380 <fwp_hof0.constprop.0+0x1100>
    9c00:	8b 72 18             	mov    0x18(%rdx),%esi
    9c03:	0f b7 c0             	movzwl %ax,%eax
    9c06:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c09:	48 0f af c6          	imul   %rsi,%rax
    9c0d:	48 c1 e8 20          	shr    $0x20,%rax
    9c11:	48 39 d0             	cmp    %rdx,%rax
    9c14:	0f 83 66 07 00 00    	jae    a380 <fwp_hof0.constprop.0+0x1100>
    9c1a:	48 01 c1             	add    %rax,%rcx
    9c1d:	80 39 01             	cmpb   $0x1,(%rcx)
    9c20:	0f 85 5a 07 00 00    	jne    a380 <fwp_hof0.constprop.0+0x1100>
    9c26:	4c 89 3c 24          	mov    %r15,(%rsp)
    9c2a:	4c 89 fd             	mov    %r15,%rbp
    9c2d:	31 ff                	xor    %edi,%edi
    9c2f:	48 8b 04 24          	mov    (%rsp),%rax
    9c33:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9c37:	31 c0                	xor    %eax,%eax
    9c39:	4d 85 f6             	test   %r14,%r14
    9c3c:	75 2c                	jne    9c6a <fwp_hof0.constprop.0+0x9ea>
    9c3e:	eb 40                	jmp    9c80 <fwp_hof0.constprop.0+0xa00>
    9c40:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9c45:	0f 88 da 0d 00 00    	js     aa25 <fwp_hof0.constprop.0+0x17a5>
    9c4b:	f2 0f 10 05 5d 5f 00 	movsd  0x5f5d(%rip),%xmm0        # fbb0 <msg.4+0x40>
    9c52:	00 
    9c53:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    9c58:	48 83 c0 01          	add    $0x1,%rax
    9c5c:	48 83 c2 08          	add    $0x8,%rdx
    9c60:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9c65:	49 39 c6             	cmp    %rax,%r14
    9c68:	74 16                	je     9c80 <fwp_hof0.constprop.0+0xa00>
    9c6a:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    9c6e:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9c72:	79 cc                	jns    9c40 <fwp_hof0.constprop.0+0x9c0>
    9c74:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    9c78:	eb c6                	jmp    9c40 <fwp_hof0.constprop.0+0x9c0>
    9c7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c80:	e8 6b de ff ff       	call   7af0 <fwp_drop10>
    9c85:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9c8a:	31 d2                	xor    %edx,%edx
    9c8c:	48 89 f8             	mov    %rdi,%rax
    9c8f:	48 85 ff             	test   %rdi,%rdi
    9c92:	0f 84 d7 0b 00 00    	je     a86f <fwp_hof0.constprop.0+0x15ef>
    9c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9c9f:	00 
    9ca0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9ca4:	48 83 c2 01          	add    $0x1,%rdx
    9ca8:	48 85 c0             	test   %rax,%rax
    9cab:	75 f3                	jne    9ca0 <fwp_hof0.constprop.0+0xa20>
    9cad:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9cb1:	49 89 c7             	mov    %rax,%r15
    9cb4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9cb9:	48 85 c0             	test   %rax,%rax
    9cbc:	0f 88 9b 05 00 00    	js     a25d <fwp_hof0.constprop.0+0xfdd>
    9cc2:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    9cc9:	48 8b 0c 24          	mov    (%rsp),%rcx
    9ccd:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    9cd4:	48 c1 e0 10          	shl    $0x10,%rax
    9cd8:	48 39 c1             	cmp    %rax,%rcx
    9cdb:	0f 83 7c 05 00 00    	jae    a25d <fwp_hof0.constprop.0+0xfdd>
    9ce1:	48 89 c8             	mov    %rcx,%rax
    9ce4:	48 c1 e8 10          	shr    $0x10,%rax
    9ce8:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    9cec:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    9cf3:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9cf7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9cfb:	48 85 ff             	test   %rdi,%rdi
    9cfe:	0f 84 59 05 00 00    	je     a25d <fwp_hof0.constprop.0+0xfdd>
    9d04:	0f b6 06             	movzbl (%rsi),%eax
    9d07:	3c 02                	cmp    $0x2,%al
    9d09:	0f 84 39 05 00 00    	je     a248 <fwp_hof0.constprop.0+0xfc8>
    9d0f:	3c 01                	cmp    $0x1,%al
    9d11:	0f 85 3a 05 00 00    	jne    a251 <fwp_hof0.constprop.0+0xfd1>
    9d17:	8b 46 18             	mov    0x18(%rsi),%eax
    9d1a:	0f b7 c9             	movzwl %cx,%ecx
    9d1d:	48 0f af c8          	imul   %rax,%rcx
    9d21:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9d24:	48 c1 e9 20          	shr    $0x20,%rcx
    9d28:	48 39 c1             	cmp    %rax,%rcx
    9d2b:	0f 83 20 05 00 00    	jae    a251 <fwp_hof0.constprop.0+0xfd1>
    9d31:	48 01 cf             	add    %rcx,%rdi
    9d34:	80 3f 01             	cmpb   $0x1,(%rdi)
    9d37:	0f 85 14 05 00 00    	jne    a251 <fwp_hof0.constprop.0+0xfd1>
    9d3d:	49 39 d7             	cmp    %rdx,%r15
    9d40:	48 89 d0             	mov    %rdx,%rax
    9d43:	49 0f 46 c7          	cmovbe %r15,%rax
    9d47:	48 85 c0             	test   %rax,%rax
    9d4a:	0f 84 e1 0c 00 00    	je     aa31 <fwp_hof0.constprop.0+0x17b1>
    9d50:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    9d57:	00 
    9d58:	48 8d 5d 08          	lea    0x8(%rbp),%rbx
    9d5c:	4c 8b 04 24          	mov    (%rsp),%r8
    9d60:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    9d65:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    9d6c:	00 
    9d6d:	31 d2                	xor    %edx,%edx
    9d6f:	49 8d 78 08          	lea    0x8(%r8),%rdi
    9d73:	eb 27                	jmp    9d9c <fwp_hof0.constprop.0+0xb1c>
    9d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d7c:	00 00 00 00 
    9d80:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9d85:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    9d8a:	f2 0f 11 04 13       	movsd  %xmm0,(%rbx,%rdx,1)
    9d8f:	48 83 c2 08          	add    $0x8,%rdx
    9d93:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9d97:	49 39 d1             	cmp    %rdx,%r9
    9d9a:	74 14                	je     9db0 <fwp_hof0.constprop.0+0xb30>
    9d9c:	48 89 fe             	mov    %rdi,%rsi
    9d9f:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9da4:	79 da                	jns    9d80 <fwp_hof0.constprop.0+0xb00>
    9da6:	49 8b 70 10          	mov    0x10(%r8),%rsi
    9daa:	eb d4                	jmp    9d80 <fwp_hof0.constprop.0+0xb00>
    9dac:	0f 1f 40 00          	nopl   0x0(%rax)
    9db0:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    9db5:	48 85 c9             	test   %rcx,%rcx
    9db8:	0f 84 47 0c 00 00    	je     aa05 <fwp_hof0.constprop.0+0x1785>
    9dbe:	4d 8b 8d d8 13 00 00 	mov    0x13d8(%r13),%r9
    9dc5:	4d 8b 95 b0 13 00 00 	mov    0x13b0(%r13),%r10
    9dcc:	45 31 ff             	xor    %r15d,%r15d
    9dcf:	4d 8b 9d f8 13 00 00 	mov    0x13f8(%r13),%r11
    9dd6:	49 c1 e1 10          	shl    $0x10,%r9
    9dda:	eb 1a                	jmp    9df6 <fwp_hof0.constprop.0+0xb76>
    9ddc:	0f 1f 40 00          	nopl   0x0(%rax)
    9de0:	49 83 c7 01          	add    $0x1,%r15
    9de4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9de8:	49 39 c7             	cmp    %rax,%r15
    9deb:	0f 83 5f 01 00 00    	jae    9f50 <fwp_hof0.constprop.0+0xcd0>
    9df1:	48 85 c9             	test   %rcx,%rcx
    9df4:	74 56                	je     9e4c <fwp_hof0.constprop.0+0xbcc>
    9df6:	48 89 ca             	mov    %rcx,%rdx
    9df9:	4c 29 d2             	sub    %r10,%rdx
    9dfc:	4c 39 ca             	cmp    %r9,%rdx
    9dff:	73 4b                	jae    9e4c <fwp_hof0.constprop.0+0xbcc>
    9e01:	48 89 d6             	mov    %rdx,%rsi
    9e04:	48 c1 ee 10          	shr    $0x10,%rsi
    9e08:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9e0c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    9e10:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9e14:	48 85 ff             	test   %rdi,%rdi
    9e17:	74 33                	je     9e4c <fwp_hof0.constprop.0+0xbcc>
    9e19:	44 0f b6 06          	movzbl (%rsi),%r8d
    9e1d:	41 80 f8 02          	cmp    $0x2,%r8b
    9e21:	0f 84 11 01 00 00    	je     9f38 <fwp_hof0.constprop.0+0xcb8>
    9e27:	41 80 f8 01          	cmp    $0x1,%r8b
    9e2b:	75 1f                	jne    9e4c <fwp_hof0.constprop.0+0xbcc>
    9e2d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9e31:	0f b7 d2             	movzwl %dx,%edx
    9e34:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9e37:	49 0f af d0          	imul   %r8,%rdx
    9e3b:	48 c1 ea 20          	shr    $0x20,%rdx
    9e3f:	48 39 f2             	cmp    %rsi,%rdx
    9e42:	73 08                	jae    9e4c <fwp_hof0.constprop.0+0xbcc>
    9e44:	48 01 d7             	add    %rdx,%rdi
    9e47:	80 3f 01             	cmpb   $0x1,(%rdi)
    9e4a:	74 94                	je     9de0 <fwp_hof0.constprop.0+0xb60>
    9e4c:	49 39 c7             	cmp    %rax,%r15
    9e4f:	0f 83 fb 00 00 00    	jae    9f50 <fwp_hof0.constprop.0+0xcd0>
    9e55:	49 89 c4             	mov    %rax,%r12
    9e58:	45 31 f6             	xor    %r14d,%r14d
    9e5b:	48 8d ac 24 00 01 00 	lea    0x100(%rsp),%rbp
    9e62:	00 
    9e63:	eb 37                	jmp    9e9c <fwp_hof0.constprop.0+0xc1c>
    9e65:	0f 1f 00             	nopl   (%rax)
    9e68:	40 80 fe 01          	cmp    $0x1,%sil
    9e6c:	75 25                	jne    9e93 <fwp_hof0.constprop.0+0xc13>
    9e6e:	8b 71 18             	mov    0x18(%rcx),%esi
    9e71:	0f b7 c0             	movzwl %ax,%eax
    9e74:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9e77:	48 0f af c6          	imul   %rsi,%rax
    9e7b:	48 c1 e8 20          	shr    $0x20,%rax
    9e7f:	48 39 c8             	cmp    %rcx,%rax
    9e82:	73 0f                	jae    9e93 <fwp_hof0.constprop.0+0xc13>
    9e84:	48 01 c2             	add    %rax,%rdx
    9e87:	80 3a ff             	cmpb   $0xff,(%rdx)
    9e8a:	0f 84 98 05 00 00    	je     a428 <fwp_hof0.constprop.0+0x11a8>
    9e90:	c6 02 01             	movb   $0x1,(%rdx)
    9e93:	4d 39 e7             	cmp    %r12,%r15
    9e96:	0f 83 84 00 00 00    	jae    9f20 <fwp_hof0.constprop.0+0xca0>
    9e9c:	49 83 ec 01          	sub    $0x1,%r12
    9ea0:	66 49 0f 6e ee       	movq   %r14,%xmm5
    9ea5:	48 89 ee             	mov    %rbp,%rsi
    9ea8:	bf 01 00 00 00       	mov    $0x1,%edi
    9ead:	f3 42 0f 7e 04 e3    	movq   (%rbx,%r12,8),%xmm0
    9eb3:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9eb7:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    9ebe:	00 
    9ebf:	e8 ec be ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9ec4:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9ecb:	49 89 c6             	mov    %rax,%r14
    9ece:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9ed5:	48 c1 e2 10          	shl    $0x10,%rdx
    9ed9:	48 39 d0             	cmp    %rdx,%rax
    9edc:	73 b5                	jae    9e93 <fwp_hof0.constprop.0+0xc13>
    9ede:	48 89 c2             	mov    %rax,%rdx
    9ee1:	48 c1 ea 10          	shr    $0x10,%rdx
    9ee5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ee9:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9ef0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9ef4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9ef8:	48 85 d2             	test   %rdx,%rdx
    9efb:	74 96                	je     9e93 <fwp_hof0.constprop.0+0xc13>
    9efd:	0f b6 31             	movzbl (%rcx),%esi
    9f00:	40 80 fe 02          	cmp    $0x2,%sil
    9f04:	0f 85 5e ff ff ff    	jne    9e68 <fwp_hof0.constprop.0+0xbe8>
    9f0a:	66 85 c0             	test   %ax,%ax
    9f0d:	0f 84 74 ff ff ff    	je     9e87 <fwp_hof0.constprop.0+0xc07>
    9f13:	4d 39 e7             	cmp    %r12,%r15
    9f16:	72 84                	jb     9e9c <fwp_hof0.constprop.0+0xc1c>
    9f18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f1f:	00 
    9f20:	4d 85 ff             	test   %r15,%r15
    9f23:	75 2e                	jne    9f53 <fwp_hof0.constprop.0+0xcd3>
    9f25:	8b 44 24 10          	mov    0x10(%rsp),%eax
    9f29:	85 c0                	test   %eax,%eax
    9f2b:	49 0f 45 df          	cmovne %r15,%rbx
    9f2f:	eb 62                	jmp    9f93 <fwp_hof0.constprop.0+0xd13>
    9f31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9f38:	66 85 d2             	test   %dx,%dx
    9f3b:	0f 84 06 ff ff ff    	je     9e47 <fwp_hof0.constprop.0+0xbc7>
    9f41:	49 39 c7             	cmp    %rax,%r15
    9f44:	0f 82 0b ff ff ff    	jb     9e55 <fwp_hof0.constprop.0+0xbd5>
    9f4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9f50:	45 31 f6             	xor    %r14d,%r14d
    9f53:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    9f58:	48 89 da             	mov    %rbx,%rdx
    9f5b:	4e 8d 0c fb          	lea    (%rbx,%r15,8),%r9
    9f5f:	90                   	nop
    9f60:	48 8b 0a             	mov    (%rdx),%rcx
    9f63:	48 83 c2 08          	add    $0x8,%rdx
    9f67:	48 89 c7             	mov    %rax,%rdi
    9f6a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    9f6e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9f72:	4c 39 ca             	cmp    %r9,%rdx
    9f75:	75 e9                	jne    9f60 <fwp_hof0.constprop.0+0xce0>
    9f77:	8b 54 24 10          	mov    0x10(%rsp),%edx
    9f7b:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    9f7f:	85 d2                	test   %edx,%edx
    9f81:	0f 84 69 07 00 00    	je     a6f0 <fwp_hof0.constprop.0+0x1470>
    9f87:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
    9f8c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9f91:	31 db                	xor    %ebx,%ebx
    9f93:	48 89 df             	mov    %rbx,%rdi
    9f96:	e8 f5 b7 ff ff       	call   5790 <fwp_mem_free>
    9f9b:	48 8b 3c 24          	mov    (%rsp),%rdi
    9f9f:	e8 4c db ff ff       	call   7af0 <fwp_drop10>
    9fa4:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9fab:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    9fb0:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9fb7:	48 c1 e2 10          	shl    $0x10,%rdx
    9fbb:	48 39 d0             	cmp    %rdx,%rax
    9fbe:	73 70                	jae    a030 <fwp_hof0.constprop.0+0xdb0>
    9fc0:	48 89 c2             	mov    %rax,%rdx
    9fc3:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    9fca:	48 c1 ea 10          	shr    $0x10,%rdx
    9fce:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    9fd2:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    9fd6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9fda:	48 85 ed             	test   %rbp,%rbp
    9fdd:	74 51                	je     a030 <fwp_hof0.constprop.0+0xdb0>
    9fdf:	0f b6 0a             	movzbl (%rdx),%ecx
    9fe2:	80 f9 02             	cmp    $0x2,%cl
    9fe5:	0f 84 8d 06 00 00    	je     a678 <fwp_hof0.constprop.0+0x13f8>
    9feb:	80 f9 01             	cmp    $0x1,%cl
    9fee:	75 40                	jne    a030 <fwp_hof0.constprop.0+0xdb0>
    9ff0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ff3:	0f b7 c0             	movzwl %ax,%eax
    9ff6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ff9:	48 0f af c1          	imul   %rcx,%rax
    9ffd:	48 c1 e8 20          	shr    $0x20,%rax
    a001:	48 39 d0             	cmp    %rdx,%rax
    a004:	73 2a                	jae    a030 <fwp_hof0.constprop.0+0xdb0>
    a006:	48 01 c5             	add    %rax,%rbp
    a009:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a00d:	84 c0                	test   %al,%al
    a00f:	74 1f                	je     a030 <fwp_hof0.constprop.0+0xdb0>
    a011:	3c 01                	cmp    $0x1,%al
    a013:	0f 84 e7 06 00 00    	je     a700 <fwp_hof0.constprop.0+0x1480>
    a019:	3c ff                	cmp    $0xff,%al
    a01b:	0f 84 b8 08 00 00    	je     a8d9 <fwp_hof0.constprop.0+0x1659>
    a021:	83 e8 01             	sub    $0x1,%eax
    a024:	88 45 00             	mov    %al,0x0(%rbp)
    a027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a02e:	00 00 
    a030:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
    a036:	0f 85 f4 04 00 00    	jne    a530 <fwp_hof0.constprop.0+0x12b0>
    a03c:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    a041:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a045:	4c 89 f6             	mov    %r14,%rsi
    a048:	4c 89 f5             	mov    %r14,%rbp
    a04b:	b9 01 00 00 00       	mov    $0x1,%ecx
    a050:	48 8d 15 29 8b 00 00 	lea    0x8b29(%rip),%rdx        # 12b80 <d0>
    a057:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a05e:	00 00 00 00 00 
    a063:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    a06a:	00 
    a06b:	e8 d0 e1 ff ff       	call   8240 <fwp_write>
    a070:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    a077:	00 
    a078:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
    a07f:	00 
    a080:	48 8d 05 0a 50 00 00 	lea    0x500a(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    a087:	48 85 c9             	test   %rcx,%rcx
    a08a:	48 0f 44 c8          	cmove  %rax,%rcx
    a08e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a092:	0f 87 6f 0a 00 00    	ja     ab07 <fwp_hof0.constprop.0+0x1887>
    a098:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a09c:	be 01 00 00 00       	mov    $0x1,%esi
    a0a1:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    a0a6:	e8 e5 bb ff ff       	call   5c90 <fwp_heap_alloc>
    a0ab:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    a0b0:	4c 89 fa             	mov    %r15,%rdx
    a0b3:	4c 89 38             	mov    %r15,(%rax)
    a0b6:	4c 8d 70 08          	lea    0x8(%rax),%r14
    a0ba:	48 89 c3             	mov    %rax,%rbx
    a0bd:	4c 89 f7             	mov    %r14,%rdi
    a0c0:	e8 db 94 ff ff       	call   35a0 <memcpy@plt>
    a0c5:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a0cb:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    a0d2:	00 
    a0d3:	e8 e8 92 ff ff       	call   33c0 <free@plt>
    a0d8:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a0df:	48 89 d8             	mov    %rbx,%rax
    a0e2:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a0e9:	48 c1 e2 10          	shl    $0x10,%rdx
    a0ed:	48 39 d0             	cmp    %rdx,%rax
    a0f0:	73 57                	jae    a149 <fwp_hof0.constprop.0+0xec9>
    a0f2:	48 89 c2             	mov    %rax,%rdx
    a0f5:	48 c1 ea 10          	shr    $0x10,%rdx
    a0f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a0fd:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a104:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a108:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a10c:	4d 85 ff             	test   %r15,%r15
    a10f:	74 38                	je     a149 <fwp_hof0.constprop.0+0xec9>
    a111:	0f b6 0a             	movzbl (%rdx),%ecx
    a114:	80 f9 02             	cmp    $0x2,%cl
    a117:	0f 84 e3 06 00 00    	je     a800 <fwp_hof0.constprop.0+0x1580>
    a11d:	80 f9 01             	cmp    $0x1,%cl
    a120:	75 27                	jne    a149 <fwp_hof0.constprop.0+0xec9>
    a122:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a125:	0f b7 c0             	movzwl %ax,%eax
    a128:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a12b:	48 0f af c1          	imul   %rcx,%rax
    a12f:	48 c1 e8 20          	shr    $0x20,%rax
    a133:	48 39 d0             	cmp    %rdx,%rax
    a136:	73 11                	jae    a149 <fwp_hof0.constprop.0+0xec9>
    a138:	49 01 c7             	add    %rax,%r15
    a13b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a13f:	0f 84 ce 06 00 00    	je     a813 <fwp_hof0.constprop.0+0x1593>
    a145:	41 c6 07 01          	movb   $0x1,(%r15)
    a149:	48 89 ef             	mov    %rbp,%rdi
    a14c:	e8 af d5 ff ff       	call   7700 <fwp_drop0>
    a151:	48 8b 13             	mov    (%rbx),%rdx
    a154:	be 01 00 00 00       	mov    $0x1,%esi
    a159:	4c 89 f7             	mov    %r14,%rdi
    a15c:	48 8b 0d bd b2 01 00 	mov    0x1b2bd(%rip),%rcx        # 25420 <fwp_prog_out>
    a163:	e8 18 95 ff ff       	call   3680 <fwrite@plt>
    a168:	48 8b 35 b1 b2 01 00 	mov    0x1b2b1(%rip),%rsi        # 25420 <fwp_prog_out>
    a16f:	bf 0a 00 00 00       	mov    $0xa,%edi
    a174:	e8 67 93 ff ff       	call   34e0 <fputc@plt>
    a179:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a180:	48 89 d8             	mov    %rbx,%rax
    a183:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a18a:	48 c1 e2 10          	shl    $0x10,%rdx
    a18e:	48 39 d0             	cmp    %rdx,%rax
    a191:	73 6d                	jae    a200 <fwp_hof0.constprop.0+0xf80>
    a193:	48 89 c2             	mov    %rax,%rdx
    a196:	48 c1 ea 10          	shr    $0x10,%rdx
    a19a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a19e:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a1a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1a9:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a1ad:	48 85 ed             	test   %rbp,%rbp
    a1b0:	74 4e                	je     a200 <fwp_hof0.constprop.0+0xf80>
    a1b2:	0f b6 0a             	movzbl (%rdx),%ecx
    a1b5:	80 f9 02             	cmp    $0x2,%cl
    a1b8:	0f 84 62 06 00 00    	je     a820 <fwp_hof0.constprop.0+0x15a0>
    a1be:	80 f9 01             	cmp    $0x1,%cl
    a1c1:	75 3d                	jne    a200 <fwp_hof0.constprop.0+0xf80>
    a1c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1c6:	0f b7 c0             	movzwl %ax,%eax
    a1c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1cc:	48 0f af c1          	imul   %rcx,%rax
    a1d0:	48 c1 e8 20          	shr    $0x20,%rax
    a1d4:	48 39 d0             	cmp    %rdx,%rax
    a1d7:	73 27                	jae    a200 <fwp_hof0.constprop.0+0xf80>
    a1d9:	48 01 c5             	add    %rax,%rbp
    a1dc:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a1e0:	84 c0                	test   %al,%al
    a1e2:	74 1c                	je     a200 <fwp_hof0.constprop.0+0xf80>
    a1e4:	3c 01                	cmp    $0x1,%al
    a1e6:	0f 84 51 06 00 00    	je     a83d <fwp_hof0.constprop.0+0x15bd>
    a1ec:	3c ff                	cmp    $0xff,%al
    a1ee:	0f 84 51 07 00 00    	je     a945 <fwp_hof0.constprop.0+0x16c5>
    a1f4:	83 e8 01             	sub    $0x1,%eax
    a1f7:	88 45 00             	mov    %al,0x0(%rbp)
    a1fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a200:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    a205:	48 8b 40 10          	mov    0x10(%rax),%rax
    a209:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a20e:	48 85 c0             	test   %rax,%rax
    a211:	0f 85 a9 f0 ff ff    	jne    92c0 <fwp_hof0.constprop.0+0x40>
    a217:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    a21e:	00 
    a21f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a226:	00 00 
    a228:	0f 85 d4 08 00 00    	jne    ab02 <fwp_hof0.constprop.0+0x1882>
    a22e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    a235:	31 c0                	xor    %eax,%eax
    a237:	5b                   	pop    %rbx
    a238:	5d                   	pop    %rbp
    a239:	41 5c                	pop    %r12
    a23b:	41 5d                	pop    %r13
    a23d:	41 5e                	pop    %r14
    a23f:	41 5f                	pop    %r15
    a241:	c3                   	ret
    a242:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a248:	66 85 c9             	test   %cx,%cx
    a24b:	0f 84 e3 fa ff ff    	je     9d34 <fwp_hof0.constprop.0+0xab4>
    a251:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
    a257:	0f 84 74 02 00 00    	je     a4d1 <fwp_hof0.constprop.0+0x1251>
    a25d:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    a262:	45 31 f6             	xor    %r14d,%r14d
    a265:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a26c:	00 00 00 00 
    a270:	48 8b 40 10          	mov    0x10(%rax),%rax
    a274:	4c 89 f2             	mov    %r14,%rdx
    a277:	49 83 c6 01          	add    $0x1,%r14
    a27b:	48 85 c0             	test   %rax,%rax
    a27e:	75 f0                	jne    a270 <fwp_hof0.constprop.0+0xff0>
    a280:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a287:	ff ff 1f 
    a28a:	4c 39 f0             	cmp    %r14,%rax
    a28d:	0f 82 bd 07 00 00    	jb     aa50 <fwp_hof0.constprop.0+0x17d0>
    a293:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a29a:	00 
    a29b:	be 02 00 00 00       	mov    $0x2,%esi
    a2a0:	e8 eb b9 ff ff       	call   5c90 <fwp_heap_alloc>
    a2a5:	4d 39 f7             	cmp    %r14,%r15
    a2a8:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    a2ad:	48 89 c3             	mov    %rax,%rbx
    a2b0:	4c 89 f0             	mov    %r14,%rax
    a2b3:	49 0f 46 c7          	cmovbe %r15,%rax
    a2b7:	48 89 d9             	mov    %rbx,%rcx
    a2ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2c0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a2c4:	48 83 c1 08          	add    $0x8,%rcx
    a2c8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a2cc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a2d0:	48 85 d2             	test   %rdx,%rdx
    a2d3:	75 eb                	jne    a2c0 <fwp_hof0.constprop.0+0x1040>
    a2d5:	48 85 c0             	test   %rax,%rax
    a2d8:	0f 84 05 02 00 00    	je     a4e3 <fwp_hof0.constprop.0+0x1263>
    a2de:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    a2e5:	00 
    a2e6:	e9 71 fa ff ff       	jmp    9d5c <fwp_hof0.constprop.0+0xadc>
    a2eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a2f0:	48 83 3d 90 8d 01 00 	cmpq   $0x0,0x18d90(%rip)        # 23088 <fwp_tape_cached_bytes>
    a2f7:	00 
    a2f8:	0f 84 b8 f2 ff ff    	je     95b6 <fwp_hof0.constprop.0+0x336>
    a2fe:	66 0f 6f 0d 9a 8d 01 	movdqa 0x18d9a(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a305:	00 
    a306:	48 c7 05 77 8d 01 00 	movq   $0x0,0x18d77(%rip)        # 23088 <fwp_tape_cached_bytes>
    a30d:	00 00 00 00 
    a311:	0f 11 49 20          	movups %xmm1,0x20(%rcx)
    a315:	48 8b 05 a4 8d 01 00 	mov    0x18da4(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a31c:	66 0f 6f 0d 8c 8d 01 	movdqa 0x18d8c(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    a323:	00 
    a324:	48 89 41 40          	mov    %rax,0x40(%rcx)
    a328:	48 8b 05 99 8d 01 00 	mov    0x18d99(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    a32f:	0f 11 49 30          	movups %xmm1,0x30(%rcx)
    a333:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a337:	48 89 41 18          	mov    %rax,0x18(%rcx)
    a33b:	48 8b 05 8e 8d 01 00 	mov    0x18d8e(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    a342:	0f 29 0d 57 8d 01 00 	movaps %xmm1,0x18d57(%rip)        # 230a0 <fwp_tape_workspace>
    a349:	48 89 41 48          	mov    %rax,0x48(%rcx)
    a34d:	0f 29 0d 5c 8d 01 00 	movaps %xmm1,0x18d5c(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a354:	48 c7 05 71 8d 01 00 	movq   $0x0,0x18d71(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    a35b:	00 00 00 00 
    a35f:	0f 29 0d 5a 8d 01 00 	movaps %xmm1,0x18d5a(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a366:	e9 4b f2 ff ff       	jmp    95b6 <fwp_hof0.constprop.0+0x336>
    a36b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a370:	66 85 c0             	test   %ax,%ax
    a373:	0f 84 a4 f8 ff ff    	je     9c1d <fwp_hof0.constprop.0+0x99d>
    a379:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a380:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a387:	ff ff 1f 
    a38a:	4c 39 f0             	cmp    %r14,%rax
    a38d:	0f 82 b1 06 00 00    	jb     aa44 <fwp_hof0.constprop.0+0x17c4>
    a393:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a39a:	00 
    a39b:	be 01 00 00 00       	mov    $0x1,%esi
    a3a0:	e8 eb b8 ff ff       	call   5c90 <fwp_heap_alloc>
    a3a5:	4c 89 30             	mov    %r14,(%rax)
    a3a8:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a3af:	48 89 c5             	mov    %rax,%rbp
    a3b2:	48 89 04 24          	mov    %rax,(%rsp)
    a3b6:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a3bd:	48 c1 e2 10          	shl    $0x10,%rdx
    a3c1:	48 39 d0             	cmp    %rdx,%rax
    a3c4:	73 57                	jae    a41d <fwp_hof0.constprop.0+0x119d>
    a3c6:	48 89 c2             	mov    %rax,%rdx
    a3c9:	48 c1 ea 10          	shr    $0x10,%rdx
    a3cd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a3d1:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a3d8:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a3dc:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    a3e0:	48 85 db             	test   %rbx,%rbx
    a3e3:	74 38                	je     a41d <fwp_hof0.constprop.0+0x119d>
    a3e5:	0f b6 31             	movzbl (%rcx),%esi
    a3e8:	40 80 fe 02          	cmp    $0x2,%sil
    a3ec:	0f 84 b6 03 00 00    	je     a7a8 <fwp_hof0.constprop.0+0x1528>
    a3f2:	40 80 fe 01          	cmp    $0x1,%sil
    a3f6:	75 25                	jne    a41d <fwp_hof0.constprop.0+0x119d>
    a3f8:	8b 71 18             	mov    0x18(%rcx),%esi
    a3fb:	0f b7 c0             	movzwl %ax,%eax
    a3fe:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a401:	48 0f af c6          	imul   %rsi,%rax
    a405:	48 c1 e8 20          	shr    $0x20,%rax
    a409:	48 39 c8             	cmp    %rcx,%rax
    a40c:	73 0f                	jae    a41d <fwp_hof0.constprop.0+0x119d>
    a40e:	48 01 c3             	add    %rax,%rbx
    a411:	80 3b ff             	cmpb   $0xff,(%rbx)
    a414:	0f 84 a0 03 00 00    	je     a7ba <fwp_hof0.constprop.0+0x153a>
    a41a:	c6 03 01             	movb   $0x1,(%rbx)
    a41d:	4c 89 ff             	mov    %r15,%rdi
    a420:	e9 0a f8 ff ff       	jmp    9c2f <fwp_hof0.constprop.0+0x9af>
    a425:	0f 1f 00             	nopl   (%rax)
    a428:	48 89 d7             	mov    %rdx,%rdi
    a42b:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    a430:	e8 1b b1 ff ff       	call   5550 <fwp_rc_forget_slot>
    a435:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    a43a:	e9 51 fa ff ff       	jmp    9e90 <fwp_hof0.constprop.0+0xc10>
    a43f:	90                   	nop
    a440:	44 89 f2             	mov    %r14d,%edx
    a443:	be 02 00 00 00       	mov    $0x2,%esi
    a448:	bf 08 00 00 00       	mov    $0x8,%edi
    a44d:	48 c1 e2 10          	shl    $0x10,%rdx
    a451:	48 09 d5             	or     %rdx,%rbp
    a454:	e8 37 b8 ff ff       	call   5c90 <fwp_heap_alloc>
    a459:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a460:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a467:	49 89 c6             	mov    %rax,%r14
    a46a:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a471:	48 c1 e2 10          	shl    $0x10,%rdx
    a475:	48 39 d0             	cmp    %rdx,%rax
    a478:	0f 83 82 00 00 00    	jae    a500 <fwp_hof0.constprop.0+0x1280>
    a47e:	48 89 c2             	mov    %rax,%rdx
    a481:	48 c1 ea 10          	shr    $0x10,%rdx
    a485:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a489:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a490:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a494:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a498:	4d 85 ff             	test   %r15,%r15
    a49b:	0f 84 13 f3 ff ff    	je     97b4 <fwp_hof0.constprop.0+0x534>
    a4a1:	0f b6 32             	movzbl (%rdx),%esi
    a4a4:	45 31 e4             	xor    %r12d,%r12d
    a4a7:	40 80 fe 02          	cmp    $0x2,%sil
    a4ab:	0f 85 69 f2 ff ff    	jne    971a <fwp_hof0.constprop.0+0x49a>
    a4b1:	66 85 c0             	test   %ax,%ax
    a4b4:	0f 85 8d f2 ff ff    	jne    9747 <fwp_hof0.constprop.0+0x4c7>
    a4ba:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a4be:	0f 85 7f f2 ff ff    	jne    9743 <fwp_hof0.constprop.0+0x4c3>
    a4c4:	4c 89 ff             	mov    %r15,%rdi
    a4c7:	e8 84 b0 ff ff       	call   5550 <fwp_rc_forget_slot>
    a4cc:	e9 72 f2 ff ff       	jmp    9743 <fwp_hof0.constprop.0+0x4c3>
    a4d1:	be 02 00 00 00       	mov    $0x2,%esi
    a4d6:	bf 08 00 00 00       	mov    $0x8,%edi
    a4db:	e8 b0 b7 ff ff       	call   5c90 <fwp_heap_alloc>
    a4e0:	48 89 c3             	mov    %rax,%rbx
    a4e3:	45 31 f6             	xor    %r14d,%r14d
    a4e6:	e9 a8 fa ff ff       	jmp    9f93 <fwp_hof0.constprop.0+0xd13>
    a4eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4f0:	4d 85 e4             	test   %r12,%r12
    a4f3:	0f 85 53 f2 ff ff    	jne    974c <fwp_hof0.constprop.0+0x4cc>
    a4f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a500:	31 d2                	xor    %edx,%edx
    a502:	e9 1b f3 ff ff       	jmp    9822 <fwp_hof0.constprop.0+0x5a2>
    a507:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a50e:	00 00 
    a510:	49 39 d4             	cmp    %rdx,%r12
    a513:	0f 84 a7 ef ff ff    	je     94c0 <fwp_hof0.constprop.0+0x240>
    a519:	4c 8b 0d d0 8b 01 00 	mov    0x18bd0(%rip),%r9        # 230f0 <fwp_tapes>
    a520:	49 89 d4             	mov    %rdx,%r12
    a523:	48 8d 6a 01          	lea    0x1(%rdx),%rbp
    a527:	e9 32 f0 ff ff       	jmp    955e <fwp_hof0.constprop.0+0x2de>
    a52c:	0f 1f 40 00          	nopl   0x0(%rax)
    a530:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a535:	45 31 c0             	xor    %r8d,%r8d
    a538:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
    a53d:	48 83 e8 01          	sub    $0x1,%rax
    a541:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a546:	41 0f 90 c0          	seto   %r8b
    a54a:	e9 00 ee ff ff       	jmp    934f <fwp_hof0.constprop.0+0xcf>
    a54f:	90                   	nop
    a550:	49 8d 6a 01          	lea    0x1(%r10),%rbp
    a554:	48 39 ea             	cmp    %rbp,%rdx
    a557:	7c 42                	jl     a59b <fwp_hof0.constprop.0+0x131b>
    a559:	4d 85 e4             	test   %r12,%r12
    a55c:	0f 84 13 05 00 00    	je     aa75 <fwp_hof0.constprop.0+0x17f5>
    a562:	49 89 eb             	mov    %rbp,%r11
    a565:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    a56c:	00 
    a56d:	31 f6                	xor    %esi,%esi
    a56f:	4c 89 e7             	mov    %r12,%rdi
    a572:	4d 29 f3             	sub    %r14,%r11
    a575:	4c 89 54 24 68       	mov    %r10,0x68(%rsp)
    a57a:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
    a57f:	e8 3c 8f ff ff       	call   34c0 <memset@plt>
    a584:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    a589:	4c 8b 54 24 68       	mov    0x68(%rsp),%r10
    a58e:	e9 2a f4 ff ff       	jmp    99bd <fwp_hof0.constprop.0+0x73d>
    a593:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a598:	4c 89 f5             	mov    %r14,%rbp
    a59b:	48 85 d2             	test   %rdx,%rdx
    a59e:	48 0f 44 d5          	cmove  %rbp,%rdx
    a5a2:	eb 31                	jmp    a5d5 <fwp_hof0.constprop.0+0x1355>
    a5a4:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a5b1:	00 00 00 00 
    a5b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a5bc:	00 00 00 00 
    a5c0:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    a5c4:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    a5cb:	48 89 e8             	mov    %rbp,%rax
    a5ce:	48 0f 4c c1          	cmovl  %rcx,%rax
    a5d2:	48 89 c2             	mov    %rax,%rdx
    a5d5:	48 39 ea             	cmp    %rbp,%rdx
    a5d8:	7c e6                	jl     a5c0 <fwp_hof0.constprop.0+0x1340>
    a5da:	4d 85 e4             	test   %r12,%r12
    a5dd:	0f 84 ed 01 00 00    	je     a7d0 <fwp_hof0.constprop.0+0x1550>
    a5e3:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    a5ea:	00 
    a5eb:	4c 89 e7             	mov    %r12,%rdi
    a5ee:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
    a5f3:	e8 d8 8f ff ff       	call   35d0 <realloc@plt>
    a5f8:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    a5fd:	49 89 c4             	mov    %rax,%r12
    a600:	4d 85 e4             	test   %r12,%r12
    a603:	0f 84 63 04 00 00    	je     aa6c <fwp_hof0.constprop.0+0x17ec>
    a609:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    a610:	00 
    a611:	48 89 94 24 f0 00 00 	mov    %rdx,0xf0(%rsp)
    a618:	00 
    a619:	48 85 ed             	test   %rbp,%rbp
    a61c:	0f 85 56 03 00 00    	jne    a978 <fwp_hof0.constprop.0+0x16f8>
    a622:	4d 89 f3             	mov    %r14,%r11
    a625:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a62c:	49 f7 db             	neg    %r11
    a62f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a634:	48 85 c0             	test   %rax,%rax
    a637:	0f 88 94 f3 ff ff    	js     99d1 <fwp_hof0.constprop.0+0x751>
    a63d:	41 89 c2             	mov    %eax,%r10d
    a640:	e9 78 f3 ff ff       	jmp    99bd <fwp_hof0.constprop.0+0x73d>
    a645:	0f 1f 00             	nopl   (%rax)
    a648:	48 8d 3d 91 c4 ff ff 	lea    -0x3b6f(%rip),%rdi        # 6ae0 <fwp_tape_finish>
    a64f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    a654:	e8 47 3b 00 00       	call   e1a0 <atexit>
    a659:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    a65e:	85 c0                	test   %eax,%eax
    a660:	0f 85 ad 04 00 00    	jne    ab13 <fwp_hof0.constprop.0+0x1893>
    a666:	c7 05 f0 89 00 00 01 	movl   $0x1,0x89f0(%rip)        # 13060 <registered_finish.1>
    a66d:	00 00 00 
    a670:	e9 ff ed ff ff       	jmp    9474 <fwp_hof0.constprop.0+0x1f4>
    a675:	0f 1f 00             	nopl   (%rax)
    a678:	66 85 c0             	test   %ax,%ax
    a67b:	0f 85 af f9 ff ff    	jne    a030 <fwp_hof0.constprop.0+0xdb0>
    a681:	e9 83 f9 ff ff       	jmp    a009 <fwp_hof0.constprop.0+0xd89>
    a686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a68d:	00 00 00 
    a690:	66 85 c0             	test   %ax,%ax
    a693:	0f 85 89 ed ff ff    	jne    9422 <fwp_hof0.constprop.0+0x1a2>
    a699:	e9 70 ed ff ff       	jmp    940e <fwp_hof0.constprop.0+0x18e>
    a69e:	66 90                	xchg   %ax,%ax
    a6a0:	49 39 d6             	cmp    %rdx,%r14
    a6a3:	0f 8f ef fe ff ff    	jg     a598 <fwp_hof0.constprop.0+0x1318>
    a6a9:	4d 85 f6             	test   %r14,%r14
    a6ac:	74 12                	je     a6c0 <fwp_hof0.constprop.0+0x1440>
    a6ae:	4d 85 e4             	test   %r12,%r12
    a6b1:	0f 84 be 03 00 00    	je     aa75 <fwp_hof0.constprop.0+0x17f5>
    a6b7:	4d 85 f6             	test   %r14,%r14
    a6ba:	0f 85 b5 02 00 00    	jne    a975 <fwp_hof0.constprop.0+0x16f5>
    a6c0:	45 31 db             	xor    %r11d,%r11d
    a6c3:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a6ca:	e9 02 f3 ff ff       	jmp    99d1 <fwp_hof0.constprop.0+0x751>
    a6cf:	90                   	nop
    a6d0:	66 85 c0             	test   %ax,%ax
    a6d3:	0f 85 97 f4 ff ff    	jne    9b70 <fwp_hof0.constprop.0+0x8f0>
    a6d9:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a6dd:	0f 85 89 f4 ff ff    	jne    9b6c <fwp_hof0.constprop.0+0x8ec>
    a6e3:	48 89 ef             	mov    %rbp,%rdi
    a6e6:	e8 65 ae ff ff       	call   5550 <fwp_rc_forget_slot>
    a6eb:	e9 7c f4 ff ff       	jmp    9b6c <fwp_hof0.constprop.0+0x8ec>
    a6f0:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
    a6f5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    a6fa:	e9 94 f8 ff ff       	jmp    9f93 <fwp_hof0.constprop.0+0xd13>
    a6ff:	90                   	nop
    a700:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    a705:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a70c:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a713:	48 8b 58 10          	mov    0x10(%rax),%rbx
    a717:	48 29 c8             	sub    %rcx,%rax
    a71a:	48 c1 e2 10          	shl    $0x10,%rdx
    a71e:	48 39 d0             	cmp    %rdx,%rax
    a721:	73 67                	jae    a78a <fwp_hof0.constprop.0+0x150a>
    a723:	48 89 c7             	mov    %rax,%rdi
    a726:	48 c1 ef 10          	shr    $0x10,%rdi
    a72a:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    a72e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a732:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a736:	48 85 ff             	test   %rdi,%rdi
    a739:	74 4f                	je     a78a <fwp_hof0.constprop.0+0x150a>
    a73b:	44 0f b6 06          	movzbl (%rsi),%r8d
    a73f:	41 80 f8 02          	cmp    $0x2,%r8b
    a743:	0f 84 82 01 00 00    	je     a8cb <fwp_hof0.constprop.0+0x164b>
    a749:	41 80 f8 01          	cmp    $0x1,%r8b
    a74d:	75 3b                	jne    a78a <fwp_hof0.constprop.0+0x150a>
    a74f:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a753:	0f b7 c0             	movzwl %ax,%eax
    a756:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a759:	49 0f af c0          	imul   %r8,%rax
    a75d:	48 c1 e8 20          	shr    $0x20,%rax
    a761:	48 39 f0             	cmp    %rsi,%rax
    a764:	73 24                	jae    a78a <fwp_hof0.constprop.0+0x150a>
    a766:	48 01 c7             	add    %rax,%rdi
    a769:	80 3f 01             	cmpb   $0x1,(%rdi)
    a76c:	75 1c                	jne    a78a <fwp_hof0.constprop.0+0x150a>
    a76e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    a773:	e8 18 b0 ff ff       	call   5790 <fwp_mem_free>
    a778:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a77f:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a786:	48 c1 e2 10          	shl    $0x10,%rdx
    a78a:	48 89 d8             	mov    %rbx,%rax
    a78d:	48 29 c8             	sub    %rcx,%rax
    a790:	48 39 d0             	cmp    %rdx,%rax
    a793:	0f 83 97 f8 ff ff    	jae    a030 <fwp_hof0.constprop.0+0xdb0>
    a799:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
    a79e:	e9 1d f8 ff ff       	jmp    9fc0 <fwp_hof0.constprop.0+0xd40>
    a7a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a7a8:	66 85 c0             	test   %ax,%ax
    a7ab:	0f 85 6c fc ff ff    	jne    a41d <fwp_hof0.constprop.0+0x119d>
    a7b1:	80 3b ff             	cmpb   $0xff,(%rbx)
    a7b4:	0f 85 60 fc ff ff    	jne    a41a <fwp_hof0.constprop.0+0x119a>
    a7ba:	48 89 df             	mov    %rbx,%rdi
    a7bd:	e8 8e ad ff ff       	call   5550 <fwp_rc_forget_slot>
    a7c2:	e9 53 fc ff ff       	jmp    a41a <fwp_hof0.constprop.0+0x119a>
    a7c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a7ce:	00 00 
    a7d0:	48 89 d7             	mov    %rdx,%rdi
    a7d3:	be 08 00 00 00       	mov    $0x8,%esi
    a7d8:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
    a7dd:	e8 3e 8d ff ff       	call   3520 <calloc@plt>
    a7e2:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    a7e7:	49 89 c4             	mov    %rax,%r12
    a7ea:	e9 11 fe ff ff       	jmp    a600 <fwp_hof0.constprop.0+0x1380>
    a7ef:	90                   	nop
    a7f0:	66 85 c0             	test   %ax,%ax
    a7f3:	0f 85 40 eb ff ff    	jne    9339 <fwp_hof0.constprop.0+0xb9>
    a7f9:	e9 27 eb ff ff       	jmp    9325 <fwp_hof0.constprop.0+0xa5>
    a7fe:	66 90                	xchg   %ax,%ax
    a800:	66 85 c0             	test   %ax,%ax
    a803:	0f 85 40 f9 ff ff    	jne    a149 <fwp_hof0.constprop.0+0xec9>
    a809:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a80d:	0f 85 32 f9 ff ff    	jne    a145 <fwp_hof0.constprop.0+0xec5>
    a813:	4c 89 ff             	mov    %r15,%rdi
    a816:	e8 35 ad ff ff       	call   5550 <fwp_rc_forget_slot>
    a81b:	e9 25 f9 ff ff       	jmp    a145 <fwp_hof0.constprop.0+0xec5>
    a820:	66 85 c0             	test   %ax,%ax
    a823:	0f 85 d7 f9 ff ff    	jne    a200 <fwp_hof0.constprop.0+0xf80>
    a829:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a82d:	84 c0                	test   %al,%al
    a82f:	0f 84 cb f9 ff ff    	je     a200 <fwp_hof0.constprop.0+0xf80>
    a835:	3c 01                	cmp    $0x1,%al
    a837:	0f 85 af f9 ff ff    	jne    a1ec <fwp_hof0.constprop.0+0xf6c>
    a83d:	48 89 df             	mov    %rbx,%rdi
    a840:	e8 4b af ff ff       	call   5790 <fwp_mem_free>
    a845:	e9 b6 f9 ff ff       	jmp    a200 <fwp_hof0.constprop.0+0xf80>
    a84a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a850:	be 68 00 00 00       	mov    $0x68,%esi
    a855:	bd 01 00 00 00       	mov    $0x1,%ebp
    a85a:	e9 9b ec ff ff       	jmp    94fa <fwp_hof0.constprop.0+0x27a>
    a85f:	31 ff                	xor    %edi,%edi
    a861:	e8 ea 99 ff ff       	call   4250 <descent_phase_step>
    a866:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a86a:	e9 f7 eb ff ff       	jmp    9466 <fwp_hof0.constprop.0+0x1e6>
    a86f:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a873:	48 85 c0             	test   %rax,%rax
    a876:	0f 88 55 fc ff ff    	js     a4d1 <fwp_hof0.constprop.0+0x1251>
    a87c:	49 8b b5 d8 13 00 00 	mov    0x13d8(%r13),%rsi
    a883:	48 8b 0c 24          	mov    (%rsp),%rcx
    a887:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    a88e:	48 c1 e6 10          	shl    $0x10,%rsi
    a892:	48 39 f1             	cmp    %rsi,%rcx
    a895:	0f 83 36 fc ff ff    	jae    a4d1 <fwp_hof0.constprop.0+0x1251>
    a89b:	48 89 ce             	mov    %rcx,%rsi
    a89e:	48 c1 ee 10          	shr    $0x10,%rsi
    a8a2:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a8a6:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    a8ad:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a8b1:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a8b5:	48 85 ff             	test   %rdi,%rdi
    a8b8:	0f 84 13 fc ff ff    	je     a4d1 <fwp_hof0.constprop.0+0x1251>
    a8be:	48 0f ba f0 3f       	btr    $0x3f,%rax
    a8c3:	49 89 c7             	mov    %rax,%r15
    a8c6:	e9 39 f4 ff ff       	jmp    9d04 <fwp_hof0.constprop.0+0xa84>
    a8cb:	66 85 c0             	test   %ax,%ax
    a8ce:	0f 85 b6 fe ff ff    	jne    a78a <fwp_hof0.constprop.0+0x150a>
    a8d4:	e9 90 fe ff ff       	jmp    a769 <fwp_hof0.constprop.0+0x14e9>
    a8d9:	48 89 ea             	mov    %rbp,%rdx
    a8dc:	48 c1 ea 11          	shr    $0x11,%rdx
    a8e0:	48 31 ea             	xor    %rbp,%rdx
    a8e3:	48 89 d0             	mov    %rdx,%rax
    a8e6:	48 c1 e8 09          	shr    $0x9,%rax
    a8ea:	48 31 c2             	xor    %rax,%rdx
    a8ed:	0f b6 d2             	movzbl %dl,%edx
    a8f0:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a8f7:	00 
    a8f8:	48 85 c0             	test   %rax,%rax
    a8fb:	75 0c                	jne    a909 <fwp_hof0.constprop.0+0x1689>
    a8fd:	eb 6a                	jmp    a969 <fwp_hof0.constprop.0+0x16e9>
    a8ff:	90                   	nop
    a900:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a904:	48 85 c0             	test   %rax,%rax
    a907:	74 60                	je     a969 <fwp_hof0.constprop.0+0x16e9>
    a909:	48 89 c2             	mov    %rax,%rdx
    a90c:	48 39 28             	cmp    %rbp,(%rax)
    a90f:	75 ef                	jne    a900 <fwp_hof0.constprop.0+0x1680>
    a911:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a915:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    a919:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a91d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a924:	0f 85 06 f7 ff ff    	jne    a030 <fwp_hof0.constprop.0+0xdb0>
    a92a:	48 89 ef             	mov    %rbp,%rdi
    a92d:	e8 1e ac ff ff       	call   5550 <fwp_rc_forget_slot>
    a932:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a936:	e9 f5 f6 ff ff       	jmp    a030 <fwp_hof0.constprop.0+0xdb0>
    a93b:	e8 f0 aa ff ff       	call   5430 <fwp_rc_wide_dup>
    a940:	e9 dd ea ff ff       	jmp    9422 <fwp_hof0.constprop.0+0x1a2>
    a945:	48 89 e8             	mov    %rbp,%rax
    a948:	48 c1 e8 11          	shr    $0x11,%rax
    a94c:	48 31 e8             	xor    %rbp,%rax
    a94f:	48 89 c2             	mov    %rax,%rdx
    a952:	48 c1 ea 09          	shr    $0x9,%rdx
    a956:	48 31 d0             	xor    %rdx,%rax
    a959:	0f b6 d0             	movzbl %al,%edx
    a95c:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a963:	00 
    a964:	48 85 c0             	test   %rax,%rax
    a967:	75 60                	jne    a9c9 <fwp_hof0.constprop.0+0x1749>
    a969:	48 8d 3d 20 4f 00 00 	lea    0x4f20(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    a970:	e8 7b 9a ff ff       	call   43f0 <fwp_trap>
    a975:	4c 89 f5             	mov    %r14,%rbp
    a978:	49 89 eb             	mov    %rbp,%r11
    a97b:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    a982:	00 
    a983:	31 f6                	xor    %esi,%esi
    a985:	4c 89 e7             	mov    %r12,%rdi
    a988:	4d 29 f3             	sub    %r14,%r11
    a98b:	4c 8d 7d ff          	lea    -0x1(%rbp),%r15
    a98f:	4c 89 5c 24 68       	mov    %r11,0x68(%rsp)
    a994:	e8 27 8b ff ff       	call   34c0 <memset@plt>
    a999:	4c 8b 5c 24 68       	mov    0x68(%rsp),%r11
    a99e:	e9 8c fc ff ff       	jmp    a62f <fwp_hof0.constprop.0+0x13af>
    a9a3:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a9b1:	00 00 00 00 
    a9b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a9bc:	00 00 00 00 
    a9c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a9c4:	48 85 c0             	test   %rax,%rax
    a9c7:	74 a0                	je     a969 <fwp_hof0.constprop.0+0x16e9>
    a9c9:	48 89 c2             	mov    %rax,%rdx
    a9cc:	48 3b 28             	cmp    (%rax),%rbp
    a9cf:	75 ef                	jne    a9c0 <fwp_hof0.constprop.0+0x1740>
    a9d1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a9d5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    a9d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a9dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a9e4:	0f 85 16 f8 ff ff    	jne    a200 <fwp_hof0.constprop.0+0xf80>
    a9ea:	48 89 ef             	mov    %rbp,%rdi
    a9ed:	e8 5e ab ff ff       	call   5550 <fwp_rc_forget_slot>
    a9f2:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a9f6:	e9 05 f8 ff ff       	jmp    a200 <fwp_hof0.constprop.0+0xf80>
    a9fb:	e8 30 aa ff ff       	call   5430 <fwp_rc_wide_dup>
    aa00:	e9 34 e9 ff ff       	jmp    9339 <fwp_hof0.constprop.0+0xb9>
    aa05:	45 31 ff             	xor    %r15d,%r15d
    aa08:	e9 48 f4 ff ff       	jmp    9e55 <fwp_hof0.constprop.0+0xbd5>
    aa0d:	48 8d 3d a4 4e 00 00 	lea    0x4ea4(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    aa14:	e8 d7 99 ff ff       	call   43f0 <fwp_trap>
    aa19:	48 8d 3d 47 47 00 00 	lea    0x4747(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    aa20:	e8 cb 99 ff ff       	call   43f0 <fwp_trap>
    aa25:	48 8d 3d 64 4f 00 00 	lea    0x4f64(%rip),%rdi        # f990 <_IO_stdin_used+0x990>
    aa2c:	e8 bf 99 ff ff       	call   43f0 <fwp_trap>
    aa31:	31 db                	xor    %ebx,%ebx
    aa33:	e9 ab fa ff ff       	jmp    a4e3 <fwp_hof0.constprop.0+0x1263>
    aa38:	48 8d 3d dd 47 00 00 	lea    0x47dd(%rip),%rdi        # f21c <_IO_stdin_used+0x21c>
    aa3f:	e8 ac 99 ff ff       	call   43f0 <fwp_trap>
    aa44:	48 8d 3d eb 47 00 00 	lea    0x47eb(%rip),%rdi        # f236 <_IO_stdin_used+0x236>
    aa4b:	e8 a0 99 ff ff       	call   43f0 <fwp_trap>
    aa50:	48 8d 3d 39 47 00 00 	lea    0x4739(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    aa57:	e8 94 99 ff ff       	call   43f0 <fwp_trap>
    aa5c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa60:	48 8d 3d 51 4f 00 00 	lea    0x4f51(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    aa67:	e8 84 99 ff ff       	call   43f0 <fwp_trap>
    aa6c:	48 85 ed             	test   %rbp,%rbp
    aa6f:	0f 84 ad fb ff ff    	je     a622 <fwp_hof0.constprop.0+0x13a2>
    aa75:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    aa7c:	00 
    aa7d:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    aa82:	48 89 05 cf a9 01 00 	mov    %rax,0x1a9cf(%rip)        # 25458 <fwp_cleanups>
    aa89:	e8 e2 a5 ff ff       	call   5070 <fwp_tape_buffers_release>
    aa8e:	ba 13 00 00 00       	mov    $0x13,%edx
    aa93:	48 8b 0d a6 85 00 00 	mov    0x85a6(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    aa9a:	be 01 00 00 00       	mov    $0x1,%esi
    aa9f:	48 8d 3d 62 45 00 00 	lea    0x4562(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aaa6:	e8 d5 8b ff ff       	call   3680 <fwrite@plt>
    aaab:	31 ff                	xor    %edi,%edi
    aaad:	e8 0e 8b ff ff       	call   35c0 <fflush@plt>
    aab2:	bf 66 00 00 00       	mov    $0x66,%edi
    aab7:	e8 e4 8b ff ff       	call   36a0 <_Exit@plt>
    aabc:	48 8d 3d 9d 4e 00 00 	lea    0x4e9d(%rip),%rdi        # f960 <_IO_stdin_used+0x960>
    aac3:	e8 28 99 ff ff       	call   43f0 <fwp_trap>
    aac8:	48 8b 0d 71 85 00 00 	mov    0x8571(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    aacf:	ba 13 00 00 00       	mov    $0x13,%edx
    aad4:	be 01 00 00 00       	mov    $0x1,%esi
    aad9:	48 8d 3d 28 45 00 00 	lea    0x4528(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aae0:	e8 9b 8b ff ff       	call   3680 <fwrite@plt>
    aae5:	31 ff                	xor    %edi,%edi
    aae7:	e8 d4 8a ff ff       	call   35c0 <fflush@plt>
    aaec:	bf 66 00 00 00       	mov    $0x66,%edi
    aaf1:	e8 aa 8b ff ff       	call   36a0 <_Exit@plt>
    aaf6:	48 8d 3d 03 4e 00 00 	lea    0x4e03(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    aafd:	e8 ee 98 ff ff       	call   43f0 <fwp_trap>
    ab02:	e8 59 89 ff ff       	call   3460 <__stack_chk_fail@plt>
    ab07:	48 8d 3d 38 47 00 00 	lea    0x4738(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    ab0e:	e8 dd 98 ff ff       	call   43f0 <fwp_trap>
    ab13:	48 8b 0d 26 85 00 00 	mov    0x8526(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ab1a:	ba 13 00 00 00       	mov    $0x13,%edx
    ab1f:	be 01 00 00 00       	mov    $0x1,%esi
    ab24:	48 8d 3d dd 44 00 00 	lea    0x44dd(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    ab2b:	e8 50 8b ff ff       	call   3680 <fwrite@plt>
    ab30:	31 ff                	xor    %edi,%edi
    ab32:	e8 89 8a ff ff       	call   35c0 <fflush@plt>
    ab37:	bf 66 00 00 00       	mov    $0x66,%edi
    ab3c:	e8 5f 8b ff ff       	call   36a0 <_Exit@plt>
    ab41:	0f 1f 40 00          	nopl   0x0(%rax)
    ab45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab4c:	00 00 00 00 

000000000000ab50 <f0>:
    ab50:	41 56                	push   %r14
    ab52:	4c 8d 35 67 8c 01 00 	lea    0x18c67(%rip),%r14        # 237c0 <fwp_heap>
    ab59:	41 55                	push   %r13
    ab5b:	41 54                	push   %r12
    ab5d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    ab63:	55                   	push   %rbp
    ab64:	53                   	push   %rbx
    ab65:	31 db                	xor    %ebx,%ebx
    ab67:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    ab6e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ab75:	00 00 
    ab77:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    ab7e:	00 
    ab7f:	31 c0                	xor    %eax,%eax
    ab81:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    ab88:	00 
    ab89:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    ab90:	00 00 
    ab92:	66 48 0f 6e c0       	movq   %rax,%xmm0
    ab97:	48 8d 05 52 cd ff ff 	lea    -0x32ae(%rip),%rax        # 78f0 <fwp_drop1>
    ab9e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    aba3:	48 8b 05 ae a8 01 00 	mov    0x1a8ae(%rip),%rax        # 25458 <fwp_cleanups>
    abaa:	48 89 25 a7 a8 01 00 	mov    %rsp,0x1a8a7(%rip)        # 25458 <fwp_cleanups>
    abb1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    abb5:	48 89 04 24          	mov    %rax,(%rsp)
    abb9:	48 8d 05 10 90 ff ff 	lea    -0x6ff0(%rip),%rax        # 3bd0 <fwp_range_release>
    abc0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    abc5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    abca:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    abcf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    abd4:	eb 47                	jmp    ac1d <f0+0xcd>
    abd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    abdd:	00 00 00 
    abe0:	80 f9 01             	cmp    $0x1,%cl
    abe3:	75 29                	jne    ac0e <f0+0xbe>
    abe5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    abe8:	0f b7 c0             	movzwl %ax,%eax
    abeb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    abee:	48 0f af c1          	imul   %rcx,%rax
    abf2:	48 c1 e8 20          	shr    $0x20,%rax
    abf6:	48 39 d0             	cmp    %rdx,%rax
    abf9:	73 13                	jae    ac0e <f0+0xbe>
    abfb:	49 01 c5             	add    %rax,%r13
    abfe:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    ac03:	0f 84 c7 27 00 00    	je     d3d0 <f0+0x2880>
    ac09:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    ac0e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    ac13:	49 83 ec 01          	sub    $0x1,%r12
    ac17:	0f 82 83 00 00 00    	jb     aca0 <f0+0x150>
    ac1d:	48 89 ee             	mov    %rbp,%rsi
    ac20:	bf 01 00 00 00       	mov    $0x1,%edi
    ac25:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    ac2c:	00 
    ac2d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    ac32:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    ac39:	00 
    ac3a:	e8 71 b1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ac3f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    ac46:	48 89 c3             	mov    %rax,%rbx
    ac49:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    ac50:	48 c1 e2 10          	shl    $0x10,%rdx
    ac54:	48 39 d0             	cmp    %rdx,%rax
    ac57:	73 b5                	jae    ac0e <f0+0xbe>
    ac59:	48 89 c2             	mov    %rax,%rdx
    ac5c:	48 c1 ea 10          	shr    $0x10,%rdx
    ac60:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac64:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    ac6b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac6f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    ac73:	4d 85 ed             	test   %r13,%r13
    ac76:	74 96                	je     ac0e <f0+0xbe>
    ac78:	0f b6 0a             	movzbl (%rdx),%ecx
    ac7b:	80 f9 02             	cmp    $0x2,%cl
    ac7e:	0f 85 5c ff ff ff    	jne    abe0 <f0+0x90>
    ac84:	66 85 c0             	test   %ax,%ax
    ac87:	0f 84 71 ff ff ff    	je     abfe <f0+0xae>
    ac8d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    ac92:	49 83 ec 01          	sub    $0x1,%r12
    ac96:	73 85                	jae    ac1d <f0+0xcd>
    ac98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ac9f:	00 
    aca0:	48 8b 04 24          	mov    (%rsp),%rax
    aca4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    aca9:	bf 01 00 00 00       	mov    $0x1,%edi
    acae:	66 0f 6f 05 8a 4f 00 	movdqa 0x4f8a(%rip),%xmm0        # fc40 <msg.4+0xd0>
    acb5:	00 
    acb6:	48 89 05 9b a7 01 00 	mov    %rax,0x1a79b(%rip)        # 25458 <fwp_cleanups>
    acbd:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    acc2:	e8 e9 b0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    acc7:	48 8b 15 ca 9e 01 00 	mov    0x19eca(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    acce:	49 89 c5             	mov    %rax,%r13
    acd1:	48 2b 05 98 9e 01 00 	sub    0x19e98(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    acd8:	48 c1 e2 10          	shl    $0x10,%rdx
    acdc:	48 39 d0             	cmp    %rdx,%rax
    acdf:	73 59                	jae    ad3a <f0+0x1ea>
    ace1:	48 89 c2             	mov    %rax,%rdx
    ace4:	48 c1 ea 10          	shr    $0x10,%rdx
    ace8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    acec:	48 8b 15 c5 9e 01 00 	mov    0x19ec5(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    acf3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    acf7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    acfb:	4d 85 e4             	test   %r12,%r12
    acfe:	74 3a                	je     ad3a <f0+0x1ea>
    ad00:	0f b6 0a             	movzbl (%rdx),%ecx
    ad03:	80 f9 02             	cmp    $0x2,%cl
    ad06:	0f 84 74 27 00 00    	je     d480 <f0+0x2930>
    ad0c:	80 f9 01             	cmp    $0x1,%cl
    ad0f:	75 29                	jne    ad3a <f0+0x1ea>
    ad11:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad14:	0f b7 c0             	movzwl %ax,%eax
    ad17:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad1a:	48 0f af c1          	imul   %rcx,%rax
    ad1e:	48 c1 e8 20          	shr    $0x20,%rax
    ad22:	48 39 d0             	cmp    %rdx,%rax
    ad25:	73 13                	jae    ad3a <f0+0x1ea>
    ad27:	49 01 c4             	add    %rax,%r12
    ad2a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ad2f:	0f 84 26 29 00 00    	je     d65b <f0+0x2b0b>
    ad35:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ad3a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    ad3f:	bf 01 00 00 00       	mov    $0x1,%edi
    ad44:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    ad49:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ad50:	00 f0 3f 
    ad53:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    ad58:	e8 53 b0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ad5d:	48 8b 15 34 9e 01 00 	mov    0x19e34(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ad64:	49 89 c5             	mov    %rax,%r13
    ad67:	48 2b 05 02 9e 01 00 	sub    0x19e02(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ad6e:	48 c1 e2 10          	shl    $0x10,%rdx
    ad72:	48 39 d0             	cmp    %rdx,%rax
    ad75:	73 59                	jae    add0 <f0+0x280>
    ad77:	48 89 c2             	mov    %rax,%rdx
    ad7a:	48 c1 ea 10          	shr    $0x10,%rdx
    ad7e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad82:	48 8b 15 2f 9e 01 00 	mov    0x19e2f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ad89:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad8d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ad91:	4d 85 e4             	test   %r12,%r12
    ad94:	74 3a                	je     add0 <f0+0x280>
    ad96:	0f b6 0a             	movzbl (%rdx),%ecx
    ad99:	80 f9 02             	cmp    $0x2,%cl
    ad9c:	0f 84 ce 26 00 00    	je     d470 <f0+0x2920>
    ada2:	80 f9 01             	cmp    $0x1,%cl
    ada5:	75 29                	jne    add0 <f0+0x280>
    ada7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    adaa:	0f b7 c0             	movzwl %ax,%eax
    adad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    adb0:	48 0f af c1          	imul   %rcx,%rax
    adb4:	48 c1 e8 20          	shr    $0x20,%rax
    adb8:	48 39 d0             	cmp    %rdx,%rax
    adbb:	73 13                	jae    add0 <f0+0x280>
    adbd:	49 01 c4             	add    %rax,%r12
    adc0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    adc5:	0f 84 9d 28 00 00    	je     d668 <f0+0x2b18>
    adcb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    add0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    add5:	bf 01 00 00 00       	mov    $0x1,%edi
    adda:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    addf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ade6:	33 f3 bf 
    ade9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    adee:	e8 bd af ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    adf3:	48 8b 15 9e 9d 01 00 	mov    0x19d9e(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    adfa:	49 89 c5             	mov    %rax,%r13
    adfd:	48 2b 05 6c 9d 01 00 	sub    0x19d6c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ae04:	48 c1 e2 10          	shl    $0x10,%rdx
    ae08:	48 39 d0             	cmp    %rdx,%rax
    ae0b:	73 59                	jae    ae66 <f0+0x316>
    ae0d:	48 89 c2             	mov    %rax,%rdx
    ae10:	48 c1 ea 10          	shr    $0x10,%rdx
    ae14:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae18:	48 8b 15 99 9d 01 00 	mov    0x19d99(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ae1f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae23:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ae27:	4d 85 e4             	test   %r12,%r12
    ae2a:	74 3a                	je     ae66 <f0+0x316>
    ae2c:	0f b6 0a             	movzbl (%rdx),%ecx
    ae2f:	80 f9 02             	cmp    $0x2,%cl
    ae32:	0f 84 28 26 00 00    	je     d460 <f0+0x2910>
    ae38:	80 f9 01             	cmp    $0x1,%cl
    ae3b:	75 29                	jne    ae66 <f0+0x316>
    ae3d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae40:	0f b7 c0             	movzwl %ax,%eax
    ae43:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae46:	48 0f af c1          	imul   %rcx,%rax
    ae4a:	48 c1 e8 20          	shr    $0x20,%rax
    ae4e:	48 39 d0             	cmp    %rdx,%rax
    ae51:	73 13                	jae    ae66 <f0+0x316>
    ae53:	49 01 c4             	add    %rax,%r12
    ae56:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ae5b:	0f 84 14 28 00 00    	je     d675 <f0+0x2b25>
    ae61:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ae66:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    ae6b:	bf 01 00 00 00       	mov    $0x1,%edi
    ae70:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    ae75:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ae7c:	00 f0 3f 
    ae7f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    ae84:	e8 27 af ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ae89:	48 8b 15 08 9d 01 00 	mov    0x19d08(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ae90:	49 89 c5             	mov    %rax,%r13
    ae93:	48 2b 05 d6 9c 01 00 	sub    0x19cd6(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ae9a:	48 c1 e2 10          	shl    $0x10,%rdx
    ae9e:	48 39 d0             	cmp    %rdx,%rax
    aea1:	73 59                	jae    aefc <f0+0x3ac>
    aea3:	48 89 c2             	mov    %rax,%rdx
    aea6:	48 c1 ea 10          	shr    $0x10,%rdx
    aeaa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aeae:	48 8b 15 03 9d 01 00 	mov    0x19d03(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    aeb5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aeb9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aebd:	4d 85 e4             	test   %r12,%r12
    aec0:	74 3a                	je     aefc <f0+0x3ac>
    aec2:	0f b6 0a             	movzbl (%rdx),%ecx
    aec5:	80 f9 02             	cmp    $0x2,%cl
    aec8:	0f 84 f2 25 00 00    	je     d4c0 <f0+0x2970>
    aece:	80 f9 01             	cmp    $0x1,%cl
    aed1:	75 29                	jne    aefc <f0+0x3ac>
    aed3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aed6:	0f b7 c0             	movzwl %ax,%eax
    aed9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aedc:	48 0f af c1          	imul   %rcx,%rax
    aee0:	48 c1 e8 20          	shr    $0x20,%rax
    aee4:	48 39 d0             	cmp    %rdx,%rax
    aee7:	73 13                	jae    aefc <f0+0x3ac>
    aee9:	49 01 c4             	add    %rax,%r12
    aeec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    aef1:	0f 84 8b 27 00 00    	je     d682 <f0+0x2b32>
    aef7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    aefc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    af03:	33 f3 bf 
    af06:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    af0d:	00 
    af0e:	bf 01 00 00 00       	mov    $0x1,%edi
    af13:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    af1a:	00 
    af1b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    af22:	00 
    af23:	e8 88 ae ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    af28:	48 8b 15 69 9c 01 00 	mov    0x19c69(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    af2f:	49 89 c5             	mov    %rax,%r13
    af32:	48 2b 05 37 9c 01 00 	sub    0x19c37(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    af39:	48 c1 e2 10          	shl    $0x10,%rdx
    af3d:	48 39 d0             	cmp    %rdx,%rax
    af40:	73 59                	jae    af9b <f0+0x44b>
    af42:	48 89 c2             	mov    %rax,%rdx
    af45:	48 c1 ea 10          	shr    $0x10,%rdx
    af49:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af4d:	48 8b 15 64 9c 01 00 	mov    0x19c64(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    af54:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af58:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    af5c:	4d 85 e4             	test   %r12,%r12
    af5f:	74 3a                	je     af9b <f0+0x44b>
    af61:	0f b6 0a             	movzbl (%rdx),%ecx
    af64:	80 f9 02             	cmp    $0x2,%cl
    af67:	0f 84 43 25 00 00    	je     d4b0 <f0+0x2960>
    af6d:	80 f9 01             	cmp    $0x1,%cl
    af70:	75 29                	jne    af9b <f0+0x44b>
    af72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af75:	0f b7 c0             	movzwl %ax,%eax
    af78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af7b:	48 0f af c1          	imul   %rcx,%rax
    af7f:	48 c1 e8 20          	shr    $0x20,%rax
    af83:	48 39 d0             	cmp    %rdx,%rax
    af86:	73 13                	jae    af9b <f0+0x44b>
    af88:	49 01 c4             	add    %rax,%r12
    af8b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    af90:	0f 84 f9 26 00 00    	je     d68f <f0+0x2b3f>
    af96:	41 c6 04 24 01       	movb   $0x1,(%r12)
    af9b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    afa2:	00 f0 3f 
    afa5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    afac:	00 
    afad:	bf 01 00 00 00       	mov    $0x1,%edi
    afb2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    afb9:	00 
    afba:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    afc1:	00 
    afc2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    afc9:	33 f3 bf 
    afcc:	e8 df ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    afd1:	48 89 c7             	mov    %rax,%rdi
    afd4:	e8 f7 b4 ff ff       	call   64d0 <fwp_rc_fresh>
    afd9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    afe0:	00 
    afe1:	bf 01 00 00 00       	mov    $0x1,%edi
    afe6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    afed:	00 
    afee:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    aff5:	00 
    aff6:	e8 b5 ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    affb:	48 89 c7             	mov    %rax,%rdi
    affe:	e8 cd b4 ff ff       	call   64d0 <fwp_rc_fresh>
    b003:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b00a:	00 
    b00b:	bf 01 00 00 00       	mov    $0x1,%edi
    b010:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b017:	00 
    b018:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b01f:	00 
    b020:	e8 8b ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b025:	48 89 c7             	mov    %rax,%rdi
    b028:	e8 a3 b4 ff ff       	call   64d0 <fwp_rc_fresh>
    b02d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b034:	00 
    b035:	bf 01 00 00 00       	mov    $0x1,%edi
    b03a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b041:	00 
    b042:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b049:	00 
    b04a:	e8 61 ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b04f:	48 89 c7             	mov    %rax,%rdi
    b052:	e8 79 b4 ff ff       	call   64d0 <fwp_rc_fresh>
    b057:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b05e:	00 
    b05f:	bf 01 00 00 00       	mov    $0x1,%edi
    b064:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b06b:	00 
    b06c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b073:	00 
    b074:	e8 37 ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b079:	48 89 c7             	mov    %rax,%rdi
    b07c:	e8 4f b4 ff ff       	call   64d0 <fwp_rc_fresh>
    b081:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b088:	00 
    b089:	bf 01 00 00 00       	mov    $0x1,%edi
    b08e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b095:	00 
    b096:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b09d:	00 
    b09e:	e8 0d ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b0a3:	48 89 c7             	mov    %rax,%rdi
    b0a6:	e8 25 b4 ff ff       	call   64d0 <fwp_rc_fresh>
    b0ab:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b0b2:	00 
    b0b3:	bf 01 00 00 00       	mov    $0x1,%edi
    b0b8:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b0bf:	00 
    b0c0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b0c7:	00 
    b0c8:	e8 e3 ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b0cd:	48 89 c7             	mov    %rax,%rdi
    b0d0:	e8 fb b3 ff ff       	call   64d0 <fwp_rc_fresh>
    b0d5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b0dc:	00 
    b0dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b0e2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b0e9:	00 
    b0ea:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b0f1:	00 
    b0f2:	e8 b9 ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b0f7:	48 89 c7             	mov    %rax,%rdi
    b0fa:	e8 d1 b3 ff ff       	call   64d0 <fwp_rc_fresh>
    b0ff:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b106:	00 
    b107:	bf 01 00 00 00       	mov    $0x1,%edi
    b10c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b113:	00 
    b114:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b11b:	00 
    b11c:	e8 8f ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b121:	48 89 c7             	mov    %rax,%rdi
    b124:	e8 a7 b3 ff ff       	call   64d0 <fwp_rc_fresh>
    b129:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b130:	00 
    b131:	bf 01 00 00 00       	mov    $0x1,%edi
    b136:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b13d:	00 
    b13e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b145:	00 
    b146:	e8 65 ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b14b:	48 89 c7             	mov    %rax,%rdi
    b14e:	e8 7d b3 ff ff       	call   64d0 <fwp_rc_fresh>
    b153:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b15a:	00 
    b15b:	bf 01 00 00 00       	mov    $0x1,%edi
    b160:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b167:	00 
    b168:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b16f:	00 
    b170:	e8 3b ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b175:	48 89 c7             	mov    %rax,%rdi
    b178:	e8 53 b3 ff ff       	call   64d0 <fwp_rc_fresh>
    b17d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b184:	00 
    b185:	bf 01 00 00 00       	mov    $0x1,%edi
    b18a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b191:	00 
    b192:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b199:	00 
    b19a:	e8 11 ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b19f:	48 89 c7             	mov    %rax,%rdi
    b1a2:	e8 29 b3 ff ff       	call   64d0 <fwp_rc_fresh>
    b1a7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b1ae:	00 
    b1af:	bf 01 00 00 00       	mov    $0x1,%edi
    b1b4:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b1bb:	00 
    b1bc:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b1c3:	00 
    b1c4:	e8 e7 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b1c9:	48 89 c7             	mov    %rax,%rdi
    b1cc:	e8 ff b2 ff ff       	call   64d0 <fwp_rc_fresh>
    b1d1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b1d8:	00 
    b1d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b1de:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b1e5:	00 
    b1e6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b1ed:	00 
    b1ee:	e8 bd ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b1f3:	48 89 c7             	mov    %rax,%rdi
    b1f6:	e8 d5 b2 ff ff       	call   64d0 <fwp_rc_fresh>
    b1fb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b202:	00 
    b203:	bf 01 00 00 00       	mov    $0x1,%edi
    b208:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b20f:	00 
    b210:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b217:	00 
    b218:	e8 93 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b21d:	48 89 c7             	mov    %rax,%rdi
    b220:	e8 ab b2 ff ff       	call   64d0 <fwp_rc_fresh>
    b225:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b22c:	00 
    b22d:	bf 01 00 00 00       	mov    $0x1,%edi
    b232:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b239:	00 
    b23a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b241:	00 
    b242:	e8 69 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b247:	48 89 c7             	mov    %rax,%rdi
    b24a:	e8 81 b2 ff ff       	call   64d0 <fwp_rc_fresh>
    b24f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b256:	00 
    b257:	bf 01 00 00 00       	mov    $0x1,%edi
    b25c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b263:	00 
    b264:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b26b:	00 
    b26c:	e8 3f ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b271:	48 89 c7             	mov    %rax,%rdi
    b274:	e8 57 b2 ff ff       	call   64d0 <fwp_rc_fresh>
    b279:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b280:	00 
    b281:	bf 01 00 00 00       	mov    $0x1,%edi
    b286:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b28d:	00 
    b28e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b295:	00 
    b296:	e8 15 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b29b:	48 89 c7             	mov    %rax,%rdi
    b29e:	e8 2d b2 ff ff       	call   64d0 <fwp_rc_fresh>
    b2a3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b2aa:	00 
    b2ab:	bf 01 00 00 00       	mov    $0x1,%edi
    b2b0:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b2b7:	00 
    b2b8:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b2bf:	00 
    b2c0:	e8 eb aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b2c5:	48 89 c7             	mov    %rax,%rdi
    b2c8:	e8 03 b2 ff ff       	call   64d0 <fwp_rc_fresh>
    b2cd:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b2d4:	00 
    b2d5:	bf 01 00 00 00       	mov    $0x1,%edi
    b2da:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b2e1:	00 
    b2e2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b2e9:	00 
    b2ea:	e8 c1 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b2ef:	48 89 c7             	mov    %rax,%rdi
    b2f2:	e8 d9 b1 ff ff       	call   64d0 <fwp_rc_fresh>
    b2f7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b2fe:	00 
    b2ff:	bf 01 00 00 00       	mov    $0x1,%edi
    b304:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b30b:	00 
    b30c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b313:	00 
    b314:	e8 97 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b319:	48 89 c7             	mov    %rax,%rdi
    b31c:	e8 af b1 ff ff       	call   64d0 <fwp_rc_fresh>
    b321:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b328:	00 
    b329:	bf 01 00 00 00       	mov    $0x1,%edi
    b32e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b335:	00 
    b336:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b33d:	00 
    b33e:	e8 6d aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b343:	48 89 c7             	mov    %rax,%rdi
    b346:	e8 85 b1 ff ff       	call   64d0 <fwp_rc_fresh>
    b34b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b352:	00 
    b353:	bf 01 00 00 00       	mov    $0x1,%edi
    b358:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b35f:	00 
    b360:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b367:	00 
    b368:	e8 43 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b36d:	48 89 c7             	mov    %rax,%rdi
    b370:	e8 5b b1 ff ff       	call   64d0 <fwp_rc_fresh>
    b375:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b37c:	00 
    b37d:	bf 01 00 00 00       	mov    $0x1,%edi
    b382:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b389:	00 
    b38a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b391:	00 
    b392:	e8 19 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b397:	48 89 c7             	mov    %rax,%rdi
    b39a:	e8 31 b1 ff ff       	call   64d0 <fwp_rc_fresh>
    b39f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b3a6:	00 
    b3a7:	bf 01 00 00 00       	mov    $0x1,%edi
    b3ac:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b3b3:	00 
    b3b4:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b3bb:	00 
    b3bc:	e8 ef a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b3c1:	48 89 c7             	mov    %rax,%rdi
    b3c4:	e8 07 b1 ff ff       	call   64d0 <fwp_rc_fresh>
    b3c9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b3d0:	00 
    b3d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b3d6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b3dd:	00 
    b3de:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b3e5:	00 
    b3e6:	e8 c5 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b3eb:	48 89 c7             	mov    %rax,%rdi
    b3ee:	e8 dd b0 ff ff       	call   64d0 <fwp_rc_fresh>
    b3f3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b3fa:	00 
    b3fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b400:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b407:	00 
    b408:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b40f:	00 
    b410:	e8 9b a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b415:	48 89 c7             	mov    %rax,%rdi
    b418:	e8 b3 b0 ff ff       	call   64d0 <fwp_rc_fresh>
    b41d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b424:	00 
    b425:	bf 01 00 00 00       	mov    $0x1,%edi
    b42a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b431:	00 
    b432:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b439:	00 
    b43a:	e8 71 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b43f:	48 89 c7             	mov    %rax,%rdi
    b442:	e8 89 b0 ff ff       	call   64d0 <fwp_rc_fresh>
    b447:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b44e:	00 
    b44f:	bf 01 00 00 00       	mov    $0x1,%edi
    b454:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b45b:	00 
    b45c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b463:	00 
    b464:	e8 47 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b469:	48 89 c7             	mov    %rax,%rdi
    b46c:	e8 5f b0 ff ff       	call   64d0 <fwp_rc_fresh>
    b471:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b478:	00 
    b479:	bf 01 00 00 00       	mov    $0x1,%edi
    b47e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b485:	00 
    b486:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b48d:	00 
    b48e:	e8 1d a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b493:	48 89 c7             	mov    %rax,%rdi
    b496:	e8 35 b0 ff ff       	call   64d0 <fwp_rc_fresh>
    b49b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b4a2:	00 
    b4a3:	bf 01 00 00 00       	mov    $0x1,%edi
    b4a8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b4af:	00 
    b4b0:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b4b7:	00 
    b4b8:	e8 f3 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b4bd:	48 89 c7             	mov    %rax,%rdi
    b4c0:	e8 0b b0 ff ff       	call   64d0 <fwp_rc_fresh>
    b4c5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b4cc:	00 
    b4cd:	bf 01 00 00 00       	mov    $0x1,%edi
    b4d2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b4d9:	00 
    b4da:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b4e1:	00 
    b4e2:	e8 c9 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b4e7:	48 89 c7             	mov    %rax,%rdi
    b4ea:	e8 e1 af ff ff       	call   64d0 <fwp_rc_fresh>
    b4ef:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b4f6:	00 
    b4f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b4fc:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b503:	00 
    b504:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b50b:	00 
    b50c:	e8 9f a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b511:	48 89 c7             	mov    %rax,%rdi
    b514:	e8 b7 af ff ff       	call   64d0 <fwp_rc_fresh>
    b519:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b520:	00 
    b521:	bf 01 00 00 00       	mov    $0x1,%edi
    b526:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b52d:	00 
    b52e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b535:	00 
    b536:	e8 75 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b53b:	48 89 c7             	mov    %rax,%rdi
    b53e:	e8 8d af ff ff       	call   64d0 <fwp_rc_fresh>
    b543:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b54a:	00 
    b54b:	bf 01 00 00 00       	mov    $0x1,%edi
    b550:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b557:	00 
    b558:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b55f:	00 
    b560:	e8 4b a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b565:	48 89 c7             	mov    %rax,%rdi
    b568:	e8 63 af ff ff       	call   64d0 <fwp_rc_fresh>
    b56d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b574:	00 
    b575:	bf 01 00 00 00       	mov    $0x1,%edi
    b57a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b581:	00 
    b582:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b589:	00 
    b58a:	e8 21 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b58f:	48 89 c7             	mov    %rax,%rdi
    b592:	e8 39 af ff ff       	call   64d0 <fwp_rc_fresh>
    b597:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b59e:	00 
    b59f:	bf 01 00 00 00       	mov    $0x1,%edi
    b5a4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b5ab:	00 
    b5ac:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b5b3:	00 
    b5b4:	e8 f7 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5b9:	48 89 c7             	mov    %rax,%rdi
    b5bc:	e8 0f af ff ff       	call   64d0 <fwp_rc_fresh>
    b5c1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b5c8:	00 
    b5c9:	bf 01 00 00 00       	mov    $0x1,%edi
    b5ce:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b5d5:	00 
    b5d6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b5dd:	00 
    b5de:	e8 cd a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5e3:	48 89 c7             	mov    %rax,%rdi
    b5e6:	e8 e5 ae ff ff       	call   64d0 <fwp_rc_fresh>
    b5eb:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b5f2:	00 
    b5f3:	bf 01 00 00 00       	mov    $0x1,%edi
    b5f8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b5ff:	00 
    b600:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b607:	00 
    b608:	e8 a3 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b60d:	48 89 c7             	mov    %rax,%rdi
    b610:	e8 bb ae ff ff       	call   64d0 <fwp_rc_fresh>
    b615:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b61c:	00 
    b61d:	bf 01 00 00 00       	mov    $0x1,%edi
    b622:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b629:	00 
    b62a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b631:	00 
    b632:	e8 79 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b637:	48 89 c7             	mov    %rax,%rdi
    b63a:	e8 91 ae ff ff       	call   64d0 <fwp_rc_fresh>
    b63f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    b646:	00 
    b647:	bf 01 00 00 00       	mov    $0x1,%edi
    b64c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    b653:	00 
    b654:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    b65b:	00 
    b65c:	e8 4f a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b661:	48 89 c7             	mov    %rax,%rdi
    b664:	e8 67 ae ff ff       	call   64d0 <fwp_rc_fresh>
    b669:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    b670:	00 
    b671:	bf 01 00 00 00       	mov    $0x1,%edi
    b676:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    b67d:	00 
    b67e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    b685:	00 
    b686:	e8 25 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b68b:	48 89 c7             	mov    %rax,%rdi
    b68e:	e8 3d ae ff ff       	call   64d0 <fwp_rc_fresh>
    b693:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    b69a:	00 
    b69b:	bf 01 00 00 00       	mov    $0x1,%edi
    b6a0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    b6a7:	00 
    b6a8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    b6af:	00 
    b6b0:	e8 fb a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6b5:	48 89 c7             	mov    %rax,%rdi
    b6b8:	e8 13 ae ff ff       	call   64d0 <fwp_rc_fresh>
    b6bd:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    b6c4:	00 
    b6c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b6ca:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    b6d1:	00 
    b6d2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    b6d9:	00 
    b6da:	e8 d1 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6df:	48 89 c7             	mov    %rax,%rdi
    b6e2:	e8 e9 ad ff ff       	call   64d0 <fwp_rc_fresh>
    b6e7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    b6ee:	00 
    b6ef:	bf 01 00 00 00       	mov    $0x1,%edi
    b6f4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    b6fb:	00 
    b6fc:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    b703:	00 
    b704:	e8 a7 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b709:	48 89 c7             	mov    %rax,%rdi
    b70c:	e8 bf ad ff ff       	call   64d0 <fwp_rc_fresh>
    b711:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    b718:	00 
    b719:	bf 01 00 00 00       	mov    $0x1,%edi
    b71e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    b725:	00 
    b726:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    b72d:	00 
    b72e:	e8 7d a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b733:	48 89 c7             	mov    %rax,%rdi
    b736:	e8 95 ad ff ff       	call   64d0 <fwp_rc_fresh>
    b73b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    b742:	00 
    b743:	bf 01 00 00 00       	mov    $0x1,%edi
    b748:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    b74f:	00 
    b750:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    b757:	00 
    b758:	e8 53 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b75d:	48 89 c7             	mov    %rax,%rdi
    b760:	e8 6b ad ff ff       	call   64d0 <fwp_rc_fresh>
    b765:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    b76c:	00 
    b76d:	bf 01 00 00 00       	mov    $0x1,%edi
    b772:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    b779:	00 
    b77a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    b781:	00 
    b782:	e8 29 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b787:	48 89 c7             	mov    %rax,%rdi
    b78a:	e8 41 ad ff ff       	call   64d0 <fwp_rc_fresh>
    b78f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    b796:	00 
    b797:	bf 01 00 00 00       	mov    $0x1,%edi
    b79c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    b7a3:	00 
    b7a4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    b7ab:	00 
    b7ac:	e8 ff a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7b1:	48 89 c7             	mov    %rax,%rdi
    b7b4:	e8 17 ad ff ff       	call   64d0 <fwp_rc_fresh>
    b7b9:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    b7c0:	00 
    b7c1:	bf 01 00 00 00       	mov    $0x1,%edi
    b7c6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    b7cd:	00 
    b7ce:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    b7d5:	00 
    b7d6:	e8 d5 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7db:	48 89 c7             	mov    %rax,%rdi
    b7de:	e8 ed ac ff ff       	call   64d0 <fwp_rc_fresh>
    b7e3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    b7ea:	00 
    b7eb:	bf 01 00 00 00       	mov    $0x1,%edi
    b7f0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    b7f7:	00 
    b7f8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    b7ff:	00 
    b800:	e8 ab a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b805:	48 89 c7             	mov    %rax,%rdi
    b808:	e8 c3 ac ff ff       	call   64d0 <fwp_rc_fresh>
    b80d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    b814:	00 
    b815:	bf 01 00 00 00       	mov    $0x1,%edi
    b81a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    b821:	00 
    b822:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    b829:	00 
    b82a:	e8 81 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b82f:	48 89 c7             	mov    %rax,%rdi
    b832:	e8 99 ac ff ff       	call   64d0 <fwp_rc_fresh>
    b837:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    b83e:	00 
    b83f:	bf 01 00 00 00       	mov    $0x1,%edi
    b844:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    b84b:	00 
    b84c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    b853:	00 
    b854:	e8 57 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b859:	48 89 c7             	mov    %rax,%rdi
    b85c:	e8 6f ac ff ff       	call   64d0 <fwp_rc_fresh>
    b861:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    b868:	00 
    b869:	bf 01 00 00 00       	mov    $0x1,%edi
    b86e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    b875:	00 
    b876:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    b87d:	00 
    b87e:	e8 2d a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b883:	48 89 c7             	mov    %rax,%rdi
    b886:	e8 45 ac ff ff       	call   64d0 <fwp_rc_fresh>
    b88b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    b892:	00 
    b893:	bf 01 00 00 00       	mov    $0x1,%edi
    b898:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    b89f:	00 
    b8a0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    b8a7:	00 
    b8a8:	e8 03 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b8ad:	48 89 c7             	mov    %rax,%rdi
    b8b0:	e8 1b ac ff ff       	call   64d0 <fwp_rc_fresh>
    b8b5:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    b8bc:	00 
    b8bd:	bf 01 00 00 00       	mov    $0x1,%edi
    b8c2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    b8c9:	00 
    b8ca:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    b8d1:	00 
    b8d2:	e8 d9 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b8d7:	48 89 c7             	mov    %rax,%rdi
    b8da:	e8 f1 ab ff ff       	call   64d0 <fwp_rc_fresh>
    b8df:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    b8e6:	00 
    b8e7:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ec:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    b8f3:	00 
    b8f4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    b8fb:	00 
    b8fc:	e8 af a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b901:	48 89 c7             	mov    %rax,%rdi
    b904:	e8 c7 ab ff ff       	call   64d0 <fwp_rc_fresh>
    b909:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    b910:	00 
    b911:	bf 01 00 00 00       	mov    $0x1,%edi
    b916:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    b91d:	00 
    b91e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    b925:	00 
    b926:	e8 85 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b92b:	48 89 c7             	mov    %rax,%rdi
    b92e:	e8 9d ab ff ff       	call   64d0 <fwp_rc_fresh>
    b933:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    b93a:	00 
    b93b:	bf 01 00 00 00       	mov    $0x1,%edi
    b940:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    b947:	00 
    b948:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    b94f:	00 
    b950:	e8 5b a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b955:	48 89 c7             	mov    %rax,%rdi
    b958:	e8 73 ab ff ff       	call   64d0 <fwp_rc_fresh>
    b95d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    b964:	00 
    b965:	bf 01 00 00 00       	mov    $0x1,%edi
    b96a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    b971:	00 
    b972:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    b979:	00 
    b97a:	e8 31 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b97f:	48 89 c7             	mov    %rax,%rdi
    b982:	e8 49 ab ff ff       	call   64d0 <fwp_rc_fresh>
    b987:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    b98e:	00 
    b98f:	bf 01 00 00 00       	mov    $0x1,%edi
    b994:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    b99b:	00 
    b99c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    b9a3:	00 
    b9a4:	e8 07 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b9a9:	48 89 c7             	mov    %rax,%rdi
    b9ac:	e8 1f ab ff ff       	call   64d0 <fwp_rc_fresh>
    b9b1:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    b9b8:	00 
    b9b9:	bf 01 00 00 00       	mov    $0x1,%edi
    b9be:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    b9c5:	00 
    b9c6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    b9cd:	00 
    b9ce:	e8 dd a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b9d3:	48 89 c7             	mov    %rax,%rdi
    b9d6:	e8 f5 aa ff ff       	call   64d0 <fwp_rc_fresh>
    b9db:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    b9e2:	00 
    b9e3:	bf 01 00 00 00       	mov    $0x1,%edi
    b9e8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    b9ef:	00 
    b9f0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    b9f7:	00 
    b9f8:	e8 b3 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b9fd:	48 89 c7             	mov    %rax,%rdi
    ba00:	e8 cb aa ff ff       	call   64d0 <fwp_rc_fresh>
    ba05:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    ba0c:	00 
    ba0d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba12:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    ba19:	00 
    ba1a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    ba21:	00 
    ba22:	e8 89 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba27:	48 89 c7             	mov    %rax,%rdi
    ba2a:	e8 a1 aa ff ff       	call   64d0 <fwp_rc_fresh>
    ba2f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    ba36:	00 
    ba37:	bf 01 00 00 00       	mov    $0x1,%edi
    ba3c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    ba43:	00 
    ba44:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    ba4b:	00 
    ba4c:	e8 5f a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba51:	48 89 c7             	mov    %rax,%rdi
    ba54:	e8 77 aa ff ff       	call   64d0 <fwp_rc_fresh>
    ba59:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    ba60:	00 
    ba61:	bf 01 00 00 00       	mov    $0x1,%edi
    ba66:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    ba6d:	00 
    ba6e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    ba75:	00 
    ba76:	e8 35 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba7b:	48 89 c7             	mov    %rax,%rdi
    ba7e:	e8 4d aa ff ff       	call   64d0 <fwp_rc_fresh>
    ba83:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    ba8a:	00 
    ba8b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba90:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    ba97:	00 
    ba98:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    ba9f:	00 
    baa0:	e8 0b a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    baa5:	48 89 c7             	mov    %rax,%rdi
    baa8:	e8 23 aa ff ff       	call   64d0 <fwp_rc_fresh>
    baad:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    bab4:	00 
    bab5:	bf 01 00 00 00       	mov    $0x1,%edi
    baba:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    bac1:	00 
    bac2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    bac9:	00 
    baca:	e8 e1 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bacf:	48 89 c7             	mov    %rax,%rdi
    bad2:	e8 f9 a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bad7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    bade:	00 
    badf:	bf 01 00 00 00       	mov    $0x1,%edi
    bae4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    baeb:	00 
    baec:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    baf3:	00 
    baf4:	e8 b7 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    baf9:	48 89 c7             	mov    %rax,%rdi
    bafc:	e8 cf a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bb01:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    bb08:	00 
    bb09:	bf 01 00 00 00       	mov    $0x1,%edi
    bb0e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    bb15:	00 
    bb16:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    bb1d:	00 
    bb1e:	e8 8d a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb23:	48 89 c7             	mov    %rax,%rdi
    bb26:	e8 a5 a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bb2b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    bb32:	00 
    bb33:	bf 01 00 00 00       	mov    $0x1,%edi
    bb38:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    bb3f:	00 
    bb40:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    bb47:	00 
    bb48:	e8 63 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb4d:	48 89 c7             	mov    %rax,%rdi
    bb50:	e8 7b a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bb55:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    bb5c:	00 
    bb5d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb62:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    bb69:	00 
    bb6a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    bb71:	00 
    bb72:	e8 39 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb77:	48 89 c7             	mov    %rax,%rdi
    bb7a:	e8 51 a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bb7f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    bb86:	00 
    bb87:	bf 01 00 00 00       	mov    $0x1,%edi
    bb8c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    bb93:	00 
    bb94:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    bb9b:	00 
    bb9c:	e8 0f a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bba1:	48 89 c7             	mov    %rax,%rdi
    bba4:	e8 27 a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bba9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    bbb0:	00 
    bbb1:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb6:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    bbbd:	00 
    bbbe:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    bbc5:	00 
    bbc6:	e8 e5 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bbcb:	48 89 c7             	mov    %rax,%rdi
    bbce:	e8 fd a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bbd3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    bbda:	00 
    bbdb:	bf 01 00 00 00       	mov    $0x1,%edi
    bbe0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    bbe7:	00 
    bbe8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    bbef:	00 
    bbf0:	e8 bb a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bbf5:	48 89 c7             	mov    %rax,%rdi
    bbf8:	e8 d3 a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bbfd:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    bc04:	00 
    bc05:	bf 01 00 00 00       	mov    $0x1,%edi
    bc0a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    bc11:	00 
    bc12:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    bc19:	00 
    bc1a:	e8 91 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc1f:	48 89 c7             	mov    %rax,%rdi
    bc22:	e8 a9 a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bc27:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    bc2e:	00 
    bc2f:	bf 01 00 00 00       	mov    $0x1,%edi
    bc34:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    bc3b:	00 
    bc3c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    bc43:	00 
    bc44:	e8 67 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc49:	48 89 c7             	mov    %rax,%rdi
    bc4c:	e8 7f a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bc51:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    bc58:	00 
    bc59:	bf 01 00 00 00       	mov    $0x1,%edi
    bc5e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    bc65:	00 
    bc66:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    bc6d:	00 
    bc6e:	e8 3d a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc73:	48 89 c7             	mov    %rax,%rdi
    bc76:	e8 55 a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bc7b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    bc82:	00 
    bc83:	bf 01 00 00 00       	mov    $0x1,%edi
    bc88:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    bc8f:	00 
    bc90:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    bc97:	00 
    bc98:	e8 13 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc9d:	48 89 c7             	mov    %rax,%rdi
    bca0:	e8 2b a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bca5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    bcac:	00 
    bcad:	bf 01 00 00 00       	mov    $0x1,%edi
    bcb2:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    bcb9:	00 
    bcba:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    bcc1:	00 
    bcc2:	e8 e9 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bcc7:	48 89 c7             	mov    %rax,%rdi
    bcca:	e8 01 a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bccf:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    bcd6:	00 
    bcd7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcdc:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    bce3:	00 
    bce4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    bceb:	00 
    bcec:	e8 bf a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bcf1:	48 89 c7             	mov    %rax,%rdi
    bcf4:	e8 d7 a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bcf9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    bd00:	00 
    bd01:	bf 01 00 00 00       	mov    $0x1,%edi
    bd06:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    bd0d:	00 
    bd0e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    bd15:	00 
    bd16:	e8 95 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd1b:	48 89 c7             	mov    %rax,%rdi
    bd1e:	e8 ad a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bd23:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    bd2a:	00 
    bd2b:	bf 01 00 00 00       	mov    $0x1,%edi
    bd30:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    bd37:	00 
    bd38:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    bd3f:	00 
    bd40:	e8 6b a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd45:	48 89 c7             	mov    %rax,%rdi
    bd48:	e8 83 a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bd4d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    bd54:	00 
    bd55:	bf 01 00 00 00       	mov    $0x1,%edi
    bd5a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    bd61:	00 
    bd62:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    bd69:	00 
    bd6a:	e8 41 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd6f:	48 89 c7             	mov    %rax,%rdi
    bd72:	e8 59 a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bd77:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    bd7e:	00 
    bd7f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd84:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    bd8b:	00 
    bd8c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    bd93:	00 
    bd94:	e8 17 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd99:	48 89 c7             	mov    %rax,%rdi
    bd9c:	e8 2f a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bda1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    bda8:	00 
    bda9:	bf 01 00 00 00       	mov    $0x1,%edi
    bdae:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    bdb5:	00 
    bdb6:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    bdbd:	00 
    bdbe:	e8 ed 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bdc3:	48 89 c7             	mov    %rax,%rdi
    bdc6:	e8 05 a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bdcb:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    bdd2:	00 
    bdd3:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    bddf:	00 
    bde0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    bde7:	00 
    bde8:	e8 c3 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bded:	48 89 c7             	mov    %rax,%rdi
    bdf0:	e8 db a6 ff ff       	call   64d0 <fwp_rc_fresh>
    bdf5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    bdfc:	00 
    bdfd:	bf 01 00 00 00       	mov    $0x1,%edi
    be02:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    be09:	00 
    be0a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    be11:	00 
    be12:	e8 99 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be17:	48 89 c7             	mov    %rax,%rdi
    be1a:	e8 b1 a6 ff ff       	call   64d0 <fwp_rc_fresh>
    be1f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    be26:	00 
    be27:	bf 01 00 00 00       	mov    $0x1,%edi
    be2c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    be33:	00 
    be34:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    be3b:	00 
    be3c:	e8 6f 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be41:	48 89 c7             	mov    %rax,%rdi
    be44:	e8 87 a6 ff ff       	call   64d0 <fwp_rc_fresh>
    be49:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    be50:	00 
    be51:	bf 01 00 00 00       	mov    $0x1,%edi
    be56:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    be5d:	00 
    be5e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    be65:	00 
    be66:	e8 45 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be6b:	48 89 c7             	mov    %rax,%rdi
    be6e:	e8 5d a6 ff ff       	call   64d0 <fwp_rc_fresh>
    be73:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    be7a:	00 
    be7b:	bf 01 00 00 00       	mov    $0x1,%edi
    be80:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    be87:	00 
    be88:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    be8f:	00 
    be90:	e8 1b 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be95:	48 8b 15 fc 8c 01 00 	mov    0x18cfc(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    be9c:	49 89 c5             	mov    %rax,%r13
    be9f:	48 2b 05 ca 8c 01 00 	sub    0x18cca(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    bea6:	48 c1 e2 10          	shl    $0x10,%rdx
    beaa:	48 39 d0             	cmp    %rdx,%rax
    bead:	73 59                	jae    bf08 <f0+0x13b8>
    beaf:	48 89 c2             	mov    %rax,%rdx
    beb2:	48 c1 ea 10          	shr    $0x10,%rdx
    beb6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    beba:	48 8b 15 f7 8c 01 00 	mov    0x18cf7(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    bec1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bec5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bec9:	4d 85 e4             	test   %r12,%r12
    becc:	74 3a                	je     bf08 <f0+0x13b8>
    bece:	0f b6 0a             	movzbl (%rdx),%ecx
    bed1:	80 f9 02             	cmp    $0x2,%cl
    bed4:	0f 84 c6 15 00 00    	je     d4a0 <f0+0x2950>
    beda:	80 f9 01             	cmp    $0x1,%cl
    bedd:	75 29                	jne    bf08 <f0+0x13b8>
    bedf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bee2:	0f b7 c0             	movzwl %ax,%eax
    bee5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bee8:	48 0f af c1          	imul   %rcx,%rax
    beec:	48 c1 e8 20          	shr    $0x20,%rax
    bef0:	48 39 d0             	cmp    %rdx,%rax
    bef3:	73 13                	jae    bf08 <f0+0x13b8>
    bef5:	49 01 c4             	add    %rax,%r12
    bef8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    befd:	0f 84 99 17 00 00    	je     d69c <f0+0x2b4c>
    bf03:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf08:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bf0f:	33 f3 bf 
    bf12:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    bf19:	00 
    bf1a:	bf 01 00 00 00       	mov    $0x1,%edi
    bf1f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    bf26:	00 
    bf27:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    bf2e:	00 
    bf2f:	e8 7c 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bf34:	48 8b 15 5d 8c 01 00 	mov    0x18c5d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    bf3b:	49 89 c5             	mov    %rax,%r13
    bf3e:	48 2b 05 2b 8c 01 00 	sub    0x18c2b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    bf45:	48 c1 e2 10          	shl    $0x10,%rdx
    bf49:	48 39 d0             	cmp    %rdx,%rax
    bf4c:	73 59                	jae    bfa7 <f0+0x1457>
    bf4e:	48 89 c2             	mov    %rax,%rdx
    bf51:	48 c1 ea 10          	shr    $0x10,%rdx
    bf55:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf59:	48 8b 15 58 8c 01 00 	mov    0x18c58(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    bf60:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf64:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf68:	4d 85 e4             	test   %r12,%r12
    bf6b:	74 3a                	je     bfa7 <f0+0x1457>
    bf6d:	0f b6 0a             	movzbl (%rdx),%ecx
    bf70:	80 f9 02             	cmp    $0x2,%cl
    bf73:	0f 84 17 15 00 00    	je     d490 <f0+0x2940>
    bf79:	80 f9 01             	cmp    $0x1,%cl
    bf7c:	75 29                	jne    bfa7 <f0+0x1457>
    bf7e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf81:	0f b7 c0             	movzwl %ax,%eax
    bf84:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf87:	48 0f af c1          	imul   %rcx,%rax
    bf8b:	48 c1 e8 20          	shr    $0x20,%rax
    bf8f:	48 39 d0             	cmp    %rdx,%rax
    bf92:	73 13                	jae    bfa7 <f0+0x1457>
    bf94:	49 01 c4             	add    %rax,%r12
    bf97:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf9c:	0f 84 07 17 00 00    	je     d6a9 <f0+0x2b59>
    bfa2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bfa7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bfae:	00 f0 3f 
    bfb1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    bfb8:	00 
    bfb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bfbe:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    bfc5:	00 
    bfc6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    bfcd:	00 
    bfce:	e8 dd 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bfd3:	48 8b 15 be 8b 01 00 	mov    0x18bbe(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    bfda:	49 89 c5             	mov    %rax,%r13
    bfdd:	48 2b 05 8c 8b 01 00 	sub    0x18b8c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    bfe4:	48 c1 e2 10          	shl    $0x10,%rdx
    bfe8:	48 39 d0             	cmp    %rdx,%rax
    bfeb:	73 59                	jae    c046 <f0+0x14f6>
    bfed:	48 89 c2             	mov    %rax,%rdx
    bff0:	48 c1 ea 10          	shr    $0x10,%rdx
    bff4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bff8:	48 8b 15 b9 8b 01 00 	mov    0x18bb9(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    bfff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c003:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c007:	4d 85 e4             	test   %r12,%r12
    c00a:	74 3a                	je     c046 <f0+0x14f6>
    c00c:	0f b6 0a             	movzbl (%rdx),%ecx
    c00f:	80 f9 02             	cmp    $0x2,%cl
    c012:	0f 84 28 15 00 00    	je     d540 <f0+0x29f0>
    c018:	80 f9 01             	cmp    $0x1,%cl
    c01b:	75 29                	jne    c046 <f0+0x14f6>
    c01d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c020:	0f b7 c0             	movzwl %ax,%eax
    c023:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c026:	48 0f af c1          	imul   %rcx,%rax
    c02a:	48 c1 e8 20          	shr    $0x20,%rax
    c02e:	48 39 d0             	cmp    %rdx,%rax
    c031:	73 13                	jae    c046 <f0+0x14f6>
    c033:	49 01 c4             	add    %rax,%r12
    c036:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c03b:	0f 84 75 16 00 00    	je     d6b6 <f0+0x2b66>
    c041:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c046:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c04d:	33 f3 bf 
    c050:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c057:	00 
    c058:	bf 01 00 00 00       	mov    $0x1,%edi
    c05d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c064:	00 
    c065:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c06c:	00 
    c06d:	e8 3e 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c072:	48 8b 15 1f 8b 01 00 	mov    0x18b1f(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c079:	49 89 c5             	mov    %rax,%r13
    c07c:	48 2b 05 ed 8a 01 00 	sub    0x18aed(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c083:	48 c1 e2 10          	shl    $0x10,%rdx
    c087:	48 39 d0             	cmp    %rdx,%rax
    c08a:	73 59                	jae    c0e5 <f0+0x1595>
    c08c:	48 89 c2             	mov    %rax,%rdx
    c08f:	48 c1 ea 10          	shr    $0x10,%rdx
    c093:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c097:	48 8b 15 1a 8b 01 00 	mov    0x18b1a(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c09e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c0a2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c0a6:	4d 85 e4             	test   %r12,%r12
    c0a9:	74 3a                	je     c0e5 <f0+0x1595>
    c0ab:	0f b6 0a             	movzbl (%rdx),%ecx
    c0ae:	80 f9 02             	cmp    $0x2,%cl
    c0b1:	0f 84 79 14 00 00    	je     d530 <f0+0x29e0>
    c0b7:	80 f9 01             	cmp    $0x1,%cl
    c0ba:	75 29                	jne    c0e5 <f0+0x1595>
    c0bc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0bf:	0f b7 c0             	movzwl %ax,%eax
    c0c2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0c5:	48 0f af c1          	imul   %rcx,%rax
    c0c9:	48 c1 e8 20          	shr    $0x20,%rax
    c0cd:	48 39 d0             	cmp    %rdx,%rax
    c0d0:	73 13                	jae    c0e5 <f0+0x1595>
    c0d2:	49 01 c4             	add    %rax,%r12
    c0d5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c0da:	0f 84 e3 15 00 00    	je     d6c3 <f0+0x2b73>
    c0e0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c0e5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c0ec:	00 f0 3f 
    c0ef:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c0f6:	00 
    c0f7:	bf 01 00 00 00       	mov    $0x1,%edi
    c0fc:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c103:	00 
    c104:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c10b:	00 
    c10c:	e8 9f 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c111:	48 8b 15 80 8a 01 00 	mov    0x18a80(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c118:	49 89 c5             	mov    %rax,%r13
    c11b:	48 2b 05 4e 8a 01 00 	sub    0x18a4e(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c122:	48 c1 e2 10          	shl    $0x10,%rdx
    c126:	48 39 d0             	cmp    %rdx,%rax
    c129:	73 59                	jae    c184 <f0+0x1634>
    c12b:	48 89 c2             	mov    %rax,%rdx
    c12e:	48 c1 ea 10          	shr    $0x10,%rdx
    c132:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c136:	48 8b 15 7b 8a 01 00 	mov    0x18a7b(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c13d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c141:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c145:	4d 85 e4             	test   %r12,%r12
    c148:	74 3a                	je     c184 <f0+0x1634>
    c14a:	0f b6 0a             	movzbl (%rdx),%ecx
    c14d:	80 f9 02             	cmp    $0x2,%cl
    c150:	0f 84 ca 13 00 00    	je     d520 <f0+0x29d0>
    c156:	80 f9 01             	cmp    $0x1,%cl
    c159:	75 29                	jne    c184 <f0+0x1634>
    c15b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c15e:	0f b7 c0             	movzwl %ax,%eax
    c161:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c164:	48 0f af c1          	imul   %rcx,%rax
    c168:	48 c1 e8 20          	shr    $0x20,%rax
    c16c:	48 39 d0             	cmp    %rdx,%rax
    c16f:	73 13                	jae    c184 <f0+0x1634>
    c171:	49 01 c4             	add    %rax,%r12
    c174:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c179:	0f 84 51 15 00 00    	je     d6d0 <f0+0x2b80>
    c17f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c184:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c18b:	33 f3 bf 
    c18e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c195:	00 
    c196:	bf 01 00 00 00       	mov    $0x1,%edi
    c19b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c1a2:	00 
    c1a3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c1aa:	00 
    c1ab:	e8 00 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c1b0:	48 8b 15 e1 89 01 00 	mov    0x189e1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c1b7:	49 89 c5             	mov    %rax,%r13
    c1ba:	48 2b 05 af 89 01 00 	sub    0x189af(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c1c1:	48 c1 e2 10          	shl    $0x10,%rdx
    c1c5:	48 39 d0             	cmp    %rdx,%rax
    c1c8:	73 59                	jae    c223 <f0+0x16d3>
    c1ca:	48 89 c2             	mov    %rax,%rdx
    c1cd:	48 c1 ea 10          	shr    $0x10,%rdx
    c1d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c1d5:	48 8b 15 dc 89 01 00 	mov    0x189dc(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c1dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c1e0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c1e4:	4d 85 e4             	test   %r12,%r12
    c1e7:	74 3a                	je     c223 <f0+0x16d3>
    c1e9:	0f b6 0a             	movzbl (%rdx),%ecx
    c1ec:	80 f9 02             	cmp    $0x2,%cl
    c1ef:	0f 84 1b 13 00 00    	je     d510 <f0+0x29c0>
    c1f5:	80 f9 01             	cmp    $0x1,%cl
    c1f8:	75 29                	jne    c223 <f0+0x16d3>
    c1fa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c1fd:	0f b7 c0             	movzwl %ax,%eax
    c200:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c203:	48 0f af c1          	imul   %rcx,%rax
    c207:	48 c1 e8 20          	shr    $0x20,%rax
    c20b:	48 39 d0             	cmp    %rdx,%rax
    c20e:	73 13                	jae    c223 <f0+0x16d3>
    c210:	49 01 c4             	add    %rax,%r12
    c213:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c218:	0f 84 bf 14 00 00    	je     d6dd <f0+0x2b8d>
    c21e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c223:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c22a:	00 f0 3f 
    c22d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c234:	00 
    c235:	bf 01 00 00 00       	mov    $0x1,%edi
    c23a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c241:	00 
    c242:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c249:	00 
    c24a:	e8 61 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c24f:	48 8b 15 42 89 01 00 	mov    0x18942(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c256:	49 89 c5             	mov    %rax,%r13
    c259:	48 2b 05 10 89 01 00 	sub    0x18910(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c260:	48 c1 e2 10          	shl    $0x10,%rdx
    c264:	48 39 d0             	cmp    %rdx,%rax
    c267:	73 59                	jae    c2c2 <f0+0x1772>
    c269:	48 89 c2             	mov    %rax,%rdx
    c26c:	48 c1 ea 10          	shr    $0x10,%rdx
    c270:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c274:	48 8b 15 3d 89 01 00 	mov    0x1893d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c27b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c27f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c283:	4d 85 e4             	test   %r12,%r12
    c286:	74 3a                	je     c2c2 <f0+0x1772>
    c288:	0f b6 0a             	movzbl (%rdx),%ecx
    c28b:	80 f9 02             	cmp    $0x2,%cl
    c28e:	0f 84 6c 12 00 00    	je     d500 <f0+0x29b0>
    c294:	80 f9 01             	cmp    $0x1,%cl
    c297:	75 29                	jne    c2c2 <f0+0x1772>
    c299:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c29c:	0f b7 c0             	movzwl %ax,%eax
    c29f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2a2:	48 0f af c1          	imul   %rcx,%rax
    c2a6:	48 c1 e8 20          	shr    $0x20,%rax
    c2aa:	48 39 d0             	cmp    %rdx,%rax
    c2ad:	73 13                	jae    c2c2 <f0+0x1772>
    c2af:	49 01 c4             	add    %rax,%r12
    c2b2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2b7:	0f 84 2d 14 00 00    	je     d6ea <f0+0x2b9a>
    c2bd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2c2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c2c9:	33 f3 bf 
    c2cc:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c2d3:	00 
    c2d4:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c2e0:	00 
    c2e1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c2e8:	00 
    c2e9:	e8 c2 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c2ee:	48 8b 15 a3 88 01 00 	mov    0x188a3(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c2f5:	49 89 c5             	mov    %rax,%r13
    c2f8:	48 2b 05 71 88 01 00 	sub    0x18871(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c2ff:	48 c1 e2 10          	shl    $0x10,%rdx
    c303:	48 39 d0             	cmp    %rdx,%rax
    c306:	73 59                	jae    c361 <f0+0x1811>
    c308:	48 89 c2             	mov    %rax,%rdx
    c30b:	48 c1 ea 10          	shr    $0x10,%rdx
    c30f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c313:	48 8b 15 9e 88 01 00 	mov    0x1889e(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c31a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c31e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c322:	4d 85 e4             	test   %r12,%r12
    c325:	74 3a                	je     c361 <f0+0x1811>
    c327:	0f b6 0a             	movzbl (%rdx),%ecx
    c32a:	80 f9 02             	cmp    $0x2,%cl
    c32d:	0f 84 bd 11 00 00    	je     d4f0 <f0+0x29a0>
    c333:	80 f9 01             	cmp    $0x1,%cl
    c336:	75 29                	jne    c361 <f0+0x1811>
    c338:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c33b:	0f b7 c0             	movzwl %ax,%eax
    c33e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c341:	48 0f af c1          	imul   %rcx,%rax
    c345:	48 c1 e8 20          	shr    $0x20,%rax
    c349:	48 39 d0             	cmp    %rdx,%rax
    c34c:	73 13                	jae    c361 <f0+0x1811>
    c34e:	49 01 c4             	add    %rax,%r12
    c351:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c356:	0f 84 9b 13 00 00    	je     d6f7 <f0+0x2ba7>
    c35c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c361:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c368:	00 f0 3f 
    c36b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c372:	00 
    c373:	bf 01 00 00 00       	mov    $0x1,%edi
    c378:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c37f:	00 
    c380:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c387:	00 
    c388:	e8 23 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c38d:	48 8b 15 04 88 01 00 	mov    0x18804(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c394:	49 89 c5             	mov    %rax,%r13
    c397:	48 2b 05 d2 87 01 00 	sub    0x187d2(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c39e:	48 c1 e2 10          	shl    $0x10,%rdx
    c3a2:	48 39 d0             	cmp    %rdx,%rax
    c3a5:	73 59                	jae    c400 <f0+0x18b0>
    c3a7:	48 89 c2             	mov    %rax,%rdx
    c3aa:	48 c1 ea 10          	shr    $0x10,%rdx
    c3ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c3b2:	48 8b 15 ff 87 01 00 	mov    0x187ff(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c3b9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3bd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3c1:	4d 85 e4             	test   %r12,%r12
    c3c4:	74 3a                	je     c400 <f0+0x18b0>
    c3c6:	0f b6 0a             	movzbl (%rdx),%ecx
    c3c9:	80 f9 02             	cmp    $0x2,%cl
    c3cc:	0f 84 0e 11 00 00    	je     d4e0 <f0+0x2990>
    c3d2:	80 f9 01             	cmp    $0x1,%cl
    c3d5:	75 29                	jne    c400 <f0+0x18b0>
    c3d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c3da:	0f b7 c0             	movzwl %ax,%eax
    c3dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c3e0:	48 0f af c1          	imul   %rcx,%rax
    c3e4:	48 c1 e8 20          	shr    $0x20,%rax
    c3e8:	48 39 d0             	cmp    %rdx,%rax
    c3eb:	73 13                	jae    c400 <f0+0x18b0>
    c3ed:	49 01 c4             	add    %rax,%r12
    c3f0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c3f5:	0f 84 09 13 00 00    	je     d704 <f0+0x2bb4>
    c3fb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c400:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c407:	33 f3 bf 
    c40a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c411:	00 
    c412:	bf 01 00 00 00       	mov    $0x1,%edi
    c417:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c41e:	00 
    c41f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c426:	00 
    c427:	e8 84 99 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c42c:	48 8b 15 65 87 01 00 	mov    0x18765(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c433:	49 89 c5             	mov    %rax,%r13
    c436:	48 2b 05 33 87 01 00 	sub    0x18733(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c43d:	48 c1 e2 10          	shl    $0x10,%rdx
    c441:	48 39 d0             	cmp    %rdx,%rax
    c444:	73 59                	jae    c49f <f0+0x194f>
    c446:	48 89 c2             	mov    %rax,%rdx
    c449:	48 c1 ea 10          	shr    $0x10,%rdx
    c44d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c451:	48 8b 15 60 87 01 00 	mov    0x18760(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c458:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c45c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c460:	4d 85 e4             	test   %r12,%r12
    c463:	74 3a                	je     c49f <f0+0x194f>
    c465:	0f b6 0a             	movzbl (%rdx),%ecx
    c468:	80 f9 02             	cmp    $0x2,%cl
    c46b:	0f 84 5f 10 00 00    	je     d4d0 <f0+0x2980>
    c471:	80 f9 01             	cmp    $0x1,%cl
    c474:	75 29                	jne    c49f <f0+0x194f>
    c476:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c479:	0f b7 c0             	movzwl %ax,%eax
    c47c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c47f:	48 0f af c1          	imul   %rcx,%rax
    c483:	48 c1 e8 20          	shr    $0x20,%rax
    c487:	48 39 d0             	cmp    %rdx,%rax
    c48a:	73 13                	jae    c49f <f0+0x194f>
    c48c:	49 01 c4             	add    %rax,%r12
    c48f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c494:	0f 84 77 12 00 00    	je     d711 <f0+0x2bc1>
    c49a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c49f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c4a6:	00 f0 3f 
    c4a9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c4b0:	00 
    c4b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c4b6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c4bd:	00 
    c4be:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c4c5:	00 
    c4c6:	e8 e5 98 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c4cb:	48 8b 15 c6 86 01 00 	mov    0x186c6(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c4d2:	49 89 c5             	mov    %rax,%r13
    c4d5:	48 2b 05 94 86 01 00 	sub    0x18694(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c4dc:	48 c1 e2 10          	shl    $0x10,%rdx
    c4e0:	48 39 d0             	cmp    %rdx,%rax
    c4e3:	73 59                	jae    c53e <f0+0x19ee>
    c4e5:	48 89 c2             	mov    %rax,%rdx
    c4e8:	48 c1 ea 10          	shr    $0x10,%rdx
    c4ec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c4f0:	48 8b 15 c1 86 01 00 	mov    0x186c1(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c4f7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c4fb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c4ff:	4d 85 e4             	test   %r12,%r12
    c502:	74 3a                	je     c53e <f0+0x19ee>
    c504:	0f b6 0a             	movzbl (%rdx),%ecx
    c507:	80 f9 02             	cmp    $0x2,%cl
    c50a:	0f 84 40 0f 00 00    	je     d450 <f0+0x2900>
    c510:	80 f9 01             	cmp    $0x1,%cl
    c513:	75 29                	jne    c53e <f0+0x19ee>
    c515:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c518:	0f b7 c0             	movzwl %ax,%eax
    c51b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c51e:	48 0f af c1          	imul   %rcx,%rax
    c522:	48 c1 e8 20          	shr    $0x20,%rax
    c526:	48 39 d0             	cmp    %rdx,%rax
    c529:	73 13                	jae    c53e <f0+0x19ee>
    c52b:	49 01 c4             	add    %rax,%r12
    c52e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c533:	0f 84 e5 11 00 00    	je     d71e <f0+0x2bce>
    c539:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c53e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c545:	33 f3 bf 
    c548:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c54f:	00 
    c550:	bf 01 00 00 00       	mov    $0x1,%edi
    c555:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c55c:	00 
    c55d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c564:	00 
    c565:	e8 46 98 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c56a:	48 8b 15 27 86 01 00 	mov    0x18627(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c571:	49 89 c5             	mov    %rax,%r13
    c574:	48 2b 05 f5 85 01 00 	sub    0x185f5(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c57b:	48 c1 e2 10          	shl    $0x10,%rdx
    c57f:	48 39 d0             	cmp    %rdx,%rax
    c582:	73 59                	jae    c5dd <f0+0x1a8d>
    c584:	48 89 c2             	mov    %rax,%rdx
    c587:	48 c1 ea 10          	shr    $0x10,%rdx
    c58b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c58f:	48 8b 15 22 86 01 00 	mov    0x18622(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c596:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c59a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c59e:	4d 85 e4             	test   %r12,%r12
    c5a1:	74 3a                	je     c5dd <f0+0x1a8d>
    c5a3:	0f b6 0a             	movzbl (%rdx),%ecx
    c5a6:	80 f9 02             	cmp    $0x2,%cl
    c5a9:	0f 84 91 0e 00 00    	je     d440 <f0+0x28f0>
    c5af:	80 f9 01             	cmp    $0x1,%cl
    c5b2:	75 29                	jne    c5dd <f0+0x1a8d>
    c5b4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5b7:	0f b7 c0             	movzwl %ax,%eax
    c5ba:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5bd:	48 0f af c1          	imul   %rcx,%rax
    c5c1:	48 c1 e8 20          	shr    $0x20,%rax
    c5c5:	48 39 d0             	cmp    %rdx,%rax
    c5c8:	73 13                	jae    c5dd <f0+0x1a8d>
    c5ca:	49 01 c4             	add    %rax,%r12
    c5cd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5d2:	0f 84 53 11 00 00    	je     d72b <f0+0x2bdb>
    c5d8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c5dd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c5e4:	00 f0 3f 
    c5e7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c5ee:	00 
    c5ef:	bf 01 00 00 00       	mov    $0x1,%edi
    c5f4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c5fb:	00 
    c5fc:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c603:	00 
    c604:	e8 a7 97 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c609:	48 8b 15 88 85 01 00 	mov    0x18588(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c610:	49 89 c5             	mov    %rax,%r13
    c613:	48 2b 05 56 85 01 00 	sub    0x18556(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c61a:	48 c1 e2 10          	shl    $0x10,%rdx
    c61e:	48 39 d0             	cmp    %rdx,%rax
    c621:	73 59                	jae    c67c <f0+0x1b2c>
    c623:	48 89 c2             	mov    %rax,%rdx
    c626:	48 c1 ea 10          	shr    $0x10,%rdx
    c62a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c62e:	48 8b 15 83 85 01 00 	mov    0x18583(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c635:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c639:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c63d:	4d 85 e4             	test   %r12,%r12
    c640:	74 3a                	je     c67c <f0+0x1b2c>
    c642:	0f b6 0a             	movzbl (%rdx),%ecx
    c645:	80 f9 02             	cmp    $0x2,%cl
    c648:	0f 84 e2 0d 00 00    	je     d430 <f0+0x28e0>
    c64e:	80 f9 01             	cmp    $0x1,%cl
    c651:	75 29                	jne    c67c <f0+0x1b2c>
    c653:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c656:	0f b7 c0             	movzwl %ax,%eax
    c659:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c65c:	48 0f af c1          	imul   %rcx,%rax
    c660:	48 c1 e8 20          	shr    $0x20,%rax
    c664:	48 39 d0             	cmp    %rdx,%rax
    c667:	73 13                	jae    c67c <f0+0x1b2c>
    c669:	49 01 c4             	add    %rax,%r12
    c66c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c671:	0f 84 c1 10 00 00    	je     d738 <f0+0x2be8>
    c677:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c67c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c683:	33 f3 bf 
    c686:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    c68d:	00 
    c68e:	bf 01 00 00 00       	mov    $0x1,%edi
    c693:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    c69a:	00 
    c69b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    c6a2:	00 
    c6a3:	e8 08 97 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c6a8:	48 8b 15 e9 84 01 00 	mov    0x184e9(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c6af:	49 89 c5             	mov    %rax,%r13
    c6b2:	48 2b 05 b7 84 01 00 	sub    0x184b7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c6b9:	48 c1 e2 10          	shl    $0x10,%rdx
    c6bd:	48 39 d0             	cmp    %rdx,%rax
    c6c0:	73 59                	jae    c71b <f0+0x1bcb>
    c6c2:	48 89 c2             	mov    %rax,%rdx
    c6c5:	48 c1 ea 10          	shr    $0x10,%rdx
    c6c9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6cd:	48 8b 15 e4 84 01 00 	mov    0x184e4(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c6d4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c6d8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c6dc:	4d 85 e4             	test   %r12,%r12
    c6df:	74 3a                	je     c71b <f0+0x1bcb>
    c6e1:	0f b6 0a             	movzbl (%rdx),%ecx
    c6e4:	80 f9 02             	cmp    $0x2,%cl
    c6e7:	0f 84 33 0d 00 00    	je     d420 <f0+0x28d0>
    c6ed:	80 f9 01             	cmp    $0x1,%cl
    c6f0:	75 29                	jne    c71b <f0+0x1bcb>
    c6f2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c6f5:	0f b7 c0             	movzwl %ax,%eax
    c6f8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c6fb:	48 0f af c1          	imul   %rcx,%rax
    c6ff:	48 c1 e8 20          	shr    $0x20,%rax
    c703:	48 39 d0             	cmp    %rdx,%rax
    c706:	73 13                	jae    c71b <f0+0x1bcb>
    c708:	49 01 c4             	add    %rax,%r12
    c70b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c710:	0f 84 2f 10 00 00    	je     d745 <f0+0x2bf5>
    c716:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c71b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c722:	00 f0 3f 
    c725:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    c72c:	00 
    c72d:	bf 01 00 00 00       	mov    $0x1,%edi
    c732:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    c739:	00 
    c73a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    c741:	00 
    c742:	e8 69 96 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c747:	48 8b 15 4a 84 01 00 	mov    0x1844a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c74e:	49 89 c5             	mov    %rax,%r13
    c751:	48 2b 05 18 84 01 00 	sub    0x18418(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c758:	48 c1 e2 10          	shl    $0x10,%rdx
    c75c:	48 39 d0             	cmp    %rdx,%rax
    c75f:	73 59                	jae    c7ba <f0+0x1c6a>
    c761:	48 89 c2             	mov    %rax,%rdx
    c764:	48 c1 ea 10          	shr    $0x10,%rdx
    c768:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c76c:	48 8b 15 45 84 01 00 	mov    0x18445(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c773:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c777:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c77b:	4d 85 e4             	test   %r12,%r12
    c77e:	74 3a                	je     c7ba <f0+0x1c6a>
    c780:	0f b6 0a             	movzbl (%rdx),%ecx
    c783:	80 f9 02             	cmp    $0x2,%cl
    c786:	0f 84 84 0c 00 00    	je     d410 <f0+0x28c0>
    c78c:	80 f9 01             	cmp    $0x1,%cl
    c78f:	75 29                	jne    c7ba <f0+0x1c6a>
    c791:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c794:	0f b7 c0             	movzwl %ax,%eax
    c797:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c79a:	48 0f af c1          	imul   %rcx,%rax
    c79e:	48 c1 e8 20          	shr    $0x20,%rax
    c7a2:	48 39 d0             	cmp    %rdx,%rax
    c7a5:	73 13                	jae    c7ba <f0+0x1c6a>
    c7a7:	49 01 c4             	add    %rax,%r12
    c7aa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7af:	0f 84 9d 0f 00 00    	je     d752 <f0+0x2c02>
    c7b5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7ba:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c7c1:	33 f3 bf 
    c7c4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    c7cb:	00 
    c7cc:	bf 01 00 00 00       	mov    $0x1,%edi
    c7d1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    c7d8:	00 
    c7d9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    c7e0:	00 
    c7e1:	e8 ca 95 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c7e6:	48 8b 15 ab 83 01 00 	mov    0x183ab(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c7ed:	49 89 c5             	mov    %rax,%r13
    c7f0:	48 2b 05 79 83 01 00 	sub    0x18379(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c7f7:	48 c1 e2 10          	shl    $0x10,%rdx
    c7fb:	48 39 d0             	cmp    %rdx,%rax
    c7fe:	73 59                	jae    c859 <f0+0x1d09>
    c800:	48 89 c2             	mov    %rax,%rdx
    c803:	48 c1 ea 10          	shr    $0x10,%rdx
    c807:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c80b:	48 8b 15 a6 83 01 00 	mov    0x183a6(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c812:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c816:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c81a:	4d 85 e4             	test   %r12,%r12
    c81d:	74 3a                	je     c859 <f0+0x1d09>
    c81f:	0f b6 0a             	movzbl (%rdx),%ecx
    c822:	80 f9 02             	cmp    $0x2,%cl
    c825:	0f 84 d5 0b 00 00    	je     d400 <f0+0x28b0>
    c82b:	80 f9 01             	cmp    $0x1,%cl
    c82e:	75 29                	jne    c859 <f0+0x1d09>
    c830:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c833:	0f b7 c0             	movzwl %ax,%eax
    c836:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c839:	48 0f af c1          	imul   %rcx,%rax
    c83d:	48 c1 e8 20          	shr    $0x20,%rax
    c841:	48 39 d0             	cmp    %rdx,%rax
    c844:	73 13                	jae    c859 <f0+0x1d09>
    c846:	49 01 c4             	add    %rax,%r12
    c849:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c84e:	0f 84 0b 0f 00 00    	je     d75f <f0+0x2c0f>
    c854:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c859:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c860:	00 f0 3f 
    c863:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    c86a:	00 
    c86b:	bf 01 00 00 00       	mov    $0x1,%edi
    c870:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    c877:	00 
    c878:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    c87f:	00 
    c880:	e8 2b 95 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c885:	48 8b 15 0c 83 01 00 	mov    0x1830c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c88c:	49 89 c5             	mov    %rax,%r13
    c88f:	48 2b 05 da 82 01 00 	sub    0x182da(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c896:	48 c1 e2 10          	shl    $0x10,%rdx
    c89a:	48 39 d0             	cmp    %rdx,%rax
    c89d:	73 59                	jae    c8f8 <f0+0x1da8>
    c89f:	48 89 c2             	mov    %rax,%rdx
    c8a2:	48 c1 ea 10          	shr    $0x10,%rdx
    c8a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8aa:	48 8b 15 07 83 01 00 	mov    0x18307(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c8b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8b5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8b9:	4d 85 e4             	test   %r12,%r12
    c8bc:	74 3a                	je     c8f8 <f0+0x1da8>
    c8be:	0f b6 0a             	movzbl (%rdx),%ecx
    c8c1:	80 f9 02             	cmp    $0x2,%cl
    c8c4:	0f 84 26 0b 00 00    	je     d3f0 <f0+0x28a0>
    c8ca:	80 f9 01             	cmp    $0x1,%cl
    c8cd:	75 29                	jne    c8f8 <f0+0x1da8>
    c8cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8d2:	0f b7 c0             	movzwl %ax,%eax
    c8d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8d8:	48 0f af c1          	imul   %rcx,%rax
    c8dc:	48 c1 e8 20          	shr    $0x20,%rax
    c8e0:	48 39 d0             	cmp    %rdx,%rax
    c8e3:	73 13                	jae    c8f8 <f0+0x1da8>
    c8e5:	49 01 c4             	add    %rax,%r12
    c8e8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8ed:	0f 84 79 0e 00 00    	je     d76c <f0+0x2c1c>
    c8f3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8f8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c8ff:	33 f3 bf 
    c902:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    c909:	00 
    c90a:	bf 01 00 00 00       	mov    $0x1,%edi
    c90f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    c916:	00 
    c917:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    c91e:	00 
    c91f:	e8 8c 94 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c924:	48 8b 15 6d 82 01 00 	mov    0x1826d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c92b:	49 89 c5             	mov    %rax,%r13
    c92e:	48 2b 05 3b 82 01 00 	sub    0x1823b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c935:	48 c1 e2 10          	shl    $0x10,%rdx
    c939:	48 39 d0             	cmp    %rdx,%rax
    c93c:	73 59                	jae    c997 <f0+0x1e47>
    c93e:	48 89 c2             	mov    %rax,%rdx
    c941:	48 c1 ea 10          	shr    $0x10,%rdx
    c945:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c949:	48 8b 15 68 82 01 00 	mov    0x18268(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c950:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c954:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c958:	4d 85 e4             	test   %r12,%r12
    c95b:	74 3a                	je     c997 <f0+0x1e47>
    c95d:	0f b6 0a             	movzbl (%rdx),%ecx
    c960:	80 f9 02             	cmp    $0x2,%cl
    c963:	0f 84 77 0a 00 00    	je     d3e0 <f0+0x2890>
    c969:	80 f9 01             	cmp    $0x1,%cl
    c96c:	75 29                	jne    c997 <f0+0x1e47>
    c96e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c971:	0f b7 c0             	movzwl %ax,%eax
    c974:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c977:	48 0f af c1          	imul   %rcx,%rax
    c97b:	48 c1 e8 20          	shr    $0x20,%rax
    c97f:	48 39 d0             	cmp    %rdx,%rax
    c982:	73 13                	jae    c997 <f0+0x1e47>
    c984:	49 01 c4             	add    %rax,%r12
    c987:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c98c:	0f 84 e7 0d 00 00    	je     d779 <f0+0x2c29>
    c992:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c997:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c99e:	00 f0 3f 
    c9a1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    c9a8:	00 
    c9a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c9ae:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    c9b5:	00 
    c9b6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    c9bd:	00 
    c9be:	e8 ed 93 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c9c3:	48 8b 15 ce 81 01 00 	mov    0x181ce(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c9ca:	49 89 c5             	mov    %rax,%r13
    c9cd:	48 2b 05 9c 81 01 00 	sub    0x1819c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c9d4:	48 c1 e2 10          	shl    $0x10,%rdx
    c9d8:	48 39 d0             	cmp    %rdx,%rax
    c9db:	73 59                	jae    ca36 <f0+0x1ee6>
    c9dd:	48 89 c2             	mov    %rax,%rdx
    c9e0:	48 c1 ea 10          	shr    $0x10,%rdx
    c9e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9e8:	48 8b 15 c9 81 01 00 	mov    0x181c9(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c9ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9f3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9f7:	4d 85 e4             	test   %r12,%r12
    c9fa:	74 3a                	je     ca36 <f0+0x1ee6>
    c9fc:	0f b6 0a             	movzbl (%rdx),%ecx
    c9ff:	80 f9 02             	cmp    $0x2,%cl
    ca02:	0f 84 38 0c 00 00    	je     d640 <f0+0x2af0>
    ca08:	80 f9 01             	cmp    $0x1,%cl
    ca0b:	75 29                	jne    ca36 <f0+0x1ee6>
    ca0d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca10:	0f b7 c0             	movzwl %ax,%eax
    ca13:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca16:	48 0f af c1          	imul   %rcx,%rax
    ca1a:	48 c1 e8 20          	shr    $0x20,%rax
    ca1e:	48 39 d0             	cmp    %rdx,%rax
    ca21:	73 13                	jae    ca36 <f0+0x1ee6>
    ca23:	49 01 c4             	add    %rax,%r12
    ca26:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca2b:	0f 84 55 0d 00 00    	je     d786 <f0+0x2c36>
    ca31:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca36:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca3d:	33 f3 bf 
    ca40:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    ca47:	00 
    ca48:	bf 01 00 00 00       	mov    $0x1,%edi
    ca4d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    ca54:	00 
    ca55:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    ca5c:	00 
    ca5d:	e8 4e 93 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ca62:	48 8b 15 2f 81 01 00 	mov    0x1812f(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ca69:	49 89 c5             	mov    %rax,%r13
    ca6c:	48 2b 05 fd 80 01 00 	sub    0x180fd(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ca73:	48 c1 e2 10          	shl    $0x10,%rdx
    ca77:	48 39 d0             	cmp    %rdx,%rax
    ca7a:	73 59                	jae    cad5 <f0+0x1f85>
    ca7c:	48 89 c2             	mov    %rax,%rdx
    ca7f:	48 c1 ea 10          	shr    $0x10,%rdx
    ca83:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca87:	48 8b 15 2a 81 01 00 	mov    0x1812a(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ca8e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca92:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca96:	4d 85 e4             	test   %r12,%r12
    ca99:	74 3a                	je     cad5 <f0+0x1f85>
    ca9b:	0f b6 0a             	movzbl (%rdx),%ecx
    ca9e:	80 f9 02             	cmp    $0x2,%cl
    caa1:	0f 84 89 0b 00 00    	je     d630 <f0+0x2ae0>
    caa7:	80 f9 01             	cmp    $0x1,%cl
    caaa:	75 29                	jne    cad5 <f0+0x1f85>
    caac:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caaf:	0f b7 c0             	movzwl %ax,%eax
    cab2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cab5:	48 0f af c1          	imul   %rcx,%rax
    cab9:	48 c1 e8 20          	shr    $0x20,%rax
    cabd:	48 39 d0             	cmp    %rdx,%rax
    cac0:	73 13                	jae    cad5 <f0+0x1f85>
    cac2:	49 01 c4             	add    %rax,%r12
    cac5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    caca:	0f 84 c3 0c 00 00    	je     d793 <f0+0x2c43>
    cad0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cad5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cadc:	00 f0 3f 
    cadf:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    cae6:	00 
    cae7:	bf 01 00 00 00       	mov    $0x1,%edi
    caec:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    caf3:	00 
    caf4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    cafb:	00 
    cafc:	e8 af 92 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cb01:	48 8b 15 90 80 01 00 	mov    0x18090(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cb08:	49 89 c5             	mov    %rax,%r13
    cb0b:	48 2b 05 5e 80 01 00 	sub    0x1805e(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cb12:	48 c1 e2 10          	shl    $0x10,%rdx
    cb16:	48 39 d0             	cmp    %rdx,%rax
    cb19:	73 59                	jae    cb74 <f0+0x2024>
    cb1b:	48 89 c2             	mov    %rax,%rdx
    cb1e:	48 c1 ea 10          	shr    $0x10,%rdx
    cb22:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb26:	48 8b 15 8b 80 01 00 	mov    0x1808b(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cb2d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb31:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb35:	4d 85 e4             	test   %r12,%r12
    cb38:	74 3a                	je     cb74 <f0+0x2024>
    cb3a:	0f b6 0a             	movzbl (%rdx),%ecx
    cb3d:	80 f9 02             	cmp    $0x2,%cl
    cb40:	0f 84 da 0a 00 00    	je     d620 <f0+0x2ad0>
    cb46:	80 f9 01             	cmp    $0x1,%cl
    cb49:	75 29                	jne    cb74 <f0+0x2024>
    cb4b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb4e:	0f b7 c0             	movzwl %ax,%eax
    cb51:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb54:	48 0f af c1          	imul   %rcx,%rax
    cb58:	48 c1 e8 20          	shr    $0x20,%rax
    cb5c:	48 39 d0             	cmp    %rdx,%rax
    cb5f:	73 13                	jae    cb74 <f0+0x2024>
    cb61:	49 01 c4             	add    %rax,%r12
    cb64:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb69:	0f 84 31 0c 00 00    	je     d7a0 <f0+0x2c50>
    cb6f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb74:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb7b:	33 f3 bf 
    cb7e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    cb85:	00 
    cb86:	bf 01 00 00 00       	mov    $0x1,%edi
    cb8b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    cb92:	00 
    cb93:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    cb9a:	00 
    cb9b:	e8 10 92 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cba0:	48 8b 15 f1 7f 01 00 	mov    0x17ff1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cba7:	49 89 c5             	mov    %rax,%r13
    cbaa:	48 2b 05 bf 7f 01 00 	sub    0x17fbf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cbb1:	48 c1 e2 10          	shl    $0x10,%rdx
    cbb5:	48 39 d0             	cmp    %rdx,%rax
    cbb8:	73 59                	jae    cc13 <f0+0x20c3>
    cbba:	48 89 c2             	mov    %rax,%rdx
    cbbd:	48 c1 ea 10          	shr    $0x10,%rdx
    cbc1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbc5:	48 8b 15 ec 7f 01 00 	mov    0x17fec(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cbcc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbd0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbd4:	4d 85 e4             	test   %r12,%r12
    cbd7:	74 3a                	je     cc13 <f0+0x20c3>
    cbd9:	0f b6 0a             	movzbl (%rdx),%ecx
    cbdc:	80 f9 02             	cmp    $0x2,%cl
    cbdf:	0f 84 2b 0a 00 00    	je     d610 <f0+0x2ac0>
    cbe5:	80 f9 01             	cmp    $0x1,%cl
    cbe8:	75 29                	jne    cc13 <f0+0x20c3>
    cbea:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbed:	0f b7 c0             	movzwl %ax,%eax
    cbf0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbf3:	48 0f af c1          	imul   %rcx,%rax
    cbf7:	48 c1 e8 20          	shr    $0x20,%rax
    cbfb:	48 39 d0             	cmp    %rdx,%rax
    cbfe:	73 13                	jae    cc13 <f0+0x20c3>
    cc00:	49 01 c4             	add    %rax,%r12
    cc03:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc08:	0f 84 9f 0b 00 00    	je     d7ad <f0+0x2c5d>
    cc0e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc13:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc1a:	00 f0 3f 
    cc1d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    cc24:	00 
    cc25:	bf 01 00 00 00       	mov    $0x1,%edi
    cc2a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    cc31:	00 
    cc32:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    cc39:	00 
    cc3a:	e8 71 91 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cc3f:	48 8b 15 52 7f 01 00 	mov    0x17f52(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cc46:	49 89 c5             	mov    %rax,%r13
    cc49:	48 2b 05 20 7f 01 00 	sub    0x17f20(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cc50:	48 c1 e2 10          	shl    $0x10,%rdx
    cc54:	48 39 d0             	cmp    %rdx,%rax
    cc57:	73 59                	jae    ccb2 <f0+0x2162>
    cc59:	48 89 c2             	mov    %rax,%rdx
    cc5c:	48 c1 ea 10          	shr    $0x10,%rdx
    cc60:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc64:	48 8b 15 4d 7f 01 00 	mov    0x17f4d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cc6b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc6f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc73:	4d 85 e4             	test   %r12,%r12
    cc76:	74 3a                	je     ccb2 <f0+0x2162>
    cc78:	0f b6 0a             	movzbl (%rdx),%ecx
    cc7b:	80 f9 02             	cmp    $0x2,%cl
    cc7e:	0f 84 7c 09 00 00    	je     d600 <f0+0x2ab0>
    cc84:	80 f9 01             	cmp    $0x1,%cl
    cc87:	75 29                	jne    ccb2 <f0+0x2162>
    cc89:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc8c:	0f b7 c0             	movzwl %ax,%eax
    cc8f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc92:	48 0f af c1          	imul   %rcx,%rax
    cc96:	48 c1 e8 20          	shr    $0x20,%rax
    cc9a:	48 39 d0             	cmp    %rdx,%rax
    cc9d:	73 13                	jae    ccb2 <f0+0x2162>
    cc9f:	49 01 c4             	add    %rax,%r12
    cca2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cca7:	0f 84 0d 0b 00 00    	je     d7ba <f0+0x2c6a>
    ccad:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccb2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccb9:	33 f3 bf 
    ccbc:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    ccc3:	00 
    ccc4:	bf 01 00 00 00       	mov    $0x1,%edi
    ccc9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    ccd0:	00 
    ccd1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    ccd8:	00 
    ccd9:	e8 d2 90 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ccde:	48 8b 15 b3 7e 01 00 	mov    0x17eb3(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cce5:	49 89 c5             	mov    %rax,%r13
    cce8:	48 2b 05 81 7e 01 00 	sub    0x17e81(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ccef:	48 c1 e2 10          	shl    $0x10,%rdx
    ccf3:	48 39 d0             	cmp    %rdx,%rax
    ccf6:	73 59                	jae    cd51 <f0+0x2201>
    ccf8:	48 89 c2             	mov    %rax,%rdx
    ccfb:	48 c1 ea 10          	shr    $0x10,%rdx
    ccff:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd03:	48 8b 15 ae 7e 01 00 	mov    0x17eae(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cd0a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd0e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd12:	4d 85 e4             	test   %r12,%r12
    cd15:	74 3a                	je     cd51 <f0+0x2201>
    cd17:	0f b6 0a             	movzbl (%rdx),%ecx
    cd1a:	80 f9 02             	cmp    $0x2,%cl
    cd1d:	0f 84 cd 08 00 00    	je     d5f0 <f0+0x2aa0>
    cd23:	80 f9 01             	cmp    $0x1,%cl
    cd26:	75 29                	jne    cd51 <f0+0x2201>
    cd28:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd2b:	0f b7 c0             	movzwl %ax,%eax
    cd2e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd31:	48 0f af c1          	imul   %rcx,%rax
    cd35:	48 c1 e8 20          	shr    $0x20,%rax
    cd39:	48 39 d0             	cmp    %rdx,%rax
    cd3c:	73 13                	jae    cd51 <f0+0x2201>
    cd3e:	49 01 c4             	add    %rax,%r12
    cd41:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd46:	0f 84 7b 0a 00 00    	je     d7c7 <f0+0x2c77>
    cd4c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd51:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd58:	00 f0 3f 
    cd5b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    cd62:	00 
    cd63:	bf 01 00 00 00       	mov    $0x1,%edi
    cd68:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    cd6f:	00 
    cd70:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    cd77:	00 
    cd78:	e8 33 90 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cd7d:	48 8b 15 14 7e 01 00 	mov    0x17e14(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cd84:	49 89 c5             	mov    %rax,%r13
    cd87:	48 2b 05 e2 7d 01 00 	sub    0x17de2(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cd8e:	48 c1 e2 10          	shl    $0x10,%rdx
    cd92:	48 39 d0             	cmp    %rdx,%rax
    cd95:	73 59                	jae    cdf0 <f0+0x22a0>
    cd97:	48 89 c2             	mov    %rax,%rdx
    cd9a:	48 c1 ea 10          	shr    $0x10,%rdx
    cd9e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cda2:	48 8b 15 0f 7e 01 00 	mov    0x17e0f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cda9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdad:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdb1:	4d 85 e4             	test   %r12,%r12
    cdb4:	74 3a                	je     cdf0 <f0+0x22a0>
    cdb6:	0f b6 0a             	movzbl (%rdx),%ecx
    cdb9:	80 f9 02             	cmp    $0x2,%cl
    cdbc:	0f 84 1e 08 00 00    	je     d5e0 <f0+0x2a90>
    cdc2:	80 f9 01             	cmp    $0x1,%cl
    cdc5:	75 29                	jne    cdf0 <f0+0x22a0>
    cdc7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdca:	0f b7 c0             	movzwl %ax,%eax
    cdcd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdd0:	48 0f af c1          	imul   %rcx,%rax
    cdd4:	48 c1 e8 20          	shr    $0x20,%rax
    cdd8:	48 39 d0             	cmp    %rdx,%rax
    cddb:	73 13                	jae    cdf0 <f0+0x22a0>
    cddd:	49 01 c4             	add    %rax,%r12
    cde0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cde5:	0f 84 e9 09 00 00    	je     d7d4 <f0+0x2c84>
    cdeb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdf0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cdf7:	33 f3 bf 
    cdfa:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    ce01:	00 
    ce02:	bf 01 00 00 00       	mov    $0x1,%edi
    ce07:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    ce0e:	00 
    ce0f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    ce16:	00 
    ce17:	e8 94 8f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ce1c:	48 8b 15 75 7d 01 00 	mov    0x17d75(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ce23:	49 89 c5             	mov    %rax,%r13
    ce26:	48 2b 05 43 7d 01 00 	sub    0x17d43(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ce2d:	48 c1 e2 10          	shl    $0x10,%rdx
    ce31:	48 39 d0             	cmp    %rdx,%rax
    ce34:	73 59                	jae    ce8f <f0+0x233f>
    ce36:	48 89 c2             	mov    %rax,%rdx
    ce39:	48 c1 ea 10          	shr    $0x10,%rdx
    ce3d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce41:	48 8b 15 70 7d 01 00 	mov    0x17d70(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ce48:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce4c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce50:	4d 85 e4             	test   %r12,%r12
    ce53:	74 3a                	je     ce8f <f0+0x233f>
    ce55:	0f b6 0a             	movzbl (%rdx),%ecx
    ce58:	80 f9 02             	cmp    $0x2,%cl
    ce5b:	0f 84 6f 07 00 00    	je     d5d0 <f0+0x2a80>
    ce61:	80 f9 01             	cmp    $0x1,%cl
    ce64:	75 29                	jne    ce8f <f0+0x233f>
    ce66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce69:	0f b7 c0             	movzwl %ax,%eax
    ce6c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce6f:	48 0f af c1          	imul   %rcx,%rax
    ce73:	48 c1 e8 20          	shr    $0x20,%rax
    ce77:	48 39 d0             	cmp    %rdx,%rax
    ce7a:	73 13                	jae    ce8f <f0+0x233f>
    ce7c:	49 01 c4             	add    %rax,%r12
    ce7f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce84:	0f 84 57 09 00 00    	je     d7e1 <f0+0x2c91>
    ce8a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce8f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce96:	00 f0 3f 
    ce99:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    cea0:	00 
    cea1:	bf 01 00 00 00       	mov    $0x1,%edi
    cea6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    cead:	00 
    ceae:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    ceb5:	00 
    ceb6:	e8 f5 8e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cebb:	48 8b 15 d6 7c 01 00 	mov    0x17cd6(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cec2:	49 89 c5             	mov    %rax,%r13
    cec5:	48 2b 05 a4 7c 01 00 	sub    0x17ca4(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cecc:	48 c1 e2 10          	shl    $0x10,%rdx
    ced0:	48 39 d0             	cmp    %rdx,%rax
    ced3:	73 59                	jae    cf2e <f0+0x23de>
    ced5:	48 89 c2             	mov    %rax,%rdx
    ced8:	48 c1 ea 10          	shr    $0x10,%rdx
    cedc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cee0:	48 8b 15 d1 7c 01 00 	mov    0x17cd1(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cee7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ceeb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ceef:	4d 85 e4             	test   %r12,%r12
    cef2:	74 3a                	je     cf2e <f0+0x23de>
    cef4:	0f b6 0a             	movzbl (%rdx),%ecx
    cef7:	80 f9 02             	cmp    $0x2,%cl
    cefa:	0f 84 c0 06 00 00    	je     d5c0 <f0+0x2a70>
    cf00:	80 f9 01             	cmp    $0x1,%cl
    cf03:	75 29                	jne    cf2e <f0+0x23de>
    cf05:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf08:	0f b7 c0             	movzwl %ax,%eax
    cf0b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf0e:	48 0f af c1          	imul   %rcx,%rax
    cf12:	48 c1 e8 20          	shr    $0x20,%rax
    cf16:	48 39 d0             	cmp    %rdx,%rax
    cf19:	73 13                	jae    cf2e <f0+0x23de>
    cf1b:	49 01 c4             	add    %rax,%r12
    cf1e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf23:	0f 84 c5 08 00 00    	je     d7ee <f0+0x2c9e>
    cf29:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf2e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf35:	33 f3 bf 
    cf38:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    cf3f:	00 
    cf40:	bf 01 00 00 00       	mov    $0x1,%edi
    cf45:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    cf4c:	00 
    cf4d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    cf54:	00 
    cf55:	e8 56 8e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cf5a:	48 8b 15 37 7c 01 00 	mov    0x17c37(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cf61:	49 89 c5             	mov    %rax,%r13
    cf64:	48 2b 05 05 7c 01 00 	sub    0x17c05(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cf6b:	48 c1 e2 10          	shl    $0x10,%rdx
    cf6f:	48 39 d0             	cmp    %rdx,%rax
    cf72:	73 59                	jae    cfcd <f0+0x247d>
    cf74:	48 89 c2             	mov    %rax,%rdx
    cf77:	48 c1 ea 10          	shr    $0x10,%rdx
    cf7b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf7f:	48 8b 15 32 7c 01 00 	mov    0x17c32(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cf86:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf8a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf8e:	4d 85 e4             	test   %r12,%r12
    cf91:	74 3a                	je     cfcd <f0+0x247d>
    cf93:	0f b6 0a             	movzbl (%rdx),%ecx
    cf96:	80 f9 02             	cmp    $0x2,%cl
    cf99:	0f 84 11 06 00 00    	je     d5b0 <f0+0x2a60>
    cf9f:	80 f9 01             	cmp    $0x1,%cl
    cfa2:	75 29                	jne    cfcd <f0+0x247d>
    cfa4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfa7:	0f b7 c0             	movzwl %ax,%eax
    cfaa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfad:	48 0f af c1          	imul   %rcx,%rax
    cfb1:	48 c1 e8 20          	shr    $0x20,%rax
    cfb5:	48 39 d0             	cmp    %rdx,%rax
    cfb8:	73 13                	jae    cfcd <f0+0x247d>
    cfba:	49 01 c4             	add    %rax,%r12
    cfbd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfc2:	0f 84 33 08 00 00    	je     d7fb <f0+0x2cab>
    cfc8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfcd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cfd4:	00 f0 3f 
    cfd7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    cfde:	00 
    cfdf:	bf 01 00 00 00       	mov    $0x1,%edi
    cfe4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    cfeb:	00 
    cfec:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    cff3:	00 
    cff4:	e8 b7 8d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cff9:	48 8b 15 98 7b 01 00 	mov    0x17b98(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d000:	49 89 c5             	mov    %rax,%r13
    d003:	48 2b 05 66 7b 01 00 	sub    0x17b66(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d00a:	48 c1 e2 10          	shl    $0x10,%rdx
    d00e:	48 39 d0             	cmp    %rdx,%rax
    d011:	73 59                	jae    d06c <f0+0x251c>
    d013:	48 89 c2             	mov    %rax,%rdx
    d016:	48 c1 ea 10          	shr    $0x10,%rdx
    d01a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d01e:	48 8b 15 93 7b 01 00 	mov    0x17b93(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d025:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d029:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d02d:	4d 85 e4             	test   %r12,%r12
    d030:	74 3a                	je     d06c <f0+0x251c>
    d032:	0f b6 0a             	movzbl (%rdx),%ecx
    d035:	80 f9 02             	cmp    $0x2,%cl
    d038:	0f 84 62 05 00 00    	je     d5a0 <f0+0x2a50>
    d03e:	80 f9 01             	cmp    $0x1,%cl
    d041:	75 29                	jne    d06c <f0+0x251c>
    d043:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d046:	0f b7 c0             	movzwl %ax,%eax
    d049:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d04c:	48 0f af c1          	imul   %rcx,%rax
    d050:	48 c1 e8 20          	shr    $0x20,%rax
    d054:	48 39 d0             	cmp    %rdx,%rax
    d057:	73 13                	jae    d06c <f0+0x251c>
    d059:	49 01 c4             	add    %rax,%r12
    d05c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d061:	0f 84 a1 07 00 00    	je     d808 <f0+0x2cb8>
    d067:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d06c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d073:	33 f3 bf 
    d076:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d07d:	00 
    d07e:	bf 01 00 00 00       	mov    $0x1,%edi
    d083:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d08a:	00 
    d08b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d092:	00 
    d093:	e8 18 8d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d098:	48 8b 15 f9 7a 01 00 	mov    0x17af9(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d09f:	49 89 c5             	mov    %rax,%r13
    d0a2:	48 2b 05 c7 7a 01 00 	sub    0x17ac7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d0a9:	48 c1 e2 10          	shl    $0x10,%rdx
    d0ad:	48 39 d0             	cmp    %rdx,%rax
    d0b0:	73 59                	jae    d10b <f0+0x25bb>
    d0b2:	48 89 c2             	mov    %rax,%rdx
    d0b5:	48 c1 ea 10          	shr    $0x10,%rdx
    d0b9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0bd:	48 8b 15 f4 7a 01 00 	mov    0x17af4(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d0c4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0c8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0cc:	4d 85 e4             	test   %r12,%r12
    d0cf:	74 3a                	je     d10b <f0+0x25bb>
    d0d1:	0f b6 0a             	movzbl (%rdx),%ecx
    d0d4:	80 f9 02             	cmp    $0x2,%cl
    d0d7:	0f 84 b3 04 00 00    	je     d590 <f0+0x2a40>
    d0dd:	80 f9 01             	cmp    $0x1,%cl
    d0e0:	75 29                	jne    d10b <f0+0x25bb>
    d0e2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0e5:	0f b7 c0             	movzwl %ax,%eax
    d0e8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0eb:	48 0f af c1          	imul   %rcx,%rax
    d0ef:	48 c1 e8 20          	shr    $0x20,%rax
    d0f3:	48 39 d0             	cmp    %rdx,%rax
    d0f6:	73 13                	jae    d10b <f0+0x25bb>
    d0f8:	49 01 c4             	add    %rax,%r12
    d0fb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d100:	0f 84 0f 07 00 00    	je     d815 <f0+0x2cc5>
    d106:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d10b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d112:	00 f0 3f 
    d115:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d11c:	00 
    d11d:	bf 01 00 00 00       	mov    $0x1,%edi
    d122:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d129:	00 
    d12a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d131:	00 
    d132:	e8 79 8c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d137:	48 8b 15 5a 7a 01 00 	mov    0x17a5a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d13e:	49 89 c5             	mov    %rax,%r13
    d141:	48 2b 05 28 7a 01 00 	sub    0x17a28(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d148:	48 c1 e2 10          	shl    $0x10,%rdx
    d14c:	48 39 d0             	cmp    %rdx,%rax
    d14f:	73 59                	jae    d1aa <f0+0x265a>
    d151:	48 89 c2             	mov    %rax,%rdx
    d154:	48 c1 ea 10          	shr    $0x10,%rdx
    d158:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d15c:	48 8b 15 55 7a 01 00 	mov    0x17a55(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d163:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d167:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d16b:	4d 85 e4             	test   %r12,%r12
    d16e:	74 3a                	je     d1aa <f0+0x265a>
    d170:	0f b6 0a             	movzbl (%rdx),%ecx
    d173:	80 f9 02             	cmp    $0x2,%cl
    d176:	0f 84 04 04 00 00    	je     d580 <f0+0x2a30>
    d17c:	80 f9 01             	cmp    $0x1,%cl
    d17f:	75 29                	jne    d1aa <f0+0x265a>
    d181:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d184:	0f b7 c0             	movzwl %ax,%eax
    d187:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d18a:	48 0f af c1          	imul   %rcx,%rax
    d18e:	48 c1 e8 20          	shr    $0x20,%rax
    d192:	48 39 d0             	cmp    %rdx,%rax
    d195:	73 13                	jae    d1aa <f0+0x265a>
    d197:	49 01 c4             	add    %rax,%r12
    d19a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d19f:	0f 84 7d 06 00 00    	je     d822 <f0+0x2cd2>
    d1a5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1aa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1b1:	33 f3 bf 
    d1b4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d1bb:	00 
    d1bc:	bf 01 00 00 00       	mov    $0x1,%edi
    d1c1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d1c8:	00 
    d1c9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d1d0:	00 
    d1d1:	e8 da 8b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d1d6:	48 8b 15 bb 79 01 00 	mov    0x179bb(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d1dd:	49 89 c5             	mov    %rax,%r13
    d1e0:	48 2b 05 89 79 01 00 	sub    0x17989(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d1e7:	48 c1 e2 10          	shl    $0x10,%rdx
    d1eb:	48 39 d0             	cmp    %rdx,%rax
    d1ee:	73 59                	jae    d249 <f0+0x26f9>
    d1f0:	48 89 c2             	mov    %rax,%rdx
    d1f3:	48 c1 ea 10          	shr    $0x10,%rdx
    d1f7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1fb:	48 8b 15 b6 79 01 00 	mov    0x179b6(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d202:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d206:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d20a:	4d 85 e4             	test   %r12,%r12
    d20d:	74 3a                	je     d249 <f0+0x26f9>
    d20f:	0f b6 0a             	movzbl (%rdx),%ecx
    d212:	80 f9 02             	cmp    $0x2,%cl
    d215:	0f 84 55 03 00 00    	je     d570 <f0+0x2a20>
    d21b:	80 f9 01             	cmp    $0x1,%cl
    d21e:	75 29                	jne    d249 <f0+0x26f9>
    d220:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d223:	0f b7 c0             	movzwl %ax,%eax
    d226:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d229:	48 0f af c1          	imul   %rcx,%rax
    d22d:	48 c1 e8 20          	shr    $0x20,%rax
    d231:	48 39 d0             	cmp    %rdx,%rax
    d234:	73 13                	jae    d249 <f0+0x26f9>
    d236:	49 01 c4             	add    %rax,%r12
    d239:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d23e:	0f 84 eb 05 00 00    	je     d82f <f0+0x2cdf>
    d244:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d249:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d250:	00 f0 3f 
    d253:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d25a:	00 
    d25b:	bf 01 00 00 00       	mov    $0x1,%edi
    d260:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d267:	00 
    d268:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d26f:	00 
    d270:	e8 3b 8b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d275:	48 8b 15 1c 79 01 00 	mov    0x1791c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d27c:	49 89 c5             	mov    %rax,%r13
    d27f:	48 2b 05 ea 78 01 00 	sub    0x178ea(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d286:	48 c1 e2 10          	shl    $0x10,%rdx
    d28a:	48 39 d0             	cmp    %rdx,%rax
    d28d:	73 59                	jae    d2e8 <f0+0x2798>
    d28f:	48 89 c2             	mov    %rax,%rdx
    d292:	48 c1 ea 10          	shr    $0x10,%rdx
    d296:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d29a:	48 8b 15 17 79 01 00 	mov    0x17917(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d2a1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2a5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2a9:	4d 85 e4             	test   %r12,%r12
    d2ac:	74 3a                	je     d2e8 <f0+0x2798>
    d2ae:	0f b6 0a             	movzbl (%rdx),%ecx
    d2b1:	80 f9 02             	cmp    $0x2,%cl
    d2b4:	0f 84 a6 02 00 00    	je     d560 <f0+0x2a10>
    d2ba:	80 f9 01             	cmp    $0x1,%cl
    d2bd:	75 29                	jne    d2e8 <f0+0x2798>
    d2bf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2c2:	0f b7 c0             	movzwl %ax,%eax
    d2c5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2c8:	48 0f af c1          	imul   %rcx,%rax
    d2cc:	48 c1 e8 20          	shr    $0x20,%rax
    d2d0:	48 39 d0             	cmp    %rdx,%rax
    d2d3:	73 13                	jae    d2e8 <f0+0x2798>
    d2d5:	49 01 c4             	add    %rax,%r12
    d2d8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2dd:	0f 84 59 05 00 00    	je     d83c <f0+0x2cec>
    d2e3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2e8:	48 89 ee             	mov    %rbp,%rsi
    d2eb:	bf 01 00 00 00       	mov    $0x1,%edi
    d2f0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d2f7:	33 f3 bf 
    d2fa:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d301:	00 
    d302:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d309:	00 
    d30a:	e8 a1 8a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d30f:	48 8b 15 82 78 01 00 	mov    0x17882(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d316:	48 89 c5             	mov    %rax,%rbp
    d319:	48 2b 05 50 78 01 00 	sub    0x17850(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d320:	48 c1 e2 10          	shl    $0x10,%rdx
    d324:	48 39 d0             	cmp    %rdx,%rax
    d327:	73 59                	jae    d382 <f0+0x2832>
    d329:	48 89 c2             	mov    %rax,%rdx
    d32c:	48 c1 ea 10          	shr    $0x10,%rdx
    d330:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d334:	48 8b 15 7d 78 01 00 	mov    0x1787d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d33b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d33f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d343:	4d 85 e4             	test   %r12,%r12
    d346:	74 3a                	je     d382 <f0+0x2832>
    d348:	0f b6 0a             	movzbl (%rdx),%ecx
    d34b:	80 f9 02             	cmp    $0x2,%cl
    d34e:	0f 84 fc 01 00 00    	je     d550 <f0+0x2a00>
    d354:	80 f9 01             	cmp    $0x1,%cl
    d357:	75 29                	jne    d382 <f0+0x2832>
    d359:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d35c:	0f b7 c0             	movzwl %ax,%eax
    d35f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d362:	48 0f af c1          	imul   %rcx,%rax
    d366:	48 c1 e8 20          	shr    $0x20,%rax
    d36a:	48 39 d0             	cmp    %rdx,%rax
    d36d:	73 13                	jae    d382 <f0+0x2832>
    d36f:	49 01 c4             	add    %rax,%r12
    d372:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d377:	0f 84 d1 02 00 00    	je     d64e <f0+0x2afe>
    d37d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d382:	48 89 de             	mov    %rbx,%rsi
    d385:	48 89 ef             	mov    %rbp,%rdi
    d388:	e8 f3 be ff ff       	call   9280 <fwp_hof0.constprop.0>
    d38d:	48 89 ef             	mov    %rbp,%rdi
    d390:	e8 6b a3 ff ff       	call   7700 <fwp_drop0>
    d395:	48 89 df             	mov    %rbx,%rdi
    d398:	e8 63 a3 ff ff       	call   7700 <fwp_drop0>
    d39d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d3a4:	00 
    d3a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d3ac:	00 00 
    d3ae:	0f 85 95 04 00 00    	jne    d849 <f0+0x2cf9>
    d3b4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d3bb:	31 c0                	xor    %eax,%eax
    d3bd:	5b                   	pop    %rbx
    d3be:	5d                   	pop    %rbp
    d3bf:	41 5c                	pop    %r12
    d3c1:	41 5d                	pop    %r13
    d3c3:	41 5e                	pop    %r14
    d3c5:	c3                   	ret
    d3c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d3cd:	00 00 00 
    d3d0:	4c 89 ef             	mov    %r13,%rdi
    d3d3:	e8 78 81 ff ff       	call   5550 <fwp_rc_forget_slot>
    d3d8:	e9 2c d8 ff ff       	jmp    ac09 <f0+0xb9>
    d3dd:	0f 1f 00             	nopl   (%rax)
    d3e0:	66 85 c0             	test   %ax,%ax
    d3e3:	0f 85 ae f5 ff ff    	jne    c997 <f0+0x1e47>
    d3e9:	e9 99 f5 ff ff       	jmp    c987 <f0+0x1e37>
    d3ee:	66 90                	xchg   %ax,%ax
    d3f0:	66 85 c0             	test   %ax,%ax
    d3f3:	0f 85 ff f4 ff ff    	jne    c8f8 <f0+0x1da8>
    d3f9:	e9 ea f4 ff ff       	jmp    c8e8 <f0+0x1d98>
    d3fe:	66 90                	xchg   %ax,%ax
    d400:	66 85 c0             	test   %ax,%ax
    d403:	0f 85 50 f4 ff ff    	jne    c859 <f0+0x1d09>
    d409:	e9 3b f4 ff ff       	jmp    c849 <f0+0x1cf9>
    d40e:	66 90                	xchg   %ax,%ax
    d410:	66 85 c0             	test   %ax,%ax
    d413:	0f 85 a1 f3 ff ff    	jne    c7ba <f0+0x1c6a>
    d419:	e9 8c f3 ff ff       	jmp    c7aa <f0+0x1c5a>
    d41e:	66 90                	xchg   %ax,%ax
    d420:	66 85 c0             	test   %ax,%ax
    d423:	0f 85 f2 f2 ff ff    	jne    c71b <f0+0x1bcb>
    d429:	e9 dd f2 ff ff       	jmp    c70b <f0+0x1bbb>
    d42e:	66 90                	xchg   %ax,%ax
    d430:	66 85 c0             	test   %ax,%ax
    d433:	0f 85 43 f2 ff ff    	jne    c67c <f0+0x1b2c>
    d439:	e9 2e f2 ff ff       	jmp    c66c <f0+0x1b1c>
    d43e:	66 90                	xchg   %ax,%ax
    d440:	66 85 c0             	test   %ax,%ax
    d443:	0f 85 94 f1 ff ff    	jne    c5dd <f0+0x1a8d>
    d449:	e9 7f f1 ff ff       	jmp    c5cd <f0+0x1a7d>
    d44e:	66 90                	xchg   %ax,%ax
    d450:	66 85 c0             	test   %ax,%ax
    d453:	0f 85 e5 f0 ff ff    	jne    c53e <f0+0x19ee>
    d459:	e9 d0 f0 ff ff       	jmp    c52e <f0+0x19de>
    d45e:	66 90                	xchg   %ax,%ax
    d460:	66 85 c0             	test   %ax,%ax
    d463:	0f 85 fd d9 ff ff    	jne    ae66 <f0+0x316>
    d469:	e9 e8 d9 ff ff       	jmp    ae56 <f0+0x306>
    d46e:	66 90                	xchg   %ax,%ax
    d470:	66 85 c0             	test   %ax,%ax
    d473:	0f 85 57 d9 ff ff    	jne    add0 <f0+0x280>
    d479:	e9 42 d9 ff ff       	jmp    adc0 <f0+0x270>
    d47e:	66 90                	xchg   %ax,%ax
    d480:	66 85 c0             	test   %ax,%ax
    d483:	0f 85 b1 d8 ff ff    	jne    ad3a <f0+0x1ea>
    d489:	e9 9c d8 ff ff       	jmp    ad2a <f0+0x1da>
    d48e:	66 90                	xchg   %ax,%ax
    d490:	66 85 c0             	test   %ax,%ax
    d493:	0f 85 0e eb ff ff    	jne    bfa7 <f0+0x1457>
    d499:	e9 f9 ea ff ff       	jmp    bf97 <f0+0x1447>
    d49e:	66 90                	xchg   %ax,%ax
    d4a0:	66 85 c0             	test   %ax,%ax
    d4a3:	0f 85 5f ea ff ff    	jne    bf08 <f0+0x13b8>
    d4a9:	e9 4a ea ff ff       	jmp    bef8 <f0+0x13a8>
    d4ae:	66 90                	xchg   %ax,%ax
    d4b0:	66 85 c0             	test   %ax,%ax
    d4b3:	0f 85 e2 da ff ff    	jne    af9b <f0+0x44b>
    d4b9:	e9 cd da ff ff       	jmp    af8b <f0+0x43b>
    d4be:	66 90                	xchg   %ax,%ax
    d4c0:	66 85 c0             	test   %ax,%ax
    d4c3:	0f 85 33 da ff ff    	jne    aefc <f0+0x3ac>
    d4c9:	e9 1e da ff ff       	jmp    aeec <f0+0x39c>
    d4ce:	66 90                	xchg   %ax,%ax
    d4d0:	66 85 c0             	test   %ax,%ax
    d4d3:	0f 85 c6 ef ff ff    	jne    c49f <f0+0x194f>
    d4d9:	e9 b1 ef ff ff       	jmp    c48f <f0+0x193f>
    d4de:	66 90                	xchg   %ax,%ax
    d4e0:	66 85 c0             	test   %ax,%ax
    d4e3:	0f 85 17 ef ff ff    	jne    c400 <f0+0x18b0>
    d4e9:	e9 02 ef ff ff       	jmp    c3f0 <f0+0x18a0>
    d4ee:	66 90                	xchg   %ax,%ax
    d4f0:	66 85 c0             	test   %ax,%ax
    d4f3:	0f 85 68 ee ff ff    	jne    c361 <f0+0x1811>
    d4f9:	e9 53 ee ff ff       	jmp    c351 <f0+0x1801>
    d4fe:	66 90                	xchg   %ax,%ax
    d500:	66 85 c0             	test   %ax,%ax
    d503:	0f 85 b9 ed ff ff    	jne    c2c2 <f0+0x1772>
    d509:	e9 a4 ed ff ff       	jmp    c2b2 <f0+0x1762>
    d50e:	66 90                	xchg   %ax,%ax
    d510:	66 85 c0             	test   %ax,%ax
    d513:	0f 85 0a ed ff ff    	jne    c223 <f0+0x16d3>
    d519:	e9 f5 ec ff ff       	jmp    c213 <f0+0x16c3>
    d51e:	66 90                	xchg   %ax,%ax
    d520:	66 85 c0             	test   %ax,%ax
    d523:	0f 85 5b ec ff ff    	jne    c184 <f0+0x1634>
    d529:	e9 46 ec ff ff       	jmp    c174 <f0+0x1624>
    d52e:	66 90                	xchg   %ax,%ax
    d530:	66 85 c0             	test   %ax,%ax
    d533:	0f 85 ac eb ff ff    	jne    c0e5 <f0+0x1595>
    d539:	e9 97 eb ff ff       	jmp    c0d5 <f0+0x1585>
    d53e:	66 90                	xchg   %ax,%ax
    d540:	66 85 c0             	test   %ax,%ax
    d543:	0f 85 fd ea ff ff    	jne    c046 <f0+0x14f6>
    d549:	e9 e8 ea ff ff       	jmp    c036 <f0+0x14e6>
    d54e:	66 90                	xchg   %ax,%ax
    d550:	66 85 c0             	test   %ax,%ax
    d553:	0f 85 29 fe ff ff    	jne    d382 <f0+0x2832>
    d559:	e9 14 fe ff ff       	jmp    d372 <f0+0x2822>
    d55e:	66 90                	xchg   %ax,%ax
    d560:	66 85 c0             	test   %ax,%ax
    d563:	0f 85 7f fd ff ff    	jne    d2e8 <f0+0x2798>
    d569:	e9 6a fd ff ff       	jmp    d2d8 <f0+0x2788>
    d56e:	66 90                	xchg   %ax,%ax
    d570:	66 85 c0             	test   %ax,%ax
    d573:	0f 85 d0 fc ff ff    	jne    d249 <f0+0x26f9>
    d579:	e9 bb fc ff ff       	jmp    d239 <f0+0x26e9>
    d57e:	66 90                	xchg   %ax,%ax
    d580:	66 85 c0             	test   %ax,%ax
    d583:	0f 85 21 fc ff ff    	jne    d1aa <f0+0x265a>
    d589:	e9 0c fc ff ff       	jmp    d19a <f0+0x264a>
    d58e:	66 90                	xchg   %ax,%ax
    d590:	66 85 c0             	test   %ax,%ax
    d593:	0f 85 72 fb ff ff    	jne    d10b <f0+0x25bb>
    d599:	e9 5d fb ff ff       	jmp    d0fb <f0+0x25ab>
    d59e:	66 90                	xchg   %ax,%ax
    d5a0:	66 85 c0             	test   %ax,%ax
    d5a3:	0f 85 c3 fa ff ff    	jne    d06c <f0+0x251c>
    d5a9:	e9 ae fa ff ff       	jmp    d05c <f0+0x250c>
    d5ae:	66 90                	xchg   %ax,%ax
    d5b0:	66 85 c0             	test   %ax,%ax
    d5b3:	0f 85 14 fa ff ff    	jne    cfcd <f0+0x247d>
    d5b9:	e9 ff f9 ff ff       	jmp    cfbd <f0+0x246d>
    d5be:	66 90                	xchg   %ax,%ax
    d5c0:	66 85 c0             	test   %ax,%ax
    d5c3:	0f 85 65 f9 ff ff    	jne    cf2e <f0+0x23de>
    d5c9:	e9 50 f9 ff ff       	jmp    cf1e <f0+0x23ce>
    d5ce:	66 90                	xchg   %ax,%ax
    d5d0:	66 85 c0             	test   %ax,%ax
    d5d3:	0f 85 b6 f8 ff ff    	jne    ce8f <f0+0x233f>
    d5d9:	e9 a1 f8 ff ff       	jmp    ce7f <f0+0x232f>
    d5de:	66 90                	xchg   %ax,%ax
    d5e0:	66 85 c0             	test   %ax,%ax
    d5e3:	0f 85 07 f8 ff ff    	jne    cdf0 <f0+0x22a0>
    d5e9:	e9 f2 f7 ff ff       	jmp    cde0 <f0+0x2290>
    d5ee:	66 90                	xchg   %ax,%ax
    d5f0:	66 85 c0             	test   %ax,%ax
    d5f3:	0f 85 58 f7 ff ff    	jne    cd51 <f0+0x2201>
    d5f9:	e9 43 f7 ff ff       	jmp    cd41 <f0+0x21f1>
    d5fe:	66 90                	xchg   %ax,%ax
    d600:	66 85 c0             	test   %ax,%ax
    d603:	0f 85 a9 f6 ff ff    	jne    ccb2 <f0+0x2162>
    d609:	e9 94 f6 ff ff       	jmp    cca2 <f0+0x2152>
    d60e:	66 90                	xchg   %ax,%ax
    d610:	66 85 c0             	test   %ax,%ax
    d613:	0f 85 fa f5 ff ff    	jne    cc13 <f0+0x20c3>
    d619:	e9 e5 f5 ff ff       	jmp    cc03 <f0+0x20b3>
    d61e:	66 90                	xchg   %ax,%ax
    d620:	66 85 c0             	test   %ax,%ax
    d623:	0f 85 4b f5 ff ff    	jne    cb74 <f0+0x2024>
    d629:	e9 36 f5 ff ff       	jmp    cb64 <f0+0x2014>
    d62e:	66 90                	xchg   %ax,%ax
    d630:	66 85 c0             	test   %ax,%ax
    d633:	0f 85 9c f4 ff ff    	jne    cad5 <f0+0x1f85>
    d639:	e9 87 f4 ff ff       	jmp    cac5 <f0+0x1f75>
    d63e:	66 90                	xchg   %ax,%ax
    d640:	66 85 c0             	test   %ax,%ax
    d643:	0f 85 ed f3 ff ff    	jne    ca36 <f0+0x1ee6>
    d649:	e9 d8 f3 ff ff       	jmp    ca26 <f0+0x1ed6>
    d64e:	4c 89 e7             	mov    %r12,%rdi
    d651:	e8 fa 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d656:	e9 22 fd ff ff       	jmp    d37d <f0+0x282d>
    d65b:	4c 89 e7             	mov    %r12,%rdi
    d65e:	e8 ed 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d663:	e9 cd d6 ff ff       	jmp    ad35 <f0+0x1e5>
    d668:	4c 89 e7             	mov    %r12,%rdi
    d66b:	e8 e0 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d670:	e9 56 d7 ff ff       	jmp    adcb <f0+0x27b>
    d675:	4c 89 e7             	mov    %r12,%rdi
    d678:	e8 d3 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d67d:	e9 df d7 ff ff       	jmp    ae61 <f0+0x311>
    d682:	4c 89 e7             	mov    %r12,%rdi
    d685:	e8 c6 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d68a:	e9 68 d8 ff ff       	jmp    aef7 <f0+0x3a7>
    d68f:	4c 89 e7             	mov    %r12,%rdi
    d692:	e8 b9 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d697:	e9 fa d8 ff ff       	jmp    af96 <f0+0x446>
    d69c:	4c 89 e7             	mov    %r12,%rdi
    d69f:	e8 ac 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6a4:	e9 5a e8 ff ff       	jmp    bf03 <f0+0x13b3>
    d6a9:	4c 89 e7             	mov    %r12,%rdi
    d6ac:	e8 9f 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6b1:	e9 ec e8 ff ff       	jmp    bfa2 <f0+0x1452>
    d6b6:	4c 89 e7             	mov    %r12,%rdi
    d6b9:	e8 92 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6be:	e9 7e e9 ff ff       	jmp    c041 <f0+0x14f1>
    d6c3:	4c 89 e7             	mov    %r12,%rdi
    d6c6:	e8 85 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6cb:	e9 10 ea ff ff       	jmp    c0e0 <f0+0x1590>
    d6d0:	4c 89 e7             	mov    %r12,%rdi
    d6d3:	e8 78 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6d8:	e9 a2 ea ff ff       	jmp    c17f <f0+0x162f>
    d6dd:	4c 89 e7             	mov    %r12,%rdi
    d6e0:	e8 6b 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6e5:	e9 34 eb ff ff       	jmp    c21e <f0+0x16ce>
    d6ea:	4c 89 e7             	mov    %r12,%rdi
    d6ed:	e8 5e 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6f2:	e9 c6 eb ff ff       	jmp    c2bd <f0+0x176d>
    d6f7:	4c 89 e7             	mov    %r12,%rdi
    d6fa:	e8 51 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6ff:	e9 58 ec ff ff       	jmp    c35c <f0+0x180c>
    d704:	4c 89 e7             	mov    %r12,%rdi
    d707:	e8 44 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d70c:	e9 ea ec ff ff       	jmp    c3fb <f0+0x18ab>
    d711:	4c 89 e7             	mov    %r12,%rdi
    d714:	e8 37 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d719:	e9 7c ed ff ff       	jmp    c49a <f0+0x194a>
    d71e:	4c 89 e7             	mov    %r12,%rdi
    d721:	e8 2a 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d726:	e9 0e ee ff ff       	jmp    c539 <f0+0x19e9>
    d72b:	4c 89 e7             	mov    %r12,%rdi
    d72e:	e8 1d 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d733:	e9 a0 ee ff ff       	jmp    c5d8 <f0+0x1a88>
    d738:	4c 89 e7             	mov    %r12,%rdi
    d73b:	e8 10 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d740:	e9 32 ef ff ff       	jmp    c677 <f0+0x1b27>
    d745:	4c 89 e7             	mov    %r12,%rdi
    d748:	e8 03 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d74d:	e9 c4 ef ff ff       	jmp    c716 <f0+0x1bc6>
    d752:	4c 89 e7             	mov    %r12,%rdi
    d755:	e8 f6 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d75a:	e9 56 f0 ff ff       	jmp    c7b5 <f0+0x1c65>
    d75f:	4c 89 e7             	mov    %r12,%rdi
    d762:	e8 e9 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d767:	e9 e8 f0 ff ff       	jmp    c854 <f0+0x1d04>
    d76c:	4c 89 e7             	mov    %r12,%rdi
    d76f:	e8 dc 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d774:	e9 7a f1 ff ff       	jmp    c8f3 <f0+0x1da3>
    d779:	4c 89 e7             	mov    %r12,%rdi
    d77c:	e8 cf 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d781:	e9 0c f2 ff ff       	jmp    c992 <f0+0x1e42>
    d786:	4c 89 e7             	mov    %r12,%rdi
    d789:	e8 c2 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d78e:	e9 9e f2 ff ff       	jmp    ca31 <f0+0x1ee1>
    d793:	4c 89 e7             	mov    %r12,%rdi
    d796:	e8 b5 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d79b:	e9 30 f3 ff ff       	jmp    cad0 <f0+0x1f80>
    d7a0:	4c 89 e7             	mov    %r12,%rdi
    d7a3:	e8 a8 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7a8:	e9 c2 f3 ff ff       	jmp    cb6f <f0+0x201f>
    d7ad:	4c 89 e7             	mov    %r12,%rdi
    d7b0:	e8 9b 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7b5:	e9 54 f4 ff ff       	jmp    cc0e <f0+0x20be>
    d7ba:	4c 89 e7             	mov    %r12,%rdi
    d7bd:	e8 8e 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7c2:	e9 e6 f4 ff ff       	jmp    ccad <f0+0x215d>
    d7c7:	4c 89 e7             	mov    %r12,%rdi
    d7ca:	e8 81 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7cf:	e9 78 f5 ff ff       	jmp    cd4c <f0+0x21fc>
    d7d4:	4c 89 e7             	mov    %r12,%rdi
    d7d7:	e8 74 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7dc:	e9 0a f6 ff ff       	jmp    cdeb <f0+0x229b>
    d7e1:	4c 89 e7             	mov    %r12,%rdi
    d7e4:	e8 67 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7e9:	e9 9c f6 ff ff       	jmp    ce8a <f0+0x233a>
    d7ee:	4c 89 e7             	mov    %r12,%rdi
    d7f1:	e8 5a 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7f6:	e9 2e f7 ff ff       	jmp    cf29 <f0+0x23d9>
    d7fb:	4c 89 e7             	mov    %r12,%rdi
    d7fe:	e8 4d 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d803:	e9 c0 f7 ff ff       	jmp    cfc8 <f0+0x2478>
    d808:	4c 89 e7             	mov    %r12,%rdi
    d80b:	e8 40 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d810:	e9 52 f8 ff ff       	jmp    d067 <f0+0x2517>
    d815:	4c 89 e7             	mov    %r12,%rdi
    d818:	e8 33 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d81d:	e9 e4 f8 ff ff       	jmp    d106 <f0+0x25b6>
    d822:	4c 89 e7             	mov    %r12,%rdi
    d825:	e8 26 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d82a:	e9 76 f9 ff ff       	jmp    d1a5 <f0+0x2655>
    d82f:	4c 89 e7             	mov    %r12,%rdi
    d832:	e8 19 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d837:	e9 08 fa ff ff       	jmp    d244 <f0+0x26f4>
    d83c:	4c 89 e7             	mov    %r12,%rdi
    d83f:	e8 0c 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d844:	e9 9a fa ff ff       	jmp    d2e3 <f0+0x2793>
    d849:	e8 12 5c ff ff       	call   3460 <__stack_chk_fail@plt>
    d84e:	66 90                	xchg   %ax,%ax

000000000000d850 <fwp_main_thread>:
    d850:	f3 0f 1e fa          	endbr64
    d854:	41 54                	push   %r12
    d856:	55                   	push   %rbp
    d857:	53                   	push   %rbx
    d858:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    d85f:	8b 35 ff 72 01 00    	mov    0x172ff(%rip),%esi        # 24b64 <fwp_heap+0x13a4>
    d865:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    d86c:	00 00 
    d86e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    d875:	00 
    d876:	31 c0                	xor    %eax,%eax
    d878:	85 f6                	test   %esi,%esi
    d87a:	0f 84 a8 06 00 00    	je     df28 <fwp_main_thread+0x6d8>
    d880:	8b 0d e2 72 01 00    	mov    0x172e2(%rip),%ecx        # 24b68 <fwp_heap+0x13a8>
    d886:	85 c9                	test   %ecx,%ecx
    d888:	0f 85 82 06 00 00    	jne    df10 <fwp_main_thread+0x6c0>
    d88e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    d893:	31 f6                	xor    %esi,%esi
    d895:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    d89a:	48 c7 05 ab 58 01 00 	movq   $0x40000000,0x158ab(%rip)        # 23150 <fwp_main_stack_size>
    d8a1:	00 00 00 40 
    d8a5:	48 89 05 ac 58 01 00 	mov    %rax,0x158ac(%rip)        # 23158 <fwp_main_stack_top>
    d8ac:	48 8d 05 cd 57 00 00 	lea    0x57cd(%rip),%rax        # 13080 <alt.5>
    d8b3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    d8b8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    d8bf:	01 00 
    d8c1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    d8c8:	00 
    d8c9:	e8 f2 5d ff ff       	call   36c0 <sigaltstack@plt>
    d8ce:	85 c0                	test   %eax,%eax
    d8d0:	0f 85 8a 06 00 00    	jne    df60 <fwp_main_thread+0x710>
    d8d6:	31 c0                	xor    %eax,%eax
    d8d8:	b9 12 00 00 00       	mov    $0x12,%ecx
    d8dd:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d8e2:	f3 48 ab             	rep stos %rax,(%rdi)
    d8e5:	48 8d 05 04 64 ff ff 	lea    -0x9bfc(%rip),%rax        # 3cf0 <fwp_segv>
    d8ec:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d8f1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    d8f8:	04 00 00 08 
    d8fc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    d901:	e8 7a 5c ff ff       	call   3580 <sigemptyset@plt>
    d906:	85 c0                	test   %eax,%eax
    d908:	0f 85 52 06 00 00    	jne    df60 <fwp_main_thread+0x710>
    d90e:	31 d2                	xor    %edx,%edx
    d910:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d915:	bf 0b 00 00 00       	mov    $0xb,%edi
    d91a:	e8 e1 5a ff ff       	call   3400 <sigaction@plt>
    d91f:	85 c0                	test   %eax,%eax
    d921:	0f 85 39 06 00 00    	jne    df60 <fwp_main_thread+0x710>
    d927:	31 d2                	xor    %edx,%edx
    d929:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d92e:	bf 07 00 00 00       	mov    $0x7,%edi
    d933:	e8 c8 5a ff ff       	call   3400 <sigaction@plt>
    d938:	85 c0                	test   %eax,%eax
    d93a:	0f 85 20 06 00 00    	jne    df60 <fwp_main_thread+0x710>
    d940:	8b 15 b2 57 01 00    	mov    0x157b2(%rip),%edx        # 230f8 <descent_registered>
    d946:	85 d2                	test   %edx,%edx
    d948:	0f 84 72 05 00 00    	je     dec0 <fwp_main_thread+0x670>
    d94e:	8b 05 1c 57 00 00    	mov    0x571c(%rip),%eax        # 13070 <st.3>
    d954:	85 c0                	test   %eax,%eax
    d956:	0f 84 90 05 00 00    	je     deec <fwp_main_thread+0x69c>
    d95c:	48 8b 2d 3d 5e 01 00 	mov    0x15e3d(%rip),%rbp        # 237a0 <fwp_cur>
    d963:	48 85 ed             	test   %rbp,%rbp
    d966:	0f 84 74 03 00 00    	je     dce0 <fwp_main_thread+0x490>
    d96c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    d971:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    d975:	48 89 eb             	mov    %rbp,%rbx
    d978:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d97d:	0f 84 41 01 00 00    	je     dac4 <fwp_main_thread+0x274>
    d983:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    d988:	0f 84 82 02 00 00    	je     dc10 <fwp_main_thread+0x3c0>
    d98e:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    d992:	0f 84 68 02 00 00    	je     dc00 <fwp_main_thread+0x3b0>
    d998:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    d99c:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    d9a0:	0f 85 ea 02 00 00    	jne    dc90 <fwp_main_thread+0x440>
    d9a6:	48 8b 43 60          	mov    0x60(%rbx),%rax
    d9aa:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    d9b1:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    d9b5:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    d9bc:	00 00 00 00 
    d9c0:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    d9c7:	48 85 d2             	test   %rdx,%rdx
    d9ca:	74 07                	je     d9d3 <fwp_main_thread+0x183>
    d9cc:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    d9d3:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    d9d7:	48 85 c0             	test   %rax,%rax
    d9da:	74 34                	je     da10 <fwp_main_thread+0x1c0>
    d9dc:	48 89 43 68          	mov    %rax,0x68(%rbx)
    d9e0:	48 8b 05 91 5d 01 00 	mov    0x15d91(%rip),%rax        # 23778 <fwp_timers>
    d9e7:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    d9eb:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    d9f2:	00 00 00 00 
    d9f6:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    d9fd:	48 85 c0             	test   %rax,%rax
    da00:	74 07                	je     da09 <fwp_main_thread+0x1b9>
    da02:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    da09:	48 89 1d 68 5d 01 00 	mov    %rbx,0x15d68(%rip)        # 23778 <fwp_timers>
    da10:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    da14:	e8 b7 98 ff ff       	call   72d0 <fwp_block>
    da19:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    da20:	48 85 c9             	test   %rcx,%rcx
    da23:	74 47                	je     da6c <fwp_main_thread+0x21c>
    da25:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    da2c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    da33:	48 85 d2             	test   %rdx,%rdx
    da36:	0f 84 94 02 00 00    	je     dcd0 <fwp_main_thread+0x480>
    da3c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    da43:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    da4a:	48 85 c0             	test   %rax,%rax
    da4d:	74 07                	je     da56 <fwp_main_thread+0x206>
    da4f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    da56:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    da5d:	00 00 00 00 
    da61:	66 0f ef c0          	pxor   %xmm0,%xmm0
    da65:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    da6c:	48 8b 0d 2d 5d 01 00 	mov    0x15d2d(%rip),%rcx        # 237a0 <fwp_cur>
    da73:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    da77:	0f 84 03 02 00 00    	je     dc80 <fwp_main_thread+0x430>
    da7d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    da84:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    da8b:	48 85 d2             	test   %rdx,%rdx
    da8e:	0f 84 fc 03 00 00    	je     de90 <fwp_main_thread+0x640>
    da94:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    da9b:	48 85 c0             	test   %rax,%rax
    da9e:	74 07                	je     daa7 <fwp_main_thread+0x257>
    daa0:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    daa7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    daab:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    daaf:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    dab6:	48 89 cb             	mov    %rcx,%rbx
    dab9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    dabe:	0f 85 bf fe ff ff    	jne    d983 <fwp_main_thread+0x133>
    dac4:	48 83 3d 6c 79 01 00 	cmpq   $0x0,0x1796c(%rip)        # 25438 <fwp_state_len>
    dacb:	00 
    dacc:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    dad0:	0f 84 bc 00 00 00    	je     db92 <fwp_main_thread+0x342>
    dad6:	48 39 1d bb 5c 01 00 	cmp    %rbx,0x15cbb(%rip)        # 23798 <fwp_root>
    dadd:	c7 05 99 55 01 00 00 	movl   $0x0,0x15599(%rip)        # 23080 <fwp_exit_code>
    dae4:	00 00 00 
    dae7:	0f 85 91 04 00 00    	jne    df7e <fwp_main_thread+0x72e>
    daed:	48 85 db             	test   %rbx,%rbx
    daf0:	0f 84 10 02 00 00    	je     dd06 <fwp_main_thread+0x4b6>
    daf6:	48 8b 15 6b 5c 01 00 	mov    0x15c6b(%rip),%rdx        # 23768 <fwp_tasks_active>
    dafd:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    db01:	48 85 d2             	test   %rdx,%rdx
    db04:	0f 84 fc 01 00 00    	je     dd06 <fwp_main_thread+0x4b6>
    db0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    db10:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    db14:	75 08                	jne    db1e <fwp_main_thread+0x2ce>
    db16:	48 89 d7             	mov    %rdx,%rdi
    db19:	e8 e2 67 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    db1e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    db25:	48 85 d2             	test   %rdx,%rdx
    db28:	75 e6                	jne    db10 <fwp_main_thread+0x2c0>
    db2a:	eb 31                	jmp    db5d <fwp_main_thread+0x30d>
    db2c:	0f 1f 40 00          	nopl   0x0(%rax)
    db30:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    db37:	48 89 1d 42 5c 01 00 	mov    %rbx,0x15c42(%rip)        # 23780 <fwp_ready_tail>
    db3e:	e8 8d 97 ff ff       	call   72d0 <fwp_block>
    db43:	e8 78 95 ff ff       	call   70c0 <fwp_free_zombie>
    db48:	48 83 3d 18 5c 01 00 	cmpq   $0x0,0x15c18(%rip)        # 23768 <fwp_tasks_active>
    db4f:	00 
    db50:	0f 84 b0 01 00 00    	je     dd06 <fwp_main_thread+0x4b6>
    db56:	48 8b 1d 3b 5c 01 00 	mov    0x15c3b(%rip),%rbx        # 23798 <fwp_root>
    db5d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    db61:	75 db                	jne    db3e <fwp_main_thread+0x2ee>
    db63:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    db67:	75 d5                	jne    db3e <fwp_main_thread+0x2ee>
    db69:	48 8b 05 10 5c 01 00 	mov    0x15c10(%rip),%rax        # 23780 <fwp_ready_tail>
    db70:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    db74:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    db7b:	00 00 00 00 
    db7f:	48 85 c0             	test   %rax,%rax
    db82:	75 ac                	jne    db30 <fwp_main_thread+0x2e0>
    db84:	48 89 1d fd 5b 01 00 	mov    %rbx,0x15bfd(%rip)        # 23788 <fwp_ready_head>
    db8b:	eb aa                	jmp    db37 <fwp_main_thread+0x2e7>
    db8d:	0f 1f 00             	nopl   (%rax)
    db90:	31 db                	xor    %ebx,%ebx
    db92:	48 83 3d 8e 78 01 00 	cmpq   $0x0,0x1788e(%rip)        # 25428 <fwp_state_owners>
    db99:	00 
    db9a:	0f 85 36 ff ff ff    	jne    dad6 <fwp_main_thread+0x286>
    dba0:	48 8b 3d 99 78 01 00 	mov    0x17899(%rip),%rdi        # 25440 <fwp_state>
    dba7:	e8 e4 7b ff ff       	call   5790 <fwp_mem_free>
    dbac:	48 c7 05 89 78 01 00 	movq   $0x0,0x17889(%rip)        # 25440 <fwp_state>
    dbb3:	00 00 00 00 
    dbb7:	48 c7 05 6e 78 01 00 	movq   $0x0,0x1786e(%rip)        # 25430 <fwp_state_cap>
    dbbe:	00 00 00 00 
    dbc2:	48 85 db             	test   %rbx,%rbx
    dbc5:	0f 84 76 03 00 00    	je     df41 <fwp_main_thread+0x6f1>
    dbcb:	48 39 1d c6 5b 01 00 	cmp    %rbx,0x15bc6(%rip)        # 23798 <fwp_root>
    dbd2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    dbd9:	00 00 00 00 
    dbdd:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    dbe4:	00 00 00 00 
    dbe8:	c7 05 8e 54 01 00 00 	movl   $0x0,0x1548e(%rip)        # 23080 <fwp_exit_code>
    dbef:	00 00 00 
    dbf2:	0f 84 fe fe ff ff    	je     daf6 <fwp_main_thread+0x2a6>
    dbf8:	e9 58 5b ff ff       	jmp    3755 <fwp_main_thread.cold>
    dbfd:	0f 1f 00             	nopl   (%rax)
    dc00:	e8 5b 69 ff ff       	call   4560 <fwp_now_ns>
    dc05:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    dc09:	0f 8d 91 02 00 00    	jge    dea0 <fwp_main_thread+0x650>
    dc0f:	90                   	nop
    dc10:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    dc14:	0f 85 7e fd ff ff    	jne    d998 <fwp_main_thread+0x148>
    dc1a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    dc1e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    dc22:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dc26:	0f 85 7e fd ff ff    	jne    d9aa <fwp_main_thread+0x15a>
    dc2c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    dc30:	48 85 c9             	test   %rcx,%rcx
    dc33:	0f 84 71 fd ff ff    	je     d9aa <fwp_main_thread+0x15a>
    dc39:	48 85 c0             	test   %rax,%rax
    dc3c:	0f 84 2f 03 00 00    	je     df71 <fwp_main_thread+0x721>
    dc42:	48 39 c8             	cmp    %rcx,%rax
    dc45:	48 0f 4f c1          	cmovg  %rcx,%rax
    dc49:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dc50:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    dc54:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dc5b:	00 00 00 00 
    dc5f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    dc66:	48 85 d2             	test   %rdx,%rdx
    dc69:	74 07                	je     dc72 <fwp_main_thread+0x422>
    dc6b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    dc72:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dc76:	e9 61 fd ff ff       	jmp    d9dc <fwp_main_thread+0x18c>
    dc7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    dc80:	48 89 cb             	mov    %rcx,%rbx
    dc83:	e9 f0 fc ff ff       	jmp    d978 <fwp_main_thread+0x128>
    dc88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dc8f:	00 
    dc90:	48 8b 45 40          	mov    0x40(%rbp),%rax
    dc94:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dc9b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dca2:	00 00 00 00 
    dca6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    dcad:	48 85 c0             	test   %rax,%rax
    dcb0:	0f 84 82 02 00 00    	je     df38 <fwp_main_thread+0x6e8>
    dcb6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    dcbd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dcc1:	e9 4a fd ff ff       	jmp    da10 <fwp_main_thread+0x1c0>
    dcc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dccd:	00 00 00 
    dcd0:	48 89 01             	mov    %rax,(%rcx)
    dcd3:	e9 72 fd ff ff       	jmp    da4a <fwp_main_thread+0x1fa>
    dcd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dcdf:	00 
    dce0:	48 83 3d 50 77 01 00 	cmpq   $0x0,0x17750(%rip)        # 25438 <fwp_state_len>
    dce7:	00 
    dce8:	0f 84 a2 fe ff ff    	je     db90 <fwp_main_thread+0x340>
    dcee:	48 83 3d a2 5a 01 00 	cmpq   $0x0,0x15aa2(%rip)        # 23798 <fwp_root>
    dcf5:	00 
    dcf6:	c7 05 80 53 01 00 00 	movl   $0x0,0x15380(%rip)        # 23080 <fwp_exit_code>
    dcfd:	00 00 00 
    dd00:	0f 85 7d 02 00 00    	jne    df83 <fwp_main_thread+0x733>
    dd06:	e8 b5 93 ff ff       	call   70c0 <fwp_free_zombie>
    dd0b:	48 83 3d 75 5a 01 00 	cmpq   $0x0,0x15a75(%rip)        # 23788 <fwp_ready_head>
    dd12:	00 
    dd13:	0f 85 3c 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dd19:	48 83 3d 57 5a 01 00 	cmpq   $0x0,0x15a57(%rip)        # 23778 <fwp_timers>
    dd20:	00 
    dd21:	0f 85 2e 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dd27:	8b 1d 37 54 01 00    	mov    0x15437(%rip),%ebx        # 23164 <fwp_stack_pool_n>
    dd2d:	85 db                	test   %ebx,%ebx
    dd2f:	74 36                	je     dd67 <fwp_main_thread+0x517>
    dd31:	83 eb 01             	sub    $0x1,%ebx
    dd34:	48 8d 05 45 54 01 00 	lea    0x15445(%rip),%rax        # 23180 <fwp_stack_pool>
    dd3b:	48 63 d3             	movslq %ebx,%rdx
    dd3e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    dd42:	eb 07                	jmp    dd4b <fwp_main_thread+0x4fb>
    dd44:	0f 1f 40 00          	nopl   0x0(%rax)
    dd48:	83 eb 01             	sub    $0x1,%ebx
    dd4b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    dd4f:	be 00 00 00 10       	mov    $0x10000000,%esi
    dd54:	89 1d 0a 54 01 00    	mov    %ebx,0x1540a(%rip)        # 23164 <fwp_stack_pool_n>
    dd5a:	48 83 ed 08          	sub    $0x8,%rbp
    dd5e:	e8 7d 58 ff ff       	call   35e0 <munmap@plt>
    dd63:	85 db                	test   %ebx,%ebx
    dd65:	75 e1                	jne    dd48 <fwp_main_thread+0x4f8>
    dd67:	8b 3d af 52 00 00    	mov    0x52af(%rip),%edi        # 1301c <fwp_epfd>
    dd6d:	85 ff                	test   %edi,%edi
    dd6f:	78 05                	js     dd76 <fwp_main_thread+0x526>
    dd71:	e8 5a 57 ff ff       	call   34d0 <close@plt>
    dd76:	4c 8b 25 03 56 01 00 	mov    0x15603(%rip),%r12        # 23380 <fwp_nfdws>
    dd7d:	48 8b 2d 04 56 01 00 	mov    0x15604(%rip),%rbp        # 23388 <fwp_fdws>
    dd84:	31 db                	xor    %ebx,%ebx
    dd86:	c7 05 8c 52 00 00 ff 	movl   $0xffffffff,0x528c(%rip)        # 1301c <fwp_epfd>
    dd8d:	ff ff ff 
    dd90:	4d 85 e4             	test   %r12,%r12
    dd93:	74 38                	je     ddcd <fwp_main_thread+0x57d>
    dd95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    dd9c:	00 00 00 00 
    dda0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    dda5:	48 85 ff             	test   %rdi,%rdi
    dda8:	74 1a                	je     ddc4 <fwp_main_thread+0x574>
    ddaa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    ddae:	0f 85 a1 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    ddb4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    ddb9:	0f 85 96 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    ddbf:	e8 cc 79 ff ff       	call   5790 <fwp_mem_free>
    ddc4:	48 83 c3 01          	add    $0x1,%rbx
    ddc8:	4c 39 e3             	cmp    %r12,%rbx
    ddcb:	75 d3                	jne    dda0 <fwp_main_thread+0x550>
    ddcd:	48 89 ef             	mov    %rbp,%rdi
    ddd0:	e8 bb 79 ff ff       	call   5790 <fwp_mem_free>
    ddd5:	48 8b 15 bc 59 01 00 	mov    0x159bc(%rip),%rdx        # 23798 <fwp_root>
    dddc:	48 c7 05 a1 55 01 00 	movq   $0x0,0x155a1(%rip)        # 23388 <fwp_fdws>
    dde3:	00 00 00 00 
    dde7:	48 c7 05 8e 55 01 00 	movq   $0x0,0x1558e(%rip)        # 23380 <fwp_nfdws>
    ddee:	00 00 00 00 
    ddf2:	48 85 d2             	test   %rdx,%rdx
    ddf5:	74 4e                	je     de45 <fwp_main_thread+0x5f5>
    ddf7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    ddfc:	0f 85 53 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de02:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    de09:	00 
    de0a:	0f 85 45 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de10:	48 83 3d 20 76 01 00 	cmpq   $0x0,0x17620(%rip)        # 25438 <fwp_state_len>
    de17:	00 
    de18:	0f 85 37 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de1e:	48 83 3d 02 76 01 00 	cmpq   $0x0,0x17602(%rip)        # 25428 <fwp_state_owners>
    de25:	00 
    de26:	0f 85 29 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de2c:	b9 79 00 00 00       	mov    $0x79,%ecx
    de31:	31 c0                	xor    %eax,%eax
    de33:	48 8d 3d 66 55 01 00 	lea    0x15566(%rip),%rdi        # 233a0 <fwp_root_context>
    de3a:	f3 48 ab             	rep stos %rax,(%rdi)
    de3d:	48 89 d7             	mov    %rdx,%rdi
    de40:	e8 4b 79 ff ff       	call   5790 <fwp_mem_free>
    de45:	48 8b 3d d4 51 00 00 	mov    0x51d4(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    de4c:	48 c7 05 49 59 01 00 	movq   $0x0,0x15949(%rip)        # 237a0 <fwp_cur>
    de53:	00 00 00 00 
    de57:	48 c7 05 36 59 01 00 	movq   $0x0,0x15936(%rip)        # 23798 <fwp_root>
    de5e:	00 00 00 00 
    de62:	e8 59 57 ff ff       	call   35c0 <fflush@plt>
    de67:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    de6e:	00 
    de6f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    de76:	00 00 
    de78:	0f 85 fb 00 00 00    	jne    df79 <fwp_main_thread+0x729>
    de7e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    de85:	31 c0                	xor    %eax,%eax
    de87:	5b                   	pop    %rbx
    de88:	5d                   	pop    %rbp
    de89:	41 5c                	pop    %r12
    de8b:	c3                   	ret
    de8c:	0f 1f 40 00          	nopl   0x0(%rax)
    de90:	48 89 05 e1 58 01 00 	mov    %rax,0x158e1(%rip)        # 23778 <fwp_timers>
    de97:	e9 ff fb ff ff       	jmp    da9b <fwp_main_thread+0x24b>
    de9c:	0f 1f 40 00          	nopl   0x0(%rax)
    dea0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    dea4:	0f 85 66 fd ff ff    	jne    dc10 <fwp_main_thread+0x3c0>
    deaa:	48 89 ef             	mov    %rbp,%rdi
    dead:	e8 4e 64 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    deb2:	e9 59 fd ff ff       	jmp    dc10 <fwp_main_thread+0x3c0>
    deb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    debe:	00 00 
    dec0:	48 8d 3d 49 5f ff ff 	lea    -0xa0b7(%rip),%rdi        # 3e10 <descent_phase_report>
    dec7:	e8 d4 02 00 00       	call   e1a0 <atexit>
    decc:	85 c0                	test   %eax,%eax
    dece:	0f 85 98 00 00 00    	jne    df6c <fwp_main_thread+0x71c>
    ded4:	c7 05 1a 52 01 00 01 	movl   $0x1,0x1521a(%rip)        # 230f8 <descent_registered>
    dedb:	00 00 00 
    dede:	8b 05 8c 51 00 00    	mov    0x518c(%rip),%eax        # 13070 <st.3>
    dee4:	85 c0                	test   %eax,%eax
    dee6:	0f 85 70 fa ff ff    	jne    d95c <fwp_main_thread+0x10c>
    deec:	e8 5f cc ff ff       	call   ab50 <f0>
    def1:	48 c7 05 6c 51 00 00 	movq   $0x0,0x516c(%rip)        # 13068 <v.2>
    def8:	00 00 00 00 
    defc:	c7 05 6a 51 00 00 01 	movl   $0x1,0x516a(%rip)        # 13070 <st.3>
    df03:	00 00 00 
    df06:	e9 51 fa ff ff       	jmp    d95c <fwp_main_thread+0x10c>
    df0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    df10:	48 8d 3d 49 6d ff ff 	lea    -0x92b7(%rip),%rdi        # 4c60 <fwp_heap_report>
    df17:	e8 84 02 00 00       	call   e1a0 <atexit>
    df1c:	e9 6d f9 ff ff       	jmp    d88e <fwp_main_thread+0x3e>
    df21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    df28:	e8 43 6e ff ff       	call   4d70 <fwp_heap_init>
    df2d:	e9 4e f9 ff ff       	jmp    d880 <fwp_main_thread+0x30>
    df32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    df38:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    df3c:	e9 cf fa ff ff       	jmp    da10 <fwp_main_thread+0x1c0>
    df41:	48 83 3d 4f 58 01 00 	cmpq   $0x0,0x1584f(%rip)        # 23798 <fwp_root>
    df48:	00 
    df49:	c7 05 2d 51 01 00 00 	movl   $0x0,0x1512d(%rip)        # 23080 <fwp_exit_code>
    df50:	00 00 00 
    df53:	0f 84 ad fd ff ff    	je     dd06 <fwp_main_thread+0x4b6>
    df59:	e9 f7 57 ff ff       	jmp    3755 <fwp_main_thread.cold>
    df5e:	66 90                	xchg   %ax,%ax
    df60:	48 8d 3d 81 1a 00 00 	lea    0x1a81(%rip),%rdi        # f9e8 <_IO_stdin_used+0x9e8>
    df67:	e8 84 64 ff ff       	call   43f0 <fwp_trap>
    df6c:	e8 6f 5e ff ff       	call   3de0 <descent_phase_fail>
    df71:	48 89 c8             	mov    %rcx,%rax
    df74:	e9 d0 fc ff ff       	jmp    dc49 <fwp_main_thread+0x3f9>
    df79:	e8 e2 54 ff ff       	call   3460 <__stack_chk_fail@plt>
    df7e:	e9 d2 57 ff ff       	jmp    3755 <fwp_main_thread.cold>
    df83:	e9 cd 57 ff ff       	jmp    3755 <fwp_main_thread.cold>
    df88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    df8f:	00 

000000000000df90 <__divmodti4>:
    df90:	f3 0f 1e fa          	endbr64
    df94:	55                   	push   %rbp
    df95:	49 89 f1             	mov    %rsi,%r9
    df98:	49 89 d2             	mov    %rdx,%r10
    df9b:	48 89 fe             	mov    %rdi,%rsi
    df9e:	49 89 cb             	mov    %rcx,%r11
    dfa1:	48 89 e5             	mov    %rsp,%rbp
    dfa4:	41 57                	push   %r15
    dfa6:	41 56                	push   %r14
    dfa8:	41 55                	push   %r13
    dfaa:	41 54                	push   %r12
    dfac:	53                   	push   %rbx
    dfad:	4c 89 c3             	mov    %r8,%rbx
    dfb0:	45 31 c0             	xor    %r8d,%r8d
    dfb3:	4d 85 c9             	test   %r9,%r9
    dfb6:	79 12                	jns    dfca <__divmodti4+0x3a>
    dfb8:	31 ff                	xor    %edi,%edi
    dfba:	48 f7 de             	neg    %rsi
    dfbd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    dfc4:	4c 19 cf             	sbb    %r9,%rdi
    dfc7:	49 89 f9             	mov    %rdi,%r9
    dfca:	4c 89 d8             	mov    %r11,%rax
    dfcd:	4d 85 db             	test   %r11,%r11
    dfd0:	0f 88 1a 01 00 00    	js     e0f0 <__divmodti4+0x160>
    dfd6:	4c 89 d9             	mov    %r11,%rcx
    dfd9:	49 89 f3             	mov    %rsi,%r11
    dfdc:	75 62                	jne    e040 <__divmodti4+0xb0>
    dfde:	4d 89 c4             	mov    %r8,%r12
    dfe1:	4d 39 d1             	cmp    %r10,%r9
    dfe4:	0f 83 46 01 00 00    	jae    e130 <__divmodti4+0x1a0>
    dfea:	4c 89 d8             	mov    %r11,%rax
    dfed:	4c 89 ca             	mov    %r9,%rdx
    dff0:	49 f7 f2             	div    %r10
    dff3:	49 89 c3             	mov    %rax,%r11
    dff6:	31 c0                	xor    %eax,%eax
    dff8:	48 89 d6             	mov    %rdx,%rsi
    dffb:	31 ff                	xor    %edi,%edi
    dffd:	4c 89 d9             	mov    %r11,%rcx
    e000:	48 89 c2             	mov    %rax,%rdx
    e003:	48 89 c8             	mov    %rcx,%rax
    e006:	4d 85 e4             	test   %r12,%r12
    e009:	74 0a                	je     e015 <__divmodti4+0x85>
    e00b:	48 f7 d8             	neg    %rax
    e00e:	48 83 d2 00          	adc    $0x0,%rdx
    e012:	48 f7 da             	neg    %rdx
    e015:	4d 85 c0             	test   %r8,%r8
    e018:	74 0a                	je     e024 <__divmodti4+0x94>
    e01a:	48 f7 de             	neg    %rsi
    e01d:	48 83 d7 00          	adc    $0x0,%rdi
    e021:	48 f7 df             	neg    %rdi
    e024:	48 89 33             	mov    %rsi,(%rbx)
    e027:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e02b:	5b                   	pop    %rbx
    e02c:	41 5c                	pop    %r12
    e02e:	41 5d                	pop    %r13
    e030:	41 5e                	pop    %r14
    e032:	41 5f                	pop    %r15
    e034:	5d                   	pop    %rbp
    e035:	c3                   	ret
    e036:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e03d:	00 00 00 
    e040:	4d 89 c4             	mov    %r8,%r12
    e043:	49 39 c1             	cmp    %rax,%r9
    e046:	0f 82 ce 00 00 00    	jb     e11a <__divmodti4+0x18a>
    e04c:	31 ff                	xor    %edi,%edi
    e04e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e053:	48 63 c7             	movslq %edi,%rax
    e056:	be 40 00 00 00       	mov    $0x40,%esi
    e05b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e060:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e065:	48 29 c6             	sub    %rax,%rsi
    e068:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e06d:	48 09 c8             	or     %rcx,%rax
    e070:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e075:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e07a:	49 89 c6             	mov    %rax,%r14
    e07d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e081:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e086:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e08b:	49 09 c1             	or     %rax,%r9
    e08e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e092:	4c 89 c8             	mov    %r9,%rax
    e095:	49 f7 f6             	div    %r14
    e098:	48 89 d1             	mov    %rdx,%rcx
    e09b:	49 89 c3             	mov    %rax,%r11
    e09e:	49 89 c1             	mov    %rax,%r9
    e0a1:	49 f7 e2             	mul    %r10
    e0a4:	49 89 c6             	mov    %rax,%r14
    e0a7:	49 89 d2             	mov    %rdx,%r10
    e0aa:	48 39 d1             	cmp    %rdx,%rcx
    e0ad:	72 07                	jb     e0b6 <__divmodti4+0x126>
    e0af:	75 17                	jne    e0c8 <__divmodti4+0x138>
    e0b1:	49 39 c7             	cmp    %rax,%r15
    e0b4:	73 12                	jae    e0c8 <__divmodti4+0x138>
    e0b6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e0ba:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e0be:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e0c2:	49 89 d2             	mov    %rdx,%r10
    e0c5:	49 89 c6             	mov    %rax,%r14
    e0c8:	4c 89 f8             	mov    %r15,%rax
    e0cb:	4c 29 f0             	sub    %r14,%rax
    e0ce:	4c 19 d1             	sbb    %r10,%rcx
    e0d1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e0d6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e0db:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e0e0:	48 09 c6             	or     %rax,%rsi
    e0e3:	48 89 cf             	mov    %rcx,%rdi
    e0e6:	31 c0                	xor    %eax,%eax
    e0e8:	4c 89 c9             	mov    %r9,%rcx
    e0eb:	e9 10 ff ff ff       	jmp    e000 <__divmodti4+0x70>
    e0f0:	4c 89 d0             	mov    %r10,%rax
    e0f3:	4c 89 da             	mov    %r11,%rdx
    e0f6:	4d 89 c4             	mov    %r8,%r12
    e0f9:	49 89 f3             	mov    %rsi,%r11
    e0fc:	48 f7 d8             	neg    %rax
    e0ff:	49 f7 d4             	not    %r12
    e102:	48 83 d2 00          	adc    $0x0,%rdx
    e106:	49 89 c2             	mov    %rax,%r10
    e109:	48 f7 da             	neg    %rdx
    e10c:	48 89 d1             	mov    %rdx,%rcx
    e10f:	0f 84 cc fe ff ff    	je     dfe1 <__divmodti4+0x51>
    e115:	49 39 d1             	cmp    %rdx,%r9
    e118:	73 46                	jae    e160 <__divmodti4+0x1d0>
    e11a:	4c 89 cf             	mov    %r9,%rdi
    e11d:	31 c0                	xor    %eax,%eax
    e11f:	31 c9                	xor    %ecx,%ecx
    e121:	e9 da fe ff ff       	jmp    e000 <__divmodti4+0x70>
    e126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e12d:	00 00 00 
    e130:	4d 85 d2             	test   %r10,%r10
    e133:	75 0d                	jne    e142 <__divmodti4+0x1b2>
    e135:	b8 01 00 00 00       	mov    $0x1,%eax
    e13a:	31 d2                	xor    %edx,%edx
    e13c:	49 f7 f2             	div    %r10
    e13f:	49 89 c2             	mov    %rax,%r10
    e142:	4c 89 c8             	mov    %r9,%rax
    e145:	31 d2                	xor    %edx,%edx
    e147:	49 f7 f2             	div    %r10
    e14a:	49 89 c1             	mov    %rax,%r9
    e14d:	4c 89 d8             	mov    %r11,%rax
    e150:	49 f7 f2             	div    %r10
    e153:	49 89 c3             	mov    %rax,%r11
    e156:	4c 89 c8             	mov    %r9,%rax
    e159:	e9 9a fe ff ff       	jmp    dff8 <__divmodti4+0x68>
    e15e:	66 90                	xchg   %ax,%ax
    e160:	45 31 f6             	xor    %r14d,%r14d
    e163:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e168:	44 89 f7             	mov    %r14d,%edi
    e16b:	45 85 f6             	test   %r14d,%r14d
    e16e:	0f 85 df fe ff ff    	jne    e053 <__divmodti4+0xc3>
    e174:	4c 39 ca             	cmp    %r9,%rdx
    e177:	72 17                	jb     e190 <__divmodti4+0x200>
    e179:	31 c9                	xor    %ecx,%ecx
    e17b:	48 39 c6             	cmp    %rax,%rsi
    e17e:	73 10                	jae    e190 <__divmodti4+0x200>
    e180:	4c 89 cf             	mov    %r9,%rdi
    e183:	31 c0                	xor    %eax,%eax
    e185:	e9 76 fe ff ff       	jmp    e000 <__divmodti4+0x70>
    e18a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e190:	4c 89 de             	mov    %r11,%rsi
    e193:	b9 01 00 00 00       	mov    $0x1,%ecx
    e198:	48 29 c6             	sub    %rax,%rsi
    e19b:	49 19 d1             	sbb    %rdx,%r9
    e19e:	eb e0                	jmp    e180 <__divmodti4+0x1f0>

000000000000e1a0 <atexit>:
    e1a0:	f3 0f 1e fa          	endbr64
    e1a4:	48 8b 15 5d 4e 00 00 	mov    0x4e5d(%rip),%rdx        # 13008 <__dso_handle>
    e1ab:	31 f6                	xor    %esi,%esi
    e1ad:	e9 ae 54 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e1b4 <_fini>:
    e1b4:	f3 0f 1e fa          	endbr64
    e1b8:	48 83 ec 08          	sub    $0x8,%rsp
    e1bc:	48 83 c4 08          	add    $0x8,%rsp
    e1c0:	c3                   	ret
