
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 dc 00 00 	lea    0xdce1(%rip),%rax        # 11460 <fwp_fn_table>
    377f:	48 89 05 b2 1c 02 00 	mov    %rax,0x21cb2(%rip)        # 25438 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ac 1c 02 00 	mov    %rax,0x21cac(%rip)        # 25440 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 3f ab 00 00 	lea    0xab3f(%rip),%rdx        # e3a0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e c1 00 00 	lea    0xc17e(%rip),%rdi        # fa88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 c1 00 00 	lea    0xc138(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc c0 00 00 	lea    0xc0fc(%rip),%rdi        # fa30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 c0 00 00 	lea    0xc0c8(%rip),%rdi        # fa08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee f4 01 00 	add    0x1f4ee(%rip),%rdx        # 23110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc f4 01 00 	add    0x1f4dc(%rip),%rax        # 23110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d c9 17 02 00 	mov    0x217c9(%rip),%rdi        # 25440 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 c1 fa 01 00 	mov    0x1fac1(%rip),%rax        # 237c0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 f9 f3 01 00 	mov    0x1f3f9(%rip),%rax        # 23178 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 e5 f3 01 00 	sub    0x1f3e5(%rip),%rax        # 23170 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f b8 00 00 	lea    0xb87f(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 62 f2 00 00 	mov    0xf262(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d ed f1 00 00 ff 	cmpl   $0xffffffff,0xf1ed(%rip)        # 13020 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d e1 f2 01 00 	mov    0x1f2e1(%rip),%r9        # 23128 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 bc f2 01 00 	mov    0x1f2bc(%rip),%r8        # 23120 <descent_inputs>
    3e64:	48 8b 0d c5 f2 01 00 	mov    0x1f2c5(%rip),%rcx        # 23130 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d e2 f1 00 00 	mov    0xf1e2(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 b8 00 00 	lea    0xb818(%rip),%rdx        # f6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 91 f2 01 00 	lea    0x1f291(%rip),%r12        # 23140 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 7b f1 00 00 	mov    0xf17b(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 40 f1 00 00 	mov    0xf140(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d 19 f1 00 00 	mov    0xf119(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 3b 0c 02 00 	mov    0x20c3b(%rip),%rax        # 24bd0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 34 0c 02 00 	lea    0x20c34(%rip),%r8        # 24bd0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 15 0c 02 00 	mov    0x20c15(%rip),%rbx        # 24bb8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 25 0c 02 00 	mov    0x20c25(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d c1 0b 02 00 	mov    0x20bc1(%rip),%rdi        # 24bc0 <fwp_heap+0x13e0>
    3fff:	48 29 35 0a 0c 02 00 	sub    %rsi,0x20c0a(%rip)        # 24c10 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 9a 0b 02 00 	mov    0x20b9a(%rip),%rax        # 24bb0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 50 0b 02 00 	add    0x20b50(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 5e 0b 02 00 	mov    0x20b5e(%rip),%rsi        # 24bc0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 6c 0b 02 00 	mov    0x20b6c(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 1b 0b 02 00 	mov    %r12,0x20b1b(%rip)        # 24bc0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 09 0b 02 00 	mov    %rbp,0x20b09(%rip)        # 24bb8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ee 0a 02 00 	cmp    %rdi,0x20aee(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d e5 0a 02 00 	mov    %rdi,0x20ae5(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 29 0b 02 00 	sub    %rdi,0x20b29(%rip)        # 24c10 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 d1 0a 02 00 	mov    0x20ad1(%rip),%rax        # 24bc8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ca 0a 02 00 	lea    0x20aca(%rip),%r8        # 24bc8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 7d ee 00 00 	mov    0xee7d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d b5 ed 00 00 	movslq 0xedb5(%rip),%rbp        # 13020 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 9a ee 01 00 	mov    0x1ee9a(%rip),%rsi        # 23138 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 96 ee 01 00 	lea    0x1ee96(%rip),%rcx        # 23140 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 6b ee 01 00 	addq   $0x1,0x1ee6b(%rip)        # 23130 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 50 ed 00 00    	mov    %ebx,0xed50(%rip)        # 13020 <descent_active_phase>
    42d0:	48 89 05 61 ee 01 00 	mov    %rax,0x1ee61(%rip)        # 23138 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d b9 f4 01 00 	cmp    0x1f4b9(%rip),%rdi        # 237c0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 7f f4 01 00 	mov    0x1f47f(%rip),%rax        # 237a0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 5d f4 01 00 	mov    %rdi,0x1f45d(%rip)        # 237a0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 39 f4 01 00 	mov    %rdi,0x1f439(%rip)        # 237a8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 ae 00 00 	lea    0xae18(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 48 ec 00 00 	mov    0xec48(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 30 ec 00 00 	mov    0xec30(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 41 eb 00 00 	mov    0xeb41(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 b1 00 00 	lea    0xb110(%rip),%rdi        # f700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 b5 00 	movdqa 0xb580(%rip),%xmm0        # fb90 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ca 0d 02 00 	add    0x20dca(%rip),%rax        # 25438 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 b0 00 00 	lea    0xb064(%rip),%rdi        # f728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 25 ea 01 00 	cmp    %rax,0x1ea25(%rip)        # 23108 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 20 ea 01 00 	add    0x1ea20(%rip),%rax        # 23110 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d b0 00 00 	lea    0xb04d(%rip),%rdi        # f758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e a5 00 00 	lea    0xa57e(%rip),%rsi        # f20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d a5 fe 01 00 	mov    0x1fea5(%rip),%r9        # 24ba8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 fe fe 01 00 	mov    0x1fefe(%rip),%r8        # 24c08 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 aa 00 00 	lea    0xaa97(%rip),%rdx        # f7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d e6 fe 01 00 	mov    0x1fee6(%rip),%rcx        # 24c00 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d f4 fe 01 	movsd  0x1fef4(%rip),%xmm1        # 24c20 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 e4 fe 01 	movsd  0x1fee4(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 25 e3 00 00 	mov    0xe325(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 ae 00 	movdqa 0xae28(%rip),%xmm0        # fba0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 9f f9 01 00 	lea    0x1f99f(%rip),%rax        # 24720 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 ae 00 	movdqa 0xae51(%rip),%xmm2        # fbe0 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 45 f9 01 00 	movaps %xmm0,0x1f945(%rip)        # 246e0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d ae 00 	movdqa 0xae0d(%rip),%xmm0        # fbb0 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 d3 fd 01 00 01 	movl   $0x1,0x1fdd3(%rip)        # 24b84 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 33 f9 01 00 	movaps %xmm0,0x1f933(%rip)        # 246f0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb ad 00 	movdqa 0xadfb(%rip),%xmm0        # fbc0 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 34 f9 01 00 	movaps %xmm0,0x1f934(%rip)        # 24700 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc ad 00 	movdqa 0xadfc(%rip),%xmm0        # fbd0 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 35 f9 01 00 	movaps %xmm0,0x1f935(%rip)        # 24710 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 b5 e9 01 00 	lea    0x1e9b5(%rip),%r8        # 237e0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 d0 fc 01 00 	mov    %rax,0x1fcd0(%rip)        # 24b98 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ae fc 01 00 	mov    %r12,0x1fcae(%rip)        # 24ba0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 97 fc 01 00 	mov    %rax,0x1fc97(%rip)        # 24b90 <fwp_heap+0x13b0>
    4ef9:	48 89 1d b0 fc 01 00 	mov    %rbx,0x1fcb0(%rip)        # 24bb0 <fwp_heap+0x13d0>
    4f00:	48 89 35 d9 fc 01 00 	mov    %rsi,0x1fcd9(%rip)        # 24be0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 b8 fc 01 00 	mov    %rax,0x1fcb8(%rip)        # 24bd8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 3c fc 01 00    	mov    %eax,0x1fc3c(%rip)        # 24b88 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 2c e8 01 00 	mov    0x1e82c(%rip),%r8        # 237a0 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 5c e7 01 00 	mov    %rbx,0x1e75c(%rip)        # 237a8 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 48 e7 01 00 	mov    %r8,0x1e748(%rip)        # 237a0 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c a0 00 00 	lea    0xa05c(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d bd df 01 00 	lea    0x1dfbd(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 a5 df 01 00 	movaps %xmm0,0x1dfa5(%rip)        # 230c0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 81 df 01 00 	mov    %rax,0x1df81(%rip)        # 230a8 <fwp_tape_cached_bytes>
    5127:	0f 29 05 a2 df 01 00 	movaps %xmm0,0x1dfa2(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 a6 df 01 00 	movaps %xmm0,0x1dfa6(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 a7 df 01 00 	mov    %rdx,0x1dfa7(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 9f 00 00 	lea    0x9fb3(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d d7 e5 01 00 	mov    0x1e5d7(%rip),%rbx        # 23798 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d aa dd 00 00 	mov    0xddaa(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 73 a5 00 00 	lea    0xa573(%rip),%rdi        # f830 <_IO_stdin_used+0x830>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 ad e4 01 00 	mov    0x1e4ad(%rip),%rax        # 237a0 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 87 e4 01 00 	mov    %rdx,0x1e487(%rip)        # 237a0 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d d4 e3 01 00 	mov    0x1e3d4(%rip),%rbx        # 23798 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 91 e3 01 00 	mov    %rbx,0x1e391(%rip)        # 23798 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 91 e3 01 00 	mov    %rdx,0x1e391(%rip)        # 237a8 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 a6 e3 01 00 	lea    0x1e3a6(%rip),%rsi        # 237e0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 25 ff 01 00 	addq   $0x1,0x1ff25(%rip)        # 25428 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 47 a3 00 00 	lea    0xa347(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 58 a3 00 00 	lea    0xa358(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 9b 00 00 	lea    0x9bf7(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 5e e2 01 00 	lea    0x1e25e(%rip),%rcx        # 237e0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 5f fe 01 00 	subq   $0x1,0x1fe5f(%rip)        # 25428 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d b3 a2 00 00 	lea    0xa2b3(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 40 fe 01 00 	cmpq   $0x0,0x1fe40(%rip)        # 25428 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 95 fd 01 00 	sub    %rax,0x1fd95(%rip)        # 25430 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 73 fd 01 00 	add    %r12,0x1fd73(%rip)        # 25430 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 cf f4 01 00 	mov    0x1f4cf(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 cc e0 01 00 	lea    0x1e0cc(%rip),%rax        # 237e0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 23 f4 01 00 	add    0x1f423(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 f0 f3 01 00 	mov    0x1f3f0(%rip),%rsi        # 24b90 <fwp_heap+0x13b0>
    57a0:	48 8b 05 11 f4 01 00 	mov    0x1f411(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 05 f4 01 00 	add    0x1f405(%rip),%r8        # 24bd8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 cd f3 01 	addsd  0x1f3cd(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 82 df 01 00 	lea    0x1df82(%rip),%rax        # 237e0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 8c f3 01 00 	sub    %rdi,0x1f38c(%rip)        # 24c00 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 a4 f3 01 	movsd  %xmm0,0x1f3a4(%rip)        # 24c20 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 5e f3 01 00 	sub    %rdx,0x1f35e(%rip)        # 24c00 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 64 f3 01 	addsd  0x1f364(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 58 f3 01 	movsd  %xmm0,0x1f358(%rip)        # 24c20 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 ef f2 01 00 	mov    0x1f2ef(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d e9 f2 01 00 	add    %rcx,0x1f2e9(%rip)        # 24c10 <fwp_heap+0x1430>
    5927:	4c 3b 0d a2 f2 01 00 	cmp    0x1f2a2(%rip),%r9        # 24bd0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 99 f2 01 00 	mov    %r9,0x1f299(%rip)        # 24bd0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 8a f2 01 00 	cmp    0x1f28a(%rip),%r9        # 24bc8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 7d f2 01 00 	mov    %r9,0x1f27d(%rip)        # 24bc8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 93 f1 01 00 	add    0x1f193(%rip),%rdi        # 24bd8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 70 dd 01 00 	lea    0x1dd70(%rip),%r15        # 237e0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 e0 f0 01 00 	add    0x1f0e0(%rip),%r12        # 24b90 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 39 f1 01 00 	add    0x1f139(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 38 f1 01 00 	cmp    %rax,0x1f138(%rip)        # 24c08 <fwp_heap+0x1428>
    5ad0:	48 89 05 29 f1 01 00 	mov    %rax,0x1f129(%rip)        # 24c00 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 28 f1 01 00 	mov    %rax,0x1f128(%rip)        # 24c08 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 24 f1 01 	addsd  0x1f124(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 1c f1 01 	movsd  %xmm0,0x1f11c(%rip)        # 24c18 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 63 f0 01 00    	mov    0x1f063(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 9f dc 01 00 	lea    0x1dc9f(%rip),%rdi        # 237e0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 58 f0 01 00 	add    0x1f058(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 53 f0 01 00 	cmp    %rax,0x1f053(%rip)        # 24c08 <fwp_heap+0x1428>
    5bb5:	48 89 05 44 f0 01 00 	mov    %rax,0x1f044(%rip)        # 24c00 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 43 f0 01 00 	mov    %rax,0x1f043(%rip)        # 24c08 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 3f f0 01 	addsd  0x1f03f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 37 f0 01 	movsd  %xmm0,0x1f037(%rip)        # 24c18 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ee ee 01 00    	mov    0x1eeee(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 25 db 01 00 	lea    0x1db25(%rip),%rax        # 237e0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 db ee 01 00 	add    0x1eedb(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 da ee 01 00 	cmp    %rax,0x1eeda(%rip)        # 24c08 <fwp_heap+0x1428>
    5d2e:	48 89 05 cb ee 01 00 	mov    %rax,0x1eecb(%rip)        # 24c00 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 ca ee 01 00 	mov    %rax,0x1eeca(%rip)        # 24c08 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 c6 ee 01 	addsd  0x1eec6(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 be ee 01 	movsd  %xmm0,0x1eebe(%rip)        # 24c18 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_apply>:
    5db0:	55                   	push   %rbp
    5db1:	48 89 f9             	mov    %rdi,%rcx
    5db4:	48 89 e5             	mov    %rsp,%rbp
    5db7:	41 57                	push   %r15
    5db9:	41 56                	push   %r14
    5dbb:	41 55                	push   %r13
    5dbd:	41 89 f5             	mov    %esi,%r13d
    5dc0:	41 54                	push   %r12
    5dc2:	53                   	push   %rbx
    5dc3:	48 83 ec 28          	sub    $0x28,%rsp
    5dc7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5dce:	00 00 
    5dd0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5dd4:	49 89 d6             	mov    %rdx,%r14
    5dd7:	44 8b 09             	mov    (%rcx),%r9d
    5dda:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5dde:	49 89 e0             	mov    %rsp,%r8
    5de1:	49 c1 e1 05          	shl    $0x5,%r9
    5de5:	4c 03 0d 4c f6 01 00 	add    0x1f64c(%rip),%r9        # 25438 <fwp_fns>
    5dec:	41 8b 19             	mov    (%r9),%ebx
    5def:	45 85 e4             	test   %r12d,%r12d
    5df2:	75 2c                	jne    5e20 <fwp_apply+0x70>
    5df4:	41 39 dd             	cmp    %ebx,%r13d
    5df7:	72 27                	jb     5e20 <fwp_apply+0x70>
    5df9:	85 db                	test   %ebx,%ebx
    5dfb:	0f 84 a7 01 00 00    	je     5fa8 <fwp_apply+0x1f8>
    5e01:	4c 89 f7             	mov    %r14,%rdi
    5e04:	41 ff 51 08          	call   *0x8(%r9)
    5e08:	48 89 c1             	mov    %rax,%rcx
    5e0b:	41 39 dd             	cmp    %ebx,%r13d
    5e0e:	0f 84 6c 01 00 00    	je     5f80 <fwp_apply+0x1d0>
    5e14:	89 d8                	mov    %ebx,%eax
    5e16:	41 29 dd             	sub    %ebx,%r13d
    5e19:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e1d:	eb b8                	jmp    5dd7 <fwp_apply+0x27>
    5e1f:	90                   	nop
    5e20:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e25:	41 39 df             	cmp    %ebx,%r15d
    5e28:	0f 82 cc 00 00 00    	jb     5efa <fwp_apply+0x14a>
    5e2e:	41 89 df             	mov    %ebx,%r15d
    5e31:	b8 01 00 00 00       	mov    $0x1,%eax
    5e36:	48 89 e2             	mov    %rsp,%rdx
    5e39:	45 29 e7             	sub    %r12d,%r15d
    5e3c:	85 db                	test   %ebx,%ebx
    5e3e:	0f 45 c3             	cmovne %ebx,%eax
    5e41:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5e48:	00 
    5e49:	48 c1 e8 04          	shr    $0x4,%rax
    5e4d:	48 c1 e0 04          	shl    $0x4,%rax
    5e51:	48 89 c6             	mov    %rax,%rsi
    5e54:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5e5b:	48 29 f2             	sub    %rsi,%rdx
    5e5e:	48 39 d4             	cmp    %rdx,%rsp
    5e61:	74 15                	je     5e78 <fwp_apply+0xc8>
    5e63:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5e6a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5e71:	00 00 
    5e73:	48 39 d4             	cmp    %rdx,%rsp
    5e76:	75 eb                	jne    5e63 <fwp_apply+0xb3>
    5e78:	25 ff 0f 00 00       	and    $0xfff,%eax
    5e7d:	48 29 c4             	sub    %rax,%rsp
    5e80:	48 85 c0             	test   %rax,%rax
    5e83:	0f 85 49 01 00 00    	jne    5fd2 <fwp_apply+0x222>
    5e89:	45 89 e2             	mov    %r12d,%r10d
    5e8c:	48 89 e6             	mov    %rsp,%rsi
    5e8f:	48 89 e7             	mov    %rsp,%rdi
    5e92:	31 c0                	xor    %eax,%eax
    5e94:	49 c1 e2 03          	shl    $0x3,%r10
    5e98:	45 85 e4             	test   %r12d,%r12d
    5e9b:	74 15                	je     5eb2 <fwp_apply+0x102>
    5e9d:	0f 1f 00             	nopl   (%rax)
    5ea0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5ea5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5ea9:	48 83 c0 08          	add    $0x8,%rax
    5ead:	4c 39 d0             	cmp    %r10,%rax
    5eb0:	75 ee                	jne    5ea0 <fwp_apply+0xf0>
    5eb2:	45 85 ff             	test   %r15d,%r15d
    5eb5:	0f 84 f4 00 00 00    	je     5faf <fwp_apply+0x1ff>
    5ebb:	44 89 fa             	mov    %r15d,%edx
    5ebe:	4c 89 f0             	mov    %r14,%rax
    5ec1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ec5:	44 89 e2             	mov    %r12d,%edx
    5ec8:	66 90                	xchg   %ax,%ax
    5eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ed1:	00 00 00 00 
    5ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5edc:	00 00 00 00 
    5ee0:	4c 8b 10             	mov    (%rax),%r10
    5ee3:	89 d1                	mov    %edx,%ecx
    5ee5:	48 83 c0 08          	add    $0x8,%rax
    5ee9:	83 c2 01             	add    $0x1,%edx
    5eec:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5ef0:	4c 39 d8             	cmp    %r11,%rax
    5ef3:	75 eb                	jne    5ee0 <fwp_apply+0x130>
    5ef5:	e9 b5 00 00 00       	jmp    5faf <fwp_apply+0x1ff>
    5efa:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5efe:	be 02 00 00 00       	mov    $0x2,%esi
    5f03:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f07:	48 c1 e7 03          	shl    $0x3,%rdi
    5f0b:	e8 80 fd ff ff       	call   5c90 <fwp_heap_alloc>
    5f10:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f14:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f19:	48 89 c3             	mov    %rax,%rbx
    5f1c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f20:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f24:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f28:	45 85 e4             	test   %r12d,%r12d
    5f2b:	74 14                	je     5f41 <fwp_apply+0x191>
    5f2d:	44 89 e2             	mov    %r12d,%edx
    5f30:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f34:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f38:	48 c1 e2 03          	shl    $0x3,%rdx
    5f3c:	e8 cf d6 ff ff       	call   3610 <memmove@plt>
    5f41:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5f45:	45 85 ed             	test   %r13d,%r13d
    5f48:	74 2e                	je     5f78 <fwp_apply+0x1c8>
    5f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f51:	00 00 00 00 
    5f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f5c:	00 00 00 00 
    5f60:	49 8b 16             	mov    (%r14),%rdx
    5f63:	44 89 e0             	mov    %r12d,%eax
    5f66:	49 83 c6 08          	add    $0x8,%r14
    5f6a:	41 83 c4 01          	add    $0x1,%r12d
    5f6e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5f73:	49 39 ce             	cmp    %rcx,%r14
    5f76:	75 e8                	jne    5f60 <fwp_apply+0x1b0>
    5f78:	48 89 d9             	mov    %rbx,%rcx
    5f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f80:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5f84:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f8b:	00 00 
    5f8d:	75 4e                	jne    5fdd <fwp_apply+0x22d>
    5f8f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5f93:	48 89 c8             	mov    %rcx,%rax
    5f96:	5b                   	pop    %rbx
    5f97:	41 5c                	pop    %r12
    5f99:	41 5d                	pop    %r13
    5f9b:	41 5e                	pop    %r14
    5f9d:	41 5f                	pop    %r15
    5f9f:	5d                   	pop    %rbp
    5fa0:	c3                   	ret
    5fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fa8:	45 31 ff             	xor    %r15d,%r15d
    5fab:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5faf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5fb3:	41 ff 51 08          	call   *0x8(%r9)
    5fb7:	48 89 c1             	mov    %rax,%rcx
    5fba:	45 39 fd             	cmp    %r15d,%r13d
    5fbd:	74 c1                	je     5f80 <fwp_apply+0x1d0>
    5fbf:	45 01 e5             	add    %r12d,%r13d
    5fc2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5fc6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5fca:	41 29 dd             	sub    %ebx,%r13d
    5fcd:	e9 05 fe ff ff       	jmp    5dd7 <fwp_apply+0x27>
    5fd2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5fd8:	e9 ac fe ff ff       	jmp    5e89 <fwp_apply+0xd9>
    5fdd:	e8 7e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    5fe2:	0f 1f 00             	nopl   (%rax)
    5fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fec:	00 00 00 00 

0000000000005ff0 <fwp_p_ad_push>:
    5ff0:	41 57                	push   %r15
    5ff2:	41 56                	push   %r14
    5ff4:	41 55                	push   %r13
    5ff6:	49 89 d5             	mov    %rdx,%r13
    5ff9:	41 54                	push   %r12
    5ffb:	49 89 fc             	mov    %rdi,%r12
    5ffe:	55                   	push   %rbp
    5fff:	53                   	push   %rbx
    6000:	48 83 ec 48          	sub    $0x48,%rsp
    6004:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6009:	48 85 ff             	test   %rdi,%rdi
    600c:	79 09                	jns    6017 <fwp_p_ad_push+0x27>
    600e:	48 85 d2             	test   %rdx,%rdx
    6011:	0f 88 b9 02 00 00    	js     62d0 <fwp_p_ad_push+0x2e0>
    6017:	48 89 f8             	mov    %rdi,%rax
    601a:	48 89 0c 24          	mov    %rcx,(%rsp)
    601e:	4c 89 c5             	mov    %r8,%rbp
    6021:	48 09 d0             	or     %rdx,%rax
    6024:	0f 89 7e 02 00 00    	jns    62a8 <fwp_p_ad_push+0x2b8>
    602a:	48 85 ff             	test   %rdi,%rdi
    602d:	0f 89 e6 03 00 00    	jns    6419 <fwp_p_ad_push+0x429>
    6033:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6038:	49 89 d6             	mov    %rdx,%r14
    603b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6042:	00 
    6043:	49 89 d4             	mov    %rdx,%r12
    6046:	49 c1 fe 20          	sar    $0x20,%r14
    604a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6051:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6057:	48 85 ed             	test   %rbp,%rbp
    605a:	0f 84 48 03 00 00    	je     63a8 <fwp_p_ad_push+0x3b8>
    6060:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    6064:	0f 84 be 02 00 00    	je     6328 <fwp_p_ad_push+0x338>
    606a:	4c 89 f7             	mov    %r14,%rdi
    606d:	e8 5e e6 ff ff       	call   46d0 <fwp_tape_of>
    6072:	48 89 c3             	mov    %rax,%rbx
    6075:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    607a:	0f 85 3e 03 00 00    	jne    63be <fwp_p_ad_push+0x3ce>
    6080:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    6084:	48 89 45 08          	mov    %rax,0x8(%rbp)
    6088:	4c 8b 43 10          	mov    0x10(%rbx),%r8
    608c:	49 81 f8 fe ff ff 7f 	cmp    $0x7ffffffe,%r8
    6093:	0f 8f cd 03 00 00    	jg     6466 <fwp_p_ad_push+0x476>
    6099:	44 89 e0             	mov    %r12d,%eax
    609c:	4c 39 c0             	cmp    %r8,%rax
    609f:	0f 8d b5 03 00 00    	jge    645a <fwp_p_ad_push+0x46a>
    60a5:	4d 85 ed             	test   %r13,%r13
    60a8:	78 0c                	js     60b6 <fwp_p_ad_push+0xc6>
    60aa:	44 89 e8             	mov    %r13d,%eax
    60ad:	4c 39 c0             	cmp    %r8,%rax
    60b0:	0f 8d a4 03 00 00    	jge    645a <fwp_p_ad_push+0x46a>
    60b6:	4d 89 c7             	mov    %r8,%r15
    60b9:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    60bd:	49 8d 47 01          	lea    0x1(%r15),%rax
    60c1:	4c 89 f9             	mov    %r15,%rcx
    60c4:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    60ca:	0f 87 96 03 00 00    	ja     6466 <fwp_p_ad_push+0x476>
    60d0:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    60d4:	48 39 e8             	cmp    %rbp,%rax
    60d7:	0f 8e 23 02 00 00    	jle    6300 <fwp_p_ad_push+0x310>
    60dd:	48 85 ed             	test   %rbp,%rbp
    60e0:	ba 40 00 00 00       	mov    $0x40,%edx
    60e5:	48 0f 44 ea          	cmove  %rdx,%rbp
    60e9:	48 39 e8             	cmp    %rbp,%rax
    60ec:	7e 22                	jle    6110 <fwp_p_ad_push+0x120>
    60ee:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    60f5:	0f 8f f5 01 00 00    	jg     62f0 <fwp_p_ad_push+0x300>
    60fb:	48 01 ed             	add    %rbp,%rbp
    60fe:	48 39 e8             	cmp    %rbp,%rax
    6101:	7f eb                	jg     60ee <fwp_p_ad_push+0xfe>
    6103:	66 90                	xchg   %ax,%ax
    6105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    610c:	00 00 00 00 
    6110:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6117:	00 
    6118:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    611c:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6121:	48 89 c6             	mov    %rax,%rsi
    6124:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6129:	4c 8b 73 60          	mov    0x60(%rbx),%r14
    612d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6132:	e8 99 d4 ff ff       	call   35d0 <realloc@plt>
    6137:	48 85 c0             	test   %rax,%rax
    613a:	0f 84 32 03 00 00    	je     6472 <fwp_p_ad_push+0x482>
    6140:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6144:	4d 85 f6             	test   %r14,%r14
    6147:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    614c:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6150:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6155:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    6159:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    615d:	0f 84 d5 01 00 00    	je     6338 <fwp_p_ad_push+0x348>
    6163:	49 8b 56 60          	mov    0x60(%r14),%rdx
    6167:	48 39 ea             	cmp    %rbp,%rdx
    616a:	0f 8d bb 00 00 00    	jge    622b <fwp_p_ad_push+0x23b>
    6170:	49 8b 76 40          	mov    0x40(%r14),%rsi
    6174:	48 89 ef             	mov    %rbp,%rdi
    6177:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    617c:	48 c1 e7 04          	shl    $0x4,%rdi
    6180:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    6185:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    618a:	be 02 00 00 00       	mov    $0x2,%esi
    618f:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    6194:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    6199:	e8 f2 fa ff ff       	call   5c90 <fwp_heap_alloc>
    619e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    61a3:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    61a8:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    61ad:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    61b2:	48 85 f6             	test   %rsi,%rsi
    61b5:	74 31                	je     61e8 <fwp_p_ad_push+0x1f8>
    61b7:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    61bc:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    61c1:	48 c1 e2 04          	shl    $0x4,%rdx
    61c5:	48 39 fa             	cmp    %rdi,%rdx
    61c8:	48 0f 47 d7          	cmova  %rdi,%rdx
    61cc:	48 89 c7             	mov    %rax,%rdi
    61cf:	e8 cc d3 ff ff       	call   35a0 <memcpy@plt>
    61d4:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    61d9:	e8 b2 f5 ff ff       	call   5790 <fwp_mem_free>
    61de:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    61e3:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    61e8:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    61ec:	48 89 ea             	mov    %rbp,%rdx
    61ef:	31 f6                	xor    %esi,%esi
    61f1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    61f6:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    61fb:	48 29 fa             	sub    %rdi,%rdx
    61fe:	48 c1 e7 04          	shl    $0x4,%rdi
    6202:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    6207:	48 c1 e2 04          	shl    $0x4,%rdx
    620b:	e8 b0 d2 ff ff       	call   34c0 <memset@plt>
    6210:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6215:	49 89 6e 60          	mov    %rbp,0x60(%r14)
    6219:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    621e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6223:	49 89 46 40          	mov    %rax,0x40(%r14)
    6227:	48 8b 43 20          	mov    0x20(%rbx),%rax
    622b:	4d 85 ff             	test   %r15,%r15
    622e:	0f 85 9c 01 00 00    	jne    63d0 <fwp_p_ad_push+0x3e0>
    6234:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6238:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    623c:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6243:	00 
    6244:	49 01 c6             	add    %rax,%r14
    6247:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    624b:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    624f:	46 89 24 38          	mov    %r12d,(%rax,%r15,1)
    6253:	4d 85 ed             	test   %r13,%r13
    6256:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    625c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6263:	4c 0f 48 e8          	cmovs  %rax,%r13
    6267:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    626c:	49 8d 40 01          	lea    0x1(%r8),%rax
    6270:	f2 0f 11 0c 0a       	movsd  %xmm1,(%rdx,%rcx,1)
    6275:	47 89 2c 3e          	mov    %r13d,(%r14,%r15,1)
    6279:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    627e:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6282:	48 83 c4 48          	add    $0x48,%rsp
    6286:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    628d:	ff ff ff 
    6290:	4c 21 e0             	and    %r12,%rax
    6293:	5b                   	pop    %rbx
    6294:	5d                   	pop    %rbp
    6295:	4c 09 c0             	or     %r8,%rax
    6298:	41 5c                	pop    %r12
    629a:	41 5d                	pop    %r13
    629c:	41 5e                	pop    %r14
    629e:	41 5f                	pop    %r15
    62a0:	c3                   	ret
    62a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    62a8:	48 c1 fa 20          	sar    $0x20,%rdx
    62ac:	48 c1 ff 20          	sar    $0x20,%rdi
    62b0:	49 89 d6             	mov    %rdx,%r14
    62b3:	48 39 d7             	cmp    %rdx,%rdi
    62b6:	0f 84 9b fd ff ff    	je     6057 <fwp_p_ad_push+0x67>
    62bc:	48 8d 3d ed 95 00 00 	lea    0x95ed(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    62c3:	e8 28 e1 ff ff       	call   43f0 <fwp_trap>
    62c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    62cf:	00 
    62d0:	48 83 c4 48          	add    $0x48,%rsp
    62d4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    62db:	5b                   	pop    %rbx
    62dc:	5d                   	pop    %rbp
    62dd:	41 5c                	pop    %r12
    62df:	41 5d                	pop    %r13
    62e1:	41 5e                	pop    %r14
    62e3:	41 5f                	pop    %r15
    62e5:	c3                   	ret
    62e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ed:	00 00 00 
    62f0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    62f5:	e9 16 fe ff ff       	jmp    6110 <fwp_p_ad_push+0x120>
    62fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6300:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6304:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6308:	48 c1 e1 03          	shl    $0x3,%rcx
    630c:	4e 8d 3c bd 00 00 00 	lea    0x0(,%r15,4),%r15
    6313:	00 
    6314:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6318:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    631c:	e9 2e ff ff ff       	jmp    624f <fwp_p_ad_push+0x25f>
    6321:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6328:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    632c:	e9 57 fd ff ff       	jmp    6088 <fwp_p_ad_push+0x98>
    6331:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6338:	49 89 ee             	mov    %rbp,%r14
    633b:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    633f:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6344:	49 c1 e6 04          	shl    $0x4,%r14
    6348:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    634d:	4c 89 f6             	mov    %r14,%rsi
    6350:	e8 7b d2 ff ff       	call   35d0 <realloc@plt>
    6355:	48 89 c2             	mov    %rax,%rdx
    6358:	48 85 c0             	test   %rax,%rax
    635b:	0f 84 11 01 00 00    	je     6472 <fwp_p_ad_push+0x482>
    6361:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6365:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6369:	4d 85 ff             	test   %r15,%r15
    636c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6371:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6376:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    637a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    637f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6383:	48 8d 3c 02          	lea    (%rdx,%rax,1),%rdi
    6387:	0f 85 98 00 00 00    	jne    6425 <fwp_p_ad_push+0x435>
    638d:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6391:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6395:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    639c:	00 
    639d:	45 31 ff             	xor    %r15d,%r15d
    63a0:	e9 9f fe ff ff       	jmp    6244 <fwp_p_ad_push+0x254>
    63a5:	0f 1f 00             	nopl   (%rax)
    63a8:	4c 89 f7             	mov    %r14,%rdi
    63ab:	e8 20 e3 ff ff       	call   46d0 <fwp_tape_of>
    63b0:	48 89 c3             	mov    %rax,%rbx
    63b3:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63b8:	0f 84 ca fc ff ff    	je     6088 <fwp_p_ad_push+0x98>
    63be:	48 8d 3d 33 95 00 00 	lea    0x9533(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    63c5:	e8 26 e0 ff ff       	call   43f0 <fwp_trap>
    63ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    63d0:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
    63d7:	00 
    63d8:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    63dd:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    63e1:	49 c1 e7 02          	shl    $0x2,%r15
    63e5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    63ea:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    63f1:	00 
    63f2:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    63f6:	4c 89 fa             	mov    %r15,%rdx
    63f9:	e8 12 d2 ff ff       	call   3610 <memmove@plt>
    63fe:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6402:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6406:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    640a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    640f:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6414:	e9 2b fe ff ff       	jmp    6244 <fwp_p_ad_push+0x254>
    6419:	48 c1 ff 20          	sar    $0x20,%rdi
    641d:	49 89 fe             	mov    %rdi,%r14
    6420:	e9 32 fc ff ff       	jmp    6057 <fwp_p_ad_push+0x67>
    6425:	4c 39 f0             	cmp    %r14,%rax
    6428:	4c 89 f1             	mov    %r14,%rcx
    642b:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
    6432:	00 
    6433:	49 89 c6             	mov    %rax,%r14
    6436:	48 0f 43 c8          	cmovae %rax,%rcx
    643a:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    643f:	48 29 c1             	sub    %rax,%rcx
    6442:	e8 19 d1 ff ff       	call   3560 <__memmove_chk@plt>
    6447:	4c 03 73 30          	add    0x30(%rbx),%r14
    644b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    644f:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6453:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6458:	eb 83                	jmp    63dd <fwp_p_ad_push+0x3ed>
    645a:	48 8d 3d 06 8d 00 00 	lea    0x8d06(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    6461:	e8 8a df ff ff       	call   43f0 <fwp_trap>
    6466:	48 8d 3d df 8c 00 00 	lea    0x8cdf(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    646d:	e8 7e df ff ff       	call   43f0 <fwp_trap>
    6472:	48 89 df             	mov    %rbx,%rdi
    6475:	e8 86 d7 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    647a:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    647e:	e8 3d cf ff ff       	call   33c0 <free@plt>
    6483:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6487:	e8 34 cf ff ff       	call   33c0 <free@plt>
    648c:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6490:	e8 2b cf ff ff       	call   33c0 <free@plt>
    6495:	31 c9                	xor    %ecx,%ecx
    6497:	31 c0                	xor    %eax,%eax
    6499:	31 d2                	xor    %edx,%edx
    649b:	89 53 04             	mov    %edx,0x4(%rbx)
    649e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    64a2:	ba 13 00 00 00       	mov    $0x13,%edx
    64a7:	be 01 00 00 00       	mov    $0x1,%esi
    64ac:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    64b0:	48 8d 3d 51 8b 00 00 	lea    0x8b51(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    64b7:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    64bb:	48 8b 0d 9e cb 00 00 	mov    0xcb9e(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    64c2:	48 89 43 40          	mov    %rax,0x40(%rbx)
    64c6:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    64ca:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    64ce:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    64d2:	e8 a9 d1 ff ff       	call   3680 <fwrite@plt>
    64d7:	31 ff                	xor    %edi,%edi
    64d9:	e8 e2 d0 ff ff       	call   35c0 <fflush@plt>
    64de:	bf 66 00 00 00       	mov    $0x66,%edi
    64e3:	e8 b8 d1 ff ff       	call   36a0 <_Exit@plt>
    64e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    64ef:	00 

00000000000064f0 <w107>:
    64f0:	41 56                	push   %r14
    64f2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    64f6:	48 89 fa             	mov    %rdi,%rdx
    64f9:	41 55                	push   %r13
    64fb:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    64ff:	49 89 fd             	mov    %rdi,%r13
    6502:	41 54                	push   %r12
    6504:	55                   	push   %rbp
    6505:	53                   	push   %rbx
    6506:	48 83 ec 40          	sub    $0x40,%rsp
    650a:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6510:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6515:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    651c:	00 00 
    651e:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    6523:	48 89 f5             	mov    %rsi,%rbp
    6526:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    652b:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6531:	48 89 f1             	mov    %rsi,%rcx
    6534:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    653a:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    6541:	ff ff 
    6543:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    654a:	00 00 
    654c:	e8 9f fa ff ff       	call   5ff0 <fwp_p_ad_push>
    6551:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6557:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    655c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6562:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6569:	00 f0 3f 
    656c:	48 89 c7             	mov    %rax,%rdi
    656f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6576:	00 f0 bf 
    6579:	48 89 ea             	mov    %rbp,%rdx
    657c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6581:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6587:	e8 64 fa ff ff       	call   5ff0 <fwp_p_ad_push>
    658c:	f2 0f 10 05 8c 96 00 	movsd  0x968c(%rip),%xmm0        # fc20 <msg.4+0xb0>
    6593:	00 
    6594:	4c 89 ef             	mov    %r13,%rdi
    6597:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    659d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    65a2:	49 89 c6             	mov    %rax,%r14
    65a5:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    65ac:	00 f0 3f 
    65af:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    65b6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    65bd:	00 f0 bf 
    65c0:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    65c5:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    65cb:	e8 20 fa ff ff       	call   5ff0 <fwp_p_ad_push>
    65d0:	4c 89 e1             	mov    %r12,%rcx
    65d3:	4c 89 e6             	mov    %r12,%rsi
    65d6:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    65db:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    65e1:	4c 89 f2             	mov    %r14,%rdx
    65e4:	4c 89 f7             	mov    %r14,%rdi
    65e7:	49 89 c5             	mov    %rax,%r13
    65ea:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    65ee:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    65f4:	e8 f7 f9 ff ff       	call   5ff0 <fwp_p_ad_push>
    65f9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    65ff:	f2 0f 59 1d 21 96 00 	mulsd  0x9621(%rip),%xmm3        # fc28 <msg.4+0xb8>
    6606:	00 
    6607:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    660c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6611:	48 89 c2             	mov    %rax,%rdx
    6614:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    661b:	00 59 40 
    661e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6625:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    662b:	e8 c0 f9 ff ff       	call   5ff0 <fwp_p_ad_push>
    6630:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6635:	48 89 e9             	mov    %rbp,%rcx
    6638:	4c 89 ea             	mov    %r13,%rdx
    663b:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6641:	48 89 ee             	mov    %rbp,%rsi
    6644:	4c 89 ef             	mov    %r13,%rdi
    6647:	49 89 c4             	mov    %rax,%r12
    664a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    664e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6654:	e8 97 f9 ff ff       	call   5ff0 <fwp_p_ad_push>
    6659:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    665f:	45 31 c0             	xor    %r8d,%r8d
    6662:	4c 89 e2             	mov    %r12,%rdx
    6665:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    666b:	48 89 c7             	mov    %rax,%rdi
    666e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6675:	00 f0 3f 
    6678:	48 89 ce             	mov    %rcx,%rsi
    667b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6680:	e8 6b f9 ff ff       	call   5ff0 <fwp_p_ad_push>
    6685:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    668a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6691:	00 00 
    6693:	75 12                	jne    66a7 <w107+0x1b7>
    6695:	48 83 c4 40          	add    $0x40,%rsp
    6699:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    669e:	5b                   	pop    %rbx
    669f:	5d                   	pop    %rbp
    66a0:	41 5c                	pop    %r12
    66a2:	41 5d                	pop    %r13
    66a4:	41 5e                	pop    %r14
    66a6:	c3                   	ret
    66a7:	e8 b4 cd ff ff       	call   3460 <__stack_chk_fail@plt>
    66ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000066b0 <w164.constprop.0>:
    66b0:	41 54                	push   %r12
    66b2:	55                   	push   %rbp
    66b3:	53                   	push   %rbx
    66b4:	48 83 ec 10          	sub    $0x10,%rsp
    66b8:	4c 8b 27             	mov    (%rdi),%r12
    66bb:	4d 85 e4             	test   %r12,%r12
    66be:	74 58                	je     6718 <w164.constprop.0+0x68>
    66c0:	48 89 fd             	mov    %rdi,%rbp
    66c3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    66c7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    66ce:	31 db                	xor    %ebx,%ebx
    66d0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    66d6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    66db:	45 31 c0             	xor    %r8d,%r8d
    66de:	48 83 c3 02          	add    $0x2,%rbx
    66e2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66e9:	00 f0 3f 
    66ec:	48 89 ce             	mov    %rcx,%rsi
    66ef:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    66f5:	e8 f6 f8 ff ff       	call   5ff0 <fwp_p_ad_push>
    66fa:	4c 39 e3             	cmp    %r12,%rbx
    66fd:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6703:	48 89 c7             	mov    %rax,%rdi
    6706:	72 c8                	jb     66d0 <w164.constprop.0+0x20>
    6708:	48 83 c4 10          	add    $0x10,%rsp
    670c:	48 89 f8             	mov    %rdi,%rax
    670f:	5b                   	pop    %rbx
    6710:	5d                   	pop    %rbp
    6711:	41 5c                	pop    %r12
    6713:	c3                   	ret
    6714:	0f 1f 40 00          	nopl   0x0(%rax)
    6718:	48 83 c4 10          	add    $0x10,%rsp
    671c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6723:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6727:	5b                   	pop    %rbx
    6728:	48 89 f8             	mov    %rdi,%rax
    672b:	5d                   	pop    %rbp
    672c:	41 5c                	pop    %r12
    672e:	c3                   	ret
    672f:	90                   	nop

0000000000006730 <fwp_data.part.0.constprop.0>:
    6730:	41 56                	push   %r14
    6732:	41 89 fe             	mov    %edi,%r14d
    6735:	41 54                	push   %r12
    6737:	49 89 f4             	mov    %rsi,%r12
    673a:	55                   	push   %rbp
    673b:	53                   	push   %rbx
    673c:	48 83 ec 08          	sub    $0x8,%rsp
    6740:	8b 05 3e e4 01 00    	mov    0x1e43e(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    6746:	85 c0                	test   %eax,%eax
    6748:	0f 84 fa 00 00 00    	je     6848 <fwp_data.part.0.constprop.0+0x118>
    674e:	0f b6 05 2d e0 01 00 	movzbl 0x1e02d(%rip),%eax        # 24782 <fwp_heap+0xfa2>
    6755:	48 8d 15 84 d0 01 00 	lea    0x1d084(%rip),%rdx        # 237e0 <fwp_heap>
    675c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6763:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6767:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    676b:	48 8b 18             	mov    (%rax),%rbx
    676e:	48 85 db             	test   %rbx,%rbx
    6771:	0f 84 a9 00 00 00    	je     6820 <fwp_data.part.0.constprop.0+0xf0>
    6777:	48 8b 13             	mov    (%rbx),%rdx
    677a:	48 f7 d2             	not    %rdx
    677d:	48 89 10             	mov    %rdx,(%rax)
    6780:	48 83 fd 18          	cmp    $0x18,%rbp
    6784:	76 1b                	jbe    67a1 <fwp_data.part.0.constprop.0+0x71>
    6786:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    678a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    678e:	31 f6                	xor    %esi,%esi
    6790:	48 c1 e8 03          	shr    $0x3,%rax
    6794:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    679b:	00 
    679c:	e8 1f cd ff ff       	call   34c0 <memset@plt>
    67a1:	48 89 e8             	mov    %rbp,%rax
    67a4:	48 03 05 55 e4 01 00 	add    0x1e455(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    67ab:	0f 82 a8 00 00 00    	jb     6859 <fwp_data.part.0.constprop.0+0x129>
    67b1:	48 39 05 50 e4 01 00 	cmp    %rax,0x1e450(%rip)        # 24c08 <fwp_heap+0x1428>
    67b8:	48 89 05 41 e4 01 00 	mov    %rax,0x1e441(%rip)        # 24c00 <fwp_heap+0x1420>
    67bf:	73 07                	jae    67c8 <fwp_data.part.0.constprop.0+0x98>
    67c1:	48 89 05 40 e4 01 00 	mov    %rax,0x1e440(%rip)        # 24c08 <fwp_heap+0x1428>
    67c8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67cc:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    67d1:	f2 0f 58 05 3f e4 01 	addsd  0x1e43f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    67d8:	00 
    67d9:	f2 0f 11 05 37 e4 01 	movsd  %xmm0,0x1e437(%rip)        # 24c18 <fwp_heap+0x1438>
    67e0:	00 
    67e1:	b8 02 00 00 00       	mov    $0x2,%eax
    67e6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    67eb:	66 0f 6e c8          	movd   %eax,%xmm1
    67ef:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    67f3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    67f7:	49 8b 04 24          	mov    (%r12),%rax
    67fb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    67ff:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6804:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6808:	48 83 c4 08          	add    $0x8,%rsp
    680c:	48 89 d8             	mov    %rbx,%rax
    680f:	5b                   	pop    %rbx
    6810:	5d                   	pop    %rbp
    6811:	41 5c                	pop    %r12
    6813:	41 5e                	pop    %r14
    6815:	c3                   	ret
    6816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    681d:	00 00 00 
    6820:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6824:	48 85 db             	test   %rbx,%rbx
    6827:	74 1f                	je     6848 <fwp_data.part.0.constprop.0+0x118>
    6829:	48 8b 50 10          	mov    0x10(%rax),%rdx
    682d:	48 29 da             	sub    %rbx,%rdx
    6830:	48 39 ea             	cmp    %rbp,%rdx
    6833:	72 13                	jb     6848 <fwp_data.part.0.constprop.0+0x118>
    6835:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6839:	48 89 50 08          	mov    %rdx,0x8(%rax)
    683d:	e9 3e ff ff ff       	jmp    6780 <fwp_data.part.0.constprop.0+0x50>
    6842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6848:	31 f6                	xor    %esi,%esi
    684a:	bf 18 00 00 00       	mov    $0x18,%edi
    684f:	e8 3c f4 ff ff       	call   5c90 <fwp_heap_alloc>
    6854:	48 89 c3             	mov    %rax,%rbx
    6857:	eb 88                	jmp    67e1 <fwp_data.part.0.constprop.0+0xb1>
    6859:	e8 52 d4 ff ff       	call   3cb0 <fwp_heap_oom>
    685e:	66 90                	xchg   %ax,%ax

0000000000006860 <fwp_rc_share>:
    6860:	48 8b 05 51 e3 01 00 	mov    0x1e351(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    6867:	48 2b 3d 22 e3 01 00 	sub    0x1e322(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    686e:	48 c1 e0 10          	shl    $0x10,%rax
    6872:	48 39 c7             	cmp    %rax,%rdi
    6875:	73 4a                	jae    68c1 <fwp_rc_share+0x61>
    6877:	48 89 f8             	mov    %rdi,%rax
    687a:	48 c1 e8 10          	shr    $0x10,%rax
    687e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6882:	48 8b 05 4f e3 01 00 	mov    0x1e34f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    6889:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    688d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6891:	48 85 d2             	test   %rdx,%rdx
    6894:	74 2b                	je     68c1 <fwp_rc_share+0x61>
    6896:	0f b6 08             	movzbl (%rax),%ecx
    6899:	80 f9 02             	cmp    $0x2,%cl
    689c:	74 2a                	je     68c8 <fwp_rc_share+0x68>
    689e:	80 f9 01             	cmp    $0x1,%cl
    68a1:	75 1e                	jne    68c1 <fwp_rc_share+0x61>
    68a3:	8b 48 18             	mov    0x18(%rax),%ecx
    68a6:	0f b7 ff             	movzwl %di,%edi
    68a9:	8b 40 1c             	mov    0x1c(%rax),%eax
    68ac:	48 0f af f9          	imul   %rcx,%rdi
    68b0:	48 c1 ef 20          	shr    $0x20,%rdi
    68b4:	48 39 c7             	cmp    %rax,%rdi
    68b7:	73 08                	jae    68c1 <fwp_rc_share+0x61>
    68b9:	48 01 fa             	add    %rdi,%rdx
    68bc:	80 3a 00             	cmpb   $0x0,(%rdx)
    68bf:	75 0d                	jne    68ce <fwp_rc_share+0x6e>
    68c1:	c3                   	ret
    68c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68c8:	66 85 ff             	test   %di,%di
    68cb:	74 ef                	je     68bc <fwp_rc_share+0x5c>
    68cd:	c3                   	ret
    68ce:	50                   	push   %rax
    68cf:	48 8d 3d 52 90 00 00 	lea    0x9052(%rip),%rdi        # f928 <_IO_stdin_used+0x928>
    68d6:	e8 15 db ff ff       	call   43f0 <fwp_trap>
    68db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000068e0 <fwp_rc_fresh>:
    68e0:	48 8b 15 d1 e2 01 00 	mov    0x1e2d1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    68e7:	48 89 f8             	mov    %rdi,%rax
    68ea:	48 89 fe             	mov    %rdi,%rsi
    68ed:	48 2b 05 9c e2 01 00 	sub    0x1e29c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    68f4:	48 c1 e2 10          	shl    $0x10,%rdx
    68f8:	48 39 d0             	cmp    %rdx,%rax
    68fb:	73 4f                	jae    694c <fwp_rc_fresh+0x6c>
    68fd:	48 89 c2             	mov    %rax,%rdx
    6900:	48 c1 ea 10          	shr    $0x10,%rdx
    6904:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6908:	48 8b 15 c9 e2 01 00 	mov    0x1e2c9(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    690f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6913:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6917:	48 85 d2             	test   %rdx,%rdx
    691a:	74 30                	je     694c <fwp_rc_fresh+0x6c>
    691c:	0f b6 39             	movzbl (%rcx),%edi
    691f:	40 80 ff 02          	cmp    $0x2,%dil
    6923:	74 2b                	je     6950 <fwp_rc_fresh+0x70>
    6925:	40 80 ff 01          	cmp    $0x1,%dil
    6929:	75 21                	jne    694c <fwp_rc_fresh+0x6c>
    692b:	8b 79 18             	mov    0x18(%rcx),%edi
    692e:	0f b7 c0             	movzwl %ax,%eax
    6931:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6934:	48 0f af c7          	imul   %rdi,%rax
    6938:	48 c1 e8 20          	shr    $0x20,%rax
    693c:	48 39 c8             	cmp    %rcx,%rax
    693f:	73 0b                	jae    694c <fwp_rc_fresh+0x6c>
    6941:	48 01 c2             	add    %rax,%rdx
    6944:	80 3a ff             	cmpb   $0xff,(%rdx)
    6947:	74 17                	je     6960 <fwp_rc_fresh+0x80>
    6949:	c6 02 01             	movb   $0x1,(%rdx)
    694c:	48 89 f0             	mov    %rsi,%rax
    694f:	c3                   	ret
    6950:	66 85 c0             	test   %ax,%ax
    6953:	74 ef                	je     6944 <fwp_rc_fresh+0x64>
    6955:	48 89 f0             	mov    %rsi,%rax
    6958:	c3                   	ret
    6959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6960:	48 83 ec 18          	sub    $0x18,%rsp
    6964:	48 89 d7             	mov    %rdx,%rdi
    6967:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    696c:	48 89 14 24          	mov    %rdx,(%rsp)
    6970:	e8 db eb ff ff       	call   5550 <fwp_rc_forget_slot>
    6975:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    697a:	48 8b 14 24          	mov    (%rsp),%rdx
    697e:	48 89 f0             	mov    %rsi,%rax
    6981:	c6 02 01             	movb   $0x1,(%rdx)
    6984:	48 83 c4 18          	add    $0x18,%rsp
    6988:	c3                   	ret
    6989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006990 <fwp_rc_free_arr>:
    6990:	48 8b 15 21 e2 01 00 	mov    0x1e221(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6997:	48 89 f8             	mov    %rdi,%rax
    699a:	48 2b 05 ef e1 01 00 	sub    0x1e1ef(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    69a1:	48 c1 e2 10          	shl    $0x10,%rdx
    69a5:	48 39 d0             	cmp    %rdx,%rax
    69a8:	73 5b                	jae    6a05 <fwp_rc_free_arr+0x75>
    69aa:	48 89 c2             	mov    %rax,%rdx
    69ad:	48 c1 ea 10          	shr    $0x10,%rdx
    69b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69b5:	48 8b 15 1c e2 01 00 	mov    0x1e21c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    69bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    69c0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    69c4:	48 85 c9             	test   %rcx,%rcx
    69c7:	74 3c                	je     6a05 <fwp_rc_free_arr+0x75>
    69c9:	0f b6 32             	movzbl (%rdx),%esi
    69cc:	40 80 fe 02          	cmp    $0x2,%sil
    69d0:	74 2e                	je     6a00 <fwp_rc_free_arr+0x70>
    69d2:	40 80 fe 01          	cmp    $0x1,%sil
    69d6:	75 2d                	jne    6a05 <fwp_rc_free_arr+0x75>
    69d8:	8b 72 18             	mov    0x18(%rdx),%esi
    69db:	0f b7 c0             	movzwl %ax,%eax
    69de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69e1:	48 0f af c6          	imul   %rsi,%rax
    69e5:	48 c1 e8 20          	shr    $0x20,%rax
    69e9:	48 39 d0             	cmp    %rdx,%rax
    69ec:	73 17                	jae    6a05 <fwp_rc_free_arr+0x75>
    69ee:	48 01 c1             	add    %rax,%rcx
    69f1:	80 39 01             	cmpb   $0x1,(%rcx)
    69f4:	75 0f                	jne    6a05 <fwp_rc_free_arr+0x75>
    69f6:	e9 95 ed ff ff       	jmp    5790 <fwp_mem_free>
    69fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a00:	66 85 c0             	test   %ax,%ax
    6a03:	74 ec                	je     69f1 <fwp_rc_free_arr+0x61>
    6a05:	c3                   	ret
    6a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a0d:	00 00 00 

0000000000006a10 <fwp_rc_dup>:
    6a10:	f3 0f 1e fa          	endbr64
    6a14:	48 8b 05 9d e1 01 00 	mov    0x1e19d(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    6a1b:	48 2b 3d 6e e1 01 00 	sub    0x1e16e(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    6a22:	48 c1 e0 10          	shl    $0x10,%rax
    6a26:	48 39 c7             	cmp    %rax,%rdi
    6a29:	73 56                	jae    6a81 <fwp_rc_dup+0x71>
    6a2b:	48 89 f8             	mov    %rdi,%rax
    6a2e:	48 c1 e8 10          	shr    $0x10,%rax
    6a32:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a36:	48 8b 05 9b e1 01 00 	mov    0x1e19b(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    6a3d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6a41:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6a45:	48 85 c0             	test   %rax,%rax
    6a48:	74 37                	je     6a81 <fwp_rc_dup+0x71>
    6a4a:	0f b6 0a             	movzbl (%rdx),%ecx
    6a4d:	80 f9 02             	cmp    $0x2,%cl
    6a50:	74 36                	je     6a88 <fwp_rc_dup+0x78>
    6a52:	80 f9 01             	cmp    $0x1,%cl
    6a55:	75 2a                	jne    6a81 <fwp_rc_dup+0x71>
    6a57:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6a5a:	0f b7 ff             	movzwl %di,%edi
    6a5d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a60:	48 0f af f9          	imul   %rcx,%rdi
    6a64:	48 c1 ef 20          	shr    $0x20,%rdi
    6a68:	48 39 d7             	cmp    %rdx,%rdi
    6a6b:	73 14                	jae    6a81 <fwp_rc_dup+0x71>
    6a6d:	48 01 f8             	add    %rdi,%rax
    6a70:	0f b6 10             	movzbl (%rax),%edx
    6a73:	84 d2                	test   %dl,%dl
    6a75:	74 0a                	je     6a81 <fwp_rc_dup+0x71>
    6a77:	80 fa fd             	cmp    $0xfd,%dl
    6a7a:	77 14                	ja     6a90 <fwp_rc_dup+0x80>
    6a7c:	83 c2 01             	add    $0x1,%edx
    6a7f:	88 10                	mov    %dl,(%rax)
    6a81:	c3                   	ret
    6a82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a88:	66 85 ff             	test   %di,%di
    6a8b:	74 e3                	je     6a70 <fwp_rc_dup+0x60>
    6a8d:	c3                   	ret
    6a8e:	66 90                	xchg   %ax,%ax
    6a90:	48 89 c7             	mov    %rax,%rdi
    6a93:	e9 98 e9 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6a98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a9f:	00 

0000000000006aa0 <fwp_owned_entry161>:
    6aa0:	f3 0f 1e fa          	endbr64
    6aa4:	48 83 ec 38          	sub    $0x38,%rsp
    6aa8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6aad:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ab4:	00 00 
    6ab6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6abb:	31 c0                	xor    %eax,%eax
    6abd:	48 8b 07             	mov    (%rdi),%rax
    6ac0:	48 03 47 10          	add    0x10(%rdi),%rax
    6ac4:	0f 80 c2 00 00 00    	jo     6b8c <fwp_owned_entry161+0xec>
    6aca:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6acf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6ad4:	31 ff                	xor    %edi,%edi
    6ad6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6ada:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6adf:	e8 4c fc ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    6ae4:	48 8b 15 cd e0 01 00 	mov    0x1e0cd(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6aeb:	48 89 c6             	mov    %rax,%rsi
    6aee:	48 2b 05 9b e0 01 00 	sub    0x1e09b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6af5:	48 c1 e2 10          	shl    $0x10,%rdx
    6af9:	48 39 d0             	cmp    %rdx,%rax
    6afc:	73 4f                	jae    6b4d <fwp_owned_entry161+0xad>
    6afe:	48 89 c2             	mov    %rax,%rdx
    6b01:	48 c1 ea 10          	shr    $0x10,%rdx
    6b05:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b09:	48 8b 15 c8 e0 01 00 	mov    0x1e0c8(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6b10:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b14:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b18:	48 85 d2             	test   %rdx,%rdx
    6b1b:	74 30                	je     6b4d <fwp_owned_entry161+0xad>
    6b1d:	0f b6 39             	movzbl (%rcx),%edi
    6b20:	40 80 ff 02          	cmp    $0x2,%dil
    6b24:	74 42                	je     6b68 <fwp_owned_entry161+0xc8>
    6b26:	40 80 ff 01          	cmp    $0x1,%dil
    6b2a:	75 21                	jne    6b4d <fwp_owned_entry161+0xad>
    6b2c:	8b 79 18             	mov    0x18(%rcx),%edi
    6b2f:	0f b7 c0             	movzwl %ax,%eax
    6b32:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b35:	48 0f af c7          	imul   %rdi,%rax
    6b39:	48 c1 e8 20          	shr    $0x20,%rax
    6b3d:	48 39 c8             	cmp    %rcx,%rax
    6b40:	73 0b                	jae    6b4d <fwp_owned_entry161+0xad>
    6b42:	48 01 c2             	add    %rax,%rdx
    6b45:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b48:	74 26                	je     6b70 <fwp_owned_entry161+0xd0>
    6b4a:	c6 02 01             	movb   $0x1,(%rdx)
    6b4d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b52:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b59:	00 00 
    6b5b:	75 34                	jne    6b91 <fwp_owned_entry161+0xf1>
    6b5d:	48 89 f0             	mov    %rsi,%rax
    6b60:	48 83 c4 38          	add    $0x38,%rsp
    6b64:	c3                   	ret
    6b65:	0f 1f 00             	nopl   (%rax)
    6b68:	66 85 c0             	test   %ax,%ax
    6b6b:	75 e0                	jne    6b4d <fwp_owned_entry161+0xad>
    6b6d:	eb d6                	jmp    6b45 <fwp_owned_entry161+0xa5>
    6b6f:	90                   	nop
    6b70:	48 89 d7             	mov    %rdx,%rdi
    6b73:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b78:	48 89 14 24          	mov    %rdx,(%rsp)
    6b7c:	e8 cf e9 ff ff       	call   5550 <fwp_rc_forget_slot>
    6b81:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6b86:	48 8b 14 24          	mov    (%rsp),%rdx
    6b8a:	eb be                	jmp    6b4a <fwp_owned_entry161+0xaa>
    6b8c:	e8 6f cb ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6b91:	e8 ca c8 ff ff       	call   3460 <__stack_chk_fail@plt>
    6b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b9d:	00 00 00 

0000000000006ba0 <e161>:
    6ba0:	f3 0f 1e fa          	endbr64
    6ba4:	53                   	push   %rbx
    6ba5:	48 83 ec 30          	sub    $0x30,%rsp
    6ba9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6bae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bb5:	00 00 
    6bb7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6bbc:	31 c0                	xor    %eax,%eax
    6bbe:	48 8b 07             	mov    (%rdi),%rax
    6bc1:	48 03 47 10          	add    0x10(%rdi),%rax
    6bc5:	0f 80 c9 00 00 00    	jo     6c94 <e161+0xf4>
    6bcb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6bd0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6bd5:	31 ff                	xor    %edi,%edi
    6bd7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6bdb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6be0:	e8 4b fb ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    6be5:	48 8b 15 cc df 01 00 	mov    0x1dfcc(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6bec:	48 89 c3             	mov    %rax,%rbx
    6bef:	48 2b 05 9a df 01 00 	sub    0x1df9a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6bf6:	48 c1 e2 10          	shl    $0x10,%rdx
    6bfa:	48 39 d0             	cmp    %rdx,%rax
    6bfd:	73 4f                	jae    6c4e <e161+0xae>
    6bff:	48 89 c2             	mov    %rax,%rdx
    6c02:	48 c1 ea 10          	shr    $0x10,%rdx
    6c06:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c0a:	48 8b 15 c7 df 01 00 	mov    0x1dfc7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6c11:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c15:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c19:	48 85 d2             	test   %rdx,%rdx
    6c1c:	74 30                	je     6c4e <e161+0xae>
    6c1e:	0f b6 31             	movzbl (%rcx),%esi
    6c21:	40 80 fe 02          	cmp    $0x2,%sil
    6c25:	74 49                	je     6c70 <e161+0xd0>
    6c27:	40 80 fe 01          	cmp    $0x1,%sil
    6c2b:	75 21                	jne    6c4e <e161+0xae>
    6c2d:	8b 71 18             	mov    0x18(%rcx),%esi
    6c30:	0f b7 c0             	movzwl %ax,%eax
    6c33:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c36:	48 0f af c6          	imul   %rsi,%rax
    6c3a:	48 c1 e8 20          	shr    $0x20,%rax
    6c3e:	48 39 c8             	cmp    %rcx,%rax
    6c41:	73 0b                	jae    6c4e <e161+0xae>
    6c43:	48 01 c2             	add    %rax,%rdx
    6c46:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c49:	74 35                	je     6c80 <e161+0xe0>
    6c4b:	c6 02 01             	movb   $0x1,(%rdx)
    6c4e:	48 89 df             	mov    %rbx,%rdi
    6c51:	e8 0a fc ff ff       	call   6860 <fwp_rc_share>
    6c56:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c5b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c62:	00 00 
    6c64:	75 33                	jne    6c99 <e161+0xf9>
    6c66:	48 83 c4 30          	add    $0x30,%rsp
    6c6a:	48 89 d8             	mov    %rbx,%rax
    6c6d:	5b                   	pop    %rbx
    6c6e:	c3                   	ret
    6c6f:	90                   	nop
    6c70:	66 85 c0             	test   %ax,%ax
    6c73:	75 d9                	jne    6c4e <e161+0xae>
    6c75:	eb cf                	jmp    6c46 <e161+0xa6>
    6c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c7e:	00 00 
    6c80:	48 89 d7             	mov    %rdx,%rdi
    6c83:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c88:	e8 c3 e8 ff ff       	call   5550 <fwp_rc_forget_slot>
    6c8d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c92:	eb b7                	jmp    6c4b <e161+0xab>
    6c94:	e8 67 ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6c99:	e8 c2 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6c9e:	66 90                	xchg   %ax,%ax

0000000000006ca0 <fwp_drop0>:
    6ca0:	f3 0f 1e fa          	endbr64
    6ca4:	48 8b 15 0d df 01 00 	mov    0x1df0d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6cab:	48 89 f8             	mov    %rdi,%rax
    6cae:	48 2b 05 db de 01 00 	sub    0x1dedb(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6cb5:	48 c1 e2 10          	shl    $0x10,%rdx
    6cb9:	48 39 d0             	cmp    %rdx,%rax
    6cbc:	0f 83 be 00 00 00    	jae    6d80 <fwp_drop0+0xe0>
    6cc2:	48 83 ec 18          	sub    $0x18,%rsp
    6cc6:	4c 8d 05 13 cb 01 00 	lea    0x1cb13(%rip),%r8        # 237e0 <fwp_heap>
    6ccd:	48 89 c2             	mov    %rax,%rdx
    6cd0:	48 c1 ea 10          	shr    $0x10,%rdx
    6cd4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cd8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6cdf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ce3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ce7:	48 85 d2             	test   %rdx,%rdx
    6cea:	74 3c                	je     6d28 <fwp_drop0+0x88>
    6cec:	0f b6 31             	movzbl (%rcx),%esi
    6cef:	40 80 fe 02          	cmp    $0x2,%sil
    6cf3:	74 3b                	je     6d30 <fwp_drop0+0x90>
    6cf5:	40 80 fe 01          	cmp    $0x1,%sil
    6cf9:	75 2d                	jne    6d28 <fwp_drop0+0x88>
    6cfb:	8b 71 18             	mov    0x18(%rcx),%esi
    6cfe:	0f b7 c0             	movzwl %ax,%eax
    6d01:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d04:	48 0f af c6          	imul   %rsi,%rax
    6d08:	48 c1 e8 20          	shr    $0x20,%rax
    6d0c:	48 39 c8             	cmp    %rcx,%rax
    6d0f:	73 17                	jae    6d28 <fwp_drop0+0x88>
    6d11:	48 01 c2             	add    %rax,%rdx
    6d14:	0f b6 02             	movzbl (%rdx),%eax
    6d17:	84 c0                	test   %al,%al
    6d19:	74 0d                	je     6d28 <fwp_drop0+0x88>
    6d1b:	3c 01                	cmp    $0x1,%al
    6d1d:	74 21                	je     6d40 <fwp_drop0+0xa0>
    6d1f:	3c ff                	cmp    $0xff,%al
    6d21:	74 65                	je     6d88 <fwp_drop0+0xe8>
    6d23:	83 e8 01             	sub    $0x1,%eax
    6d26:	88 02                	mov    %al,(%rdx)
    6d28:	48 83 c4 18          	add    $0x18,%rsp
    6d2c:	c3                   	ret
    6d2d:	0f 1f 00             	nopl   (%rax)
    6d30:	66 85 c0             	test   %ax,%ax
    6d33:	74 df                	je     6d14 <fwp_drop0+0x74>
    6d35:	48 83 c4 18          	add    $0x18,%rsp
    6d39:	c3                   	ret
    6d3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d40:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6d44:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6d49:	e8 42 fc ff ff       	call   6990 <fwp_rc_free_arr>
    6d4e:	4c 8d 05 8b ca 01 00 	lea    0x1ca8b(%rip),%r8        # 237e0 <fwp_heap>
    6d55:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6d5a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6d61:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6d68:	48 c1 e2 10          	shl    $0x10,%rdx
    6d6c:	48 39 d0             	cmp    %rdx,%rax
    6d6f:	73 b7                	jae    6d28 <fwp_drop0+0x88>
    6d71:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6d76:	e9 52 ff ff ff       	jmp    6ccd <fwp_drop0+0x2d>
    6d7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d80:	c3                   	ret
    6d81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d88:	48 89 d0             	mov    %rdx,%rax
    6d8b:	48 c1 e8 11          	shr    $0x11,%rax
    6d8f:	48 31 d0             	xor    %rdx,%rax
    6d92:	48 89 c1             	mov    %rax,%rcx
    6d95:	48 c1 e9 09          	shr    $0x9,%rcx
    6d99:	48 31 c8             	xor    %rcx,%rax
    6d9c:	0f b6 c8             	movzbl %al,%ecx
    6d9f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6da6:	00 
    6da7:	48 85 c0             	test   %rax,%rax
    6daa:	75 1d                	jne    6dc9 <fwp_drop0+0x129>
    6dac:	eb 56                	jmp    6e04 <fwp_drop0+0x164>
    6dae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dbc:	00 00 00 00 
    6dc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6dc4:	48 85 c0             	test   %rax,%rax
    6dc7:	74 3b                	je     6e04 <fwp_drop0+0x164>
    6dc9:	48 89 c1             	mov    %rax,%rcx
    6dcc:	48 39 10             	cmp    %rdx,(%rax)
    6dcf:	75 ef                	jne    6dc0 <fwp_drop0+0x120>
    6dd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6dd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6dd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6ddd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6de4:	0f 85 3e ff ff ff    	jne    6d28 <fwp_drop0+0x88>
    6dea:	48 89 d7             	mov    %rdx,%rdi
    6ded:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6df2:	e8 59 e7 ff ff       	call   5550 <fwp_rc_forget_slot>
    6df7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6dfc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6dff:	e9 24 ff ff ff       	jmp    6d28 <fwp_drop0+0x88>
    6e04:	48 8d 3d 7d 8a 00 00 	lea    0x8a7d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6e0b:	e8 e0 d5 ff ff       	call   43f0 <fwp_trap>

0000000000006e10 <fwp_arg_drop12>:
    6e10:	f3 0f 1e fa          	endbr64
    6e14:	85 f6                	test   %esi,%esi
    6e16:	75 04                	jne    6e1c <fwp_arg_drop12+0xc>
    6e18:	85 d2                	test   %edx,%edx
    6e1a:	75 04                	jne    6e20 <fwp_arg_drop12+0x10>
    6e1c:	c3                   	ret
    6e1d:	0f 1f 00             	nopl   (%rax)
    6e20:	48 8b 3f             	mov    (%rdi),%rdi
    6e23:	e9 78 fe ff ff       	jmp    6ca0 <fwp_drop0>
    6e28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e2f:	00 

0000000000006e30 <fwp_drop1>:
    6e30:	f3 0f 1e fa          	endbr64
    6e34:	48 8b 15 7d dd 01 00 	mov    0x1dd7d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6e3b:	48 89 f8             	mov    %rdi,%rax
    6e3e:	48 2b 05 4b dd 01 00 	sub    0x1dd4b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6e45:	48 c1 e2 10          	shl    $0x10,%rdx
    6e49:	48 39 d0             	cmp    %rdx,%rax
    6e4c:	0f 83 be 00 00 00    	jae    6f10 <fwp_drop1+0xe0>
    6e52:	48 83 ec 18          	sub    $0x18,%rsp
    6e56:	4c 8d 05 83 c9 01 00 	lea    0x1c983(%rip),%r8        # 237e0 <fwp_heap>
    6e5d:	48 89 c2             	mov    %rax,%rdx
    6e60:	48 c1 ea 10          	shr    $0x10,%rdx
    6e64:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e68:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6e6f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e73:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e77:	48 85 d2             	test   %rdx,%rdx
    6e7a:	74 3c                	je     6eb8 <fwp_drop1+0x88>
    6e7c:	0f b6 31             	movzbl (%rcx),%esi
    6e7f:	40 80 fe 02          	cmp    $0x2,%sil
    6e83:	74 3b                	je     6ec0 <fwp_drop1+0x90>
    6e85:	40 80 fe 01          	cmp    $0x1,%sil
    6e89:	75 2d                	jne    6eb8 <fwp_drop1+0x88>
    6e8b:	8b 71 18             	mov    0x18(%rcx),%esi
    6e8e:	0f b7 c0             	movzwl %ax,%eax
    6e91:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e94:	48 0f af c6          	imul   %rsi,%rax
    6e98:	48 c1 e8 20          	shr    $0x20,%rax
    6e9c:	48 39 c8             	cmp    %rcx,%rax
    6e9f:	73 17                	jae    6eb8 <fwp_drop1+0x88>
    6ea1:	48 01 c2             	add    %rax,%rdx
    6ea4:	0f b6 02             	movzbl (%rdx),%eax
    6ea7:	84 c0                	test   %al,%al
    6ea9:	74 0d                	je     6eb8 <fwp_drop1+0x88>
    6eab:	3c 01                	cmp    $0x1,%al
    6ead:	74 21                	je     6ed0 <fwp_drop1+0xa0>
    6eaf:	3c ff                	cmp    $0xff,%al
    6eb1:	74 65                	je     6f18 <fwp_drop1+0xe8>
    6eb3:	83 e8 01             	sub    $0x1,%eax
    6eb6:	88 02                	mov    %al,(%rdx)
    6eb8:	48 83 c4 18          	add    $0x18,%rsp
    6ebc:	c3                   	ret
    6ebd:	0f 1f 00             	nopl   (%rax)
    6ec0:	66 85 c0             	test   %ax,%ax
    6ec3:	74 df                	je     6ea4 <fwp_drop1+0x74>
    6ec5:	48 83 c4 18          	add    $0x18,%rsp
    6ec9:	c3                   	ret
    6eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ed0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6ed4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6ed9:	e8 b2 fa ff ff       	call   6990 <fwp_rc_free_arr>
    6ede:	4c 8d 05 fb c8 01 00 	lea    0x1c8fb(%rip),%r8        # 237e0 <fwp_heap>
    6ee5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6eea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6ef1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ef8:	48 c1 e2 10          	shl    $0x10,%rdx
    6efc:	48 39 d0             	cmp    %rdx,%rax
    6eff:	73 b7                	jae    6eb8 <fwp_drop1+0x88>
    6f01:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6f06:	e9 52 ff ff ff       	jmp    6e5d <fwp_drop1+0x2d>
    6f0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f10:	c3                   	ret
    6f11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f18:	48 89 d0             	mov    %rdx,%rax
    6f1b:	48 c1 e8 11          	shr    $0x11,%rax
    6f1f:	48 31 d0             	xor    %rdx,%rax
    6f22:	48 89 c1             	mov    %rax,%rcx
    6f25:	48 c1 e9 09          	shr    $0x9,%rcx
    6f29:	48 31 c8             	xor    %rcx,%rax
    6f2c:	0f b6 c8             	movzbl %al,%ecx
    6f2f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6f36:	00 
    6f37:	48 85 c0             	test   %rax,%rax
    6f3a:	75 0d                	jne    6f49 <fwp_drop1+0x119>
    6f3c:	eb 46                	jmp    6f84 <fwp_drop1+0x154>
    6f3e:	66 90                	xchg   %ax,%ax
    6f40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6f44:	48 85 c0             	test   %rax,%rax
    6f47:	74 3b                	je     6f84 <fwp_drop1+0x154>
    6f49:	48 89 c1             	mov    %rax,%rcx
    6f4c:	48 39 10             	cmp    %rdx,(%rax)
    6f4f:	75 ef                	jne    6f40 <fwp_drop1+0x110>
    6f51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6f59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6f5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6f64:	0f 85 4e ff ff ff    	jne    6eb8 <fwp_drop1+0x88>
    6f6a:	48 89 d7             	mov    %rdx,%rdi
    6f6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f72:	e8 d9 e5 ff ff       	call   5550 <fwp_rc_forget_slot>
    6f77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6f7f:	e9 34 ff ff ff       	jmp    6eb8 <fwp_drop1+0x88>
    6f84:	48 8d 3d fd 88 00 00 	lea    0x88fd(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6f8b:	e8 60 d4 ff ff       	call   43f0 <fwp_trap>

0000000000006f90 <fwp_closure_drop>:
    6f90:	48 8b 15 21 dc 01 00 	mov    0x1dc21(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6f97:	48 89 f8             	mov    %rdi,%rax
    6f9a:	48 2b 05 ef db 01 00 	sub    0x1dbef(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6fa1:	48 c1 e2 10          	shl    $0x10,%rdx
    6fa5:	48 39 d0             	cmp    %rdx,%rax
    6fa8:	73 6b                	jae    7015 <fwp_closure_drop+0x85>
    6faa:	48 89 c2             	mov    %rax,%rdx
    6fad:	48 c1 ea 10          	shr    $0x10,%rdx
    6fb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fb5:	48 8b 15 1c dc 01 00 	mov    0x1dc1c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6fbc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6fc0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6fc4:	48 85 d2             	test   %rdx,%rdx
    6fc7:	74 4c                	je     7015 <fwp_closure_drop+0x85>
    6fc9:	0f b6 31             	movzbl (%rcx),%esi
    6fcc:	40 80 fe 02          	cmp    $0x2,%sil
    6fd0:	74 3e                	je     7010 <fwp_closure_drop+0x80>
    6fd2:	40 80 fe 01          	cmp    $0x1,%sil
    6fd6:	75 3d                	jne    7015 <fwp_closure_drop+0x85>
    6fd8:	8b 71 18             	mov    0x18(%rcx),%esi
    6fdb:	0f b7 c0             	movzwl %ax,%eax
    6fde:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6fe1:	48 0f af c6          	imul   %rsi,%rax
    6fe5:	48 c1 e8 20          	shr    $0x20,%rax
    6fe9:	48 39 c8             	cmp    %rcx,%rax
    6fec:	73 27                	jae    7015 <fwp_closure_drop+0x85>
    6fee:	48 01 c2             	add    %rax,%rdx
    6ff1:	0f b6 02             	movzbl (%rdx),%eax
    6ff4:	84 c0                	test   %al,%al
    6ff6:	74 1d                	je     7015 <fwp_closure_drop+0x85>
    6ff8:	3c 01                	cmp    $0x1,%al
    6ffa:	74 24                	je     7020 <fwp_closure_drop+0x90>
    6ffc:	3c ff                	cmp    $0xff,%al
    6ffe:	74 48                	je     7048 <fwp_closure_drop+0xb8>
    7000:	83 e8 01             	sub    $0x1,%eax
    7003:	88 02                	mov    %al,(%rdx)
    7005:	c3                   	ret
    7006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    700d:	00 00 00 
    7010:	66 85 c0             	test   %ax,%ax
    7013:	74 dc                	je     6ff1 <fwp_closure_drop+0x61>
    7015:	c3                   	ret
    7016:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    701d:	00 00 00 
    7020:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7027:	ff ff 
    7029:	48 85 c0             	test   %rax,%rax
    702c:	74 12                	je     7040 <fwp_closure_drop+0xb0>
    702e:	48 89 fe             	mov    %rdi,%rsi
    7031:	48 89 c7             	mov    %rax,%rdi
    7034:	e9 17 d4 ff ff       	jmp    4450 <fwp_closure_drop_push>
    7039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7040:	e9 bb d5 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    7045:	0f 1f 00             	nopl   (%rax)
    7048:	48 89 d0             	mov    %rdx,%rax
    704b:	48 8d 35 8e c7 01 00 	lea    0x1c78e(%rip),%rsi        # 237e0 <fwp_heap>
    7052:	48 83 ec 18          	sub    $0x18,%rsp
    7056:	48 c1 e8 11          	shr    $0x11,%rax
    705a:	48 31 d0             	xor    %rdx,%rax
    705d:	48 89 c1             	mov    %rax,%rcx
    7060:	48 c1 e9 09          	shr    $0x9,%rcx
    7064:	48 31 c8             	xor    %rcx,%rax
    7067:	0f b6 c8             	movzbl %al,%ecx
    706a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7071:	00 
    7072:	48 85 c0             	test   %rax,%rax
    7075:	75 12                	jne    7089 <fwp_closure_drop+0xf9>
    7077:	eb 49                	jmp    70c2 <fwp_closure_drop+0x132>
    7079:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7080:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7084:	48 85 c0             	test   %rax,%rax
    7087:	74 39                	je     70c2 <fwp_closure_drop+0x132>
    7089:	48 89 c1             	mov    %rax,%rcx
    708c:	48 39 10             	cmp    %rdx,(%rax)
    708f:	75 ef                	jne    7080 <fwp_closure_drop+0xf0>
    7091:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7095:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7099:	48 89 48 08          	mov    %rcx,0x8(%rax)
    709d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    70a4:	74 05                	je     70ab <fwp_closure_drop+0x11b>
    70a6:	48 83 c4 18          	add    $0x18,%rsp
    70aa:	c3                   	ret
    70ab:	48 89 d7             	mov    %rdx,%rdi
    70ae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70b3:	e8 98 e4 ff ff       	call   5550 <fwp_rc_forget_slot>
    70b8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70bd:	c6 02 fe             	movb   $0xfe,(%rdx)
    70c0:	eb e4                	jmp    70a6 <fwp_closure_drop+0x116>
    70c2:	48 8d 3d bf 87 00 00 	lea    0x87bf(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    70c9:	e8 22 d3 ff ff       	call   43f0 <fwp_trap>
    70ce:	66 90                	xchg   %ax,%ax

00000000000070d0 <fwp_owned_tape_release>:
    70d0:	48 85 ff             	test   %rdi,%rdi
    70d3:	0f 84 f7 00 00 00    	je     71d0 <fwp_owned_tape_release+0x100>
    70d9:	41 54                	push   %r12
    70db:	55                   	push   %rbp
    70dc:	53                   	push   %rbx
    70dd:	48 8b 07             	mov    (%rdi),%rax
    70e0:	48 85 c0             	test   %rax,%rax
    70e3:	74 08                	je     70ed <fwp_owned_tape_release+0x1d>
    70e5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    70e9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    70ed:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    70f1:	48 85 d2             	test   %rdx,%rdx
    70f4:	74 03                	je     70f9 <fwp_owned_tape_release+0x29>
    70f6:	48 89 02             	mov    %rax,(%rdx)
    70f9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    70fd:	48 89 fb             	mov    %rdi,%rbx
    7100:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7104:	48 85 c0             	test   %rax,%rax
    7107:	0f 84 89 00 00 00    	je     7196 <fwp_owned_tape_release+0xc6>
    710d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7111:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7115:	7e 47                	jle    715e <fwp_owned_tape_release+0x8e>
    7117:	31 ed                	xor    %ebp,%ebp
    7119:	eb 0d                	jmp    7128 <fwp_owned_tape_release+0x58>
    711b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7120:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7124:	48 8b 40 68          	mov    0x68(%rax),%rax
    7128:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    712c:	49 89 ec             	mov    %rbp,%r12
    712f:	48 83 c5 01          	add    $0x1,%rbp
    7133:	49 c1 e4 04          	shl    $0x4,%r12
    7137:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    713b:	ff d0                	call   *%rax
    713d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7141:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7146:	48 8b 43 10          	mov    0x10(%rbx),%rax
    714a:	ff 50 68             	call   *0x68(%rax)
    714d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7151:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7155:	48 39 e8             	cmp    %rbp,%rax
    7158:	7f c6                	jg     7120 <fwp_owned_tape_release+0x50>
    715a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    715e:	31 ed                	xor    %ebp,%ebp
    7160:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7165:	7e 28                	jle    718f <fwp_owned_tape_release+0xbf>
    7167:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    716e:	00 00 
    7170:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7174:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7178:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    717c:	74 07                	je     7185 <fwp_owned_tape_release+0xb5>
    717e:	ff 52 68             	call   *0x68(%rdx)
    7181:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7185:	48 83 c5 01          	add    $0x1,%rbp
    7189:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    718d:	7f e1                	jg     7170 <fwp_owned_tape_release+0xa0>
    718f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7193:	ff 52 68             	call   *0x68(%rdx)
    7196:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    719a:	e8 f1 fd ff ff       	call   6f90 <fwp_closure_drop>
    719f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    71a3:	e8 e8 fd ff ff       	call   6f90 <fwp_closure_drop>
    71a8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    71ac:	e8 df fd ff ff       	call   6f90 <fwp_closure_drop>
    71b1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    71b5:	e8 d6 e5 ff ff       	call   5790 <fwp_mem_free>
    71ba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    71be:	e8 cd e5 ff ff       	call   5790 <fwp_mem_free>
    71c3:	48 89 df             	mov    %rbx,%rdi
    71c6:	5b                   	pop    %rbx
    71c7:	5d                   	pop    %rbp
    71c8:	41 5c                	pop    %r12
    71ca:	e9 c1 e5 ff ff       	jmp    5790 <fwp_mem_free>
    71cf:	90                   	nop
    71d0:	c3                   	ret
    71d1:	0f 1f 40 00          	nopl   0x0(%rax)
    71d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71dc:	00 00 00 00 

00000000000071e0 <fwp_tape_finish>:
    71e0:	f3 0f 1e fa          	endbr64
    71e4:	41 56                	push   %r14
    71e6:	48 8d 3d d3 be 01 00 	lea    0x1bed3(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    71ed:	41 55                	push   %r13
    71ef:	41 54                	push   %r12
    71f1:	55                   	push   %rbp
    71f2:	53                   	push   %rbx
    71f3:	e8 18 cf ff ff       	call   4110 <fwp_tape_buffers_dispose>
    71f8:	48 83 3d 08 bf 01 00 	cmpq   $0x0,0x1bf08(%rip)        # 23108 <fwp_ntapes>
    71ff:	00 
    7200:	48 c7 05 9d be 01 00 	movq   $0x0,0x1be9d(%rip)        # 230a8 <fwp_tape_cached_bytes>
    7207:	00 00 00 00 
    720b:	7e 68                	jle    7275 <fwp_tape_finish+0x95>
    720d:	45 31 e4             	xor    %r12d,%r12d
    7210:	31 ed                	xor    %ebp,%ebp
    7212:	0f 1f 00             	nopl   (%rax)
    7215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    721c:	00 00 00 00 
    7220:	48 8b 1d e9 be 01 00 	mov    0x1bee9(%rip),%rbx        # 23110 <fwp_tapes>
    7227:	48 83 c5 01          	add    $0x1,%rbp
    722b:	4c 01 e3             	add    %r12,%rbx
    722e:	49 83 c4 68          	add    $0x68,%r12
    7232:	48 89 df             	mov    %rbx,%rdi
    7235:	e8 c6 c9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    723a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    723e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7242:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    7246:	e8 75 c1 ff ff       	call   33c0 <free@plt>
    724b:	4c 89 f7             	mov    %r14,%rdi
    724e:	e8 6d c1 ff ff       	call   33c0 <free@plt>
    7253:	4c 89 ef             	mov    %r13,%rdi
    7256:	e8 65 c1 ff ff       	call   33c0 <free@plt>
    725b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    725f:	e8 6c fe ff ff       	call   70d0 <fwp_owned_tape_release>
    7264:	48 39 2d 9d be 01 00 	cmp    %rbp,0x1be9d(%rip)        # 23108 <fwp_ntapes>
    726b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7272:	00 
    7273:	7f ab                	jg     7220 <fwp_tape_finish+0x40>
    7275:	48 8b 3d 94 be 01 00 	mov    0x1be94(%rip),%rdi        # 23110 <fwp_tapes>
    727c:	e8 3f c1 ff ff       	call   33c0 <free@plt>
    7281:	5b                   	pop    %rbx
    7282:	5d                   	pop    %rbp
    7283:	48 c7 05 82 be 01 00 	movq   $0x0,0x1be82(%rip)        # 23110 <fwp_tapes>
    728a:	00 00 00 00 
    728e:	48 c7 05 67 be 01 00 	movq   $0x0,0x1be67(%rip)        # 23100 <fwp_tapes_cap>
    7295:	00 00 00 00 
    7299:	41 5c                	pop    %r12
    729b:	48 c7 05 62 be 01 00 	movq   $0x0,0x1be62(%rip)        # 23108 <fwp_ntapes>
    72a2:	00 00 00 00 
    72a6:	41 5d                	pop    %r13
    72a8:	48 c7 05 45 be 01 00 	movq   $0x0,0x1be45(%rip)        # 230f8 <fwp_tape_next_slot>
    72af:	00 00 00 00 
    72b3:	41 5e                	pop    %r14
    72b5:	c3                   	ret
    72b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72bd:	00 00 00 

00000000000072c0 <fwp_tape_scope_release>:
    72c0:	f3 0f 1e fa          	endbr64
    72c4:	41 55                	push   %r13
    72c6:	41 54                	push   %r12
    72c8:	55                   	push   %rbp
    72c9:	53                   	push   %rbx
    72ca:	48 83 ec 58          	sub    $0x58,%rsp
    72ce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    72d5:	00 00 
    72d7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    72dc:	48 63 07             	movslq (%rdi),%rax
    72df:	85 c0                	test   %eax,%eax
    72e1:	0f 88 05 01 00 00    	js     73ec <fwp_tape_scope_release+0x12c>
    72e7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    72ee:	ec c4 4e 
    72f1:	48 89 fb             	mov    %rdi,%rbx
    72f4:	eb 3c                	jmp    7332 <fwp_tape_scope_release+0x72>
    72f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72fd:	00 00 00 
    7300:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    7305:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7309:	e8 b2 c0 ff ff       	call   33c0 <free@plt>
    730e:	48 8b 3c 24          	mov    (%rsp),%rdi
    7312:	e8 a9 c0 ff ff       	call   33c0 <free@plt>
    7317:	4c 89 ef             	mov    %r13,%rdi
    731a:	e8 a1 c0 ff ff       	call   33c0 <free@plt>
    731f:	4c 89 e7             	mov    %r12,%rdi
    7322:	e8 a9 fd ff ff       	call   70d0 <fwp_owned_tape_release>
    7327:	48 63 03             	movslq (%rbx),%rax
    732a:	85 c0                	test   %eax,%eax
    732c:	0f 88 ba 00 00 00    	js     73ec <fwp_tape_scope_release+0x12c>
    7332:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    7336:	48 8b 35 d3 bd 01 00 	mov    0x1bdd3(%rip),%rsi        # 23110 <fwp_tapes>
    733d:	4c 01 c6             	add    %r8,%rsi
    7340:	48 89 f7             	mov    %rsi,%rdi
    7343:	e8 b8 c8 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7348:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    734d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7352:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7359:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    735d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    7361:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7368:	00 
    7369:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    736e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    7372:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    7377:	66 0f ef d2          	pxor   %xmm2,%xmm2
    737b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7380:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7387:	00 
    7388:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    738f:	00 
    7390:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7397:	00 
    7398:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    739d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    73a2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    73a6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    73aa:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    73ae:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    73b4:	77 18                	ja     73ce <fwp_tape_scope_release+0x10e>
    73b6:	49 c1 f8 03          	sar    $0x3,%r8
    73ba:	4c 0f af c5          	imul   %rbp,%r8
    73be:	4c 3b 05 33 bd 01 00 	cmp    0x1bd33(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    73c5:	7d 07                	jge    73ce <fwp_tape_scope_release+0x10e>
    73c7:	4c 89 05 2a bd 01 00 	mov    %r8,0x1bd2a(%rip)        # 230f8 <fwp_tape_next_slot>
    73ce:	4d 85 e4             	test   %r12,%r12
    73d1:	0f 85 29 ff ff ff    	jne    7300 <fwp_tape_scope_release+0x40>
    73d7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    73dc:	e8 8f dc ff ff       	call   5070 <fwp_tape_buffers_release>
    73e1:	48 63 03             	movslq (%rbx),%rax
    73e4:	85 c0                	test   %eax,%eax
    73e6:	0f 89 46 ff ff ff    	jns    7332 <fwp_tape_scope_release+0x72>
    73ec:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    73f1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    73f8:	00 00 
    73fa:	75 0b                	jne    7407 <fwp_tape_scope_release+0x147>
    73fc:	48 83 c4 58          	add    $0x58,%rsp
    7400:	5b                   	pop    %rbx
    7401:	5d                   	pop    %rbp
    7402:	41 5c                	pop    %r12
    7404:	41 5d                	pop    %r13
    7406:	c3                   	ret
    7407:	e8 54 c0 ff ff       	call   3460 <__stack_chk_fail@plt>
    740c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007410 <fwp_task_dispose>:
    7410:	53                   	push   %rbx
    7411:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7415:	0f 84 2b c3 ff ff    	je     3746 <fwp_task_dispose.cold>
    741b:	48 89 fb             	mov    %rdi,%rbx
    741e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7423:	0f 85 1d c3 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7429:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    742d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7434:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    743b:	00 
    743c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7440:	48 85 ff             	test   %rdi,%rdi
    7443:	74 07                	je     744c <fwp_task_dispose+0x3c>
    7445:	48 85 c0             	test   %rax,%rax
    7448:	74 02                	je     744c <fwp_task_dispose+0x3c>
    744a:	ff d0                	call   *%rax
    744c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7453:	e8 38 e3 ff ff       	call   5790 <fwp_mem_free>
    7458:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    745f:	00 00 00 00 
    7463:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7467:	74 6f                	je     74d8 <fwp_task_dispose+0xc8>
    7469:	48 8b 15 48 d7 01 00 	mov    0x1d748(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7470:	48 89 d8             	mov    %rbx,%rax
    7473:	48 2b 05 16 d7 01 00 	sub    0x1d716(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    747a:	48 c1 e2 10          	shl    $0x10,%rdx
    747e:	48 39 d0             	cmp    %rdx,%rax
    7481:	73 4c                	jae    74cf <fwp_task_dispose+0xbf>
    7483:	48 89 c2             	mov    %rax,%rdx
    7486:	48 c1 ea 10          	shr    $0x10,%rdx
    748a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    748e:	48 8b 15 43 d7 01 00 	mov    0x1d743(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7495:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7499:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    749d:	48 85 c9             	test   %rcx,%rcx
    74a0:	74 2d                	je     74cf <fwp_task_dispose+0xbf>
    74a2:	0f b6 32             	movzbl (%rdx),%esi
    74a5:	40 80 fe 02          	cmp    $0x2,%sil
    74a9:	74 3d                	je     74e8 <fwp_task_dispose+0xd8>
    74ab:	40 80 fe 01          	cmp    $0x1,%sil
    74af:	75 1e                	jne    74cf <fwp_task_dispose+0xbf>
    74b1:	8b 72 18             	mov    0x18(%rdx),%esi
    74b4:	0f b7 c0             	movzwl %ax,%eax
    74b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74ba:	48 0f af c6          	imul   %rsi,%rax
    74be:	48 c1 e8 20          	shr    $0x20,%rax
    74c2:	48 39 d0             	cmp    %rdx,%rax
    74c5:	73 08                	jae    74cf <fwp_task_dispose+0xbf>
    74c7:	48 01 c1             	add    %rax,%rcx
    74ca:	80 39 01             	cmpb   $0x1,(%rcx)
    74cd:	74 09                	je     74d8 <fwp_task_dispose+0xc8>
    74cf:	5b                   	pop    %rbx
    74d0:	c3                   	ret
    74d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74d8:	48 89 df             	mov    %rbx,%rdi
    74db:	5b                   	pop    %rbx
    74dc:	e9 af e2 ff ff       	jmp    5790 <fwp_mem_free>
    74e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74e8:	66 85 c0             	test   %ax,%ax
    74eb:	74 dd                	je     74ca <fwp_task_dispose+0xba>
    74ed:	5b                   	pop    %rbx
    74ee:	c3                   	ret
    74ef:	90                   	nop

00000000000074f0 <fwp_free_zombie>:
    74f0:	48 8b 15 b9 c2 01 00 	mov    0x1c2b9(%rip),%rdx        # 237b0 <fwp_zombie>
    74f7:	48 85 d2             	test   %rdx,%rdx
    74fa:	0f 84 98 00 00 00    	je     7598 <fwp_free_zombie+0xa8>
    7500:	48 3b 15 b9 c2 01 00 	cmp    0x1c2b9(%rip),%rdx        # 237c0 <fwp_cur>
    7507:	0f 84 8b 00 00 00    	je     7598 <fwp_free_zombie+0xa8>
    750d:	48 83 ec 18          	sub    $0x18,%rsp
    7511:	48 63 05 6c bc 01 00 	movslq 0x1bc6c(%rip),%rax        # 23184 <fwp_stack_pool_n>
    7518:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    751c:	83 f8 3f             	cmp    $0x3f,%eax
    751f:	7f 7f                	jg     75a0 <fwp_free_zombie+0xb0>
    7521:	8d 48 01             	lea    0x1(%rax),%ecx
    7524:	89 0d 5a bc 01 00    	mov    %ecx,0x1bc5a(%rip)        # 23184 <fwp_stack_pool_n>
    752a:	48 8d 0d 6f bc 01 00 	lea    0x1bc6f(%rip),%rcx        # 231a0 <fwp_stack_pool>
    7531:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7535:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    753c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7540:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7547:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    754b:	48 85 c9             	test   %rcx,%rcx
    754e:	0f 84 fc 00 00 00    	je     7650 <fwp_free_zombie+0x160>
    7554:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    755b:	48 85 c0             	test   %rax,%rax
    755e:	74 07                	je     7567 <fwp_free_zombie+0x77>
    7560:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7567:	8b 42 5c             	mov    0x5c(%rdx),%eax
    756a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    756e:	48 c7 05 37 c2 01 00 	movq   $0x0,0x1c237(%rip)        # 237b0 <fwp_zombie>
    7575:	00 00 00 00 
    7579:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7580:	85 c0                	test   %eax,%eax
    7582:	74 34                	je     75b8 <fwp_free_zombie+0xc8>
    7584:	83 f8 01             	cmp    $0x1,%eax
    7587:	0f 84 b3 00 00 00    	je     7640 <fwp_free_zombie+0x150>
    758d:	48 83 c4 18          	add    $0x18,%rsp
    7591:	c3                   	ret
    7592:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7598:	c3                   	ret
    7599:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75a0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    75a4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    75a9:	e8 32 c0 ff ff       	call   35e0 <munmap@plt>
    75ae:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75b3:	eb 80                	jmp    7535 <fwp_free_zombie+0x45>
    75b5:	0f 1f 00             	nopl   (%rax)
    75b8:	48 8b 0d f9 d5 01 00 	mov    0x1d5f9(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    75bf:	48 89 d0             	mov    %rdx,%rax
    75c2:	48 2b 05 c7 d5 01 00 	sub    0x1d5c7(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    75c9:	48 c1 e1 10          	shl    $0x10,%rcx
    75cd:	48 39 c8             	cmp    %rcx,%rax
    75d0:	73 bb                	jae    758d <fwp_free_zombie+0x9d>
    75d2:	48 89 c1             	mov    %rax,%rcx
    75d5:	48 c1 e9 10          	shr    $0x10,%rcx
    75d9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    75dd:	48 8b 0d f4 d5 01 00 	mov    0x1d5f4(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    75e4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    75e8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    75ec:	48 85 c9             	test   %rcx,%rcx
    75ef:	74 9c                	je     758d <fwp_free_zombie+0x9d>
    75f1:	0f b6 3e             	movzbl (%rsi),%edi
    75f4:	40 80 ff 02          	cmp    $0x2,%dil
    75f8:	74 66                	je     7660 <fwp_free_zombie+0x170>
    75fa:	40 80 ff 01          	cmp    $0x1,%dil
    75fe:	75 8d                	jne    758d <fwp_free_zombie+0x9d>
    7600:	8b 7e 18             	mov    0x18(%rsi),%edi
    7603:	0f b7 c0             	movzwl %ax,%eax
    7606:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7609:	48 0f af c7          	imul   %rdi,%rax
    760d:	48 c1 e8 20          	shr    $0x20,%rax
    7611:	48 39 f0             	cmp    %rsi,%rax
    7614:	0f 83 73 ff ff ff    	jae    758d <fwp_free_zombie+0x9d>
    761a:	48 01 c1             	add    %rax,%rcx
    761d:	0f b6 01             	movzbl (%rcx),%eax
    7620:	84 c0                	test   %al,%al
    7622:	0f 84 65 ff ff ff    	je     758d <fwp_free_zombie+0x9d>
    7628:	3c 01                	cmp    $0x1,%al
    762a:	74 14                	je     7640 <fwp_free_zombie+0x150>
    762c:	3c ff                	cmp    $0xff,%al
    762e:	74 3b                	je     766b <fwp_free_zombie+0x17b>
    7630:	83 e8 01             	sub    $0x1,%eax
    7633:	88 01                	mov    %al,(%rcx)
    7635:	e9 53 ff ff ff       	jmp    758d <fwp_free_zombie+0x9d>
    763a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7640:	48 89 d7             	mov    %rdx,%rdi
    7643:	48 83 c4 18          	add    $0x18,%rsp
    7647:	e9 c4 fd ff ff       	jmp    7410 <fwp_task_dispose>
    764c:	0f 1f 40 00          	nopl   0x0(%rax)
    7650:	48 89 05 31 c1 01 00 	mov    %rax,0x1c131(%rip)        # 23788 <fwp_tasks_active>
    7657:	e9 ff fe ff ff       	jmp    755b <fwp_free_zombie+0x6b>
    765c:	0f 1f 40 00          	nopl   0x0(%rax)
    7660:	66 85 c0             	test   %ax,%ax
    7663:	0f 85 24 ff ff ff    	jne    758d <fwp_free_zombie+0x9d>
    7669:	eb b2                	jmp    761d <fwp_free_zombie+0x12d>
    766b:	48 89 ca             	mov    %rcx,%rdx
    766e:	48 8d 35 6b c1 01 00 	lea    0x1c16b(%rip),%rsi        # 237e0 <fwp_heap>
    7675:	48 c1 ea 11          	shr    $0x11,%rdx
    7679:	48 31 ca             	xor    %rcx,%rdx
    767c:	48 89 d0             	mov    %rdx,%rax
    767f:	48 c1 e8 09          	shr    $0x9,%rax
    7683:	48 31 c2             	xor    %rax,%rdx
    7686:	0f b6 d2             	movzbl %dl,%edx
    7689:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7690:	00 
    7691:	48 85 c0             	test   %rax,%rax
    7694:	75 13                	jne    76a9 <fwp_free_zombie+0x1b9>
    7696:	eb 4c                	jmp    76e4 <fwp_free_zombie+0x1f4>
    7698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    769f:	00 
    76a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    76a4:	48 85 c0             	test   %rax,%rax
    76a7:	74 3b                	je     76e4 <fwp_free_zombie+0x1f4>
    76a9:	48 89 c2             	mov    %rax,%rdx
    76ac:	48 39 08             	cmp    %rcx,(%rax)
    76af:	75 ef                	jne    76a0 <fwp_free_zombie+0x1b0>
    76b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    76b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    76bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    76c4:	0f 85 c3 fe ff ff    	jne    758d <fwp_free_zombie+0x9d>
    76ca:	48 89 cf             	mov    %rcx,%rdi
    76cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    76d2:	e8 79 de ff ff       	call   5550 <fwp_rc_forget_slot>
    76d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    76dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    76df:	e9 a9 fe ff ff       	jmp    758d <fwp_free_zombie+0x9d>
    76e4:	48 8d 3d 9d 81 00 00 	lea    0x819d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    76eb:	e8 00 cd ff ff       	call   43f0 <fwp_trap>

00000000000076f0 <fwp_block>:
    76f0:	48 83 ec 08          	sub    $0x8,%rsp
    76f4:	48 8b 05 ad c0 01 00 	mov    0x1c0ad(%rip),%rax        # 237a8 <fwp_ready_head>
    76fb:	48 85 c0             	test   %rax,%rax
    76fe:	0f 84 1c 01 00 00    	je     7820 <fwp_block+0x130>
    7704:	90                   	nop
    7705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    770c:	00 00 00 00 
    7710:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7717:	48 89 15 8a c0 01 00 	mov    %rdx,0x1c08a(%rip)        # 237a8 <fwp_ready_head>
    771e:	48 85 d2             	test   %rdx,%rdx
    7721:	0f 84 19 01 00 00    	je     7840 <fwp_block+0x150>
    7727:	48 8b 15 92 c0 01 00 	mov    0x1c092(%rip),%rdx        # 237c0 <fwp_cur>
    772e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7732:	48 39 c2             	cmp    %rax,%rdx
    7735:	0f 84 d5 00 00 00    	je     7810 <fwp_block+0x120>
    773b:	48 8b 0d 06 dd 01 00 	mov    0x1dd06(%rip),%rcx        # 25448 <fwp_state_owners>
    7742:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7746:	48 89 05 73 c0 01 00 	mov    %rax,0x1c073(%rip)        # 237c0 <fwp_cur>
    774d:	f3 0f 7e 05 1b dd 01 	movq   0x1dd1b(%rip),%xmm0        # 25470 <fwp_foreign_callbacks>
    7754:	00 
    7755:	0f 16 05 04 dd 01 00 	movhps 0x1dd04(%rip),%xmm0        # 25460 <fwp_state>
    775c:	f3 0f 7e 0d 04 dd 01 	movq   0x1dd04(%rip),%xmm1        # 25468 <fwp_handlers>
    7763:	00 
    7764:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    776b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7772:	0f 16 0d ff dc 01 00 	movhps 0x1dcff(%rip),%xmm1        # 25478 <fwp_cleanups>
    7779:	f3 0f 7e 05 d7 dc 01 	movq   0x1dcd7(%rip),%xmm0        # 25458 <fwp_state_len>
    7780:	00 
    7781:	0f 16 05 c8 dc 01 00 	movhps 0x1dcc8(%rip),%xmm0        # 25450 <fwp_state_cap>
    7788:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    778f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7796:	48 8b 70 08          	mov    0x8(%rax),%rsi
    779a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    77a1:	48 89 0d c0 dc 01 00 	mov    %rcx,0x1dcc0(%rip)        # 25468 <fwp_handlers>
    77a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    77af:	48 89 0d c2 dc 01 00 	mov    %rcx,0x1dcc2(%rip)        # 25478 <fwp_cleanups>
    77b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    77bd:	48 89 0d ac dc 01 00 	mov    %rcx,0x1dcac(%rip)        # 25470 <fwp_foreign_callbacks>
    77c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    77cb:	48 89 0d 8e dc 01 00 	mov    %rcx,0x1dc8e(%rip)        # 25460 <fwp_state>
    77d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    77d9:	48 89 0d 78 dc 01 00 	mov    %rcx,0x1dc78(%rip)        # 25458 <fwp_state_len>
    77e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    77e7:	48 89 0d 62 dc 01 00 	mov    %rcx,0x1dc62(%rip)        # 25450 <fwp_state_cap>
    77ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    77f5:	48 89 0d 4c dc 01 00 	mov    %rcx,0x1dc4c(%rip)        # 25448 <fwp_state_owners>
    77fc:	e8 8f bc ff ff       	call   3490 <swapcontext@plt>
    7801:	f3 0f 1e fa          	endbr64
    7805:	e8 e6 fc ff ff       	call   74f0 <fwp_free_zombie>
    780a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7810:	8b 05 6a b9 01 00    	mov    0x1b96a(%rip),%eax        # 23180 <fwp_slice>
    7816:	85 c0                	test   %eax,%eax
    7818:	74 36                	je     7850 <fwp_block+0x160>
    781a:	48 83 c4 08          	add    $0x8,%rsp
    781e:	c3                   	ret
    781f:	90                   	nop
    7820:	e8 7b d9 ff ff       	call   51a0 <fwp_poll_events>
    7825:	48 8b 05 7c bf 01 00 	mov    0x1bf7c(%rip),%rax        # 237a8 <fwp_ready_head>
    782c:	48 85 c0             	test   %rax,%rax
    782f:	0f 85 db fe ff ff    	jne    7710 <fwp_block+0x20>
    7835:	eb e9                	jmp    7820 <fwp_block+0x130>
    7837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    783e:	00 00 
    7840:	48 c7 05 55 bf 01 00 	movq   $0x0,0x1bf55(%rip)        # 237a0 <fwp_ready_tail>
    7847:	00 00 00 00 
    784b:	e9 d7 fe ff ff       	jmp    7727 <fwp_block+0x37>
    7850:	48 8d 3d 2d 79 00 00 	lea    0x792d(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    7857:	e8 44 bb ff ff       	call   33a0 <getenv@plt>
    785c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7861:	48 85 c0             	test   %rax,%rax
    7864:	74 05                	je     786b <fwp_block+0x17b>
    7866:	80 38 00             	cmpb   $0x0,(%rax)
    7869:	75 0b                	jne    7876 <fwp_block+0x186>
    786b:	89 15 0f b9 01 00    	mov    %edx,0x1b90f(%rip)        # 23180 <fwp_slice>
    7871:	48 83 c4 08          	add    $0x8,%rsp
    7875:	c3                   	ret
    7876:	ba 0a 00 00 00       	mov    $0xa,%edx
    787b:	31 f6                	xor    %esi,%esi
    787d:	48 89 c7             	mov    %rax,%rdi
    7880:	e8 cb bc ff ff       	call   3550 <strtoll@plt>
    7885:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7889:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7890:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7895:	0f 46 d0             	cmovbe %eax,%edx
    7898:	eb d1                	jmp    786b <fwp_block+0x17b>
    789a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000078a0 <fwp_drop4>:
    78a0:	48 8b 15 11 d3 01 00 	mov    0x1d311(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    78a7:	48 89 f8             	mov    %rdi,%rax
    78aa:	48 2b 05 df d2 01 00 	sub    0x1d2df(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    78b1:	48 c1 e2 10          	shl    $0x10,%rdx
    78b5:	48 39 d0             	cmp    %rdx,%rax
    78b8:	0f 83 52 01 00 00    	jae    7a10 <fwp_drop4+0x170>
    78be:	48 83 ec 18          	sub    $0x18,%rsp
    78c2:	4c 8d 05 17 bf 01 00 	lea    0x1bf17(%rip),%r8        # 237e0 <fwp_heap>
    78c9:	48 89 c2             	mov    %rax,%rdx
    78cc:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    78d3:	48 c1 ea 10          	shr    $0x10,%rdx
    78d7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    78db:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    78df:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    78e3:	48 85 d2             	test   %rdx,%rdx
    78e6:	74 46                	je     792e <fwp_drop4+0x8e>
    78e8:	44 0f b6 09          	movzbl (%rcx),%r9d
    78ec:	41 80 f9 02          	cmp    $0x2,%r9b
    78f0:	0f 84 ca 00 00 00    	je     79c0 <fwp_drop4+0x120>
    78f6:	41 80 f9 01          	cmp    $0x1,%r9b
    78fa:	75 32                	jne    792e <fwp_drop4+0x8e>
    78fc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7900:	0f b7 c0             	movzwl %ax,%eax
    7903:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7906:	49 0f af c1          	imul   %r9,%rax
    790a:	48 c1 e8 20          	shr    $0x20,%rax
    790e:	48 39 c8             	cmp    %rcx,%rax
    7911:	73 1b                	jae    792e <fwp_drop4+0x8e>
    7913:	48 01 c2             	add    %rax,%rdx
    7916:	0f b6 02             	movzbl (%rdx),%eax
    7919:	84 c0                	test   %al,%al
    791b:	74 11                	je     792e <fwp_drop4+0x8e>
    791d:	3c 01                	cmp    $0x1,%al
    791f:	74 17                	je     7938 <fwp_drop4+0x98>
    7921:	3c ff                	cmp    $0xff,%al
    7923:	0f 84 ef 00 00 00    	je     7a18 <fwp_drop4+0x178>
    7929:	83 e8 01             	sub    $0x1,%eax
    792c:	88 02                	mov    %al,(%rdx)
    792e:	48 83 c4 18          	add    $0x18,%rsp
    7932:	c3                   	ret
    7933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7938:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    793c:	0f 88 8e 00 00 00    	js     79d0 <fwp_drop4+0x130>
    7942:	48 8b 15 6f d2 01 00 	mov    0x1d26f(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7949:	48 89 f8             	mov    %rdi,%rax
    794c:	48 2b 05 3d d2 01 00 	sub    0x1d23d(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7953:	48 c1 e2 10          	shl    $0x10,%rdx
    7957:	48 39 d0             	cmp    %rdx,%rax
    795a:	73 d2                	jae    792e <fwp_drop4+0x8e>
    795c:	48 89 c2             	mov    %rax,%rdx
    795f:	48 c1 ea 10          	shr    $0x10,%rdx
    7963:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7967:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    796b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    796f:	48 85 c9             	test   %rcx,%rcx
    7972:	74 ba                	je     792e <fwp_drop4+0x8e>
    7974:	0f b6 32             	movzbl (%rdx),%esi
    7977:	40 80 fe 02          	cmp    $0x2,%sil
    797b:	74 33                	je     79b0 <fwp_drop4+0x110>
    797d:	40 80 fe 01          	cmp    $0x1,%sil
    7981:	75 ab                	jne    792e <fwp_drop4+0x8e>
    7983:	8b 72 18             	mov    0x18(%rdx),%esi
    7986:	0f b7 c0             	movzwl %ax,%eax
    7989:	8b 52 1c             	mov    0x1c(%rdx),%edx
    798c:	48 0f af c6          	imul   %rsi,%rax
    7990:	48 c1 e8 20          	shr    $0x20,%rax
    7994:	48 39 d0             	cmp    %rdx,%rax
    7997:	73 95                	jae    792e <fwp_drop4+0x8e>
    7999:	48 01 c1             	add    %rax,%rcx
    799c:	80 39 01             	cmpb   $0x1,(%rcx)
    799f:	75 8d                	jne    792e <fwp_drop4+0x8e>
    79a1:	48 83 c4 18          	add    $0x18,%rsp
    79a5:	e9 e6 dd ff ff       	jmp    5790 <fwp_mem_free>
    79aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79b0:	66 85 c0             	test   %ax,%ax
    79b3:	74 e7                	je     799c <fwp_drop4+0xfc>
    79b5:	48 83 c4 18          	add    $0x18,%rsp
    79b9:	c3                   	ret
    79ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79c0:	66 85 c0             	test   %ax,%ax
    79c3:	0f 84 4d ff ff ff    	je     7916 <fwp_drop4+0x76>
    79c9:	48 83 c4 18          	add    $0x18,%rsp
    79cd:	c3                   	ret
    79ce:	66 90                	xchg   %ax,%ax
    79d0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    79d4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    79d9:	e8 b2 ef ff ff       	call   6990 <fwp_rc_free_arr>
    79de:	4c 8d 05 fb bd 01 00 	lea    0x1bdfb(%rip),%r8        # 237e0 <fwp_heap>
    79e5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    79ea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    79f1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    79f8:	48 c1 e2 10          	shl    $0x10,%rdx
    79fc:	48 39 d0             	cmp    %rdx,%rax
    79ff:	0f 83 29 ff ff ff    	jae    792e <fwp_drop4+0x8e>
    7a05:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7a0a:	e9 ba fe ff ff       	jmp    78c9 <fwp_drop4+0x29>
    7a0f:	90                   	nop
    7a10:	c3                   	ret
    7a11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a18:	48 89 d0             	mov    %rdx,%rax
    7a1b:	48 c1 e8 11          	shr    $0x11,%rax
    7a1f:	48 31 d0             	xor    %rdx,%rax
    7a22:	48 89 c1             	mov    %rax,%rcx
    7a25:	48 c1 e9 09          	shr    $0x9,%rcx
    7a29:	48 31 c8             	xor    %rcx,%rax
    7a2c:	0f b6 c8             	movzbl %al,%ecx
    7a2f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7a36:	00 
    7a37:	48 85 c0             	test   %rax,%rax
    7a3a:	75 0d                	jne    7a49 <fwp_drop4+0x1a9>
    7a3c:	eb 46                	jmp    7a84 <fwp_drop4+0x1e4>
    7a3e:	66 90                	xchg   %ax,%ax
    7a40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7a44:	48 85 c0             	test   %rax,%rax
    7a47:	74 3b                	je     7a84 <fwp_drop4+0x1e4>
    7a49:	48 89 c1             	mov    %rax,%rcx
    7a4c:	48 39 10             	cmp    %rdx,(%rax)
    7a4f:	75 ef                	jne    7a40 <fwp_drop4+0x1a0>
    7a51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7a59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7a5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7a64:	0f 85 c4 fe ff ff    	jne    792e <fwp_drop4+0x8e>
    7a6a:	48 89 d7             	mov    %rdx,%rdi
    7a6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a72:	e8 d9 da ff ff       	call   5550 <fwp_rc_forget_slot>
    7a77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7a7f:	e9 aa fe ff ff       	jmp    792e <fwp_drop4+0x8e>
    7a84:	48 8d 3d fd 7d 00 00 	lea    0x7dfd(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    7a8b:	e8 60 c9 ff ff       	call   43f0 <fwp_trap>

0000000000007a90 <fwp_caps161>:
    7a90:	f3 0f 1e fa          	endbr64
    7a94:	85 f6                	test   %esi,%esi
    7a96:	74 08                	je     7aa0 <fwp_caps161+0x10>
    7a98:	c3                   	ret
    7a99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7aa0:	48 8b 15 11 d1 01 00 	mov    0x1d111(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7aa7:	48 89 f8             	mov    %rdi,%rax
    7aaa:	48 2b 05 df d0 01 00 	sub    0x1d0df(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7ab1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ab5:	48 39 d0             	cmp    %rdx,%rax
    7ab8:	73 de                	jae    7a98 <fwp_caps161+0x8>
    7aba:	48 89 c2             	mov    %rax,%rdx
    7abd:	48 c1 ea 10          	shr    $0x10,%rdx
    7ac1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ac5:	48 8b 15 0c d1 01 00 	mov    0x1d10c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7acc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ad0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7ad4:	48 85 c9             	test   %rcx,%rcx
    7ad7:	74 bf                	je     7a98 <fwp_caps161+0x8>
    7ad9:	0f b6 32             	movzbl (%rdx),%esi
    7adc:	40 80 fe 02          	cmp    $0x2,%sil
    7ae0:	74 2e                	je     7b10 <fwp_caps161+0x80>
    7ae2:	40 80 fe 01          	cmp    $0x1,%sil
    7ae6:	75 b0                	jne    7a98 <fwp_caps161+0x8>
    7ae8:	8b 72 18             	mov    0x18(%rdx),%esi
    7aeb:	0f b7 c0             	movzwl %ax,%eax
    7aee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7af1:	48 0f af c6          	imul   %rsi,%rax
    7af5:	48 c1 e8 20          	shr    $0x20,%rax
    7af9:	48 39 d0             	cmp    %rdx,%rax
    7afc:	73 9a                	jae    7a98 <fwp_caps161+0x8>
    7afe:	48 01 c1             	add    %rax,%rcx
    7b01:	80 39 01             	cmpb   $0x1,(%rcx)
    7b04:	75 92                	jne    7a98 <fwp_caps161+0x8>
    7b06:	e9 85 dc ff ff       	jmp    5790 <fwp_mem_free>
    7b0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b10:	66 85 c0             	test   %ax,%ax
    7b13:	74 ec                	je     7b01 <fwp_caps161+0x71>
    7b15:	c3                   	ret
    7b16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b1d:	00 00 00 

0000000000007b20 <fwp_args12>:
    7b20:	f3 0f 1e fa          	endbr64
    7b24:	85 d2                	test   %edx,%edx
    7b26:	74 04                	je     7b2c <fwp_args12+0xc>
    7b28:	85 f6                	test   %esi,%esi
    7b2a:	74 04                	je     7b30 <fwp_args12+0x10>
    7b2c:	c3                   	ret
    7b2d:	0f 1f 00             	nopl   (%rax)
    7b30:	48 8b 15 81 d0 01 00 	mov    0x1d081(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7b37:	48 8b 07             	mov    (%rdi),%rax
    7b3a:	48 2b 05 4f d0 01 00 	sub    0x1d04f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7b41:	48 c1 e2 10          	shl    $0x10,%rdx
    7b45:	48 39 d0             	cmp    %rdx,%rax
    7b48:	73 e2                	jae    7b2c <fwp_args12+0xc>
    7b4a:	48 89 c2             	mov    %rax,%rdx
    7b4d:	48 c1 ea 10          	shr    $0x10,%rdx
    7b51:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b55:	48 8b 15 7c d0 01 00 	mov    0x1d07c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7b5c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b60:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7b64:	48 85 ff             	test   %rdi,%rdi
    7b67:	74 c3                	je     7b2c <fwp_args12+0xc>
    7b69:	0f b6 0a             	movzbl (%rdx),%ecx
    7b6c:	80 f9 02             	cmp    $0x2,%cl
    7b6f:	74 2f                	je     7ba0 <fwp_args12+0x80>
    7b71:	80 f9 01             	cmp    $0x1,%cl
    7b74:	75 b6                	jne    7b2c <fwp_args12+0xc>
    7b76:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b79:	0f b7 c0             	movzwl %ax,%eax
    7b7c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b7f:	48 0f af c1          	imul   %rcx,%rax
    7b83:	48 c1 e8 20          	shr    $0x20,%rax
    7b87:	48 39 d0             	cmp    %rdx,%rax
    7b8a:	73 a0                	jae    7b2c <fwp_args12+0xc>
    7b8c:	48 01 c7             	add    %rax,%rdi
    7b8f:	0f b6 07             	movzbl (%rdi),%eax
    7b92:	84 c0                	test   %al,%al
    7b94:	74 96                	je     7b2c <fwp_args12+0xc>
    7b96:	3c fd                	cmp    $0xfd,%al
    7b98:	77 0c                	ja     7ba6 <fwp_args12+0x86>
    7b9a:	83 c0 01             	add    $0x1,%eax
    7b9d:	88 07                	mov    %al,(%rdi)
    7b9f:	c3                   	ret
    7ba0:	66 85 c0             	test   %ax,%ax
    7ba3:	74 ea                	je     7b8f <fwp_args12+0x6f>
    7ba5:	c3                   	ret
    7ba6:	e9 85 d8 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007bb0 <fwp_args23>:
    7bb0:	f3 0f 1e fa          	endbr64
    7bb4:	85 d2                	test   %edx,%edx
    7bb6:	74 04                	je     7bbc <fwp_args23+0xc>
    7bb8:	85 f6                	test   %esi,%esi
    7bba:	74 04                	je     7bc0 <fwp_args23+0x10>
    7bbc:	c3                   	ret
    7bbd:	0f 1f 00             	nopl   (%rax)
    7bc0:	48 8b 15 f1 cf 01 00 	mov    0x1cff1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7bc7:	48 8b 07             	mov    (%rdi),%rax
    7bca:	48 2b 05 bf cf 01 00 	sub    0x1cfbf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7bd1:	48 c1 e2 10          	shl    $0x10,%rdx
    7bd5:	48 39 d0             	cmp    %rdx,%rax
    7bd8:	73 e2                	jae    7bbc <fwp_args23+0xc>
    7bda:	48 89 c2             	mov    %rax,%rdx
    7bdd:	48 c1 ea 10          	shr    $0x10,%rdx
    7be1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7be5:	48 8b 15 ec cf 01 00 	mov    0x1cfec(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7bec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7bf0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7bf4:	48 85 ff             	test   %rdi,%rdi
    7bf7:	74 c3                	je     7bbc <fwp_args23+0xc>
    7bf9:	0f b6 0a             	movzbl (%rdx),%ecx
    7bfc:	80 f9 02             	cmp    $0x2,%cl
    7bff:	74 2f                	je     7c30 <fwp_args23+0x80>
    7c01:	80 f9 01             	cmp    $0x1,%cl
    7c04:	75 b6                	jne    7bbc <fwp_args23+0xc>
    7c06:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c09:	0f b7 c0             	movzwl %ax,%eax
    7c0c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c0f:	48 0f af c1          	imul   %rcx,%rax
    7c13:	48 c1 e8 20          	shr    $0x20,%rax
    7c17:	48 39 d0             	cmp    %rdx,%rax
    7c1a:	73 a0                	jae    7bbc <fwp_args23+0xc>
    7c1c:	48 01 c7             	add    %rax,%rdi
    7c1f:	0f b6 07             	movzbl (%rdi),%eax
    7c22:	84 c0                	test   %al,%al
    7c24:	74 96                	je     7bbc <fwp_args23+0xc>
    7c26:	3c fd                	cmp    $0xfd,%al
    7c28:	77 0c                	ja     7c36 <fwp_args23+0x86>
    7c2a:	83 c0 01             	add    $0x1,%eax
    7c2d:	88 07                	mov    %al,(%rdi)
    7c2f:	c3                   	ret
    7c30:	66 85 c0             	test   %ax,%ax
    7c33:	74 ea                	je     7c1f <fwp_args23+0x6f>
    7c35:	c3                   	ret
    7c36:	e9 f5 d7 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7c3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007c40 <fwp_caps12>:
    7c40:	f3 0f 1e fa          	endbr64
    7c44:	48 83 ec 18          	sub    $0x18,%rsp
    7c48:	8b 57 04             	mov    0x4(%rdi),%edx
    7c4b:	48 89 f8             	mov    %rdi,%rax
    7c4e:	85 d2                	test   %edx,%edx
    7c50:	0f 84 9a 00 00 00    	je     7cf0 <fwp_caps12+0xb0>
    7c56:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7c5a:	85 f6                	test   %esi,%esi
    7c5c:	0f 85 9e 00 00 00    	jne    7d00 <fwp_caps12+0xc0>
    7c62:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7c67:	e8 34 f0 ff ff       	call   6ca0 <fwp_drop0>
    7c6c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c71:	48 8b 0d 40 cf 01 00 	mov    0x1cf40(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7c78:	48 89 c2             	mov    %rax,%rdx
    7c7b:	48 2b 15 0e cf 01 00 	sub    0x1cf0e(%rip),%rdx        # 24b90 <fwp_heap+0x13b0>
    7c82:	48 c1 e1 10          	shl    $0x10,%rcx
    7c86:	48 39 ca             	cmp    %rcx,%rdx
    7c89:	73 6d                	jae    7cf8 <fwp_caps12+0xb8>
    7c8b:	48 89 d1             	mov    %rdx,%rcx
    7c8e:	48 c1 e9 10          	shr    $0x10,%rcx
    7c92:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7c96:	48 8b 0d 3b cf 01 00 	mov    0x1cf3b(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7c9d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7ca1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7ca5:	48 85 f6             	test   %rsi,%rsi
    7ca8:	74 4e                	je     7cf8 <fwp_caps12+0xb8>
    7caa:	0f b6 39             	movzbl (%rcx),%edi
    7cad:	40 80 ff 02          	cmp    $0x2,%dil
    7cb1:	0f 84 b9 00 00 00    	je     7d70 <fwp_caps12+0x130>
    7cb7:	40 80 ff 01          	cmp    $0x1,%dil
    7cbb:	75 3b                	jne    7cf8 <fwp_caps12+0xb8>
    7cbd:	8b 79 18             	mov    0x18(%rcx),%edi
    7cc0:	0f b7 d2             	movzwl %dx,%edx
    7cc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7cc6:	48 0f af d7          	imul   %rdi,%rdx
    7cca:	48 c1 ea 20          	shr    $0x20,%rdx
    7cce:	48 39 ca             	cmp    %rcx,%rdx
    7cd1:	73 25                	jae    7cf8 <fwp_caps12+0xb8>
    7cd3:	48 01 d6             	add    %rdx,%rsi
    7cd6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7cd9:	75 1d                	jne    7cf8 <fwp_caps12+0xb8>
    7cdb:	48 89 c7             	mov    %rax,%rdi
    7cde:	48 83 c4 18          	add    $0x18,%rsp
    7ce2:	e9 a9 da ff ff       	jmp    5790 <fwp_mem_free>
    7ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cee:	00 00 
    7cf0:	85 f6                	test   %esi,%esi
    7cf2:	0f 84 79 ff ff ff    	je     7c71 <fwp_caps12+0x31>
    7cf8:	48 83 c4 18          	add    $0x18,%rsp
    7cfc:	c3                   	ret
    7cfd:	0f 1f 00             	nopl   (%rax)
    7d00:	48 8b 05 b1 ce 01 00 	mov    0x1ceb1(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    7d07:	48 2b 3d 82 ce 01 00 	sub    0x1ce82(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    7d0e:	48 c1 e0 10          	shl    $0x10,%rax
    7d12:	48 39 c7             	cmp    %rax,%rdi
    7d15:	73 e1                	jae    7cf8 <fwp_caps12+0xb8>
    7d17:	48 89 f8             	mov    %rdi,%rax
    7d1a:	48 c1 e8 10          	shr    $0x10,%rax
    7d1e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7d22:	48 8b 05 af ce 01 00 	mov    0x1ceaf(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    7d29:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7d2d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7d31:	48 85 c0             	test   %rax,%rax
    7d34:	74 c2                	je     7cf8 <fwp_caps12+0xb8>
    7d36:	0f b6 0a             	movzbl (%rdx),%ecx
    7d39:	80 f9 02             	cmp    $0x2,%cl
    7d3c:	74 42                	je     7d80 <fwp_caps12+0x140>
    7d3e:	80 f9 01             	cmp    $0x1,%cl
    7d41:	75 b5                	jne    7cf8 <fwp_caps12+0xb8>
    7d43:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d46:	0f b7 ff             	movzwl %di,%edi
    7d49:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d4c:	48 0f af f9          	imul   %rcx,%rdi
    7d50:	48 c1 ef 20          	shr    $0x20,%rdi
    7d54:	48 39 d7             	cmp    %rdx,%rdi
    7d57:	73 9f                	jae    7cf8 <fwp_caps12+0xb8>
    7d59:	48 01 f8             	add    %rdi,%rax
    7d5c:	0f b6 10             	movzbl (%rax),%edx
    7d5f:	84 d2                	test   %dl,%dl
    7d61:	74 95                	je     7cf8 <fwp_caps12+0xb8>
    7d63:	80 fa fd             	cmp    $0xfd,%dl
    7d66:	77 23                	ja     7d8b <fwp_caps12+0x14b>
    7d68:	83 c2 01             	add    $0x1,%edx
    7d6b:	88 10                	mov    %dl,(%rax)
    7d6d:	eb 89                	jmp    7cf8 <fwp_caps12+0xb8>
    7d6f:	90                   	nop
    7d70:	66 85 d2             	test   %dx,%dx
    7d73:	0f 85 7f ff ff ff    	jne    7cf8 <fwp_caps12+0xb8>
    7d79:	e9 58 ff ff ff       	jmp    7cd6 <fwp_caps12+0x96>
    7d7e:	66 90                	xchg   %ax,%ax
    7d80:	66 85 ff             	test   %di,%di
    7d83:	0f 85 6f ff ff ff    	jne    7cf8 <fwp_caps12+0xb8>
    7d89:	eb d1                	jmp    7d5c <fwp_caps12+0x11c>
    7d8b:	48 89 c7             	mov    %rax,%rdi
    7d8e:	48 83 c4 18          	add    $0x18,%rsp
    7d92:	e9 99 d6 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d9e:	00 00 

0000000000007da0 <fwp_drop2>:
    7da0:	48 8b 0d 11 ce 01 00 	mov    0x1ce11(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7da7:	48 89 f8             	mov    %rdi,%rax
    7daa:	48 2b 05 df cd 01 00 	sub    0x1cddf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7db1:	48 c1 e1 10          	shl    $0x10,%rcx
    7db5:	48 39 c8             	cmp    %rcx,%rax
    7db8:	0f 83 42 01 00 00    	jae    7f00 <fwp_drop2+0x160>
    7dbe:	48 83 ec 18          	sub    $0x18,%rsp
    7dc2:	48 89 fa             	mov    %rdi,%rdx
    7dc5:	4c 8d 05 14 ba 01 00 	lea    0x1ba14(%rip),%r8        # 237e0 <fwp_heap>
    7dcc:	48 89 c1             	mov    %rax,%rcx
    7dcf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7dd6:	48 c1 e9 10          	shr    $0x10,%rcx
    7dda:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7dde:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7de2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7de6:	48 85 c9             	test   %rcx,%rcx
    7de9:	74 40                	je     7e2b <fwp_drop2+0x8b>
    7deb:	0f b6 3e             	movzbl (%rsi),%edi
    7dee:	40 80 ff 02          	cmp    $0x2,%dil
    7df2:	74 3c                	je     7e30 <fwp_drop2+0x90>
    7df4:	40 80 ff 01          	cmp    $0x1,%dil
    7df8:	75 31                	jne    7e2b <fwp_drop2+0x8b>
    7dfa:	8b 7e 18             	mov    0x18(%rsi),%edi
    7dfd:	0f b7 c0             	movzwl %ax,%eax
    7e00:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7e03:	48 0f af c7          	imul   %rdi,%rax
    7e07:	48 c1 e8 20          	shr    $0x20,%rax
    7e0b:	48 39 f0             	cmp    %rsi,%rax
    7e0e:	73 1b                	jae    7e2b <fwp_drop2+0x8b>
    7e10:	48 01 c1             	add    %rax,%rcx
    7e13:	0f b6 01             	movzbl (%rcx),%eax
    7e16:	84 c0                	test   %al,%al
    7e18:	74 11                	je     7e2b <fwp_drop2+0x8b>
    7e1a:	3c 01                	cmp    $0x1,%al
    7e1c:	74 22                	je     7e40 <fwp_drop2+0xa0>
    7e1e:	3c ff                	cmp    $0xff,%al
    7e20:	0f 84 0a 01 00 00    	je     7f30 <fwp_drop2+0x190>
    7e26:	83 e8 01             	sub    $0x1,%eax
    7e29:	88 01                	mov    %al,(%rcx)
    7e2b:	48 83 c4 18          	add    $0x18,%rsp
    7e2f:	c3                   	ret
    7e30:	66 85 c0             	test   %ax,%ax
    7e33:	74 de                	je     7e13 <fwp_drop2+0x73>
    7e35:	48 83 c4 18          	add    $0x18,%rsp
    7e39:	c3                   	ret
    7e3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e40:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7e44:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7e4b:	48 89 f8             	mov    %rdi,%rax
    7e4e:	48 c1 e1 10          	shl    $0x10,%rcx
    7e52:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7e59:	48 39 c8             	cmp    %rcx,%rax
    7e5c:	73 62                	jae    7ec0 <fwp_drop2+0x120>
    7e5e:	48 89 c1             	mov    %rax,%rcx
    7e61:	48 c1 e9 10          	shr    $0x10,%rcx
    7e65:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7e69:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7e6d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7e71:	48 85 c9             	test   %rcx,%rcx
    7e74:	74 4a                	je     7ec0 <fwp_drop2+0x120>
    7e76:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7e7a:	41 80 f9 02          	cmp    $0x2,%r9b
    7e7e:	0f 84 9c 00 00 00    	je     7f20 <fwp_drop2+0x180>
    7e84:	41 80 f9 01          	cmp    $0x1,%r9b
    7e88:	75 36                	jne    7ec0 <fwp_drop2+0x120>
    7e8a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7e8e:	0f b7 c0             	movzwl %ax,%eax
    7e91:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7e94:	49 0f af c1          	imul   %r9,%rax
    7e98:	48 c1 e8 20          	shr    $0x20,%rax
    7e9c:	48 39 f0             	cmp    %rsi,%rax
    7e9f:	73 1f                	jae    7ec0 <fwp_drop2+0x120>
    7ea1:	48 01 c1             	add    %rax,%rcx
    7ea4:	0f b6 01             	movzbl (%rcx),%eax
    7ea7:	84 c0                	test   %al,%al
    7ea9:	74 15                	je     7ec0 <fwp_drop2+0x120>
    7eab:	3c 01                	cmp    $0x1,%al
    7ead:	74 59                	je     7f08 <fwp_drop2+0x168>
    7eaf:	3c ff                	cmp    $0xff,%al
    7eb1:	0f 84 ef 00 00 00    	je     7fa6 <fwp_drop2+0x206>
    7eb7:	83 e8 01             	sub    $0x1,%eax
    7eba:	88 01                	mov    %al,(%rcx)
    7ebc:	0f 1f 40 00          	nopl   0x0(%rax)
    7ec0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7ec4:	48 89 d7             	mov    %rdx,%rdi
    7ec7:	48 89 0c 24          	mov    %rcx,(%rsp)
    7ecb:	e8 c0 ea ff ff       	call   6990 <fwp_rc_free_arr>
    7ed0:	4c 8d 05 09 b9 01 00 	lea    0x1b909(%rip),%r8        # 237e0 <fwp_heap>
    7ed7:	48 8b 04 24          	mov    (%rsp),%rax
    7edb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7ee2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7ee9:	48 c1 e2 10          	shl    $0x10,%rdx
    7eed:	48 39 d0             	cmp    %rdx,%rax
    7ef0:	0f 83 35 ff ff ff    	jae    7e2b <fwp_drop2+0x8b>
    7ef6:	48 8b 14 24          	mov    (%rsp),%rdx
    7efa:	e9 cd fe ff ff       	jmp    7dcc <fwp_drop2+0x2c>
    7eff:	90                   	nop
    7f00:	c3                   	ret
    7f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f08:	48 89 14 24          	mov    %rdx,(%rsp)
    7f0c:	e8 7f ea ff ff       	call   6990 <fwp_rc_free_arr>
    7f11:	48 8b 14 24          	mov    (%rsp),%rdx
    7f15:	eb a9                	jmp    7ec0 <fwp_drop2+0x120>
    7f17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f1e:	00 00 
    7f20:	66 85 c0             	test   %ax,%ax
    7f23:	75 9b                	jne    7ec0 <fwp_drop2+0x120>
    7f25:	e9 7a ff ff ff       	jmp    7ea4 <fwp_drop2+0x104>
    7f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f30:	48 89 c8             	mov    %rcx,%rax
    7f33:	48 c1 e8 11          	shr    $0x11,%rax
    7f37:	48 31 c8             	xor    %rcx,%rax
    7f3a:	48 89 c2             	mov    %rax,%rdx
    7f3d:	48 c1 ea 09          	shr    $0x9,%rdx
    7f41:	48 31 d0             	xor    %rdx,%rax
    7f44:	0f b6 d0             	movzbl %al,%edx
    7f47:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7f4e:	00 
    7f4f:	48 85 c0             	test   %rax,%rax
    7f52:	75 19                	jne    7f6d <fwp_drop2+0x1cd>
    7f54:	e9 d3 00 00 00       	jmp    802c <fwp_drop2+0x28c>
    7f59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7f64:	48 85 c0             	test   %rax,%rax
    7f67:	0f 84 bf 00 00 00    	je     802c <fwp_drop2+0x28c>
    7f6d:	48 89 c2             	mov    %rax,%rdx
    7f70:	48 39 08             	cmp    %rcx,(%rax)
    7f73:	75 eb                	jne    7f60 <fwp_drop2+0x1c0>
    7f75:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7f79:	48 83 ea 01          	sub    $0x1,%rdx
    7f7d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7f81:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7f88:	0f 85 9d fe ff ff    	jne    7e2b <fwp_drop2+0x8b>
    7f8e:	48 89 cf             	mov    %rcx,%rdi
    7f91:	48 89 0c 24          	mov    %rcx,(%rsp)
    7f95:	e8 b6 d5 ff ff       	call   5550 <fwp_rc_forget_slot>
    7f9a:	48 8b 0c 24          	mov    (%rsp),%rcx
    7f9e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7fa1:	e9 85 fe ff ff       	jmp    7e2b <fwp_drop2+0x8b>
    7fa6:	48 89 ce             	mov    %rcx,%rsi
    7fa9:	48 c1 ee 11          	shr    $0x11,%rsi
    7fad:	48 31 ce             	xor    %rcx,%rsi
    7fb0:	48 89 f0             	mov    %rsi,%rax
    7fb3:	48 c1 e8 09          	shr    $0x9,%rax
    7fb7:	48 31 c6             	xor    %rax,%rsi
    7fba:	40 0f b6 f6          	movzbl %sil,%esi
    7fbe:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7fc5:	00 
    7fc6:	48 85 c0             	test   %rax,%rax
    7fc9:	75 1e                	jne    7fe9 <fwp_drop2+0x249>
    7fcb:	eb 5f                	jmp    802c <fwp_drop2+0x28c>
    7fcd:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7fd4:	00 
    7fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7fdc:	00 00 00 00 
    7fe0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7fe4:	48 85 c0             	test   %rax,%rax
    7fe7:	74 43                	je     802c <fwp_drop2+0x28c>
    7fe9:	48 89 c6             	mov    %rax,%rsi
    7fec:	48 39 08             	cmp    %rcx,(%rax)
    7fef:	75 ef                	jne    7fe0 <fwp_drop2+0x240>
    7ff1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ff5:	48 83 ee 01          	sub    $0x1,%rsi
    7ff9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7ffd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    8004:	0f 85 b6 fe ff ff    	jne    7ec0 <fwp_drop2+0x120>
    800a:	48 89 cf             	mov    %rcx,%rdi
    800d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8012:	48 89 0c 24          	mov    %rcx,(%rsp)
    8016:	e8 35 d5 ff ff       	call   5550 <fwp_rc_forget_slot>
    801b:	48 8b 0c 24          	mov    (%rsp),%rcx
    801f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8024:	c6 01 fe             	movb   $0xfe,(%rcx)
    8027:	e9 94 fe ff ff       	jmp    7ec0 <fwp_drop2+0x120>
    802c:	48 8d 3d 55 78 00 00 	lea    0x7855(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    8033:	e8 b8 c3 ff ff       	call   43f0 <fwp_trap>
    8038:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    803f:	00 

0000000000008040 <fwp_arg_drop23>:
    8040:	f3 0f 1e fa          	endbr64
    8044:	85 f6                	test   %esi,%esi
    8046:	75 04                	jne    804c <fwp_arg_drop23+0xc>
    8048:	85 d2                	test   %edx,%edx
    804a:	75 04                	jne    8050 <fwp_arg_drop23+0x10>
    804c:	c3                   	ret
    804d:	0f 1f 00             	nopl   (%rax)
    8050:	48 8b 3f             	mov    (%rdi),%rdi
    8053:	e9 48 fd ff ff       	jmp    7da0 <fwp_drop2>
    8058:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    805f:	00 

0000000000008060 <fwp_caps23>:
    8060:	f3 0f 1e fa          	endbr64
    8064:	48 83 ec 18          	sub    $0x18,%rsp
    8068:	8b 57 04             	mov    0x4(%rdi),%edx
    806b:	48 89 f8             	mov    %rdi,%rax
    806e:	85 d2                	test   %edx,%edx
    8070:	0f 84 9a 00 00 00    	je     8110 <fwp_caps23+0xb0>
    8076:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    807a:	85 f6                	test   %esi,%esi
    807c:	0f 85 9e 00 00 00    	jne    8120 <fwp_caps23+0xc0>
    8082:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8087:	e8 14 fd ff ff       	call   7da0 <fwp_drop2>
    808c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8091:	48 8b 0d 20 cb 01 00 	mov    0x1cb20(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    8098:	48 89 c2             	mov    %rax,%rdx
    809b:	48 2b 15 ee ca 01 00 	sub    0x1caee(%rip),%rdx        # 24b90 <fwp_heap+0x13b0>
    80a2:	48 c1 e1 10          	shl    $0x10,%rcx
    80a6:	48 39 ca             	cmp    %rcx,%rdx
    80a9:	73 6d                	jae    8118 <fwp_caps23+0xb8>
    80ab:	48 89 d1             	mov    %rdx,%rcx
    80ae:	48 c1 e9 10          	shr    $0x10,%rcx
    80b2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    80b6:	48 8b 0d 1b cb 01 00 	mov    0x1cb1b(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    80bd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    80c1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    80c5:	48 85 f6             	test   %rsi,%rsi
    80c8:	74 4e                	je     8118 <fwp_caps23+0xb8>
    80ca:	0f b6 39             	movzbl (%rcx),%edi
    80cd:	40 80 ff 02          	cmp    $0x2,%dil
    80d1:	0f 84 b9 00 00 00    	je     8190 <fwp_caps23+0x130>
    80d7:	40 80 ff 01          	cmp    $0x1,%dil
    80db:	75 3b                	jne    8118 <fwp_caps23+0xb8>
    80dd:	8b 79 18             	mov    0x18(%rcx),%edi
    80e0:	0f b7 d2             	movzwl %dx,%edx
    80e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    80e6:	48 0f af d7          	imul   %rdi,%rdx
    80ea:	48 c1 ea 20          	shr    $0x20,%rdx
    80ee:	48 39 ca             	cmp    %rcx,%rdx
    80f1:	73 25                	jae    8118 <fwp_caps23+0xb8>
    80f3:	48 01 d6             	add    %rdx,%rsi
    80f6:	80 3e 01             	cmpb   $0x1,(%rsi)
    80f9:	75 1d                	jne    8118 <fwp_caps23+0xb8>
    80fb:	48 89 c7             	mov    %rax,%rdi
    80fe:	48 83 c4 18          	add    $0x18,%rsp
    8102:	e9 89 d6 ff ff       	jmp    5790 <fwp_mem_free>
    8107:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    810e:	00 00 
    8110:	85 f6                	test   %esi,%esi
    8112:	0f 84 79 ff ff ff    	je     8091 <fwp_caps23+0x31>
    8118:	48 83 c4 18          	add    $0x18,%rsp
    811c:	c3                   	ret
    811d:	0f 1f 00             	nopl   (%rax)
    8120:	48 8b 05 91 ca 01 00 	mov    0x1ca91(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    8127:	48 2b 3d 62 ca 01 00 	sub    0x1ca62(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    812e:	48 c1 e0 10          	shl    $0x10,%rax
    8132:	48 39 c7             	cmp    %rax,%rdi
    8135:	73 e1                	jae    8118 <fwp_caps23+0xb8>
    8137:	48 89 f8             	mov    %rdi,%rax
    813a:	48 c1 e8 10          	shr    $0x10,%rax
    813e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8142:	48 8b 05 8f ca 01 00 	mov    0x1ca8f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    8149:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    814d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8151:	48 85 c0             	test   %rax,%rax
    8154:	74 c2                	je     8118 <fwp_caps23+0xb8>
    8156:	0f b6 0a             	movzbl (%rdx),%ecx
    8159:	80 f9 02             	cmp    $0x2,%cl
    815c:	74 42                	je     81a0 <fwp_caps23+0x140>
    815e:	80 f9 01             	cmp    $0x1,%cl
    8161:	75 b5                	jne    8118 <fwp_caps23+0xb8>
    8163:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8166:	0f b7 ff             	movzwl %di,%edi
    8169:	8b 52 1c             	mov    0x1c(%rdx),%edx
    816c:	48 0f af f9          	imul   %rcx,%rdi
    8170:	48 c1 ef 20          	shr    $0x20,%rdi
    8174:	48 39 d7             	cmp    %rdx,%rdi
    8177:	73 9f                	jae    8118 <fwp_caps23+0xb8>
    8179:	48 01 f8             	add    %rdi,%rax
    817c:	0f b6 10             	movzbl (%rax),%edx
    817f:	84 d2                	test   %dl,%dl
    8181:	74 95                	je     8118 <fwp_caps23+0xb8>
    8183:	80 fa fd             	cmp    $0xfd,%dl
    8186:	77 23                	ja     81ab <fwp_caps23+0x14b>
    8188:	83 c2 01             	add    $0x1,%edx
    818b:	88 10                	mov    %dl,(%rax)
    818d:	eb 89                	jmp    8118 <fwp_caps23+0xb8>
    818f:	90                   	nop
    8190:	66 85 d2             	test   %dx,%dx
    8193:	0f 85 7f ff ff ff    	jne    8118 <fwp_caps23+0xb8>
    8199:	e9 58 ff ff ff       	jmp    80f6 <fwp_caps23+0x96>
    819e:	66 90                	xchg   %ax,%ax
    81a0:	66 85 ff             	test   %di,%di
    81a3:	0f 85 6f ff ff ff    	jne    8118 <fwp_caps23+0xb8>
    81a9:	eb d1                	jmp    817c <fwp_caps23+0x11c>
    81ab:	48 89 c7             	mov    %rax,%rdi
    81ae:	48 83 c4 18          	add    $0x18,%rsp
    81b2:	e9 79 d2 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    81b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81be:	00 00 

00000000000081c0 <f23>:
    81c0:	41 57                	push   %r15
    81c2:	41 56                	push   %r14
    81c4:	41 55                	push   %r13
    81c6:	41 54                	push   %r12
    81c8:	55                   	push   %rbp
    81c9:	53                   	push   %rbx
    81ca:	48 83 ec 38          	sub    $0x38,%rsp
    81ce:	48 8b 15 e3 c9 01 00 	mov    0x1c9e3(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    81d5:	48 8b 0d b4 c9 01 00 	mov    0x1c9b4(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    81dc:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    81e3:	00 00 
    81e5:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    81ea:	49 89 fc             	mov    %rdi,%r12
    81ed:	48 c1 e2 10          	shl    $0x10,%rdx
    81f1:	48 85 ff             	test   %rdi,%rdi
    81f4:	0f 84 bc 02 00 00    	je     84b6 <f23+0x2f6>
    81fa:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    81ff:	48 89 d8             	mov    %rbx,%rax
    8202:	48 29 c8             	sub    %rcx,%rax
    8205:	48 39 d0             	cmp    %rdx,%rax
    8208:	0f 83 72 03 00 00    	jae    8580 <f23+0x3c0>
    820e:	48 89 c2             	mov    %rax,%rdx
    8211:	48 c1 ea 10          	shr    $0x10,%rdx
    8215:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8219:	48 8b 15 b8 c9 01 00 	mov    0x1c9b8(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8220:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8224:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8228:	48 85 ff             	test   %rdi,%rdi
    822b:	0f 84 4f 03 00 00    	je     8580 <f23+0x3c0>
    8231:	0f b6 0a             	movzbl (%rdx),%ecx
    8234:	80 f9 02             	cmp    $0x2,%cl
    8237:	0f 84 53 02 00 00    	je     8490 <f23+0x2d0>
    823d:	80 f9 01             	cmp    $0x1,%cl
    8240:	75 24                	jne    8266 <f23+0xa6>
    8242:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8245:	0f b7 c0             	movzwl %ax,%eax
    8248:	8b 52 1c             	mov    0x1c(%rdx),%edx
    824b:	48 0f af c1          	imul   %rcx,%rax
    824f:	48 c1 e8 20          	shr    $0x20,%rax
    8253:	48 39 d0             	cmp    %rdx,%rax
    8256:	73 0e                	jae    8266 <f23+0xa6>
    8258:	48 01 c7             	add    %rax,%rdi
    825b:	0f b6 07             	movzbl (%rdi),%eax
    825e:	84 c0                	test   %al,%al
    8260:	0f 85 ca 02 00 00    	jne    8530 <f23+0x370>
    8266:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    826b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    8270:	ba 01 00 00 00       	mov    $0x1,%edx
    8275:	48 85 db             	test   %rbx,%rbx
    8278:	74 13                	je     828d <f23+0xcd>
    827a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8280:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8284:	48 83 c2 01          	add    $0x1,%rdx
    8288:	48 85 db             	test   %rbx,%rbx
    828b:	75 f3                	jne    8280 <f23+0xc0>
    828d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8292:	48 85 c0             	test   %rax,%rax
    8295:	0f 84 15 03 00 00    	je     85b0 <f23+0x3f0>
    829b:	31 db                	xor    %ebx,%ebx
    829d:	0f 1f 00             	nopl   (%rax)
    82a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    82a4:	48 83 c3 01          	add    $0x1,%rbx
    82a8:	48 85 c0             	test   %rax,%rax
    82ab:	75 f3                	jne    82a0 <f23+0xe0>
    82ad:	48 39 d3             	cmp    %rdx,%rbx
    82b0:	48 0f 47 da          	cmova  %rdx,%rbx
    82b4:	48 89 d8             	mov    %rbx,%rax
    82b7:	48 c1 e8 3c          	shr    $0x3c,%rax
    82bb:	0f 85 8f 03 00 00    	jne    8650 <f23+0x490>
    82c1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    82c5:	be 02 00 00 00       	mov    $0x2,%esi
    82ca:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    82d1:	00 
    82d2:	e8 b9 d9 ff ff       	call   5c90 <fwp_heap_alloc>
    82d7:	48 89 28             	mov    %rbp,(%rax)
    82da:	48 8b 15 d7 c8 01 00 	mov    0x1c8d7(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    82e1:	49 89 c6             	mov    %rax,%r14
    82e4:	48 2b 05 a5 c8 01 00 	sub    0x1c8a5(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    82eb:	48 c1 e2 10          	shl    $0x10,%rdx
    82ef:	48 39 d0             	cmp    %rdx,%rax
    82f2:	73 57                	jae    834b <f23+0x18b>
    82f4:	48 89 c2             	mov    %rax,%rdx
    82f7:	48 c1 ea 10          	shr    $0x10,%rdx
    82fb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82ff:	48 8b 15 d2 c8 01 00 	mov    0x1c8d2(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8306:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    830a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    830e:	48 85 ed             	test   %rbp,%rbp
    8311:	74 38                	je     834b <f23+0x18b>
    8313:	0f b6 0a             	movzbl (%rdx),%ecx
    8316:	80 f9 02             	cmp    $0x2,%cl
    8319:	0f 84 51 02 00 00    	je     8570 <f23+0x3b0>
    831f:	80 f9 01             	cmp    $0x1,%cl
    8322:	75 27                	jne    834b <f23+0x18b>
    8324:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8327:	0f b7 c0             	movzwl %ax,%eax
    832a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    832d:	48 0f af c1          	imul   %rcx,%rax
    8331:	48 c1 e8 20          	shr    $0x20,%rax
    8335:	48 39 d0             	cmp    %rdx,%rax
    8338:	73 11                	jae    834b <f23+0x18b>
    833a:	48 01 c5             	add    %rax,%rbp
    833d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8341:	0f 84 d5 02 00 00    	je     861c <f23+0x45c>
    8347:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    834b:	48 85 db             	test   %rbx,%rbx
    834e:	74 5d                	je     83ad <f23+0x1ed>
    8350:	48 c1 e3 04          	shl    $0x4,%rbx
    8354:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    8359:	4c 89 f5             	mov    %r14,%rbp
    835c:	4d 89 e5             	mov    %r12,%r13
    835f:	4c 01 f3             	add    %r14,%rbx
    8362:	0f 1f 00             	nopl   (%rax)
    8365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    836c:	00 00 00 00 
    8370:	49 8b 45 08          	mov    0x8(%r13),%rax
    8374:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8378:	48 83 c5 10          	add    $0x10,%rbp
    837c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8381:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8385:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8389:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    838e:	e8 5d e1 ff ff       	call   64f0 <w107>
    8393:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8398:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    839c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    83a0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    83a4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    83a8:	48 39 dd             	cmp    %rbx,%rbp
    83ab:	75 c3                	jne    8370 <f23+0x1b0>
    83ad:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    83b2:	e8 e9 f9 ff ff       	call   7da0 <fwp_drop2>
    83b7:	4c 89 e7             	mov    %r12,%rdi
    83ba:	e8 e1 f9 ff ff       	call   7da0 <fwp_drop2>
    83bf:	4c 89 f7             	mov    %r14,%rdi
    83c2:	e8 e9 e2 ff ff       	call   66b0 <w164.constprop.0>
    83c7:	4c 89 f7             	mov    %r14,%rdi
    83ca:	48 89 c3             	mov    %rax,%rbx
    83cd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    83d3:	e8 c8 f4 ff ff       	call   78a0 <fwp_drop4>
    83d8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    83de:	66 48 0f 6e db       	movq   %rbx,%xmm3
    83e3:	31 ff                	xor    %edi,%edi
    83e5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    83ea:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    83ee:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    83f3:	e8 38 e3 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    83f8:	48 8b 15 b9 c7 01 00 	mov    0x1c7b9(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    83ff:	48 89 c5             	mov    %rax,%rbp
    8402:	48 2b 05 87 c7 01 00 	sub    0x1c787(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8409:	48 c1 e2 10          	shl    $0x10,%rdx
    840d:	48 39 d0             	cmp    %rdx,%rax
    8410:	73 55                	jae    8467 <f23+0x2a7>
    8412:	48 89 c2             	mov    %rax,%rdx
    8415:	48 c1 ea 10          	shr    $0x10,%rdx
    8419:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    841d:	48 8b 15 b4 c7 01 00 	mov    0x1c7b4(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8424:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8428:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    842c:	48 85 db             	test   %rbx,%rbx
    842f:	74 36                	je     8467 <f23+0x2a7>
    8431:	0f b6 0a             	movzbl (%rdx),%ecx
    8434:	80 f9 02             	cmp    $0x2,%cl
    8437:	0f 84 1b 01 00 00    	je     8558 <f23+0x398>
    843d:	80 f9 01             	cmp    $0x1,%cl
    8440:	75 25                	jne    8467 <f23+0x2a7>
    8442:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8445:	0f b7 c0             	movzwl %ax,%eax
    8448:	8b 52 1c             	mov    0x1c(%rdx),%edx
    844b:	48 0f af c1          	imul   %rcx,%rax
    844f:	48 c1 e8 20          	shr    $0x20,%rax
    8453:	48 39 d0             	cmp    %rdx,%rax
    8456:	73 0f                	jae    8467 <f23+0x2a7>
    8458:	48 01 c3             	add    %rax,%rbx
    845b:	80 3b ff             	cmpb   $0xff,(%rbx)
    845e:	0f 84 ab 01 00 00    	je     860f <f23+0x44f>
    8464:	c6 03 01             	movb   $0x1,(%rbx)
    8467:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    846c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8473:	00 00 
    8475:	0f 85 d0 01 00 00    	jne    864b <f23+0x48b>
    847b:	48 83 c4 38          	add    $0x38,%rsp
    847f:	48 89 e8             	mov    %rbp,%rax
    8482:	5b                   	pop    %rbx
    8483:	5d                   	pop    %rbp
    8484:	41 5c                	pop    %r12
    8486:	41 5d                	pop    %r13
    8488:	41 5e                	pop    %r14
    848a:	41 5f                	pop    %r15
    848c:	c3                   	ret
    848d:	0f 1f 00             	nopl   (%rax)
    8490:	66 85 c0             	test   %ax,%ax
    8493:	0f 85 cd fd ff ff    	jne    8266 <f23+0xa6>
    8499:	0f b6 07             	movzbl (%rdi),%eax
    849c:	84 c0                	test   %al,%al
    849e:	0f 84 c2 fd ff ff    	je     8266 <f23+0xa6>
    84a4:	3c fd                	cmp    $0xfd,%al
    84a6:	0f 87 95 01 00 00    	ja     8641 <f23+0x481>
    84ac:	83 c0 01             	add    $0x1,%eax
    84af:	88 07                	mov    %al,(%rdi)
    84b1:	e9 b0 fd ff ff       	jmp    8266 <f23+0xa6>
    84b6:	48 f7 d9             	neg    %rcx
    84b9:	48 39 d1             	cmp    %rdx,%rcx
    84bc:	0f 83 ee 00 00 00    	jae    85b0 <f23+0x3f0>
    84c2:	48 89 c8             	mov    %rcx,%rax
    84c5:	48 c1 e8 10          	shr    $0x10,%rax
    84c9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    84cd:	48 8b 05 04 c7 01 00 	mov    0x1c704(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    84d4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    84d8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    84dc:	48 85 ff             	test   %rdi,%rdi
    84df:	0f 84 cb 00 00 00    	je     85b0 <f23+0x3f0>
    84e5:	0f b6 02             	movzbl (%rdx),%eax
    84e8:	3c 02                	cmp    $0x2,%al
    84ea:	0f 84 9a 00 00 00    	je     858a <f23+0x3ca>
    84f0:	3c 01                	cmp    $0x1,%al
    84f2:	0f 85 b8 00 00 00    	jne    85b0 <f23+0x3f0>
    84f8:	0f b7 c1             	movzwl %cx,%eax
    84fb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8501:	48 0f af c1          	imul   %rcx,%rax
    8505:	48 c1 e8 20          	shr    $0x20,%rax
    8509:	48 39 d0             	cmp    %rdx,%rax
    850c:	0f 83 9e 00 00 00    	jae    85b0 <f23+0x3f0>
    8512:	48 01 c7             	add    %rax,%rdi
    8515:	0f b6 07             	movzbl (%rdi),%eax
    8518:	84 c0                	test   %al,%al
    851a:	0f 84 90 00 00 00    	je     85b0 <f23+0x3f0>
    8520:	31 db                	xor    %ebx,%ebx
    8522:	0f 1f 00             	nopl   (%rax)
    8525:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    852c:	00 00 00 00 
    8530:	3c fd                	cmp    $0xfd,%al
    8532:	0f 87 f1 00 00 00    	ja     8629 <f23+0x469>
    8538:	83 c0 01             	add    $0x1,%eax
    853b:	88 07                	mov    %al,(%rdi)
    853d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8542:	31 d2                	xor    %edx,%edx
    8544:	4d 85 e4             	test   %r12,%r12
    8547:	0f 85 1e fd ff ff    	jne    826b <f23+0xab>
    854d:	e9 3b fd ff ff       	jmp    828d <f23+0xcd>
    8552:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8558:	66 85 c0             	test   %ax,%ax
    855b:	0f 85 06 ff ff ff    	jne    8467 <f23+0x2a7>
    8561:	e9 f5 fe ff ff       	jmp    845b <f23+0x29b>
    8566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    856d:	00 00 00 
    8570:	66 85 c0             	test   %ax,%ax
    8573:	0f 85 d2 fd ff ff    	jne    834b <f23+0x18b>
    8579:	e9 bf fd ff ff       	jmp    833d <f23+0x17d>
    857e:	66 90                	xchg   %ax,%ax
    8580:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8585:	e9 e6 fc ff ff       	jmp    8270 <f23+0xb0>
    858a:	66 85 c9             	test   %cx,%cx
    858d:	75 21                	jne    85b0 <f23+0x3f0>
    858f:	0f b6 07             	movzbl (%rdi),%eax
    8592:	84 c0                	test   %al,%al
    8594:	74 1a                	je     85b0 <f23+0x3f0>
    8596:	3c fd                	cmp    $0xfd,%al
    8598:	0f 87 be 00 00 00    	ja     865c <f23+0x49c>
    859e:	83 c0 01             	add    $0x1,%eax
    85a1:	88 07                	mov    %al,(%rdi)
    85a3:	66 90                	xchg   %ax,%ax
    85a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    85ac:	00 00 00 00 
    85b0:	be 02 00 00 00       	mov    $0x2,%esi
    85b5:	bf 08 00 00 00       	mov    $0x8,%edi
    85ba:	e8 d1 d6 ff ff       	call   5c90 <fwp_heap_alloc>
    85bf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    85c6:	48 8b 15 eb c5 01 00 	mov    0x1c5eb(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    85cd:	49 89 c6             	mov    %rax,%r14
    85d0:	48 2b 05 b9 c5 01 00 	sub    0x1c5b9(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    85d7:	48 c1 e2 10          	shl    $0x10,%rdx
    85db:	48 39 d0             	cmp    %rdx,%rax
    85de:	73 53                	jae    8633 <f23+0x473>
    85e0:	48 89 c2             	mov    %rax,%rdx
    85e3:	48 c1 ea 10          	shr    $0x10,%rdx
    85e7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85eb:	48 8b 15 e6 c5 01 00 	mov    0x1c5e6(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    85f2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85f6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    85fa:	48 85 ed             	test   %rbp,%rbp
    85fd:	74 34                	je     8633 <f23+0x473>
    85ff:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8606:	00 00 
    8608:	31 db                	xor    %ebx,%ebx
    860a:	e9 04 fd ff ff       	jmp    8313 <f23+0x153>
    860f:	48 89 df             	mov    %rbx,%rdi
    8612:	e8 39 cf ff ff       	call   5550 <fwp_rc_forget_slot>
    8617:	e9 48 fe ff ff       	jmp    8464 <f23+0x2a4>
    861c:	48 89 ef             	mov    %rbp,%rdi
    861f:	e8 2c cf ff ff       	call   5550 <fwp_rc_forget_slot>
    8624:	e9 1e fd ff ff       	jmp    8347 <f23+0x187>
    8629:	e8 02 ce ff ff       	call   5430 <fwp_rc_wide_dup>
    862e:	e9 0a ff ff ff       	jmp    853d <f23+0x37d>
    8633:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    863a:	00 00 
    863c:	e9 6c fd ff ff       	jmp    83ad <f23+0x1ed>
    8641:	e8 ea cd ff ff       	call   5430 <fwp_rc_wide_dup>
    8646:	e9 1b fc ff ff       	jmp    8266 <f23+0xa6>
    864b:	e8 10 ae ff ff       	call   3460 <__stack_chk_fail@plt>
    8650:	48 8d 3d 39 6b 00 00 	lea    0x6b39(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    8657:	e8 94 bd ff ff       	call   43f0 <fwp_trap>
    865c:	e8 cf cd ff ff       	call   5430 <fwp_rc_wide_dup>
    8661:	e9 4a ff ff ff       	jmp    85b0 <f23+0x3f0>
    8666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    866d:	00 00 00 

0000000000008670 <fwp_owned_entry23>:
    8670:	f3 0f 1e fa          	endbr64
    8674:	48 8b 3f             	mov    (%rdi),%rdi
    8677:	e9 44 fb ff ff       	jmp    81c0 <f23>
    867c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008680 <e23>:
    8680:	f3 0f 1e fa          	endbr64
    8684:	53                   	push   %rbx
    8685:	48 8b 1f             	mov    (%rdi),%rbx
    8688:	48 89 df             	mov    %rbx,%rdi
    868b:	e8 d0 e1 ff ff       	call   6860 <fwp_rc_share>
    8690:	48 89 df             	mov    %rbx,%rdi
    8693:	e8 28 fb ff ff       	call   81c0 <f23>
    8698:	48 89 c3             	mov    %rax,%rbx
    869b:	48 89 c7             	mov    %rax,%rdi
    869e:	e8 bd e1 ff ff       	call   6860 <fwp_rc_share>
    86a3:	48 89 d8             	mov    %rbx,%rax
    86a6:	5b                   	pop    %rbx
    86a7:	c3                   	ret
    86a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    86af:	00 

00000000000086b0 <f12>:
    86b0:	41 57                	push   %r15
    86b2:	41 56                	push   %r14
    86b4:	41 55                	push   %r13
    86b6:	4c 8d 2d 03 ec ff ff 	lea    -0x13fd(%rip),%r13        # 72c0 <fwp_tape_scope_release>
    86bd:	41 54                	push   %r12
    86bf:	55                   	push   %rbp
    86c0:	53                   	push   %rbx
    86c1:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    86c8:	48 8b 05 a9 cd 01 00 	mov    0x1cda9(%rip),%rax        # 25478 <fwp_cleanups>
    86cf:	48 8b 15 e2 c4 01 00 	mov    0x1c4e2(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    86d6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    86dd:	00 00 
    86df:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    86e6:	00 
    86e7:	48 89 fd             	mov    %rdi,%rbp
    86ea:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    86f1:	ff 
    86f2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    86f7:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    86fc:	48 c1 e2 10          	shl    $0x10,%rdx
    8700:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    8705:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    870a:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    870f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    8714:	48 89 05 5d cd 01 00 	mov    %rax,0x1cd5d(%rip)        # 25478 <fwp_cleanups>
    871b:	48 8d 05 ee a8 00 00 	lea    0xa8ee(%rip),%rax        # 13010 <fc23>
    8722:	48 2b 05 67 c4 01 00 	sub    0x1c467(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8729:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    872e:	48 39 d0             	cmp    %rdx,%rax
    8731:	73 5d                	jae    8790 <f12+0xe0>
    8733:	48 89 c2             	mov    %rax,%rdx
    8736:	48 c1 ea 10          	shr    $0x10,%rdx
    873a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    873e:	48 8b 15 93 c4 01 00 	mov    0x1c493(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8745:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8749:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    874d:	48 85 ff             	test   %rdi,%rdi
    8750:	74 3e                	je     8790 <f12+0xe0>
    8752:	0f b6 0a             	movzbl (%rdx),%ecx
    8755:	80 f9 02             	cmp    $0x2,%cl
    8758:	0f 84 1a 0f 00 00    	je     9678 <f12+0xfc8>
    875e:	80 f9 01             	cmp    $0x1,%cl
    8761:	75 2d                	jne    8790 <f12+0xe0>
    8763:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8766:	0f b7 c0             	movzwl %ax,%eax
    8769:	8b 52 1c             	mov    0x1c(%rdx),%edx
    876c:	48 0f af c1          	imul   %rcx,%rax
    8770:	48 c1 e8 20          	shr    $0x20,%rax
    8774:	48 39 d0             	cmp    %rdx,%rax
    8777:	73 17                	jae    8790 <f12+0xe0>
    8779:	48 01 c7             	add    %rax,%rdi
    877c:	0f b6 07             	movzbl (%rdi),%eax
    877f:	84 c0                	test   %al,%al
    8781:	74 0d                	je     8790 <f12+0xe0>
    8783:	3c fd                	cmp    $0xfd,%al
    8785:	0f 87 63 11 00 00    	ja     98ee <f12+0x123e>
    878b:	83 c0 01             	add    $0x1,%eax
    878e:	88 07                	mov    %al,(%rdi)
    8790:	48 8d 3d 79 a8 00 00 	lea    0xa879(%rip),%rdi        # 13010 <fc23>
    8797:	e8 f4 e7 ff ff       	call   6f90 <fwp_closure_drop>
    879c:	48 85 ed             	test   %rbp,%rbp
    879f:	0f 84 aa 10 00 00    	je     984f <f12+0x119f>
    87a5:	48 89 e8             	mov    %rbp,%rax
    87a8:	31 db                	xor    %ebx,%ebx
    87aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    87b4:	48 83 c3 01          	add    $0x1,%rbx
    87b8:	48 85 c0             	test   %rax,%rax
    87bb:	75 f3                	jne    87b0 <f12+0x100>
    87bd:	31 ff                	xor    %edi,%edi
    87bf:	e8 8c ba ff ff       	call   4250 <descent_phase_step>
    87c4:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    87cb:	0f 87 95 11 00 00    	ja     9966 <f12+0x12b6>
    87d1:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    87d6:	8b 35 a4 a8 00 00    	mov    0xa8a4(%rip),%esi        # 13080 <registered_finish.0>
    87dc:	85 f6                	test   %esi,%esi
    87de:	0f 84 64 0e 00 00    	je     9648 <f12+0xf98>
    87e4:	48 8b 1d 0d a9 01 00 	mov    0x1a90d(%rip),%rbx        # 230f8 <fwp_tape_next_slot>
    87eb:	4c 8b 25 16 a9 01 00 	mov    0x1a916(%rip),%r12        # 23108 <fwp_ntapes>
    87f2:	4c 39 e3             	cmp    %r12,%rbx
    87f5:	0f 8d b5 05 00 00    	jge    8db0 <f12+0x700>
    87fb:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    87ff:	48 03 05 0a a9 01 00 	add    0x1a90a(%rip),%rax        # 23110 <fwp_tapes>
    8806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    880d:	00 00 00 
    8810:	8b 48 04             	mov    0x4(%rax),%ecx
    8813:	85 c9                	test   %ecx,%ecx
    8815:	75 0c                	jne    8823 <f12+0x173>
    8817:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    881d:	0f 86 8d 05 00 00    	jbe    8db0 <f12+0x700>
    8823:	48 83 c3 01          	add    $0x1,%rbx
    8827:	48 83 c0 68          	add    $0x68,%rax
    882b:	4c 39 e3             	cmp    %r12,%rbx
    882e:	75 e0                	jne    8810 <f12+0x160>
    8830:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    8837:	0f 8f 4d 11 00 00    	jg     998a <f12+0x12da>
    883d:	4c 39 25 bc a8 01 00 	cmp    %r12,0x1a8bc(%rip)        # 23100 <fwp_tapes_cap>
    8844:	4c 8b 35 c5 a8 01 00 	mov    0x1a8c5(%rip),%r14        # 23110 <fwp_tapes>
    884b:	75 40                	jne    888d <f12+0x1dd>
    884d:	4d 85 e4             	test   %r12,%r12
    8850:	0f 85 92 0f 00 00    	jne    97e8 <f12+0x1138>
    8856:	be 68 00 00 00       	mov    $0x68,%esi
    885b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    8861:	4c 89 f7             	mov    %r14,%rdi
    8864:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8869:	e8 62 ad ff ff       	call   35d0 <realloc@plt>
    886e:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8873:	48 85 c0             	test   %rax,%rax
    8876:	49 89 c6             	mov    %rax,%r14
    8879:	0f 84 46 0e 00 00    	je     96c5 <f12+0x1015>
    887f:	48 89 05 8a a8 01 00 	mov    %rax,0x1a88a(%rip)        # 23110 <fwp_tapes>
    8886:	4c 89 3d 73 a8 01 00 	mov    %r15,0x1a873(%rip)        # 23100 <fwp_tapes_cap>
    888d:	49 6b c4 68          	imul   $0x68,%r12,%rax
    8891:	49 83 c4 01          	add    $0x1,%r12
    8895:	4c 01 f0             	add    %r14,%rax
    8898:	48 8d 78 08          	lea    0x8(%rax),%rdi
    889c:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    88a3:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    88a7:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    88ae:	00 
    88af:	48 29 f8             	sub    %rdi,%rax
    88b2:	8d 48 68             	lea    0x68(%rax),%ecx
    88b5:	31 c0                	xor    %eax,%eax
    88b7:	c1 e9 03             	shr    $0x3,%ecx
    88ba:	f3 48 ab             	rep stos %rax,(%rdi)
    88bd:	4c 89 25 44 a8 01 00 	mov    %r12,0x1a844(%rip)        # 23108 <fwp_ntapes>
    88c4:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    88c8:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    88cc:	48 8d 3d 4f 68 00 00 	lea    0x684f(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    88d3:	0f 29 04 24          	movaps %xmm0,(%rsp)
    88d7:	4d 01 f4             	add    %r14,%r12
    88da:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    88e1:	00 00 
    88e3:	e8 b8 aa ff ff       	call   33a0 <getenv@plt>
    88e8:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    88ed:	48 85 c0             	test   %rax,%rax
    88f0:	74 09                	je     88fb <f12+0x24b>
    88f2:	80 38 30             	cmpb   $0x30,(%rax)
    88f5:	0f 84 05 04 00 00    	je     8d00 <f12+0x650>
    88fb:	48 83 3d a5 a7 01 00 	cmpq   $0x0,0x1a7a5(%rip)        # 230a8 <fwp_tape_cached_bytes>
    8902:	00 
    8903:	0f 85 17 0e 00 00    	jne    9720 <f12+0x1070>
    8909:	41 8b 04 24          	mov    (%r12),%eax
    890d:	4c 8d 43 01          	lea    0x1(%rbx),%r8
    8911:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    8918:	00 00 
    891a:	4c 89 05 d7 a7 01 00 	mov    %r8,0x1a7d7(%rip)        # 230f8 <fwp_tape_next_slot>
    8921:	8d 70 01             	lea    0x1(%rax),%esi
    8924:	48 8b 05 4d cb 01 00 	mov    0x1cb4d(%rip),%rax        # 25478 <fwp_cleanups>
    892b:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    8932:	00 00 
    8934:	41 89 34 24          	mov    %esi,(%r12)
    8938:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    893f:	ff ff 
    8941:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    8947:	48 85 c0             	test   %rax,%rax
    894a:	75 20                	jne    896c <f12+0x2bc>
    894c:	e9 56 10 00 00       	jmp    99a7 <f12+0x12f7>
    8951:	0f 1f 40 00          	nopl   0x0(%rax)
    8955:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    895c:	00 00 00 00 
    8960:	48 8b 00             	mov    (%rax),%rax
    8963:	48 85 c0             	test   %rax,%rax
    8966:	0f 84 3b 10 00 00    	je     99a7 <f12+0x12f7>
    896c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8970:	75 ee                	jne    8960 <f12+0x2b0>
    8972:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8976:	89 df                	mov    %ebx,%edi
    8978:	48 63 01             	movslq (%rcx),%rax
    897b:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    8980:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8985:	85 c0                	test   %eax,%eax
    8987:	78 09                	js     8992 <f12+0x2e2>
    8989:	48 6b c0 68          	imul   $0x68,%rax,%rax
    898d:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8992:	89 39                	mov    %edi,(%rcx)
    8994:	bf 01 00 00 00       	mov    $0x1,%edi
    8999:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    899e:	89 34 24             	mov    %esi,(%rsp)
    89a1:	e8 aa b8 ff ff       	call   4250 <descent_phase_step>
    89a6:	31 c9                	xor    %ecx,%ecx
    89a8:	48 85 ed             	test   %rbp,%rbp
    89ab:	8b 34 24             	mov    (%rsp),%esi
    89ae:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    89b3:	48 89 e8             	mov    %rbp,%rax
    89b6:	0f 84 54 03 00 00    	je     8d10 <f12+0x660>
    89bc:	0f 1f 40 00          	nopl   0x0(%rax)
    89c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    89c4:	48 83 c1 01          	add    $0x1,%rcx
    89c8:	48 85 c0             	test   %rax,%rax
    89cb:	75 f3                	jne    89c0 <f12+0x310>
    89cd:	48 89 ea             	mov    %rbp,%rdx
    89d0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    89d4:	48 83 c0 01          	add    $0x1,%rax
    89d8:	48 85 d2             	test   %rdx,%rdx
    89db:	75 f3                	jne    89d0 <f12+0x320>
    89dd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    89e4:	ff ff 1f 
    89e7:	48 39 c2             	cmp    %rax,%rdx
    89ea:	0f 82 82 0f 00 00    	jb     9972 <f12+0x12c2>
    89f0:	48 85 c9             	test   %rcx,%rcx
    89f3:	0f 8e 17 03 00 00    	jle    8d10 <f12+0x660>
    89f9:	48 39 c1             	cmp    %rax,%rcx
    89fc:	48 0f 46 c1          	cmovbe %rcx,%rax
    8a00:	49 89 c5             	mov    %rax,%r13
    8a03:	48 c1 e8 3c          	shr    $0x3c,%rax
    8a07:	0f 85 65 0f 00 00    	jne    9972 <f12+0x12c2>
    8a0d:	48 c1 e6 10          	shl    $0x10,%rsi
    8a11:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    8a16:	4c 09 c6             	or     %r8,%rsi
    8a19:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8a20:	00 
    8a21:	49 89 f4             	mov    %rsi,%r12
    8a24:	be 02 00 00 00       	mov    $0x2,%esi
    8a29:	e8 62 d2 ff ff       	call   5c90 <fwp_heap_alloc>
    8a2e:	4c 89 30             	mov    %r14,(%rax)
    8a31:	48 8b 15 80 c1 01 00 	mov    0x1c180(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8a38:	48 89 c3             	mov    %rax,%rbx
    8a3b:	48 2b 05 4e c1 01 00 	sub    0x1c14e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8a42:	48 c1 e2 10          	shl    $0x10,%rdx
    8a46:	48 39 d0             	cmp    %rdx,%rax
    8a49:	0f 83 41 03 00 00    	jae    8d90 <f12+0x6e0>
    8a4f:	48 89 c2             	mov    %rax,%rdx
    8a52:	48 c1 ea 10          	shr    $0x10,%rdx
    8a56:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a5a:	48 8b 15 77 c1 01 00 	mov    0x1c177(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8a61:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8a65:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8a69:	48 85 d2             	test   %rdx,%rdx
    8a6c:	74 38                	je     8aa6 <f12+0x3f6>
    8a6e:	0f b6 31             	movzbl (%rcx),%esi
    8a71:	40 80 fe 02          	cmp    $0x2,%sil
    8a75:	0f 84 02 03 00 00    	je     8d7d <f12+0x6cd>
    8a7b:	40 80 fe 01          	cmp    $0x1,%sil
    8a7f:	75 25                	jne    8aa6 <f12+0x3f6>
    8a81:	8b 71 18             	mov    0x18(%rcx),%esi
    8a84:	0f b7 c0             	movzwl %ax,%eax
    8a87:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8a8a:	48 0f af c6          	imul   %rsi,%rax
    8a8e:	48 c1 e8 20          	shr    $0x20,%rax
    8a92:	48 39 c8             	cmp    %rcx,%rax
    8a95:	73 0f                	jae    8aa6 <f12+0x3f6>
    8a97:	48 01 c2             	add    %rax,%rdx
    8a9a:	80 3a ff             	cmpb   $0xff,(%rdx)
    8a9d:	0f 84 14 0e 00 00    	je     98b7 <f12+0x1207>
    8aa3:	c6 02 01             	movb   $0x1,(%rdx)
    8aa6:	4d 85 ed             	test   %r13,%r13
    8aa9:	74 48                	je     8af3 <f12+0x443>
    8aab:	4c 89 e1             	mov    %r12,%rcx
    8aae:	48 89 ea             	mov    %rbp,%rdx
    8ab1:	31 c0                	xor    %eax,%eax
    8ab3:	48 c1 e1 20          	shl    $0x20,%rcx
    8ab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8abe:	00 00 
    8ac0:	48 89 c6             	mov    %rax,%rsi
    8ac3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8ac8:	48 01 ce             	add    %rcx,%rsi
    8acb:	0f 80 88 0e 00 00    	jo     9959 <f12+0x12a9>
    8ad1:	66 48 0f 6e de       	movq   %rsi,%xmm3
    8ad6:	48 89 c6             	mov    %rax,%rsi
    8ad9:	48 83 c0 01          	add    $0x1,%rax
    8add:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    8ae1:	48 c1 e6 04          	shl    $0x4,%rsi
    8ae5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    8aea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8aee:	4c 39 e8             	cmp    %r13,%rax
    8af1:	72 cd                	jb     8ac0 <f12+0x410>
    8af3:	48 8b 03             	mov    (%rbx),%rax
    8af6:	48 d1 e8             	shr    $1,%rax
    8af9:	0f 84 a1 02 00 00    	je     8da0 <f12+0x6f0>
    8aff:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8b03:	48 89 d1             	mov    %rdx,%rcx
    8b06:	48 c1 e9 3c          	shr    $0x3c,%rcx
    8b0a:	0f 85 62 0e 00 00    	jne    9972 <f12+0x12c2>
    8b10:	4c 8d 34 12          	lea    (%rdx,%rdx,1),%r14
    8b14:	48 85 d2             	test   %rdx,%rdx
    8b17:	74 45                	je     8b5e <f12+0x4ae>
    8b19:	48 c1 e0 04          	shl    $0x4,%rax
    8b1d:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    8b21:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    8b26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b2d:	00 00 00 
    8b30:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    8b35:	49 8b 77 18          	mov    0x18(%r15),%rsi
    8b39:	49 83 c7 10          	add    $0x10,%r15
    8b3d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    8b41:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    8b46:	e8 a5 d9 ff ff       	call   64f0 <w107>
    8b4b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    8b50:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8b54:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    8b59:	4d 39 fd             	cmp    %r15,%r13
    8b5c:	75 d2                	jne    8b30 <f12+0x480>
    8b5e:	4c 89 33             	mov    %r14,(%rbx)
    8b61:	48 89 df             	mov    %rbx,%rdi
    8b64:	e8 47 db ff ff       	call   66b0 <w164.constprop.0>
    8b69:	48 89 df             	mov    %rbx,%rdi
    8b6c:	49 63 dc             	movslq %r12d,%rbx
    8b6f:	49 89 c5             	mov    %rax,%r13
    8b72:	e8 29 ed ff ff       	call   78a0 <fwp_drop4>
    8b77:	bf 02 00 00 00       	mov    $0x2,%edi
    8b7c:	e8 cf b6 ff ff       	call   4250 <descent_phase_step>
    8b81:	48 89 df             	mov    %rbx,%rdi
    8b84:	e8 47 bb ff ff       	call   46d0 <fwp_tape_of>
    8b89:	48 89 c6             	mov    %rax,%rsi
    8b8c:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8b91:	0f 85 ff 0d 00 00    	jne    9996 <f12+0x12e6>
    8b97:	48 89 c7             	mov    %rax,%rdi
    8b9a:	e8 61 b0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8b9f:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    8ba4:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    8ba8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8baf:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    8bb4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8bb9:	0f 29 74 24 10       	movaps %xmm6,0x10(%rsp)
    8bbe:	66 48 0f 6e f2       	movq   %rdx,%xmm6
    8bc3:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    8bc7:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    8bcb:	4c 8b 7e 40          	mov    0x40(%rsi),%r15
    8bcf:	0f 29 3c 24          	movaps %xmm7,(%rsp)
    8bd3:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8bd7:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8bdd:	77 19                	ja     8bf8 <f12+0x548>
    8bdf:	41 0f b7 c4          	movzwl %r12w,%eax
    8be3:	83 e8 01             	sub    $0x1,%eax
    8be6:	48 98                	cltq
    8be8:	48 3b 05 09 a5 01 00 	cmp    0x1a509(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    8bef:	7d 07                	jge    8bf8 <f12+0x548>
    8bf1:	48 89 05 00 a5 01 00 	mov    %rax,0x1a500(%rip)        # 230f8 <fwp_tape_next_slot>
    8bf8:	48 8b 05 79 c8 01 00 	mov    0x1c879(%rip),%rax        # 25478 <fwp_cleanups>
    8bff:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8c03:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    8c09:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    8c10:	00 
    8c11:	66 0f 6f 34 24       	movdqa (%rsp),%xmm6
    8c16:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8c1a:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8c21:	00 
    8c22:	48 8d 05 47 c4 ff ff 	lea    -0x3bb9(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    8c29:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8c30:	00 
    8c31:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8c38:	00 
    8c39:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8c40:	00 
    8c41:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8c45:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8c49:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8c50:	00 
    8c51:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8c58:	00 
    8c59:	4c 89 bc 24 c0 00 00 	mov    %r15,0xc0(%rsp)
    8c60:	00 
    8c61:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    8c68:	00 
    8c69:	48 89 05 08 c8 01 00 	mov    %rax,0x1c808(%rip)        # 25478 <fwp_cleanups>
    8c70:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    8c77:	00 
    8c78:	0f 29 b4 24 b0 00 00 	movaps %xmm6,0xb0(%rsp)
    8c7f:	00 
    8c80:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8c87:	00 
    8c88:	4d 85 ed             	test   %r13,%r13
    8c8b:	0f 88 ff 09 00 00    	js     9690 <f12+0xfe0>
    8c91:	4c 89 e8             	mov    %r13,%rax
    8c94:	48 c1 f8 20          	sar    $0x20,%rax
    8c98:	48 39 c3             	cmp    %rax,%rbx
    8c9b:	0f 85 a0 0c 00 00    	jne    9941 <f12+0x1291>
    8ca1:	45 89 ea             	mov    %r13d,%r10d
    8ca4:	4c 39 d7             	cmp    %r10,%rdi
    8ca7:	0f 8e 88 0c 00 00    	jle    9935 <f12+0x1285>
    8cad:	4d 39 d6             	cmp    %r10,%r14
    8cb0:	0f 8e 12 01 00 00    	jle    8dc8 <f12+0x718>
    8cb6:	49 39 d6             	cmp    %rdx,%r14
    8cb9:	0f 8f d9 0a 00 00    	jg     9798 <f12+0x10e8>
    8cbf:	4d 85 ff             	test   %r15,%r15
    8cc2:	0f 84 e6 09 00 00    	je     96ae <f12+0xffe>
    8cc8:	4d 8d 4e ff          	lea    -0x1(%r14),%r9
    8ccc:	31 f6                	xor    %esi,%esi
    8cce:	4c 89 ff             	mov    %r15,%rdi
    8cd1:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    8cd6:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    8cdd:	00 
    8cde:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    8ce3:	e8 d8 a7 ff ff       	call   34c0 <memset@plt>
    8ce8:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    8ced:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    8cf2:	45 31 db             	xor    %r11d,%r11d
    8cf5:	e9 5d 01 00 00       	jmp    8e57 <f12+0x7a7>
    8cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d00:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8d04:	0f 84 ff fb ff ff    	je     8909 <f12+0x259>
    8d0a:	e9 ec fb ff ff       	jmp    88fb <f12+0x24b>
    8d0f:	90                   	nop
    8d10:	48 c1 e6 10          	shl    $0x10,%rsi
    8d14:	bf 08 00 00 00       	mov    $0x8,%edi
    8d19:	4c 09 c6             	or     %r8,%rsi
    8d1c:	49 89 f4             	mov    %rsi,%r12
    8d1f:	be 02 00 00 00       	mov    $0x2,%esi
    8d24:	e8 67 cf ff ff       	call   5c90 <fwp_heap_alloc>
    8d29:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8d30:	48 8b 15 81 be 01 00 	mov    0x1be81(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8d37:	48 89 c3             	mov    %rax,%rbx
    8d3a:	48 2b 05 4f be 01 00 	sub    0x1be4f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8d41:	48 c1 e2 10          	shl    $0x10,%rdx
    8d45:	48 39 d0             	cmp    %rdx,%rax
    8d48:	73 56                	jae    8da0 <f12+0x6f0>
    8d4a:	48 89 c2             	mov    %rax,%rdx
    8d4d:	48 c1 ea 10          	shr    $0x10,%rdx
    8d51:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d55:	48 8b 15 7c be 01 00 	mov    0x1be7c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8d5c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8d60:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8d64:	48 85 d2             	test   %rdx,%rdx
    8d67:	0f 84 86 fd ff ff    	je     8af3 <f12+0x443>
    8d6d:	0f b6 31             	movzbl (%rcx),%esi
    8d70:	45 31 ed             	xor    %r13d,%r13d
    8d73:	40 80 fe 02          	cmp    $0x2,%sil
    8d77:	0f 85 fe fc ff ff    	jne    8a7b <f12+0x3cb>
    8d7d:	66 85 c0             	test   %ax,%ax
    8d80:	0f 85 20 fd ff ff    	jne    8aa6 <f12+0x3f6>
    8d86:	e9 0f fd ff ff       	jmp    8a9a <f12+0x3ea>
    8d8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8d90:	4d 85 ed             	test   %r13,%r13
    8d93:	0f 85 12 fd ff ff    	jne    8aab <f12+0x3fb>
    8d99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8da0:	45 31 f6             	xor    %r14d,%r14d
    8da3:	e9 b6 fd ff ff       	jmp    8b5e <f12+0x4ae>
    8da8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8daf:	00 
    8db0:	4c 39 e3             	cmp    %r12,%rbx
    8db3:	0f 84 77 fa ff ff    	je     8830 <f12+0x180>
    8db9:	4c 8b 35 50 a3 01 00 	mov    0x1a350(%rip),%r14        # 23110 <fwp_tapes>
    8dc0:	e9 ff fa ff ff       	jmp    88c4 <f12+0x214>
    8dc5:	0f 1f 00             	nopl   (%rax)
    8dc8:	49 8d 5a 01          	lea    0x1(%r10),%rbx
    8dcc:	48 39 da             	cmp    %rbx,%rdx
    8dcf:	0f 8d cb 09 00 00    	jge    97a0 <f12+0x10f0>
    8dd5:	48 85 d2             	test   %rdx,%rdx
    8dd8:	48 0f 44 d3          	cmove  %rbx,%rdx
    8ddc:	eb 17                	jmp    8df5 <f12+0x745>
    8dde:	66 90                	xchg   %ax,%ax
    8de0:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    8de4:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    8deb:	48 89 d8             	mov    %rbx,%rax
    8dee:	48 0f 4c c6          	cmovl  %rsi,%rax
    8df2:	48 89 c2             	mov    %rax,%rdx
    8df5:	48 39 da             	cmp    %rbx,%rdx
    8df8:	7c e6                	jl     8de0 <f12+0x730>
    8dfa:	4d 85 ff             	test   %r15,%r15
    8dfd:	0f 84 2d 0a 00 00    	je     9830 <f12+0x1180>
    8e03:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    8e0a:	00 
    8e0b:	4c 89 ff             	mov    %r15,%rdi
    8e0e:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    8e13:	e8 b8 a7 ff ff       	call   35d0 <realloc@plt>
    8e18:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    8e1d:	49 89 c7             	mov    %rax,%r15
    8e20:	4d 85 ff             	test   %r15,%r15
    8e23:	0f 84 73 08 00 00    	je     969c <f12+0xfec>
    8e29:	4c 89 bc 24 c0 00 00 	mov    %r15,0xc0(%rsp)
    8e30:	00 
    8e31:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
    8e38:	00 
    8e39:	48 85 db             	test   %rbx,%rbx
    8e3c:	0f 85 b6 0a 00 00    	jne    98f8 <f12+0x1248>
    8e42:	4d 89 f3             	mov    %r14,%r11
    8e45:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
    8e4c:	49 f7 db             	neg    %r11
    8e4f:	4d 85 ed             	test   %r13,%r13
    8e52:	78 17                	js     8e6b <f12+0x7bb>
    8e54:	45 89 ea             	mov    %r13d,%r10d
    8e57:	f2 0f 10 05 c1 6d 00 	movsd  0x6dc1(%rip),%xmm0        # fc20 <msg.4+0xb0>
    8e5e:	00 
    8e5f:	f2 43 0f 58 04 d7    	addsd  (%r15,%r10,8),%xmm0
    8e65:	f2 43 0f 11 04 d7    	movsd  %xmm0,(%r15,%r10,8)
    8e6b:	bf 03 00 00 00       	mov    $0x3,%edi
    8e70:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    8e75:	4c 01 35 a4 a2 01 00 	add    %r14,0x1a2a4(%rip)        # 23120 <descent_inputs>
    8e7c:	4c 01 1d a5 a2 01 00 	add    %r11,0x1a2a5(%rip)        # 23128 <descent_nodes>
    8e83:	e8 c8 b3 ff ff       	call   4250 <descent_phase_step>
    8e88:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    8e8d:	4d 39 ce             	cmp    %r9,%r14
    8e90:	0f 8f 8c 00 00 00    	jg     8f22 <f12+0x872>
    8e96:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    8e9b:	4d 29 f1             	sub    %r14,%r9
    8e9e:	4c 8b 14 24          	mov    (%rsp),%r10
    8ea2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8ea6:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8eab:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    8eb0:	4b 8d 14 cb          	lea    (%r11,%r9,8),%rdx
    8eb4:	4d 29 da             	sub    %r11,%r10
    8eb7:	4a 8d 04 8f          	lea    (%rdi,%r9,4),%rax
    8ebb:	4f 8d 0c f7          	lea    (%r15,%r14,8),%r9
    8ebf:	48 29 fe             	sub    %rdi,%rsi
    8ec2:	4d 29 d9             	sub    %r11,%r9
    8ec5:	eb 0d                	jmp    8ed4 <f12+0x824>
    8ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8ece:	00 00 
    8ed0:	48 83 e8 04          	sub    $0x4,%rax
    8ed4:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    8eda:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8ede:	7a 02                	jp     8ee2 <f12+0x832>
    8ee0:	74 37                	je     8f19 <f12+0x869>
    8ee2:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8ee6:	45 85 db             	test   %r11d,%r11d
    8ee9:	78 16                	js     8f01 <f12+0x851>
    8eeb:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8ef1:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8ef5:	f2 43 0f 58 0c df    	addsd  (%r15,%r11,8),%xmm1
    8efb:	f2 43 0f 11 0c df    	movsd  %xmm1,(%r15,%r11,8)
    8f01:	4c 63 18             	movslq (%rax),%r11
    8f04:	45 85 db             	test   %r11d,%r11d
    8f07:	78 10                	js     8f19 <f12+0x869>
    8f09:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8f0d:	f2 43 0f 58 04 df    	addsd  (%r15,%r11,8),%xmm0
    8f13:	f2 43 0f 11 04 df    	movsd  %xmm0,(%r15,%r11,8)
    8f19:	48 83 ea 08          	sub    $0x8,%rdx
    8f1d:	48 39 c7             	cmp    %rax,%rdi
    8f20:	75 ae                	jne    8ed0 <f12+0x820>
    8f22:	bf 04 00 00 00       	mov    $0x4,%edi
    8f27:	e8 24 b3 ff ff       	call   4250 <descent_phase_step>
    8f2c:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8f33:	ff ff 1f 
    8f36:	4c 39 f0             	cmp    %r14,%rax
    8f39:	0f 82 3f 0a 00 00    	jb     997e <f12+0x12ce>
    8f3f:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8f46:	00 
    8f47:	be 02 00 00 00       	mov    $0x2,%esi
    8f4c:	e8 3f cd ff ff       	call   5c90 <fwp_heap_alloc>
    8f51:	4c 89 30             	mov    %r14,(%rax)
    8f54:	49 89 c5             	mov    %rax,%r13
    8f57:	31 c0                	xor    %eax,%eax
    8f59:	4d 85 f6             	test   %r14,%r14
    8f5c:	74 14                	je     8f72 <f12+0x8c2>
    8f5e:	66 90                	xchg   %ax,%ax
    8f60:	49 8b 14 c7          	mov    (%r15,%rax,8),%rdx
    8f64:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    8f69:	48 83 c0 01          	add    $0x1,%rax
    8f6d:	49 39 c6             	cmp    %rax,%r14
    8f70:	75 ee                	jne    8f60 <f12+0x8b0>
    8f72:	bf 05 00 00 00       	mov    $0x5,%edi
    8f77:	e8 d4 b2 ff ff       	call   4250 <descent_phase_step>
    8f7c:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    8f83:	00 
    8f84:	4c 89 e7             	mov    %r12,%rdi
    8f87:	48 89 0d ea c4 01 00 	mov    %rcx,0x1c4ea(%rip)        # 25478 <fwp_cleanups>
    8f8e:	48 89 0c 24          	mov    %rcx,(%rsp)
    8f92:	e8 d9 c0 ff ff       	call   5070 <fwp_tape_buffers_release>
    8f97:	bf 06 00 00 00       	mov    $0x6,%edi
    8f9c:	e8 af b2 ff ff       	call   4250 <descent_phase_step>
    8fa1:	48 8b 15 10 bc 01 00 	mov    0x1bc10(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8fa8:	4c 89 e8             	mov    %r13,%rax
    8fab:	48 8b 0c 24          	mov    (%rsp),%rcx
    8faf:	48 2b 05 da bb 01 00 	sub    0x1bbda(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8fb6:	48 c1 e2 10          	shl    $0x10,%rdx
    8fba:	48 39 d0             	cmp    %rdx,%rax
    8fbd:	73 57                	jae    9016 <f12+0x966>
    8fbf:	48 89 c2             	mov    %rax,%rdx
    8fc2:	48 c1 ea 10          	shr    $0x10,%rdx
    8fc6:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8fca:	48 8b 15 07 bc 01 00 	mov    0x1bc07(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8fd1:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8fd5:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8fd9:	48 85 db             	test   %rbx,%rbx
    8fdc:	74 38                	je     9016 <f12+0x966>
    8fde:	0f b6 32             	movzbl (%rdx),%esi
    8fe1:	40 80 fe 02          	cmp    $0x2,%sil
    8fe5:	0f 84 0d 07 00 00    	je     96f8 <f12+0x1048>
    8feb:	40 80 fe 01          	cmp    $0x1,%sil
    8fef:	75 25                	jne    9016 <f12+0x966>
    8ff1:	8b 72 18             	mov    0x18(%rdx),%esi
    8ff4:	0f b7 c0             	movzwl %ax,%eax
    8ff7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ffa:	48 0f af c6          	imul   %rsi,%rax
    8ffe:	48 c1 e8 20          	shr    $0x20,%rax
    9002:	48 39 d0             	cmp    %rdx,%rax
    9005:	73 0f                	jae    9016 <f12+0x966>
    9007:	48 01 c3             	add    %rax,%rbx
    900a:	80 3b ff             	cmpb   $0xff,(%rbx)
    900d:	0f 84 b9 08 00 00    	je     98cc <f12+0x121c>
    9013:	c6 03 01             	movb   $0x1,(%rbx)
    9016:	48 3b 4c 24 30       	cmp    0x30(%rsp),%rcx
    901b:	0f 85 2a a7 ff ff    	jne    374b <f12.cold>
    9021:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    9026:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    902b:	48 89 05 46 c4 01 00 	mov    %rax,0x1c446(%rip)        # 25478 <fwp_cleanups>
    9032:	e8 89 e2 ff ff       	call   72c0 <fwp_tape_scope_release>
    9037:	49 8b 45 00          	mov    0x0(%r13),%rax
    903b:	49 89 c4             	mov    %rax,%r12
    903e:	49 0f ba f4 3f       	btr    $0x3f,%r12
    9043:	48 85 c0             	test   %rax,%rax
    9046:	0f 88 34 05 00 00    	js     9580 <f12+0xed0>
    904c:	48 8b 15 65 bb 01 00 	mov    0x1bb65(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    9053:	4c 89 e8             	mov    %r13,%rax
    9056:	48 2b 05 33 bb 01 00 	sub    0x1bb33(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    905d:	48 c1 e2 10          	shl    $0x10,%rdx
    9061:	48 39 d0             	cmp    %rdx,%rax
    9064:	0f 83 16 05 00 00    	jae    9580 <f12+0xed0>
    906a:	48 89 c2             	mov    %rax,%rdx
    906d:	48 c1 ea 10          	shr    $0x10,%rdx
    9071:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9075:	48 8b 15 5c bb 01 00 	mov    0x1bb5c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    907c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9080:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9084:	48 85 c9             	test   %rcx,%rcx
    9087:	0f 84 f3 04 00 00    	je     9580 <f12+0xed0>
    908d:	0f b6 32             	movzbl (%rdx),%esi
    9090:	40 80 fe 02          	cmp    $0x2,%sil
    9094:	0f 84 d6 04 00 00    	je     9570 <f12+0xec0>
    909a:	40 80 fe 01          	cmp    $0x1,%sil
    909e:	0f 85 dc 04 00 00    	jne    9580 <f12+0xed0>
    90a4:	8b 72 18             	mov    0x18(%rdx),%esi
    90a7:	0f b7 c0             	movzwl %ax,%eax
    90aa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    90ad:	48 0f af c6          	imul   %rsi,%rax
    90b1:	48 c1 e8 20          	shr    $0x20,%rax
    90b5:	48 39 d0             	cmp    %rdx,%rax
    90b8:	0f 83 c2 04 00 00    	jae    9580 <f12+0xed0>
    90be:	48 01 c1             	add    %rax,%rcx
    90c1:	80 39 01             	cmpb   $0x1,(%rcx)
    90c4:	0f 85 b6 04 00 00    	jne    9580 <f12+0xed0>
    90ca:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    90cf:	4d 89 ef             	mov    %r13,%r15
    90d2:	31 ff                	xor    %edi,%edi
    90d4:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    90d9:	f2 0f 10 0d 4f 6b 00 	movsd  0x6b4f(%rip),%xmm1        # fc30 <msg.4+0xc0>
    90e0:	00 
    90e1:	48 8d 50 08          	lea    0x8(%rax),%rdx
    90e5:	31 c0                	xor    %eax,%eax
    90e7:	4d 85 e4             	test   %r12,%r12
    90ea:	75 29                	jne    9115 <f12+0xa65>
    90ec:	eb 42                	jmp    9130 <f12+0xa80>
    90ee:	66 90                	xchg   %ax,%ax
    90f0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    90f4:	0f 88 53 08 00 00    	js     994d <f12+0x129d>
    90fa:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    90ff:	48 83 c0 01          	add    $0x1,%rax
    9103:	48 83 c2 08          	add    $0x8,%rdx
    9107:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    910b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9110:	49 39 c4             	cmp    %rax,%r12
    9113:	74 1b                	je     9130 <f12+0xa80>
    9115:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    9119:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    911e:	79 d0                	jns    90f0 <f12+0xa40>
    9120:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    9124:	eb ca                	jmp    90f0 <f12+0xa40>
    9126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    912d:	00 00 00 
    9130:	e8 6b e7 ff ff       	call   78a0 <fwp_drop4>
    9135:	48 89 e8             	mov    %rbp,%rax
    9138:	31 d2                	xor    %edx,%edx
    913a:	48 85 ed             	test   %rbp,%rbp
    913d:	0f 84 1c 07 00 00    	je     985f <f12+0x11af>
    9143:	66 90                	xchg   %ax,%ax
    9145:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    914c:	00 00 00 00 
    9150:	48 8b 40 10          	mov    0x10(%rax),%rax
    9154:	48 83 c2 01          	add    $0x1,%rdx
    9158:	48 85 c0             	test   %rax,%rax
    915b:	75 f3                	jne    9150 <f12+0xaa0>
    915d:	49 8b 07             	mov    (%r15),%rax
    9160:	49 89 c5             	mov    %rax,%r13
    9163:	49 0f ba f5 3f       	btr    $0x3f,%r13
    9168:	48 85 c0             	test   %rax,%rax
    916b:	0f 88 61 03 00 00    	js     94d2 <f12+0xe22>
    9171:	48 8b 05 40 ba 01 00 	mov    0x1ba40(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    9178:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    917d:	48 2b 0d 0c ba 01 00 	sub    0x1ba0c(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    9184:	48 c1 e0 10          	shl    $0x10,%rax
    9188:	48 39 c1             	cmp    %rax,%rcx
    918b:	0f 83 41 03 00 00    	jae    94d2 <f12+0xe22>
    9191:	48 89 c8             	mov    %rcx,%rax
    9194:	48 c1 e8 10          	shr    $0x10,%rax
    9198:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    919c:	48 8b 05 35 ba 01 00 	mov    0x1ba35(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    91a3:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    91a7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    91ab:	48 85 ff             	test   %rdi,%rdi
    91ae:	0f 84 1e 03 00 00    	je     94d2 <f12+0xe22>
    91b4:	0f b6 06             	movzbl (%rsi),%eax
    91b7:	3c 02                	cmp    $0x2,%al
    91b9:	0f 84 01 03 00 00    	je     94c0 <f12+0xe10>
    91bf:	3c 01                	cmp    $0x1,%al
    91c1:	0f 85 02 03 00 00    	jne    94c9 <f12+0xe19>
    91c7:	8b 46 18             	mov    0x18(%rsi),%eax
    91ca:	0f b7 c9             	movzwl %cx,%ecx
    91cd:	48 0f af c8          	imul   %rax,%rcx
    91d1:	8b 46 1c             	mov    0x1c(%rsi),%eax
    91d4:	48 c1 e9 20          	shr    $0x20,%rcx
    91d8:	48 39 c1             	cmp    %rax,%rcx
    91db:	0f 83 e8 02 00 00    	jae    94c9 <f12+0xe19>
    91e1:	48 01 cf             	add    %rcx,%rdi
    91e4:	80 3f 01             	cmpb   $0x1,(%rdi)
    91e7:	0f 85 dc 02 00 00    	jne    94c9 <f12+0xe19>
    91ed:	49 39 d5             	cmp    %rdx,%r13
    91f0:	48 89 d0             	mov    %rdx,%rax
    91f3:	49 0f 46 c5          	cmovbe %r13,%rax
    91f7:	48 85 c0             	test   %rax,%rax
    91fa:	0f 84 5e 07 00 00    	je     995e <f12+0x12ae>
    9200:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
    9207:	00 
    9208:	4d 8d 77 08          	lea    0x8(%r15),%r14
    920c:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    9211:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    9218:	00 
    9219:	48 89 e9             	mov    %rbp,%rcx
    921c:	31 d2                	xor    %edx,%edx
    921e:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    9222:	eb 39                	jmp    925d <f12+0xbad>
    9224:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    922a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9231:	00 00 00 00 
    9235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    923c:	00 00 00 00 
    9240:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9245:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    924a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9250:	48 83 c2 08          	add    $0x8,%rdx
    9254:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9258:	49 39 d0             	cmp    %rdx,%r8
    925b:	74 1b                	je     9278 <f12+0xbc8>
    925d:	48 89 fe             	mov    %rdi,%rsi
    9260:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9264:	79 da                	jns    9240 <f12+0xb90>
    9266:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    926b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    926f:	eb cf                	jmp    9240 <f12+0xb90>
    9271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9278:	48 85 ed             	test   %rbp,%rbp
    927b:	0f 84 ac 06 00 00    	je     992d <f12+0x127d>
    9281:	4c 8b 05 30 b9 01 00 	mov    0x1b930(%rip),%r8        # 24bb8 <fwp_heap+0x13d8>
    9288:	4c 8b 0d 01 b9 01 00 	mov    0x1b901(%rip),%r9        # 24b90 <fwp_heap+0x13b0>
    928f:	48 89 e9             	mov    %rbp,%rcx
    9292:	45 31 ed             	xor    %r13d,%r13d
    9295:	4c 8b 15 3c b9 01 00 	mov    0x1b93c(%rip),%r10        # 24bd8 <fwp_heap+0x13f8>
    929c:	49 c1 e0 10          	shl    $0x10,%r8
    92a0:	eb 1c                	jmp    92be <f12+0xc0e>
    92a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92a8:	49 83 c5 01          	add    $0x1,%r13
    92ac:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    92b0:	49 39 c5             	cmp    %rax,%r13
    92b3:	0f 83 67 01 00 00    	jae    9420 <f12+0xd70>
    92b9:	48 85 c9             	test   %rcx,%rcx
    92bc:	74 56                	je     9314 <f12+0xc64>
    92be:	48 89 ca             	mov    %rcx,%rdx
    92c1:	4c 29 ca             	sub    %r9,%rdx
    92c4:	4c 39 c2             	cmp    %r8,%rdx
    92c7:	73 4b                	jae    9314 <f12+0xc64>
    92c9:	48 89 d6             	mov    %rdx,%rsi
    92cc:	48 c1 ee 10          	shr    $0x10,%rsi
    92d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    92d4:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    92d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    92dc:	48 85 ff             	test   %rdi,%rdi
    92df:	74 33                	je     9314 <f12+0xc64>
    92e1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    92e5:	41 80 fb 02          	cmp    $0x2,%r11b
    92e9:	0f 84 19 01 00 00    	je     9408 <f12+0xd58>
    92ef:	41 80 fb 01          	cmp    $0x1,%r11b
    92f3:	75 1f                	jne    9314 <f12+0xc64>
    92f5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    92f9:	0f b7 d2             	movzwl %dx,%edx
    92fc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    92ff:	49 0f af d3          	imul   %r11,%rdx
    9303:	48 c1 ea 20          	shr    $0x20,%rdx
    9307:	48 39 f2             	cmp    %rsi,%rdx
    930a:	73 08                	jae    9314 <f12+0xc64>
    930c:	48 01 d7             	add    %rdx,%rdi
    930f:	80 3f 01             	cmpb   $0x1,(%rdi)
    9312:	74 94                	je     92a8 <f12+0xbf8>
    9314:	49 39 c5             	cmp    %rax,%r13
    9317:	0f 83 03 01 00 00    	jae    9420 <f12+0xd70>
    931d:	49 89 c7             	mov    %rax,%r15
    9320:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    9327:	00 
    9328:	45 31 e4             	xor    %r12d,%r12d
    932b:	48 89 04 24          	mov    %rax,(%rsp)
    932f:	48 8d 1d aa a4 01 00 	lea    0x1a4aa(%rip),%rbx        # 237e0 <fwp_heap>
    9336:	eb 3a                	jmp    9372 <f12+0xcc2>
    9338:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    933f:	00 
    9340:	41 80 f9 01          	cmp    $0x1,%r9b
    9344:	75 27                	jne    936d <f12+0xcbd>
    9346:	45 8b 48 18          	mov    0x18(%r8),%r9d
    934a:	0f b7 c0             	movzwl %ax,%eax
    934d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9351:	49 0f af c1          	imul   %r9,%rax
    9355:	48 c1 e8 20          	shr    $0x20,%rax
    9359:	4c 39 c0             	cmp    %r8,%rax
    935c:	73 0f                	jae    936d <f12+0xcbd>
    935e:	48 01 c7             	add    %rax,%rdi
    9361:	80 3f ff             	cmpb   $0xff,(%rdi)
    9364:	0f 84 c6 02 00 00    	je     9630 <f12+0xf80>
    936a:	c6 07 01             	movb   $0x1,(%rdi)
    936d:	4d 39 fd             	cmp    %r15,%r13
    9370:	73 7e                	jae    93f0 <f12+0xd40>
    9372:	49 83 ef 01          	sub    $0x1,%r15
    9376:	66 49 0f 6e ec       	movq   %r12,%xmm5
    937b:	48 8b 34 24          	mov    (%rsp),%rsi
    937f:	bf 01 00 00 00       	mov    $0x1,%edi
    9384:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    938a:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    938e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9395:	00 
    9396:	e8 95 d3 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    939b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    93a2:	49 89 c4             	mov    %rax,%r12
    93a5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    93ac:	48 c1 e7 10          	shl    $0x10,%rdi
    93b0:	48 39 f8             	cmp    %rdi,%rax
    93b3:	73 b8                	jae    936d <f12+0xcbd>
    93b5:	48 89 c7             	mov    %rax,%rdi
    93b8:	48 c1 ef 10          	shr    $0x10,%rdi
    93bc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    93c0:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    93c7:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    93cb:	49 8b 78 20          	mov    0x20(%r8),%rdi
    93cf:	48 85 ff             	test   %rdi,%rdi
    93d2:	74 99                	je     936d <f12+0xcbd>
    93d4:	45 0f b6 08          	movzbl (%r8),%r9d
    93d8:	41 80 f9 02          	cmp    $0x2,%r9b
    93dc:	0f 85 5e ff ff ff    	jne    9340 <f12+0xc90>
    93e2:	66 85 c0             	test   %ax,%ax
    93e5:	0f 84 76 ff ff ff    	je     9361 <f12+0xcb1>
    93eb:	4d 39 fd             	cmp    %r15,%r13
    93ee:	72 82                	jb     9372 <f12+0xcc2>
    93f0:	4d 85 ed             	test   %r13,%r13
    93f3:	75 2e                	jne    9423 <f12+0xd73>
    93f5:	8b 44 24 28          	mov    0x28(%rsp),%eax
    93f9:	85 c0                	test   %eax,%eax
    93fb:	4d 0f 45 f5          	cmovne %r13,%r14
    93ff:	eb 6f                	jmp    9470 <f12+0xdc0>
    9401:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9408:	66 85 d2             	test   %dx,%dx
    940b:	0f 84 fe fe ff ff    	je     930f <f12+0xc5f>
    9411:	49 39 c5             	cmp    %rax,%r13
    9414:	0f 82 03 ff ff ff    	jb     931d <f12+0xc6d>
    941a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9420:	45 31 e4             	xor    %r12d,%r12d
    9423:	4c 89 f2             	mov    %r14,%rdx
    9426:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    942a:	48 89 e8             	mov    %rbp,%rax
    942d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9434:	00 
    9435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    943c:	00 00 00 00 
    9440:	48 8b 0a             	mov    (%rdx),%rcx
    9443:	48 83 c2 08          	add    $0x8,%rdx
    9447:	48 89 c7             	mov    %rax,%rdi
    944a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    944e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9452:	4c 39 c2             	cmp    %r8,%rdx
    9455:	75 e9                	jne    9440 <f12+0xd90>
    9457:	8b 54 24 28          	mov    0x28(%rsp),%edx
    945b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    945f:	85 d2                	test   %edx,%edx
    9461:	0f 84 a9 02 00 00    	je     9710 <f12+0x1060>
    9467:	49 89 ec             	mov    %rbp,%r12
    946a:	45 31 f6             	xor    %r14d,%r14d
    946d:	48 89 c5             	mov    %rax,%rbp
    9470:	4c 89 f7             	mov    %r14,%rdi
    9473:	e8 18 c3 ff ff       	call   5790 <fwp_mem_free>
    9478:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    947d:	e8 1e e4 ff ff       	call   78a0 <fwp_drop4>
    9482:	48 89 ef             	mov    %rbp,%rdi
    9485:	e8 16 d8 ff ff       	call   6ca0 <fwp_drop0>
    948a:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    9491:	00 
    9492:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9499:	00 00 
    949b:	0f 85 01 05 00 00    	jne    99a2 <f12+0x12f2>
    94a1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    94a8:	4c 89 e0             	mov    %r12,%rax
    94ab:	5b                   	pop    %rbx
    94ac:	5d                   	pop    %rbp
    94ad:	41 5c                	pop    %r12
    94af:	41 5d                	pop    %r13
    94b1:	41 5e                	pop    %r14
    94b3:	41 5f                	pop    %r15
    94b5:	c3                   	ret
    94b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    94bd:	00 00 00 
    94c0:	66 85 c9             	test   %cx,%cx
    94c3:	0f 84 1b fd ff ff    	je     91e4 <f12+0xb34>
    94c9:	48 85 ed             	test   %rbp,%rbp
    94cc:	0f 84 2f 03 00 00    	je     9801 <f12+0x1151>
    94d2:	48 89 e8             	mov    %rbp,%rax
    94d5:	45 31 e4             	xor    %r12d,%r12d
    94d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    94df:	00 
    94e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    94e4:	4c 89 e2             	mov    %r12,%rdx
    94e7:	49 83 c4 01          	add    $0x1,%r12
    94eb:	48 85 c0             	test   %rax,%rax
    94ee:	75 f0                	jne    94e0 <f12+0xe30>
    94f0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    94f7:	ff ff 1f 
    94fa:	4c 39 e0             	cmp    %r12,%rax
    94fd:	0f 82 6f 04 00 00    	jb     9972 <f12+0x12c2>
    9503:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    950a:	00 
    950b:	be 02 00 00 00       	mov    $0x2,%esi
    9510:	e8 7b c7 ff ff       	call   5c90 <fwp_heap_alloc>
    9515:	4d 39 e5             	cmp    %r12,%r13
    9518:	48 89 ea             	mov    %rbp,%rdx
    951b:	49 89 c6             	mov    %rax,%r14
    951e:	4c 89 e0             	mov    %r12,%rax
    9521:	49 0f 46 c5          	cmovbe %r13,%rax
    9525:	4c 89 f1             	mov    %r14,%rcx
    9528:	66 90                	xchg   %ax,%ax
    952a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9531:	00 00 00 00 
    9535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    953c:	00 00 00 00 
    9540:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9544:	48 83 c1 08          	add    $0x8,%rcx
    9548:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    954c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9550:	48 85 d2             	test   %rdx,%rdx
    9553:	75 eb                	jne    9540 <f12+0xe90>
    9555:	48 85 c0             	test   %rax,%rax
    9558:	0f 84 b5 02 00 00    	je     9813 <f12+0x1163>
    955e:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
    9565:	00 
    9566:	e9 a1 fc ff ff       	jmp    920c <f12+0xb5c>
    956b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9570:	66 85 c0             	test   %ax,%ax
    9573:	0f 84 48 fb ff ff    	je     90c1 <f12+0xa11>
    9579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9580:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9587:	ff ff 1f 
    958a:	4c 39 e0             	cmp    %r12,%rax
    958d:	0f 82 eb 03 00 00    	jb     997e <f12+0x12ce>
    9593:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    959a:	00 
    959b:	be 01 00 00 00       	mov    $0x1,%esi
    95a0:	e8 eb c6 ff ff       	call   5c90 <fwp_heap_alloc>
    95a5:	4c 89 20             	mov    %r12,(%rax)
    95a8:	48 8b 15 09 b6 01 00 	mov    0x1b609(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    95af:	49 89 c7             	mov    %rax,%r15
    95b2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    95b7:	48 2b 05 d2 b5 01 00 	sub    0x1b5d2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    95be:	48 c1 e2 10          	shl    $0x10,%rdx
    95c2:	48 39 d0             	cmp    %rdx,%rax
    95c5:	73 57                	jae    961e <f12+0xf6e>
    95c7:	48 89 c2             	mov    %rax,%rdx
    95ca:	48 c1 ea 10          	shr    $0x10,%rdx
    95ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95d2:	48 8b 15 ff b5 01 00 	mov    0x1b5ff(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    95d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95dd:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    95e1:	4d 85 f6             	test   %r14,%r14
    95e4:	74 38                	je     961e <f12+0xf6e>
    95e6:	0f b6 0a             	movzbl (%rdx),%ecx
    95e9:	80 f9 02             	cmp    $0x2,%cl
    95ec:	0f 84 2e 02 00 00    	je     9820 <f12+0x1170>
    95f2:	80 f9 01             	cmp    $0x1,%cl
    95f5:	75 27                	jne    961e <f12+0xf6e>
    95f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    95fa:	0f b7 c0             	movzwl %ax,%eax
    95fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9600:	48 0f af c1          	imul   %rcx,%rax
    9604:	48 c1 e8 20          	shr    $0x20,%rax
    9608:	48 39 d0             	cmp    %rdx,%rax
    960b:	73 11                	jae    961e <f12+0xf6e>
    960d:	49 01 c6             	add    %rax,%r14
    9610:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9614:	0f 84 c7 02 00 00    	je     98e1 <f12+0x1231>
    961a:	41 c6 06 01          	movb   $0x1,(%r14)
    961e:	4c 89 ef             	mov    %r13,%rdi
    9621:	e9 ae fa ff ff       	jmp    90d4 <f12+0xa24>
    9626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    962d:	00 00 00 
    9630:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    9635:	e8 16 bf ff ff       	call   5550 <fwp_rc_forget_slot>
    963a:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    963f:	e9 26 fd ff ff       	jmp    936a <f12+0xcba>
    9644:	0f 1f 40 00          	nopl   0x0(%rax)
    9648:	48 8d 3d 91 db ff ff 	lea    -0x246f(%rip),%rdi        # 71e0 <fwp_tape_finish>
    964f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9654:	e8 97 56 00 00       	call   ecf0 <atexit>
    9659:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    965e:	85 c0                	test   %eax,%eax
    9660:	75 63                	jne    96c5 <f12+0x1015>
    9662:	c7 05 14 9a 00 00 01 	movl   $0x1,0x9a14(%rip)        # 13080 <registered_finish.0>
    9669:	00 00 00 
    966c:	e9 73 f1 ff ff       	jmp    87e4 <f12+0x134>
    9671:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9678:	66 85 c0             	test   %ax,%ax
    967b:	0f 85 0f f1 ff ff    	jne    8790 <f12+0xe0>
    9681:	e9 f6 f0 ff ff       	jmp    877c <f12+0xcc>
    9686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    968d:	00 00 00 
    9690:	4c 89 f3             	mov    %r14,%rbx
    9693:	49 39 d6             	cmp    %rdx,%r14
    9696:	0f 8f 39 f7 ff ff    	jg     8dd5 <f12+0x725>
    969c:	48 85 db             	test   %rbx,%rbx
    969f:	0f 84 9d f7 ff ff    	je     8e42 <f12+0x792>
    96a5:	4d 85 ff             	test   %r15,%r15
    96a8:	0f 85 8b f7 ff ff    	jne    8e39 <f12+0x789>
    96ae:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    96b5:	00 
    96b6:	4c 89 e7             	mov    %r12,%rdi
    96b9:	48 89 05 b8 bd 01 00 	mov    %rax,0x1bdb8(%rip)        # 25478 <fwp_cleanups>
    96c0:	e8 ab b9 ff ff       	call   5070 <fwp_tape_buffers_release>
    96c5:	48 8b 0d 94 99 00 00 	mov    0x9994(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    96cc:	ba 13 00 00 00       	mov    $0x13,%edx
    96d1:	be 01 00 00 00       	mov    $0x1,%esi
    96d6:	48 8d 3d 2b 59 00 00 	lea    0x592b(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    96dd:	e8 9e 9f ff ff       	call   3680 <fwrite@plt>
    96e2:	31 ff                	xor    %edi,%edi
    96e4:	e8 d7 9e ff ff       	call   35c0 <fflush@plt>
    96e9:	bf 66 00 00 00       	mov    $0x66,%edi
    96ee:	e8 ad 9f ff ff       	call   36a0 <_Exit@plt>
    96f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    96f8:	66 85 c0             	test   %ax,%ax
    96fb:	0f 85 15 f9 ff ff    	jne    9016 <f12+0x966>
    9701:	e9 04 f9 ff ff       	jmp    900a <f12+0x95a>
    9706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    970d:	00 00 00 
    9710:	49 89 ec             	mov    %rbp,%r12
    9713:	48 89 c5             	mov    %rax,%rbp
    9716:	e9 55 fd ff ff       	jmp    9470 <f12+0xdc0>
    971b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9720:	66 0f 6f 0d 98 99 01 	movdqa 0x19998(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    9727:	00 
    9728:	48 c7 05 75 99 01 00 	movq   $0x0,0x19975(%rip)        # 230a8 <fwp_tape_cached_bytes>
    972f:	00 00 00 00 
    9733:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    9739:	48 8b 05 a0 99 01 00 	mov    0x199a0(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    9740:	66 0f 6f 0d 88 99 01 	movdqa 0x19988(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    9747:	00 
    9748:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    974d:	48 8b 05 94 99 01 00 	mov    0x19994(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    9754:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    975a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    975e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    9763:	48 8b 05 86 99 01 00 	mov    0x19986(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    976a:	0f 29 0d 4f 99 01 00 	movaps %xmm1,0x1994f(%rip)        # 230c0 <fwp_tape_workspace>
    9771:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    9776:	0f 29 0d 53 99 01 00 	movaps %xmm1,0x19953(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    977d:	48 c7 05 68 99 01 00 	movq   $0x0,0x19968(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    9784:	00 00 00 00 
    9788:	0f 29 0d 51 99 01 00 	movaps %xmm1,0x19951(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    978f:	e9 75 f1 ff ff       	jmp    8909 <f12+0x259>
    9794:	0f 1f 40 00          	nopl   0x0(%rax)
    9798:	4c 89 f3             	mov    %r14,%rbx
    979b:	e9 35 f6 ff ff       	jmp    8dd5 <f12+0x725>
    97a0:	4d 85 ff             	test   %r15,%r15
    97a3:	0f 84 05 ff ff ff    	je     96ae <f12+0xffe>
    97a9:	49 89 db             	mov    %rbx,%r11
    97ac:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    97b3:	00 
    97b4:	31 f6                	xor    %esi,%esi
    97b6:	4c 89 ff             	mov    %r15,%rdi
    97b9:	4d 29 f3             	sub    %r14,%r11
    97bc:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    97c1:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
    97c6:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    97cb:	e8 f0 9c ff ff       	call   34c0 <memset@plt>
    97d0:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    97d5:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    97da:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
    97df:	e9 73 f6 ff ff       	jmp    8e57 <f12+0x7a7>
    97e4:	0f 1f 40 00          	nopl   0x0(%rax)
    97e8:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    97ec:	b8 ff ff 00 00       	mov    $0xffff,%eax
    97f1:	49 39 c7             	cmp    %rax,%r15
    97f4:	4c 0f 4f f8          	cmovg  %rax,%r15
    97f8:	49 6b f7 68          	imul   $0x68,%r15,%rsi
    97fc:	e9 60 f0 ff ff       	jmp    8861 <f12+0x1b1>
    9801:	be 02 00 00 00       	mov    $0x2,%esi
    9806:	bf 08 00 00 00       	mov    $0x8,%edi
    980b:	e8 80 c4 ff ff       	call   5c90 <fwp_heap_alloc>
    9810:	49 89 c6             	mov    %rax,%r14
    9813:	45 31 e4             	xor    %r12d,%r12d
    9816:	e9 55 fc ff ff       	jmp    9470 <f12+0xdc0>
    981b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9820:	66 85 c0             	test   %ax,%ax
    9823:	0f 85 f5 fd ff ff    	jne    961e <f12+0xf6e>
    9829:	e9 e2 fd ff ff       	jmp    9610 <f12+0xf60>
    982e:	66 90                	xchg   %ax,%ax
    9830:	48 89 d7             	mov    %rdx,%rdi
    9833:	be 08 00 00 00       	mov    $0x8,%esi
    9838:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    983d:	e8 de 9c ff ff       	call   3520 <calloc@plt>
    9842:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    9847:	49 89 c7             	mov    %rax,%r15
    984a:	e9 d1 f5 ff ff       	jmp    8e20 <f12+0x770>
    984f:	31 ff                	xor    %edi,%edi
    9851:	e8 fa a9 ff ff       	call   4250 <descent_phase_step>
    9856:	66 0f ef c0          	pxor   %xmm0,%xmm0
    985a:	e9 77 ef ff ff       	jmp    87d6 <f12+0x126>
    985f:	49 8b 07             	mov    (%r15),%rax
    9862:	48 85 c0             	test   %rax,%rax
    9865:	78 9a                	js     9801 <f12+0x1151>
    9867:	48 8b 35 4a b3 01 00 	mov    0x1b34a(%rip),%rsi        # 24bb8 <fwp_heap+0x13d8>
    986e:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9873:	48 2b 0d 16 b3 01 00 	sub    0x1b316(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    987a:	48 c1 e6 10          	shl    $0x10,%rsi
    987e:	48 39 f1             	cmp    %rsi,%rcx
    9881:	0f 83 7a ff ff ff    	jae    9801 <f12+0x1151>
    9887:	48 89 ce             	mov    %rcx,%rsi
    988a:	48 c1 ee 10          	shr    $0x10,%rsi
    988e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9892:	48 8b 35 3f b3 01 00 	mov    0x1b33f(%rip),%rsi        # 24bd8 <fwp_heap+0x13f8>
    9899:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    989d:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    98a1:	48 85 ff             	test   %rdi,%rdi
    98a4:	0f 84 57 ff ff ff    	je     9801 <f12+0x1151>
    98aa:	48 0f ba f0 3f       	btr    $0x3f,%rax
    98af:	49 89 c5             	mov    %rax,%r13
    98b2:	e9 fd f8 ff ff       	jmp    91b4 <f12+0xb04>
    98b7:	48 89 d7             	mov    %rdx,%rdi
    98ba:	48 89 14 24          	mov    %rdx,(%rsp)
    98be:	e8 8d bc ff ff       	call   5550 <fwp_rc_forget_slot>
    98c3:	48 8b 14 24          	mov    (%rsp),%rdx
    98c7:	e9 d7 f1 ff ff       	jmp    8aa3 <f12+0x3f3>
    98cc:	48 89 df             	mov    %rbx,%rdi
    98cf:	48 89 0c 24          	mov    %rcx,(%rsp)
    98d3:	e8 78 bc ff ff       	call   5550 <fwp_rc_forget_slot>
    98d8:	48 8b 0c 24          	mov    (%rsp),%rcx
    98dc:	e9 32 f7 ff ff       	jmp    9013 <f12+0x963>
    98e1:	4c 89 f7             	mov    %r14,%rdi
    98e4:	e8 67 bc ff ff       	call   5550 <fwp_rc_forget_slot>
    98e9:	e9 2c fd ff ff       	jmp    961a <f12+0xf6a>
    98ee:	e8 3d bb ff ff       	call   5430 <fwp_rc_wide_dup>
    98f3:	e9 98 ee ff ff       	jmp    8790 <f12+0xe0>
    98f8:	49 89 db             	mov    %rbx,%r11
    98fb:	4c 8d 4b ff          	lea    -0x1(%rbx),%r9
    98ff:	31 f6                	xor    %esi,%esi
    9901:	4c 89 ff             	mov    %r15,%rdi
    9904:	4d 29 f3             	sub    %r14,%r11
    9907:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    990e:	00 
    990f:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    9914:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
    9919:	e8 a2 9b ff ff       	call   34c0 <memset@plt>
    991e:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    9923:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    9928:	e9 22 f5 ff ff       	jmp    8e4f <f12+0x79f>
    992d:	45 31 ed             	xor    %r13d,%r13d
    9930:	e9 e8 f9 ff ff       	jmp    931d <f12+0xc6d>
    9935:	48 8d 3d 2b 58 00 00 	lea    0x582b(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    993c:	e8 af aa ff ff       	call   43f0 <fwp_trap>
    9941:	48 8d 3d 68 5f 00 00 	lea    0x5f68(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    9948:	e8 a3 aa ff ff       	call   43f0 <fwp_trap>
    994d:	48 8d 3d 64 60 00 00 	lea    0x6064(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    9954:	e8 97 aa ff ff       	call   43f0 <fwp_trap>
    9959:	e8 a2 9d ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    995e:	45 31 f6             	xor    %r14d,%r14d
    9961:	e9 ad fe ff ff       	jmp    9813 <f12+0x1163>
    9966:	48 8d 3d 31 58 00 00 	lea    0x5831(%rip),%rdi        # f19e <_IO_stdin_used+0x19e>
    996d:	e8 7e aa ff ff       	call   43f0 <fwp_trap>
    9972:	48 8d 3d 17 58 00 00 	lea    0x5817(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    9979:	e8 72 aa ff ff       	call   43f0 <fwp_trap>
    997e:	48 8d 3d 33 58 00 00 	lea    0x5833(%rip),%rdi        # f1b8 <_IO_stdin_used+0x1b8>
    9985:	e8 66 aa ff ff       	call   43f0 <fwp_trap>
    998a:	48 8d 3d c7 5f 00 00 	lea    0x5fc7(%rip),%rdi        # f958 <_IO_stdin_used+0x958>
    9991:	e8 5a aa ff ff       	call   43f0 <fwp_trap>
    9996:	48 8d 3d 5b 5f 00 00 	lea    0x5f5b(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    999d:	e8 4e aa ff ff       	call   43f0 <fwp_trap>
    99a2:	e8 b9 9a ff ff       	call   3460 <__stack_chk_fail@plt>
    99a7:	48 8d 3d da 5f 00 00 	lea    0x5fda(%rip),%rdi        # f988 <_IO_stdin_used+0x988>
    99ae:	e8 3d aa ff ff       	call   43f0 <fwp_trap>
    99b3:	66 90                	xchg   %ax,%ax
    99b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99bc:	00 00 00 00 

00000000000099c0 <fwp_owned_entry12>:
    99c0:	f3 0f 1e fa          	endbr64
    99c4:	48 8b 3f             	mov    (%rdi),%rdi
    99c7:	e9 e4 ec ff ff       	jmp    86b0 <f12>
    99cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000099d0 <e12>:
    99d0:	f3 0f 1e fa          	endbr64
    99d4:	53                   	push   %rbx
    99d5:	48 8b 1f             	mov    (%rdi),%rbx
    99d8:	48 89 df             	mov    %rbx,%rdi
    99db:	e8 80 ce ff ff       	call   6860 <fwp_rc_share>
    99e0:	48 89 df             	mov    %rbx,%rdi
    99e3:	e8 c8 ec ff ff       	call   86b0 <f12>
    99e8:	48 89 c3             	mov    %rax,%rbx
    99eb:	48 89 c7             	mov    %rax,%rdi
    99ee:	e8 6d ce ff ff       	call   6860 <fwp_rc_share>
    99f3:	48 89 d8             	mov    %rbx,%rax
    99f6:	5b                   	pop    %rbx
    99f7:	c3                   	ret
    99f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    99ff:	00 

0000000000009a00 <fwp_write>:
    9a00:	41 57                	push   %r15
    9a02:	41 56                	push   %r14
    9a04:	41 55                	push   %r13
    9a06:	41 54                	push   %r12
    9a08:	55                   	push   %rbp
    9a09:	53                   	push   %rbx
    9a0a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9a11:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9a18:	00 00 
    9a1a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9a21:	00 
    9a22:	49 89 d4             	mov    %rdx,%r12
    9a25:	8b 12                	mov    (%rdx),%edx
    9a27:	83 fa 19             	cmp    $0x19,%edx
    9a2a:	77 6a                	ja     9a96 <fwp_write+0x96>
    9a2c:	48 89 f5             	mov    %rsi,%rbp
    9a2f:	89 d0                	mov    %edx,%eax
    9a31:	89 ce                	mov    %ecx,%esi
    9a33:	48 89 fb             	mov    %rdi,%rbx
    9a36:	48 8d 0d c3 60 00 00 	lea    0x60c3(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    9a3d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9a41:	48 01 c8             	add    %rcx,%rax
    9a44:	3e ff e0             	notrack jmp *%rax
    9a47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a4e:	00 00 
    9a50:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9a54:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9a58:	48 89 ca             	mov    %rcx,%rdx
    9a5b:	48 85 c9             	test   %rcx,%rcx
    9a5e:	0f 88 9c 0c 00 00    	js     a700 <fwp_write+0xd00>
    9a64:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a6b:	00 
    9a6c:	48 89 c6             	mov    %rax,%rsi
    9a6f:	4c 89 e7             	mov    %r12,%rdi
    9a72:	e8 c9 9f ff ff       	call   3a40 <fwp_fmt_u128>
    9a77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a7e:	00 00 
    9a80:	4c 89 e7             	mov    %r12,%rdi
    9a83:	e8 c8 99 ff ff       	call   3450 <strlen@plt>
    9a88:	4c 89 e6             	mov    %r12,%rsi
    9a8b:	48 89 df             	mov    %rbx,%rdi
    9a8e:	48 89 c2             	mov    %rax,%rdx
    9a91:	e8 7a a7 ff ff       	call   4210 <buf_put>
    9a96:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9a9d:	00 
    9a9e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9aa5:	00 00 
    9aa7:	0f 85 28 04 00 00    	jne    9ed5 <fwp_write+0x4d5>
    9aad:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9ab4:	5b                   	pop    %rbx
    9ab5:	5d                   	pop    %rbp
    9ab6:	41 5c                	pop    %r12
    9ab8:	41 5d                	pop    %r13
    9aba:	41 5e                	pop    %r14
    9abc:	41 5f                	pop    %r15
    9abe:	c3                   	ret
    9abf:	90                   	nop
    9ac0:	49 89 e9             	mov    %rbp,%r9
    9ac3:	4c 8d 05 ab 55 00 00 	lea    0x55ab(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    9aca:	b9 00 02 00 00       	mov    $0x200,%ecx
    9acf:	ba 02 00 00 00       	mov    $0x2,%edx
    9ad4:	be 00 02 00 00       	mov    $0x200,%esi
    9ad9:	31 c0                	xor    %eax,%eax
    9adb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9ae2:	00 
    9ae3:	e8 c8 98 ff ff       	call   33b0 <__snprintf_chk@plt>
    9ae8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9aef:	00 
    9af0:	e8 5b 99 ff ff       	call   3450 <strlen@plt>
    9af5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9afc:	00 
    9afd:	48 89 df             	mov    %rbx,%rdi
    9b00:	48 89 c2             	mov    %rax,%rdx
    9b03:	e8 08 a7 ff ff       	call   4210 <buf_put>
    9b08:	eb 8c                	jmp    9a96 <fwp_write+0x96>
    9b0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b10:	49 89 e9             	mov    %rbp,%r9
    9b13:	4c 8d 05 c5 56 00 00 	lea    0x56c5(%rip),%r8        # f1df <_IO_stdin_used+0x1df>
    9b1a:	eb ae                	jmp    9aca <fwp_write+0xca>
    9b1c:	0f 1f 40 00          	nopl   0x0(%rax)
    9b20:	83 fa 13             	cmp    $0x13,%edx
    9b23:	48 8d 05 ab 56 00 00 	lea    0x56ab(%rip),%rax        # f1d5 <_IO_stdin_used+0x1d5>
    9b2a:	48 8d 35 a9 56 00 00 	lea    0x56a9(%rip),%rsi        # f1da <_IO_stdin_used+0x1da>
    9b31:	ba 04 00 00 00       	mov    $0x4,%edx
    9b36:	48 0f 44 f0          	cmove  %rax,%rsi
    9b3a:	45 31 ed             	xor    %r13d,%r13d
    9b3d:	e8 ce a6 ff ff       	call   4210 <buf_put>
    9b42:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9b47:	0f 84 a3 08 00 00    	je     a3f0 <fwp_write+0x9f0>
    9b4d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9b52:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9b57:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9b5c:	48 89 df             	mov    %rbx,%rdi
    9b5f:	49 0f 44 c5          	cmove  %r13,%rax
    9b63:	31 c9                	xor    %ecx,%ecx
    9b65:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9b6a:	e8 91 fe ff ff       	call   9a00 <fwp_write>
    9b6f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9b74:	0f 84 6e 09 00 00    	je     a4e8 <fwp_write+0xae8>
    9b7a:	49 83 c5 01          	add    $0x1,%r13
    9b7e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9b82:	0f 83 68 08 00 00    	jae    a3f0 <fwp_write+0x9f0>
    9b88:	ba 02 00 00 00       	mov    $0x2,%edx
    9b8d:	48 8d 35 8b 56 00 00 	lea    0x568b(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9b94:	48 89 df             	mov    %rbx,%rdi
    9b97:	e8 74 a6 ff ff       	call   4210 <buf_put>
    9b9c:	eb af                	jmp    9b4d <fwp_write+0x14d>
    9b9e:	66 90                	xchg   %ax,%ax
    9ba0:	ba 06 00 00 00       	mov    $0x6,%edx
    9ba5:	48 8d 35 4c 56 00 00 	lea    0x564c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    9bac:	48 83 c5 10          	add    $0x10,%rbp
    9bb0:	e8 5b a6 ff ff       	call   4210 <buf_put>
    9bb5:	48 89 ef             	mov    %rbp,%rdi
    9bb8:	e8 93 98 ff ff       	call   3450 <strlen@plt>
    9bbd:	48 89 ee             	mov    %rbp,%rsi
    9bc0:	48 89 df             	mov    %rbx,%rdi
    9bc3:	48 89 c2             	mov    %rax,%rdx
    9bc6:	e8 45 a6 ff ff       	call   4210 <buf_put>
    9bcb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9bd0:	ba 01 00 00 00       	mov    $0x1,%edx
    9bd5:	48 89 df             	mov    %rbx,%rdi
    9bd8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9bdd:	e8 2e a6 ff ff       	call   4210 <buf_put>
    9be2:	e9 af fe ff ff       	jmp    9a96 <fwp_write+0x96>
    9be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9bee:	00 00 
    9bf0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9bf7:	00 
    9bf8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9bff:	00 00 
    9c01:	0f 85 ce 02 00 00    	jne    9ed5 <fwp_write+0x4d5>
    9c07:	ba 0a 00 00 00       	mov    $0xa,%edx
    9c0c:	48 8d 35 d1 55 00 00 	lea    0x55d1(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    9c13:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9c1a:	48 89 df             	mov    %rbx,%rdi
    9c1d:	5b                   	pop    %rbx
    9c1e:	5d                   	pop    %rbp
    9c1f:	41 5c                	pop    %r12
    9c21:	41 5d                	pop    %r13
    9c23:	41 5e                	pop    %r14
    9c25:	41 5f                	pop    %r15
    9c27:	e9 e4 a5 ff ff       	jmp    4210 <buf_put>
    9c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c30:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9c35:	4d 85 ed             	test   %r13,%r13
    9c38:	0f 84 02 0c 00 00    	je     a840 <fwp_write+0xe40>
    9c3e:	48 8d 35 e7 55 00 00 	lea    0x55e7(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    9c45:	4c 89 ef             	mov    %r13,%rdi
    9c48:	e8 e3 98 ff ff       	call   3530 <strcmp@plt>
    9c4d:	41 89 c1             	mov    %eax,%r9d
    9c50:	85 c0                	test   %eax,%eax
    9c52:	0f 84 6c 0c 00 00    	je     a8c4 <fwp_write+0xec4>
    9c58:	4c 89 ef             	mov    %r13,%rdi
    9c5b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9c60:	e8 eb 97 ff ff       	call   3450 <strlen@plt>
    9c65:	4c 89 ee             	mov    %r13,%rsi
    9c68:	48 89 df             	mov    %rbx,%rdi
    9c6b:	48 89 c2             	mov    %rax,%rdx
    9c6e:	e8 9d a5 ff ff       	call   4210 <buf_put>
    9c73:	ba 01 00 00 00       	mov    $0x1,%edx
    9c78:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9c7d:	48 89 df             	mov    %rbx,%rdi
    9c80:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9c85:	e8 86 a5 ff ff       	call   4210 <buf_put>
    9c8a:	ba 01 00 00 00       	mov    $0x1,%edx
    9c8f:	4c 89 fe             	mov    %r15,%rsi
    9c92:	48 89 df             	mov    %rbx,%rdi
    9c95:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9c9a:	e8 71 a5 ff ff       	call   4210 <buf_put>
    9c9f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9ca4:	45 31 f6             	xor    %r14d,%r14d
    9ca7:	85 d2                	test   %edx,%edx
    9ca9:	0f 8e 81 0a 00 00    	jle    a730 <fwp_write+0xd30>
    9caf:	45 31 ed             	xor    %r13d,%r13d
    9cb2:	4d 85 ed             	test   %r13,%r13
    9cb5:	0f 85 75 07 00 00    	jne    a430 <fwp_write+0xa30>
    9cbb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9cc2:	00 
    9cc3:	45 85 f6             	test   %r14d,%r14d
    9cc6:	0f 84 84 07 00 00    	je     a450 <fwp_write+0xa50>
    9ccc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9cd1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9cd6:	48 89 df             	mov    %rbx,%rdi
    9cd9:	49 83 c5 01          	add    $0x1,%r13
    9cdd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9ce1:	31 c9                	xor    %ecx,%ecx
    9ce3:	e8 18 fd ff ff       	call   9a00 <fwp_write>
    9ce8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9ced:	7f c3                	jg     9cb2 <fwp_write+0x2b2>
    9cef:	45 85 f6             	test   %r14d,%r14d
    9cf2:	0f 84 38 0a 00 00    	je     a730 <fwp_write+0xd30>
    9cf8:	b8 29 00 00 00       	mov    $0x29,%eax
    9cfd:	ba 01 00 00 00       	mov    $0x1,%edx
    9d02:	4c 89 fe             	mov    %r15,%rsi
    9d05:	48 89 df             	mov    %rbx,%rdi
    9d08:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9d0c:	e8 ff a4 ff ff       	call   4210 <buf_put>
    9d11:	e9 80 fd ff ff       	jmp    9a96 <fwp_write+0x96>
    9d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9d1d:	00 00 00 
    9d20:	ba 01 00 00 00       	mov    $0x1,%edx
    9d25:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9d2a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9d2f:	e8 dc a4 ff ff       	call   4210 <buf_put>
    9d34:	48 85 ed             	test   %rbp,%rbp
    9d37:	0f 84 93 06 00 00    	je     a3d0 <fwp_write+0x9d0>
    9d3d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9d41:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9d46:	31 c9                	xor    %ecx,%ecx
    9d48:	48 89 df             	mov    %rbx,%rdi
    9d4b:	e8 b0 fc ff ff       	call   9a00 <fwp_write>
    9d50:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9d54:	48 85 ed             	test   %rbp,%rbp
    9d57:	0f 84 73 06 00 00    	je     a3d0 <fwp_write+0x9d0>
    9d5d:	ba 02 00 00 00       	mov    $0x2,%edx
    9d62:	48 8d 35 b6 54 00 00 	lea    0x54b6(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9d69:	48 89 df             	mov    %rbx,%rdi
    9d6c:	e8 9f a4 ff ff       	call   4210 <buf_put>
    9d71:	eb ca                	jmp    9d3d <fwp_write+0x33d>
    9d73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d78:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9d7c:	85 f6                	test   %esi,%esi
    9d7e:	0f 84 fc 07 00 00    	je     a580 <fwp_write+0xb80>
    9d84:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d8b:	00 
    9d8c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d93:	00 00 
    9d95:	0f 85 3a 01 00 00    	jne    9ed5 <fwp_write+0x4d5>
    9d9b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9d9f:	4c 89 ea             	mov    %r13,%rdx
    9da2:	e9 6c fe ff ff       	jmp    9c13 <fwp_write+0x213>
    9da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9dae:	00 00 
    9db0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9db5:	ba 01 00 00 00       	mov    $0x1,%edx
    9dba:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9dbf:	48 89 ee             	mov    %rbp,%rsi
    9dc2:	e8 49 a4 ff ff       	call   4210 <buf_put>
    9dc7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9dcc:	4c 89 e7             	mov    %r12,%rdi
    9dcf:	e8 7c 96 ff ff       	call   3450 <strlen@plt>
    9dd4:	4c 89 e6             	mov    %r12,%rsi
    9dd7:	48 89 df             	mov    %rbx,%rdi
    9dda:	48 89 c2             	mov    %rax,%rdx
    9ddd:	e8 2e a4 ff ff       	call   4210 <buf_put>
    9de2:	ba 01 00 00 00       	mov    $0x1,%edx
    9de7:	48 89 ee             	mov    %rbp,%rsi
    9dea:	48 89 df             	mov    %rbx,%rdi
    9ded:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9df2:	e8 19 a4 ff ff       	call   4210 <buf_put>
    9df7:	e9 9a fc ff ff       	jmp    9a96 <fwp_write+0x96>
    9dfc:	0f 1f 40 00          	nopl   0x0(%rax)
    9e00:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9e05:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9e09:	0f 8a 8e 0b 00 00    	jp     a99d <fwp_write+0xf9d>
    9e0f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e13:	66 0f 54 05 e5 5d 00 	andpd  0x5de5(%rip),%xmm0        # fc00 <msg.4+0x90>
    9e1a:	00 
    9e1b:	bd 01 00 00 00       	mov    $0x1,%ebp
    9e20:	66 0f 2e 05 10 5e 00 	ucomisd 0x5e10(%rip),%xmm0        # fc38 <msg.4+0xc8>
    9e27:	00 
    9e28:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9e2f:	00 
    9e30:	0f 87 b2 09 00 00    	ja     a7e8 <fwp_write+0xde8>
    9e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e3d:	00 00 00 
    9e40:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e44:	89 ee                	mov    %ebp,%esi
    9e46:	4c 89 e7             	mov    %r12,%rdi
    9e49:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9e4e:	e8 bd a8 ff ff       	call   4710 <fwp_format_g.constprop.0>
    9e53:	31 f6                	xor    %esi,%esi
    9e55:	4c 89 e7             	mov    %r12,%rdi
    9e58:	e8 b3 95 ff ff       	call   3410 <strtod@plt>
    9e5d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9e62:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9e66:	7a 06                	jp     9e6e <fwp_write+0x46e>
    9e68:	0f 84 e9 01 00 00    	je     a057 <fwp_write+0x657>
    9e6e:	83 c5 01             	add    $0x1,%ebp
    9e71:	83 fd 12             	cmp    $0x12,%ebp
    9e74:	75 ca                	jne    9e40 <fwp_write+0x440>
    9e76:	be 11 00 00 00       	mov    $0x11,%esi
    9e7b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e7f:	4c 89 e7             	mov    %r12,%rdi
    9e82:	e8 89 a8 ff ff       	call   4710 <fwp_format_g.constprop.0>
    9e87:	e9 cb 01 00 00       	jmp    a057 <fwp_write+0x657>
    9e8c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e90:	48 83 fd 01          	cmp    $0x1,%rbp
    9e94:	0f 84 e6 08 00 00    	je     a780 <fwp_write+0xd80>
    9e9a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9e9e:	b8 02 00 00 00       	mov    $0x2,%eax
    9ea3:	ba 01 00 00 00       	mov    $0x1,%edx
    9ea8:	48 0f 44 d0          	cmove  %rax,%rdx
    9eac:	48 8d 35 1a 53 00 00 	lea    0x531a(%rip),%rsi        # f1cd <_IO_stdin_used+0x1cd>
    9eb3:	48 8d 05 18 53 00 00 	lea    0x5318(%rip),%rax        # f1d2 <_IO_stdin_used+0x1d2>
    9eba:	48 0f 44 f0          	cmove  %rax,%rsi
    9ebe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9ec5:	00 
    9ec6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9ecd:	00 00 
    9ecf:	0f 84 3e fd ff ff    	je     9c13 <fwp_write+0x213>
    9ed5:	e8 86 95 ff ff       	call   3460 <__stack_chk_fail@plt>
    9eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ee0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9ee5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9eea:	e8 61 a2 ff ff       	call   4150 <buf_grow>
    9eef:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9ef3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9ef9:	4c 03 0b             	add    (%rbx),%r9
    9efc:	66 45 89 11          	mov    %r10w,(%r9)
    9f00:	45 85 e4             	test   %r12d,%r12d
    9f03:	0f 8e 07 05 00 00    	jle    a410 <fwp_write+0xa10>
    9f09:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9f10:	55 55 55 
    9f13:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9f18:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9f1f:	aa aa aa 
    9f22:	49 83 c1 01          	add    $0x1,%r9
    9f26:	eb 45                	jmp    9f6d <fwp_write+0x56d>
    9f28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f2f:	00 
    9f30:	be 01 00 00 00       	mov    $0x1,%esi
    9f35:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9f3a:	88 07                	mov    %al,(%rdi)
    9f3c:	48 89 e8             	mov    %rbp,%rax
    9f3f:	49 f7 e8             	imul   %r8
    9f42:	48 89 e8             	mov    %rbp,%rax
    9f45:	48 c1 f8 3f          	sar    $0x3f,%rax
    9f49:	48 29 c2             	sub    %rax,%rdx
    9f4c:	48 85 c9             	test   %rcx,%rcx
    9f4f:	0f 95 c0             	setne  %al
    9f52:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9f56:	48 83 ef 01          	sub    $0x1,%rdi
    9f5a:	48 21 c5             	and    %rax,%rbp
    9f5d:	48 29 ea             	sub    %rbp,%rdx
    9f60:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9f64:	49 39 f9             	cmp    %rdi,%r9
    9f67:	0f 84 a3 04 00 00    	je     a410 <fwp_write+0xa10>
    9f6d:	48 89 e8             	mov    %rbp,%rax
    9f70:	49 f7 e8             	imul   %r8
    9f73:	48 89 e8             	mov    %rbp,%rax
    9f76:	48 c1 f8 3f          	sar    $0x3f,%rax
    9f7a:	48 89 d1             	mov    %rdx,%rcx
    9f7d:	48 29 c1             	sub    %rax,%rcx
    9f80:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9f84:	48 89 e9             	mov    %rbp,%rcx
    9f87:	48 29 c1             	sub    %rax,%rcx
    9f8a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9f8e:	49 f7 e2             	mul    %r10
    9f91:	b8 30 00 00 00       	mov    $0x30,%eax
    9f96:	48 89 d6             	mov    %rdx,%rsi
    9f99:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9f9d:	48 d1 ee             	shr    $1,%rsi
    9fa0:	48 01 f2             	add    %rsi,%rdx
    9fa3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9fa7:	48 29 d6             	sub    %rdx,%rsi
    9faa:	74 8e                	je     9f3a <fwp_write+0x53a>
    9fac:	48 83 fe 01          	cmp    $0x1,%rsi
    9fb0:	0f 85 7a ff ff ff    	jne    9f30 <fwp_write+0x530>
    9fb6:	31 f6                	xor    %esi,%esi
    9fb8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9fbd:	e9 78 ff ff ff       	jmp    9f3a <fwp_write+0x53a>
    9fc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9fc8:	66 0f 6e cd          	movd   %ebp,%xmm1
    9fcc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9fcf:	0f 8a c8 09 00 00    	jp     a99d <fwp_write+0xf9d>
    9fd5:	0f 28 c1             	movaps %xmm1,%xmm0
    9fd8:	0f 54 05 11 5c 00 00 	andps  0x5c11(%rip),%xmm0        # fbf0 <msg.4+0x80>
    9fdf:	0f 2e 05 1e 50 00 00 	ucomiss 0x501e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    9fe6:	0f 87 24 08 00 00    	ja     a810 <fwp_write+0xe10>
    9fec:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9ff0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9ff6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9ffd:	00 
    9ffe:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a002:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a00e:	00 00 
    a010:	44 89 ee             	mov    %r13d,%esi
    a013:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a018:	4c 89 e7             	mov    %r12,%rdi
    a01b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a020:	e8 eb a6 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a025:	31 f6                	xor    %esi,%esi
    a027:	4c 89 e7             	mov    %r12,%rdi
    a02a:	e8 81 94 ff ff       	call   34b0 <strtof@plt>
    a02f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a034:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a037:	7a 02                	jp     a03b <fwp_write+0x63b>
    a039:	74 1c                	je     a057 <fwp_write+0x657>
    a03b:	41 83 c5 01          	add    $0x1,%r13d
    a03f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a043:	75 cb                	jne    a010 <fwp_write+0x610>
    a045:	be 09 00 00 00       	mov    $0x9,%esi
    a04a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a04f:	4c 89 e7             	mov    %r12,%rdi
    a052:	e8 b9 a6 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a057:	4c 89 e7             	mov    %r12,%rdi
    a05a:	e8 21 a3 ff ff       	call   4380 <fwp_finish_float>
    a05f:	e9 1c fa ff ff       	jmp    9a80 <fwp_write+0x80>
    a064:	0f 1f 40 00          	nopl   0x0(%rax)
    a068:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a06c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a070:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a077:	00 
    a078:	48 89 ef             	mov    %rbp,%rdi
    a07b:	e8 c0 99 ff ff       	call   3a40 <fwp_fmt_u128>
    a080:	48 89 ef             	mov    %rbp,%rdi
    a083:	e8 c8 93 ff ff       	call   3450 <strlen@plt>
    a088:	48 89 ee             	mov    %rbp,%rsi
    a08b:	48 89 df             	mov    %rbx,%rdi
    a08e:	48 89 c2             	mov    %rax,%rdx
    a091:	e8 7a a1 ff ff       	call   4210 <buf_put>
    a096:	e9 fb f9 ff ff       	jmp    9a96 <fwp_write+0x96>
    a09b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a0a0:	ba 06 00 00 00       	mov    $0x6,%edx
    a0a5:	48 8d 35 76 51 00 00 	lea    0x5176(%rip),%rsi        # f222 <_IO_stdin_used+0x222>
    a0ac:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a0b2:	e8 59 a1 ff ff       	call   4210 <buf_put>
    a0b7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a0be:	ff ff 7f 
    a0c1:	48 23 55 00          	and    0x0(%rbp),%rdx
    a0c5:	0f 84 86 02 00 00    	je     a351 <fwp_write+0x951>
    a0cb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a0d0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a0d4:	48 85 d2             	test   %rdx,%rdx
    a0d7:	0f 84 ae 00 00 00    	je     a18b <fwp_write+0x78b>
    a0dd:	8b 0a                	mov    (%rdx),%ecx
    a0df:	83 f9 1c             	cmp    $0x1c,%ecx
    a0e2:	0f 84 58 06 00 00    	je     a740 <fwp_write+0xd40>
    a0e8:	83 f9 1b             	cmp    $0x1b,%ecx
    a0eb:	0f 87 9a 00 00 00    	ja     a18b <fwp_write+0x78b>
    a0f1:	be 01 00 00 00       	mov    $0x1,%esi
    a0f6:	48 d3 e6             	shl    %cl,%rsi
    a0f9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a0ff:	0f 85 4b 04 00 00    	jne    a550 <fwp_write+0xb50>
    a105:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a10b:	0f 85 0f 04 00 00    	jne    a520 <fwp_write+0xb20>
    a111:	83 e6 21             	and    $0x21,%esi
    a114:	74 75                	je     a18b <fwp_write+0x78b>
    a116:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a11b:	48 85 ff             	test   %rdi,%rdi
    a11e:	79 07                	jns    a127 <fwp_write+0x727>
    a120:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a124:	4c 01 ee             	add    %r13,%rsi
    a127:	48 0f be 3e          	movsbq (%rsi),%rdi
    a12b:	85 c9                	test   %ecx,%ecx
    a12d:	40 0f b6 f7          	movzbl %dil,%esi
    a131:	48 0f 44 f7          	cmove  %rdi,%rsi
    a135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a13c:	00 00 00 00 
    a140:	31 c9                	xor    %ecx,%ecx
    a142:	48 89 df             	mov    %rbx,%rdi
    a145:	49 83 c5 01          	add    $0x1,%r13
    a149:	e8 b2 f8 ff ff       	call   9a00 <fwp_write>
    a14e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a155:	ff ff 7f 
    a158:	48 23 55 00          	and    0x0(%rbp),%rdx
    a15c:	49 39 d5             	cmp    %rdx,%r13
    a15f:	0f 83 ec 01 00 00    	jae    a351 <fwp_write+0x951>
    a165:	ba 02 00 00 00       	mov    $0x2,%edx
    a16a:	48 89 df             	mov    %rbx,%rdi
    a16d:	48 8d 35 ab 50 00 00 	lea    0x50ab(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a174:	e8 97 a0 ff ff       	call   4210 <buf_put>
    a179:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a17e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a182:	48 85 d2             	test   %rdx,%rdx
    a185:	0f 85 52 ff ff ff    	jne    a0dd <fwp_write+0x6dd>
    a18b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a190:	48 85 ff             	test   %rdi,%rdi
    a193:	0f 88 cf 05 00 00    	js     a768 <fwp_write+0xd68>
    a199:	48 8b 31             	mov    (%rcx),%rsi
    a19c:	eb a2                	jmp    a140 <fwp_write+0x740>
    a19e:	66 90                	xchg   %ax,%ax
    a1a0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a1a7:	00 
    a1a8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a1af:	00 00 
    a1b1:	0f 85 1e fd ff ff    	jne    9ed5 <fwp_write+0x4d5>
    a1b7:	ba 08 00 00 00       	mov    $0x8,%edx
    a1bc:	48 8d 35 2c 50 00 00 	lea    0x502c(%rip),%rsi        # f1ef <_IO_stdin_used+0x1ef>
    a1c3:	e9 4b fa ff ff       	jmp    9c13 <fwp_write+0x213>
    a1c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1cf:	00 
    a1d0:	89 e8                	mov    %ebp,%eax
    a1d2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a1d9:	76 03                	jbe    a1de <fwp_write+0x7de>
    a1db:	8b 45 00             	mov    0x0(%rbp),%eax
    a1de:	41 89 c6             	mov    %eax,%r14d
    a1e1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a1e6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a1eb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a1ef:	4c 89 ef             	mov    %r13,%rdi
    a1f2:	e8 59 92 ff ff       	call   3450 <strlen@plt>
    a1f7:	4c 89 ee             	mov    %r13,%rsi
    a1fa:	48 89 df             	mov    %rbx,%rdi
    a1fd:	48 89 c2             	mov    %rax,%rdx
    a200:	e8 0b a0 ff ff       	call   4210 <buf_put>
    a205:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a20a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a20e:	85 f6                	test   %esi,%esi
    a210:	0f 8e 80 f8 ff ff    	jle    9a96 <fwp_write+0x96>
    a216:	45 31 ed             	xor    %r13d,%r13d
    a219:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a21e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a223:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a228:	ba 01 00 00 00       	mov    $0x1,%edx
    a22d:	4c 89 fe             	mov    %r15,%rsi
    a230:	48 89 04 24          	mov    %rax,(%rsp)
    a234:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a239:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a23d:	48 89 df             	mov    %rbx,%rdi
    a240:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a244:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a249:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a24e:	e8 bd 9f ff ff       	call   4210 <buf_put>
    a253:	41 8b 06             	mov    (%r14),%eax
    a256:	83 f8 0e             	cmp    $0xe,%eax
    a259:	0f 84 71 02 00 00    	je     a4d0 <fwp_write+0xad0>
    a25f:	83 f8 10             	cmp    $0x10,%eax
    a262:	0f 84 38 02 00 00    	je     a4a0 <fwp_write+0xaa0>
    a268:	83 f8 0a             	cmp    $0xa,%eax
    a26b:	0f 84 7f 04 00 00    	je     a6f0 <fwp_write+0xcf0>
    a271:	0f 8f f9 00 00 00    	jg     a370 <fwp_write+0x970>
    a277:	83 f8 03             	cmp    $0x3,%eax
    a27a:	0f 8f 50 04 00 00    	jg     a6d0 <fwp_write+0xcd0>
    a280:	85 c0                	test   %eax,%eax
    a282:	78 10                	js     a294 <fwp_write+0x894>
    a284:	48 8b 04 24          	mov    (%rsp),%rax
    a288:	48 c1 e8 3f          	shr    $0x3f,%rax
    a28c:	85 c0                	test   %eax,%eax
    a28e:	0f 85 f9 00 00 00    	jne    a38d <fwp_write+0x98d>
    a294:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a299:	48 8b 34 24          	mov    (%rsp),%rsi
    a29d:	31 c9                	xor    %ecx,%ecx
    a29f:	48 89 df             	mov    %rbx,%rdi
    a2a2:	e8 59 f7 ff ff       	call   9a00 <fwp_write>
    a2a7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a2ac:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a2b1:	49 83 c5 01          	add    $0x1,%r13
    a2b5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a2b9:	0f 8f 5f ff ff ff    	jg     a21e <fwp_write+0x81e>
    a2bf:	e9 d2 f7 ff ff       	jmp    9a96 <fwp_write+0x96>
    a2c4:	0f 1f 40 00          	nopl   0x0(%rax)
    a2c8:	ba 06 00 00 00       	mov    $0x6,%edx
    a2cd:	48 8d 35 41 4f 00 00 	lea    0x4f41(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    a2d4:	45 31 ed             	xor    %r13d,%r13d
    a2d7:	e8 34 9f ff ff       	call   4210 <buf_put>
    a2dc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a2e1:	75 19                	jne    a2fc <fwp_write+0x8fc>
    a2e3:	eb 6c                	jmp    a351 <fwp_write+0x951>
    a2e5:	0f 1f 00             	nopl   (%rax)
    a2e8:	ba 02 00 00 00       	mov    $0x2,%edx
    a2ed:	48 8d 35 2b 4f 00 00 	lea    0x4f2b(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a2f4:	48 89 df             	mov    %rbx,%rdi
    a2f7:	e8 14 9f ff ff       	call   4210 <buf_put>
    a2fc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a302:	b9 00 02 00 00       	mov    $0x200,%ecx
    a307:	31 c0                	xor    %eax,%eax
    a309:	49 83 c5 01          	add    $0x1,%r13
    a30d:	4c 8d 05 08 4f 00 00 	lea    0x4f08(%rip),%r8        # f21c <_IO_stdin_used+0x21c>
    a314:	ba 02 00 00 00       	mov    $0x2,%edx
    a319:	be 00 02 00 00       	mov    $0x200,%esi
    a31e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a325:	00 
    a326:	e8 85 90 ff ff       	call   33b0 <__snprintf_chk@plt>
    a32b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a332:	00 
    a333:	e8 18 91 ff ff       	call   3450 <strlen@plt>
    a338:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a33f:	00 
    a340:	48 89 df             	mov    %rbx,%rdi
    a343:	48 89 c2             	mov    %rax,%rdx
    a346:	e8 c5 9e ff ff       	call   4210 <buf_put>
    a34b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a34f:	72 97                	jb     a2e8 <fwp_write+0x8e8>
    a351:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a356:	ba 01 00 00 00       	mov    $0x1,%edx
    a35b:	48 89 df             	mov    %rbx,%rdi
    a35e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a363:	e8 a8 9e ff ff       	call   4210 <buf_put>
    a368:	e9 29 f7 ff ff       	jmp    9a96 <fwp_write+0x96>
    a36d:	0f 1f 00             	nopl   (%rax)
    a370:	83 f8 0b             	cmp    $0xb,%eax
    a373:	0f 85 1b ff ff ff    	jne    a294 <fwp_write+0x894>
    a379:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a37e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a382:	83 e0 01             	and    $0x1,%eax
    a385:	85 c0                	test   %eax,%eax
    a387:	0f 84 07 ff ff ff    	je     a294 <fwp_write+0x894>
    a38d:	4c 89 fe             	mov    %r15,%rsi
    a390:	48 89 df             	mov    %rbx,%rdi
    a393:	ba 01 00 00 00       	mov    $0x1,%edx
    a398:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a39d:	e8 6e 9e ff ff       	call   4210 <buf_put>
    a3a2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a3a7:	48 8b 34 24          	mov    (%rsp),%rsi
    a3ab:	31 c9                	xor    %ecx,%ecx
    a3ad:	48 89 df             	mov    %rbx,%rdi
    a3b0:	e8 4b f6 ff ff       	call   9a00 <fwp_write>
    a3b5:	ba 01 00 00 00       	mov    $0x1,%edx
    a3ba:	4c 89 fe             	mov    %r15,%rsi
    a3bd:	48 89 df             	mov    %rbx,%rdi
    a3c0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a3c5:	e8 46 9e ff ff       	call   4210 <buf_put>
    a3ca:	e9 d8 fe ff ff       	jmp    a2a7 <fwp_write+0x8a7>
    a3cf:	90                   	nop
    a3d0:	ba 01 00 00 00       	mov    $0x1,%edx
    a3d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a3da:	48 89 df             	mov    %rbx,%rdi
    a3dd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a3e2:	e8 29 9e ff ff       	call   4210 <buf_put>
    a3e7:	e9 aa f6 ff ff       	jmp    9a96 <fwp_write+0x96>
    a3ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a3f0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a3f5:	ba 01 00 00 00       	mov    $0x1,%edx
    a3fa:	48 89 df             	mov    %rbx,%rdi
    a3fd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a402:	e8 09 9e ff ff       	call   4210 <buf_put>
    a407:	e9 8a f6 ff ff       	jmp    9a96 <fwp_write+0x96>
    a40c:	0f 1f 40 00          	nopl   0x0(%rax)
    a410:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a414:	48 8b 13             	mov    (%rbx),%rdx
    a417:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a41c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a420:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a424:	e9 6d f6 ff ff       	jmp    9a96 <fwp_write+0x96>
    a429:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a430:	ba 02 00 00 00       	mov    $0x2,%edx
    a435:	48 8d 35 e3 4d 00 00 	lea    0x4de3(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a43c:	48 89 df             	mov    %rbx,%rdi
    a43f:	e8 cc 9d ff ff       	call   4210 <buf_put>
    a444:	e9 72 f8 ff ff       	jmp    9cbb <fwp_write+0x2bb>
    a449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a450:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a455:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a45a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a45e:	48 89 f7             	mov    %rsi,%rdi
    a461:	48 89 34 24          	mov    %rsi,(%rsp)
    a465:	e8 e6 8f ff ff       	call   3450 <strlen@plt>
    a46a:	48 8b 34 24          	mov    (%rsp),%rsi
    a46e:	48 89 df             	mov    %rbx,%rdi
    a471:	48 89 c2             	mov    %rax,%rdx
    a474:	e8 97 9d ff ff       	call   4210 <buf_put>
    a479:	ba 03 00 00 00       	mov    $0x3,%edx
    a47e:	48 8d 35 bd 4d 00 00 	lea    0x4dbd(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    a485:	48 89 df             	mov    %rbx,%rdi
    a488:	e8 83 9d ff ff       	call   4210 <buf_put>
    a48d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a492:	e9 35 f8 ff ff       	jmp    9ccc <fwp_write+0x2cc>
    a497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a49e:	00 00 
    a4a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a4a5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a4a9:	48 85 ff             	test   %rdi,%rdi
    a4ac:	0f 84 e2 fd ff ff    	je     a294 <fwp_write+0x894>
    a4b2:	48 8d 35 73 4d 00 00 	lea    0x4d73(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    a4b9:	e8 72 90 ff ff       	call   3530 <strcmp@plt>
    a4be:	85 c0                	test   %eax,%eax
    a4c0:	0f 95 c0             	setne  %al
    a4c3:	0f b6 c0             	movzbl %al,%eax
    a4c6:	e9 c1 fd ff ff       	jmp    a28c <fwp_write+0x88c>
    a4cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4d0:	31 c0                	xor    %eax,%eax
    a4d2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a4d9:	00 
    a4da:	0f 97 c0             	seta   %al
    a4dd:	e9 aa fd ff ff       	jmp    a28c <fwp_write+0x88c>
    a4e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4e8:	48 89 df             	mov    %rbx,%rdi
    a4eb:	ba 02 00 00 00       	mov    $0x2,%edx
    a4f0:	48 8d 35 32 4d 00 00 	lea    0x4d32(%rip),%rsi        # f229 <_IO_stdin_used+0x229>
    a4f7:	e8 14 9d ff ff       	call   4210 <buf_put>
    a4fc:	4c 89 e8             	mov    %r13,%rax
    a4ff:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a504:	31 c9                	xor    %ecx,%ecx
    a506:	48 c1 e0 04          	shl    $0x4,%rax
    a50a:	48 89 df             	mov    %rbx,%rdi
    a50d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a512:	e8 e9 f4 ff ff       	call   9a00 <fwp_write>
    a517:	e9 5e f6 ff ff       	jmp    9b7a <fwp_write+0x17a>
    a51c:	0f 1f 40 00          	nopl   0x0(%rax)
    a520:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a525:	48 85 ff             	test   %rdi,%rdi
    a528:	79 0c                	jns    a536 <fwp_write+0xb36>
    a52a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a531:	00 
    a532:	48 03 75 10          	add    0x10(%rbp),%rsi
    a536:	48 63 3e             	movslq (%rsi),%rdi
    a539:	83 f9 02             	cmp    $0x2,%ecx
    a53c:	89 fe                	mov    %edi,%esi
    a53e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a542:	e9 f9 fb ff ff       	jmp    a140 <fwp_write+0x740>
    a547:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a54e:	00 00 
    a550:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a555:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a55a:	48 85 ff             	test   %rdi,%rdi
    a55d:	0f 88 0f 03 00 00    	js     a872 <fwp_write+0xe72>
    a563:	49 0f bf 38          	movswq (%r8),%rdi
    a567:	83 f9 01             	cmp    $0x1,%ecx
    a56a:	0f b7 f7             	movzwl %di,%esi
    a56d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a571:	e9 ca fb ff ff       	jmp    a140 <fwp_write+0x740>
    a576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a57d:	00 00 00 
    a580:	ba 01 00 00 00       	mov    $0x1,%edx
    a585:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a58a:	48 83 c5 08          	add    $0x8,%rbp
    a58e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a593:	e8 78 9c ff ff       	call   4210 <buf_put>
    a598:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a59d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a5a2:	4d 85 ed             	test   %r13,%r13
    a5a5:	75 46                	jne    a5ed <fwp_write+0xbed>
    a5a7:	e9 04 01 00 00       	jmp    a6b0 <fwp_write+0xcb0>
    a5ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a5b0:	41 80 f9 09          	cmp    $0x9,%r9b
    a5b4:	0f 84 d6 00 00 00    	je     a690 <fwp_write+0xc90>
    a5ba:	41 80 f9 0a          	cmp    $0xa,%r9b
    a5be:	0f 85 9c 00 00 00    	jne    a660 <fwp_write+0xc60>
    a5c4:	ba 02 00 00 00       	mov    $0x2,%edx
    a5c9:	48 8d 35 35 4c 00 00 	lea    0x4c35(%rip),%rsi        # f205 <_IO_stdin_used+0x205>
    a5d0:	48 89 df             	mov    %rbx,%rdi
    a5d3:	e8 38 9c ff ff       	call   4210 <buf_put>
    a5d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a5df:	00 
    a5e0:	48 83 c5 01          	add    $0x1,%rbp
    a5e4:	49 39 ec             	cmp    %rbp,%r12
    a5e7:	0f 84 c3 00 00 00    	je     a6b0 <fwp_write+0xcb0>
    a5ed:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a5f2:	41 80 f9 0d          	cmp    $0xd,%r9b
    a5f6:	74 28                	je     a620 <fwp_write+0xc20>
    a5f8:	7e b6                	jle    a5b0 <fwp_write+0xbb0>
    a5fa:	41 80 f9 22          	cmp    $0x22,%r9b
    a5fe:	74 40                	je     a640 <fwp_write+0xc40>
    a600:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a604:	75 5a                	jne    a660 <fwp_write+0xc60>
    a606:	ba 02 00 00 00       	mov    $0x2,%edx
    a60b:	48 8d 35 f0 4b 00 00 	lea    0x4bf0(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    a612:	48 89 df             	mov    %rbx,%rdi
    a615:	e8 f6 9b ff ff       	call   4210 <buf_put>
    a61a:	eb c4                	jmp    a5e0 <fwp_write+0xbe0>
    a61c:	0f 1f 40 00          	nopl   0x0(%rax)
    a620:	ba 02 00 00 00       	mov    $0x2,%edx
    a625:	48 8d 35 df 4b 00 00 	lea    0x4bdf(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    a62c:	48 89 df             	mov    %rbx,%rdi
    a62f:	e8 dc 9b ff ff       	call   4210 <buf_put>
    a634:	eb aa                	jmp    a5e0 <fwp_write+0xbe0>
    a636:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a63d:	00 00 00 
    a640:	ba 02 00 00 00       	mov    $0x2,%edx
    a645:	48 8d 35 b3 4b 00 00 	lea    0x4bb3(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    a64c:	48 89 df             	mov    %rbx,%rdi
    a64f:	e8 bc 9b ff ff       	call   4210 <buf_put>
    a654:	eb 8a                	jmp    a5e0 <fwp_write+0xbe0>
    a656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a65d:	00 00 00 
    a660:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a664:	0f 86 2e 01 00 00    	jbe    a798 <fwp_write+0xd98>
    a66a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a66e:	0f 84 24 01 00 00    	je     a798 <fwp_write+0xd98>
    a674:	ba 01 00 00 00       	mov    $0x1,%edx
    a679:	4c 89 fe             	mov    %r15,%rsi
    a67c:	48 89 df             	mov    %rbx,%rdi
    a67f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a684:	e8 87 9b ff ff       	call   4210 <buf_put>
    a689:	e9 52 ff ff ff       	jmp    a5e0 <fwp_write+0xbe0>
    a68e:	66 90                	xchg   %ax,%ax
    a690:	ba 02 00 00 00       	mov    $0x2,%edx
    a695:	48 8d 35 6c 4b 00 00 	lea    0x4b6c(%rip),%rsi        # f208 <_IO_stdin_used+0x208>
    a69c:	48 89 df             	mov    %rbx,%rdi
    a69f:	e8 6c 9b ff ff       	call   4210 <buf_put>
    a6a4:	e9 37 ff ff ff       	jmp    a5e0 <fwp_write+0xbe0>
    a6a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6b0:	ba 01 00 00 00       	mov    $0x1,%edx
    a6b5:	4c 89 fe             	mov    %r15,%rsi
    a6b8:	48 89 df             	mov    %rbx,%rdi
    a6bb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a6c0:	e8 4b 9b ff ff       	call   4210 <buf_put>
    a6c5:	e9 cc f3 ff ff       	jmp    9a96 <fwp_write+0x96>
    a6ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6d0:	83 f8 04             	cmp    $0x4,%eax
    a6d3:	0f 85 bb fb ff ff    	jne    a294 <fwp_write+0x894>
    a6d9:	48 8b 04 24          	mov    (%rsp),%rax
    a6dd:	48 8b 40 08          	mov    0x8(%rax),%rax
    a6e1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a6e6:	48 c1 e8 3f          	shr    $0x3f,%rax
    a6ea:	e9 96 fc ff ff       	jmp    a385 <fwp_write+0x985>
    a6ef:	90                   	nop
    a6f0:	8b 0c 24             	mov    (%rsp),%ecx
    a6f3:	31 c0                	xor    %eax,%eax
    a6f5:	85 c9                	test   %ecx,%ecx
    a6f7:	0f 98 c0             	sets   %al
    a6fa:	e9 86 fc ff ff       	jmp    a385 <fwp_write+0x985>
    a6ff:	90                   	nop
    a700:	48 f7 d8             	neg    %rax
    a703:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a70a:	00 
    a70b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a712:	2d 
    a713:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a71a:	00 
    a71b:	48 83 d2 00          	adc    $0x0,%rdx
    a71f:	48 89 c6             	mov    %rax,%rsi
    a722:	48 f7 da             	neg    %rdx
    a725:	e8 16 93 ff ff       	call   3a40 <fwp_fmt_u128>
    a72a:	e9 51 f3 ff ff       	jmp    9a80 <fwp_write+0x80>
    a72f:	90                   	nop
    a730:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a735:	e9 c3 f5 ff ff       	jmp    9cfd <fwp_write+0x2fd>
    a73a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a740:	4c 89 e9             	mov    %r13,%rcx
    a743:	48 c1 e1 04          	shl    $0x4,%rcx
    a747:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a74c:	48 85 ff             	test   %rdi,%rdi
    a74f:	0f 89 eb f9 ff ff    	jns    a140 <fwp_write+0x740>
    a755:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a759:	48 89 ce             	mov    %rcx,%rsi
    a75c:	e9 df f9 ff ff       	jmp    a140 <fwp_write+0x740>
    a761:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a768:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a76f:	00 
    a770:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a774:	e9 20 fa ff ff       	jmp    a199 <fwp_write+0x799>
    a779:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a780:	ba 02 00 00 00       	mov    $0x2,%edx
    a785:	48 8d 35 43 4a 00 00 	lea    0x4a43(%rip),%rsi        # f1cf <_IO_stdin_used+0x1cf>
    a78c:	e9 2d f7 ff ff       	jmp    9ebe <fwp_write+0x4be>
    a791:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a798:	4c 8d 05 6f 4a 00 00 	lea    0x4a6f(%rip),%r8        # f20e <_IO_stdin_used+0x20e>
    a79f:	b9 10 00 00 00       	mov    $0x10,%ecx
    a7a4:	31 c0                	xor    %eax,%eax
    a7a6:	ba 02 00 00 00       	mov    $0x2,%edx
    a7ab:	be 10 00 00 00       	mov    $0x10,%esi
    a7b0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7b7:	00 
    a7b8:	e8 f3 8b ff ff       	call   33b0 <__snprintf_chk@plt>
    a7bd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7c4:	00 
    a7c5:	e8 86 8c ff ff       	call   3450 <strlen@plt>
    a7ca:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a7d1:	00 
    a7d2:	48 89 df             	mov    %rbx,%rdi
    a7d5:	48 89 c2             	mov    %rax,%rdx
    a7d8:	e8 33 9a ff ff       	call   4210 <buf_put>
    a7dd:	e9 fe fd ff ff       	jmp    a5e0 <fwp_write+0xbe0>
    a7e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7e8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a7ec:	48 8d 35 d6 49 00 00 	lea    0x49d6(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    a7f3:	48 8d 05 ce 49 00 00 	lea    0x49ce(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    a7fa:	4c 89 e7             	mov    %r12,%rdi
    a7fd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a801:	48 0f 46 f0          	cmovbe %rax,%rsi
    a805:	e8 e6 8b ff ff       	call   33f0 <strcpy@plt>
    a80a:	e9 71 f2 ff ff       	jmp    9a80 <fwp_write+0x80>
    a80f:	90                   	nop
    a810:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a814:	48 8d 35 ae 49 00 00 	lea    0x49ae(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    a81b:	48 8d 05 a6 49 00 00 	lea    0x49a6(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    a822:	0f 2f c8             	comiss %xmm0,%xmm1
    a825:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a82c:	00 
    a82d:	4c 89 e7             	mov    %r12,%rdi
    a830:	48 0f 46 f0          	cmovbe %rax,%rsi
    a834:	e8 b7 8b ff ff       	call   33f0 <strcpy@plt>
    a839:	e9 42 f2 ff ff       	jmp    9a80 <fwp_write+0x80>
    a83e:	66 90                	xchg   %ax,%ax
    a840:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a845:	45 85 c0             	test   %r8d,%r8d
    a848:	75 34                	jne    a87e <fwp_write+0xe7e>
    a84a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a851:	00 
    a852:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a859:	00 00 
    a85b:	0f 85 74 f6 ff ff    	jne    9ed5 <fwp_write+0x4d5>
    a861:	ba 02 00 00 00       	mov    $0x2,%edx
    a866:	48 8d 35 d2 49 00 00 	lea    0x49d2(%rip),%rsi        # f23f <_IO_stdin_used+0x23f>
    a86d:	e9 a1 f3 ff ff       	jmp    9c13 <fwp_write+0x213>
    a872:	48 03 75 10          	add    0x10(%rbp),%rsi
    a876:	49 89 f0             	mov    %rsi,%r8
    a879:	e9 e5 fc ff ff       	jmp    a563 <fwp_write+0xb63>
    a87e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a883:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a888:	85 ff                	test   %edi,%edi
    a88a:	0f 84 fa f3 ff ff    	je     9c8a <fwp_write+0x28a>
    a890:	ba 01 00 00 00       	mov    $0x1,%edx
    a895:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a89a:	48 89 df             	mov    %rbx,%rdi
    a89d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a8a2:	e8 69 99 ff ff       	call   4210 <buf_put>
    a8a7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a8ac:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a8b1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a8b7:	85 c0                	test   %eax,%eax
    a8b9:	0f 8f f0 f3 ff ff    	jg     9caf <fwp_write+0x2af>
    a8bf:	e9 34 f4 ff ff       	jmp    9cf8 <fwp_write+0x2f8>
    a8c4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a8c8:	49 89 c5             	mov    %rax,%r13
    a8cb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a8d0:	49 89 c4             	mov    %rax,%r12
    a8d3:	49 c1 fd 3f          	sar    $0x3f,%r13
    a8d7:	4c 09 e8             	or     %r13,%rax
    a8da:	0f 84 a7 00 00 00    	je     a987 <fwp_write+0xf87>
    a8e0:	48 8d 2d 19 6b 00 00 	lea    0x6b19(%rip),%rbp        # 11400 <units.1>
    a8e7:	4d 89 e7             	mov    %r12,%r15
    a8ea:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a8ee:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a8f3:	4c 89 ff             	mov    %r15,%rdi
    a8f6:	4c 89 ee             	mov    %r13,%rsi
    a8f9:	44 89 0c 24          	mov    %r9d,(%rsp)
    a8fd:	48 99                	cqto
    a8ff:	48 89 d1             	mov    %rdx,%rcx
    a902:	48 89 c2             	mov    %rax,%rdx
    a905:	e8 d6 41 00 00       	call   eae0 <__divmodti4>
    a90a:	44 8b 0c 24          	mov    (%rsp),%r9d
    a90e:	48 89 c1             	mov    %rax,%rcx
    a911:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a916:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a91b:	0f 84 94 00 00 00    	je     a9b5 <fwp_write+0xfb5>
    a921:	41 83 c1 01          	add    $0x1,%r9d
    a925:	48 83 c5 10          	add    $0x10,%rbp
    a929:	41 83 f9 05          	cmp    $0x5,%r9d
    a92d:	75 bb                	jne    a8ea <fwp_write+0xeea>
    a92f:	4d 85 ed             	test   %r13,%r13
    a932:	79 53                	jns    a987 <fwp_write+0xf87>
    a934:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a939:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a93e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a943:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a948:	48 99                	cqto
    a94a:	48 f7 d8             	neg    %rax
    a94d:	48 83 d2 00          	adc    $0x0,%rdx
    a951:	48 89 c6             	mov    %rax,%rsi
    a954:	48 f7 da             	neg    %rdx
    a957:	e8 e4 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a95c:	49 89 e8             	mov    %rbp,%r8
    a95f:	ba 00 02 00 00       	mov    $0x200,%edx
    a964:	be 02 00 00 00       	mov    $0x2,%esi
    a969:	31 c0                	xor    %eax,%eax
    a96b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a972:	00 
    a973:	48 8d 0d c0 48 00 00 	lea    0x48c0(%rip),%rcx        # f23a <_IO_stdin_used+0x23a>
    a97a:	4c 89 e7             	mov    %r12,%rdi
    a97d:	e8 5e 8d ff ff       	call   36e0 <__sprintf_chk@plt>
    a982:	e9 f9 f0 ff ff       	jmp    9a80 <fwp_write+0x80>
    a987:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a98c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a991:	31 d2                	xor    %edx,%edx
    a993:	48 89 ef             	mov    %rbp,%rdi
    a996:	e8 a5 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a99b:	eb bf                	jmp    a95c <fwp_write+0xf5c>
    a99d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a9a4:	4e 61 4e 00 
    a9a8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9af:	00 
    a9b0:	e9 cb f0 ff ff       	jmp    9a80 <fwp_write+0x80>
    a9b5:	44 89 0c 24          	mov    %r9d,(%rsp)
    a9b9:	48 89 c8             	mov    %rcx,%rax
    a9bc:	48 85 d2             	test   %rdx,%rdx
    a9bf:	78 51                	js     aa12 <fwp_write+0x1012>
    a9c1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a9c6:	48 89 c6             	mov    %rax,%rsi
    a9c9:	48 89 ef             	mov    %rbp,%rdi
    a9cc:	e8 6f 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9d1:	44 8b 0c 24          	mov    (%rsp),%r9d
    a9d5:	49 63 c1             	movslq %r9d,%rax
    a9d8:	49 89 e8             	mov    %rbp,%r8
    a9db:	ba 00 02 00 00       	mov    $0x200,%edx
    a9e0:	be 02 00 00 00       	mov    $0x2,%esi
    a9e5:	48 c1 e0 04          	shl    $0x4,%rax
    a9e9:	48 8d 3d 10 6a 00 00 	lea    0x6a10(%rip),%rdi        # 11400 <units.1>
    a9f0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9f7:	00 
    a9f8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    a9fc:	48 8d 0d 32 48 00 00 	lea    0x4832(%rip),%rcx        # f235 <_IO_stdin_used+0x235>
    aa03:	4c 89 e7             	mov    %r12,%rdi
    aa06:	31 c0                	xor    %eax,%eax
    aa08:	e8 d3 8c ff ff       	call   36e0 <__sprintf_chk@plt>
    aa0d:	e9 6e f0 ff ff       	jmp    9a80 <fwp_write+0x80>
    aa12:	48 f7 d8             	neg    %rax
    aa15:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    aa1a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    aa1f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aa24:	48 83 d2 00          	adc    $0x0,%rdx
    aa28:	48 89 c6             	mov    %rax,%rsi
    aa2b:	48 f7 da             	neg    %rdx
    aa2e:	e8 0d 90 ff ff       	call   3a40 <fwp_fmt_u128>
    aa33:	44 8b 0c 24          	mov    (%rsp),%r9d
    aa37:	eb 9c                	jmp    a9d5 <fwp_write+0xfd5>
    aa39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000aa40 <fwp_hof0.constprop.0>:
    aa40:	55                   	push   %rbp
    aa41:	48 89 e5             	mov    %rsp,%rbp
    aa44:	41 57                	push   %r15
    aa46:	41 56                	push   %r14
    aa48:	41 55                	push   %r13
    aa4a:	41 54                	push   %r12
    aa4c:	53                   	push   %rbx
    aa4d:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    aa54:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    aa5b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    aa62:	00 00 
    aa64:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    aa68:	31 c0                	xor    %eax,%eax
    aa6a:	48 85 f6             	test   %rsi,%rsi
    aa6d:	0f 84 86 06 00 00    	je     b0f9 <fwp_hof0.constprop.0+0x6b9>
    aa73:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    aa77:	49 89 f7             	mov    %rsi,%r15
    aa7a:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    aa81:	48 8d 35 58 8d 01 00 	lea    0x18d58(%rip),%rsi        # 237e0 <fwp_heap>
    aa88:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    aa8f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    aa96:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    aa9d:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    aaa1:	48 c1 e2 10          	shl    $0x10,%rdx
    aaa5:	48 39 d0             	cmp    %rdx,%rax
    aaa8:	73 5d                	jae    ab07 <fwp_hof0.constprop.0+0xc7>
    aaaa:	48 89 c2             	mov    %rax,%rdx
    aaad:	48 c1 ea 10          	shr    $0x10,%rdx
    aab1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aab5:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    aabc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aac0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    aac4:	48 85 ff             	test   %rdi,%rdi
    aac7:	74 3e                	je     ab07 <fwp_hof0.constprop.0+0xc7>
    aac9:	0f b6 0a             	movzbl (%rdx),%ecx
    aacc:	80 f9 02             	cmp    $0x2,%cl
    aacf:	0f 84 cd 0a 00 00    	je     b5a2 <fwp_hof0.constprop.0+0xb62>
    aad5:	80 f9 01             	cmp    $0x1,%cl
    aad8:	75 2d                	jne    ab07 <fwp_hof0.constprop.0+0xc7>
    aada:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aadd:	0f b7 c0             	movzwl %ax,%eax
    aae0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aae3:	48 0f af c1          	imul   %rcx,%rax
    aae7:	48 c1 e8 20          	shr    $0x20,%rax
    aaeb:	48 39 d0             	cmp    %rdx,%rax
    aaee:	73 17                	jae    ab07 <fwp_hof0.constprop.0+0xc7>
    aaf0:	48 01 c7             	add    %rax,%rdi
    aaf3:	0f b6 07             	movzbl (%rdi),%eax
    aaf6:	84 c0                	test   %al,%al
    aaf8:	74 0d                	je     ab07 <fwp_hof0.constprop.0+0xc7>
    aafa:	3c fd                	cmp    $0xfd,%al
    aafc:	0f 87 7e 0b 00 00    	ja     b680 <fwp_hof0.constprop.0+0xc40>
    ab02:	83 c0 01             	add    $0x1,%eax
    ab05:	88 07                	mov    %al,(%rdi)
    ab07:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    ab0e:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    ab15:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    ab1c:	c7 00 00 00 
    ab20:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ab24:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ab28:	48 8b 15 09 a9 01 00 	mov    0x1a909(%rip),%rdx        # 25438 <fwp_fns>
    ab2f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    ab33:	48 8d 05 de 84 00 00 	lea    0x84de(%rip),%rax        # 13018 <fc12>
    ab3a:	44 8b 20             	mov    (%rax),%r12d
    ab3d:	49 c1 e4 05          	shl    $0x5,%r12
    ab41:	49 01 d4             	add    %rdx,%r12
    ab44:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    ab49:	48 85 c9             	test   %rcx,%rcx
    ab4c:	0f 84 1d 0a 00 00    	je     b56f <fwp_hof0.constprop.0+0xb2f>
    ab52:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    ab57:	0f 84 7b 08 00 00    	je     b3d8 <fwp_hof0.constprop.0+0x998>
    ab5d:	48 8d 3d 7c 8c 01 00 	lea    0x18c7c(%rip),%rdi        # 237e0 <fwp_heap>
    ab64:	48 8d 05 ad 84 00 00 	lea    0x84ad(%rip),%rax        # 13018 <fc12>
    ab6b:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    ab72:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    ab79:	48 89 f1             	mov    %rsi,%rcx
    ab7c:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    ab80:	48 c1 e1 10          	shl    $0x10,%rcx
    ab84:	48 39 c8             	cmp    %rcx,%rax
    ab87:	73 5f                	jae    abe8 <fwp_hof0.constprop.0+0x1a8>
    ab89:	48 89 c1             	mov    %rax,%rcx
    ab8c:	48 c1 e9 10          	shr    $0x10,%rcx
    ab90:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ab94:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    ab9b:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    ab9f:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    aba3:	48 85 ff             	test   %rdi,%rdi
    aba6:	74 40                	je     abe8 <fwp_hof0.constprop.0+0x1a8>
    aba8:	0f b6 31             	movzbl (%rcx),%esi
    abab:	40 80 fe 02          	cmp    $0x2,%sil
    abaf:	0f 84 08 09 00 00    	je     b4bd <fwp_hof0.constprop.0+0xa7d>
    abb5:	40 80 fe 01          	cmp    $0x1,%sil
    abb9:	75 2d                	jne    abe8 <fwp_hof0.constprop.0+0x1a8>
    abbb:	8b 71 18             	mov    0x18(%rcx),%esi
    abbe:	0f b7 c0             	movzwl %ax,%eax
    abc1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    abc4:	48 0f af c6          	imul   %rsi,%rax
    abc8:	48 c1 e8 20          	shr    $0x20,%rax
    abcc:	48 39 c8             	cmp    %rcx,%rax
    abcf:	73 17                	jae    abe8 <fwp_hof0.constprop.0+0x1a8>
    abd1:	48 01 c7             	add    %rax,%rdi
    abd4:	0f b6 07             	movzbl (%rdi),%eax
    abd7:	84 c0                	test   %al,%al
    abd9:	74 0d                	je     abe8 <fwp_hof0.constprop.0+0x1a8>
    abdb:	3c fd                	cmp    $0xfd,%al
    abdd:	0f 87 66 09 00 00    	ja     b549 <fwp_hof0.constprop.0+0xb09>
    abe3:	83 c0 01             	add    $0x1,%eax
    abe6:	88 07                	mov    %al,(%rdi)
    abe8:	48 8d 05 29 84 00 00 	lea    0x8429(%rip),%rax        # 13018 <fc12>
    abef:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    abf6:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    abfa:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    ac01:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    ac05:	48 8d 05 0c 84 00 00 	lea    0x840c(%rip),%rax        # 13018 <fc12>
    ac0c:	41 8b 0c 24          	mov    (%r12),%ecx
    ac10:	2b 48 04             	sub    0x4(%rax),%ecx
    ac13:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ac17:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    ac1b:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    ac1e:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    ac22:	49 89 c1             	mov    %rax,%r9
    ac25:	8b 00                	mov    (%rax),%eax
    ac27:	44 39 e9             	cmp    %r13d,%ecx
    ac2a:	44 0f 46 e9          	cmovbe %ecx,%r13d
    ac2e:	4d 89 cf             	mov    %r9,%r15
    ac31:	48 c1 e0 05          	shl    $0x5,%rax
    ac35:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    ac39:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    ac40:	4d 8b 50 18          	mov    0x18(%r8),%r10
    ac44:	4d 85 d2             	test   %r10,%r10
    ac47:	75 58                	jne    aca1 <fwp_hof0.constprop.0+0x261>
    ac49:	e9 f5 01 00 00       	jmp    ae43 <fwp_hof0.constprop.0+0x403>
    ac4e:	66 90                	xchg   %ax,%ax
    ac50:	45 85 ff             	test   %r15d,%r15d
    ac53:	74 69                	je     acbe <fwp_hof0.constprop.0+0x27e>
    ac55:	4c 89 e7             	mov    %r12,%rdi
    ac58:	41 ff 12             	call   *(%r10)
    ac5b:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ac5f:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    ac63:	e8 28 c3 ff ff       	call   6f90 <fwp_closure_drop>
    ac68:	44 39 eb             	cmp    %r13d,%ebx
    ac6b:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    ac6f:	0f 84 53 07 00 00    	je     b3c8 <fwp_hof0.constprop.0+0x988>
    ac75:	44 8b 00             	mov    (%rax),%r8d
    ac78:	45 29 fe             	sub    %r15d,%r14d
    ac7b:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    ac7f:	49 89 c1             	mov    %rax,%r9
    ac82:	45 89 f5             	mov    %r14d,%r13d
    ac85:	49 c1 e0 05          	shl    $0x5,%r8
    ac89:	4c 03 05 a8 a7 01 00 	add    0x1a7a8(%rip),%r8        # 25438 <fwp_fns>
    ac90:	4d 8b 50 18          	mov    0x18(%r8),%r10
    ac94:	4d 85 d2             	test   %r10,%r10
    ac97:	0f 84 a3 01 00 00    	je     ae40 <fwp_hof0.constprop.0+0x400>
    ac9d:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aca1:	41 8b 49 04          	mov    0x4(%r9),%ecx
    aca5:	45 8b 38             	mov    (%r8),%r15d
    aca8:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    acac:	45 39 fe             	cmp    %r15d,%r14d
    acaf:	0f 82 6b 04 00 00    	jb     b120 <fwp_hof0.constprop.0+0x6e0>
    acb5:	44 89 fb             	mov    %r15d,%ebx
    acb8:	29 cb                	sub    %ecx,%ebx
    acba:	85 c9                	test   %ecx,%ecx
    acbc:	74 92                	je     ac50 <fwp_hof0.constprop.0+0x210>
    acbe:	45 85 ff             	test   %r15d,%r15d
    acc1:	b8 01 00 00 00       	mov    $0x1,%eax
    acc6:	48 89 e6             	mov    %rsp,%rsi
    acc9:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    accd:	41 0f 45 c7          	cmovne %r15d,%eax
    acd1:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    acd8:	00 
    acd9:	48 c1 e8 04          	shr    $0x4,%rax
    acdd:	48 c1 e0 04          	shl    $0x4,%rax
    ace1:	48 89 c7             	mov    %rax,%rdi
    ace4:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    aceb:	48 29 fe             	sub    %rdi,%rsi
    acee:	48 39 f4             	cmp    %rsi,%rsp
    acf1:	74 15                	je     ad08 <fwp_hof0.constprop.0+0x2c8>
    acf3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    acfa:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    ad01:	00 00 
    ad03:	48 39 f4             	cmp    %rsi,%rsp
    ad06:	75 eb                	jne    acf3 <fwp_hof0.constprop.0+0x2b3>
    ad08:	25 ff 0f 00 00       	and    $0xfff,%eax
    ad0d:	48 29 c4             	sub    %rax,%rsp
    ad10:	48 85 c0             	test   %rax,%rax
    ad13:	74 06                	je     ad1b <fwp_hof0.constprop.0+0x2db>
    ad15:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    ad1b:	89 cf                	mov    %ecx,%edi
    ad1d:	49 89 e3             	mov    %rsp,%r11
    ad20:	31 c0                	xor    %eax,%eax
    ad22:	48 c1 e7 03          	shl    $0x3,%rdi
    ad26:	85 c9                	test   %ecx,%ecx
    ad28:	74 28                	je     ad52 <fwp_hof0.constprop.0+0x312>
    ad2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad31:	00 00 00 00 
    ad35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad3c:	00 00 00 00 
    ad40:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    ad45:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    ad49:	48 83 c0 08          	add    $0x8,%rax
    ad4d:	48 39 c7             	cmp    %rax,%rdi
    ad50:	75 ee                	jne    ad40 <fwp_hof0.constprop.0+0x300>
    ad52:	85 db                	test   %ebx,%ebx
    ad54:	74 1f                	je     ad75 <fwp_hof0.constprop.0+0x335>
    ad56:	89 de                	mov    %ebx,%esi
    ad58:	4c 89 e0             	mov    %r12,%rax
    ad5b:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    ad5f:	90                   	nop
    ad60:	48 8b 30             	mov    (%rax),%rsi
    ad63:	89 ca                	mov    %ecx,%edx
    ad65:	48 83 c0 08          	add    $0x8,%rax
    ad69:	83 c1 01             	add    $0x1,%ecx
    ad6c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    ad70:	48 39 c7             	cmp    %rax,%rdi
    ad73:	75 eb                	jne    ad60 <fwp_hof0.constprop.0+0x320>
    ad75:	48 8d 15 64 8a 01 00 	lea    0x18a64(%rip),%rdx        # 237e0 <fwp_heap>
    ad7c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ad80:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    ad87:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    ad8e:	48 89 f1             	mov    %rsi,%rcx
    ad91:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    ad95:	48 c1 e1 10          	shl    $0x10,%rcx
    ad99:	48 39 c8             	cmp    %rcx,%rax
    ad9c:	73 4c                	jae    adea <fwp_hof0.constprop.0+0x3aa>
    ad9e:	48 89 c1             	mov    %rax,%rcx
    ada1:	48 c1 e9 10          	shr    $0x10,%rcx
    ada5:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ada9:	48 8b 0d 28 9e 01 00 	mov    0x19e28(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    adb0:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    adb4:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    adb8:	48 85 f6             	test   %rsi,%rsi
    adbb:	74 2d                	je     adea <fwp_hof0.constprop.0+0x3aa>
    adbd:	0f b6 39             	movzbl (%rcx),%edi
    adc0:	40 80 ff 02          	cmp    $0x2,%dil
    adc4:	74 6a                	je     ae30 <fwp_hof0.constprop.0+0x3f0>
    adc6:	40 80 ff 01          	cmp    $0x1,%dil
    adca:	75 1e                	jne    adea <fwp_hof0.constprop.0+0x3aa>
    adcc:	8b 79 18             	mov    0x18(%rcx),%edi
    adcf:	0f b7 c0             	movzwl %ax,%eax
    add2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    add5:	48 0f af c7          	imul   %rdi,%rax
    add9:	48 c1 e8 20          	shr    $0x20,%rax
    addd:	48 39 c8             	cmp    %rcx,%rax
    ade0:	73 08                	jae    adea <fwp_hof0.constprop.0+0x3aa>
    ade2:	48 01 c6             	add    %rax,%rsi
    ade5:	80 3e 01             	cmpb   $0x1,(%rsi)
    ade8:	74 36                	je     ae20 <fwp_hof0.constprop.0+0x3e0>
    adea:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    adee:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    adf2:	be 01 00 00 00       	mov    $0x1,%esi
    adf7:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    adfb:	41 ff 52 08          	call   *0x8(%r10)
    adff:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    ae03:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    ae07:	49 8b 40 18          	mov    0x18(%r8),%rax
    ae0b:	4c 89 df             	mov    %r11,%rdi
    ae0e:	ff 10                	call   *(%rax)
    ae10:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    ae14:	e9 42 fe ff ff       	jmp    ac5b <fwp_hof0.constprop.0+0x21b>
    ae19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ae20:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    ae27:	00 
    ae28:	eb dd                	jmp    ae07 <fwp_hof0.constprop.0+0x3c7>
    ae2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae30:	66 85 c0             	test   %ax,%ax
    ae33:	75 b5                	jne    adea <fwp_hof0.constprop.0+0x3aa>
    ae35:	eb ae                	jmp    ade5 <fwp_hof0.constprop.0+0x3a5>
    ae37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ae3e:	00 00 
    ae40:	49 89 c7             	mov    %rax,%r15
    ae43:	4c 89 ff             	mov    %r15,%rdi
    ae46:	e8 15 ba ff ff       	call   6860 <fwp_rc_share>
    ae4b:	45 85 ed             	test   %r13d,%r13d
    ae4e:	74 21                	je     ae71 <fwp_hof0.constprop.0+0x431>
    ae50:	44 89 ea             	mov    %r13d,%edx
    ae53:	4c 89 e3             	mov    %r12,%rbx
    ae56:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    ae5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae60:	48 8b 3b             	mov    (%rbx),%rdi
    ae63:	48 83 c3 08          	add    $0x8,%rbx
    ae67:	e8 f4 b9 ff ff       	call   6860 <fwp_rc_share>
    ae6c:	4c 39 f3             	cmp    %r14,%rbx
    ae6f:	75 ef                	jne    ae60 <fwp_hof0.constprop.0+0x420>
    ae71:	4c 89 e2             	mov    %r12,%rdx
    ae74:	44 89 ee             	mov    %r13d,%esi
    ae77:	4c 89 ff             	mov    %r15,%rdi
    ae7a:	e8 31 af ff ff       	call   5db0 <fwp_apply>
    ae7f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ae83:	8b 75 94             	mov    -0x6c(%rbp),%esi
    ae86:	39 75 90             	cmp    %esi,-0x70(%rbp)
    ae89:	0f 83 87 00 00 00    	jae    af16 <fwp_hof0.constprop.0+0x4d6>
    ae8f:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    ae95:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    ae99:	48 89 c2             	mov    %rax,%rdx
    ae9c:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    aea0:	29 d6                	sub    %edx,%esi
    aea2:	48 8b 15 8f a5 01 00 	mov    0x1a58f(%rip),%rdx        # 25438 <fwp_fns>
    aea9:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    aead:	89 75 94             	mov    %esi,-0x6c(%rbp)
    aeb0:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    aeb4:	44 8b 26             	mov    (%rsi),%r12d
    aeb7:	48 89 f0             	mov    %rsi,%rax
    aeba:	49 c1 e4 05          	shl    $0x5,%r12
    aebe:	49 01 d4             	add    %rdx,%r12
    aec1:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    aec7:	0f 85 3f fd ff ff    	jne    ac0c <fwp_hof0.constprop.0+0x1cc>
    aecd:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aed1:	e8 8a b9 ff ff       	call   6860 <fwp_rc_share>
    aed6:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    aeda:	45 85 f6             	test   %r14d,%r14d
    aedd:	74 23                	je     af02 <fwp_hof0.constprop.0+0x4c2>
    aedf:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    aee3:	31 db                	xor    %ebx,%ebx
    aee5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aeec:	00 00 00 00 
    aef0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    aef4:	48 83 c3 01          	add    $0x1,%rbx
    aef8:	e8 63 b9 ff ff       	call   6860 <fwp_rc_share>
    aefd:	44 39 f3             	cmp    %r14d,%ebx
    af00:	72 ee                	jb     aef0 <fwp_hof0.constprop.0+0x4b0>
    af02:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    af06:	8b 75 94             	mov    -0x6c(%rbp),%esi
    af09:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    af0d:	e8 9e ae ff ff       	call   5db0 <fwp_apply>
    af12:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    af16:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    af1d:	01 
    af1e:	0f 85 00 fc ff ff    	jne    ab24 <fwp_hof0.constprop.0+0xe4>
    af24:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    af28:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    af2f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af33:	b9 01 00 00 00       	mov    $0x1,%ecx
    af38:	48 8d 15 41 7c 00 00 	lea    0x7c41(%rip),%rdx        # 12b80 <d0>
    af3f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    af46:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    af4d:	00 
    af4e:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    af52:	e8 a9 ea ff ff       	call   9a00 <fwp_write>
    af57:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    af5b:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    af5f:	48 8d 05 2b 41 00 00 	lea    0x412b(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    af66:	48 85 c9             	test   %rcx,%rcx
    af69:	48 0f 44 c8          	cmove  %rax,%rcx
    af6d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    af71:	0f 87 f5 06 00 00    	ja     b66c <fwp_hof0.constprop.0+0xc2c>
    af77:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    af7b:	be 01 00 00 00       	mov    $0x1,%esi
    af80:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    af84:	e8 07 ad ff ff       	call   5c90 <fwp_heap_alloc>
    af89:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    af8d:	4c 89 f2             	mov    %r14,%rdx
    af90:	4c 89 30             	mov    %r14,(%rax)
    af93:	4c 8d 60 08          	lea    0x8(%rax),%r12
    af97:	48 89 c3             	mov    %rax,%rbx
    af9a:	4c 89 e7             	mov    %r12,%rdi
    af9d:	e8 fe 85 ff ff       	call   35a0 <memcpy@plt>
    afa2:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    afa8:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    afac:	e8 0f 84 ff ff       	call   33c0 <free@plt>
    afb1:	48 8d 35 28 88 01 00 	lea    0x18828(%rip),%rsi        # 237e0 <fwp_heap>
    afb8:	48 89 d8             	mov    %rbx,%rax
    afbb:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    afc2:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    afc9:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    afcd:	48 c1 e2 10          	shl    $0x10,%rdx
    afd1:	48 39 d0             	cmp    %rdx,%rax
    afd4:	73 57                	jae    b02d <fwp_hof0.constprop.0+0x5ed>
    afd6:	48 89 c2             	mov    %rax,%rdx
    afd9:	48 c1 ea 10          	shr    $0x10,%rdx
    afdd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    afe1:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    afe8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    afec:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    aff0:	4d 85 f6             	test   %r14,%r14
    aff3:	74 38                	je     b02d <fwp_hof0.constprop.0+0x5ed>
    aff5:	0f b6 0a             	movzbl (%rdx),%ecx
    aff8:	80 f9 02             	cmp    $0x2,%cl
    affb:	0f 84 c9 05 00 00    	je     b5ca <fwp_hof0.constprop.0+0xb8a>
    b001:	80 f9 01             	cmp    $0x1,%cl
    b004:	75 27                	jne    b02d <fwp_hof0.constprop.0+0x5ed>
    b006:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b009:	0f b7 c0             	movzwl %ax,%eax
    b00c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b00f:	48 0f af c1          	imul   %rcx,%rax
    b013:	48 c1 e8 20          	shr    $0x20,%rax
    b017:	48 39 d0             	cmp    %rdx,%rax
    b01a:	73 11                	jae    b02d <fwp_hof0.constprop.0+0x5ed>
    b01c:	49 01 c6             	add    %rax,%r14
    b01f:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b023:	0f 84 67 06 00 00    	je     b690 <fwp_hof0.constprop.0+0xc50>
    b029:	41 c6 06 01          	movb   $0x1,(%r14)
    b02d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b031:	e8 6a bc ff ff       	call   6ca0 <fwp_drop0>
    b036:	48 8b 13             	mov    (%rbx),%rdx
    b039:	be 01 00 00 00       	mov    $0x1,%esi
    b03e:	4c 89 e7             	mov    %r12,%rdi
    b041:	48 8b 0d f8 a3 01 00 	mov    0x1a3f8(%rip),%rcx        # 25440 <fwp_prog_out>
    b048:	e8 33 86 ff ff       	call   3680 <fwrite@plt>
    b04d:	48 8b 35 ec a3 01 00 	mov    0x1a3ec(%rip),%rsi        # 25440 <fwp_prog_out>
    b054:	bf 0a 00 00 00       	mov    $0xa,%edi
    b059:	e8 82 84 ff ff       	call   34e0 <fputc@plt>
    b05e:	48 8d 35 7b 87 01 00 	lea    0x1877b(%rip),%rsi        # 237e0 <fwp_heap>
    b065:	48 89 d8             	mov    %rbx,%rax
    b068:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b06f:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b076:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    b07a:	48 c1 e2 10          	shl    $0x10,%rdx
    b07e:	48 39 d0             	cmp    %rdx,%rax
    b081:	73 69                	jae    b0ec <fwp_hof0.constprop.0+0x6ac>
    b083:	48 89 c2             	mov    %rax,%rdx
    b086:	48 c1 ea 10          	shr    $0x10,%rdx
    b08a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b08e:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b095:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b099:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b09d:	4d 85 e4             	test   %r12,%r12
    b0a0:	74 4a                	je     b0ec <fwp_hof0.constprop.0+0x6ac>
    b0a2:	0f b6 0a             	movzbl (%rdx),%ecx
    b0a5:	80 f9 02             	cmp    $0x2,%cl
    b0a8:	0f 84 2a 05 00 00    	je     b5d8 <fwp_hof0.constprop.0+0xb98>
    b0ae:	80 f9 01             	cmp    $0x1,%cl
    b0b1:	75 39                	jne    b0ec <fwp_hof0.constprop.0+0x6ac>
    b0b3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b0b6:	0f b7 c0             	movzwl %ax,%eax
    b0b9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b0bc:	48 0f af c1          	imul   %rcx,%rax
    b0c0:	48 c1 e8 20          	shr    $0x20,%rax
    b0c4:	48 39 d0             	cmp    %rdx,%rax
    b0c7:	73 23                	jae    b0ec <fwp_hof0.constprop.0+0x6ac>
    b0c9:	49 01 c4             	add    %rax,%r12
    b0cc:	41 0f b6 04 24       	movzbl (%r12),%eax
    b0d1:	84 c0                	test   %al,%al
    b0d3:	74 17                	je     b0ec <fwp_hof0.constprop.0+0x6ac>
    b0d5:	3c 01                	cmp    $0x1,%al
    b0d7:	0f 84 d3 04 00 00    	je     b5b0 <fwp_hof0.constprop.0+0xb70>
    b0dd:	3c ff                	cmp    $0xff,%al
    b0df:	0f 84 01 05 00 00    	je     b5e6 <fwp_hof0.constprop.0+0xba6>
    b0e5:	83 e8 01             	sub    $0x1,%eax
    b0e8:	41 88 04 24          	mov    %al,(%r12)
    b0ec:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b0f0:	4d 85 ff             	test   %r15,%r15
    b0f3:	0f 85 88 f9 ff ff    	jne    aa81 <fwp_hof0.constprop.0+0x41>
    b0f9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b0fd:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b104:	00 00 
    b106:	0f 85 7e 05 00 00    	jne    b68a <fwp_hof0.constprop.0+0xc4a>
    b10c:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b110:	31 c0                	xor    %eax,%eax
    b112:	5b                   	pop    %rbx
    b113:	41 5c                	pop    %r12
    b115:	41 5d                	pop    %r13
    b117:	41 5e                	pop    %r14
    b119:	41 5f                	pop    %r15
    b11b:	5d                   	pop    %rbp
    b11c:	c3                   	ret
    b11d:	0f 1f 00             	nopl   (%rax)
    b120:	48 8d 1d b9 86 01 00 	lea    0x186b9(%rip),%rbx        # 237e0 <fwp_heap>
    b127:	41 8d 76 01          	lea    0x1(%r14),%esi
    b12b:	45 89 f7             	mov    %r14d,%r15d
    b12e:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    b134:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    b13b:	00 
    b13c:	85 c0                	test   %eax,%eax
    b13e:	0f 84 a9 03 00 00    	je     b4ed <fwp_hof0.constprop.0+0xaad>
    b144:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b14b:	0f 87 9c 03 00 00    	ja     b4ed <fwp_hof0.constprop.0+0xaad>
    b151:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    b155:	48 c1 e8 04          	shr    $0x4,%rax
    b159:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    b160:	00 
    b161:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    b168:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    b16c:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    b170:	4c 8b 12             	mov    (%rdx),%r10
    b173:	4d 85 d2             	test   %r10,%r10
    b176:	0f 84 4f 03 00 00    	je     b4cb <fwp_hof0.constprop.0+0xa8b>
    b17c:	4d 8b 1a             	mov    (%r10),%r11
    b17f:	49 f7 d3             	not    %r11
    b182:	4c 89 1a             	mov    %r11,(%rdx)
    b185:	48 39 c7             	cmp    %rax,%rdi
    b188:	73 50                	jae    b1da <fwp_hof0.constprop.0+0x79a>
    b18a:	48 89 fa             	mov    %rdi,%rdx
    b18d:	48 83 c7 08          	add    $0x8,%rdi
    b191:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    b198:	00 
    b199:	48 f7 d2             	not    %rdx
    b19c:	48 01 c2             	add    %rax,%rdx
    b19f:	48 c1 ea 03          	shr    $0x3,%rdx
    b1a3:	48 39 c7             	cmp    %rax,%rdi
    b1a6:	73 32                	jae    b1da <fwp_hof0.constprop.0+0x79a>
    b1a8:	83 e2 01             	and    $0x1,%edx
    b1ab:	74 13                	je     b1c0 <fwp_hof0.constprop.0+0x780>
    b1ad:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b1b4:	00 
    b1b5:	48 83 c7 08          	add    $0x8,%rdi
    b1b9:	48 39 c7             	cmp    %rax,%rdi
    b1bc:	73 1c                	jae    b1da <fwp_hof0.constprop.0+0x79a>
    b1be:	66 90                	xchg   %ax,%ax
    b1c0:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b1c7:	00 
    b1c8:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    b1cf:	00 00 
    b1d1:	48 83 c7 10          	add    $0x10,%rdi
    b1d5:	48 39 c7             	cmp    %rax,%rdi
    b1d8:	72 e6                	jb     b1c0 <fwp_hof0.constprop.0+0x780>
    b1da:	48 8d 35 ff 85 01 00 	lea    0x185ff(%rip),%rsi        # 237e0 <fwp_heap>
    b1e1:	48 89 c2             	mov    %rax,%rdx
    b1e4:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    b1eb:	0f 82 6a 04 00 00    	jb     b65b <fwp_hof0.constprop.0+0xc1b>
    b1f1:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    b1f8:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    b1ff:	73 07                	jae    b208 <fwp_hof0.constprop.0+0x7c8>
    b201:	48 89 15 00 9a 01 00 	mov    %rdx,0x19a00(%rip)        # 24c08 <fwp_heap+0x1428>
    b208:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b20c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b211:	f2 0f 58 05 ff 99 01 	addsd  0x199ff(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    b218:	00 
    b219:	f2 0f 11 05 f7 99 01 	movsd  %xmm0,0x199f7(%rip)        # 24c18 <fwp_heap+0x1438>
    b220:	00 
    b221:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b226:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b22b:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b22f:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b234:	85 c9                	test   %ecx,%ecx
    b236:	74 37                	je     b26f <fwp_hof0.constprop.0+0x82f>
    b238:	89 ca                	mov    %ecx,%edx
    b23a:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b23e:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b242:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b245:	48 c1 e2 03          	shl    $0x3,%rdx
    b249:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b250:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b254:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b258:	e8 b3 83 ff ff       	call   3610 <memmove@plt>
    b25d:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b261:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b265:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b268:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b26f:	45 85 ed             	test   %r13d,%r13d
    b272:	74 23                	je     b297 <fwp_hof0.constprop.0+0x857>
    b274:	45 89 ed             	mov    %r13d,%r13d
    b277:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b27b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b280:	49 8b 14 24          	mov    (%r12),%rdx
    b284:	89 c8                	mov    %ecx,%eax
    b286:	49 83 c4 08          	add    $0x8,%r12
    b28a:	83 c1 01             	add    $0x1,%ecx
    b28d:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b292:	4c 39 e6             	cmp    %r12,%rsi
    b295:	75 e9                	jne    b280 <fwp_hof0.constprop.0+0x840>
    b297:	48 8d 35 42 85 01 00 	lea    0x18542(%rip),%rsi        # 237e0 <fwp_heap>
    b29e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b2a2:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b2a9:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b2b0:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b2b4:	48 c1 e2 10          	shl    $0x10,%rdx
    b2b8:	48 39 d0             	cmp    %rdx,%rax
    b2bb:	73 54                	jae    b311 <fwp_hof0.constprop.0+0x8d1>
    b2bd:	48 89 c2             	mov    %rax,%rdx
    b2c0:	48 c1 ea 10          	shr    $0x10,%rdx
    b2c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2c8:	48 8b 15 09 99 01 00 	mov    0x19909(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b2cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2d3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b2d7:	48 85 c9             	test   %rcx,%rcx
    b2da:	74 35                	je     b311 <fwp_hof0.constprop.0+0x8d1>
    b2dc:	0f b6 32             	movzbl (%rdx),%esi
    b2df:	40 80 fe 02          	cmp    $0x2,%sil
    b2e3:	0f 84 52 02 00 00    	je     b53b <fwp_hof0.constprop.0+0xafb>
    b2e9:	40 80 fe 01          	cmp    $0x1,%sil
    b2ed:	75 22                	jne    b311 <fwp_hof0.constprop.0+0x8d1>
    b2ef:	8b 72 18             	mov    0x18(%rdx),%esi
    b2f2:	0f b7 c0             	movzwl %ax,%eax
    b2f5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b2f8:	48 0f af c6          	imul   %rsi,%rax
    b2fc:	48 c1 e8 20          	shr    $0x20,%rax
    b300:	48 39 d0             	cmp    %rdx,%rax
    b303:	73 0c                	jae    b311 <fwp_hof0.constprop.0+0x8d1>
    b305:	48 01 c1             	add    %rax,%rcx
    b308:	80 39 01             	cmpb   $0x1,(%rcx)
    b30b:	0f 84 9f 01 00 00    	je     b4b0 <fwp_hof0.constprop.0+0xa70>
    b311:	49 8b 40 18          	mov    0x18(%r8),%rax
    b315:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b319:	be 01 00 00 00       	mov    $0x1,%esi
    b31e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b322:	ff 50 08             	call   *0x8(%rax)
    b325:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b329:	48 8d 35 b0 84 01 00 	lea    0x184b0(%rip),%rsi        # 237e0 <fwp_heap>
    b330:	4c 89 d0             	mov    %r10,%rax
    b333:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b33a:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b341:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b345:	48 c1 e2 10          	shl    $0x10,%rdx
    b349:	48 39 d0             	cmp    %rdx,%rax
    b34c:	73 59                	jae    b3a7 <fwp_hof0.constprop.0+0x967>
    b34e:	48 89 c2             	mov    %rax,%rdx
    b351:	48 c1 ea 10          	shr    $0x10,%rdx
    b355:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b359:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b360:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b364:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b368:	4d 85 e4             	test   %r12,%r12
    b36b:	74 3a                	je     b3a7 <fwp_hof0.constprop.0+0x967>
    b36d:	0f b6 0a             	movzbl (%rdx),%ecx
    b370:	80 f9 02             	cmp    $0x2,%cl
    b373:	0f 84 99 01 00 00    	je     b512 <fwp_hof0.constprop.0+0xad2>
    b379:	80 f9 01             	cmp    $0x1,%cl
    b37c:	75 29                	jne    b3a7 <fwp_hof0.constprop.0+0x967>
    b37e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b381:	0f b7 c0             	movzwl %ax,%eax
    b384:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b387:	48 0f af c1          	imul   %rcx,%rax
    b38b:	48 c1 e8 20          	shr    $0x20,%rax
    b38f:	48 39 d0             	cmp    %rdx,%rax
    b392:	73 13                	jae    b3a7 <fwp_hof0.constprop.0+0x967>
    b394:	49 01 c4             	add    %rax,%r12
    b397:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b39c:	0f 84 84 01 00 00    	je     b526 <fwp_hof0.constprop.0+0xae6>
    b3a2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b3a7:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b3ab:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b3af:	e8 dc bb ff ff       	call   6f90 <fwp_closure_drop>
    b3b4:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b3b8:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b3bc:	e9 c2 fa ff ff       	jmp    ae83 <fwp_hof0.constprop.0+0x443>
    b3c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b3c8:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b3cc:	e9 b2 fa ff ff       	jmp    ae83 <fwp_hof0.constprop.0+0x443>
    b3d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b3d8:	41 8b 34 24          	mov    (%r12),%esi
    b3dc:	8b 05 3a 7c 00 00    	mov    0x7c3a(%rip),%eax        # 1301c <fc12+0x4>
    b3e2:	89 f7                	mov    %esi,%edi
    b3e4:	29 c7                	sub    %eax,%edi
    b3e6:	83 ff 01             	cmp    $0x1,%edi
    b3e9:	0f 85 6e f7 ff ff    	jne    ab5d <fwp_hof0.constprop.0+0x11d>
    b3ef:	48 89 e3             	mov    %rsp,%rbx
    b3f2:	85 c0                	test   %eax,%eax
    b3f4:	0f 84 60 01 00 00    	je     b55a <fwp_hof0.constprop.0+0xb1a>
    b3fa:	89 f1                	mov    %esi,%ecx
    b3fc:	ba 08 00 00 00       	mov    $0x8,%edx
    b401:	48 c1 e1 03          	shl    $0x3,%rcx
    b405:	85 f6                	test   %esi,%esi
    b407:	48 89 e6             	mov    %rsp,%rsi
    b40a:	48 0f 45 d1          	cmovne %rcx,%rdx
    b40e:	49 89 d7             	mov    %rdx,%r15
    b411:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b415:	48 c1 ea 04          	shr    $0x4,%rdx
    b419:	48 c1 e2 04          	shl    $0x4,%rdx
    b41d:	48 89 d7             	mov    %rdx,%rdi
    b420:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b427:	48 29 fe             	sub    %rdi,%rsi
    b42a:	48 39 f4             	cmp    %rsi,%rsp
    b42d:	74 15                	je     b444 <fwp_hof0.constprop.0+0xa04>
    b42f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b436:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b43d:	00 00 
    b43f:	48 39 f4             	cmp    %rsi,%rsp
    b442:	75 eb                	jne    b42f <fwp_hof0.constprop.0+0x9ef>
    b444:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b44a:	48 29 d4             	sub    %rdx,%rsp
    b44d:	48 85 d2             	test   %rdx,%rdx
    b450:	74 06                	je     b458 <fwp_hof0.constprop.0+0xa18>
    b452:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b458:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b45f:	00 
    b460:	4c 89 f9             	mov    %r15,%rcx
    b463:	48 8d 35 b6 7b 00 00 	lea    0x7bb6(%rip),%rsi        # 13020 <descent_active_phase>
    b46a:	48 89 e7             	mov    %rsp,%rdi
    b46d:	4c 89 f2             	mov    %r14,%rdx
    b470:	e8 fb 80 ff ff       	call   3570 <__memcpy_chk@plt>
    b475:	4d 39 f7             	cmp    %r14,%r15
    b478:	4c 89 f9             	mov    %r15,%rcx
    b47b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b47f:	49 0f 42 ce          	cmovb  %r14,%rcx
    b483:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b48a:	ba 08 00 00 00       	mov    $0x8,%edx
    b48f:	4c 29 f1             	sub    %r14,%rcx
    b492:	e8 d9 80 ff ff       	call   3570 <__memcpy_chk@plt>
    b497:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b49c:	48 89 e7             	mov    %rsp,%rdi
    b49f:	ff 10                	call   *(%rax)
    b4a1:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b4a5:	e9 bd 00 00 00       	jmp    b567 <fwp_hof0.constprop.0+0xb27>
    b4aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b4b0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b4b7:	00 
    b4b8:	e9 6c fe ff ff       	jmp    b329 <fwp_hof0.constprop.0+0x8e9>
    b4bd:	66 85 c0             	test   %ax,%ax
    b4c0:	0f 85 22 f7 ff ff    	jne    abe8 <fwp_hof0.constprop.0+0x1a8>
    b4c6:	e9 09 f7 ff ff       	jmp    abd4 <fwp_hof0.constprop.0+0x194>
    b4cb:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b4cf:	4d 85 d2             	test   %r10,%r10
    b4d2:	74 19                	je     b4ed <fwp_hof0.constprop.0+0xaad>
    b4d4:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b4d8:	4d 29 d3             	sub    %r10,%r11
    b4db:	49 39 c3             	cmp    %rax,%r11
    b4de:	72 0d                	jb     b4ed <fwp_hof0.constprop.0+0xaad>
    b4e0:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b4e4:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b4e8:	e9 98 fc ff ff       	jmp    b185 <fwp_hof0.constprop.0+0x745>
    b4ed:	31 f6                	xor    %esi,%esi
    b4ef:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b4f2:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b4f6:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b4fa:	e8 91 a7 ff ff       	call   5c90 <fwp_heap_alloc>
    b4ff:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b502:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b506:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b50a:	49 89 c2             	mov    %rax,%r10
    b50d:	e9 0f fd ff ff       	jmp    b221 <fwp_hof0.constprop.0+0x7e1>
    b512:	66 85 c0             	test   %ax,%ax
    b515:	0f 85 8c fe ff ff    	jne    b3a7 <fwp_hof0.constprop.0+0x967>
    b51b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b520:	0f 85 7c fe ff ff    	jne    b3a2 <fwp_hof0.constprop.0+0x962>
    b526:	4c 89 e7             	mov    %r12,%rdi
    b529:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b52d:	e8 1e a0 ff ff       	call   5550 <fwp_rc_forget_slot>
    b532:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b536:	e9 67 fe ff ff       	jmp    b3a2 <fwp_hof0.constprop.0+0x962>
    b53b:	66 85 c0             	test   %ax,%ax
    b53e:	0f 85 cd fd ff ff    	jne    b311 <fwp_hof0.constprop.0+0x8d1>
    b544:	e9 bf fd ff ff       	jmp    b308 <fwp_hof0.constprop.0+0x8c8>
    b549:	e8 e2 9e ff ff       	call   5430 <fwp_rc_wide_dup>
    b54e:	48 8b 15 e3 9e 01 00 	mov    0x19ee3(%rip),%rdx        # 25438 <fwp_fns>
    b555:	e9 8e f6 ff ff       	jmp    abe8 <fwp_hof0.constprop.0+0x1a8>
    b55a:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b561:	ff 11                	call   *(%rcx)
    b563:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b567:	48 89 dc             	mov    %rbx,%rsp
    b56a:	e9 a7 f9 ff ff       	jmp    af16 <fwp_hof0.constprop.0+0x4d6>
    b56f:	48 89 c7             	mov    %rax,%rdi
    b572:	e8 e9 b2 ff ff       	call   6860 <fwp_rc_share>
    b577:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b57b:	e8 e0 b2 ff ff       	call   6860 <fwp_rc_share>
    b580:	48 8d 05 91 7a 00 00 	lea    0x7a91(%rip),%rax        # 13018 <fc12>
    b587:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b58e:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b592:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b599:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b59d:	e9 60 f9 ff ff       	jmp    af02 <fwp_hof0.constprop.0+0x4c2>
    b5a2:	66 85 c0             	test   %ax,%ax
    b5a5:	0f 85 5c f5 ff ff    	jne    ab07 <fwp_hof0.constprop.0+0xc7>
    b5ab:	e9 43 f5 ff ff       	jmp    aaf3 <fwp_hof0.constprop.0+0xb3>
    b5b0:	48 89 df             	mov    %rbx,%rdi
    b5b3:	e8 d8 b3 ff ff       	call   6990 <fwp_rc_free_arr>
    b5b8:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b5bc:	4d 85 ff             	test   %r15,%r15
    b5bf:	0f 85 bc f4 ff ff    	jne    aa81 <fwp_hof0.constprop.0+0x41>
    b5c5:	e9 2f fb ff ff       	jmp    b0f9 <fwp_hof0.constprop.0+0x6b9>
    b5ca:	66 85 c0             	test   %ax,%ax
    b5cd:	0f 85 5a fa ff ff    	jne    b02d <fwp_hof0.constprop.0+0x5ed>
    b5d3:	e9 47 fa ff ff       	jmp    b01f <fwp_hof0.constprop.0+0x5df>
    b5d8:	66 85 c0             	test   %ax,%ax
    b5db:	0f 85 0b fb ff ff    	jne    b0ec <fwp_hof0.constprop.0+0x6ac>
    b5e1:	e9 e6 fa ff ff       	jmp    b0cc <fwp_hof0.constprop.0+0x68c>
    b5e6:	4c 89 e0             	mov    %r12,%rax
    b5e9:	48 8d 35 f0 81 01 00 	lea    0x181f0(%rip),%rsi        # 237e0 <fwp_heap>
    b5f0:	48 c1 e8 11          	shr    $0x11,%rax
    b5f4:	4c 31 e0             	xor    %r12,%rax
    b5f7:	48 89 c2             	mov    %rax,%rdx
    b5fa:	48 c1 ea 09          	shr    $0x9,%rdx
    b5fe:	48 31 d0             	xor    %rdx,%rax
    b601:	0f b6 c0             	movzbl %al,%eax
    b604:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b60b:	00 
    b60c:	48 85 d2             	test   %rdx,%rdx
    b60f:	75 18                	jne    b629 <fwp_hof0.constprop.0+0xbe9>
    b611:	eb 4d                	jmp    b660 <fwp_hof0.constprop.0+0xc20>
    b613:	66 90                	xchg   %ax,%ax
    b615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b61c:	00 00 00 00 
    b620:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b624:	48 85 d2             	test   %rdx,%rdx
    b627:	74 37                	je     b660 <fwp_hof0.constprop.0+0xc20>
    b629:	48 89 d0             	mov    %rdx,%rax
    b62c:	4c 39 22             	cmp    %r12,(%rdx)
    b62f:	75 ef                	jne    b620 <fwp_hof0.constprop.0+0xbe0>
    b631:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b635:	48 83 e8 01          	sub    $0x1,%rax
    b639:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b63d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b643:	0f 85 a3 fa ff ff    	jne    b0ec <fwp_hof0.constprop.0+0x6ac>
    b649:	4c 89 e7             	mov    %r12,%rdi
    b64c:	e8 ff 9e ff ff       	call   5550 <fwp_rc_forget_slot>
    b651:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b656:	e9 91 fa ff ff       	jmp    b0ec <fwp_hof0.constprop.0+0x6ac>
    b65b:	e8 50 86 ff ff       	call   3cb0 <fwp_heap_oom>
    b660:	48 8d 3d 21 42 00 00 	lea    0x4221(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    b667:	e8 84 8d ff ff       	call   43f0 <fwp_trap>
    b66c:	48 8d 3d d3 3b 00 00 	lea    0x3bd3(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    b673:	e8 78 8d ff ff       	call   43f0 <fwp_trap>
    b678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b67f:	00 
    b680:	e8 ab 9d ff ff       	call   5430 <fwp_rc_wide_dup>
    b685:	e9 7d f4 ff ff       	jmp    ab07 <fwp_hof0.constprop.0+0xc7>
    b68a:	e8 d1 7d ff ff       	call   3460 <__stack_chk_fail@plt>
    b68f:	90                   	nop
    b690:	4c 89 f7             	mov    %r14,%rdi
    b693:	e8 b8 9e ff ff       	call   5550 <fwp_rc_forget_slot>
    b698:	e9 8c f9 ff ff       	jmp    b029 <fwp_hof0.constprop.0+0x5e9>
    b69d:	0f 1f 00             	nopl   (%rax)

000000000000b6a0 <f0>:
    b6a0:	41 56                	push   %r14
    b6a2:	4c 8d 35 37 81 01 00 	lea    0x18137(%rip),%r14        # 237e0 <fwp_heap>
    b6a9:	41 55                	push   %r13
    b6ab:	41 54                	push   %r12
    b6ad:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b6b3:	55                   	push   %rbp
    b6b4:	53                   	push   %rbx
    b6b5:	31 db                	xor    %ebx,%ebx
    b6b7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b6be:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b6c5:	00 00 
    b6c7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b6ce:	00 
    b6cf:	31 c0                	xor    %eax,%eax
    b6d1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b6d8:	00 
    b6d9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b6e0:	00 00 
    b6e2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b6e7:	48 8d 05 42 b7 ff ff 	lea    -0x48be(%rip),%rax        # 6e30 <fwp_drop1>
    b6ee:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b6f3:	48 8b 05 7e 9d 01 00 	mov    0x19d7e(%rip),%rax        # 25478 <fwp_cleanups>
    b6fa:	48 89 25 77 9d 01 00 	mov    %rsp,0x19d77(%rip)        # 25478 <fwp_cleanups>
    b701:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b705:	48 89 04 24          	mov    %rax,(%rsp)
    b709:	48 8d 05 c0 84 ff ff 	lea    -0x7b40(%rip),%rax        # 3bd0 <fwp_range_release>
    b710:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b715:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b71a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b71f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b724:	eb 47                	jmp    b76d <f0+0xcd>
    b726:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b72d:	00 00 00 
    b730:	80 f9 01             	cmp    $0x1,%cl
    b733:	75 29                	jne    b75e <f0+0xbe>
    b735:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b738:	0f b7 c0             	movzwl %ax,%eax
    b73b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b73e:	48 0f af c1          	imul   %rcx,%rax
    b742:	48 c1 e8 20          	shr    $0x20,%rax
    b746:	48 39 d0             	cmp    %rdx,%rax
    b749:	73 13                	jae    b75e <f0+0xbe>
    b74b:	49 01 c5             	add    %rax,%r13
    b74e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b753:	0f 84 c7 27 00 00    	je     df20 <f0+0x2880>
    b759:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b75e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b763:	49 83 ec 01          	sub    $0x1,%r12
    b767:	0f 82 83 00 00 00    	jb     b7f0 <f0+0x150>
    b76d:	48 89 ee             	mov    %rbp,%rsi
    b770:	bf 01 00 00 00       	mov    $0x1,%edi
    b775:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b77c:	00 
    b77d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b782:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b789:	00 
    b78a:	e8 a1 af ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    b78f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b796:	48 89 c3             	mov    %rax,%rbx
    b799:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b7a0:	48 c1 e2 10          	shl    $0x10,%rdx
    b7a4:	48 39 d0             	cmp    %rdx,%rax
    b7a7:	73 b5                	jae    b75e <f0+0xbe>
    b7a9:	48 89 c2             	mov    %rax,%rdx
    b7ac:	48 c1 ea 10          	shr    $0x10,%rdx
    b7b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7b4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b7bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7bf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b7c3:	4d 85 ed             	test   %r13,%r13
    b7c6:	74 96                	je     b75e <f0+0xbe>
    b7c8:	0f b6 0a             	movzbl (%rdx),%ecx
    b7cb:	80 f9 02             	cmp    $0x2,%cl
    b7ce:	0f 85 5c ff ff ff    	jne    b730 <f0+0x90>
    b7d4:	66 85 c0             	test   %ax,%ax
    b7d7:	0f 84 71 ff ff ff    	je     b74e <f0+0xae>
    b7dd:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b7e2:	49 83 ec 01          	sub    $0x1,%r12
    b7e6:	73 85                	jae    b76d <f0+0xcd>
    b7e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b7ef:	00 
    b7f0:	48 8b 04 24          	mov    (%rsp),%rax
    b7f4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b7f9:	bf 01 00 00 00       	mov    $0x1,%edi
    b7fe:	66 0f 6f 05 0a 44 00 	movdqa 0x440a(%rip),%xmm0        # fc10 <msg.4+0xa0>
    b805:	00 
    b806:	48 89 05 6b 9c 01 00 	mov    %rax,0x19c6b(%rip)        # 25478 <fwp_cleanups>
    b80d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b812:	e8 19 af ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    b817:	48 8b 15 9a 93 01 00 	mov    0x1939a(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b81e:	49 89 c5             	mov    %rax,%r13
    b821:	48 2b 05 68 93 01 00 	sub    0x19368(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b828:	48 c1 e2 10          	shl    $0x10,%rdx
    b82c:	48 39 d0             	cmp    %rdx,%rax
    b82f:	73 59                	jae    b88a <f0+0x1ea>
    b831:	48 89 c2             	mov    %rax,%rdx
    b834:	48 c1 ea 10          	shr    $0x10,%rdx
    b838:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b83c:	48 8b 15 95 93 01 00 	mov    0x19395(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b843:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b847:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b84b:	4d 85 e4             	test   %r12,%r12
    b84e:	74 3a                	je     b88a <f0+0x1ea>
    b850:	0f b6 0a             	movzbl (%rdx),%ecx
    b853:	80 f9 02             	cmp    $0x2,%cl
    b856:	0f 84 74 27 00 00    	je     dfd0 <f0+0x2930>
    b85c:	80 f9 01             	cmp    $0x1,%cl
    b85f:	75 29                	jne    b88a <f0+0x1ea>
    b861:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b864:	0f b7 c0             	movzwl %ax,%eax
    b867:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b86a:	48 0f af c1          	imul   %rcx,%rax
    b86e:	48 c1 e8 20          	shr    $0x20,%rax
    b872:	48 39 d0             	cmp    %rdx,%rax
    b875:	73 13                	jae    b88a <f0+0x1ea>
    b877:	49 01 c4             	add    %rax,%r12
    b87a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b87f:	0f 84 26 29 00 00    	je     e1ab <f0+0x2b0b>
    b885:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b88a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b88f:	bf 01 00 00 00       	mov    $0x1,%edi
    b894:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b899:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b8a0:	00 f0 3f 
    b8a3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b8a8:	e8 83 ae ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    b8ad:	48 8b 15 04 93 01 00 	mov    0x19304(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b8b4:	49 89 c5             	mov    %rax,%r13
    b8b7:	48 2b 05 d2 92 01 00 	sub    0x192d2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b8be:	48 c1 e2 10          	shl    $0x10,%rdx
    b8c2:	48 39 d0             	cmp    %rdx,%rax
    b8c5:	73 59                	jae    b920 <f0+0x280>
    b8c7:	48 89 c2             	mov    %rax,%rdx
    b8ca:	48 c1 ea 10          	shr    $0x10,%rdx
    b8ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b8d2:	48 8b 15 ff 92 01 00 	mov    0x192ff(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b8d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b8dd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b8e1:	4d 85 e4             	test   %r12,%r12
    b8e4:	74 3a                	je     b920 <f0+0x280>
    b8e6:	0f b6 0a             	movzbl (%rdx),%ecx
    b8e9:	80 f9 02             	cmp    $0x2,%cl
    b8ec:	0f 84 ce 26 00 00    	je     dfc0 <f0+0x2920>
    b8f2:	80 f9 01             	cmp    $0x1,%cl
    b8f5:	75 29                	jne    b920 <f0+0x280>
    b8f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8fa:	0f b7 c0             	movzwl %ax,%eax
    b8fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b900:	48 0f af c1          	imul   %rcx,%rax
    b904:	48 c1 e8 20          	shr    $0x20,%rax
    b908:	48 39 d0             	cmp    %rdx,%rax
    b90b:	73 13                	jae    b920 <f0+0x280>
    b90d:	49 01 c4             	add    %rax,%r12
    b910:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b915:	0f 84 9d 28 00 00    	je     e1b8 <f0+0x2b18>
    b91b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b920:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b925:	bf 01 00 00 00       	mov    $0x1,%edi
    b92a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b92f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b936:	33 f3 bf 
    b939:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b93e:	e8 ed ad ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    b943:	48 8b 15 6e 92 01 00 	mov    0x1926e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b94a:	49 89 c5             	mov    %rax,%r13
    b94d:	48 2b 05 3c 92 01 00 	sub    0x1923c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b954:	48 c1 e2 10          	shl    $0x10,%rdx
    b958:	48 39 d0             	cmp    %rdx,%rax
    b95b:	73 59                	jae    b9b6 <f0+0x316>
    b95d:	48 89 c2             	mov    %rax,%rdx
    b960:	48 c1 ea 10          	shr    $0x10,%rdx
    b964:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b968:	48 8b 15 69 92 01 00 	mov    0x19269(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b96f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b973:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b977:	4d 85 e4             	test   %r12,%r12
    b97a:	74 3a                	je     b9b6 <f0+0x316>
    b97c:	0f b6 0a             	movzbl (%rdx),%ecx
    b97f:	80 f9 02             	cmp    $0x2,%cl
    b982:	0f 84 28 26 00 00    	je     dfb0 <f0+0x2910>
    b988:	80 f9 01             	cmp    $0x1,%cl
    b98b:	75 29                	jne    b9b6 <f0+0x316>
    b98d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b990:	0f b7 c0             	movzwl %ax,%eax
    b993:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b996:	48 0f af c1          	imul   %rcx,%rax
    b99a:	48 c1 e8 20          	shr    $0x20,%rax
    b99e:	48 39 d0             	cmp    %rdx,%rax
    b9a1:	73 13                	jae    b9b6 <f0+0x316>
    b9a3:	49 01 c4             	add    %rax,%r12
    b9a6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b9ab:	0f 84 14 28 00 00    	je     e1c5 <f0+0x2b25>
    b9b1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b9b6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b9bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b9c0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b9c5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b9cc:	00 f0 3f 
    b9cf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b9d4:	e8 57 ad ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    b9d9:	48 8b 15 d8 91 01 00 	mov    0x191d8(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b9e0:	49 89 c5             	mov    %rax,%r13
    b9e3:	48 2b 05 a6 91 01 00 	sub    0x191a6(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b9ea:	48 c1 e2 10          	shl    $0x10,%rdx
    b9ee:	48 39 d0             	cmp    %rdx,%rax
    b9f1:	73 59                	jae    ba4c <f0+0x3ac>
    b9f3:	48 89 c2             	mov    %rax,%rdx
    b9f6:	48 c1 ea 10          	shr    $0x10,%rdx
    b9fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b9fe:	48 8b 15 d3 91 01 00 	mov    0x191d3(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ba05:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ba09:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ba0d:	4d 85 e4             	test   %r12,%r12
    ba10:	74 3a                	je     ba4c <f0+0x3ac>
    ba12:	0f b6 0a             	movzbl (%rdx),%ecx
    ba15:	80 f9 02             	cmp    $0x2,%cl
    ba18:	0f 84 f2 25 00 00    	je     e010 <f0+0x2970>
    ba1e:	80 f9 01             	cmp    $0x1,%cl
    ba21:	75 29                	jne    ba4c <f0+0x3ac>
    ba23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ba26:	0f b7 c0             	movzwl %ax,%eax
    ba29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ba2c:	48 0f af c1          	imul   %rcx,%rax
    ba30:	48 c1 e8 20          	shr    $0x20,%rax
    ba34:	48 39 d0             	cmp    %rdx,%rax
    ba37:	73 13                	jae    ba4c <f0+0x3ac>
    ba39:	49 01 c4             	add    %rax,%r12
    ba3c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ba41:	0f 84 8b 27 00 00    	je     e1d2 <f0+0x2b32>
    ba47:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ba4c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ba53:	33 f3 bf 
    ba56:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ba5d:	00 
    ba5e:	bf 01 00 00 00       	mov    $0x1,%edi
    ba63:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    ba6a:	00 
    ba6b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    ba72:	00 
    ba73:	e8 b8 ac ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    ba78:	48 8b 15 39 91 01 00 	mov    0x19139(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ba7f:	49 89 c5             	mov    %rax,%r13
    ba82:	48 2b 05 07 91 01 00 	sub    0x19107(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ba89:	48 c1 e2 10          	shl    $0x10,%rdx
    ba8d:	48 39 d0             	cmp    %rdx,%rax
    ba90:	73 59                	jae    baeb <f0+0x44b>
    ba92:	48 89 c2             	mov    %rax,%rdx
    ba95:	48 c1 ea 10          	shr    $0x10,%rdx
    ba99:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba9d:	48 8b 15 34 91 01 00 	mov    0x19134(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    baa4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    baa8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    baac:	4d 85 e4             	test   %r12,%r12
    baaf:	74 3a                	je     baeb <f0+0x44b>
    bab1:	0f b6 0a             	movzbl (%rdx),%ecx
    bab4:	80 f9 02             	cmp    $0x2,%cl
    bab7:	0f 84 43 25 00 00    	je     e000 <f0+0x2960>
    babd:	80 f9 01             	cmp    $0x1,%cl
    bac0:	75 29                	jne    baeb <f0+0x44b>
    bac2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bac5:	0f b7 c0             	movzwl %ax,%eax
    bac8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bacb:	48 0f af c1          	imul   %rcx,%rax
    bacf:	48 c1 e8 20          	shr    $0x20,%rax
    bad3:	48 39 d0             	cmp    %rdx,%rax
    bad6:	73 13                	jae    baeb <f0+0x44b>
    bad8:	49 01 c4             	add    %rax,%r12
    badb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bae0:	0f 84 f9 26 00 00    	je     e1df <f0+0x2b3f>
    bae6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    baeb:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    baf2:	00 f0 3f 
    baf5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    bafc:	00 
    bafd:	bf 01 00 00 00       	mov    $0x1,%edi
    bb02:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    bb09:	00 
    bb0a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    bb11:	00 
    bb12:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    bb19:	33 f3 bf 
    bb1c:	e8 0f ac ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bb21:	48 89 c7             	mov    %rax,%rdi
    bb24:	e8 b7 ad ff ff       	call   68e0 <fwp_rc_fresh>
    bb29:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    bb30:	00 
    bb31:	bf 01 00 00 00       	mov    $0x1,%edi
    bb36:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    bb3d:	00 
    bb3e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    bb45:	00 
    bb46:	e8 e5 ab ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bb4b:	48 89 c7             	mov    %rax,%rdi
    bb4e:	e8 8d ad ff ff       	call   68e0 <fwp_rc_fresh>
    bb53:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    bb5a:	00 
    bb5b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb60:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    bb67:	00 
    bb68:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    bb6f:	00 
    bb70:	e8 bb ab ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bb75:	48 89 c7             	mov    %rax,%rdi
    bb78:	e8 63 ad ff ff       	call   68e0 <fwp_rc_fresh>
    bb7d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    bb84:	00 
    bb85:	bf 01 00 00 00       	mov    $0x1,%edi
    bb8a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    bb91:	00 
    bb92:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    bb99:	00 
    bb9a:	e8 91 ab ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bb9f:	48 89 c7             	mov    %rax,%rdi
    bba2:	e8 39 ad ff ff       	call   68e0 <fwp_rc_fresh>
    bba7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    bbae:	00 
    bbaf:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    bbbb:	00 
    bbbc:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    bbc3:	00 
    bbc4:	e8 67 ab ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bbc9:	48 89 c7             	mov    %rax,%rdi
    bbcc:	e8 0f ad ff ff       	call   68e0 <fwp_rc_fresh>
    bbd1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    bbd8:	00 
    bbd9:	bf 01 00 00 00       	mov    $0x1,%edi
    bbde:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    bbe5:	00 
    bbe6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    bbed:	00 
    bbee:	e8 3d ab ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bbf3:	48 89 c7             	mov    %rax,%rdi
    bbf6:	e8 e5 ac ff ff       	call   68e0 <fwp_rc_fresh>
    bbfb:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    bc02:	00 
    bc03:	bf 01 00 00 00       	mov    $0x1,%edi
    bc08:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    bc0f:	00 
    bc10:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    bc17:	00 
    bc18:	e8 13 ab ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bc1d:	48 89 c7             	mov    %rax,%rdi
    bc20:	e8 bb ac ff ff       	call   68e0 <fwp_rc_fresh>
    bc25:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    bc2c:	00 
    bc2d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc32:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    bc39:	00 
    bc3a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    bc41:	00 
    bc42:	e8 e9 aa ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bc47:	48 89 c7             	mov    %rax,%rdi
    bc4a:	e8 91 ac ff ff       	call   68e0 <fwp_rc_fresh>
    bc4f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    bc56:	00 
    bc57:	bf 01 00 00 00       	mov    $0x1,%edi
    bc5c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    bc63:	00 
    bc64:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    bc6b:	00 
    bc6c:	e8 bf aa ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bc71:	48 89 c7             	mov    %rax,%rdi
    bc74:	e8 67 ac ff ff       	call   68e0 <fwp_rc_fresh>
    bc79:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    bc80:	00 
    bc81:	bf 01 00 00 00       	mov    $0x1,%edi
    bc86:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    bc8d:	00 
    bc8e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    bc95:	00 
    bc96:	e8 95 aa ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bc9b:	48 89 c7             	mov    %rax,%rdi
    bc9e:	e8 3d ac ff ff       	call   68e0 <fwp_rc_fresh>
    bca3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    bcaa:	00 
    bcab:	bf 01 00 00 00       	mov    $0x1,%edi
    bcb0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    bcb7:	00 
    bcb8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    bcbf:	00 
    bcc0:	e8 6b aa ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bcc5:	48 89 c7             	mov    %rax,%rdi
    bcc8:	e8 13 ac ff ff       	call   68e0 <fwp_rc_fresh>
    bccd:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    bcd4:	00 
    bcd5:	bf 01 00 00 00       	mov    $0x1,%edi
    bcda:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    bce1:	00 
    bce2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    bce9:	00 
    bcea:	e8 41 aa ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bcef:	48 89 c7             	mov    %rax,%rdi
    bcf2:	e8 e9 ab ff ff       	call   68e0 <fwp_rc_fresh>
    bcf7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    bcfe:	00 
    bcff:	bf 01 00 00 00       	mov    $0x1,%edi
    bd04:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    bd0b:	00 
    bd0c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    bd13:	00 
    bd14:	e8 17 aa ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bd19:	48 89 c7             	mov    %rax,%rdi
    bd1c:	e8 bf ab ff ff       	call   68e0 <fwp_rc_fresh>
    bd21:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    bd28:	00 
    bd29:	bf 01 00 00 00       	mov    $0x1,%edi
    bd2e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    bd35:	00 
    bd36:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    bd3d:	00 
    bd3e:	e8 ed a9 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bd43:	48 89 c7             	mov    %rax,%rdi
    bd46:	e8 95 ab ff ff       	call   68e0 <fwp_rc_fresh>
    bd4b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    bd52:	00 
    bd53:	bf 01 00 00 00       	mov    $0x1,%edi
    bd58:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    bd5f:	00 
    bd60:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    bd67:	00 
    bd68:	e8 c3 a9 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bd6d:	48 89 c7             	mov    %rax,%rdi
    bd70:	e8 6b ab ff ff       	call   68e0 <fwp_rc_fresh>
    bd75:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    bd7c:	00 
    bd7d:	bf 01 00 00 00       	mov    $0x1,%edi
    bd82:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    bd89:	00 
    bd8a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    bd91:	00 
    bd92:	e8 99 a9 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bd97:	48 89 c7             	mov    %rax,%rdi
    bd9a:	e8 41 ab ff ff       	call   68e0 <fwp_rc_fresh>
    bd9f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    bda6:	00 
    bda7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdac:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    bdb3:	00 
    bdb4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    bdbb:	00 
    bdbc:	e8 6f a9 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bdc1:	48 89 c7             	mov    %rax,%rdi
    bdc4:	e8 17 ab ff ff       	call   68e0 <fwp_rc_fresh>
    bdc9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    bdd0:	00 
    bdd1:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    bddd:	00 
    bdde:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    bde5:	00 
    bde6:	e8 45 a9 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bdeb:	48 89 c7             	mov    %rax,%rdi
    bdee:	e8 ed aa ff ff       	call   68e0 <fwp_rc_fresh>
    bdf3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    bdfa:	00 
    bdfb:	bf 01 00 00 00       	mov    $0x1,%edi
    be00:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    be07:	00 
    be08:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    be0f:	00 
    be10:	e8 1b a9 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    be15:	48 89 c7             	mov    %rax,%rdi
    be18:	e8 c3 aa ff ff       	call   68e0 <fwp_rc_fresh>
    be1d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    be24:	00 
    be25:	bf 01 00 00 00       	mov    $0x1,%edi
    be2a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    be31:	00 
    be32:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    be39:	00 
    be3a:	e8 f1 a8 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    be3f:	48 89 c7             	mov    %rax,%rdi
    be42:	e8 99 aa ff ff       	call   68e0 <fwp_rc_fresh>
    be47:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    be4e:	00 
    be4f:	bf 01 00 00 00       	mov    $0x1,%edi
    be54:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    be5b:	00 
    be5c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    be63:	00 
    be64:	e8 c7 a8 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    be69:	48 89 c7             	mov    %rax,%rdi
    be6c:	e8 6f aa ff ff       	call   68e0 <fwp_rc_fresh>
    be71:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    be78:	00 
    be79:	bf 01 00 00 00       	mov    $0x1,%edi
    be7e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    be85:	00 
    be86:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    be8d:	00 
    be8e:	e8 9d a8 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    be93:	48 89 c7             	mov    %rax,%rdi
    be96:	e8 45 aa ff ff       	call   68e0 <fwp_rc_fresh>
    be9b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    bea2:	00 
    bea3:	bf 01 00 00 00       	mov    $0x1,%edi
    bea8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    beaf:	00 
    beb0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    beb7:	00 
    beb8:	e8 73 a8 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bebd:	48 89 c7             	mov    %rax,%rdi
    bec0:	e8 1b aa ff ff       	call   68e0 <fwp_rc_fresh>
    bec5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    becc:	00 
    becd:	bf 01 00 00 00       	mov    $0x1,%edi
    bed2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    bed9:	00 
    beda:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    bee1:	00 
    bee2:	e8 49 a8 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bee7:	48 89 c7             	mov    %rax,%rdi
    beea:	e8 f1 a9 ff ff       	call   68e0 <fwp_rc_fresh>
    beef:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bef6:	00 
    bef7:	bf 01 00 00 00       	mov    $0x1,%edi
    befc:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    bf03:	00 
    bf04:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    bf0b:	00 
    bf0c:	e8 1f a8 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bf11:	48 89 c7             	mov    %rax,%rdi
    bf14:	e8 c7 a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bf19:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bf20:	00 
    bf21:	bf 01 00 00 00       	mov    $0x1,%edi
    bf26:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    bf2d:	00 
    bf2e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bf35:	00 
    bf36:	e8 f5 a7 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bf3b:	48 89 c7             	mov    %rax,%rdi
    bf3e:	e8 9d a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bf43:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    bf4a:	00 
    bf4b:	bf 01 00 00 00       	mov    $0x1,%edi
    bf50:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bf57:	00 
    bf58:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    bf5f:	00 
    bf60:	e8 cb a7 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bf65:	48 89 c7             	mov    %rax,%rdi
    bf68:	e8 73 a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bf6d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    bf74:	00 
    bf75:	bf 01 00 00 00       	mov    $0x1,%edi
    bf7a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bf81:	00 
    bf82:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bf89:	00 
    bf8a:	e8 a1 a7 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bf8f:	48 89 c7             	mov    %rax,%rdi
    bf92:	e8 49 a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bf97:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bf9e:	00 
    bf9f:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bfab:	00 
    bfac:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bfb3:	00 
    bfb4:	e8 77 a7 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bfb9:	48 89 c7             	mov    %rax,%rdi
    bfbc:	e8 1f a9 ff ff       	call   68e0 <fwp_rc_fresh>
    bfc1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bfc8:	00 
    bfc9:	bf 01 00 00 00       	mov    $0x1,%edi
    bfce:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bfd5:	00 
    bfd6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    bfdd:	00 
    bfde:	e8 4d a7 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    bfe3:	48 89 c7             	mov    %rax,%rdi
    bfe6:	e8 f5 a8 ff ff       	call   68e0 <fwp_rc_fresh>
    bfeb:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    bff2:	00 
    bff3:	bf 01 00 00 00       	mov    $0x1,%edi
    bff8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    bfff:	00 
    c000:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    c007:	00 
    c008:	e8 23 a7 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c00d:	48 89 c7             	mov    %rax,%rdi
    c010:	e8 cb a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c015:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    c01c:	00 
    c01d:	bf 01 00 00 00       	mov    $0x1,%edi
    c022:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    c029:	00 
    c02a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    c031:	00 
    c032:	e8 f9 a6 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c037:	48 89 c7             	mov    %rax,%rdi
    c03a:	e8 a1 a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c03f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    c046:	00 
    c047:	bf 01 00 00 00       	mov    $0x1,%edi
    c04c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    c053:	00 
    c054:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    c05b:	00 
    c05c:	e8 cf a6 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c061:	48 89 c7             	mov    %rax,%rdi
    c064:	e8 77 a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c069:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    c070:	00 
    c071:	bf 01 00 00 00       	mov    $0x1,%edi
    c076:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    c07d:	00 
    c07e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    c085:	00 
    c086:	e8 a5 a6 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c08b:	48 89 c7             	mov    %rax,%rdi
    c08e:	e8 4d a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c093:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    c09a:	00 
    c09b:	bf 01 00 00 00       	mov    $0x1,%edi
    c0a0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    c0a7:	00 
    c0a8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    c0af:	00 
    c0b0:	e8 7b a6 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c0b5:	48 89 c7             	mov    %rax,%rdi
    c0b8:	e8 23 a8 ff ff       	call   68e0 <fwp_rc_fresh>
    c0bd:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    c0c4:	00 
    c0c5:	bf 01 00 00 00       	mov    $0x1,%edi
    c0ca:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    c0d1:	00 
    c0d2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    c0d9:	00 
    c0da:	e8 51 a6 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c0df:	48 89 c7             	mov    %rax,%rdi
    c0e2:	e8 f9 a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c0e7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    c0ee:	00 
    c0ef:	bf 01 00 00 00       	mov    $0x1,%edi
    c0f4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    c0fb:	00 
    c0fc:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    c103:	00 
    c104:	e8 27 a6 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c109:	48 89 c7             	mov    %rax,%rdi
    c10c:	e8 cf a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c111:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    c118:	00 
    c119:	bf 01 00 00 00       	mov    $0x1,%edi
    c11e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    c125:	00 
    c126:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    c12d:	00 
    c12e:	e8 fd a5 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c133:	48 89 c7             	mov    %rax,%rdi
    c136:	e8 a5 a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c13b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    c142:	00 
    c143:	bf 01 00 00 00       	mov    $0x1,%edi
    c148:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    c14f:	00 
    c150:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    c157:	00 
    c158:	e8 d3 a5 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c15d:	48 89 c7             	mov    %rax,%rdi
    c160:	e8 7b a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c165:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c16c:	00 
    c16d:	bf 01 00 00 00       	mov    $0x1,%edi
    c172:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    c179:	00 
    c17a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c181:	00 
    c182:	e8 a9 a5 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c187:	48 89 c7             	mov    %rax,%rdi
    c18a:	e8 51 a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c18f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c196:	00 
    c197:	bf 01 00 00 00       	mov    $0x1,%edi
    c19c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    c1a3:	00 
    c1a4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c1ab:	00 
    c1ac:	e8 7f a5 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c1b1:	48 89 c7             	mov    %rax,%rdi
    c1b4:	e8 27 a7 ff ff       	call   68e0 <fwp_rc_fresh>
    c1b9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c1c0:	00 
    c1c1:	bf 01 00 00 00       	mov    $0x1,%edi
    c1c6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    c1cd:	00 
    c1ce:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c1d5:	00 
    c1d6:	e8 55 a5 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c1db:	48 89 c7             	mov    %rax,%rdi
    c1de:	e8 fd a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c1e3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c1ea:	00 
    c1eb:	bf 01 00 00 00       	mov    $0x1,%edi
    c1f0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    c1f7:	00 
    c1f8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c1ff:	00 
    c200:	e8 2b a5 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c205:	48 89 c7             	mov    %rax,%rdi
    c208:	e8 d3 a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c20d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c214:	00 
    c215:	bf 01 00 00 00       	mov    $0x1,%edi
    c21a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    c221:	00 
    c222:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c229:	00 
    c22a:	e8 01 a5 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c22f:	48 89 c7             	mov    %rax,%rdi
    c232:	e8 a9 a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c237:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c23e:	00 
    c23f:	bf 01 00 00 00       	mov    $0x1,%edi
    c244:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    c24b:	00 
    c24c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c253:	00 
    c254:	e8 d7 a4 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c259:	48 89 c7             	mov    %rax,%rdi
    c25c:	e8 7f a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c261:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c268:	00 
    c269:	bf 01 00 00 00       	mov    $0x1,%edi
    c26e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    c275:	00 
    c276:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c27d:	00 
    c27e:	e8 ad a4 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c283:	48 89 c7             	mov    %rax,%rdi
    c286:	e8 55 a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c28b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c292:	00 
    c293:	bf 01 00 00 00       	mov    $0x1,%edi
    c298:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    c29f:	00 
    c2a0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c2a7:	00 
    c2a8:	e8 83 a4 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c2ad:	48 89 c7             	mov    %rax,%rdi
    c2b0:	e8 2b a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c2b5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c2bc:	00 
    c2bd:	bf 01 00 00 00       	mov    $0x1,%edi
    c2c2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    c2c9:	00 
    c2ca:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c2d1:	00 
    c2d2:	e8 59 a4 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c2d7:	48 89 c7             	mov    %rax,%rdi
    c2da:	e8 01 a6 ff ff       	call   68e0 <fwp_rc_fresh>
    c2df:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c2e6:	00 
    c2e7:	bf 01 00 00 00       	mov    $0x1,%edi
    c2ec:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    c2f3:	00 
    c2f4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c2fb:	00 
    c2fc:	e8 2f a4 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c301:	48 89 c7             	mov    %rax,%rdi
    c304:	e8 d7 a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c309:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c310:	00 
    c311:	bf 01 00 00 00       	mov    $0x1,%edi
    c316:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    c31d:	00 
    c31e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c325:	00 
    c326:	e8 05 a4 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c32b:	48 89 c7             	mov    %rax,%rdi
    c32e:	e8 ad a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c333:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c33a:	00 
    c33b:	bf 01 00 00 00       	mov    $0x1,%edi
    c340:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    c347:	00 
    c348:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c34f:	00 
    c350:	e8 db a3 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c355:	48 89 c7             	mov    %rax,%rdi
    c358:	e8 83 a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c35d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c364:	00 
    c365:	bf 01 00 00 00       	mov    $0x1,%edi
    c36a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    c371:	00 
    c372:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c379:	00 
    c37a:	e8 b1 a3 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c37f:	48 89 c7             	mov    %rax,%rdi
    c382:	e8 59 a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c387:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c38e:	00 
    c38f:	bf 01 00 00 00       	mov    $0x1,%edi
    c394:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    c39b:	00 
    c39c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c3a3:	00 
    c3a4:	e8 87 a3 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c3a9:	48 89 c7             	mov    %rax,%rdi
    c3ac:	e8 2f a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c3b1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c3b8:	00 
    c3b9:	bf 01 00 00 00       	mov    $0x1,%edi
    c3be:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c3c5:	00 
    c3c6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c3cd:	00 
    c3ce:	e8 5d a3 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c3d3:	48 89 c7             	mov    %rax,%rdi
    c3d6:	e8 05 a5 ff ff       	call   68e0 <fwp_rc_fresh>
    c3db:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c3e2:	00 
    c3e3:	bf 01 00 00 00       	mov    $0x1,%edi
    c3e8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c3ef:	00 
    c3f0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c3f7:	00 
    c3f8:	e8 33 a3 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c3fd:	48 89 c7             	mov    %rax,%rdi
    c400:	e8 db a4 ff ff       	call   68e0 <fwp_rc_fresh>
    c405:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c40c:	00 
    c40d:	bf 01 00 00 00       	mov    $0x1,%edi
    c412:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c419:	00 
    c41a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c421:	00 
    c422:	e8 09 a3 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c427:	48 89 c7             	mov    %rax,%rdi
    c42a:	e8 b1 a4 ff ff       	call   68e0 <fwp_rc_fresh>
    c42f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c436:	00 
    c437:	bf 01 00 00 00       	mov    $0x1,%edi
    c43c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c443:	00 
    c444:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c44b:	00 
    c44c:	e8 df a2 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c451:	48 89 c7             	mov    %rax,%rdi
    c454:	e8 87 a4 ff ff       	call   68e0 <fwp_rc_fresh>
    c459:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c460:	00 
    c461:	bf 01 00 00 00       	mov    $0x1,%edi
    c466:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c46d:	00 
    c46e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c475:	00 
    c476:	e8 b5 a2 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c47b:	48 89 c7             	mov    %rax,%rdi
    c47e:	e8 5d a4 ff ff       	call   68e0 <fwp_rc_fresh>
    c483:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c48a:	00 
    c48b:	bf 01 00 00 00       	mov    $0x1,%edi
    c490:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c497:	00 
    c498:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c49f:	00 
    c4a0:	e8 8b a2 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c4a5:	48 89 c7             	mov    %rax,%rdi
    c4a8:	e8 33 a4 ff ff       	call   68e0 <fwp_rc_fresh>
    c4ad:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c4b4:	00 
    c4b5:	bf 01 00 00 00       	mov    $0x1,%edi
    c4ba:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c4c1:	00 
    c4c2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c4c9:	00 
    c4ca:	e8 61 a2 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c4cf:	48 89 c7             	mov    %rax,%rdi
    c4d2:	e8 09 a4 ff ff       	call   68e0 <fwp_rc_fresh>
    c4d7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c4de:	00 
    c4df:	bf 01 00 00 00       	mov    $0x1,%edi
    c4e4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c4eb:	00 
    c4ec:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c4f3:	00 
    c4f4:	e8 37 a2 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c4f9:	48 89 c7             	mov    %rax,%rdi
    c4fc:	e8 df a3 ff ff       	call   68e0 <fwp_rc_fresh>
    c501:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c508:	00 
    c509:	bf 01 00 00 00       	mov    $0x1,%edi
    c50e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c515:	00 
    c516:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c51d:	00 
    c51e:	e8 0d a2 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c523:	48 89 c7             	mov    %rax,%rdi
    c526:	e8 b5 a3 ff ff       	call   68e0 <fwp_rc_fresh>
    c52b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c532:	00 
    c533:	bf 01 00 00 00       	mov    $0x1,%edi
    c538:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c53f:	00 
    c540:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c547:	00 
    c548:	e8 e3 a1 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c54d:	48 89 c7             	mov    %rax,%rdi
    c550:	e8 8b a3 ff ff       	call   68e0 <fwp_rc_fresh>
    c555:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c55c:	00 
    c55d:	bf 01 00 00 00       	mov    $0x1,%edi
    c562:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c569:	00 
    c56a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c571:	00 
    c572:	e8 b9 a1 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c577:	48 89 c7             	mov    %rax,%rdi
    c57a:	e8 61 a3 ff ff       	call   68e0 <fwp_rc_fresh>
    c57f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c586:	00 
    c587:	bf 01 00 00 00       	mov    $0x1,%edi
    c58c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c593:	00 
    c594:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c59b:	00 
    c59c:	e8 8f a1 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c5a1:	48 89 c7             	mov    %rax,%rdi
    c5a4:	e8 37 a3 ff ff       	call   68e0 <fwp_rc_fresh>
    c5a9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c5b0:	00 
    c5b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c5b6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c5bd:	00 
    c5be:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c5c5:	00 
    c5c6:	e8 65 a1 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c5cb:	48 89 c7             	mov    %rax,%rdi
    c5ce:	e8 0d a3 ff ff       	call   68e0 <fwp_rc_fresh>
    c5d3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c5da:	00 
    c5db:	bf 01 00 00 00       	mov    $0x1,%edi
    c5e0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c5e7:	00 
    c5e8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c5ef:	00 
    c5f0:	e8 3b a1 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c5f5:	48 89 c7             	mov    %rax,%rdi
    c5f8:	e8 e3 a2 ff ff       	call   68e0 <fwp_rc_fresh>
    c5fd:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c604:	00 
    c605:	bf 01 00 00 00       	mov    $0x1,%edi
    c60a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c611:	00 
    c612:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c619:	00 
    c61a:	e8 11 a1 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c61f:	48 89 c7             	mov    %rax,%rdi
    c622:	e8 b9 a2 ff ff       	call   68e0 <fwp_rc_fresh>
    c627:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c62e:	00 
    c62f:	bf 01 00 00 00       	mov    $0x1,%edi
    c634:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c63b:	00 
    c63c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c643:	00 
    c644:	e8 e7 a0 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c649:	48 89 c7             	mov    %rax,%rdi
    c64c:	e8 8f a2 ff ff       	call   68e0 <fwp_rc_fresh>
    c651:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c658:	00 
    c659:	bf 01 00 00 00       	mov    $0x1,%edi
    c65e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c665:	00 
    c666:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c66d:	00 
    c66e:	e8 bd a0 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c673:	48 89 c7             	mov    %rax,%rdi
    c676:	e8 65 a2 ff ff       	call   68e0 <fwp_rc_fresh>
    c67b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c682:	00 
    c683:	bf 01 00 00 00       	mov    $0x1,%edi
    c688:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c68f:	00 
    c690:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c697:	00 
    c698:	e8 93 a0 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c69d:	48 89 c7             	mov    %rax,%rdi
    c6a0:	e8 3b a2 ff ff       	call   68e0 <fwp_rc_fresh>
    c6a5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c6ac:	00 
    c6ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c6b2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c6b9:	00 
    c6ba:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c6c1:	00 
    c6c2:	e8 69 a0 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c6c7:	48 89 c7             	mov    %rax,%rdi
    c6ca:	e8 11 a2 ff ff       	call   68e0 <fwp_rc_fresh>
    c6cf:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c6d6:	00 
    c6d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c6dc:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c6e3:	00 
    c6e4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c6eb:	00 
    c6ec:	e8 3f a0 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c6f1:	48 89 c7             	mov    %rax,%rdi
    c6f4:	e8 e7 a1 ff ff       	call   68e0 <fwp_rc_fresh>
    c6f9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c700:	00 
    c701:	bf 01 00 00 00       	mov    $0x1,%edi
    c706:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c70d:	00 
    c70e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c715:	00 
    c716:	e8 15 a0 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c71b:	48 89 c7             	mov    %rax,%rdi
    c71e:	e8 bd a1 ff ff       	call   68e0 <fwp_rc_fresh>
    c723:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c72a:	00 
    c72b:	bf 01 00 00 00       	mov    $0x1,%edi
    c730:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c737:	00 
    c738:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c73f:	00 
    c740:	e8 eb 9f ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c745:	48 89 c7             	mov    %rax,%rdi
    c748:	e8 93 a1 ff ff       	call   68e0 <fwp_rc_fresh>
    c74d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c754:	00 
    c755:	bf 01 00 00 00       	mov    $0x1,%edi
    c75a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c761:	00 
    c762:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c769:	00 
    c76a:	e8 c1 9f ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c76f:	48 89 c7             	mov    %rax,%rdi
    c772:	e8 69 a1 ff ff       	call   68e0 <fwp_rc_fresh>
    c777:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c77e:	00 
    c77f:	bf 01 00 00 00       	mov    $0x1,%edi
    c784:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c78b:	00 
    c78c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c793:	00 
    c794:	e8 97 9f ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c799:	48 89 c7             	mov    %rax,%rdi
    c79c:	e8 3f a1 ff ff       	call   68e0 <fwp_rc_fresh>
    c7a1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c7a8:	00 
    c7a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c7ae:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c7b5:	00 
    c7b6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c7bd:	00 
    c7be:	e8 6d 9f ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c7c3:	48 89 c7             	mov    %rax,%rdi
    c7c6:	e8 15 a1 ff ff       	call   68e0 <fwp_rc_fresh>
    c7cb:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c7d2:	00 
    c7d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c7d8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c7df:	00 
    c7e0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c7e7:	00 
    c7e8:	e8 43 9f ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c7ed:	48 89 c7             	mov    %rax,%rdi
    c7f0:	e8 eb a0 ff ff       	call   68e0 <fwp_rc_fresh>
    c7f5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c7fc:	00 
    c7fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c802:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c809:	00 
    c80a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c811:	00 
    c812:	e8 19 9f ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c817:	48 89 c7             	mov    %rax,%rdi
    c81a:	e8 c1 a0 ff ff       	call   68e0 <fwp_rc_fresh>
    c81f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c826:	00 
    c827:	bf 01 00 00 00       	mov    $0x1,%edi
    c82c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c833:	00 
    c834:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c83b:	00 
    c83c:	e8 ef 9e ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c841:	48 89 c7             	mov    %rax,%rdi
    c844:	e8 97 a0 ff ff       	call   68e0 <fwp_rc_fresh>
    c849:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c850:	00 
    c851:	bf 01 00 00 00       	mov    $0x1,%edi
    c856:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c85d:	00 
    c85e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c865:	00 
    c866:	e8 c5 9e ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c86b:	48 89 c7             	mov    %rax,%rdi
    c86e:	e8 6d a0 ff ff       	call   68e0 <fwp_rc_fresh>
    c873:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c87a:	00 
    c87b:	bf 01 00 00 00       	mov    $0x1,%edi
    c880:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c887:	00 
    c888:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c88f:	00 
    c890:	e8 9b 9e ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c895:	48 89 c7             	mov    %rax,%rdi
    c898:	e8 43 a0 ff ff       	call   68e0 <fwp_rc_fresh>
    c89d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c8a4:	00 
    c8a5:	bf 01 00 00 00       	mov    $0x1,%edi
    c8aa:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c8b1:	00 
    c8b2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c8b9:	00 
    c8ba:	e8 71 9e ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c8bf:	48 89 c7             	mov    %rax,%rdi
    c8c2:	e8 19 a0 ff ff       	call   68e0 <fwp_rc_fresh>
    c8c7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c8ce:	00 
    c8cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c8d4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c8db:	00 
    c8dc:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c8e3:	00 
    c8e4:	e8 47 9e ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c8e9:	48 89 c7             	mov    %rax,%rdi
    c8ec:	e8 ef 9f ff ff       	call   68e0 <fwp_rc_fresh>
    c8f1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c8f8:	00 
    c8f9:	bf 01 00 00 00       	mov    $0x1,%edi
    c8fe:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c905:	00 
    c906:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c90d:	00 
    c90e:	e8 1d 9e ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c913:	48 89 c7             	mov    %rax,%rdi
    c916:	e8 c5 9f ff ff       	call   68e0 <fwp_rc_fresh>
    c91b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c922:	00 
    c923:	bf 01 00 00 00       	mov    $0x1,%edi
    c928:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c92f:	00 
    c930:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c937:	00 
    c938:	e8 f3 9d ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c93d:	48 89 c7             	mov    %rax,%rdi
    c940:	e8 9b 9f ff ff       	call   68e0 <fwp_rc_fresh>
    c945:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c94c:	00 
    c94d:	bf 01 00 00 00       	mov    $0x1,%edi
    c952:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c959:	00 
    c95a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c961:	00 
    c962:	e8 c9 9d ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c967:	48 89 c7             	mov    %rax,%rdi
    c96a:	e8 71 9f ff ff       	call   68e0 <fwp_rc_fresh>
    c96f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c976:	00 
    c977:	bf 01 00 00 00       	mov    $0x1,%edi
    c97c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c983:	00 
    c984:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c98b:	00 
    c98c:	e8 9f 9d ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c991:	48 89 c7             	mov    %rax,%rdi
    c994:	e8 47 9f ff ff       	call   68e0 <fwp_rc_fresh>
    c999:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c9a0:	00 
    c9a1:	bf 01 00 00 00       	mov    $0x1,%edi
    c9a6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c9ad:	00 
    c9ae:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c9b5:	00 
    c9b6:	e8 75 9d ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c9bb:	48 89 c7             	mov    %rax,%rdi
    c9be:	e8 1d 9f ff ff       	call   68e0 <fwp_rc_fresh>
    c9c3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c9ca:	00 
    c9cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c9d0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c9d7:	00 
    c9d8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c9df:	00 
    c9e0:	e8 4b 9d ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    c9e5:	48 8b 15 cc 81 01 00 	mov    0x181cc(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c9ec:	49 89 c5             	mov    %rax,%r13
    c9ef:	48 2b 05 9a 81 01 00 	sub    0x1819a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c9f6:	48 c1 e2 10          	shl    $0x10,%rdx
    c9fa:	48 39 d0             	cmp    %rdx,%rax
    c9fd:	73 59                	jae    ca58 <f0+0x13b8>
    c9ff:	48 89 c2             	mov    %rax,%rdx
    ca02:	48 c1 ea 10          	shr    $0x10,%rdx
    ca06:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca0a:	48 8b 15 c7 81 01 00 	mov    0x181c7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ca11:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca15:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca19:	4d 85 e4             	test   %r12,%r12
    ca1c:	74 3a                	je     ca58 <f0+0x13b8>
    ca1e:	0f b6 0a             	movzbl (%rdx),%ecx
    ca21:	80 f9 02             	cmp    $0x2,%cl
    ca24:	0f 84 c6 15 00 00    	je     dff0 <f0+0x2950>
    ca2a:	80 f9 01             	cmp    $0x1,%cl
    ca2d:	75 29                	jne    ca58 <f0+0x13b8>
    ca2f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca32:	0f b7 c0             	movzwl %ax,%eax
    ca35:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca38:	48 0f af c1          	imul   %rcx,%rax
    ca3c:	48 c1 e8 20          	shr    $0x20,%rax
    ca40:	48 39 d0             	cmp    %rdx,%rax
    ca43:	73 13                	jae    ca58 <f0+0x13b8>
    ca45:	49 01 c4             	add    %rax,%r12
    ca48:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca4d:	0f 84 99 17 00 00    	je     e1ec <f0+0x2b4c>
    ca53:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca58:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca5f:	33 f3 bf 
    ca62:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    ca69:	00 
    ca6a:	bf 01 00 00 00       	mov    $0x1,%edi
    ca6f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    ca76:	00 
    ca77:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    ca7e:	00 
    ca7f:	e8 ac 9c ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    ca84:	48 8b 15 2d 81 01 00 	mov    0x1812d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ca8b:	49 89 c5             	mov    %rax,%r13
    ca8e:	48 2b 05 fb 80 01 00 	sub    0x180fb(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ca95:	48 c1 e2 10          	shl    $0x10,%rdx
    ca99:	48 39 d0             	cmp    %rdx,%rax
    ca9c:	73 59                	jae    caf7 <f0+0x1457>
    ca9e:	48 89 c2             	mov    %rax,%rdx
    caa1:	48 c1 ea 10          	shr    $0x10,%rdx
    caa5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    caa9:	48 8b 15 28 81 01 00 	mov    0x18128(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cab0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cab4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cab8:	4d 85 e4             	test   %r12,%r12
    cabb:	74 3a                	je     caf7 <f0+0x1457>
    cabd:	0f b6 0a             	movzbl (%rdx),%ecx
    cac0:	80 f9 02             	cmp    $0x2,%cl
    cac3:	0f 84 17 15 00 00    	je     dfe0 <f0+0x2940>
    cac9:	80 f9 01             	cmp    $0x1,%cl
    cacc:	75 29                	jne    caf7 <f0+0x1457>
    cace:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cad1:	0f b7 c0             	movzwl %ax,%eax
    cad4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cad7:	48 0f af c1          	imul   %rcx,%rax
    cadb:	48 c1 e8 20          	shr    $0x20,%rax
    cadf:	48 39 d0             	cmp    %rdx,%rax
    cae2:	73 13                	jae    caf7 <f0+0x1457>
    cae4:	49 01 c4             	add    %rax,%r12
    cae7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    caec:	0f 84 07 17 00 00    	je     e1f9 <f0+0x2b59>
    caf2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    caf7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cafe:	00 f0 3f 
    cb01:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    cb08:	00 
    cb09:	bf 01 00 00 00       	mov    $0x1,%edi
    cb0e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    cb15:	00 
    cb16:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    cb1d:	00 
    cb1e:	e8 0d 9c ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    cb23:	48 8b 15 8e 80 01 00 	mov    0x1808e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cb2a:	49 89 c5             	mov    %rax,%r13
    cb2d:	48 2b 05 5c 80 01 00 	sub    0x1805c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cb34:	48 c1 e2 10          	shl    $0x10,%rdx
    cb38:	48 39 d0             	cmp    %rdx,%rax
    cb3b:	73 59                	jae    cb96 <f0+0x14f6>
    cb3d:	48 89 c2             	mov    %rax,%rdx
    cb40:	48 c1 ea 10          	shr    $0x10,%rdx
    cb44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb48:	48 8b 15 89 80 01 00 	mov    0x18089(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cb4f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb53:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb57:	4d 85 e4             	test   %r12,%r12
    cb5a:	74 3a                	je     cb96 <f0+0x14f6>
    cb5c:	0f b6 0a             	movzbl (%rdx),%ecx
    cb5f:	80 f9 02             	cmp    $0x2,%cl
    cb62:	0f 84 28 15 00 00    	je     e090 <f0+0x29f0>
    cb68:	80 f9 01             	cmp    $0x1,%cl
    cb6b:	75 29                	jne    cb96 <f0+0x14f6>
    cb6d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb70:	0f b7 c0             	movzwl %ax,%eax
    cb73:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb76:	48 0f af c1          	imul   %rcx,%rax
    cb7a:	48 c1 e8 20          	shr    $0x20,%rax
    cb7e:	48 39 d0             	cmp    %rdx,%rax
    cb81:	73 13                	jae    cb96 <f0+0x14f6>
    cb83:	49 01 c4             	add    %rax,%r12
    cb86:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb8b:	0f 84 75 16 00 00    	je     e206 <f0+0x2b66>
    cb91:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb96:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb9d:	33 f3 bf 
    cba0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    cba7:	00 
    cba8:	bf 01 00 00 00       	mov    $0x1,%edi
    cbad:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    cbb4:	00 
    cbb5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    cbbc:	00 
    cbbd:	e8 6e 9b ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    cbc2:	48 8b 15 ef 7f 01 00 	mov    0x17fef(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cbc9:	49 89 c5             	mov    %rax,%r13
    cbcc:	48 2b 05 bd 7f 01 00 	sub    0x17fbd(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cbd3:	48 c1 e2 10          	shl    $0x10,%rdx
    cbd7:	48 39 d0             	cmp    %rdx,%rax
    cbda:	73 59                	jae    cc35 <f0+0x1595>
    cbdc:	48 89 c2             	mov    %rax,%rdx
    cbdf:	48 c1 ea 10          	shr    $0x10,%rdx
    cbe3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbe7:	48 8b 15 ea 7f 01 00 	mov    0x17fea(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cbee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbf2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbf6:	4d 85 e4             	test   %r12,%r12
    cbf9:	74 3a                	je     cc35 <f0+0x1595>
    cbfb:	0f b6 0a             	movzbl (%rdx),%ecx
    cbfe:	80 f9 02             	cmp    $0x2,%cl
    cc01:	0f 84 79 14 00 00    	je     e080 <f0+0x29e0>
    cc07:	80 f9 01             	cmp    $0x1,%cl
    cc0a:	75 29                	jne    cc35 <f0+0x1595>
    cc0c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc0f:	0f b7 c0             	movzwl %ax,%eax
    cc12:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc15:	48 0f af c1          	imul   %rcx,%rax
    cc19:	48 c1 e8 20          	shr    $0x20,%rax
    cc1d:	48 39 d0             	cmp    %rdx,%rax
    cc20:	73 13                	jae    cc35 <f0+0x1595>
    cc22:	49 01 c4             	add    %rax,%r12
    cc25:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc2a:	0f 84 e3 15 00 00    	je     e213 <f0+0x2b73>
    cc30:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc35:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc3c:	00 f0 3f 
    cc3f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    cc46:	00 
    cc47:	bf 01 00 00 00       	mov    $0x1,%edi
    cc4c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    cc53:	00 
    cc54:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    cc5b:	00 
    cc5c:	e8 cf 9a ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    cc61:	48 8b 15 50 7f 01 00 	mov    0x17f50(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cc68:	49 89 c5             	mov    %rax,%r13
    cc6b:	48 2b 05 1e 7f 01 00 	sub    0x17f1e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cc72:	48 c1 e2 10          	shl    $0x10,%rdx
    cc76:	48 39 d0             	cmp    %rdx,%rax
    cc79:	73 59                	jae    ccd4 <f0+0x1634>
    cc7b:	48 89 c2             	mov    %rax,%rdx
    cc7e:	48 c1 ea 10          	shr    $0x10,%rdx
    cc82:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc86:	48 8b 15 4b 7f 01 00 	mov    0x17f4b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cc8d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc91:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc95:	4d 85 e4             	test   %r12,%r12
    cc98:	74 3a                	je     ccd4 <f0+0x1634>
    cc9a:	0f b6 0a             	movzbl (%rdx),%ecx
    cc9d:	80 f9 02             	cmp    $0x2,%cl
    cca0:	0f 84 ca 13 00 00    	je     e070 <f0+0x29d0>
    cca6:	80 f9 01             	cmp    $0x1,%cl
    cca9:	75 29                	jne    ccd4 <f0+0x1634>
    ccab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccae:	0f b7 c0             	movzwl %ax,%eax
    ccb1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccb4:	48 0f af c1          	imul   %rcx,%rax
    ccb8:	48 c1 e8 20          	shr    $0x20,%rax
    ccbc:	48 39 d0             	cmp    %rdx,%rax
    ccbf:	73 13                	jae    ccd4 <f0+0x1634>
    ccc1:	49 01 c4             	add    %rax,%r12
    ccc4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ccc9:	0f 84 51 15 00 00    	je     e220 <f0+0x2b80>
    cccf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccd4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccdb:	33 f3 bf 
    ccde:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    cce5:	00 
    cce6:	bf 01 00 00 00       	mov    $0x1,%edi
    cceb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    ccf2:	00 
    ccf3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    ccfa:	00 
    ccfb:	e8 30 9a ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    cd00:	48 8b 15 b1 7e 01 00 	mov    0x17eb1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cd07:	49 89 c5             	mov    %rax,%r13
    cd0a:	48 2b 05 7f 7e 01 00 	sub    0x17e7f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cd11:	48 c1 e2 10          	shl    $0x10,%rdx
    cd15:	48 39 d0             	cmp    %rdx,%rax
    cd18:	73 59                	jae    cd73 <f0+0x16d3>
    cd1a:	48 89 c2             	mov    %rax,%rdx
    cd1d:	48 c1 ea 10          	shr    $0x10,%rdx
    cd21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd25:	48 8b 15 ac 7e 01 00 	mov    0x17eac(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cd2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd30:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd34:	4d 85 e4             	test   %r12,%r12
    cd37:	74 3a                	je     cd73 <f0+0x16d3>
    cd39:	0f b6 0a             	movzbl (%rdx),%ecx
    cd3c:	80 f9 02             	cmp    $0x2,%cl
    cd3f:	0f 84 1b 13 00 00    	je     e060 <f0+0x29c0>
    cd45:	80 f9 01             	cmp    $0x1,%cl
    cd48:	75 29                	jne    cd73 <f0+0x16d3>
    cd4a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd4d:	0f b7 c0             	movzwl %ax,%eax
    cd50:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd53:	48 0f af c1          	imul   %rcx,%rax
    cd57:	48 c1 e8 20          	shr    $0x20,%rax
    cd5b:	48 39 d0             	cmp    %rdx,%rax
    cd5e:	73 13                	jae    cd73 <f0+0x16d3>
    cd60:	49 01 c4             	add    %rax,%r12
    cd63:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd68:	0f 84 bf 14 00 00    	je     e22d <f0+0x2b8d>
    cd6e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd73:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd7a:	00 f0 3f 
    cd7d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    cd84:	00 
    cd85:	bf 01 00 00 00       	mov    $0x1,%edi
    cd8a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    cd91:	00 
    cd92:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    cd99:	00 
    cd9a:	e8 91 99 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    cd9f:	48 8b 15 12 7e 01 00 	mov    0x17e12(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cda6:	49 89 c5             	mov    %rax,%r13
    cda9:	48 2b 05 e0 7d 01 00 	sub    0x17de0(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cdb0:	48 c1 e2 10          	shl    $0x10,%rdx
    cdb4:	48 39 d0             	cmp    %rdx,%rax
    cdb7:	73 59                	jae    ce12 <f0+0x1772>
    cdb9:	48 89 c2             	mov    %rax,%rdx
    cdbc:	48 c1 ea 10          	shr    $0x10,%rdx
    cdc0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdc4:	48 8b 15 0d 7e 01 00 	mov    0x17e0d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cdcb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdcf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdd3:	4d 85 e4             	test   %r12,%r12
    cdd6:	74 3a                	je     ce12 <f0+0x1772>
    cdd8:	0f b6 0a             	movzbl (%rdx),%ecx
    cddb:	80 f9 02             	cmp    $0x2,%cl
    cdde:	0f 84 6c 12 00 00    	je     e050 <f0+0x29b0>
    cde4:	80 f9 01             	cmp    $0x1,%cl
    cde7:	75 29                	jne    ce12 <f0+0x1772>
    cde9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdec:	0f b7 c0             	movzwl %ax,%eax
    cdef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdf2:	48 0f af c1          	imul   %rcx,%rax
    cdf6:	48 c1 e8 20          	shr    $0x20,%rax
    cdfa:	48 39 d0             	cmp    %rdx,%rax
    cdfd:	73 13                	jae    ce12 <f0+0x1772>
    cdff:	49 01 c4             	add    %rax,%r12
    ce02:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce07:	0f 84 2d 14 00 00    	je     e23a <f0+0x2b9a>
    ce0d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce12:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce19:	33 f3 bf 
    ce1c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    ce23:	00 
    ce24:	bf 01 00 00 00       	mov    $0x1,%edi
    ce29:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    ce30:	00 
    ce31:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    ce38:	00 
    ce39:	e8 f2 98 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    ce3e:	48 8b 15 73 7d 01 00 	mov    0x17d73(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ce45:	49 89 c5             	mov    %rax,%r13
    ce48:	48 2b 05 41 7d 01 00 	sub    0x17d41(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ce4f:	48 c1 e2 10          	shl    $0x10,%rdx
    ce53:	48 39 d0             	cmp    %rdx,%rax
    ce56:	73 59                	jae    ceb1 <f0+0x1811>
    ce58:	48 89 c2             	mov    %rax,%rdx
    ce5b:	48 c1 ea 10          	shr    $0x10,%rdx
    ce5f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce63:	48 8b 15 6e 7d 01 00 	mov    0x17d6e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ce6a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce6e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce72:	4d 85 e4             	test   %r12,%r12
    ce75:	74 3a                	je     ceb1 <f0+0x1811>
    ce77:	0f b6 0a             	movzbl (%rdx),%ecx
    ce7a:	80 f9 02             	cmp    $0x2,%cl
    ce7d:	0f 84 bd 11 00 00    	je     e040 <f0+0x29a0>
    ce83:	80 f9 01             	cmp    $0x1,%cl
    ce86:	75 29                	jne    ceb1 <f0+0x1811>
    ce88:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce8b:	0f b7 c0             	movzwl %ax,%eax
    ce8e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce91:	48 0f af c1          	imul   %rcx,%rax
    ce95:	48 c1 e8 20          	shr    $0x20,%rax
    ce99:	48 39 d0             	cmp    %rdx,%rax
    ce9c:	73 13                	jae    ceb1 <f0+0x1811>
    ce9e:	49 01 c4             	add    %rax,%r12
    cea1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cea6:	0f 84 9b 13 00 00    	je     e247 <f0+0x2ba7>
    ceac:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ceb1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ceb8:	00 f0 3f 
    cebb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    cec2:	00 
    cec3:	bf 01 00 00 00       	mov    $0x1,%edi
    cec8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    cecf:	00 
    ced0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    ced7:	00 
    ced8:	e8 53 98 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    cedd:	48 8b 15 d4 7c 01 00 	mov    0x17cd4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cee4:	49 89 c5             	mov    %rax,%r13
    cee7:	48 2b 05 a2 7c 01 00 	sub    0x17ca2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ceee:	48 c1 e2 10          	shl    $0x10,%rdx
    cef2:	48 39 d0             	cmp    %rdx,%rax
    cef5:	73 59                	jae    cf50 <f0+0x18b0>
    cef7:	48 89 c2             	mov    %rax,%rdx
    cefa:	48 c1 ea 10          	shr    $0x10,%rdx
    cefe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf02:	48 8b 15 cf 7c 01 00 	mov    0x17ccf(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cf09:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf0d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf11:	4d 85 e4             	test   %r12,%r12
    cf14:	74 3a                	je     cf50 <f0+0x18b0>
    cf16:	0f b6 0a             	movzbl (%rdx),%ecx
    cf19:	80 f9 02             	cmp    $0x2,%cl
    cf1c:	0f 84 0e 11 00 00    	je     e030 <f0+0x2990>
    cf22:	80 f9 01             	cmp    $0x1,%cl
    cf25:	75 29                	jne    cf50 <f0+0x18b0>
    cf27:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf2a:	0f b7 c0             	movzwl %ax,%eax
    cf2d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf30:	48 0f af c1          	imul   %rcx,%rax
    cf34:	48 c1 e8 20          	shr    $0x20,%rax
    cf38:	48 39 d0             	cmp    %rdx,%rax
    cf3b:	73 13                	jae    cf50 <f0+0x18b0>
    cf3d:	49 01 c4             	add    %rax,%r12
    cf40:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf45:	0f 84 09 13 00 00    	je     e254 <f0+0x2bb4>
    cf4b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf50:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf57:	33 f3 bf 
    cf5a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    cf61:	00 
    cf62:	bf 01 00 00 00       	mov    $0x1,%edi
    cf67:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    cf6e:	00 
    cf6f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    cf76:	00 
    cf77:	e8 b4 97 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    cf7c:	48 8b 15 35 7c 01 00 	mov    0x17c35(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cf83:	49 89 c5             	mov    %rax,%r13
    cf86:	48 2b 05 03 7c 01 00 	sub    0x17c03(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cf8d:	48 c1 e2 10          	shl    $0x10,%rdx
    cf91:	48 39 d0             	cmp    %rdx,%rax
    cf94:	73 59                	jae    cfef <f0+0x194f>
    cf96:	48 89 c2             	mov    %rax,%rdx
    cf99:	48 c1 ea 10          	shr    $0x10,%rdx
    cf9d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfa1:	48 8b 15 30 7c 01 00 	mov    0x17c30(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cfa8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfb0:	4d 85 e4             	test   %r12,%r12
    cfb3:	74 3a                	je     cfef <f0+0x194f>
    cfb5:	0f b6 0a             	movzbl (%rdx),%ecx
    cfb8:	80 f9 02             	cmp    $0x2,%cl
    cfbb:	0f 84 5f 10 00 00    	je     e020 <f0+0x2980>
    cfc1:	80 f9 01             	cmp    $0x1,%cl
    cfc4:	75 29                	jne    cfef <f0+0x194f>
    cfc6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfc9:	0f b7 c0             	movzwl %ax,%eax
    cfcc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfcf:	48 0f af c1          	imul   %rcx,%rax
    cfd3:	48 c1 e8 20          	shr    $0x20,%rax
    cfd7:	48 39 d0             	cmp    %rdx,%rax
    cfda:	73 13                	jae    cfef <f0+0x194f>
    cfdc:	49 01 c4             	add    %rax,%r12
    cfdf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfe4:	0f 84 77 12 00 00    	je     e261 <f0+0x2bc1>
    cfea:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfef:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cff6:	00 f0 3f 
    cff9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    d000:	00 
    d001:	bf 01 00 00 00       	mov    $0x1,%edi
    d006:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    d00d:	00 
    d00e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    d015:	00 
    d016:	e8 15 97 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d01b:	48 8b 15 96 7b 01 00 	mov    0x17b96(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d022:	49 89 c5             	mov    %rax,%r13
    d025:	48 2b 05 64 7b 01 00 	sub    0x17b64(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d02c:	48 c1 e2 10          	shl    $0x10,%rdx
    d030:	48 39 d0             	cmp    %rdx,%rax
    d033:	73 59                	jae    d08e <f0+0x19ee>
    d035:	48 89 c2             	mov    %rax,%rdx
    d038:	48 c1 ea 10          	shr    $0x10,%rdx
    d03c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d040:	48 8b 15 91 7b 01 00 	mov    0x17b91(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d047:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d04b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d04f:	4d 85 e4             	test   %r12,%r12
    d052:	74 3a                	je     d08e <f0+0x19ee>
    d054:	0f b6 0a             	movzbl (%rdx),%ecx
    d057:	80 f9 02             	cmp    $0x2,%cl
    d05a:	0f 84 40 0f 00 00    	je     dfa0 <f0+0x2900>
    d060:	80 f9 01             	cmp    $0x1,%cl
    d063:	75 29                	jne    d08e <f0+0x19ee>
    d065:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d068:	0f b7 c0             	movzwl %ax,%eax
    d06b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d06e:	48 0f af c1          	imul   %rcx,%rax
    d072:	48 c1 e8 20          	shr    $0x20,%rax
    d076:	48 39 d0             	cmp    %rdx,%rax
    d079:	73 13                	jae    d08e <f0+0x19ee>
    d07b:	49 01 c4             	add    %rax,%r12
    d07e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d083:	0f 84 e5 11 00 00    	je     e26e <f0+0x2bce>
    d089:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d08e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d095:	33 f3 bf 
    d098:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    d09f:	00 
    d0a0:	bf 01 00 00 00       	mov    $0x1,%edi
    d0a5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    d0ac:	00 
    d0ad:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    d0b4:	00 
    d0b5:	e8 76 96 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d0ba:	48 8b 15 f7 7a 01 00 	mov    0x17af7(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d0c1:	49 89 c5             	mov    %rax,%r13
    d0c4:	48 2b 05 c5 7a 01 00 	sub    0x17ac5(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d0cb:	48 c1 e2 10          	shl    $0x10,%rdx
    d0cf:	48 39 d0             	cmp    %rdx,%rax
    d0d2:	73 59                	jae    d12d <f0+0x1a8d>
    d0d4:	48 89 c2             	mov    %rax,%rdx
    d0d7:	48 c1 ea 10          	shr    $0x10,%rdx
    d0db:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0df:	48 8b 15 f2 7a 01 00 	mov    0x17af2(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d0e6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0ea:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0ee:	4d 85 e4             	test   %r12,%r12
    d0f1:	74 3a                	je     d12d <f0+0x1a8d>
    d0f3:	0f b6 0a             	movzbl (%rdx),%ecx
    d0f6:	80 f9 02             	cmp    $0x2,%cl
    d0f9:	0f 84 91 0e 00 00    	je     df90 <f0+0x28f0>
    d0ff:	80 f9 01             	cmp    $0x1,%cl
    d102:	75 29                	jne    d12d <f0+0x1a8d>
    d104:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d107:	0f b7 c0             	movzwl %ax,%eax
    d10a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d10d:	48 0f af c1          	imul   %rcx,%rax
    d111:	48 c1 e8 20          	shr    $0x20,%rax
    d115:	48 39 d0             	cmp    %rdx,%rax
    d118:	73 13                	jae    d12d <f0+0x1a8d>
    d11a:	49 01 c4             	add    %rax,%r12
    d11d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d122:	0f 84 53 11 00 00    	je     e27b <f0+0x2bdb>
    d128:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d12d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d134:	00 f0 3f 
    d137:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    d13e:	00 
    d13f:	bf 01 00 00 00       	mov    $0x1,%edi
    d144:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    d14b:	00 
    d14c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    d153:	00 
    d154:	e8 d7 95 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d159:	48 8b 15 58 7a 01 00 	mov    0x17a58(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d160:	49 89 c5             	mov    %rax,%r13
    d163:	48 2b 05 26 7a 01 00 	sub    0x17a26(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d16a:	48 c1 e2 10          	shl    $0x10,%rdx
    d16e:	48 39 d0             	cmp    %rdx,%rax
    d171:	73 59                	jae    d1cc <f0+0x1b2c>
    d173:	48 89 c2             	mov    %rax,%rdx
    d176:	48 c1 ea 10          	shr    $0x10,%rdx
    d17a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d17e:	48 8b 15 53 7a 01 00 	mov    0x17a53(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d185:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d189:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d18d:	4d 85 e4             	test   %r12,%r12
    d190:	74 3a                	je     d1cc <f0+0x1b2c>
    d192:	0f b6 0a             	movzbl (%rdx),%ecx
    d195:	80 f9 02             	cmp    $0x2,%cl
    d198:	0f 84 e2 0d 00 00    	je     df80 <f0+0x28e0>
    d19e:	80 f9 01             	cmp    $0x1,%cl
    d1a1:	75 29                	jne    d1cc <f0+0x1b2c>
    d1a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1a6:	0f b7 c0             	movzwl %ax,%eax
    d1a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1ac:	48 0f af c1          	imul   %rcx,%rax
    d1b0:	48 c1 e8 20          	shr    $0x20,%rax
    d1b4:	48 39 d0             	cmp    %rdx,%rax
    d1b7:	73 13                	jae    d1cc <f0+0x1b2c>
    d1b9:	49 01 c4             	add    %rax,%r12
    d1bc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1c1:	0f 84 c1 10 00 00    	je     e288 <f0+0x2be8>
    d1c7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1cc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1d3:	33 f3 bf 
    d1d6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d1dd:	00 
    d1de:	bf 01 00 00 00       	mov    $0x1,%edi
    d1e3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d1ea:	00 
    d1eb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d1f2:	00 
    d1f3:	e8 38 95 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d1f8:	48 8b 15 b9 79 01 00 	mov    0x179b9(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d1ff:	49 89 c5             	mov    %rax,%r13
    d202:	48 2b 05 87 79 01 00 	sub    0x17987(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d209:	48 c1 e2 10          	shl    $0x10,%rdx
    d20d:	48 39 d0             	cmp    %rdx,%rax
    d210:	73 59                	jae    d26b <f0+0x1bcb>
    d212:	48 89 c2             	mov    %rax,%rdx
    d215:	48 c1 ea 10          	shr    $0x10,%rdx
    d219:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d21d:	48 8b 15 b4 79 01 00 	mov    0x179b4(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d224:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d228:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d22c:	4d 85 e4             	test   %r12,%r12
    d22f:	74 3a                	je     d26b <f0+0x1bcb>
    d231:	0f b6 0a             	movzbl (%rdx),%ecx
    d234:	80 f9 02             	cmp    $0x2,%cl
    d237:	0f 84 33 0d 00 00    	je     df70 <f0+0x28d0>
    d23d:	80 f9 01             	cmp    $0x1,%cl
    d240:	75 29                	jne    d26b <f0+0x1bcb>
    d242:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d245:	0f b7 c0             	movzwl %ax,%eax
    d248:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d24b:	48 0f af c1          	imul   %rcx,%rax
    d24f:	48 c1 e8 20          	shr    $0x20,%rax
    d253:	48 39 d0             	cmp    %rdx,%rax
    d256:	73 13                	jae    d26b <f0+0x1bcb>
    d258:	49 01 c4             	add    %rax,%r12
    d25b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d260:	0f 84 2f 10 00 00    	je     e295 <f0+0x2bf5>
    d266:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d26b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d272:	00 f0 3f 
    d275:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d27c:	00 
    d27d:	bf 01 00 00 00       	mov    $0x1,%edi
    d282:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d289:	00 
    d28a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d291:	00 
    d292:	e8 99 94 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d297:	48 8b 15 1a 79 01 00 	mov    0x1791a(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d29e:	49 89 c5             	mov    %rax,%r13
    d2a1:	48 2b 05 e8 78 01 00 	sub    0x178e8(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d2a8:	48 c1 e2 10          	shl    $0x10,%rdx
    d2ac:	48 39 d0             	cmp    %rdx,%rax
    d2af:	73 59                	jae    d30a <f0+0x1c6a>
    d2b1:	48 89 c2             	mov    %rax,%rdx
    d2b4:	48 c1 ea 10          	shr    $0x10,%rdx
    d2b8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2bc:	48 8b 15 15 79 01 00 	mov    0x17915(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d2c3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2c7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2cb:	4d 85 e4             	test   %r12,%r12
    d2ce:	74 3a                	je     d30a <f0+0x1c6a>
    d2d0:	0f b6 0a             	movzbl (%rdx),%ecx
    d2d3:	80 f9 02             	cmp    $0x2,%cl
    d2d6:	0f 84 84 0c 00 00    	je     df60 <f0+0x28c0>
    d2dc:	80 f9 01             	cmp    $0x1,%cl
    d2df:	75 29                	jne    d30a <f0+0x1c6a>
    d2e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2e4:	0f b7 c0             	movzwl %ax,%eax
    d2e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2ea:	48 0f af c1          	imul   %rcx,%rax
    d2ee:	48 c1 e8 20          	shr    $0x20,%rax
    d2f2:	48 39 d0             	cmp    %rdx,%rax
    d2f5:	73 13                	jae    d30a <f0+0x1c6a>
    d2f7:	49 01 c4             	add    %rax,%r12
    d2fa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2ff:	0f 84 9d 0f 00 00    	je     e2a2 <f0+0x2c02>
    d305:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d30a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d311:	33 f3 bf 
    d314:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d31b:	00 
    d31c:	bf 01 00 00 00       	mov    $0x1,%edi
    d321:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d328:	00 
    d329:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d330:	00 
    d331:	e8 fa 93 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d336:	48 8b 15 7b 78 01 00 	mov    0x1787b(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d33d:	49 89 c5             	mov    %rax,%r13
    d340:	48 2b 05 49 78 01 00 	sub    0x17849(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d347:	48 c1 e2 10          	shl    $0x10,%rdx
    d34b:	48 39 d0             	cmp    %rdx,%rax
    d34e:	73 59                	jae    d3a9 <f0+0x1d09>
    d350:	48 89 c2             	mov    %rax,%rdx
    d353:	48 c1 ea 10          	shr    $0x10,%rdx
    d357:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d35b:	48 8b 15 76 78 01 00 	mov    0x17876(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d362:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d366:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d36a:	4d 85 e4             	test   %r12,%r12
    d36d:	74 3a                	je     d3a9 <f0+0x1d09>
    d36f:	0f b6 0a             	movzbl (%rdx),%ecx
    d372:	80 f9 02             	cmp    $0x2,%cl
    d375:	0f 84 d5 0b 00 00    	je     df50 <f0+0x28b0>
    d37b:	80 f9 01             	cmp    $0x1,%cl
    d37e:	75 29                	jne    d3a9 <f0+0x1d09>
    d380:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d383:	0f b7 c0             	movzwl %ax,%eax
    d386:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d389:	48 0f af c1          	imul   %rcx,%rax
    d38d:	48 c1 e8 20          	shr    $0x20,%rax
    d391:	48 39 d0             	cmp    %rdx,%rax
    d394:	73 13                	jae    d3a9 <f0+0x1d09>
    d396:	49 01 c4             	add    %rax,%r12
    d399:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d39e:	0f 84 0b 0f 00 00    	je     e2af <f0+0x2c0f>
    d3a4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3a9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3b0:	00 f0 3f 
    d3b3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d3ba:	00 
    d3bb:	bf 01 00 00 00       	mov    $0x1,%edi
    d3c0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d3c7:	00 
    d3c8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d3cf:	00 
    d3d0:	e8 5b 93 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d3d5:	48 8b 15 dc 77 01 00 	mov    0x177dc(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d3dc:	49 89 c5             	mov    %rax,%r13
    d3df:	48 2b 05 aa 77 01 00 	sub    0x177aa(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d3e6:	48 c1 e2 10          	shl    $0x10,%rdx
    d3ea:	48 39 d0             	cmp    %rdx,%rax
    d3ed:	73 59                	jae    d448 <f0+0x1da8>
    d3ef:	48 89 c2             	mov    %rax,%rdx
    d3f2:	48 c1 ea 10          	shr    $0x10,%rdx
    d3f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3fa:	48 8b 15 d7 77 01 00 	mov    0x177d7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d401:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d405:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d409:	4d 85 e4             	test   %r12,%r12
    d40c:	74 3a                	je     d448 <f0+0x1da8>
    d40e:	0f b6 0a             	movzbl (%rdx),%ecx
    d411:	80 f9 02             	cmp    $0x2,%cl
    d414:	0f 84 26 0b 00 00    	je     df40 <f0+0x28a0>
    d41a:	80 f9 01             	cmp    $0x1,%cl
    d41d:	75 29                	jne    d448 <f0+0x1da8>
    d41f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d422:	0f b7 c0             	movzwl %ax,%eax
    d425:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d428:	48 0f af c1          	imul   %rcx,%rax
    d42c:	48 c1 e8 20          	shr    $0x20,%rax
    d430:	48 39 d0             	cmp    %rdx,%rax
    d433:	73 13                	jae    d448 <f0+0x1da8>
    d435:	49 01 c4             	add    %rax,%r12
    d438:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d43d:	0f 84 79 0e 00 00    	je     e2bc <f0+0x2c1c>
    d443:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d448:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d44f:	33 f3 bf 
    d452:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d459:	00 
    d45a:	bf 01 00 00 00       	mov    $0x1,%edi
    d45f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d466:	00 
    d467:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d46e:	00 
    d46f:	e8 bc 92 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d474:	48 8b 15 3d 77 01 00 	mov    0x1773d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d47b:	49 89 c5             	mov    %rax,%r13
    d47e:	48 2b 05 0b 77 01 00 	sub    0x1770b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d485:	48 c1 e2 10          	shl    $0x10,%rdx
    d489:	48 39 d0             	cmp    %rdx,%rax
    d48c:	73 59                	jae    d4e7 <f0+0x1e47>
    d48e:	48 89 c2             	mov    %rax,%rdx
    d491:	48 c1 ea 10          	shr    $0x10,%rdx
    d495:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d499:	48 8b 15 38 77 01 00 	mov    0x17738(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d4a0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4a4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4a8:	4d 85 e4             	test   %r12,%r12
    d4ab:	74 3a                	je     d4e7 <f0+0x1e47>
    d4ad:	0f b6 0a             	movzbl (%rdx),%ecx
    d4b0:	80 f9 02             	cmp    $0x2,%cl
    d4b3:	0f 84 77 0a 00 00    	je     df30 <f0+0x2890>
    d4b9:	80 f9 01             	cmp    $0x1,%cl
    d4bc:	75 29                	jne    d4e7 <f0+0x1e47>
    d4be:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4c1:	0f b7 c0             	movzwl %ax,%eax
    d4c4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4c7:	48 0f af c1          	imul   %rcx,%rax
    d4cb:	48 c1 e8 20          	shr    $0x20,%rax
    d4cf:	48 39 d0             	cmp    %rdx,%rax
    d4d2:	73 13                	jae    d4e7 <f0+0x1e47>
    d4d4:	49 01 c4             	add    %rax,%r12
    d4d7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4dc:	0f 84 e7 0d 00 00    	je     e2c9 <f0+0x2c29>
    d4e2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4e7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4ee:	00 f0 3f 
    d4f1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d4f8:	00 
    d4f9:	bf 01 00 00 00       	mov    $0x1,%edi
    d4fe:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d505:	00 
    d506:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d50d:	00 
    d50e:	e8 1d 92 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d513:	48 8b 15 9e 76 01 00 	mov    0x1769e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d51a:	49 89 c5             	mov    %rax,%r13
    d51d:	48 2b 05 6c 76 01 00 	sub    0x1766c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d524:	48 c1 e2 10          	shl    $0x10,%rdx
    d528:	48 39 d0             	cmp    %rdx,%rax
    d52b:	73 59                	jae    d586 <f0+0x1ee6>
    d52d:	48 89 c2             	mov    %rax,%rdx
    d530:	48 c1 ea 10          	shr    $0x10,%rdx
    d534:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d538:	48 8b 15 99 76 01 00 	mov    0x17699(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d53f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d543:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d547:	4d 85 e4             	test   %r12,%r12
    d54a:	74 3a                	je     d586 <f0+0x1ee6>
    d54c:	0f b6 0a             	movzbl (%rdx),%ecx
    d54f:	80 f9 02             	cmp    $0x2,%cl
    d552:	0f 84 38 0c 00 00    	je     e190 <f0+0x2af0>
    d558:	80 f9 01             	cmp    $0x1,%cl
    d55b:	75 29                	jne    d586 <f0+0x1ee6>
    d55d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d560:	0f b7 c0             	movzwl %ax,%eax
    d563:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d566:	48 0f af c1          	imul   %rcx,%rax
    d56a:	48 c1 e8 20          	shr    $0x20,%rax
    d56e:	48 39 d0             	cmp    %rdx,%rax
    d571:	73 13                	jae    d586 <f0+0x1ee6>
    d573:	49 01 c4             	add    %rax,%r12
    d576:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d57b:	0f 84 55 0d 00 00    	je     e2d6 <f0+0x2c36>
    d581:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d586:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d58d:	33 f3 bf 
    d590:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d597:	00 
    d598:	bf 01 00 00 00       	mov    $0x1,%edi
    d59d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d5a4:	00 
    d5a5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d5ac:	00 
    d5ad:	e8 7e 91 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d5b2:	48 8b 15 ff 75 01 00 	mov    0x175ff(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d5b9:	49 89 c5             	mov    %rax,%r13
    d5bc:	48 2b 05 cd 75 01 00 	sub    0x175cd(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d5c3:	48 c1 e2 10          	shl    $0x10,%rdx
    d5c7:	48 39 d0             	cmp    %rdx,%rax
    d5ca:	73 59                	jae    d625 <f0+0x1f85>
    d5cc:	48 89 c2             	mov    %rax,%rdx
    d5cf:	48 c1 ea 10          	shr    $0x10,%rdx
    d5d3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5d7:	48 8b 15 fa 75 01 00 	mov    0x175fa(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d5de:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5e2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5e6:	4d 85 e4             	test   %r12,%r12
    d5e9:	74 3a                	je     d625 <f0+0x1f85>
    d5eb:	0f b6 0a             	movzbl (%rdx),%ecx
    d5ee:	80 f9 02             	cmp    $0x2,%cl
    d5f1:	0f 84 89 0b 00 00    	je     e180 <f0+0x2ae0>
    d5f7:	80 f9 01             	cmp    $0x1,%cl
    d5fa:	75 29                	jne    d625 <f0+0x1f85>
    d5fc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5ff:	0f b7 c0             	movzwl %ax,%eax
    d602:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d605:	48 0f af c1          	imul   %rcx,%rax
    d609:	48 c1 e8 20          	shr    $0x20,%rax
    d60d:	48 39 d0             	cmp    %rdx,%rax
    d610:	73 13                	jae    d625 <f0+0x1f85>
    d612:	49 01 c4             	add    %rax,%r12
    d615:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d61a:	0f 84 c3 0c 00 00    	je     e2e3 <f0+0x2c43>
    d620:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d625:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d62c:	00 f0 3f 
    d62f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d636:	00 
    d637:	bf 01 00 00 00       	mov    $0x1,%edi
    d63c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d643:	00 
    d644:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d64b:	00 
    d64c:	e8 df 90 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d651:	48 8b 15 60 75 01 00 	mov    0x17560(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d658:	49 89 c5             	mov    %rax,%r13
    d65b:	48 2b 05 2e 75 01 00 	sub    0x1752e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d662:	48 c1 e2 10          	shl    $0x10,%rdx
    d666:	48 39 d0             	cmp    %rdx,%rax
    d669:	73 59                	jae    d6c4 <f0+0x2024>
    d66b:	48 89 c2             	mov    %rax,%rdx
    d66e:	48 c1 ea 10          	shr    $0x10,%rdx
    d672:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d676:	48 8b 15 5b 75 01 00 	mov    0x1755b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d67d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d681:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d685:	4d 85 e4             	test   %r12,%r12
    d688:	74 3a                	je     d6c4 <f0+0x2024>
    d68a:	0f b6 0a             	movzbl (%rdx),%ecx
    d68d:	80 f9 02             	cmp    $0x2,%cl
    d690:	0f 84 da 0a 00 00    	je     e170 <f0+0x2ad0>
    d696:	80 f9 01             	cmp    $0x1,%cl
    d699:	75 29                	jne    d6c4 <f0+0x2024>
    d69b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d69e:	0f b7 c0             	movzwl %ax,%eax
    d6a1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6a4:	48 0f af c1          	imul   %rcx,%rax
    d6a8:	48 c1 e8 20          	shr    $0x20,%rax
    d6ac:	48 39 d0             	cmp    %rdx,%rax
    d6af:	73 13                	jae    d6c4 <f0+0x2024>
    d6b1:	49 01 c4             	add    %rax,%r12
    d6b4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6b9:	0f 84 31 0c 00 00    	je     e2f0 <f0+0x2c50>
    d6bf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6c4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d6cb:	33 f3 bf 
    d6ce:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d6d5:	00 
    d6d6:	bf 01 00 00 00       	mov    $0x1,%edi
    d6db:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d6e2:	00 
    d6e3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d6ea:	00 
    d6eb:	e8 40 90 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d6f0:	48 8b 15 c1 74 01 00 	mov    0x174c1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d6f7:	49 89 c5             	mov    %rax,%r13
    d6fa:	48 2b 05 8f 74 01 00 	sub    0x1748f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d701:	48 c1 e2 10          	shl    $0x10,%rdx
    d705:	48 39 d0             	cmp    %rdx,%rax
    d708:	73 59                	jae    d763 <f0+0x20c3>
    d70a:	48 89 c2             	mov    %rax,%rdx
    d70d:	48 c1 ea 10          	shr    $0x10,%rdx
    d711:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d715:	48 8b 15 bc 74 01 00 	mov    0x174bc(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d71c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d720:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d724:	4d 85 e4             	test   %r12,%r12
    d727:	74 3a                	je     d763 <f0+0x20c3>
    d729:	0f b6 0a             	movzbl (%rdx),%ecx
    d72c:	80 f9 02             	cmp    $0x2,%cl
    d72f:	0f 84 2b 0a 00 00    	je     e160 <f0+0x2ac0>
    d735:	80 f9 01             	cmp    $0x1,%cl
    d738:	75 29                	jne    d763 <f0+0x20c3>
    d73a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d73d:	0f b7 c0             	movzwl %ax,%eax
    d740:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d743:	48 0f af c1          	imul   %rcx,%rax
    d747:	48 c1 e8 20          	shr    $0x20,%rax
    d74b:	48 39 d0             	cmp    %rdx,%rax
    d74e:	73 13                	jae    d763 <f0+0x20c3>
    d750:	49 01 c4             	add    %rax,%r12
    d753:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d758:	0f 84 9f 0b 00 00    	je     e2fd <f0+0x2c5d>
    d75e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d763:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d76a:	00 f0 3f 
    d76d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d774:	00 
    d775:	bf 01 00 00 00       	mov    $0x1,%edi
    d77a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d781:	00 
    d782:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d789:	00 
    d78a:	e8 a1 8f ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d78f:	48 8b 15 22 74 01 00 	mov    0x17422(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d796:	49 89 c5             	mov    %rax,%r13
    d799:	48 2b 05 f0 73 01 00 	sub    0x173f0(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d7a0:	48 c1 e2 10          	shl    $0x10,%rdx
    d7a4:	48 39 d0             	cmp    %rdx,%rax
    d7a7:	73 59                	jae    d802 <f0+0x2162>
    d7a9:	48 89 c2             	mov    %rax,%rdx
    d7ac:	48 c1 ea 10          	shr    $0x10,%rdx
    d7b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7b4:	48 8b 15 1d 74 01 00 	mov    0x1741d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d7bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7bf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7c3:	4d 85 e4             	test   %r12,%r12
    d7c6:	74 3a                	je     d802 <f0+0x2162>
    d7c8:	0f b6 0a             	movzbl (%rdx),%ecx
    d7cb:	80 f9 02             	cmp    $0x2,%cl
    d7ce:	0f 84 7c 09 00 00    	je     e150 <f0+0x2ab0>
    d7d4:	80 f9 01             	cmp    $0x1,%cl
    d7d7:	75 29                	jne    d802 <f0+0x2162>
    d7d9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7dc:	0f b7 c0             	movzwl %ax,%eax
    d7df:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7e2:	48 0f af c1          	imul   %rcx,%rax
    d7e6:	48 c1 e8 20          	shr    $0x20,%rax
    d7ea:	48 39 d0             	cmp    %rdx,%rax
    d7ed:	73 13                	jae    d802 <f0+0x2162>
    d7ef:	49 01 c4             	add    %rax,%r12
    d7f2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7f7:	0f 84 0d 0b 00 00    	je     e30a <f0+0x2c6a>
    d7fd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d802:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d809:	33 f3 bf 
    d80c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d813:	00 
    d814:	bf 01 00 00 00       	mov    $0x1,%edi
    d819:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d820:	00 
    d821:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d828:	00 
    d829:	e8 02 8f ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d82e:	48 8b 15 83 73 01 00 	mov    0x17383(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d835:	49 89 c5             	mov    %rax,%r13
    d838:	48 2b 05 51 73 01 00 	sub    0x17351(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d83f:	48 c1 e2 10          	shl    $0x10,%rdx
    d843:	48 39 d0             	cmp    %rdx,%rax
    d846:	73 59                	jae    d8a1 <f0+0x2201>
    d848:	48 89 c2             	mov    %rax,%rdx
    d84b:	48 c1 ea 10          	shr    $0x10,%rdx
    d84f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d853:	48 8b 15 7e 73 01 00 	mov    0x1737e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d85a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d85e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d862:	4d 85 e4             	test   %r12,%r12
    d865:	74 3a                	je     d8a1 <f0+0x2201>
    d867:	0f b6 0a             	movzbl (%rdx),%ecx
    d86a:	80 f9 02             	cmp    $0x2,%cl
    d86d:	0f 84 cd 08 00 00    	je     e140 <f0+0x2aa0>
    d873:	80 f9 01             	cmp    $0x1,%cl
    d876:	75 29                	jne    d8a1 <f0+0x2201>
    d878:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d87b:	0f b7 c0             	movzwl %ax,%eax
    d87e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d881:	48 0f af c1          	imul   %rcx,%rax
    d885:	48 c1 e8 20          	shr    $0x20,%rax
    d889:	48 39 d0             	cmp    %rdx,%rax
    d88c:	73 13                	jae    d8a1 <f0+0x2201>
    d88e:	49 01 c4             	add    %rax,%r12
    d891:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d896:	0f 84 7b 0a 00 00    	je     e317 <f0+0x2c77>
    d89c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8a1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d8a8:	00 f0 3f 
    d8ab:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d8b2:	00 
    d8b3:	bf 01 00 00 00       	mov    $0x1,%edi
    d8b8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d8bf:	00 
    d8c0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d8c7:	00 
    d8c8:	e8 63 8e ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d8cd:	48 8b 15 e4 72 01 00 	mov    0x172e4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d8d4:	49 89 c5             	mov    %rax,%r13
    d8d7:	48 2b 05 b2 72 01 00 	sub    0x172b2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d8de:	48 c1 e2 10          	shl    $0x10,%rdx
    d8e2:	48 39 d0             	cmp    %rdx,%rax
    d8e5:	73 59                	jae    d940 <f0+0x22a0>
    d8e7:	48 89 c2             	mov    %rax,%rdx
    d8ea:	48 c1 ea 10          	shr    $0x10,%rdx
    d8ee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8f2:	48 8b 15 df 72 01 00 	mov    0x172df(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d8f9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8fd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d901:	4d 85 e4             	test   %r12,%r12
    d904:	74 3a                	je     d940 <f0+0x22a0>
    d906:	0f b6 0a             	movzbl (%rdx),%ecx
    d909:	80 f9 02             	cmp    $0x2,%cl
    d90c:	0f 84 1e 08 00 00    	je     e130 <f0+0x2a90>
    d912:	80 f9 01             	cmp    $0x1,%cl
    d915:	75 29                	jne    d940 <f0+0x22a0>
    d917:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d91a:	0f b7 c0             	movzwl %ax,%eax
    d91d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d920:	48 0f af c1          	imul   %rcx,%rax
    d924:	48 c1 e8 20          	shr    $0x20,%rax
    d928:	48 39 d0             	cmp    %rdx,%rax
    d92b:	73 13                	jae    d940 <f0+0x22a0>
    d92d:	49 01 c4             	add    %rax,%r12
    d930:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d935:	0f 84 e9 09 00 00    	je     e324 <f0+0x2c84>
    d93b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d940:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d947:	33 f3 bf 
    d94a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d951:	00 
    d952:	bf 01 00 00 00       	mov    $0x1,%edi
    d957:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d95e:	00 
    d95f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d966:	00 
    d967:	e8 c4 8d ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    d96c:	48 8b 15 45 72 01 00 	mov    0x17245(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d973:	49 89 c5             	mov    %rax,%r13
    d976:	48 2b 05 13 72 01 00 	sub    0x17213(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d97d:	48 c1 e2 10          	shl    $0x10,%rdx
    d981:	48 39 d0             	cmp    %rdx,%rax
    d984:	73 59                	jae    d9df <f0+0x233f>
    d986:	48 89 c2             	mov    %rax,%rdx
    d989:	48 c1 ea 10          	shr    $0x10,%rdx
    d98d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d991:	48 8b 15 40 72 01 00 	mov    0x17240(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d998:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d99c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9a0:	4d 85 e4             	test   %r12,%r12
    d9a3:	74 3a                	je     d9df <f0+0x233f>
    d9a5:	0f b6 0a             	movzbl (%rdx),%ecx
    d9a8:	80 f9 02             	cmp    $0x2,%cl
    d9ab:	0f 84 6f 07 00 00    	je     e120 <f0+0x2a80>
    d9b1:	80 f9 01             	cmp    $0x1,%cl
    d9b4:	75 29                	jne    d9df <f0+0x233f>
    d9b6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d9b9:	0f b7 c0             	movzwl %ax,%eax
    d9bc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d9bf:	48 0f af c1          	imul   %rcx,%rax
    d9c3:	48 c1 e8 20          	shr    $0x20,%rax
    d9c7:	48 39 d0             	cmp    %rdx,%rax
    d9ca:	73 13                	jae    d9df <f0+0x233f>
    d9cc:	49 01 c4             	add    %rax,%r12
    d9cf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9d4:	0f 84 57 09 00 00    	je     e331 <f0+0x2c91>
    d9da:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9df:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d9e6:	00 f0 3f 
    d9e9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d9f0:	00 
    d9f1:	bf 01 00 00 00       	mov    $0x1,%edi
    d9f6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d9fd:	00 
    d9fe:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    da05:	00 
    da06:	e8 25 8d ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    da0b:	48 8b 15 a6 71 01 00 	mov    0x171a6(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    da12:	49 89 c5             	mov    %rax,%r13
    da15:	48 2b 05 74 71 01 00 	sub    0x17174(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    da1c:	48 c1 e2 10          	shl    $0x10,%rdx
    da20:	48 39 d0             	cmp    %rdx,%rax
    da23:	73 59                	jae    da7e <f0+0x23de>
    da25:	48 89 c2             	mov    %rax,%rdx
    da28:	48 c1 ea 10          	shr    $0x10,%rdx
    da2c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da30:	48 8b 15 a1 71 01 00 	mov    0x171a1(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    da37:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da3b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da3f:	4d 85 e4             	test   %r12,%r12
    da42:	74 3a                	je     da7e <f0+0x23de>
    da44:	0f b6 0a             	movzbl (%rdx),%ecx
    da47:	80 f9 02             	cmp    $0x2,%cl
    da4a:	0f 84 c0 06 00 00    	je     e110 <f0+0x2a70>
    da50:	80 f9 01             	cmp    $0x1,%cl
    da53:	75 29                	jne    da7e <f0+0x23de>
    da55:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da58:	0f b7 c0             	movzwl %ax,%eax
    da5b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da5e:	48 0f af c1          	imul   %rcx,%rax
    da62:	48 c1 e8 20          	shr    $0x20,%rax
    da66:	48 39 d0             	cmp    %rdx,%rax
    da69:	73 13                	jae    da7e <f0+0x23de>
    da6b:	49 01 c4             	add    %rax,%r12
    da6e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da73:	0f 84 c5 08 00 00    	je     e33e <f0+0x2c9e>
    da79:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da7e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    da85:	33 f3 bf 
    da88:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    da8f:	00 
    da90:	bf 01 00 00 00       	mov    $0x1,%edi
    da95:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    da9c:	00 
    da9d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    daa4:	00 
    daa5:	e8 86 8c ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    daaa:	48 8b 15 07 71 01 00 	mov    0x17107(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dab1:	49 89 c5             	mov    %rax,%r13
    dab4:	48 2b 05 d5 70 01 00 	sub    0x170d5(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dabb:	48 c1 e2 10          	shl    $0x10,%rdx
    dabf:	48 39 d0             	cmp    %rdx,%rax
    dac2:	73 59                	jae    db1d <f0+0x247d>
    dac4:	48 89 c2             	mov    %rax,%rdx
    dac7:	48 c1 ea 10          	shr    $0x10,%rdx
    dacb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dacf:	48 8b 15 02 71 01 00 	mov    0x17102(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dad6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dada:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dade:	4d 85 e4             	test   %r12,%r12
    dae1:	74 3a                	je     db1d <f0+0x247d>
    dae3:	0f b6 0a             	movzbl (%rdx),%ecx
    dae6:	80 f9 02             	cmp    $0x2,%cl
    dae9:	0f 84 11 06 00 00    	je     e100 <f0+0x2a60>
    daef:	80 f9 01             	cmp    $0x1,%cl
    daf2:	75 29                	jne    db1d <f0+0x247d>
    daf4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    daf7:	0f b7 c0             	movzwl %ax,%eax
    dafa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dafd:	48 0f af c1          	imul   %rcx,%rax
    db01:	48 c1 e8 20          	shr    $0x20,%rax
    db05:	48 39 d0             	cmp    %rdx,%rax
    db08:	73 13                	jae    db1d <f0+0x247d>
    db0a:	49 01 c4             	add    %rax,%r12
    db0d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db12:	0f 84 33 08 00 00    	je     e34b <f0+0x2cab>
    db18:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db1d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    db24:	00 f0 3f 
    db27:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    db2e:	00 
    db2f:	bf 01 00 00 00       	mov    $0x1,%edi
    db34:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    db3b:	00 
    db3c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    db43:	00 
    db44:	e8 e7 8b ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    db49:	48 8b 15 68 70 01 00 	mov    0x17068(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    db50:	49 89 c5             	mov    %rax,%r13
    db53:	48 2b 05 36 70 01 00 	sub    0x17036(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    db5a:	48 c1 e2 10          	shl    $0x10,%rdx
    db5e:	48 39 d0             	cmp    %rdx,%rax
    db61:	73 59                	jae    dbbc <f0+0x251c>
    db63:	48 89 c2             	mov    %rax,%rdx
    db66:	48 c1 ea 10          	shr    $0x10,%rdx
    db6a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db6e:	48 8b 15 63 70 01 00 	mov    0x17063(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    db75:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db79:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db7d:	4d 85 e4             	test   %r12,%r12
    db80:	74 3a                	je     dbbc <f0+0x251c>
    db82:	0f b6 0a             	movzbl (%rdx),%ecx
    db85:	80 f9 02             	cmp    $0x2,%cl
    db88:	0f 84 62 05 00 00    	je     e0f0 <f0+0x2a50>
    db8e:	80 f9 01             	cmp    $0x1,%cl
    db91:	75 29                	jne    dbbc <f0+0x251c>
    db93:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db96:	0f b7 c0             	movzwl %ax,%eax
    db99:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db9c:	48 0f af c1          	imul   %rcx,%rax
    dba0:	48 c1 e8 20          	shr    $0x20,%rax
    dba4:	48 39 d0             	cmp    %rdx,%rax
    dba7:	73 13                	jae    dbbc <f0+0x251c>
    dba9:	49 01 c4             	add    %rax,%r12
    dbac:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dbb1:	0f 84 a1 07 00 00    	je     e358 <f0+0x2cb8>
    dbb7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dbbc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dbc3:	33 f3 bf 
    dbc6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    dbcd:	00 
    dbce:	bf 01 00 00 00       	mov    $0x1,%edi
    dbd3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    dbda:	00 
    dbdb:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    dbe2:	00 
    dbe3:	e8 48 8b ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    dbe8:	48 8b 15 c9 6f 01 00 	mov    0x16fc9(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dbef:	49 89 c5             	mov    %rax,%r13
    dbf2:	48 2b 05 97 6f 01 00 	sub    0x16f97(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dbf9:	48 c1 e2 10          	shl    $0x10,%rdx
    dbfd:	48 39 d0             	cmp    %rdx,%rax
    dc00:	73 59                	jae    dc5b <f0+0x25bb>
    dc02:	48 89 c2             	mov    %rax,%rdx
    dc05:	48 c1 ea 10          	shr    $0x10,%rdx
    dc09:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc0d:	48 8b 15 c4 6f 01 00 	mov    0x16fc4(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dc14:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc18:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc1c:	4d 85 e4             	test   %r12,%r12
    dc1f:	74 3a                	je     dc5b <f0+0x25bb>
    dc21:	0f b6 0a             	movzbl (%rdx),%ecx
    dc24:	80 f9 02             	cmp    $0x2,%cl
    dc27:	0f 84 b3 04 00 00    	je     e0e0 <f0+0x2a40>
    dc2d:	80 f9 01             	cmp    $0x1,%cl
    dc30:	75 29                	jne    dc5b <f0+0x25bb>
    dc32:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc35:	0f b7 c0             	movzwl %ax,%eax
    dc38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc3b:	48 0f af c1          	imul   %rcx,%rax
    dc3f:	48 c1 e8 20          	shr    $0x20,%rax
    dc43:	48 39 d0             	cmp    %rdx,%rax
    dc46:	73 13                	jae    dc5b <f0+0x25bb>
    dc48:	49 01 c4             	add    %rax,%r12
    dc4b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc50:	0f 84 0f 07 00 00    	je     e365 <f0+0x2cc5>
    dc56:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc5b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dc62:	00 f0 3f 
    dc65:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    dc6c:	00 
    dc6d:	bf 01 00 00 00       	mov    $0x1,%edi
    dc72:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    dc79:	00 
    dc7a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    dc81:	00 
    dc82:	e8 a9 8a ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    dc87:	48 8b 15 2a 6f 01 00 	mov    0x16f2a(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dc8e:	49 89 c5             	mov    %rax,%r13
    dc91:	48 2b 05 f8 6e 01 00 	sub    0x16ef8(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dc98:	48 c1 e2 10          	shl    $0x10,%rdx
    dc9c:	48 39 d0             	cmp    %rdx,%rax
    dc9f:	73 59                	jae    dcfa <f0+0x265a>
    dca1:	48 89 c2             	mov    %rax,%rdx
    dca4:	48 c1 ea 10          	shr    $0x10,%rdx
    dca8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dcac:	48 8b 15 25 6f 01 00 	mov    0x16f25(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dcb3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dcb7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dcbb:	4d 85 e4             	test   %r12,%r12
    dcbe:	74 3a                	je     dcfa <f0+0x265a>
    dcc0:	0f b6 0a             	movzbl (%rdx),%ecx
    dcc3:	80 f9 02             	cmp    $0x2,%cl
    dcc6:	0f 84 04 04 00 00    	je     e0d0 <f0+0x2a30>
    dccc:	80 f9 01             	cmp    $0x1,%cl
    dccf:	75 29                	jne    dcfa <f0+0x265a>
    dcd1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dcd4:	0f b7 c0             	movzwl %ax,%eax
    dcd7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dcda:	48 0f af c1          	imul   %rcx,%rax
    dcde:	48 c1 e8 20          	shr    $0x20,%rax
    dce2:	48 39 d0             	cmp    %rdx,%rax
    dce5:	73 13                	jae    dcfa <f0+0x265a>
    dce7:	49 01 c4             	add    %rax,%r12
    dcea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dcef:	0f 84 7d 06 00 00    	je     e372 <f0+0x2cd2>
    dcf5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dcfa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dd01:	33 f3 bf 
    dd04:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    dd0b:	00 
    dd0c:	bf 01 00 00 00       	mov    $0x1,%edi
    dd11:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    dd18:	00 
    dd19:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    dd20:	00 
    dd21:	e8 0a 8a ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    dd26:	48 8b 15 8b 6e 01 00 	mov    0x16e8b(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dd2d:	49 89 c5             	mov    %rax,%r13
    dd30:	48 2b 05 59 6e 01 00 	sub    0x16e59(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dd37:	48 c1 e2 10          	shl    $0x10,%rdx
    dd3b:	48 39 d0             	cmp    %rdx,%rax
    dd3e:	73 59                	jae    dd99 <f0+0x26f9>
    dd40:	48 89 c2             	mov    %rax,%rdx
    dd43:	48 c1 ea 10          	shr    $0x10,%rdx
    dd47:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd4b:	48 8b 15 86 6e 01 00 	mov    0x16e86(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dd52:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd56:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd5a:	4d 85 e4             	test   %r12,%r12
    dd5d:	74 3a                	je     dd99 <f0+0x26f9>
    dd5f:	0f b6 0a             	movzbl (%rdx),%ecx
    dd62:	80 f9 02             	cmp    $0x2,%cl
    dd65:	0f 84 55 03 00 00    	je     e0c0 <f0+0x2a20>
    dd6b:	80 f9 01             	cmp    $0x1,%cl
    dd6e:	75 29                	jne    dd99 <f0+0x26f9>
    dd70:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd73:	0f b7 c0             	movzwl %ax,%eax
    dd76:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd79:	48 0f af c1          	imul   %rcx,%rax
    dd7d:	48 c1 e8 20          	shr    $0x20,%rax
    dd81:	48 39 d0             	cmp    %rdx,%rax
    dd84:	73 13                	jae    dd99 <f0+0x26f9>
    dd86:	49 01 c4             	add    %rax,%r12
    dd89:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd8e:	0f 84 eb 05 00 00    	je     e37f <f0+0x2cdf>
    dd94:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd99:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dda0:	00 f0 3f 
    dda3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    ddaa:	00 
    ddab:	bf 01 00 00 00       	mov    $0x1,%edi
    ddb0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    ddb7:	00 
    ddb8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    ddbf:	00 
    ddc0:	e8 6b 89 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    ddc5:	48 8b 15 ec 6d 01 00 	mov    0x16dec(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ddcc:	49 89 c5             	mov    %rax,%r13
    ddcf:	48 2b 05 ba 6d 01 00 	sub    0x16dba(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ddd6:	48 c1 e2 10          	shl    $0x10,%rdx
    ddda:	48 39 d0             	cmp    %rdx,%rax
    dddd:	73 59                	jae    de38 <f0+0x2798>
    dddf:	48 89 c2             	mov    %rax,%rdx
    dde2:	48 c1 ea 10          	shr    $0x10,%rdx
    dde6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ddea:	48 8b 15 e7 6d 01 00 	mov    0x16de7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ddf1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ddf5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ddf9:	4d 85 e4             	test   %r12,%r12
    ddfc:	74 3a                	je     de38 <f0+0x2798>
    ddfe:	0f b6 0a             	movzbl (%rdx),%ecx
    de01:	80 f9 02             	cmp    $0x2,%cl
    de04:	0f 84 a6 02 00 00    	je     e0b0 <f0+0x2a10>
    de0a:	80 f9 01             	cmp    $0x1,%cl
    de0d:	75 29                	jne    de38 <f0+0x2798>
    de0f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    de12:	0f b7 c0             	movzwl %ax,%eax
    de15:	8b 52 1c             	mov    0x1c(%rdx),%edx
    de18:	48 0f af c1          	imul   %rcx,%rax
    de1c:	48 c1 e8 20          	shr    $0x20,%rax
    de20:	48 39 d0             	cmp    %rdx,%rax
    de23:	73 13                	jae    de38 <f0+0x2798>
    de25:	49 01 c4             	add    %rax,%r12
    de28:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    de2d:	0f 84 59 05 00 00    	je     e38c <f0+0x2cec>
    de33:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de38:	48 89 ee             	mov    %rbp,%rsi
    de3b:	bf 01 00 00 00       	mov    $0x1,%edi
    de40:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    de47:	33 f3 bf 
    de4a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    de51:	00 
    de52:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    de59:	00 
    de5a:	e8 d1 88 ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    de5f:	48 8b 15 52 6d 01 00 	mov    0x16d52(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    de66:	48 89 c5             	mov    %rax,%rbp
    de69:	48 2b 05 20 6d 01 00 	sub    0x16d20(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    de70:	48 c1 e2 10          	shl    $0x10,%rdx
    de74:	48 39 d0             	cmp    %rdx,%rax
    de77:	73 59                	jae    ded2 <f0+0x2832>
    de79:	48 89 c2             	mov    %rax,%rdx
    de7c:	48 c1 ea 10          	shr    $0x10,%rdx
    de80:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    de84:	48 8b 15 4d 6d 01 00 	mov    0x16d4d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    de8b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    de8f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    de93:	4d 85 e4             	test   %r12,%r12
    de96:	74 3a                	je     ded2 <f0+0x2832>
    de98:	0f b6 0a             	movzbl (%rdx),%ecx
    de9b:	80 f9 02             	cmp    $0x2,%cl
    de9e:	0f 84 fc 01 00 00    	je     e0a0 <f0+0x2a00>
    dea4:	80 f9 01             	cmp    $0x1,%cl
    dea7:	75 29                	jne    ded2 <f0+0x2832>
    dea9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    deac:	0f b7 c0             	movzwl %ax,%eax
    deaf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    deb2:	48 0f af c1          	imul   %rcx,%rax
    deb6:	48 c1 e8 20          	shr    $0x20,%rax
    deba:	48 39 d0             	cmp    %rdx,%rax
    debd:	73 13                	jae    ded2 <f0+0x2832>
    debf:	49 01 c4             	add    %rax,%r12
    dec2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dec7:	0f 84 d1 02 00 00    	je     e19e <f0+0x2afe>
    decd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ded2:	48 89 de             	mov    %rbx,%rsi
    ded5:	48 89 ef             	mov    %rbp,%rdi
    ded8:	e8 63 cb ff ff       	call   aa40 <fwp_hof0.constprop.0>
    dedd:	48 89 ef             	mov    %rbp,%rdi
    dee0:	e8 bb 8d ff ff       	call   6ca0 <fwp_drop0>
    dee5:	48 89 df             	mov    %rbx,%rdi
    dee8:	e8 b3 8d ff ff       	call   6ca0 <fwp_drop0>
    deed:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    def4:	00 
    def5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    defc:	00 00 
    defe:	0f 85 95 04 00 00    	jne    e399 <f0+0x2cf9>
    df04:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    df0b:	31 c0                	xor    %eax,%eax
    df0d:	5b                   	pop    %rbx
    df0e:	5d                   	pop    %rbp
    df0f:	41 5c                	pop    %r12
    df11:	41 5d                	pop    %r13
    df13:	41 5e                	pop    %r14
    df15:	c3                   	ret
    df16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    df1d:	00 00 00 
    df20:	4c 89 ef             	mov    %r13,%rdi
    df23:	e8 28 76 ff ff       	call   5550 <fwp_rc_forget_slot>
    df28:	e9 2c d8 ff ff       	jmp    b759 <f0+0xb9>
    df2d:	0f 1f 00             	nopl   (%rax)
    df30:	66 85 c0             	test   %ax,%ax
    df33:	0f 85 ae f5 ff ff    	jne    d4e7 <f0+0x1e47>
    df39:	e9 99 f5 ff ff       	jmp    d4d7 <f0+0x1e37>
    df3e:	66 90                	xchg   %ax,%ax
    df40:	66 85 c0             	test   %ax,%ax
    df43:	0f 85 ff f4 ff ff    	jne    d448 <f0+0x1da8>
    df49:	e9 ea f4 ff ff       	jmp    d438 <f0+0x1d98>
    df4e:	66 90                	xchg   %ax,%ax
    df50:	66 85 c0             	test   %ax,%ax
    df53:	0f 85 50 f4 ff ff    	jne    d3a9 <f0+0x1d09>
    df59:	e9 3b f4 ff ff       	jmp    d399 <f0+0x1cf9>
    df5e:	66 90                	xchg   %ax,%ax
    df60:	66 85 c0             	test   %ax,%ax
    df63:	0f 85 a1 f3 ff ff    	jne    d30a <f0+0x1c6a>
    df69:	e9 8c f3 ff ff       	jmp    d2fa <f0+0x1c5a>
    df6e:	66 90                	xchg   %ax,%ax
    df70:	66 85 c0             	test   %ax,%ax
    df73:	0f 85 f2 f2 ff ff    	jne    d26b <f0+0x1bcb>
    df79:	e9 dd f2 ff ff       	jmp    d25b <f0+0x1bbb>
    df7e:	66 90                	xchg   %ax,%ax
    df80:	66 85 c0             	test   %ax,%ax
    df83:	0f 85 43 f2 ff ff    	jne    d1cc <f0+0x1b2c>
    df89:	e9 2e f2 ff ff       	jmp    d1bc <f0+0x1b1c>
    df8e:	66 90                	xchg   %ax,%ax
    df90:	66 85 c0             	test   %ax,%ax
    df93:	0f 85 94 f1 ff ff    	jne    d12d <f0+0x1a8d>
    df99:	e9 7f f1 ff ff       	jmp    d11d <f0+0x1a7d>
    df9e:	66 90                	xchg   %ax,%ax
    dfa0:	66 85 c0             	test   %ax,%ax
    dfa3:	0f 85 e5 f0 ff ff    	jne    d08e <f0+0x19ee>
    dfa9:	e9 d0 f0 ff ff       	jmp    d07e <f0+0x19de>
    dfae:	66 90                	xchg   %ax,%ax
    dfb0:	66 85 c0             	test   %ax,%ax
    dfb3:	0f 85 fd d9 ff ff    	jne    b9b6 <f0+0x316>
    dfb9:	e9 e8 d9 ff ff       	jmp    b9a6 <f0+0x306>
    dfbe:	66 90                	xchg   %ax,%ax
    dfc0:	66 85 c0             	test   %ax,%ax
    dfc3:	0f 85 57 d9 ff ff    	jne    b920 <f0+0x280>
    dfc9:	e9 42 d9 ff ff       	jmp    b910 <f0+0x270>
    dfce:	66 90                	xchg   %ax,%ax
    dfd0:	66 85 c0             	test   %ax,%ax
    dfd3:	0f 85 b1 d8 ff ff    	jne    b88a <f0+0x1ea>
    dfd9:	e9 9c d8 ff ff       	jmp    b87a <f0+0x1da>
    dfde:	66 90                	xchg   %ax,%ax
    dfe0:	66 85 c0             	test   %ax,%ax
    dfe3:	0f 85 0e eb ff ff    	jne    caf7 <f0+0x1457>
    dfe9:	e9 f9 ea ff ff       	jmp    cae7 <f0+0x1447>
    dfee:	66 90                	xchg   %ax,%ax
    dff0:	66 85 c0             	test   %ax,%ax
    dff3:	0f 85 5f ea ff ff    	jne    ca58 <f0+0x13b8>
    dff9:	e9 4a ea ff ff       	jmp    ca48 <f0+0x13a8>
    dffe:	66 90                	xchg   %ax,%ax
    e000:	66 85 c0             	test   %ax,%ax
    e003:	0f 85 e2 da ff ff    	jne    baeb <f0+0x44b>
    e009:	e9 cd da ff ff       	jmp    badb <f0+0x43b>
    e00e:	66 90                	xchg   %ax,%ax
    e010:	66 85 c0             	test   %ax,%ax
    e013:	0f 85 33 da ff ff    	jne    ba4c <f0+0x3ac>
    e019:	e9 1e da ff ff       	jmp    ba3c <f0+0x39c>
    e01e:	66 90                	xchg   %ax,%ax
    e020:	66 85 c0             	test   %ax,%ax
    e023:	0f 85 c6 ef ff ff    	jne    cfef <f0+0x194f>
    e029:	e9 b1 ef ff ff       	jmp    cfdf <f0+0x193f>
    e02e:	66 90                	xchg   %ax,%ax
    e030:	66 85 c0             	test   %ax,%ax
    e033:	0f 85 17 ef ff ff    	jne    cf50 <f0+0x18b0>
    e039:	e9 02 ef ff ff       	jmp    cf40 <f0+0x18a0>
    e03e:	66 90                	xchg   %ax,%ax
    e040:	66 85 c0             	test   %ax,%ax
    e043:	0f 85 68 ee ff ff    	jne    ceb1 <f0+0x1811>
    e049:	e9 53 ee ff ff       	jmp    cea1 <f0+0x1801>
    e04e:	66 90                	xchg   %ax,%ax
    e050:	66 85 c0             	test   %ax,%ax
    e053:	0f 85 b9 ed ff ff    	jne    ce12 <f0+0x1772>
    e059:	e9 a4 ed ff ff       	jmp    ce02 <f0+0x1762>
    e05e:	66 90                	xchg   %ax,%ax
    e060:	66 85 c0             	test   %ax,%ax
    e063:	0f 85 0a ed ff ff    	jne    cd73 <f0+0x16d3>
    e069:	e9 f5 ec ff ff       	jmp    cd63 <f0+0x16c3>
    e06e:	66 90                	xchg   %ax,%ax
    e070:	66 85 c0             	test   %ax,%ax
    e073:	0f 85 5b ec ff ff    	jne    ccd4 <f0+0x1634>
    e079:	e9 46 ec ff ff       	jmp    ccc4 <f0+0x1624>
    e07e:	66 90                	xchg   %ax,%ax
    e080:	66 85 c0             	test   %ax,%ax
    e083:	0f 85 ac eb ff ff    	jne    cc35 <f0+0x1595>
    e089:	e9 97 eb ff ff       	jmp    cc25 <f0+0x1585>
    e08e:	66 90                	xchg   %ax,%ax
    e090:	66 85 c0             	test   %ax,%ax
    e093:	0f 85 fd ea ff ff    	jne    cb96 <f0+0x14f6>
    e099:	e9 e8 ea ff ff       	jmp    cb86 <f0+0x14e6>
    e09e:	66 90                	xchg   %ax,%ax
    e0a0:	66 85 c0             	test   %ax,%ax
    e0a3:	0f 85 29 fe ff ff    	jne    ded2 <f0+0x2832>
    e0a9:	e9 14 fe ff ff       	jmp    dec2 <f0+0x2822>
    e0ae:	66 90                	xchg   %ax,%ax
    e0b0:	66 85 c0             	test   %ax,%ax
    e0b3:	0f 85 7f fd ff ff    	jne    de38 <f0+0x2798>
    e0b9:	e9 6a fd ff ff       	jmp    de28 <f0+0x2788>
    e0be:	66 90                	xchg   %ax,%ax
    e0c0:	66 85 c0             	test   %ax,%ax
    e0c3:	0f 85 d0 fc ff ff    	jne    dd99 <f0+0x26f9>
    e0c9:	e9 bb fc ff ff       	jmp    dd89 <f0+0x26e9>
    e0ce:	66 90                	xchg   %ax,%ax
    e0d0:	66 85 c0             	test   %ax,%ax
    e0d3:	0f 85 21 fc ff ff    	jne    dcfa <f0+0x265a>
    e0d9:	e9 0c fc ff ff       	jmp    dcea <f0+0x264a>
    e0de:	66 90                	xchg   %ax,%ax
    e0e0:	66 85 c0             	test   %ax,%ax
    e0e3:	0f 85 72 fb ff ff    	jne    dc5b <f0+0x25bb>
    e0e9:	e9 5d fb ff ff       	jmp    dc4b <f0+0x25ab>
    e0ee:	66 90                	xchg   %ax,%ax
    e0f0:	66 85 c0             	test   %ax,%ax
    e0f3:	0f 85 c3 fa ff ff    	jne    dbbc <f0+0x251c>
    e0f9:	e9 ae fa ff ff       	jmp    dbac <f0+0x250c>
    e0fe:	66 90                	xchg   %ax,%ax
    e100:	66 85 c0             	test   %ax,%ax
    e103:	0f 85 14 fa ff ff    	jne    db1d <f0+0x247d>
    e109:	e9 ff f9 ff ff       	jmp    db0d <f0+0x246d>
    e10e:	66 90                	xchg   %ax,%ax
    e110:	66 85 c0             	test   %ax,%ax
    e113:	0f 85 65 f9 ff ff    	jne    da7e <f0+0x23de>
    e119:	e9 50 f9 ff ff       	jmp    da6e <f0+0x23ce>
    e11e:	66 90                	xchg   %ax,%ax
    e120:	66 85 c0             	test   %ax,%ax
    e123:	0f 85 b6 f8 ff ff    	jne    d9df <f0+0x233f>
    e129:	e9 a1 f8 ff ff       	jmp    d9cf <f0+0x232f>
    e12e:	66 90                	xchg   %ax,%ax
    e130:	66 85 c0             	test   %ax,%ax
    e133:	0f 85 07 f8 ff ff    	jne    d940 <f0+0x22a0>
    e139:	e9 f2 f7 ff ff       	jmp    d930 <f0+0x2290>
    e13e:	66 90                	xchg   %ax,%ax
    e140:	66 85 c0             	test   %ax,%ax
    e143:	0f 85 58 f7 ff ff    	jne    d8a1 <f0+0x2201>
    e149:	e9 43 f7 ff ff       	jmp    d891 <f0+0x21f1>
    e14e:	66 90                	xchg   %ax,%ax
    e150:	66 85 c0             	test   %ax,%ax
    e153:	0f 85 a9 f6 ff ff    	jne    d802 <f0+0x2162>
    e159:	e9 94 f6 ff ff       	jmp    d7f2 <f0+0x2152>
    e15e:	66 90                	xchg   %ax,%ax
    e160:	66 85 c0             	test   %ax,%ax
    e163:	0f 85 fa f5 ff ff    	jne    d763 <f0+0x20c3>
    e169:	e9 e5 f5 ff ff       	jmp    d753 <f0+0x20b3>
    e16e:	66 90                	xchg   %ax,%ax
    e170:	66 85 c0             	test   %ax,%ax
    e173:	0f 85 4b f5 ff ff    	jne    d6c4 <f0+0x2024>
    e179:	e9 36 f5 ff ff       	jmp    d6b4 <f0+0x2014>
    e17e:	66 90                	xchg   %ax,%ax
    e180:	66 85 c0             	test   %ax,%ax
    e183:	0f 85 9c f4 ff ff    	jne    d625 <f0+0x1f85>
    e189:	e9 87 f4 ff ff       	jmp    d615 <f0+0x1f75>
    e18e:	66 90                	xchg   %ax,%ax
    e190:	66 85 c0             	test   %ax,%ax
    e193:	0f 85 ed f3 ff ff    	jne    d586 <f0+0x1ee6>
    e199:	e9 d8 f3 ff ff       	jmp    d576 <f0+0x1ed6>
    e19e:	4c 89 e7             	mov    %r12,%rdi
    e1a1:	e8 aa 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1a6:	e9 22 fd ff ff       	jmp    decd <f0+0x282d>
    e1ab:	4c 89 e7             	mov    %r12,%rdi
    e1ae:	e8 9d 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1b3:	e9 cd d6 ff ff       	jmp    b885 <f0+0x1e5>
    e1b8:	4c 89 e7             	mov    %r12,%rdi
    e1bb:	e8 90 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1c0:	e9 56 d7 ff ff       	jmp    b91b <f0+0x27b>
    e1c5:	4c 89 e7             	mov    %r12,%rdi
    e1c8:	e8 83 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1cd:	e9 df d7 ff ff       	jmp    b9b1 <f0+0x311>
    e1d2:	4c 89 e7             	mov    %r12,%rdi
    e1d5:	e8 76 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1da:	e9 68 d8 ff ff       	jmp    ba47 <f0+0x3a7>
    e1df:	4c 89 e7             	mov    %r12,%rdi
    e1e2:	e8 69 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1e7:	e9 fa d8 ff ff       	jmp    bae6 <f0+0x446>
    e1ec:	4c 89 e7             	mov    %r12,%rdi
    e1ef:	e8 5c 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1f4:	e9 5a e8 ff ff       	jmp    ca53 <f0+0x13b3>
    e1f9:	4c 89 e7             	mov    %r12,%rdi
    e1fc:	e8 4f 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e201:	e9 ec e8 ff ff       	jmp    caf2 <f0+0x1452>
    e206:	4c 89 e7             	mov    %r12,%rdi
    e209:	e8 42 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e20e:	e9 7e e9 ff ff       	jmp    cb91 <f0+0x14f1>
    e213:	4c 89 e7             	mov    %r12,%rdi
    e216:	e8 35 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e21b:	e9 10 ea ff ff       	jmp    cc30 <f0+0x1590>
    e220:	4c 89 e7             	mov    %r12,%rdi
    e223:	e8 28 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e228:	e9 a2 ea ff ff       	jmp    cccf <f0+0x162f>
    e22d:	4c 89 e7             	mov    %r12,%rdi
    e230:	e8 1b 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e235:	e9 34 eb ff ff       	jmp    cd6e <f0+0x16ce>
    e23a:	4c 89 e7             	mov    %r12,%rdi
    e23d:	e8 0e 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e242:	e9 c6 eb ff ff       	jmp    ce0d <f0+0x176d>
    e247:	4c 89 e7             	mov    %r12,%rdi
    e24a:	e8 01 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e24f:	e9 58 ec ff ff       	jmp    ceac <f0+0x180c>
    e254:	4c 89 e7             	mov    %r12,%rdi
    e257:	e8 f4 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e25c:	e9 ea ec ff ff       	jmp    cf4b <f0+0x18ab>
    e261:	4c 89 e7             	mov    %r12,%rdi
    e264:	e8 e7 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e269:	e9 7c ed ff ff       	jmp    cfea <f0+0x194a>
    e26e:	4c 89 e7             	mov    %r12,%rdi
    e271:	e8 da 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e276:	e9 0e ee ff ff       	jmp    d089 <f0+0x19e9>
    e27b:	4c 89 e7             	mov    %r12,%rdi
    e27e:	e8 cd 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e283:	e9 a0 ee ff ff       	jmp    d128 <f0+0x1a88>
    e288:	4c 89 e7             	mov    %r12,%rdi
    e28b:	e8 c0 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e290:	e9 32 ef ff ff       	jmp    d1c7 <f0+0x1b27>
    e295:	4c 89 e7             	mov    %r12,%rdi
    e298:	e8 b3 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e29d:	e9 c4 ef ff ff       	jmp    d266 <f0+0x1bc6>
    e2a2:	4c 89 e7             	mov    %r12,%rdi
    e2a5:	e8 a6 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e2aa:	e9 56 f0 ff ff       	jmp    d305 <f0+0x1c65>
    e2af:	4c 89 e7             	mov    %r12,%rdi
    e2b2:	e8 99 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e2b7:	e9 e8 f0 ff ff       	jmp    d3a4 <f0+0x1d04>
    e2bc:	4c 89 e7             	mov    %r12,%rdi
    e2bf:	e8 8c 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e2c4:	e9 7a f1 ff ff       	jmp    d443 <f0+0x1da3>
    e2c9:	4c 89 e7             	mov    %r12,%rdi
    e2cc:	e8 7f 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e2d1:	e9 0c f2 ff ff       	jmp    d4e2 <f0+0x1e42>
    e2d6:	4c 89 e7             	mov    %r12,%rdi
    e2d9:	e8 72 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e2de:	e9 9e f2 ff ff       	jmp    d581 <f0+0x1ee1>
    e2e3:	4c 89 e7             	mov    %r12,%rdi
    e2e6:	e8 65 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e2eb:	e9 30 f3 ff ff       	jmp    d620 <f0+0x1f80>
    e2f0:	4c 89 e7             	mov    %r12,%rdi
    e2f3:	e8 58 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e2f8:	e9 c2 f3 ff ff       	jmp    d6bf <f0+0x201f>
    e2fd:	4c 89 e7             	mov    %r12,%rdi
    e300:	e8 4b 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e305:	e9 54 f4 ff ff       	jmp    d75e <f0+0x20be>
    e30a:	4c 89 e7             	mov    %r12,%rdi
    e30d:	e8 3e 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e312:	e9 e6 f4 ff ff       	jmp    d7fd <f0+0x215d>
    e317:	4c 89 e7             	mov    %r12,%rdi
    e31a:	e8 31 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e31f:	e9 78 f5 ff ff       	jmp    d89c <f0+0x21fc>
    e324:	4c 89 e7             	mov    %r12,%rdi
    e327:	e8 24 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e32c:	e9 0a f6 ff ff       	jmp    d93b <f0+0x229b>
    e331:	4c 89 e7             	mov    %r12,%rdi
    e334:	e8 17 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e339:	e9 9c f6 ff ff       	jmp    d9da <f0+0x233a>
    e33e:	4c 89 e7             	mov    %r12,%rdi
    e341:	e8 0a 72 ff ff       	call   5550 <fwp_rc_forget_slot>
    e346:	e9 2e f7 ff ff       	jmp    da79 <f0+0x23d9>
    e34b:	4c 89 e7             	mov    %r12,%rdi
    e34e:	e8 fd 71 ff ff       	call   5550 <fwp_rc_forget_slot>
    e353:	e9 c0 f7 ff ff       	jmp    db18 <f0+0x2478>
    e358:	4c 89 e7             	mov    %r12,%rdi
    e35b:	e8 f0 71 ff ff       	call   5550 <fwp_rc_forget_slot>
    e360:	e9 52 f8 ff ff       	jmp    dbb7 <f0+0x2517>
    e365:	4c 89 e7             	mov    %r12,%rdi
    e368:	e8 e3 71 ff ff       	call   5550 <fwp_rc_forget_slot>
    e36d:	e9 e4 f8 ff ff       	jmp    dc56 <f0+0x25b6>
    e372:	4c 89 e7             	mov    %r12,%rdi
    e375:	e8 d6 71 ff ff       	call   5550 <fwp_rc_forget_slot>
    e37a:	e9 76 f9 ff ff       	jmp    dcf5 <f0+0x2655>
    e37f:	4c 89 e7             	mov    %r12,%rdi
    e382:	e8 c9 71 ff ff       	call   5550 <fwp_rc_forget_slot>
    e387:	e9 08 fa ff ff       	jmp    dd94 <f0+0x26f4>
    e38c:	4c 89 e7             	mov    %r12,%rdi
    e38f:	e8 bc 71 ff ff       	call   5550 <fwp_rc_forget_slot>
    e394:	e9 9a fa ff ff       	jmp    de33 <f0+0x2793>
    e399:	e8 c2 50 ff ff       	call   3460 <__stack_chk_fail@plt>
    e39e:	66 90                	xchg   %ax,%ax

000000000000e3a0 <fwp_main_thread>:
    e3a0:	f3 0f 1e fa          	endbr64
    e3a4:	41 54                	push   %r12
    e3a6:	55                   	push   %rbp
    e3a7:	53                   	push   %rbx
    e3a8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e3af:	8b 35 cf 67 01 00    	mov    0x167cf(%rip),%esi        # 24b84 <fwp_heap+0x13a4>
    e3b5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e3bc:	00 00 
    e3be:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e3c5:	00 
    e3c6:	31 c0                	xor    %eax,%eax
    e3c8:	85 f6                	test   %esi,%esi
    e3ca:	0f 84 a8 06 00 00    	je     ea78 <fwp_main_thread+0x6d8>
    e3d0:	8b 0d b2 67 01 00    	mov    0x167b2(%rip),%ecx        # 24b88 <fwp_heap+0x13a8>
    e3d6:	85 c9                	test   %ecx,%ecx
    e3d8:	0f 85 82 06 00 00    	jne    ea60 <fwp_main_thread+0x6c0>
    e3de:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e3e3:	31 f6                	xor    %esi,%esi
    e3e5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e3ea:	48 c7 05 7b 4d 01 00 	movq   $0x40000000,0x14d7b(%rip)        # 23170 <fwp_main_stack_size>
    e3f1:	00 00 00 40 
    e3f5:	48 89 05 7c 4d 01 00 	mov    %rax,0x14d7c(%rip)        # 23178 <fwp_main_stack_top>
    e3fc:	48 8d 05 9d 4c 00 00 	lea    0x4c9d(%rip),%rax        # 130a0 <alt.5>
    e403:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e408:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e40f:	01 00 
    e411:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e418:	00 
    e419:	e8 a2 52 ff ff       	call   36c0 <sigaltstack@plt>
    e41e:	85 c0                	test   %eax,%eax
    e420:	0f 85 8a 06 00 00    	jne    eab0 <fwp_main_thread+0x710>
    e426:	31 c0                	xor    %eax,%eax
    e428:	b9 12 00 00 00       	mov    $0x12,%ecx
    e42d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e432:	f3 48 ab             	rep stos %rax,(%rdi)
    e435:	48 8d 05 b4 58 ff ff 	lea    -0xa74c(%rip),%rax        # 3cf0 <fwp_segv>
    e43c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e441:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e448:	04 00 00 08 
    e44c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e451:	e8 2a 51 ff ff       	call   3580 <sigemptyset@plt>
    e456:	85 c0                	test   %eax,%eax
    e458:	0f 85 52 06 00 00    	jne    eab0 <fwp_main_thread+0x710>
    e45e:	31 d2                	xor    %edx,%edx
    e460:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e465:	bf 0b 00 00 00       	mov    $0xb,%edi
    e46a:	e8 91 4f ff ff       	call   3400 <sigaction@plt>
    e46f:	85 c0                	test   %eax,%eax
    e471:	0f 85 39 06 00 00    	jne    eab0 <fwp_main_thread+0x710>
    e477:	31 d2                	xor    %edx,%edx
    e479:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e47e:	bf 07 00 00 00       	mov    $0x7,%edi
    e483:	e8 78 4f ff ff       	call   3400 <sigaction@plt>
    e488:	85 c0                	test   %eax,%eax
    e48a:	0f 85 20 06 00 00    	jne    eab0 <fwp_main_thread+0x710>
    e490:	8b 15 82 4c 01 00    	mov    0x14c82(%rip),%edx        # 23118 <descent_registered>
    e496:	85 d2                	test   %edx,%edx
    e498:	0f 84 72 05 00 00    	je     ea10 <fwp_main_thread+0x670>
    e49e:	8b 05 ec 4b 00 00    	mov    0x4bec(%rip),%eax        # 13090 <st.3>
    e4a4:	85 c0                	test   %eax,%eax
    e4a6:	0f 84 90 05 00 00    	je     ea3c <fwp_main_thread+0x69c>
    e4ac:	48 8b 2d 0d 53 01 00 	mov    0x1530d(%rip),%rbp        # 237c0 <fwp_cur>
    e4b3:	48 85 ed             	test   %rbp,%rbp
    e4b6:	0f 84 74 03 00 00    	je     e830 <fwp_main_thread+0x490>
    e4bc:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e4c1:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e4c5:	48 89 eb             	mov    %rbp,%rbx
    e4c8:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e4cd:	0f 84 41 01 00 00    	je     e614 <fwp_main_thread+0x274>
    e4d3:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e4d8:	0f 84 82 02 00 00    	je     e760 <fwp_main_thread+0x3c0>
    e4de:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e4e2:	0f 84 68 02 00 00    	je     e750 <fwp_main_thread+0x3b0>
    e4e8:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e4ec:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e4f0:	0f 85 ea 02 00 00    	jne    e7e0 <fwp_main_thread+0x440>
    e4f6:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e4fa:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e501:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e505:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e50c:	00 00 00 00 
    e510:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e517:	48 85 d2             	test   %rdx,%rdx
    e51a:	74 07                	je     e523 <fwp_main_thread+0x183>
    e51c:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e523:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e527:	48 85 c0             	test   %rax,%rax
    e52a:	74 34                	je     e560 <fwp_main_thread+0x1c0>
    e52c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e530:	48 8b 05 61 52 01 00 	mov    0x15261(%rip),%rax        # 23798 <fwp_timers>
    e537:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e53b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e542:	00 00 00 00 
    e546:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e54d:	48 85 c0             	test   %rax,%rax
    e550:	74 07                	je     e559 <fwp_main_thread+0x1b9>
    e552:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e559:	48 89 1d 38 52 01 00 	mov    %rbx,0x15238(%rip)        # 23798 <fwp_timers>
    e560:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e564:	e8 87 91 ff ff       	call   76f0 <fwp_block>
    e569:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e570:	48 85 c9             	test   %rcx,%rcx
    e573:	74 47                	je     e5bc <fwp_main_thread+0x21c>
    e575:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e57c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e583:	48 85 d2             	test   %rdx,%rdx
    e586:	0f 84 94 02 00 00    	je     e820 <fwp_main_thread+0x480>
    e58c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e593:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e59a:	48 85 c0             	test   %rax,%rax
    e59d:	74 07                	je     e5a6 <fwp_main_thread+0x206>
    e59f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e5a6:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e5ad:	00 00 00 00 
    e5b1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e5b5:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e5bc:	48 8b 0d fd 51 01 00 	mov    0x151fd(%rip),%rcx        # 237c0 <fwp_cur>
    e5c3:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e5c7:	0f 84 03 02 00 00    	je     e7d0 <fwp_main_thread+0x430>
    e5cd:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e5d4:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e5db:	48 85 d2             	test   %rdx,%rdx
    e5de:	0f 84 fc 03 00 00    	je     e9e0 <fwp_main_thread+0x640>
    e5e4:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e5eb:	48 85 c0             	test   %rax,%rax
    e5ee:	74 07                	je     e5f7 <fwp_main_thread+0x257>
    e5f0:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e5f7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e5fb:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e5ff:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e606:	48 89 cb             	mov    %rcx,%rbx
    e609:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e60e:	0f 85 bf fe ff ff    	jne    e4d3 <fwp_main_thread+0x133>
    e614:	48 83 3d 3c 6e 01 00 	cmpq   $0x0,0x16e3c(%rip)        # 25458 <fwp_state_len>
    e61b:	00 
    e61c:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e620:	0f 84 bc 00 00 00    	je     e6e2 <fwp_main_thread+0x342>
    e626:	48 39 1d 8b 51 01 00 	cmp    %rbx,0x1518b(%rip)        # 237b8 <fwp_root>
    e62d:	c7 05 69 4a 01 00 00 	movl   $0x0,0x14a69(%rip)        # 230a0 <fwp_exit_code>
    e634:	00 00 00 
    e637:	0f 85 91 04 00 00    	jne    eace <fwp_main_thread+0x72e>
    e63d:	48 85 db             	test   %rbx,%rbx
    e640:	0f 84 10 02 00 00    	je     e856 <fwp_main_thread+0x4b6>
    e646:	48 8b 15 3b 51 01 00 	mov    0x1513b(%rip),%rdx        # 23788 <fwp_tasks_active>
    e64d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e651:	48 85 d2             	test   %rdx,%rdx
    e654:	0f 84 fc 01 00 00    	je     e856 <fwp_main_thread+0x4b6>
    e65a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e660:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e664:	75 08                	jne    e66e <fwp_main_thread+0x2ce>
    e666:	48 89 d7             	mov    %rdx,%rdi
    e669:	e8 92 5c ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e66e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e675:	48 85 d2             	test   %rdx,%rdx
    e678:	75 e6                	jne    e660 <fwp_main_thread+0x2c0>
    e67a:	eb 31                	jmp    e6ad <fwp_main_thread+0x30d>
    e67c:	0f 1f 40 00          	nopl   0x0(%rax)
    e680:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e687:	48 89 1d 12 51 01 00 	mov    %rbx,0x15112(%rip)        # 237a0 <fwp_ready_tail>
    e68e:	e8 5d 90 ff ff       	call   76f0 <fwp_block>
    e693:	e8 58 8e ff ff       	call   74f0 <fwp_free_zombie>
    e698:	48 83 3d e8 50 01 00 	cmpq   $0x0,0x150e8(%rip)        # 23788 <fwp_tasks_active>
    e69f:	00 
    e6a0:	0f 84 b0 01 00 00    	je     e856 <fwp_main_thread+0x4b6>
    e6a6:	48 8b 1d 0b 51 01 00 	mov    0x1510b(%rip),%rbx        # 237b8 <fwp_root>
    e6ad:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e6b1:	75 db                	jne    e68e <fwp_main_thread+0x2ee>
    e6b3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e6b7:	75 d5                	jne    e68e <fwp_main_thread+0x2ee>
    e6b9:	48 8b 05 e0 50 01 00 	mov    0x150e0(%rip),%rax        # 237a0 <fwp_ready_tail>
    e6c0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e6c4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e6cb:	00 00 00 00 
    e6cf:	48 85 c0             	test   %rax,%rax
    e6d2:	75 ac                	jne    e680 <fwp_main_thread+0x2e0>
    e6d4:	48 89 1d cd 50 01 00 	mov    %rbx,0x150cd(%rip)        # 237a8 <fwp_ready_head>
    e6db:	eb aa                	jmp    e687 <fwp_main_thread+0x2e7>
    e6dd:	0f 1f 00             	nopl   (%rax)
    e6e0:	31 db                	xor    %ebx,%ebx
    e6e2:	48 83 3d 5e 6d 01 00 	cmpq   $0x0,0x16d5e(%rip)        # 25448 <fwp_state_owners>
    e6e9:	00 
    e6ea:	0f 85 36 ff ff ff    	jne    e626 <fwp_main_thread+0x286>
    e6f0:	48 8b 3d 69 6d 01 00 	mov    0x16d69(%rip),%rdi        # 25460 <fwp_state>
    e6f7:	e8 94 70 ff ff       	call   5790 <fwp_mem_free>
    e6fc:	48 c7 05 59 6d 01 00 	movq   $0x0,0x16d59(%rip)        # 25460 <fwp_state>
    e703:	00 00 00 00 
    e707:	48 c7 05 3e 6d 01 00 	movq   $0x0,0x16d3e(%rip)        # 25450 <fwp_state_cap>
    e70e:	00 00 00 00 
    e712:	48 85 db             	test   %rbx,%rbx
    e715:	0f 84 76 03 00 00    	je     ea91 <fwp_main_thread+0x6f1>
    e71b:	48 39 1d 96 50 01 00 	cmp    %rbx,0x15096(%rip)        # 237b8 <fwp_root>
    e722:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e729:	00 00 00 00 
    e72d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e734:	00 00 00 00 
    e738:	c7 05 5e 49 01 00 00 	movl   $0x0,0x1495e(%rip)        # 230a0 <fwp_exit_code>
    e73f:	00 00 00 
    e742:	0f 84 fe fe ff ff    	je     e646 <fwp_main_thread+0x2a6>
    e748:	e9 03 50 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e74d:	0f 1f 00             	nopl   (%rax)
    e750:	e8 0b 5e ff ff       	call   4560 <fwp_now_ns>
    e755:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e759:	0f 8d 91 02 00 00    	jge    e9f0 <fwp_main_thread+0x650>
    e75f:	90                   	nop
    e760:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e764:	0f 85 7e fd ff ff    	jne    e4e8 <fwp_main_thread+0x148>
    e76a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e76e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e772:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e776:	0f 85 7e fd ff ff    	jne    e4fa <fwp_main_thread+0x15a>
    e77c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e780:	48 85 c9             	test   %rcx,%rcx
    e783:	0f 84 71 fd ff ff    	je     e4fa <fwp_main_thread+0x15a>
    e789:	48 85 c0             	test   %rax,%rax
    e78c:	0f 84 2f 03 00 00    	je     eac1 <fwp_main_thread+0x721>
    e792:	48 39 c8             	cmp    %rcx,%rax
    e795:	48 0f 4f c1          	cmovg  %rcx,%rax
    e799:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e7a0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e7a4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e7ab:	00 00 00 00 
    e7af:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e7b6:	48 85 d2             	test   %rdx,%rdx
    e7b9:	74 07                	je     e7c2 <fwp_main_thread+0x422>
    e7bb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e7c2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e7c6:	e9 61 fd ff ff       	jmp    e52c <fwp_main_thread+0x18c>
    e7cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e7d0:	48 89 cb             	mov    %rcx,%rbx
    e7d3:	e9 f0 fc ff ff       	jmp    e4c8 <fwp_main_thread+0x128>
    e7d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e7df:	00 
    e7e0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e7e4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e7eb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e7f2:	00 00 00 00 
    e7f6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e7fd:	48 85 c0             	test   %rax,%rax
    e800:	0f 84 82 02 00 00    	je     ea88 <fwp_main_thread+0x6e8>
    e806:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e80d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e811:	e9 4a fd ff ff       	jmp    e560 <fwp_main_thread+0x1c0>
    e816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e81d:	00 00 00 
    e820:	48 89 01             	mov    %rax,(%rcx)
    e823:	e9 72 fd ff ff       	jmp    e59a <fwp_main_thread+0x1fa>
    e828:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e82f:	00 
    e830:	48 83 3d 20 6c 01 00 	cmpq   $0x0,0x16c20(%rip)        # 25458 <fwp_state_len>
    e837:	00 
    e838:	0f 84 a2 fe ff ff    	je     e6e0 <fwp_main_thread+0x340>
    e83e:	48 83 3d 72 4f 01 00 	cmpq   $0x0,0x14f72(%rip)        # 237b8 <fwp_root>
    e845:	00 
    e846:	c7 05 50 48 01 00 00 	movl   $0x0,0x14850(%rip)        # 230a0 <fwp_exit_code>
    e84d:	00 00 00 
    e850:	0f 85 7d 02 00 00    	jne    ead3 <fwp_main_thread+0x733>
    e856:	e8 95 8c ff ff       	call   74f0 <fwp_free_zombie>
    e85b:	48 83 3d 45 4f 01 00 	cmpq   $0x0,0x14f45(%rip)        # 237a8 <fwp_ready_head>
    e862:	00 
    e863:	0f 85 e7 4e ff ff    	jne    3750 <fwp_main_thread.cold>
    e869:	48 83 3d 27 4f 01 00 	cmpq   $0x0,0x14f27(%rip)        # 23798 <fwp_timers>
    e870:	00 
    e871:	0f 85 d9 4e ff ff    	jne    3750 <fwp_main_thread.cold>
    e877:	8b 1d 07 49 01 00    	mov    0x14907(%rip),%ebx        # 23184 <fwp_stack_pool_n>
    e87d:	85 db                	test   %ebx,%ebx
    e87f:	74 36                	je     e8b7 <fwp_main_thread+0x517>
    e881:	83 eb 01             	sub    $0x1,%ebx
    e884:	48 8d 05 15 49 01 00 	lea    0x14915(%rip),%rax        # 231a0 <fwp_stack_pool>
    e88b:	48 63 d3             	movslq %ebx,%rdx
    e88e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e892:	eb 07                	jmp    e89b <fwp_main_thread+0x4fb>
    e894:	0f 1f 40 00          	nopl   0x0(%rax)
    e898:	83 eb 01             	sub    $0x1,%ebx
    e89b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e89f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e8a4:	89 1d da 48 01 00    	mov    %ebx,0x148da(%rip)        # 23184 <fwp_stack_pool_n>
    e8aa:	48 83 ed 08          	sub    $0x8,%rbp
    e8ae:	e8 2d 4d ff ff       	call   35e0 <munmap@plt>
    e8b3:	85 db                	test   %ebx,%ebx
    e8b5:	75 e1                	jne    e898 <fwp_main_thread+0x4f8>
    e8b7:	8b 3d 67 47 00 00    	mov    0x4767(%rip),%edi        # 13024 <fwp_epfd>
    e8bd:	85 ff                	test   %edi,%edi
    e8bf:	78 05                	js     e8c6 <fwp_main_thread+0x526>
    e8c1:	e8 0a 4c ff ff       	call   34d0 <close@plt>
    e8c6:	4c 8b 25 d3 4a 01 00 	mov    0x14ad3(%rip),%r12        # 233a0 <fwp_nfdws>
    e8cd:	48 8b 2d d4 4a 01 00 	mov    0x14ad4(%rip),%rbp        # 233a8 <fwp_fdws>
    e8d4:	31 db                	xor    %ebx,%ebx
    e8d6:	c7 05 44 47 00 00 ff 	movl   $0xffffffff,0x4744(%rip)        # 13024 <fwp_epfd>
    e8dd:	ff ff ff 
    e8e0:	4d 85 e4             	test   %r12,%r12
    e8e3:	74 38                	je     e91d <fwp_main_thread+0x57d>
    e8e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e8ec:	00 00 00 00 
    e8f0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e8f5:	48 85 ff             	test   %rdi,%rdi
    e8f8:	74 1a                	je     e914 <fwp_main_thread+0x574>
    e8fa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e8fe:	0f 85 4c 4e ff ff    	jne    3750 <fwp_main_thread.cold>
    e904:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e909:	0f 85 41 4e ff ff    	jne    3750 <fwp_main_thread.cold>
    e90f:	e8 7c 6e ff ff       	call   5790 <fwp_mem_free>
    e914:	48 83 c3 01          	add    $0x1,%rbx
    e918:	4c 39 e3             	cmp    %r12,%rbx
    e91b:	75 d3                	jne    e8f0 <fwp_main_thread+0x550>
    e91d:	48 89 ef             	mov    %rbp,%rdi
    e920:	e8 6b 6e ff ff       	call   5790 <fwp_mem_free>
    e925:	48 8b 15 8c 4e 01 00 	mov    0x14e8c(%rip),%rdx        # 237b8 <fwp_root>
    e92c:	48 c7 05 71 4a 01 00 	movq   $0x0,0x14a71(%rip)        # 233a8 <fwp_fdws>
    e933:	00 00 00 00 
    e937:	48 c7 05 5e 4a 01 00 	movq   $0x0,0x14a5e(%rip)        # 233a0 <fwp_nfdws>
    e93e:	00 00 00 00 
    e942:	48 85 d2             	test   %rdx,%rdx
    e945:	74 4e                	je     e995 <fwp_main_thread+0x5f5>
    e947:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e94c:	0f 85 fe 4d ff ff    	jne    3750 <fwp_main_thread.cold>
    e952:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e959:	00 
    e95a:	0f 85 f0 4d ff ff    	jne    3750 <fwp_main_thread.cold>
    e960:	48 83 3d f0 6a 01 00 	cmpq   $0x0,0x16af0(%rip)        # 25458 <fwp_state_len>
    e967:	00 
    e968:	0f 85 e2 4d ff ff    	jne    3750 <fwp_main_thread.cold>
    e96e:	48 83 3d d2 6a 01 00 	cmpq   $0x0,0x16ad2(%rip)        # 25448 <fwp_state_owners>
    e975:	00 
    e976:	0f 85 d4 4d ff ff    	jne    3750 <fwp_main_thread.cold>
    e97c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e981:	31 c0                	xor    %eax,%eax
    e983:	48 8d 3d 36 4a 01 00 	lea    0x14a36(%rip),%rdi        # 233c0 <fwp_root_context>
    e98a:	f3 48 ab             	rep stos %rax,(%rdi)
    e98d:	48 89 d7             	mov    %rdx,%rdi
    e990:	e8 fb 6d ff ff       	call   5790 <fwp_mem_free>
    e995:	48 8b 3d a4 46 00 00 	mov    0x46a4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    e99c:	48 c7 05 19 4e 01 00 	movq   $0x0,0x14e19(%rip)        # 237c0 <fwp_cur>
    e9a3:	00 00 00 00 
    e9a7:	48 c7 05 06 4e 01 00 	movq   $0x0,0x14e06(%rip)        # 237b8 <fwp_root>
    e9ae:	00 00 00 00 
    e9b2:	e8 09 4c ff ff       	call   35c0 <fflush@plt>
    e9b7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e9be:	00 
    e9bf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e9c6:	00 00 
    e9c8:	0f 85 fb 00 00 00    	jne    eac9 <fwp_main_thread+0x729>
    e9ce:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e9d5:	31 c0                	xor    %eax,%eax
    e9d7:	5b                   	pop    %rbx
    e9d8:	5d                   	pop    %rbp
    e9d9:	41 5c                	pop    %r12
    e9db:	c3                   	ret
    e9dc:	0f 1f 40 00          	nopl   0x0(%rax)
    e9e0:	48 89 05 b1 4d 01 00 	mov    %rax,0x14db1(%rip)        # 23798 <fwp_timers>
    e9e7:	e9 ff fb ff ff       	jmp    e5eb <fwp_main_thread+0x24b>
    e9ec:	0f 1f 40 00          	nopl   0x0(%rax)
    e9f0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e9f4:	0f 85 66 fd ff ff    	jne    e760 <fwp_main_thread+0x3c0>
    e9fa:	48 89 ef             	mov    %rbp,%rdi
    e9fd:	e8 fe 58 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    ea02:	e9 59 fd ff ff       	jmp    e760 <fwp_main_thread+0x3c0>
    ea07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ea0e:	00 00 
    ea10:	48 8d 3d f9 53 ff ff 	lea    -0xac07(%rip),%rdi        # 3e10 <descent_phase_report>
    ea17:	e8 d4 02 00 00       	call   ecf0 <atexit>
    ea1c:	85 c0                	test   %eax,%eax
    ea1e:	0f 85 98 00 00 00    	jne    eabc <fwp_main_thread+0x71c>
    ea24:	c7 05 ea 46 01 00 01 	movl   $0x1,0x146ea(%rip)        # 23118 <descent_registered>
    ea2b:	00 00 00 
    ea2e:	8b 05 5c 46 00 00    	mov    0x465c(%rip),%eax        # 13090 <st.3>
    ea34:	85 c0                	test   %eax,%eax
    ea36:	0f 85 70 fa ff ff    	jne    e4ac <fwp_main_thread+0x10c>
    ea3c:	e8 5f cc ff ff       	call   b6a0 <f0>
    ea41:	48 c7 05 3c 46 00 00 	movq   $0x0,0x463c(%rip)        # 13088 <v.2>
    ea48:	00 00 00 00 
    ea4c:	c7 05 3a 46 00 00 01 	movl   $0x1,0x463a(%rip)        # 13090 <st.3>
    ea53:	00 00 00 
    ea56:	e9 51 fa ff ff       	jmp    e4ac <fwp_main_thread+0x10c>
    ea5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ea60:	48 8d 3d f9 61 ff ff 	lea    -0x9e07(%rip),%rdi        # 4c60 <fwp_heap_report>
    ea67:	e8 84 02 00 00       	call   ecf0 <atexit>
    ea6c:	e9 6d f9 ff ff       	jmp    e3de <fwp_main_thread+0x3e>
    ea71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ea78:	e8 f3 62 ff ff       	call   4d70 <fwp_heap_init>
    ea7d:	e9 4e f9 ff ff       	jmp    e3d0 <fwp_main_thread+0x30>
    ea82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ea88:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ea8c:	e9 cf fa ff ff       	jmp    e560 <fwp_main_thread+0x1c0>
    ea91:	48 83 3d 1f 4d 01 00 	cmpq   $0x0,0x14d1f(%rip)        # 237b8 <fwp_root>
    ea98:	00 
    ea99:	c7 05 fd 45 01 00 00 	movl   $0x0,0x145fd(%rip)        # 230a0 <fwp_exit_code>
    eaa0:	00 00 00 
    eaa3:	0f 84 ad fd ff ff    	je     e856 <fwp_main_thread+0x4b6>
    eaa9:	e9 a2 4c ff ff       	jmp    3750 <fwp_main_thread.cold>
    eaae:	66 90                	xchg   %ax,%ax
    eab0:	48 8d 3d 29 0f 00 00 	lea    0xf29(%rip),%rdi        # f9e0 <_IO_stdin_used+0x9e0>
    eab7:	e8 34 59 ff ff       	call   43f0 <fwp_trap>
    eabc:	e8 1f 53 ff ff       	call   3de0 <descent_phase_fail>
    eac1:	48 89 c8             	mov    %rcx,%rax
    eac4:	e9 d0 fc ff ff       	jmp    e799 <fwp_main_thread+0x3f9>
    eac9:	e8 92 49 ff ff       	call   3460 <__stack_chk_fail@plt>
    eace:	e9 7d 4c ff ff       	jmp    3750 <fwp_main_thread.cold>
    ead3:	e9 78 4c ff ff       	jmp    3750 <fwp_main_thread.cold>
    ead8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    eadf:	00 

000000000000eae0 <__divmodti4>:
    eae0:	f3 0f 1e fa          	endbr64
    eae4:	55                   	push   %rbp
    eae5:	49 89 f1             	mov    %rsi,%r9
    eae8:	49 89 d2             	mov    %rdx,%r10
    eaeb:	48 89 fe             	mov    %rdi,%rsi
    eaee:	49 89 cb             	mov    %rcx,%r11
    eaf1:	48 89 e5             	mov    %rsp,%rbp
    eaf4:	41 57                	push   %r15
    eaf6:	41 56                	push   %r14
    eaf8:	41 55                	push   %r13
    eafa:	41 54                	push   %r12
    eafc:	53                   	push   %rbx
    eafd:	4c 89 c3             	mov    %r8,%rbx
    eb00:	45 31 c0             	xor    %r8d,%r8d
    eb03:	4d 85 c9             	test   %r9,%r9
    eb06:	79 12                	jns    eb1a <__divmodti4+0x3a>
    eb08:	31 ff                	xor    %edi,%edi
    eb0a:	48 f7 de             	neg    %rsi
    eb0d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    eb14:	4c 19 cf             	sbb    %r9,%rdi
    eb17:	49 89 f9             	mov    %rdi,%r9
    eb1a:	4c 89 d8             	mov    %r11,%rax
    eb1d:	4d 85 db             	test   %r11,%r11
    eb20:	0f 88 1a 01 00 00    	js     ec40 <__divmodti4+0x160>
    eb26:	4c 89 d9             	mov    %r11,%rcx
    eb29:	49 89 f3             	mov    %rsi,%r11
    eb2c:	75 62                	jne    eb90 <__divmodti4+0xb0>
    eb2e:	4d 89 c4             	mov    %r8,%r12
    eb31:	4d 39 d1             	cmp    %r10,%r9
    eb34:	0f 83 46 01 00 00    	jae    ec80 <__divmodti4+0x1a0>
    eb3a:	4c 89 d8             	mov    %r11,%rax
    eb3d:	4c 89 ca             	mov    %r9,%rdx
    eb40:	49 f7 f2             	div    %r10
    eb43:	49 89 c3             	mov    %rax,%r11
    eb46:	31 c0                	xor    %eax,%eax
    eb48:	48 89 d6             	mov    %rdx,%rsi
    eb4b:	31 ff                	xor    %edi,%edi
    eb4d:	4c 89 d9             	mov    %r11,%rcx
    eb50:	48 89 c2             	mov    %rax,%rdx
    eb53:	48 89 c8             	mov    %rcx,%rax
    eb56:	4d 85 e4             	test   %r12,%r12
    eb59:	74 0a                	je     eb65 <__divmodti4+0x85>
    eb5b:	48 f7 d8             	neg    %rax
    eb5e:	48 83 d2 00          	adc    $0x0,%rdx
    eb62:	48 f7 da             	neg    %rdx
    eb65:	4d 85 c0             	test   %r8,%r8
    eb68:	74 0a                	je     eb74 <__divmodti4+0x94>
    eb6a:	48 f7 de             	neg    %rsi
    eb6d:	48 83 d7 00          	adc    $0x0,%rdi
    eb71:	48 f7 df             	neg    %rdi
    eb74:	48 89 33             	mov    %rsi,(%rbx)
    eb77:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    eb7b:	5b                   	pop    %rbx
    eb7c:	41 5c                	pop    %r12
    eb7e:	41 5d                	pop    %r13
    eb80:	41 5e                	pop    %r14
    eb82:	41 5f                	pop    %r15
    eb84:	5d                   	pop    %rbp
    eb85:	c3                   	ret
    eb86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    eb8d:	00 00 00 
    eb90:	4d 89 c4             	mov    %r8,%r12
    eb93:	49 39 c1             	cmp    %rax,%r9
    eb96:	0f 82 ce 00 00 00    	jb     ec6a <__divmodti4+0x18a>
    eb9c:	31 ff                	xor    %edi,%edi
    eb9e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    eba3:	48 63 c7             	movslq %edi,%rax
    eba6:	be 40 00 00 00       	mov    $0x40,%esi
    ebab:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    ebb0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    ebb5:	48 29 c6             	sub    %rax,%rsi
    ebb8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    ebbd:	48 09 c8             	or     %rcx,%rax
    ebc0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    ebc5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ebca:	49 89 c6             	mov    %rax,%r14
    ebcd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ebd1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    ebd6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    ebdb:	49 09 c1             	or     %rax,%r9
    ebde:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    ebe2:	4c 89 c8             	mov    %r9,%rax
    ebe5:	49 f7 f6             	div    %r14
    ebe8:	48 89 d1             	mov    %rdx,%rcx
    ebeb:	49 89 c3             	mov    %rax,%r11
    ebee:	49 89 c1             	mov    %rax,%r9
    ebf1:	49 f7 e2             	mul    %r10
    ebf4:	49 89 c6             	mov    %rax,%r14
    ebf7:	49 89 d2             	mov    %rdx,%r10
    ebfa:	48 39 d1             	cmp    %rdx,%rcx
    ebfd:	72 07                	jb     ec06 <__divmodti4+0x126>
    ebff:	75 17                	jne    ec18 <__divmodti4+0x138>
    ec01:	49 39 c7             	cmp    %rax,%r15
    ec04:	73 12                	jae    ec18 <__divmodti4+0x138>
    ec06:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    ec0a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    ec0e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    ec12:	49 89 d2             	mov    %rdx,%r10
    ec15:	49 89 c6             	mov    %rax,%r14
    ec18:	4c 89 f8             	mov    %r15,%rax
    ec1b:	4c 29 f0             	sub    %r14,%rax
    ec1e:	4c 19 d1             	sbb    %r10,%rcx
    ec21:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ec26:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ec2b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ec30:	48 09 c6             	or     %rax,%rsi
    ec33:	48 89 cf             	mov    %rcx,%rdi
    ec36:	31 c0                	xor    %eax,%eax
    ec38:	4c 89 c9             	mov    %r9,%rcx
    ec3b:	e9 10 ff ff ff       	jmp    eb50 <__divmodti4+0x70>
    ec40:	4c 89 d0             	mov    %r10,%rax
    ec43:	4c 89 da             	mov    %r11,%rdx
    ec46:	4d 89 c4             	mov    %r8,%r12
    ec49:	49 89 f3             	mov    %rsi,%r11
    ec4c:	48 f7 d8             	neg    %rax
    ec4f:	49 f7 d4             	not    %r12
    ec52:	48 83 d2 00          	adc    $0x0,%rdx
    ec56:	49 89 c2             	mov    %rax,%r10
    ec59:	48 f7 da             	neg    %rdx
    ec5c:	48 89 d1             	mov    %rdx,%rcx
    ec5f:	0f 84 cc fe ff ff    	je     eb31 <__divmodti4+0x51>
    ec65:	49 39 d1             	cmp    %rdx,%r9
    ec68:	73 46                	jae    ecb0 <__divmodti4+0x1d0>
    ec6a:	4c 89 cf             	mov    %r9,%rdi
    ec6d:	31 c0                	xor    %eax,%eax
    ec6f:	31 c9                	xor    %ecx,%ecx
    ec71:	e9 da fe ff ff       	jmp    eb50 <__divmodti4+0x70>
    ec76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ec7d:	00 00 00 
    ec80:	4d 85 d2             	test   %r10,%r10
    ec83:	75 0d                	jne    ec92 <__divmodti4+0x1b2>
    ec85:	b8 01 00 00 00       	mov    $0x1,%eax
    ec8a:	31 d2                	xor    %edx,%edx
    ec8c:	49 f7 f2             	div    %r10
    ec8f:	49 89 c2             	mov    %rax,%r10
    ec92:	4c 89 c8             	mov    %r9,%rax
    ec95:	31 d2                	xor    %edx,%edx
    ec97:	49 f7 f2             	div    %r10
    ec9a:	49 89 c1             	mov    %rax,%r9
    ec9d:	4c 89 d8             	mov    %r11,%rax
    eca0:	49 f7 f2             	div    %r10
    eca3:	49 89 c3             	mov    %rax,%r11
    eca6:	4c 89 c8             	mov    %r9,%rax
    eca9:	e9 9a fe ff ff       	jmp    eb48 <__divmodti4+0x68>
    ecae:	66 90                	xchg   %ax,%ax
    ecb0:	45 31 f6             	xor    %r14d,%r14d
    ecb3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    ecb8:	44 89 f7             	mov    %r14d,%edi
    ecbb:	45 85 f6             	test   %r14d,%r14d
    ecbe:	0f 85 df fe ff ff    	jne    eba3 <__divmodti4+0xc3>
    ecc4:	4c 39 ca             	cmp    %r9,%rdx
    ecc7:	72 17                	jb     ece0 <__divmodti4+0x200>
    ecc9:	31 c9                	xor    %ecx,%ecx
    eccb:	48 39 c6             	cmp    %rax,%rsi
    ecce:	73 10                	jae    ece0 <__divmodti4+0x200>
    ecd0:	4c 89 cf             	mov    %r9,%rdi
    ecd3:	31 c0                	xor    %eax,%eax
    ecd5:	e9 76 fe ff ff       	jmp    eb50 <__divmodti4+0x70>
    ecda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ece0:	4c 89 de             	mov    %r11,%rsi
    ece3:	b9 01 00 00 00       	mov    $0x1,%ecx
    ece8:	48 29 c6             	sub    %rax,%rsi
    eceb:	49 19 d1             	sbb    %rdx,%r9
    ecee:	eb e0                	jmp    ecd0 <__divmodti4+0x1f0>

000000000000ecf0 <atexit>:
    ecf0:	f3 0f 1e fa          	endbr64
    ecf4:	48 8b 15 0d 43 00 00 	mov    0x430d(%rip),%rdx        # 13008 <__dso_handle>
    ecfb:	31 f6                	xor    %esi,%esi
    ecfd:	e9 5e 49 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ed04 <_fini>:
    ed04:	f3 0f 1e fa          	endbr64
    ed08:	48 83 ec 08          	sub    $0x8,%rsp
    ed0c:	48 83 c4 08          	add    $0x8,%rsp
    ed10:	c3                   	ret
