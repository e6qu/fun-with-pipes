
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 ff 00 00 	mov    0xffd1(%rip),%rax        # 12fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 fd 00 00    	push   0xfdf2(%rip)        # 12e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 fd 00 00    	jmp    *0xfdf4(%rip)        # 12e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 fc 00 00    	jmp    *0xfc66(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e fa 00 00    	jmp    *0xfa8e(%rip)        # 12e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 fa 00 00    	jmp    *0xfa86(%rip)        # 12e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e fa 00 00    	jmp    *0xfa7e(%rip)        # 12e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 fa 00 00    	jmp    *0xfa76(%rip)        # 12e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 b9 00 00 	lea    0xb9b8(%rip),%r9        # f0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 b9 00 00 	lea    0xb9b5(%rip),%r8        # f0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 61 fc ff ff       	call   33c0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 db 00 00 	lea    0xdba1(%rip),%rax        # 11320 <fwp_fn_table>
    377f:	48 89 05 f2 9c 06 00 	mov    %rax,0x69cf2(%rip)        # 6d478 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 9c 06 00 	mov    %rax,0x69cec(%rip)        # 6d480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e bb 00 00 	lea    0xbb4e(%rip),%rdi        # f2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ff a6 00 00 	lea    0xa6ff(%rip),%rdx        # df60 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe b9 00 00 	lea    0xb9fe(%rip),%rdi        # f2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 c3 00 00 	lea    0xc356(%rip),%rdi        # fc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 10 c3 00 00 	lea    0xc310(%rip),%rdi        # fc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 c2 00 00 	lea    0xc2d4(%rip),%rdi        # fc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 c2 00 00 	lea    0xc2a0(%rip),%rdi        # fbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b f6 00 00    	call   *0xf65b(%rip)        # 12fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e f6 00 00 	mov    0xf63e(%rip),%rax        # 12fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d f6 00 00 	mov    0xf60d(%rip),%rax        # 12fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea f5 00 00 	cmpq   $0x0,0xf5ea(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 f5 04 00 	lea    0x4f597(%rip),%r8        # 531a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b f5 04 00 	lea    0x4f53b(%rip),%rcx        # 53160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f f5 04 00 	lea    0x4f50f(%rip),%rcx        # 53140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 f5 04 00 	lea    0x4f541(%rip),%rcx        # 53180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 f5 04 	movdqa 0x4f550(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 f5 04 	paddq  0x4f538(%rip),%xmm0        # 531a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f f4 04 00 	cmp    %rax,0x4f49f(%rip)        # 53120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 f4 04 	movq   %xmm0,0x4f495(%rip)        # 53120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e f4 01 00 	add    0x1f43e(%rip),%rdx        # 230f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c f4 01 00 	add    0x1f42c(%rip),%rax        # 230f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 97 06 00 	mov    0x69779(%rip),%rdi        # 6d480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 f3 00 00 	mov    0xf304(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 f2 00 00 	mov    0xf2f1(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 7a 06 00 	mov    0x67ab1(%rip),%rax        # 6b800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 73 06 00 	mov    0x673f9(%rip),%rax        # 6b1c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 73 06 00 	sub    0x673e5(%rip),%rax        # 6b1c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d bf 00 00 	lea    0xbf2d(%rip),%rsi        # fd40 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 b1 00 00 	lea    0xb1c5(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 f1 00 00 	mov    0xf1f2(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 8d 06 00 	mov    0x68d8b(%rip),%rax        # 6cc10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 8d 06 00 	lea    0x68d84(%rip),%r8        # 6cc10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 8d 06 00 	mov    0x68d65(%rip),%rbx        # 6cbf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 8d 06 00 	mov    0x68d75(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 8d 06 00 	mov    0x68d11(%rip),%rdi        # 6cc00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 8d 06 00 	sub    %rsi,0x68d5a(%rip)        # 6cc50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 8c 06 00 	mov    0x68cea(%rip),%rax        # 6cbf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 8c 06 00 	add    0x68ca0(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 8c 06 00 	mov    0x68cae(%rip),%rsi        # 6cc00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 8c 06 00 	mov    0x68cbc(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 8c 06 00 	mov    %r12,0x68c6b(%rip)        # 6cc00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 8c 06 00 	mov    %rbp,0x68c59(%rip)        # 6cbf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 8c 06 00 	cmp    %rdi,0x68c3e(%rip)        # 6cbe8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 8c 06 00 	mov    %rdi,0x68c35(%rip)        # 6cbe8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 8c 06 00 	sub    %rdi,0x68c79(%rip)        # 6cc50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 8c 06 00 	mov    0x68c21(%rip),%rax        # 6cc08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 8c 06 00 	lea    0x68c1a(%rip),%r8        # 6cc08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff b6 00 00 	lea    0xb6ff(%rip),%rdx        # f708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 f0 00 00 	mov    0xf022(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d ef 00 00 	mov    0xef7d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 af 00 00 	lea    0xaf34(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 76 06 00 	cmp    0x676c9(%rip),%rdi        # 6b800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 76 06 00 	mov    0x6768f(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 76 06 00 	mov    %rdi,0x6766d(%rip)        # 6b7e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 76 06 00 	mov    %rdi,0x67649(%rip)        # 6b7e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 b0 00 00 	lea    0xb019(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 ae 00 00 	lea    0xae27(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 ef 04 	movdqa 0x4ef76(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e ef 04 	paddq  0x4ef5e(%rip),%xmm0        # 531a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 ee 01 00 	mov    0x1ee84(%rip),%r8        # 230f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e ee 04 00 	mov    0x4ee9e(%rip),%rcx        # 53120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 ed 00 00 	mov    0xedb7(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 b4 00 00 	lea    0xb4c5(%rip),%rdx        # f758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 ee 04 00 	lea    0x4eee1(%rip),%r15        # 53180 <ad_raw_peak>
    429f:	4c 8d 35 9a ee 04 00 	lea    0x4ee9a(%rip),%r14        # 53140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 ad 00 00 	lea    0xad79(%rip),%rax        # f02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 e9 00 	movq   0xe956(%rip),%xmm0        # 12c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f ee 04 00 	lea    0x4ee9f(%rip),%r13        # 53160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f ad 00 00 	lea    0xad6f(%rip),%rax        # f03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 e9 00 	movq   0xe936(%rip),%xmm0        # 12c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 ed 00 00 	mov    0xed33(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c ad 00 00 	lea    0xad0c(%rip),%rcx        # f020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d b4 00 00 	lea    0xb49d(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 ed 00 00 	mov    0xed04(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 ac 00 00 	lea    0xacf8(%rip),%rdi        # f045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 ed 01 00 	cmpq   $0x0,0x1eda6(%rip)        # 23100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd ed 01 00 	mov    0x1edbd(%rip),%r8        # 23120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be ed 01 00 	mov    0x1edbe(%rip),%r9        # 23128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af ed 01 00 	lea    0x1edaf(%rip),%rbx        # 23120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 ac 00 00 	lea    0xacf4(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 ed 01 00 	mov    0x1edb1(%rip),%rax        # 23130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a ac 00 00 	lea    0xac9a(%rip),%r12        # f020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 ec 00 00 	mov    0xec89(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 b4 00 00 	lea    0xb439(%rip),%rdx        # f7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 ed 01 00 	cmp    0x1ed33(%rip),%rbp        # 23100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 ec 00 00 	mov    0xec58(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b ac 00 00 	lea    0xac5b(%rip),%rdi        # f059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 ec 00 00 	mov    0xec23(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 b3 00 00 	lea    0xb394(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 ac 00 00 	lea    0xac40(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea b2 00 00 	lea    0xb2ea(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 eb 00 00 	mov    0xebc8(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df ab 00 00 	lea    0xabdf(%rip),%rdx        # f05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 eb 00 00 	mov    0xebb0(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ea 00 00 	mov    0xeac1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 aa 00 00 	lea    0xaa78(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 aa 00 00 	lea    0xaac0(%rip),%rdi        # f06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 aa 00 00 	lea    0xaa48(%rip),%rdi        # f087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 b1 00 00 	lea    0xb1e8(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 b7 00 	movdqa 0xb720(%rip),%xmm0        # fd90 <msg.4+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 8d 06 00 	add    0x68daa(%rip),%rax        # 6d478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c b1 00 00 	lea    0xb13c(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 e9 01 00 	cmp    %rax,0x1e9a5(%rip)        # 230e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 e9 01 00 	add    0x1e9a0(%rip),%rax        # 230f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 b1 00 00 	lea    0xb125(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 a9 00 00 	lea    0xa920(%rip),%r8        # f0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 a7 00 00 	lea    0xa775(%rip),%r8        # f0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 a6 00 00 	lea    0xa612(%rip),%r8        # f0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea a3 00 00 	lea    0xa3ea(%rip),%rdi        # f0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 7e 06 00 	mov    0x67e85(%rip),%r9        # 6cbe8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 7e 06 00 	mov    0x67ede(%rip),%r8        # 6cc48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f ab 00 00 	lea    0xab6f(%rip),%rdx        # f8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 7e 06 00 	mov    0x67ec6(%rip),%rcx        # 6cc40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 7e 06 	movsd  0x67ed4(%rip),%xmm1        # 6cc60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 7e 06 	movsd  0x67ec4(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 e2 00 00 	mov    0xe2a5(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 af 00 	movdqa 0xafc8(%rip),%xmm0        # fda0 <msg.4+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 79 06 00 	lea    0x6797f(%rip),%rax        # 6c760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 af 00 	movdqa 0xaff1(%rip),%xmm2        # fde0 <msg.4+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 79 06 00 	movaps %xmm0,0x67925(%rip)        # 6c720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad af 00 	movdqa 0xafad(%rip),%xmm0        # fdb0 <msg.4+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 7d 06 00 01 	movl   $0x1,0x67db3(%rip)        # 6cbc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 79 06 00 	movaps %xmm0,0x67913(%rip)        # 6c730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b af 00 	movdqa 0xaf9b(%rip),%xmm0        # fdc0 <msg.4+0x80>
    4e24:	00 
    4e25:	0f 29 05 14 79 06 00 	movaps %xmm0,0x67914(%rip)        # 6c740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c af 00 	movdqa 0xaf9c(%rip),%xmm0        # fdd0 <msg.4+0x90>
    4e33:	00 
    4e34:	0f 29 05 15 79 06 00 	movaps %xmm0,0x67915(%rip)        # 6c750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 69 06 00 	lea    0x66995(%rip),%r8        # 6b820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 7c 06 00 	mov    %rax,0x67cb0(%rip)        # 6cbd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 7c 06 00 	mov    %r12,0x67c8e(%rip)        # 6cbe0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 7c 06 00 	mov    %rax,0x67c77(%rip)        # 6cbd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 7c 06 00 	mov    %rbx,0x67c90(%rip)        # 6cbf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 7c 06 00 	mov    %rsi,0x67cb9(%rip)        # 6cc20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 a1 00 00 	lea    0xa174(%rip),%rdi        # f0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 7c 06 00 	mov    %rax,0x67c98(%rip)        # 6cc18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 7c 06 00    	mov    %eax,0x67c1c(%rip)        # 6cbc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 68 06 00 	mov    0x6680c(%rip),%r8        # 6b7e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 67 06 00 	mov    %rbx,0x6673c(%rip)        # 6b7e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 67 06 00 	mov    %r8,0x66728(%rip)        # 6b7e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 e0 04 00 	lea    0x4e0e9(%rip),%rcx        # 531c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 e0 04 00 	lea    0x4e098(%rip),%rcx        # 531a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 9f 00 00 	lea    0x9fc2(%rip),%rdi        # f0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 e0 04 00 	lea    0x4e016(%rip),%r12        # 531c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 9e 00 00 	lea    0x9ee8(%rip),%rax        # f112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 9e 00 00 	lea    0x9ecc(%rip),%rdx        # f0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 9f 00 00 	lea    0x9f04(%rip),%rdi        # f148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 9e 00 00 	lea    0x9edd(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 9e 00 00 	lea    0x9eaa(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae dd 01 00 	lea    0x1ddae(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 dd 01 00 	movaps %xmm0,0x1dd96(%rip)        # 230a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 dd 01 00 	mov    %rsi,0x1dd72(%rip)        # 23088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 dd 01 00 	movaps %xmm0,0x1dd93(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 dd 01 00 	movaps %xmm0,0x1dd97(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 dd 01 00 	mov    %rax,0x1dd98(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 9e 00 00 	lea    0x9e09(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d dd 01 00 	mov    0x1dd1d(%rip),%rsi        # 23088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d dd 01 00 	imul   $0x68,0x1dd6d(%rip),%rdx        # 230e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 de 04 00 	cmp    0x4de26(%rip),%rdx        # 531a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 de 04 00 	mov    0x4de25(%rip),%rax        # 531a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f de 04 00 	add    0x4de1f(%rip),%rax        # 531b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 de 04 00 	add    0x4de20(%rip),%rax        # 531b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c dd 01 00 	mov    0x1dd5c(%rip),%rcx        # 23100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 dd 01 00 	mov    %rdi,0x1dd45(%rip)        # 23100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 dd 01 00 	lea    0x1dd57(%rip),%rcx        # 23120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 72 a5 00 00 	lea    0xa572(%rip),%rdi        # f968 <_IO_stdin_used+0x968>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 9d 00 00 	lea    0x9d6f(%rip),%rdi        # f171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 63 06 00 	mov    0x663a7(%rip),%rbx        # 6b7d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a db 00 00 	mov    0xdb0a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 5b a4 00 00 	lea    0xa45b(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 62 06 00 	mov    0x6626d(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 62 06 00 	mov    %rdx,0x66247(%rip)        # 6b7e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 61 06 00 	mov    0x66194(%rip),%rbx        # 6b7d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 61 06 00 	mov    %rbx,0x66151(%rip)        # 6b7d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 61 06 00 	mov    %rdx,0x66151(%rip)        # 6b7e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 61 06 00 	lea    0x66166(%rip),%rsi        # 6b820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 7c 06 00 	addq   $0x1,0x67ce5(%rip)        # 6d468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 2f a2 00 00 	lea    0xa22f(%rip),%rdi        # f9c8 <_IO_stdin_used+0x9c8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 40 a2 00 00 	lea    0xa240(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 99 00 00 	lea    0x99d2(%rip),%rdi        # f18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 60 06 00 	lea    0x6601e(%rip),%rcx        # 6b820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 7c 06 00 	subq   $0x1,0x67c1f(%rip)        # 6d468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 9b a1 00 00 	lea    0xa19b(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 7c 06 00 	cmpq   $0x0,0x67c00(%rip)        # 6d468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 7b 06 00 	sub    %rax,0x67b55(%rip)        # 6d470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 7b 06 00 	add    %r12,0x67b33(%rip)        # 6d470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 72 06 00 	mov    0x6728f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 5e 06 00 	lea    0x65e8c(%rip),%rax        # 6b820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 71 06 00 	add    0x671e3(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 71 06 00 	mov    0x671b0(%rip),%rsi        # 6cbd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 71 06 00 	mov    0x671d1(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 71 06 00 	add    0x671c5(%rip),%r8        # 6cc18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 71 06 	addsd  0x6718d(%rip),%xmm0        # 6cc60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 5d 06 00 	lea    0x65d42(%rip),%rax        # 6b820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 71 06 00 	sub    %rdi,0x6714c(%rip)        # 6cc40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 71 06 	movsd  %xmm0,0x67164(%rip)        # 6cc60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 71 06 00 	sub    %rdx,0x6711e(%rip)        # 6cc40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 71 06 	addsd  0x67124(%rip),%xmm0        # 6cc60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 71 06 	movsd  %xmm0,0x67118(%rip)        # 6cc60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 70 06 00 	mov    0x670af(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 70 06 00 	add    %rcx,0x670a9(%rip)        # 6cc50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 70 06 00 	cmp    0x67062(%rip),%r9        # 6cc10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 70 06 00 	mov    %r9,0x67059(%rip)        # 6cc10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 70 06 00 	cmp    0x6704a(%rip),%r9        # 6cc08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 70 06 00 	mov    %r9,0x6703d(%rip)        # 6cc08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 6f 06 00 	add    0x66f53(%rip),%rdi        # 6cc18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 5b 06 00 	lea    0x65b30(%rip),%r15        # 6b820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 6e 06 00 	add    0x66ea0(%rip),%r12        # 6cbd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 6e 06 00 	add    0x66ef9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 6e 06 00 	cmp    %rax,0x66ef8(%rip)        # 6cc48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 6e 06 00 	mov    %rax,0x66ee9(%rip)        # 6cc40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 6e 06 00 	mov    %rax,0x66ee8(%rip)        # 6cc48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 6e 06 	addsd  0x66ee4(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 6e 06 	movsd  %xmm0,0x66edc(%rip)        # 6cc58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 6e 06 00    	mov    0x66e23(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 5a 06 00 	lea    0x65a5f(%rip),%rdi        # 6b820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 6e 06 00 	add    0x66e18(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 6e 06 00 	cmp    %rax,0x66e13(%rip)        # 6cc48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 6e 06 00 	mov    %rax,0x66e04(%rip)        # 6cc40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 6e 06 00 	mov    %rax,0x66e03(%rip)        # 6cc48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 6d 06 	addsd  0x66dff(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 6d 06 	movsd  %xmm0,0x66df7(%rip)        # 6cc58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 75 06 00    	mov    0x675ca(%rip),%ebx        # 6d4e8 <iteration_active>
    5f1e:	8b 05 a0 6c 06 00    	mov    0x66ca0(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 58 06 00 	lea    0x658d4(%rip),%rax        # 6b820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 6c 06 00 	add    0x66c8e(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 6c 06 00 	cmp    %rax,0x66c89(%rip)        # 6cc48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 6c 06 00 	mov    %rax,0x66c7a(%rip)        # 6cc40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 6c 06 00 	mov    %rax,0x66c79(%rip)        # 6cc48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 6c 06 	addsd  0x66c78(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 6c 06 	movsd  %xmm0,0x66c70(%rip)        # 6cc58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 6c 06 00 	mov    0x66c4d(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 74 06 	subsd  0x674bb(%rip),%xmm0        # 6d4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 74 06 	comisd 0x674ab(%rip),%xmm0        # 6d4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 74 06 	movsd  %xmm0,0x674a1(%rip)        # 6d4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 74 06 00 	addq   $0x1,0x674a4(%rip)        # 6d4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 74 06 00 	add    %rdi,0x67495(%rip)        # 6d4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_data.part.0.constprop.0>:
    6100:	41 56                	push   %r14
    6102:	8b 05 bc 6a 06 00    	mov    0x66abc(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    6108:	41 89 fe             	mov    %edi,%r14d
    610b:	41 55                	push   %r13
    610d:	44 8b 2d d4 73 06 00 	mov    0x673d4(%rip),%r13d        # 6d4e8 <iteration_active>
    6114:	41 54                	push   %r12
    6116:	49 89 f4             	mov    %rsi,%r12
    6119:	55                   	push   %rbp
    611a:	53                   	push   %rbx
    611b:	45 85 ed             	test   %r13d,%r13d
    611e:	0f 84 1c 01 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x140>
    6124:	48 83 05 b4 73 06 00 	addq   $0x1,0x673b4(%rip)        # 6d4e0 <iteration_requests>
    612b:	01 
    612c:	48 83 05 a4 73 06 00 	addq   $0x18,0x673a4(%rip)        # 6d4d8 <iteration_bytes>
    6133:	18 
    6134:	85 c0                	test   %eax,%eax
    6136:	0f 84 8c 01 00 00    	je     62c8 <fwp_data.part.0.constprop.0+0x1c8>
    613c:	0f b6 05 7f 66 06 00 	movzbl 0x6667f(%rip),%eax        # 6c7c2 <fwp_heap+0xfa2>
    6143:	48 8d 15 d6 56 06 00 	lea    0x656d6(%rip),%rdx        # 6b820 <fwp_heap>
    614a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6151:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6155:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6159:	48 8b 18             	mov    (%rax),%rbx
    615c:	48 85 db             	test   %rbx,%rbx
    615f:	0f 84 fb 00 00 00    	je     6260 <fwp_data.part.0.constprop.0+0x160>
    6165:	48 8b 13             	mov    (%rbx),%rdx
    6168:	48 f7 d2             	not    %rdx
    616b:	48 89 10             	mov    %rdx,(%rax)
    616e:	48 83 fd 18          	cmp    $0x18,%rbp
    6172:	76 1b                	jbe    618f <fwp_data.part.0.constprop.0+0x8f>
    6174:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6178:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    617c:	31 f6                	xor    %esi,%esi
    617e:	48 c1 e8 03          	shr    $0x3,%rax
    6182:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6189:	00 
    618a:	e8 21 d3 ff ff       	call   34b0 <memset@plt>
    618f:	48 89 e8             	mov    %rbp,%rax
    6192:	48 03 05 a7 6a 06 00 	add    0x66aa7(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    6199:	0f 82 3d 01 00 00    	jb     62dc <fwp_data.part.0.constprop.0+0x1dc>
    619f:	48 39 05 a2 6a 06 00 	cmp    %rax,0x66aa2(%rip)        # 6cc48 <fwp_heap+0x1428>
    61a6:	48 89 05 93 6a 06 00 	mov    %rax,0x66a93(%rip)        # 6cc40 <fwp_heap+0x1420>
    61ad:	73 07                	jae    61b6 <fwp_data.part.0.constprop.0+0xb6>
    61af:	48 89 05 92 6a 06 00 	mov    %rax,0x66a92(%rip)        # 6cc48 <fwp_heap+0x1428>
    61b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61ba:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    61bf:	f2 0f 58 05 91 6a 06 	addsd  0x66a91(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    61c6:	00 
    61c7:	f2 0f 11 05 89 6a 06 	movsd  %xmm0,0x66a89(%rip)        # 6cc58 <fwp_heap+0x1438>
    61ce:	00 
    61cf:	45 85 ed             	test   %r13d,%r13d
    61d2:	74 33                	je     6207 <fwp_data.part.0.constprop.0+0x107>
    61d4:	48 8b 05 65 6a 06 00 	mov    0x66a65(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    61db:	48 85 c0             	test   %rax,%rax
    61de:	0f 88 a4 00 00 00    	js     6288 <fwp_data.part.0.constprop.0+0x188>
    61e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61e8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61ed:	f2 0f 5c 05 d3 72 06 	subsd  0x672d3(%rip),%xmm0        # 6d4c8 <iteration_start_charge>
    61f4:	00 
    61f5:	66 0f 2f 05 c3 72 06 	comisd 0x672c3(%rip),%xmm0        # 6d4c0 <iteration_peak>
    61fc:	00 
    61fd:	76 08                	jbe    6207 <fwp_data.part.0.constprop.0+0x107>
    61ff:	f2 0f 11 05 b9 72 06 	movsd  %xmm0,0x672b9(%rip)        # 6d4c0 <iteration_peak>
    6206:	00 
    6207:	b8 02 00 00 00       	mov    $0x2,%eax
    620c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6211:	66 0f 6e c8          	movd   %eax,%xmm1
    6215:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6219:	66 0f d6 03          	movq   %xmm0,(%rbx)
    621d:	49 8b 04 24          	mov    (%r12),%rax
    6221:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6225:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    622a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    622e:	48 89 d8             	mov    %rbx,%rax
    6231:	5b                   	pop    %rbx
    6232:	5d                   	pop    %rbp
    6233:	41 5c                	pop    %r12
    6235:	41 5d                	pop    %r13
    6237:	41 5e                	pop    %r14
    6239:	c3                   	ret
    623a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6240:	85 c0                	test   %eax,%eax
    6242:	0f 85 f4 fe ff ff    	jne    613c <fwp_data.part.0.constprop.0+0x3c>
    6248:	31 f6                	xor    %esi,%esi
    624a:	bf 18 00 00 00       	mov    $0x18,%edi
    624f:	e8 bc fc ff ff       	call   5f10 <fwp_heap_alloc>
    6254:	48 89 c3             	mov    %rax,%rbx
    6257:	eb ae                	jmp    6207 <fwp_data.part.0.constprop.0+0x107>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6260:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6264:	48 85 db             	test   %rbx,%rbx
    6267:	74 47                	je     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6269:	48 8b 50 10          	mov    0x10(%rax),%rdx
    626d:	48 29 da             	sub    %rbx,%rdx
    6270:	48 39 ea             	cmp    %rbp,%rdx
    6273:	72 3b                	jb     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6275:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    627d:	e9 ec fe ff ff       	jmp    616e <fwp_data.part.0.constprop.0+0x6e>
    6282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6288:	48 89 c2             	mov    %rax,%rdx
    628b:	83 e0 01             	and    $0x1,%eax
    628e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6292:	48 d1 ea             	shr    $1,%rdx
    6295:	48 09 c2             	or     %rax,%rdx
    6298:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    629d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    62a1:	e9 47 ff ff ff       	jmp    61ed <fwp_data.part.0.constprop.0+0xed>
    62a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ad:	00 00 00 
    62b0:	31 f6                	xor    %esi,%esi
    62b2:	bf 18 00 00 00       	mov    $0x18,%edi
    62b7:	e8 54 fc ff ff       	call   5f10 <fwp_heap_alloc>
    62bc:	48 89 c3             	mov    %rax,%rbx
    62bf:	e9 0b ff ff ff       	jmp    61cf <fwp_data.part.0.constprop.0+0xcf>
    62c4:	0f 1f 40 00          	nopl   0x0(%rax)
    62c8:	31 f6                	xor    %esi,%esi
    62ca:	bf 18 00 00 00       	mov    $0x18,%edi
    62cf:	e8 3c fc ff ff       	call   5f10 <fwp_heap_alloc>
    62d4:	48 89 c3             	mov    %rax,%rbx
    62d7:	e9 f8 fe ff ff       	jmp    61d4 <fwp_data.part.0.constprop.0+0xd4>
    62dc:	e8 4f db ff ff       	call   3e30 <fwp_heap_oom>
    62e1:	0f 1f 40 00          	nopl   0x0(%rax)
    62e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62ec:	00 00 00 00 

00000000000062f0 <fwp_p_ad_push>:
    62f0:	41 57                	push   %r15
    62f2:	41 56                	push   %r14
    62f4:	41 55                	push   %r13
    62f6:	49 89 d5             	mov    %rdx,%r13
    62f9:	41 54                	push   %r12
    62fb:	49 89 fc             	mov    %rdi,%r12
    62fe:	55                   	push   %rbp
    62ff:	53                   	push   %rbx
    6300:	48 83 ec 48          	sub    $0x48,%rsp
    6304:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6309:	48 85 ff             	test   %rdi,%rdi
    630c:	79 09                	jns    6317 <fwp_p_ad_push+0x27>
    630e:	48 85 d2             	test   %rdx,%rdx
    6311:	0f 88 b9 02 00 00    	js     65d0 <fwp_p_ad_push+0x2e0>
    6317:	48 89 f8             	mov    %rdi,%rax
    631a:	48 89 0c 24          	mov    %rcx,(%rsp)
    631e:	4c 89 c5             	mov    %r8,%rbp
    6321:	48 09 d0             	or     %rdx,%rax
    6324:	0f 89 86 02 00 00    	jns    65b0 <fwp_p_ad_push+0x2c0>
    632a:	48 85 ff             	test   %rdi,%rdi
    632d:	0f 89 df 03 00 00    	jns    6712 <fwp_p_ad_push+0x422>
    6333:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6338:	49 89 d6             	mov    %rdx,%r14
    633b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6342:	00 
    6343:	49 89 d4             	mov    %rdx,%r12
    6346:	49 c1 fe 20          	sar    $0x20,%r14
    634a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6351:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6357:	48 85 ed             	test   %rbp,%rbp
    635a:	0f 84 40 03 00 00    	je     66a0 <fwp_p_ad_push+0x3b0>
    6360:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    6364:	0f 84 be 02 00 00    	je     6628 <fwp_p_ad_push+0x338>
    636a:	4c 89 f7             	mov    %r14,%rdi
    636d:	e8 be e3 ff ff       	call   4730 <fwp_tape_of>
    6372:	48 89 c3             	mov    %rax,%rbx
    6375:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    637a:	0f 85 36 03 00 00    	jne    66b6 <fwp_p_ad_push+0x3c6>
    6380:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    6384:	48 89 45 08          	mov    %rax,0x8(%rbp)
    6388:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    638c:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6393:	0f 8f bc 03 00 00    	jg     6755 <fwp_p_ad_push+0x465>
    6399:	44 89 e0             	mov    %r12d,%eax
    639c:	4c 39 f8             	cmp    %r15,%rax
    639f:	0f 8d a4 03 00 00    	jge    6749 <fwp_p_ad_push+0x459>
    63a5:	4d 85 ed             	test   %r13,%r13
    63a8:	78 0c                	js     63b6 <fwp_p_ad_push+0xc6>
    63aa:	44 89 e8             	mov    %r13d,%eax
    63ad:	4c 39 f8             	cmp    %r15,%rax
    63b0:	0f 8d 93 03 00 00    	jge    6749 <fwp_p_ad_push+0x459>
    63b6:	4d 89 fe             	mov    %r15,%r14
    63b9:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    63bd:	49 8d 46 01          	lea    0x1(%r14),%rax
    63c1:	4c 89 f1             	mov    %r14,%rcx
    63c4:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    63ca:	0f 87 85 03 00 00    	ja     6755 <fwp_p_ad_push+0x465>
    63d0:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    63d4:	48 39 e8             	cmp    %rbp,%rax
    63d7:	0f 8e 23 02 00 00    	jle    6600 <fwp_p_ad_push+0x310>
    63dd:	48 85 ed             	test   %rbp,%rbp
    63e0:	ba 40 00 00 00       	mov    $0x40,%edx
    63e5:	48 0f 44 ea          	cmove  %rdx,%rbp
    63e9:	48 39 e8             	cmp    %rbp,%rax
    63ec:	7e 22                	jle    6410 <fwp_p_ad_push+0x120>
    63ee:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    63f5:	0f 8f f5 01 00 00    	jg     65f0 <fwp_p_ad_push+0x300>
    63fb:	48 01 ed             	add    %rbp,%rbp
    63fe:	48 39 e8             	cmp    %rbp,%rax
    6401:	7f eb                	jg     63ee <fwp_p_ad_push+0xfe>
    6403:	66 90                	xchg   %ax,%ax
    6405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    640c:	00 00 00 00 
    6410:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6417:	00 
    6418:	4c 8b 43 60          	mov    0x60(%rbx),%r8
    641c:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6420:	ba 01 00 00 00       	mov    $0x1,%edx
    6425:	48 89 c6             	mov    %rax,%rsi
    6428:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    642d:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6432:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6437:	e8 54 ed ff ff       	call   5190 <ad_raw_realloc>
    643c:	48 85 c0             	test   %rax,%rax
    643f:	0f 84 1c 03 00 00    	je     6761 <fwp_p_ad_push+0x471>
    6445:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6449:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    644e:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6452:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6457:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    645b:	4d 85 c0             	test   %r8,%r8
    645e:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    6462:	0f 84 d0 01 00 00    	je     6638 <fwp_p_ad_push+0x348>
    6468:	49 8b 50 60          	mov    0x60(%r8),%rdx
    646c:	48 39 ea             	cmp    %rbp,%rdx
    646f:	0f 8d bb 00 00 00    	jge    6530 <fwp_p_ad_push+0x240>
    6475:	49 8b 70 40          	mov    0x40(%r8),%rsi
    6479:	48 89 ef             	mov    %rbp,%rdi
    647c:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6481:	48 c1 e7 04          	shl    $0x4,%rdi
    6485:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    648a:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    648f:	be 02 00 00 00       	mov    $0x2,%esi
    6494:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    6499:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    649e:	e8 6d fa ff ff       	call   5f10 <fwp_heap_alloc>
    64a3:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    64a8:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    64ad:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    64b2:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    64b7:	48 85 f6             	test   %rsi,%rsi
    64ba:	74 31                	je     64ed <fwp_p_ad_push+0x1fd>
    64bc:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    64c1:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    64c6:	48 c1 e2 04          	shl    $0x4,%rdx
    64ca:	48 39 fa             	cmp    %rdi,%rdx
    64cd:	48 0f 47 d7          	cmova  %rdi,%rdx
    64d1:	48 89 c7             	mov    %rax,%rdi
    64d4:	e8 a7 d0 ff ff       	call   3580 <memcpy@plt>
    64d9:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    64de:	e8 2d f5 ff ff       	call   5a10 <fwp_mem_free>
    64e3:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    64e8:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    64ed:	49 8b 78 60          	mov    0x60(%r8),%rdi
    64f1:	48 89 ea             	mov    %rbp,%rdx
    64f4:	31 f6                	xor    %esi,%esi
    64f6:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    64fb:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6500:	48 29 fa             	sub    %rdi,%rdx
    6503:	48 c1 e7 04          	shl    $0x4,%rdi
    6507:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    650c:	48 c1 e2 04          	shl    $0x4,%rdx
    6510:	e8 9b cf ff ff       	call   34b0 <memset@plt>
    6515:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    651a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    651f:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6524:	49 89 68 60          	mov    %rbp,0x60(%r8)
    6528:	49 89 40 40          	mov    %rax,0x40(%r8)
    652c:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6530:	4d 85 f6             	test   %r14,%r14
    6533:	0f 85 8f 01 00 00    	jne    66c8 <fwp_p_ad_push+0x3d8>
    6539:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    653d:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6541:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6548:	00 
    6549:	31 d2                	xor    %edx,%edx
    654b:	49 01 c6             	add    %rax,%r14
    654e:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    6552:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    6556:	44 89 24 10          	mov    %r12d,(%rax,%rdx,1)
    655a:	4d 85 ed             	test   %r13,%r13
    655d:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6563:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    656a:	4c 0f 48 e8          	cmovs  %rax,%r13
    656e:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6573:	49 8d 47 01          	lea    0x1(%r15),%rax
    6577:	f2 0f 11 0c 0e       	movsd  %xmm1,(%rsi,%rcx,1)
    657c:	45 89 2c 16          	mov    %r13d,(%r14,%rdx,1)
    6580:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    6585:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6589:	48 83 c4 48          	add    $0x48,%rsp
    658d:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6594:	ff ff ff 
    6597:	4c 21 e0             	and    %r12,%rax
    659a:	5b                   	pop    %rbx
    659b:	5d                   	pop    %rbp
    659c:	4c 09 f8             	or     %r15,%rax
    659f:	41 5c                	pop    %r12
    65a1:	41 5d                	pop    %r13
    65a3:	41 5e                	pop    %r14
    65a5:	41 5f                	pop    %r15
    65a7:	c3                   	ret
    65a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    65af:	00 
    65b0:	48 c1 fa 20          	sar    $0x20,%rdx
    65b4:	48 c1 ff 20          	sar    $0x20,%rdi
    65b8:	49 89 d6             	mov    %rdx,%r14
    65bb:	48 39 d7             	cmp    %rdx,%rdi
    65be:	0f 84 93 fd ff ff    	je     6357 <fwp_p_ad_push+0x67>
    65c4:	48 8d 3d 4d 94 00 00 	lea    0x944d(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    65cb:	e8 80 de ff ff       	call   4450 <fwp_trap>
    65d0:	48 83 c4 48          	add    $0x48,%rsp
    65d4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    65db:	5b                   	pop    %rbx
    65dc:	5d                   	pop    %rbp
    65dd:	41 5c                	pop    %r12
    65df:	41 5d                	pop    %r13
    65e1:	41 5e                	pop    %r14
    65e3:	41 5f                	pop    %r15
    65e5:	c3                   	ret
    65e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65ed:	00 00 00 
    65f0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    65f5:	e9 16 fe ff ff       	jmp    6410 <fwp_p_ad_push+0x120>
    65fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6600:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    6607:	00 
    6608:	48 8b 43 20          	mov    0x20(%rbx),%rax
    660c:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    6610:	48 c1 e1 03          	shl    $0x3,%rcx
    6614:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6618:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    661c:	e9 35 ff ff ff       	jmp    6556 <fwp_p_ad_push+0x266>
    6621:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6628:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    662c:	e9 57 fd ff ff       	jmp    6388 <fwp_p_ad_push+0x98>
    6631:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6638:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    663c:	48 89 ee             	mov    %rbp,%rsi
    663f:	ba 02 00 00 00       	mov    $0x2,%edx
    6644:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6649:	48 c1 e6 04          	shl    $0x4,%rsi
    664d:	e8 3e eb ff ff       	call   5190 <ad_raw_realloc>
    6652:	48 89 c6             	mov    %rax,%rsi
    6655:	48 85 c0             	test   %rax,%rax
    6658:	0f 84 03 01 00 00    	je     6761 <fwp_p_ad_push+0x471>
    665e:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6662:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6666:	4d 85 f6             	test   %r14,%r14
    6669:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    666e:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    6672:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    6676:	48 89 43 38          	mov    %rax,0x38(%rbx)
    667a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    667f:	0f 85 99 00 00 00    	jne    671e <fwp_p_ad_push+0x42e>
    6685:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6689:	48 8b 43 20          	mov    0x20(%rbx),%rax
    668d:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6694:	00 
    6695:	31 d2                	xor    %edx,%edx
    6697:	e9 af fe ff ff       	jmp    654b <fwp_p_ad_push+0x25b>
    669c:	0f 1f 40 00          	nopl   0x0(%rax)
    66a0:	4c 89 f7             	mov    %r14,%rdi
    66a3:	e8 88 e0 ff ff       	call   4730 <fwp_tape_of>
    66a8:	48 89 c3             	mov    %rax,%rbx
    66ab:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    66b0:	0f 84 d2 fc ff ff    	je     6388 <fwp_p_ad_push+0x98>
    66b6:	48 8d 3d a3 93 00 00 	lea    0x93a3(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    66bd:	e8 8e dd ff ff       	call   4450 <fwp_trap>
    66c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66c8:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    66cf:	00 
    66d0:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    66d5:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    66dc:	00 
    66dd:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    66e1:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    66e8:	00 
    66e9:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    66ed:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    66f2:	e8 f9 ce ff ff       	call   35f0 <memmove@plt>
    66f7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    66fb:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    66ff:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6703:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6708:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    670d:	e9 39 fe ff ff       	jmp    654b <fwp_p_ad_push+0x25b>
    6712:	48 c1 ff 20          	sar    $0x20,%rdi
    6716:	49 89 fe             	mov    %rdi,%r14
    6719:	e9 39 fc ff ff       	jmp    6357 <fwp_p_ad_push+0x67>
    671e:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    6725:	00 
    6726:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    672b:	48 89 f2             	mov    %rsi,%rdx
    672e:	48 89 c6             	mov    %rax,%rsi
    6731:	e8 ba ce ff ff       	call   35f0 <memmove@plt>
    6736:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    673b:	48 03 43 30          	add    0x30(%rbx),%rax
    673f:	48 89 43 38          	mov    %rax,0x38(%rbx)
    6743:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6747:	eb 8c                	jmp    66d5 <fwp_p_ad_push+0x3e5>
    6749:	48 8d 3d 72 8a 00 00 	lea    0x8a72(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    6750:	e8 fb dc ff ff       	call   4450 <fwp_trap>
    6755:	48 8d 3d 4b 8a 00 00 	lea    0x8a4b(%rip),%rdi        # f1a7 <_IO_stdin_used+0x1a7>
    675c:	e8 ef dc ff ff       	call   4450 <fwp_trap>
    6761:	48 89 df             	mov    %rbx,%rdi
    6764:	e8 27 d5 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6769:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    676d:	48 85 ff             	test   %rdi,%rdi
    6770:	74 05                	je     6777 <fwp_p_ad_push+0x487>
    6772:	e8 59 e9 ff ff       	call   50d0 <ad_raw_free.part.0>
    6777:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    677b:	48 85 ff             	test   %rdi,%rdi
    677e:	74 05                	je     6785 <fwp_p_ad_push+0x495>
    6780:	e8 4b e9 ff ff       	call   50d0 <ad_raw_free.part.0>
    6785:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6789:	48 85 ff             	test   %rdi,%rdi
    678c:	74 05                	je     6793 <fwp_p_ad_push+0x4a3>
    678e:	e8 3d e9 ff ff       	call   50d0 <ad_raw_free.part.0>
    6793:	31 c9                	xor    %ecx,%ecx
    6795:	31 c0                	xor    %eax,%eax
    6797:	31 d2                	xor    %edx,%edx
    6799:	be 01 00 00 00       	mov    $0x1,%esi
    679e:	89 53 04             	mov    %edx,0x4(%rbx)
    67a1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67a5:	ba 13 00 00 00       	mov    $0x13,%edx
    67aa:	48 8d 3d 57 88 00 00 	lea    0x8857(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    67b1:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    67b5:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    67b9:	48 8b 0d 80 c8 00 00 	mov    0xc880(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    67c0:	48 89 43 40          	mov    %rax,0x40(%rbx)
    67c4:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    67c8:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    67cc:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    67d0:	e8 8b ce ff ff       	call   3660 <fwrite@plt>
    67d5:	31 ff                	xor    %edi,%edi
    67d7:	e8 c4 cd ff ff       	call   35a0 <fflush@plt>
    67dc:	bf 66 00 00 00       	mov    $0x66,%edi
    67e1:	e8 9a ce ff ff       	call   3680 <_Exit@plt>
    67e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67ed:	00 00 00 

00000000000067f0 <w120>:
    67f0:	41 56                	push   %r14
    67f2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    67f6:	48 89 fa             	mov    %rdi,%rdx
    67f9:	41 55                	push   %r13
    67fb:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    67ff:	49 89 fd             	mov    %rdi,%r13
    6802:	41 54                	push   %r12
    6804:	55                   	push   %rbp
    6805:	53                   	push   %rbx
    6806:	48 83 ec 40          	sub    $0x40,%rsp
    680a:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6810:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6815:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    681c:	00 00 
    681e:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    6823:	48 89 f5             	mov    %rsi,%rbp
    6826:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    682b:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6831:	48 89 f1             	mov    %rsi,%rcx
    6834:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    683a:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    6841:	ff ff 
    6843:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    684a:	00 00 
    684c:	e8 9f fa ff ff       	call   62f0 <fwp_p_ad_push>
    6851:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6857:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    685c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6862:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6869:	00 f0 3f 
    686c:	48 89 c7             	mov    %rax,%rdi
    686f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6876:	00 f0 bf 
    6879:	48 89 ea             	mov    %rbp,%rdx
    687c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6881:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6887:	e8 64 fa ff ff       	call   62f0 <fwp_p_ad_push>
    688c:	f2 0f 10 05 d4 94 00 	movsd  0x94d4(%rip),%xmm0        # fd68 <msg.4+0x28>
    6893:	00 
    6894:	4c 89 ef             	mov    %r13,%rdi
    6897:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    689d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    68a2:	49 89 c6             	mov    %rax,%r14
    68a5:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    68ac:	00 f0 3f 
    68af:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    68b6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    68bd:	00 f0 bf 
    68c0:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    68c5:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    68cb:	e8 20 fa ff ff       	call   62f0 <fwp_p_ad_push>
    68d0:	4c 89 e1             	mov    %r12,%rcx
    68d3:	4c 89 e6             	mov    %r12,%rsi
    68d6:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    68db:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    68e1:	4c 89 f2             	mov    %r14,%rdx
    68e4:	4c 89 f7             	mov    %r14,%rdi
    68e7:	49 89 c5             	mov    %rax,%r13
    68ea:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    68ee:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    68f4:	e8 f7 f9 ff ff       	call   62f0 <fwp_p_ad_push>
    68f9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    68ff:	f2 0f 59 1d 69 94 00 	mulsd  0x9469(%rip),%xmm3        # fd70 <msg.4+0x30>
    6906:	00 
    6907:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    690c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6911:	48 89 c2             	mov    %rax,%rdx
    6914:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    691b:	00 59 40 
    691e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6925:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    692b:	e8 c0 f9 ff ff       	call   62f0 <fwp_p_ad_push>
    6930:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6935:	48 89 e9             	mov    %rbp,%rcx
    6938:	4c 89 ea             	mov    %r13,%rdx
    693b:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6941:	48 89 ee             	mov    %rbp,%rsi
    6944:	4c 89 ef             	mov    %r13,%rdi
    6947:	49 89 c4             	mov    %rax,%r12
    694a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    694e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6954:	e8 97 f9 ff ff       	call   62f0 <fwp_p_ad_push>
    6959:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    695f:	45 31 c0             	xor    %r8d,%r8d
    6962:	4c 89 e2             	mov    %r12,%rdx
    6965:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    696b:	48 89 c7             	mov    %rax,%rdi
    696e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6975:	00 f0 3f 
    6978:	48 89 ce             	mov    %rcx,%rsi
    697b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6980:	e8 6b f9 ff ff       	call   62f0 <fwp_p_ad_push>
    6985:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    698a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6991:	00 00 
    6993:	75 12                	jne    69a7 <w120+0x1b7>
    6995:	48 83 c4 40          	add    $0x40,%rsp
    6999:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    699e:	5b                   	pop    %rbx
    699f:	5d                   	pop    %rbp
    69a0:	41 5c                	pop    %r12
    69a2:	41 5d                	pop    %r13
    69a4:	41 5e                	pop    %r14
    69a6:	c3                   	ret
    69a7:	e8 a4 ca ff ff       	call   3450 <__stack_chk_fail@plt>
    69ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000069b0 <w176.constprop.0>:
    69b0:	41 54                	push   %r12
    69b2:	55                   	push   %rbp
    69b3:	53                   	push   %rbx
    69b4:	48 83 ec 10          	sub    $0x10,%rsp
    69b8:	4c 8b 27             	mov    (%rdi),%r12
    69bb:	4d 85 e4             	test   %r12,%r12
    69be:	74 58                	je     6a18 <w176.constprop.0+0x68>
    69c0:	48 89 fd             	mov    %rdi,%rbp
    69c3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69c7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    69ce:	31 db                	xor    %ebx,%ebx
    69d0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    69d6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    69db:	45 31 c0             	xor    %r8d,%r8d
    69de:	48 83 c3 02          	add    $0x2,%rbx
    69e2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    69e9:	00 f0 3f 
    69ec:	48 89 ce             	mov    %rcx,%rsi
    69ef:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    69f5:	e8 f6 f8 ff ff       	call   62f0 <fwp_p_ad_push>
    69fa:	4c 39 e3             	cmp    %r12,%rbx
    69fd:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6a03:	48 89 c7             	mov    %rax,%rdi
    6a06:	72 c8                	jb     69d0 <w176.constprop.0+0x20>
    6a08:	48 83 c4 10          	add    $0x10,%rsp
    6a0c:	48 89 f8             	mov    %rdi,%rax
    6a0f:	5b                   	pop    %rbx
    6a10:	5d                   	pop    %rbp
    6a11:	41 5c                	pop    %r12
    6a13:	c3                   	ret
    6a14:	0f 1f 40 00          	nopl   0x0(%rax)
    6a18:	48 83 c4 10          	add    $0x10,%rsp
    6a1c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6a23:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a27:	5b                   	pop    %rbx
    6a28:	48 89 f8             	mov    %rdi,%rax
    6a2b:	5d                   	pop    %rbp
    6a2c:	41 5c                	pop    %r12
    6a2e:	c3                   	ret
    6a2f:	90                   	nop

0000000000006a30 <fwp_rc_share>:
    6a30:	48 8b 05 c1 61 06 00 	mov    0x661c1(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    6a37:	48 2b 3d 92 61 06 00 	sub    0x66192(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    6a3e:	48 c1 e0 10          	shl    $0x10,%rax
    6a42:	48 39 c7             	cmp    %rax,%rdi
    6a45:	73 4a                	jae    6a91 <fwp_rc_share+0x61>
    6a47:	48 89 f8             	mov    %rdi,%rax
    6a4a:	48 c1 e8 10          	shr    $0x10,%rax
    6a4e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a52:	48 8b 05 bf 61 06 00 	mov    0x661bf(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    6a59:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6a5d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6a61:	48 85 d2             	test   %rdx,%rdx
    6a64:	74 2b                	je     6a91 <fwp_rc_share+0x61>
    6a66:	0f b6 08             	movzbl (%rax),%ecx
    6a69:	80 f9 02             	cmp    $0x2,%cl
    6a6c:	74 2a                	je     6a98 <fwp_rc_share+0x68>
    6a6e:	80 f9 01             	cmp    $0x1,%cl
    6a71:	75 1e                	jne    6a91 <fwp_rc_share+0x61>
    6a73:	8b 48 18             	mov    0x18(%rax),%ecx
    6a76:	0f b7 ff             	movzwl %di,%edi
    6a79:	8b 40 1c             	mov    0x1c(%rax),%eax
    6a7c:	48 0f af f9          	imul   %rcx,%rdi
    6a80:	48 c1 ef 20          	shr    $0x20,%rdi
    6a84:	48 39 c7             	cmp    %rax,%rdi
    6a87:	73 08                	jae    6a91 <fwp_rc_share+0x61>
    6a89:	48 01 fa             	add    %rdi,%rdx
    6a8c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6a8f:	75 0d                	jne    6a9e <fwp_rc_share+0x6e>
    6a91:	c3                   	ret
    6a92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a98:	66 85 ff             	test   %di,%di
    6a9b:	74 ef                	je     6a8c <fwp_rc_share+0x5c>
    6a9d:	c3                   	ret
    6a9e:	50                   	push   %rax
    6a9f:	48 8d 3d ea 8f 00 00 	lea    0x8fea(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    6aa6:	e8 a5 d9 ff ff       	call   4450 <fwp_trap>
    6aab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006ab0 <fwp_rc_fresh>:
    6ab0:	48 8b 15 41 61 06 00 	mov    0x66141(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6ab7:	48 89 f8             	mov    %rdi,%rax
    6aba:	48 89 fe             	mov    %rdi,%rsi
    6abd:	48 2b 05 0c 61 06 00 	sub    0x6610c(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6ac4:	48 c1 e2 10          	shl    $0x10,%rdx
    6ac8:	48 39 d0             	cmp    %rdx,%rax
    6acb:	73 4f                	jae    6b1c <fwp_rc_fresh+0x6c>
    6acd:	48 89 c2             	mov    %rax,%rdx
    6ad0:	48 c1 ea 10          	shr    $0x10,%rdx
    6ad4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ad8:	48 8b 15 39 61 06 00 	mov    0x66139(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6adf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ae3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ae7:	48 85 d2             	test   %rdx,%rdx
    6aea:	74 30                	je     6b1c <fwp_rc_fresh+0x6c>
    6aec:	0f b6 39             	movzbl (%rcx),%edi
    6aef:	40 80 ff 02          	cmp    $0x2,%dil
    6af3:	74 2b                	je     6b20 <fwp_rc_fresh+0x70>
    6af5:	40 80 ff 01          	cmp    $0x1,%dil
    6af9:	75 21                	jne    6b1c <fwp_rc_fresh+0x6c>
    6afb:	8b 79 18             	mov    0x18(%rcx),%edi
    6afe:	0f b7 c0             	movzwl %ax,%eax
    6b01:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b04:	48 0f af c7          	imul   %rdi,%rax
    6b08:	48 c1 e8 20          	shr    $0x20,%rax
    6b0c:	48 39 c8             	cmp    %rcx,%rax
    6b0f:	73 0b                	jae    6b1c <fwp_rc_fresh+0x6c>
    6b11:	48 01 c2             	add    %rax,%rdx
    6b14:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b17:	74 17                	je     6b30 <fwp_rc_fresh+0x80>
    6b19:	c6 02 01             	movb   $0x1,(%rdx)
    6b1c:	48 89 f0             	mov    %rsi,%rax
    6b1f:	c3                   	ret
    6b20:	66 85 c0             	test   %ax,%ax
    6b23:	74 ef                	je     6b14 <fwp_rc_fresh+0x64>
    6b25:	48 89 f0             	mov    %rsi,%rax
    6b28:	c3                   	ret
    6b29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b30:	48 83 ec 18          	sub    $0x18,%rsp
    6b34:	48 89 d7             	mov    %rdx,%rdi
    6b37:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b3c:	48 89 14 24          	mov    %rdx,(%rsp)
    6b40:	e8 8b ec ff ff       	call   57d0 <fwp_rc_forget_slot>
    6b45:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6b4a:	48 8b 14 24          	mov    (%rsp),%rdx
    6b4e:	48 89 f0             	mov    %rsi,%rax
    6b51:	c6 02 01             	movb   $0x1,(%rdx)
    6b54:	48 83 c4 18          	add    $0x18,%rsp
    6b58:	c3                   	ret
    6b59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006b60 <fwp_rc_free_obj>:
    6b60:	48 8b 15 91 60 06 00 	mov    0x66091(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6b67:	48 89 f8             	mov    %rdi,%rax
    6b6a:	48 2b 05 5f 60 06 00 	sub    0x6605f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6b71:	48 c1 e2 10          	shl    $0x10,%rdx
    6b75:	48 39 d0             	cmp    %rdx,%rax
    6b78:	73 5b                	jae    6bd5 <fwp_rc_free_obj+0x75>
    6b7a:	48 89 c2             	mov    %rax,%rdx
    6b7d:	48 c1 ea 10          	shr    $0x10,%rdx
    6b81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b85:	48 8b 15 8c 60 06 00 	mov    0x6608c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6b8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6b90:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6b94:	48 85 c9             	test   %rcx,%rcx
    6b97:	74 3c                	je     6bd5 <fwp_rc_free_obj+0x75>
    6b99:	0f b6 32             	movzbl (%rdx),%esi
    6b9c:	40 80 fe 02          	cmp    $0x2,%sil
    6ba0:	74 2e                	je     6bd0 <fwp_rc_free_obj+0x70>
    6ba2:	40 80 fe 01          	cmp    $0x1,%sil
    6ba6:	75 2d                	jne    6bd5 <fwp_rc_free_obj+0x75>
    6ba8:	8b 72 18             	mov    0x18(%rdx),%esi
    6bab:	0f b7 c0             	movzwl %ax,%eax
    6bae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6bb1:	48 0f af c6          	imul   %rsi,%rax
    6bb5:	48 c1 e8 20          	shr    $0x20,%rax
    6bb9:	48 39 d0             	cmp    %rdx,%rax
    6bbc:	73 17                	jae    6bd5 <fwp_rc_free_obj+0x75>
    6bbe:	48 01 c1             	add    %rax,%rcx
    6bc1:	80 39 01             	cmpb   $0x1,(%rcx)
    6bc4:	75 0f                	jne    6bd5 <fwp_rc_free_obj+0x75>
    6bc6:	e9 45 ee ff ff       	jmp    5a10 <fwp_mem_free>
    6bcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6bd0:	66 85 c0             	test   %ax,%ax
    6bd3:	74 ec                	je     6bc1 <fwp_rc_free_obj+0x61>
    6bd5:	c3                   	ret
    6bd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bdd:	00 00 00 

0000000000006be0 <fwp_rc_dup>:
    6be0:	f3 0f 1e fa          	endbr64
    6be4:	48 8b 05 0d 60 06 00 	mov    0x6600d(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    6beb:	48 2b 3d de 5f 06 00 	sub    0x65fde(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    6bf2:	48 c1 e0 10          	shl    $0x10,%rax
    6bf6:	48 39 c7             	cmp    %rax,%rdi
    6bf9:	73 60                	jae    6c5b <fwp_rc_dup+0x7b>
    6bfb:	48 89 f8             	mov    %rdi,%rax
    6bfe:	48 c1 e8 10          	shr    $0x10,%rax
    6c02:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6c06:	48 8b 05 0b 60 06 00 	mov    0x6600b(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    6c0d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6c11:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6c15:	48 85 c0             	test   %rax,%rax
    6c18:	74 41                	je     6c5b <fwp_rc_dup+0x7b>
    6c1a:	0f b6 0a             	movzbl (%rdx),%ecx
    6c1d:	80 f9 02             	cmp    $0x2,%cl
    6c20:	74 3e                	je     6c60 <fwp_rc_dup+0x80>
    6c22:	80 f9 01             	cmp    $0x1,%cl
    6c25:	75 34                	jne    6c5b <fwp_rc_dup+0x7b>
    6c27:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6c2a:	0f b7 ff             	movzwl %di,%edi
    6c2d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c30:	48 0f af f9          	imul   %rcx,%rdi
    6c34:	48 c1 ef 20          	shr    $0x20,%rdi
    6c38:	48 39 d7             	cmp    %rdx,%rdi
    6c3b:	73 1e                	jae    6c5b <fwp_rc_dup+0x7b>
    6c3d:	48 01 f8             	add    %rdi,%rax
    6c40:	0f b6 10             	movzbl (%rax),%edx
    6c43:	84 d2                	test   %dl,%dl
    6c45:	74 14                	je     6c5b <fwp_rc_dup+0x7b>
    6c47:	8b 0d 9b 68 06 00    	mov    0x6689b(%rip),%ecx        # 6d4e8 <iteration_active>
    6c4d:	85 c9                	test   %ecx,%ecx
    6c4f:	75 1f                	jne    6c70 <fwp_rc_dup+0x90>
    6c51:	80 fa fd             	cmp    $0xfd,%dl
    6c54:	77 2a                	ja     6c80 <fwp_rc_dup+0xa0>
    6c56:	83 c2 01             	add    $0x1,%edx
    6c59:	88 10                	mov    %dl,(%rax)
    6c5b:	c3                   	ret
    6c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    6c60:	66 85 ff             	test   %di,%di
    6c63:	74 db                	je     6c40 <fwp_rc_dup+0x60>
    6c65:	c3                   	ret
    6c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c6d:	00 00 00 
    6c70:	48 83 05 58 68 06 00 	addq   $0x1,0x66858(%rip)        # 6d4d0 <iteration_retains>
    6c77:	01 
    6c78:	eb d7                	jmp    6c51 <fwp_rc_dup+0x71>
    6c7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c80:	48 89 c7             	mov    %rax,%rdi
    6c83:	e9 28 ea ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6c88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c8f:	00 

0000000000006c90 <fwp_owned_entry173>:
    6c90:	f3 0f 1e fa          	endbr64
    6c94:	48 83 ec 38          	sub    $0x38,%rsp
    6c98:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6c9d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ca4:	00 00 
    6ca6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6cab:	31 c0                	xor    %eax,%eax
    6cad:	48 8b 07             	mov    (%rdi),%rax
    6cb0:	48 03 47 10          	add    0x10(%rdi),%rax
    6cb4:	0f 80 c2 00 00 00    	jo     6d7c <fwp_owned_entry173+0xec>
    6cba:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6cbf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6cc4:	31 ff                	xor    %edi,%edi
    6cc6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6cca:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ccf:	e8 2c f4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6cd4:	48 8b 15 1d 5f 06 00 	mov    0x65f1d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6cdb:	48 89 c6             	mov    %rax,%rsi
    6cde:	48 2b 05 eb 5e 06 00 	sub    0x65eeb(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6ce5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ce9:	48 39 d0             	cmp    %rdx,%rax
    6cec:	73 4f                	jae    6d3d <fwp_owned_entry173+0xad>
    6cee:	48 89 c2             	mov    %rax,%rdx
    6cf1:	48 c1 ea 10          	shr    $0x10,%rdx
    6cf5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cf9:	48 8b 15 18 5f 06 00 	mov    0x65f18(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6d00:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d04:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d08:	48 85 d2             	test   %rdx,%rdx
    6d0b:	74 30                	je     6d3d <fwp_owned_entry173+0xad>
    6d0d:	0f b6 39             	movzbl (%rcx),%edi
    6d10:	40 80 ff 02          	cmp    $0x2,%dil
    6d14:	74 42                	je     6d58 <fwp_owned_entry173+0xc8>
    6d16:	40 80 ff 01          	cmp    $0x1,%dil
    6d1a:	75 21                	jne    6d3d <fwp_owned_entry173+0xad>
    6d1c:	8b 79 18             	mov    0x18(%rcx),%edi
    6d1f:	0f b7 c0             	movzwl %ax,%eax
    6d22:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d25:	48 0f af c7          	imul   %rdi,%rax
    6d29:	48 c1 e8 20          	shr    $0x20,%rax
    6d2d:	48 39 c8             	cmp    %rcx,%rax
    6d30:	73 0b                	jae    6d3d <fwp_owned_entry173+0xad>
    6d32:	48 01 c2             	add    %rax,%rdx
    6d35:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d38:	74 26                	je     6d60 <fwp_owned_entry173+0xd0>
    6d3a:	c6 02 01             	movb   $0x1,(%rdx)
    6d3d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6d42:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d49:	00 00 
    6d4b:	75 34                	jne    6d81 <fwp_owned_entry173+0xf1>
    6d4d:	48 89 f0             	mov    %rsi,%rax
    6d50:	48 83 c4 38          	add    $0x38,%rsp
    6d54:	c3                   	ret
    6d55:	0f 1f 00             	nopl   (%rax)
    6d58:	66 85 c0             	test   %ax,%ax
    6d5b:	75 e0                	jne    6d3d <fwp_owned_entry173+0xad>
    6d5d:	eb d6                	jmp    6d35 <fwp_owned_entry173+0xa5>
    6d5f:	90                   	nop
    6d60:	48 89 d7             	mov    %rdx,%rdi
    6d63:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6d68:	48 89 14 24          	mov    %rdx,(%rsp)
    6d6c:	e8 5f ea ff ff       	call   57d0 <fwp_rc_forget_slot>
    6d71:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6d76:	48 8b 14 24          	mov    (%rsp),%rdx
    6d7a:	eb be                	jmp    6d3a <fwp_owned_entry173+0xaa>
    6d7c:	e8 7f c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6d81:	e8 ca c6 ff ff       	call   3450 <__stack_chk_fail@plt>
    6d86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d8d:	00 00 00 

0000000000006d90 <e173>:
    6d90:	f3 0f 1e fa          	endbr64
    6d94:	53                   	push   %rbx
    6d95:	48 83 ec 30          	sub    $0x30,%rsp
    6d99:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6d9e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6da5:	00 00 
    6da7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6dac:	31 c0                	xor    %eax,%eax
    6dae:	48 8b 07             	mov    (%rdi),%rax
    6db1:	48 03 47 10          	add    0x10(%rdi),%rax
    6db5:	0f 80 c9 00 00 00    	jo     6e84 <e173+0xf4>
    6dbb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6dc0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6dc5:	31 ff                	xor    %edi,%edi
    6dc7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6dcb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6dd0:	e8 2b f3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6dd5:	48 8b 15 1c 5e 06 00 	mov    0x65e1c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6ddc:	48 89 c3             	mov    %rax,%rbx
    6ddf:	48 2b 05 ea 5d 06 00 	sub    0x65dea(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6de6:	48 c1 e2 10          	shl    $0x10,%rdx
    6dea:	48 39 d0             	cmp    %rdx,%rax
    6ded:	73 4f                	jae    6e3e <e173+0xae>
    6def:	48 89 c2             	mov    %rax,%rdx
    6df2:	48 c1 ea 10          	shr    $0x10,%rdx
    6df6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6dfa:	48 8b 15 17 5e 06 00 	mov    0x65e17(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6e01:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e05:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e09:	48 85 d2             	test   %rdx,%rdx
    6e0c:	74 30                	je     6e3e <e173+0xae>
    6e0e:	0f b6 31             	movzbl (%rcx),%esi
    6e11:	40 80 fe 02          	cmp    $0x2,%sil
    6e15:	74 49                	je     6e60 <e173+0xd0>
    6e17:	40 80 fe 01          	cmp    $0x1,%sil
    6e1b:	75 21                	jne    6e3e <e173+0xae>
    6e1d:	8b 71 18             	mov    0x18(%rcx),%esi
    6e20:	0f b7 c0             	movzwl %ax,%eax
    6e23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e26:	48 0f af c6          	imul   %rsi,%rax
    6e2a:	48 c1 e8 20          	shr    $0x20,%rax
    6e2e:	48 39 c8             	cmp    %rcx,%rax
    6e31:	73 0b                	jae    6e3e <e173+0xae>
    6e33:	48 01 c2             	add    %rax,%rdx
    6e36:	80 3a ff             	cmpb   $0xff,(%rdx)
    6e39:	74 35                	je     6e70 <e173+0xe0>
    6e3b:	c6 02 01             	movb   $0x1,(%rdx)
    6e3e:	48 89 df             	mov    %rbx,%rdi
    6e41:	e8 ea fb ff ff       	call   6a30 <fwp_rc_share>
    6e46:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6e4b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e52:	00 00 
    6e54:	75 33                	jne    6e89 <e173+0xf9>
    6e56:	48 83 c4 30          	add    $0x30,%rsp
    6e5a:	48 89 d8             	mov    %rbx,%rax
    6e5d:	5b                   	pop    %rbx
    6e5e:	c3                   	ret
    6e5f:	90                   	nop
    6e60:	66 85 c0             	test   %ax,%ax
    6e63:	75 d9                	jne    6e3e <e173+0xae>
    6e65:	eb cf                	jmp    6e36 <e173+0xa6>
    6e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e6e:	00 00 
    6e70:	48 89 d7             	mov    %rdx,%rdi
    6e73:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e78:	e8 53 e9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6e7d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e82:	eb b7                	jmp    6e3b <e173+0xab>
    6e84:	e8 77 c8 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6e89:	e8 c2 c5 ff ff       	call   3450 <__stack_chk_fail@plt>
    6e8e:	66 90                	xchg   %ax,%ax

0000000000006e90 <fwp_closure_drop>:
    6e90:	48 8b 15 61 5d 06 00 	mov    0x65d61(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6e97:	48 89 f8             	mov    %rdi,%rax
    6e9a:	48 2b 05 2f 5d 06 00 	sub    0x65d2f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6ea1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ea5:	48 39 d0             	cmp    %rdx,%rax
    6ea8:	73 6b                	jae    6f15 <fwp_closure_drop+0x85>
    6eaa:	48 89 c2             	mov    %rax,%rdx
    6ead:	48 c1 ea 10          	shr    $0x10,%rdx
    6eb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6eb5:	48 8b 15 5c 5d 06 00 	mov    0x65d5c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6ebc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ec0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ec4:	48 85 d2             	test   %rdx,%rdx
    6ec7:	74 4c                	je     6f15 <fwp_closure_drop+0x85>
    6ec9:	0f b6 31             	movzbl (%rcx),%esi
    6ecc:	40 80 fe 02          	cmp    $0x2,%sil
    6ed0:	74 3e                	je     6f10 <fwp_closure_drop+0x80>
    6ed2:	40 80 fe 01          	cmp    $0x1,%sil
    6ed6:	75 3d                	jne    6f15 <fwp_closure_drop+0x85>
    6ed8:	8b 71 18             	mov    0x18(%rcx),%esi
    6edb:	0f b7 c0             	movzwl %ax,%eax
    6ede:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ee1:	48 0f af c6          	imul   %rsi,%rax
    6ee5:	48 c1 e8 20          	shr    $0x20,%rax
    6ee9:	48 39 c8             	cmp    %rcx,%rax
    6eec:	73 27                	jae    6f15 <fwp_closure_drop+0x85>
    6eee:	48 01 c2             	add    %rax,%rdx
    6ef1:	0f b6 02             	movzbl (%rdx),%eax
    6ef4:	84 c0                	test   %al,%al
    6ef6:	74 1d                	je     6f15 <fwp_closure_drop+0x85>
    6ef8:	3c 01                	cmp    $0x1,%al
    6efa:	74 24                	je     6f20 <fwp_closure_drop+0x90>
    6efc:	3c ff                	cmp    $0xff,%al
    6efe:	74 48                	je     6f48 <fwp_closure_drop+0xb8>
    6f00:	83 e8 01             	sub    $0x1,%eax
    6f03:	88 02                	mov    %al,(%rdx)
    6f05:	c3                   	ret
    6f06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f0d:	00 00 00 
    6f10:	66 85 c0             	test   %ax,%ax
    6f13:	74 dc                	je     6ef1 <fwp_closure_drop+0x61>
    6f15:	c3                   	ret
    6f16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f1d:	00 00 00 
    6f20:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6f27:	ff ff 
    6f29:	48 85 c0             	test   %rax,%rax
    6f2c:	74 12                	je     6f40 <fwp_closure_drop+0xb0>
    6f2e:	48 89 fe             	mov    %rdi,%rsi
    6f31:	48 89 c7             	mov    %rax,%rdi
    6f34:	e9 77 d5 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    6f39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f40:	e9 1b d7 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    6f45:	0f 1f 00             	nopl   (%rax)
    6f48:	48 89 d0             	mov    %rdx,%rax
    6f4b:	48 8d 35 ce 48 06 00 	lea    0x648ce(%rip),%rsi        # 6b820 <fwp_heap>
    6f52:	48 83 ec 18          	sub    $0x18,%rsp
    6f56:	48 c1 e8 11          	shr    $0x11,%rax
    6f5a:	48 31 d0             	xor    %rdx,%rax
    6f5d:	48 89 c1             	mov    %rax,%rcx
    6f60:	48 c1 e9 09          	shr    $0x9,%rcx
    6f64:	48 31 c8             	xor    %rcx,%rax
    6f67:	0f b6 c8             	movzbl %al,%ecx
    6f6a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6f71:	00 
    6f72:	48 85 c0             	test   %rax,%rax
    6f75:	75 12                	jne    6f89 <fwp_closure_drop+0xf9>
    6f77:	eb 49                	jmp    6fc2 <fwp_closure_drop+0x132>
    6f79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6f84:	48 85 c0             	test   %rax,%rax
    6f87:	74 39                	je     6fc2 <fwp_closure_drop+0x132>
    6f89:	48 89 c1             	mov    %rax,%rcx
    6f8c:	48 39 10             	cmp    %rdx,(%rax)
    6f8f:	75 ef                	jne    6f80 <fwp_closure_drop+0xf0>
    6f91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6f99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6f9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6fa4:	74 05                	je     6fab <fwp_closure_drop+0x11b>
    6fa6:	48 83 c4 18          	add    $0x18,%rsp
    6faa:	c3                   	ret
    6fab:	48 89 d7             	mov    %rdx,%rdi
    6fae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6fb3:	e8 18 e8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6fb8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6fbd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6fc0:	eb e4                	jmp    6fa6 <fwp_closure_drop+0x116>
    6fc2:	48 8d 3d 27 8a 00 00 	lea    0x8a27(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    6fc9:	e8 82 d4 ff ff       	call   4450 <fwp_trap>
    6fce:	66 90                	xchg   %ax,%ax

0000000000006fd0 <fwp_owned_tape_release>:
    6fd0:	48 85 ff             	test   %rdi,%rdi
    6fd3:	0f 84 f7 00 00 00    	je     70d0 <fwp_owned_tape_release+0x100>
    6fd9:	41 54                	push   %r12
    6fdb:	55                   	push   %rbp
    6fdc:	53                   	push   %rbx
    6fdd:	48 8b 07             	mov    (%rdi),%rax
    6fe0:	48 85 c0             	test   %rax,%rax
    6fe3:	74 08                	je     6fed <fwp_owned_tape_release+0x1d>
    6fe5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6fe9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6fed:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6ff1:	48 85 d2             	test   %rdx,%rdx
    6ff4:	74 03                	je     6ff9 <fwp_owned_tape_release+0x29>
    6ff6:	48 89 02             	mov    %rax,(%rdx)
    6ff9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6ffd:	48 89 fb             	mov    %rdi,%rbx
    7000:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7004:	48 85 c0             	test   %rax,%rax
    7007:	0f 84 89 00 00 00    	je     7096 <fwp_owned_tape_release+0xc6>
    700d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7011:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7015:	7e 47                	jle    705e <fwp_owned_tape_release+0x8e>
    7017:	31 ed                	xor    %ebp,%ebp
    7019:	eb 0d                	jmp    7028 <fwp_owned_tape_release+0x58>
    701b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7020:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7024:	48 8b 40 68          	mov    0x68(%rax),%rax
    7028:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    702c:	49 89 ec             	mov    %rbp,%r12
    702f:	48 83 c5 01          	add    $0x1,%rbp
    7033:	49 c1 e4 04          	shl    $0x4,%r12
    7037:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    703b:	ff d0                	call   *%rax
    703d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7041:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7046:	48 8b 43 10          	mov    0x10(%rbx),%rax
    704a:	ff 50 68             	call   *0x68(%rax)
    704d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7051:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7055:	48 39 e8             	cmp    %rbp,%rax
    7058:	7f c6                	jg     7020 <fwp_owned_tape_release+0x50>
    705a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    705e:	31 ed                	xor    %ebp,%ebp
    7060:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7065:	7e 28                	jle    708f <fwp_owned_tape_release+0xbf>
    7067:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    706e:	00 00 
    7070:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7074:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7078:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    707c:	74 07                	je     7085 <fwp_owned_tape_release+0xb5>
    707e:	ff 52 68             	call   *0x68(%rdx)
    7081:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7085:	48 83 c5 01          	add    $0x1,%rbp
    7089:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    708d:	7f e1                	jg     7070 <fwp_owned_tape_release+0xa0>
    708f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7093:	ff 52 68             	call   *0x68(%rdx)
    7096:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    709a:	e8 f1 fd ff ff       	call   6e90 <fwp_closure_drop>
    709f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    70a3:	e8 e8 fd ff ff       	call   6e90 <fwp_closure_drop>
    70a8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    70ac:	e8 df fd ff ff       	call   6e90 <fwp_closure_drop>
    70b1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    70b5:	e8 56 e9 ff ff       	call   5a10 <fwp_mem_free>
    70ba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    70be:	e8 4d e9 ff ff       	call   5a10 <fwp_mem_free>
    70c3:	48 89 df             	mov    %rbx,%rdi
    70c6:	5b                   	pop    %rbx
    70c7:	5d                   	pop    %rbp
    70c8:	41 5c                	pop    %r12
    70ca:	e9 41 e9 ff ff       	jmp    5a10 <fwp_mem_free>
    70cf:	90                   	nop
    70d0:	c3                   	ret
    70d1:	0f 1f 40 00          	nopl   0x0(%rax)
    70d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70dc:	00 00 00 00 

00000000000070e0 <fwp_tape_finish>:
    70e0:	f3 0f 1e fa          	endbr64
    70e4:	41 55                	push   %r13
    70e6:	41 54                	push   %r12
    70e8:	55                   	push   %rbp
    70e9:	53                   	push   %rbx
    70ea:	48 83 ec 48          	sub    $0x48,%rsp
    70ee:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    70f5:	00 00 
    70f7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    70fc:	48 8d 3d 9d bf 01 00 	lea    0x1bf9d(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    7103:	e8 38 e0 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7108:	48 83 3d d8 bf 01 00 	cmpq   $0x0,0x1bfd8(%rip)        # 230e8 <fwp_ntapes>
    710f:	00 
    7110:	48 c7 05 6d bf 01 00 	movq   $0x0,0x1bf6d(%rip)        # 23088 <fwp_tape_cached_bytes>
    7117:	00 00 00 00 
    711b:	7e 79                	jle    7196 <fwp_tape_finish+0xb6>
    711d:	45 31 e4             	xor    %r12d,%r12d
    7120:	31 ed                	xor    %ebp,%ebp
    7122:	0f 1f 00             	nopl   (%rax)
    7125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    712c:	00 00 00 00 
    7130:	48 8b 1d b9 bf 01 00 	mov    0x1bfb9(%rip),%rbx        # 230f0 <fwp_tapes>
    7137:	48 83 c5 01          	add    $0x1,%rbp
    713b:	4c 01 e3             	add    %r12,%rbx
    713e:	49 83 c4 68          	add    $0x68,%r12
    7142:	48 89 df             	mov    %rbx,%rdi
    7145:	e8 46 cb ff ff       	call   3c90 <fwp_tape_unlink_scope>
    714a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    714f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7154:	48 89 e7             	mov    %rsp,%rdi
    7157:	48 8b 43 40          	mov    0x40(%rbx),%rax
    715b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    715f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7164:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7169:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    716e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    7172:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7177:	e8 c4 df ff ff       	call   5140 <fwp_tape_buffers_dispose>
    717c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    7180:	e8 4b fe ff ff       	call   6fd0 <fwp_owned_tape_release>
    7185:	48 39 2d 5c bf 01 00 	cmp    %rbp,0x1bf5c(%rip)        # 230e8 <fwp_ntapes>
    718c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7193:	00 
    7194:	7f 9a                	jg     7130 <fwp_tape_finish+0x50>
    7196:	48 8b 3d 53 bf 01 00 	mov    0x1bf53(%rip),%rdi        # 230f0 <fwp_tapes>
    719d:	48 85 ff             	test   %rdi,%rdi
    71a0:	74 05                	je     71a7 <fwp_tape_finish+0xc7>
    71a2:	e8 29 df ff ff       	call   50d0 <ad_raw_free.part.0>
    71a7:	48 c7 05 3e bf 01 00 	movq   $0x0,0x1bf3e(%rip)        # 230f0 <fwp_tapes>
    71ae:	00 00 00 00 
    71b2:	48 c7 05 23 bf 01 00 	movq   $0x0,0x1bf23(%rip)        # 230e0 <fwp_tapes_cap>
    71b9:	00 00 00 00 
    71bd:	48 c7 05 20 bf 01 00 	movq   $0x0,0x1bf20(%rip)        # 230e8 <fwp_ntapes>
    71c4:	00 00 00 00 
    71c8:	48 c7 05 05 bf 01 00 	movq   $0x0,0x1bf05(%rip)        # 230d8 <fwp_tape_next_slot>
    71cf:	00 00 00 00 
    71d3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    71d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    71df:	00 00 
    71e1:	75 0b                	jne    71ee <fwp_tape_finish+0x10e>
    71e3:	48 83 c4 48          	add    $0x48,%rsp
    71e7:	5b                   	pop    %rbx
    71e8:	5d                   	pop    %rbp
    71e9:	41 5c                	pop    %r12
    71eb:	41 5d                	pop    %r13
    71ed:	c3                   	ret
    71ee:	e8 5d c2 ff ff       	call   3450 <__stack_chk_fail@plt>
    71f3:	66 90                	xchg   %ax,%ax
    71f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71fc:	00 00 00 00 

0000000000007200 <fwp_tape_scope_release>:
    7200:	f3 0f 1e fa          	endbr64
    7204:	41 55                	push   %r13
    7206:	41 54                	push   %r12
    7208:	55                   	push   %rbp
    7209:	53                   	push   %rbx
    720a:	48 83 ec 48          	sub    $0x48,%rsp
    720e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7215:	00 00 
    7217:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    721c:	48 63 07             	movslq (%rdi),%rax
    721f:	85 c0                	test   %eax,%eax
    7221:	0f 88 e8 00 00 00    	js     730f <fwp_tape_scope_release+0x10f>
    7227:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    722e:	ec c4 4e 
    7231:	48 89 fb             	mov    %rdi,%rbx
    7234:	48 89 e5             	mov    %rsp,%rbp
    7237:	eb 1f                	jmp    7258 <fwp_tape_scope_release+0x58>
    7239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7240:	e8 fb de ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7245:	4c 89 ef             	mov    %r13,%rdi
    7248:	e8 83 fd ff ff       	call   6fd0 <fwp_owned_tape_release>
    724d:	48 63 03             	movslq (%rbx),%rax
    7250:	85 c0                	test   %eax,%eax
    7252:	0f 88 b7 00 00 00    	js     730f <fwp_tape_scope_release+0x10f>
    7258:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    725c:	48 8b 35 8d be 01 00 	mov    0x1be8d(%rip),%rsi        # 230f0 <fwp_tapes>
    7263:	4c 01 c6             	add    %r8,%rsi
    7266:	48 89 f7             	mov    %rsi,%rdi
    7269:	e8 22 ca ff ff       	call   3c90 <fwp_tape_unlink_scope>
    726e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7273:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7278:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    727f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7283:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7287:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    728e:	00 
    728f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7294:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7299:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    729d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    72a2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    72a6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    72ab:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    72b2:	00 
    72b3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    72ba:	00 
    72bb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    72c2:	00 
    72c3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    72c7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    72cb:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    72cf:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    72d3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    72d9:	77 18                	ja     72f3 <fwp_tape_scope_release+0xf3>
    72db:	49 c1 f8 03          	sar    $0x3,%r8
    72df:	4d 0f af c4          	imul   %r12,%r8
    72e3:	4c 3b 05 ee bd 01 00 	cmp    0x1bdee(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    72ea:	7d 07                	jge    72f3 <fwp_tape_scope_release+0xf3>
    72ec:	4c 89 05 e5 bd 01 00 	mov    %r8,0x1bde5(%rip)        # 230d8 <fwp_tape_next_slot>
    72f3:	48 89 ef             	mov    %rbp,%rdi
    72f6:	4d 85 ed             	test   %r13,%r13
    72f9:	0f 85 41 ff ff ff    	jne    7240 <fwp_tape_scope_release+0x40>
    72ff:	e8 5c df ff ff       	call   5260 <fwp_tape_buffers_release>
    7304:	48 63 03             	movslq (%rbx),%rax
    7307:	85 c0                	test   %eax,%eax
    7309:	0f 89 49 ff ff ff    	jns    7258 <fwp_tape_scope_release+0x58>
    730f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7314:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    731b:	00 00 
    731d:	75 0b                	jne    732a <fwp_tape_scope_release+0x12a>
    731f:	48 83 c4 48          	add    $0x48,%rsp
    7323:	5b                   	pop    %rbx
    7324:	5d                   	pop    %rbp
    7325:	41 5c                	pop    %r12
    7327:	41 5d                	pop    %r13
    7329:	c3                   	ret
    732a:	e8 21 c1 ff ff       	call   3450 <__stack_chk_fail@plt>
    732f:	90                   	nop

0000000000007330 <fwp_drop4>:
    7330:	48 8b 0d c1 58 06 00 	mov    0x658c1(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    7337:	48 89 f8             	mov    %rdi,%rax
    733a:	48 2b 05 8f 58 06 00 	sub    0x6588f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7341:	48 c1 e1 10          	shl    $0x10,%rcx
    7345:	48 39 c8             	cmp    %rcx,%rax
    7348:	0f 83 42 01 00 00    	jae    7490 <fwp_drop4+0x160>
    734e:	48 83 ec 18          	sub    $0x18,%rsp
    7352:	48 89 fa             	mov    %rdi,%rdx
    7355:	4c 8d 05 c4 44 06 00 	lea    0x644c4(%rip),%r8        # 6b820 <fwp_heap>
    735c:	48 89 c1             	mov    %rax,%rcx
    735f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7366:	48 c1 e9 10          	shr    $0x10,%rcx
    736a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    736e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7372:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7376:	48 85 c9             	test   %rcx,%rcx
    7379:	74 40                	je     73bb <fwp_drop4+0x8b>
    737b:	0f b6 3e             	movzbl (%rsi),%edi
    737e:	40 80 ff 02          	cmp    $0x2,%dil
    7382:	74 3c                	je     73c0 <fwp_drop4+0x90>
    7384:	40 80 ff 01          	cmp    $0x1,%dil
    7388:	75 31                	jne    73bb <fwp_drop4+0x8b>
    738a:	8b 7e 18             	mov    0x18(%rsi),%edi
    738d:	0f b7 c0             	movzwl %ax,%eax
    7390:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7393:	48 0f af c7          	imul   %rdi,%rax
    7397:	48 c1 e8 20          	shr    $0x20,%rax
    739b:	48 39 f0             	cmp    %rsi,%rax
    739e:	73 1b                	jae    73bb <fwp_drop4+0x8b>
    73a0:	48 01 c1             	add    %rax,%rcx
    73a3:	0f b6 01             	movzbl (%rcx),%eax
    73a6:	84 c0                	test   %al,%al
    73a8:	74 11                	je     73bb <fwp_drop4+0x8b>
    73aa:	3c 01                	cmp    $0x1,%al
    73ac:	74 22                	je     73d0 <fwp_drop4+0xa0>
    73ae:	3c ff                	cmp    $0xff,%al
    73b0:	0f 84 0a 01 00 00    	je     74c0 <fwp_drop4+0x190>
    73b6:	83 e8 01             	sub    $0x1,%eax
    73b9:	88 01                	mov    %al,(%rcx)
    73bb:	48 83 c4 18          	add    $0x18,%rsp
    73bf:	c3                   	ret
    73c0:	66 85 c0             	test   %ax,%ax
    73c3:	74 de                	je     73a3 <fwp_drop4+0x73>
    73c5:	48 83 c4 18          	add    $0x18,%rsp
    73c9:	c3                   	ret
    73ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73d0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    73d4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    73db:	48 89 f8             	mov    %rdi,%rax
    73de:	48 c1 e1 10          	shl    $0x10,%rcx
    73e2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    73e9:	48 39 c8             	cmp    %rcx,%rax
    73ec:	73 62                	jae    7450 <fwp_drop4+0x120>
    73ee:	48 89 c1             	mov    %rax,%rcx
    73f1:	48 c1 e9 10          	shr    $0x10,%rcx
    73f5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    73f9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    73fd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7401:	48 85 c9             	test   %rcx,%rcx
    7404:	74 4a                	je     7450 <fwp_drop4+0x120>
    7406:	44 0f b6 0e          	movzbl (%rsi),%r9d
    740a:	41 80 f9 02          	cmp    $0x2,%r9b
    740e:	0f 84 9c 00 00 00    	je     74b0 <fwp_drop4+0x180>
    7414:	41 80 f9 01          	cmp    $0x1,%r9b
    7418:	75 36                	jne    7450 <fwp_drop4+0x120>
    741a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    741e:	0f b7 c0             	movzwl %ax,%eax
    7421:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7424:	49 0f af c1          	imul   %r9,%rax
    7428:	48 c1 e8 20          	shr    $0x20,%rax
    742c:	48 39 f0             	cmp    %rsi,%rax
    742f:	73 1f                	jae    7450 <fwp_drop4+0x120>
    7431:	48 01 c1             	add    %rax,%rcx
    7434:	0f b6 01             	movzbl (%rcx),%eax
    7437:	84 c0                	test   %al,%al
    7439:	74 15                	je     7450 <fwp_drop4+0x120>
    743b:	3c 01                	cmp    $0x1,%al
    743d:	74 59                	je     7498 <fwp_drop4+0x168>
    743f:	3c ff                	cmp    $0xff,%al
    7441:	0f 84 ff 00 00 00    	je     7546 <fwp_drop4+0x216>
    7447:	83 e8 01             	sub    $0x1,%eax
    744a:	88 01                	mov    %al,(%rcx)
    744c:	0f 1f 40 00          	nopl   0x0(%rax)
    7450:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7454:	48 89 d7             	mov    %rdx,%rdi
    7457:	48 89 0c 24          	mov    %rcx,(%rsp)
    745b:	e8 00 f7 ff ff       	call   6b60 <fwp_rc_free_obj>
    7460:	4c 8d 05 b9 43 06 00 	lea    0x643b9(%rip),%r8        # 6b820 <fwp_heap>
    7467:	48 8b 04 24          	mov    (%rsp),%rax
    746b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7472:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7479:	48 c1 e2 10          	shl    $0x10,%rdx
    747d:	48 39 d0             	cmp    %rdx,%rax
    7480:	0f 83 35 ff ff ff    	jae    73bb <fwp_drop4+0x8b>
    7486:	48 8b 14 24          	mov    (%rsp),%rdx
    748a:	e9 cd fe ff ff       	jmp    735c <fwp_drop4+0x2c>
    748f:	90                   	nop
    7490:	c3                   	ret
    7491:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7498:	48 89 14 24          	mov    %rdx,(%rsp)
    749c:	e8 bf f6 ff ff       	call   6b60 <fwp_rc_free_obj>
    74a1:	48 8b 14 24          	mov    (%rsp),%rdx
    74a5:	eb a9                	jmp    7450 <fwp_drop4+0x120>
    74a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    74ae:	00 00 
    74b0:	66 85 c0             	test   %ax,%ax
    74b3:	75 9b                	jne    7450 <fwp_drop4+0x120>
    74b5:	e9 7a ff ff ff       	jmp    7434 <fwp_drop4+0x104>
    74ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    74c0:	48 89 c8             	mov    %rcx,%rax
    74c3:	48 c1 e8 11          	shr    $0x11,%rax
    74c7:	48 31 c8             	xor    %rcx,%rax
    74ca:	48 89 c2             	mov    %rax,%rdx
    74cd:	48 c1 ea 09          	shr    $0x9,%rdx
    74d1:	48 31 d0             	xor    %rdx,%rax
    74d4:	0f b6 d0             	movzbl %al,%edx
    74d7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    74de:	00 
    74df:	48 85 c0             	test   %rax,%rax
    74e2:	75 29                	jne    750d <fwp_drop4+0x1dd>
    74e4:	e9 e3 00 00 00       	jmp    75cc <fwp_drop4+0x29c>
    74e9:	90                   	nop
    74ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74f1:	00 00 00 00 
    74f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74fc:	00 00 00 00 
    7500:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7504:	48 85 c0             	test   %rax,%rax
    7507:	0f 84 bf 00 00 00    	je     75cc <fwp_drop4+0x29c>
    750d:	48 89 c2             	mov    %rax,%rdx
    7510:	48 39 08             	cmp    %rcx,(%rax)
    7513:	75 eb                	jne    7500 <fwp_drop4+0x1d0>
    7515:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7519:	48 83 ea 01          	sub    $0x1,%rdx
    751d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7521:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7528:	0f 85 8d fe ff ff    	jne    73bb <fwp_drop4+0x8b>
    752e:	48 89 cf             	mov    %rcx,%rdi
    7531:	48 89 0c 24          	mov    %rcx,(%rsp)
    7535:	e8 96 e2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    753a:	48 8b 0c 24          	mov    (%rsp),%rcx
    753e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7541:	e9 75 fe ff ff       	jmp    73bb <fwp_drop4+0x8b>
    7546:	48 89 ce             	mov    %rcx,%rsi
    7549:	48 c1 ee 11          	shr    $0x11,%rsi
    754d:	48 31 ce             	xor    %rcx,%rsi
    7550:	48 89 f0             	mov    %rsi,%rax
    7553:	48 c1 e8 09          	shr    $0x9,%rax
    7557:	48 31 c6             	xor    %rax,%rsi
    755a:	40 0f b6 f6          	movzbl %sil,%esi
    755e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7565:	00 
    7566:	48 85 c0             	test   %rax,%rax
    7569:	75 1e                	jne    7589 <fwp_drop4+0x259>
    756b:	eb 5f                	jmp    75cc <fwp_drop4+0x29c>
    756d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7574:	00 
    7575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    757c:	00 00 00 00 
    7580:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7584:	48 85 c0             	test   %rax,%rax
    7587:	74 43                	je     75cc <fwp_drop4+0x29c>
    7589:	48 89 c6             	mov    %rax,%rsi
    758c:	48 39 08             	cmp    %rcx,(%rax)
    758f:	75 ef                	jne    7580 <fwp_drop4+0x250>
    7591:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7595:	48 83 ee 01          	sub    $0x1,%rsi
    7599:	48 89 70 08          	mov    %rsi,0x8(%rax)
    759d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    75a4:	0f 85 a6 fe ff ff    	jne    7450 <fwp_drop4+0x120>
    75aa:	48 89 cf             	mov    %rcx,%rdi
    75ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    75b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    75b6:	e8 15 e2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    75bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    75bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    75c7:	e9 84 fe ff ff       	jmp    7450 <fwp_drop4+0x120>
    75cc:	48 8d 3d 1d 84 00 00 	lea    0x841d(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    75d3:	e8 78 ce ff ff       	call   4450 <fwp_trap>
    75d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    75df:	00 

00000000000075e0 <fwp_arg_drop37>:
    75e0:	f3 0f 1e fa          	endbr64
    75e4:	85 f6                	test   %esi,%esi
    75e6:	75 04                	jne    75ec <fwp_arg_drop37+0xc>
    75e8:	85 d2                	test   %edx,%edx
    75ea:	75 04                	jne    75f0 <fwp_arg_drop37+0x10>
    75ec:	c3                   	ret
    75ed:	0f 1f 00             	nopl   (%rax)
    75f0:	48 8b 3f             	mov    (%rdi),%rdi
    75f3:	e9 38 fd ff ff       	jmp    7330 <fwp_drop4>
    75f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    75ff:	00 

0000000000007600 <fwp_task_dispose>:
    7600:	53                   	push   %rbx
    7601:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7605:	0f 84 3b c1 ff ff    	je     3746 <fwp_task_dispose.cold>
    760b:	48 89 fb             	mov    %rdi,%rbx
    760e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7613:	0f 85 2d c1 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7619:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    761d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7624:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    762b:	00 
    762c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7630:	48 85 ff             	test   %rdi,%rdi
    7633:	74 07                	je     763c <fwp_task_dispose+0x3c>
    7635:	48 85 c0             	test   %rax,%rax
    7638:	74 02                	je     763c <fwp_task_dispose+0x3c>
    763a:	ff d0                	call   *%rax
    763c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7643:	e8 c8 e3 ff ff       	call   5a10 <fwp_mem_free>
    7648:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    764f:	00 00 00 00 
    7653:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7657:	74 6f                	je     76c8 <fwp_task_dispose+0xc8>
    7659:	48 8b 15 98 55 06 00 	mov    0x65598(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7660:	48 89 d8             	mov    %rbx,%rax
    7663:	48 2b 05 66 55 06 00 	sub    0x65566(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    766a:	48 c1 e2 10          	shl    $0x10,%rdx
    766e:	48 39 d0             	cmp    %rdx,%rax
    7671:	73 4c                	jae    76bf <fwp_task_dispose+0xbf>
    7673:	48 89 c2             	mov    %rax,%rdx
    7676:	48 c1 ea 10          	shr    $0x10,%rdx
    767a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    767e:	48 8b 15 93 55 06 00 	mov    0x65593(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    7685:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7689:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    768d:	48 85 c9             	test   %rcx,%rcx
    7690:	74 2d                	je     76bf <fwp_task_dispose+0xbf>
    7692:	0f b6 32             	movzbl (%rdx),%esi
    7695:	40 80 fe 02          	cmp    $0x2,%sil
    7699:	74 3d                	je     76d8 <fwp_task_dispose+0xd8>
    769b:	40 80 fe 01          	cmp    $0x1,%sil
    769f:	75 1e                	jne    76bf <fwp_task_dispose+0xbf>
    76a1:	8b 72 18             	mov    0x18(%rdx),%esi
    76a4:	0f b7 c0             	movzwl %ax,%eax
    76a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    76aa:	48 0f af c6          	imul   %rsi,%rax
    76ae:	48 c1 e8 20          	shr    $0x20,%rax
    76b2:	48 39 d0             	cmp    %rdx,%rax
    76b5:	73 08                	jae    76bf <fwp_task_dispose+0xbf>
    76b7:	48 01 c1             	add    %rax,%rcx
    76ba:	80 39 01             	cmpb   $0x1,(%rcx)
    76bd:	74 09                	je     76c8 <fwp_task_dispose+0xc8>
    76bf:	5b                   	pop    %rbx
    76c0:	c3                   	ret
    76c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76c8:	48 89 df             	mov    %rbx,%rdi
    76cb:	5b                   	pop    %rbx
    76cc:	e9 3f e3 ff ff       	jmp    5a10 <fwp_mem_free>
    76d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76d8:	66 85 c0             	test   %ax,%ax
    76db:	74 dd                	je     76ba <fwp_task_dispose+0xba>
    76dd:	5b                   	pop    %rbx
    76de:	c3                   	ret
    76df:	90                   	nop

00000000000076e0 <fwp_free_zombie>:
    76e0:	48 8b 15 09 41 06 00 	mov    0x64109(%rip),%rdx        # 6b7f0 <fwp_zombie>
    76e7:	48 85 d2             	test   %rdx,%rdx
    76ea:	0f 84 98 00 00 00    	je     7788 <fwp_free_zombie+0xa8>
    76f0:	48 3b 15 09 41 06 00 	cmp    0x64109(%rip),%rdx        # 6b800 <fwp_cur>
    76f7:	0f 84 8b 00 00 00    	je     7788 <fwp_free_zombie+0xa8>
    76fd:	48 83 ec 18          	sub    $0x18,%rsp
    7701:	48 63 05 cc 3a 06 00 	movslq 0x63acc(%rip),%rax        # 6b1d4 <fwp_stack_pool_n>
    7708:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    770c:	83 f8 3f             	cmp    $0x3f,%eax
    770f:	7f 7f                	jg     7790 <fwp_free_zombie+0xb0>
    7711:	8d 48 01             	lea    0x1(%rax),%ecx
    7714:	89 0d ba 3a 06 00    	mov    %ecx,0x63aba(%rip)        # 6b1d4 <fwp_stack_pool_n>
    771a:	48 8d 0d bf 3a 06 00 	lea    0x63abf(%rip),%rcx        # 6b1e0 <fwp_stack_pool>
    7721:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7725:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    772c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7730:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7737:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    773b:	48 85 c9             	test   %rcx,%rcx
    773e:	0f 84 fc 00 00 00    	je     7840 <fwp_free_zombie+0x160>
    7744:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    774b:	48 85 c0             	test   %rax,%rax
    774e:	74 07                	je     7757 <fwp_free_zombie+0x77>
    7750:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7757:	8b 42 5c             	mov    0x5c(%rdx),%eax
    775a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    775e:	48 c7 05 87 40 06 00 	movq   $0x0,0x64087(%rip)        # 6b7f0 <fwp_zombie>
    7765:	00 00 00 00 
    7769:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7770:	85 c0                	test   %eax,%eax
    7772:	74 34                	je     77a8 <fwp_free_zombie+0xc8>
    7774:	83 f8 01             	cmp    $0x1,%eax
    7777:	0f 84 b3 00 00 00    	je     7830 <fwp_free_zombie+0x150>
    777d:	48 83 c4 18          	add    $0x18,%rsp
    7781:	c3                   	ret
    7782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7788:	c3                   	ret
    7789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7790:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7794:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7799:	e8 22 be ff ff       	call   35c0 <munmap@plt>
    779e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    77a3:	eb 80                	jmp    7725 <fwp_free_zombie+0x45>
    77a5:	0f 1f 00             	nopl   (%rax)
    77a8:	48 8b 0d 49 54 06 00 	mov    0x65449(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    77af:	48 89 d0             	mov    %rdx,%rax
    77b2:	48 2b 05 17 54 06 00 	sub    0x65417(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    77b9:	48 c1 e1 10          	shl    $0x10,%rcx
    77bd:	48 39 c8             	cmp    %rcx,%rax
    77c0:	73 bb                	jae    777d <fwp_free_zombie+0x9d>
    77c2:	48 89 c1             	mov    %rax,%rcx
    77c5:	48 c1 e9 10          	shr    $0x10,%rcx
    77c9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    77cd:	48 8b 0d 44 54 06 00 	mov    0x65444(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    77d4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    77d8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    77dc:	48 85 c9             	test   %rcx,%rcx
    77df:	74 9c                	je     777d <fwp_free_zombie+0x9d>
    77e1:	0f b6 3e             	movzbl (%rsi),%edi
    77e4:	40 80 ff 02          	cmp    $0x2,%dil
    77e8:	74 66                	je     7850 <fwp_free_zombie+0x170>
    77ea:	40 80 ff 01          	cmp    $0x1,%dil
    77ee:	75 8d                	jne    777d <fwp_free_zombie+0x9d>
    77f0:	8b 7e 18             	mov    0x18(%rsi),%edi
    77f3:	0f b7 c0             	movzwl %ax,%eax
    77f6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    77f9:	48 0f af c7          	imul   %rdi,%rax
    77fd:	48 c1 e8 20          	shr    $0x20,%rax
    7801:	48 39 f0             	cmp    %rsi,%rax
    7804:	0f 83 73 ff ff ff    	jae    777d <fwp_free_zombie+0x9d>
    780a:	48 01 c1             	add    %rax,%rcx
    780d:	0f b6 01             	movzbl (%rcx),%eax
    7810:	84 c0                	test   %al,%al
    7812:	0f 84 65 ff ff ff    	je     777d <fwp_free_zombie+0x9d>
    7818:	3c 01                	cmp    $0x1,%al
    781a:	74 14                	je     7830 <fwp_free_zombie+0x150>
    781c:	3c ff                	cmp    $0xff,%al
    781e:	74 3b                	je     785b <fwp_free_zombie+0x17b>
    7820:	83 e8 01             	sub    $0x1,%eax
    7823:	88 01                	mov    %al,(%rcx)
    7825:	e9 53 ff ff ff       	jmp    777d <fwp_free_zombie+0x9d>
    782a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7830:	48 89 d7             	mov    %rdx,%rdi
    7833:	48 83 c4 18          	add    $0x18,%rsp
    7837:	e9 c4 fd ff ff       	jmp    7600 <fwp_task_dispose>
    783c:	0f 1f 40 00          	nopl   0x0(%rax)
    7840:	48 89 05 81 3f 06 00 	mov    %rax,0x63f81(%rip)        # 6b7c8 <fwp_tasks_active>
    7847:	e9 ff fe ff ff       	jmp    774b <fwp_free_zombie+0x6b>
    784c:	0f 1f 40 00          	nopl   0x0(%rax)
    7850:	66 85 c0             	test   %ax,%ax
    7853:	0f 85 24 ff ff ff    	jne    777d <fwp_free_zombie+0x9d>
    7859:	eb b2                	jmp    780d <fwp_free_zombie+0x12d>
    785b:	48 89 ca             	mov    %rcx,%rdx
    785e:	48 8d 35 bb 3f 06 00 	lea    0x63fbb(%rip),%rsi        # 6b820 <fwp_heap>
    7865:	48 c1 ea 11          	shr    $0x11,%rdx
    7869:	48 31 ca             	xor    %rcx,%rdx
    786c:	48 89 d0             	mov    %rdx,%rax
    786f:	48 c1 e8 09          	shr    $0x9,%rax
    7873:	48 31 c2             	xor    %rax,%rdx
    7876:	0f b6 d2             	movzbl %dl,%edx
    7879:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7880:	00 
    7881:	48 85 c0             	test   %rax,%rax
    7884:	75 23                	jne    78a9 <fwp_free_zombie+0x1c9>
    7886:	eb 5c                	jmp    78e4 <fwp_free_zombie+0x204>
    7888:	66 90                	xchg   %ax,%ax
    788a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7891:	00 00 00 00 
    7895:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    789c:	00 00 00 00 
    78a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    78a4:	48 85 c0             	test   %rax,%rax
    78a7:	74 3b                	je     78e4 <fwp_free_zombie+0x204>
    78a9:	48 89 c2             	mov    %rax,%rdx
    78ac:	48 39 08             	cmp    %rcx,(%rax)
    78af:	75 ef                	jne    78a0 <fwp_free_zombie+0x1c0>
    78b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    78b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    78b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    78bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    78c4:	0f 85 b3 fe ff ff    	jne    777d <fwp_free_zombie+0x9d>
    78ca:	48 89 cf             	mov    %rcx,%rdi
    78cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    78d2:	e8 f9 de ff ff       	call   57d0 <fwp_rc_forget_slot>
    78d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    78dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    78df:	e9 99 fe ff ff       	jmp    777d <fwp_free_zombie+0x9d>
    78e4:	48 8d 3d 05 81 00 00 	lea    0x8105(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    78eb:	e8 60 cb ff ff       	call   4450 <fwp_trap>

00000000000078f0 <fwp_block>:
    78f0:	48 83 ec 08          	sub    $0x8,%rsp
    78f4:	48 8b 05 ed 3e 06 00 	mov    0x63eed(%rip),%rax        # 6b7e8 <fwp_ready_head>
    78fb:	48 85 c0             	test   %rax,%rax
    78fe:	0f 84 1c 01 00 00    	je     7a20 <fwp_block+0x130>
    7904:	90                   	nop
    7905:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    790c:	00 00 00 00 
    7910:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7917:	48 89 15 ca 3e 06 00 	mov    %rdx,0x63eca(%rip)        # 6b7e8 <fwp_ready_head>
    791e:	48 85 d2             	test   %rdx,%rdx
    7921:	0f 84 19 01 00 00    	je     7a40 <fwp_block+0x150>
    7927:	48 8b 15 d2 3e 06 00 	mov    0x63ed2(%rip),%rdx        # 6b800 <fwp_cur>
    792e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7932:	48 39 c2             	cmp    %rax,%rdx
    7935:	0f 84 d5 00 00 00    	je     7a10 <fwp_block+0x120>
    793b:	48 8b 0d 46 5b 06 00 	mov    0x65b46(%rip),%rcx        # 6d488 <fwp_state_owners>
    7942:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7946:	48 89 05 b3 3e 06 00 	mov    %rax,0x63eb3(%rip)        # 6b800 <fwp_cur>
    794d:	f3 0f 7e 05 5b 5b 06 	movq   0x65b5b(%rip),%xmm0        # 6d4b0 <fwp_foreign_callbacks>
    7954:	00 
    7955:	0f 16 05 44 5b 06 00 	movhps 0x65b44(%rip),%xmm0        # 6d4a0 <fwp_state>
    795c:	f3 0f 7e 0d 44 5b 06 	movq   0x65b44(%rip),%xmm1        # 6d4a8 <fwp_handlers>
    7963:	00 
    7964:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    796b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7972:	0f 16 0d 3f 5b 06 00 	movhps 0x65b3f(%rip),%xmm1        # 6d4b8 <fwp_cleanups>
    7979:	f3 0f 7e 05 17 5b 06 	movq   0x65b17(%rip),%xmm0        # 6d498 <fwp_state_len>
    7980:	00 
    7981:	0f 16 05 08 5b 06 00 	movhps 0x65b08(%rip),%xmm0        # 6d490 <fwp_state_cap>
    7988:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    798f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7996:	48 8b 70 08          	mov    0x8(%rax),%rsi
    799a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    79a1:	48 89 0d 00 5b 06 00 	mov    %rcx,0x65b00(%rip)        # 6d4a8 <fwp_handlers>
    79a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    79af:	48 89 0d 02 5b 06 00 	mov    %rcx,0x65b02(%rip)        # 6d4b8 <fwp_cleanups>
    79b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    79bd:	48 89 0d ec 5a 06 00 	mov    %rcx,0x65aec(%rip)        # 6d4b0 <fwp_foreign_callbacks>
    79c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    79cb:	48 89 0d ce 5a 06 00 	mov    %rcx,0x65ace(%rip)        # 6d4a0 <fwp_state>
    79d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    79d9:	48 89 0d b8 5a 06 00 	mov    %rcx,0x65ab8(%rip)        # 6d498 <fwp_state_len>
    79e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    79e7:	48 89 0d a2 5a 06 00 	mov    %rcx,0x65aa2(%rip)        # 6d490 <fwp_state_cap>
    79ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    79f5:	48 89 0d 8c 5a 06 00 	mov    %rcx,0x65a8c(%rip)        # 6d488 <fwp_state_owners>
    79fc:	e8 7f ba ff ff       	call   3480 <swapcontext@plt>
    7a01:	f3 0f 1e fa          	endbr64
    7a05:	e8 d6 fc ff ff       	call   76e0 <fwp_free_zombie>
    7a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a10:	8b 05 ba 37 06 00    	mov    0x637ba(%rip),%eax        # 6b1d0 <fwp_slice>
    7a16:	85 c0                	test   %eax,%eax
    7a18:	74 36                	je     7a50 <fwp_block+0x160>
    7a1a:	48 83 c4 08          	add    $0x8,%rsp
    7a1e:	c3                   	ret
    7a1f:	90                   	nop
    7a20:	e8 eb d9 ff ff       	call   5410 <fwp_poll_events>
    7a25:	48 8b 05 bc 3d 06 00 	mov    0x63dbc(%rip),%rax        # 6b7e8 <fwp_ready_head>
    7a2c:	48 85 c0             	test   %rax,%rax
    7a2f:	0f 85 db fe ff ff    	jne    7910 <fwp_block+0x20>
    7a35:	eb e9                	jmp    7a20 <fwp_block+0x130>
    7a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a3e:	00 00 
    7a40:	48 c7 05 95 3d 06 00 	movq   $0x0,0x63d95(%rip)        # 6b7e0 <fwp_ready_tail>
    7a47:	00 00 00 00 
    7a4b:	e9 d7 fe ff ff       	jmp    7927 <fwp_block+0x37>
    7a50:	48 8d 3d 88 77 00 00 	lea    0x7788(%rip),%rdi        # f1df <_IO_stdin_used+0x1df>
    7a57:	e8 34 b9 ff ff       	call   3390 <getenv@plt>
    7a5c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7a61:	48 85 c0             	test   %rax,%rax
    7a64:	74 05                	je     7a6b <fwp_block+0x17b>
    7a66:	80 38 00             	cmpb   $0x0,(%rax)
    7a69:	75 0b                	jne    7a76 <fwp_block+0x186>
    7a6b:	89 15 5f 37 06 00    	mov    %edx,0x6375f(%rip)        # 6b1d0 <fwp_slice>
    7a71:	48 83 c4 08          	add    $0x8,%rsp
    7a75:	c3                   	ret
    7a76:	ba 0a 00 00 00       	mov    $0xa,%edx
    7a7b:	31 f6                	xor    %esi,%esi
    7a7d:	48 89 c7             	mov    %rax,%rdi
    7a80:	e8 bb ba ff ff       	call   3540 <strtoll@plt>
    7a85:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7a89:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7a90:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7a95:	0f 46 d0             	cmovbe %eax,%edx
    7a98:	eb d1                	jmp    7a6b <fwp_block+0x17b>
    7a9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007aa0 <fwp_caps173>:
    7aa0:	f3 0f 1e fa          	endbr64
    7aa4:	85 f6                	test   %esi,%esi
    7aa6:	74 08                	je     7ab0 <fwp_caps173+0x10>
    7aa8:	c3                   	ret
    7aa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ab0:	48 8b 15 41 51 06 00 	mov    0x65141(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7ab7:	48 89 f8             	mov    %rdi,%rax
    7aba:	48 2b 05 0f 51 06 00 	sub    0x6510f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7ac1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ac5:	48 39 d0             	cmp    %rdx,%rax
    7ac8:	73 de                	jae    7aa8 <fwp_caps173+0x8>
    7aca:	48 89 c2             	mov    %rax,%rdx
    7acd:	48 c1 ea 10          	shr    $0x10,%rdx
    7ad1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ad5:	48 8b 15 3c 51 06 00 	mov    0x6513c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    7adc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ae0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7ae4:	48 85 c9             	test   %rcx,%rcx
    7ae7:	74 bf                	je     7aa8 <fwp_caps173+0x8>
    7ae9:	0f b6 32             	movzbl (%rdx),%esi
    7aec:	40 80 fe 02          	cmp    $0x2,%sil
    7af0:	74 2e                	je     7b20 <fwp_caps173+0x80>
    7af2:	40 80 fe 01          	cmp    $0x1,%sil
    7af6:	75 b0                	jne    7aa8 <fwp_caps173+0x8>
    7af8:	8b 72 18             	mov    0x18(%rdx),%esi
    7afb:	0f b7 c0             	movzwl %ax,%eax
    7afe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b01:	48 0f af c6          	imul   %rsi,%rax
    7b05:	48 c1 e8 20          	shr    $0x20,%rax
    7b09:	48 39 d0             	cmp    %rdx,%rax
    7b0c:	73 9a                	jae    7aa8 <fwp_caps173+0x8>
    7b0e:	48 01 c1             	add    %rax,%rcx
    7b11:	80 39 01             	cmpb   $0x1,(%rcx)
    7b14:	75 92                	jne    7aa8 <fwp_caps173+0x8>
    7b16:	e9 f5 de ff ff       	jmp    5a10 <fwp_mem_free>
    7b1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b20:	66 85 c0             	test   %ax,%ax
    7b23:	74 ec                	je     7b11 <fwp_caps173+0x71>
    7b25:	c3                   	ret
    7b26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b2d:	00 00 00 

0000000000007b30 <fwp_args37>:
    7b30:	f3 0f 1e fa          	endbr64
    7b34:	85 d2                	test   %edx,%edx
    7b36:	74 04                	je     7b3c <fwp_args37+0xc>
    7b38:	85 f6                	test   %esi,%esi
    7b3a:	74 04                	je     7b40 <fwp_args37+0x10>
    7b3c:	c3                   	ret
    7b3d:	0f 1f 00             	nopl   (%rax)
    7b40:	48 8b 15 b1 50 06 00 	mov    0x650b1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7b47:	48 8b 07             	mov    (%rdi),%rax
    7b4a:	48 2b 05 7f 50 06 00 	sub    0x6507f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7b51:	48 c1 e2 10          	shl    $0x10,%rdx
    7b55:	48 39 d0             	cmp    %rdx,%rax
    7b58:	73 e2                	jae    7b3c <fwp_args37+0xc>
    7b5a:	48 89 c2             	mov    %rax,%rdx
    7b5d:	48 c1 ea 10          	shr    $0x10,%rdx
    7b61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b65:	48 8b 15 ac 50 06 00 	mov    0x650ac(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    7b6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b70:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7b74:	48 85 ff             	test   %rdi,%rdi
    7b77:	74 c3                	je     7b3c <fwp_args37+0xc>
    7b79:	0f b6 0a             	movzbl (%rdx),%ecx
    7b7c:	80 f9 02             	cmp    $0x2,%cl
    7b7f:	74 4f                	je     7bd0 <fwp_args37+0xa0>
    7b81:	80 f9 01             	cmp    $0x1,%cl
    7b84:	75 b6                	jne    7b3c <fwp_args37+0xc>
    7b86:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b89:	0f b7 c0             	movzwl %ax,%eax
    7b8c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b8f:	48 0f af c1          	imul   %rcx,%rax
    7b93:	48 c1 e8 20          	shr    $0x20,%rax
    7b97:	48 39 d0             	cmp    %rdx,%rax
    7b9a:	73 a0                	jae    7b3c <fwp_args37+0xc>
    7b9c:	48 01 c7             	add    %rax,%rdi
    7b9f:	0f b6 07             	movzbl (%rdi),%eax
    7ba2:	84 c0                	test   %al,%al
    7ba4:	74 96                	je     7b3c <fwp_args37+0xc>
    7ba6:	8b 15 3c 59 06 00    	mov    0x6593c(%rip),%edx        # 6d4e8 <iteration_active>
    7bac:	85 d2                	test   %edx,%edx
    7bae:	75 10                	jne    7bc0 <fwp_args37+0x90>
    7bb0:	3c fd                	cmp    $0xfd,%al
    7bb2:	77 22                	ja     7bd6 <fwp_args37+0xa6>
    7bb4:	83 c0 01             	add    $0x1,%eax
    7bb7:	88 07                	mov    %al,(%rdi)
    7bb9:	c3                   	ret
    7bba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bc0:	48 83 05 08 59 06 00 	addq   $0x1,0x65908(%rip)        # 6d4d0 <iteration_retains>
    7bc7:	01 
    7bc8:	eb e6                	jmp    7bb0 <fwp_args37+0x80>
    7bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bd0:	66 85 c0             	test   %ax,%ax
    7bd3:	74 ca                	je     7b9f <fwp_args37+0x6f>
    7bd5:	c3                   	ret
    7bd6:	e9 d5 da ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7bdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007be0 <fwp_caps37>:
    7be0:	f3 0f 1e fa          	endbr64
    7be4:	48 83 ec 18          	sub    $0x18,%rsp
    7be8:	48 89 f8             	mov    %rdi,%rax
    7beb:	8b 7f 04             	mov    0x4(%rdi),%edi
    7bee:	85 ff                	test   %edi,%edi
    7bf0:	0f 84 9a 00 00 00    	je     7c90 <fwp_caps37+0xb0>
    7bf6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7bfa:	85 f6                	test   %esi,%esi
    7bfc:	0f 85 9e 00 00 00    	jne    7ca0 <fwp_caps37+0xc0>
    7c02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7c07:	e8 24 f7 ff ff       	call   7330 <fwp_drop4>
    7c0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c11:	48 8b 0d e0 4f 06 00 	mov    0x64fe0(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    7c18:	48 89 c2             	mov    %rax,%rdx
    7c1b:	48 2b 15 ae 4f 06 00 	sub    0x64fae(%rip),%rdx        # 6cbd0 <fwp_heap+0x13b0>
    7c22:	48 c1 e1 10          	shl    $0x10,%rcx
    7c26:	48 39 ca             	cmp    %rcx,%rdx
    7c29:	73 6d                	jae    7c98 <fwp_caps37+0xb8>
    7c2b:	48 89 d1             	mov    %rdx,%rcx
    7c2e:	48 c1 e9 10          	shr    $0x10,%rcx
    7c32:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7c36:	48 8b 0d db 4f 06 00 	mov    0x64fdb(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    7c3d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7c41:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7c45:	48 85 f6             	test   %rsi,%rsi
    7c48:	74 4e                	je     7c98 <fwp_caps37+0xb8>
    7c4a:	0f b6 39             	movzbl (%rcx),%edi
    7c4d:	40 80 ff 02          	cmp    $0x2,%dil
    7c51:	0f 84 c9 00 00 00    	je     7d20 <fwp_caps37+0x140>
    7c57:	40 80 ff 01          	cmp    $0x1,%dil
    7c5b:	75 3b                	jne    7c98 <fwp_caps37+0xb8>
    7c5d:	8b 79 18             	mov    0x18(%rcx),%edi
    7c60:	0f b7 d2             	movzwl %dx,%edx
    7c63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c66:	48 0f af d7          	imul   %rdi,%rdx
    7c6a:	48 c1 ea 20          	shr    $0x20,%rdx
    7c6e:	48 39 ca             	cmp    %rcx,%rdx
    7c71:	73 25                	jae    7c98 <fwp_caps37+0xb8>
    7c73:	48 01 d6             	add    %rdx,%rsi
    7c76:	80 3e 01             	cmpb   $0x1,(%rsi)
    7c79:	75 1d                	jne    7c98 <fwp_caps37+0xb8>
    7c7b:	48 89 c7             	mov    %rax,%rdi
    7c7e:	48 83 c4 18          	add    $0x18,%rsp
    7c82:	e9 89 dd ff ff       	jmp    5a10 <fwp_mem_free>
    7c87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c8e:	00 00 
    7c90:	85 f6                	test   %esi,%esi
    7c92:	0f 84 79 ff ff ff    	je     7c11 <fwp_caps37+0x31>
    7c98:	48 83 c4 18          	add    $0x18,%rsp
    7c9c:	c3                   	ret
    7c9d:	0f 1f 00             	nopl   (%rax)
    7ca0:	48 8b 05 51 4f 06 00 	mov    0x64f51(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    7ca7:	48 2b 3d 22 4f 06 00 	sub    0x64f22(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    7cae:	48 c1 e0 10          	shl    $0x10,%rax
    7cb2:	48 39 c7             	cmp    %rax,%rdi
    7cb5:	73 e1                	jae    7c98 <fwp_caps37+0xb8>
    7cb7:	48 89 f8             	mov    %rdi,%rax
    7cba:	48 c1 e8 10          	shr    $0x10,%rax
    7cbe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7cc2:	48 8b 05 4f 4f 06 00 	mov    0x64f4f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    7cc9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7ccd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7cd1:	48 85 c0             	test   %rax,%rax
    7cd4:	74 c2                	je     7c98 <fwp_caps37+0xb8>
    7cd6:	0f b6 0a             	movzbl (%rdx),%ecx
    7cd9:	80 f9 02             	cmp    $0x2,%cl
    7cdc:	74 52                	je     7d30 <fwp_caps37+0x150>
    7cde:	80 f9 01             	cmp    $0x1,%cl
    7ce1:	75 b5                	jne    7c98 <fwp_caps37+0xb8>
    7ce3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ce6:	0f b7 ff             	movzwl %di,%edi
    7ce9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cec:	48 0f af f9          	imul   %rcx,%rdi
    7cf0:	48 c1 ef 20          	shr    $0x20,%rdi
    7cf4:	48 39 d7             	cmp    %rdx,%rdi
    7cf7:	73 9f                	jae    7c98 <fwp_caps37+0xb8>
    7cf9:	48 01 f8             	add    %rdi,%rax
    7cfc:	0f b6 10             	movzbl (%rax),%edx
    7cff:	84 d2                	test   %dl,%dl
    7d01:	74 95                	je     7c98 <fwp_caps37+0xb8>
    7d03:	8b 0d df 57 06 00    	mov    0x657df(%rip),%ecx        # 6d4e8 <iteration_active>
    7d09:	85 c9                	test   %ecx,%ecx
    7d0b:	75 33                	jne    7d40 <fwp_caps37+0x160>
    7d0d:	80 fa fd             	cmp    $0xfd,%dl
    7d10:	77 38                	ja     7d4a <fwp_caps37+0x16a>
    7d12:	83 c2 01             	add    $0x1,%edx
    7d15:	88 10                	mov    %dl,(%rax)
    7d17:	e9 7c ff ff ff       	jmp    7c98 <fwp_caps37+0xb8>
    7d1c:	0f 1f 40 00          	nopl   0x0(%rax)
    7d20:	66 85 d2             	test   %dx,%dx
    7d23:	0f 85 6f ff ff ff    	jne    7c98 <fwp_caps37+0xb8>
    7d29:	e9 48 ff ff ff       	jmp    7c76 <fwp_caps37+0x96>
    7d2e:	66 90                	xchg   %ax,%ax
    7d30:	66 85 ff             	test   %di,%di
    7d33:	0f 85 5f ff ff ff    	jne    7c98 <fwp_caps37+0xb8>
    7d39:	eb c1                	jmp    7cfc <fwp_caps37+0x11c>
    7d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d40:	48 83 05 88 57 06 00 	addq   $0x1,0x65788(%rip)        # 6d4d0 <iteration_retains>
    7d47:	01 
    7d48:	eb c3                	jmp    7d0d <fwp_caps37+0x12d>
    7d4a:	48 89 c7             	mov    %rax,%rdi
    7d4d:	48 83 c4 18          	add    $0x18,%rsp
    7d51:	e9 5a d9 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d5d:	00 00 00 

0000000000007d60 <fwp_drop0>:
    7d60:	f3 0f 1e fa          	endbr64
    7d64:	48 8b 15 8d 4e 06 00 	mov    0x64e8d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7d6b:	48 89 f8             	mov    %rdi,%rax
    7d6e:	48 2b 05 5b 4e 06 00 	sub    0x64e5b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7d75:	48 c1 e2 10          	shl    $0x10,%rdx
    7d79:	48 39 d0             	cmp    %rdx,%rax
    7d7c:	0f 83 36 01 00 00    	jae    7eb8 <fwp_drop0+0x158>
    7d82:	48 83 ec 18          	sub    $0x18,%rsp
    7d86:	48 8d 35 93 3a 06 00 	lea    0x63a93(%rip),%rsi        # 6b820 <fwp_heap>
    7d8d:	48 89 c2             	mov    %rax,%rdx
    7d90:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7d97:	48 c1 ea 10          	shr    $0x10,%rdx
    7d9b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7d9f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7da3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7da7:	48 85 d2             	test   %rdx,%rdx
    7daa:	74 42                	je     7dee <fwp_drop0+0x8e>
    7dac:	44 0f b6 01          	movzbl (%rcx),%r8d
    7db0:	41 80 f8 02          	cmp    $0x2,%r8b
    7db4:	74 42                	je     7df8 <fwp_drop0+0x98>
    7db6:	41 80 f8 01          	cmp    $0x1,%r8b
    7dba:	75 32                	jne    7dee <fwp_drop0+0x8e>
    7dbc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7dc0:	0f b7 c0             	movzwl %ax,%eax
    7dc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7dc6:	49 0f af c0          	imul   %r8,%rax
    7dca:	48 c1 e8 20          	shr    $0x20,%rax
    7dce:	48 39 c8             	cmp    %rcx,%rax
    7dd1:	73 1b                	jae    7dee <fwp_drop0+0x8e>
    7dd3:	48 01 c2             	add    %rax,%rdx
    7dd6:	0f b6 02             	movzbl (%rdx),%eax
    7dd9:	84 c0                	test   %al,%al
    7ddb:	74 11                	je     7dee <fwp_drop0+0x8e>
    7ddd:	3c 01                	cmp    $0x1,%al
    7ddf:	74 27                	je     7e08 <fwp_drop0+0xa8>
    7de1:	3c ff                	cmp    $0xff,%al
    7de3:	0f 84 e7 00 00 00    	je     7ed0 <fwp_drop0+0x170>
    7de9:	83 e8 01             	sub    $0x1,%eax
    7dec:	88 02                	mov    %al,(%rdx)
    7dee:	48 83 c4 18          	add    $0x18,%rsp
    7df2:	c3                   	ret
    7df3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7df8:	66 85 c0             	test   %ax,%ax
    7dfb:	74 d9                	je     7dd6 <fwp_drop0+0x76>
    7dfd:	48 83 c4 18          	add    $0x18,%rsp
    7e01:	c3                   	ret
    7e02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e08:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e0f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e16:	48 89 f8             	mov    %rdi,%rax
    7e19:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7e1d:	48 29 c8             	sub    %rcx,%rax
    7e20:	48 c1 e2 10          	shl    $0x10,%rdx
    7e24:	48 39 d0             	cmp    %rdx,%rax
    7e27:	73 71                	jae    7e9a <fwp_drop0+0x13a>
    7e29:	49 89 c2             	mov    %rax,%r10
    7e2c:	49 c1 ea 10          	shr    $0x10,%r10
    7e30:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7e34:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7e38:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7e3c:	4d 85 d2             	test   %r10,%r10
    7e3f:	74 59                	je     7e9a <fwp_drop0+0x13a>
    7e41:	45 0f b6 19          	movzbl (%r9),%r11d
    7e45:	41 80 fb 02          	cmp    $0x2,%r11b
    7e49:	74 75                	je     7ec0 <fwp_drop0+0x160>
    7e4b:	41 80 fb 01          	cmp    $0x1,%r11b
    7e4f:	75 49                	jne    7e9a <fwp_drop0+0x13a>
    7e51:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7e55:	0f b7 c0             	movzwl %ax,%eax
    7e58:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7e5c:	49 0f af c3          	imul   %r11,%rax
    7e60:	48 c1 e8 20          	shr    $0x20,%rax
    7e64:	4c 39 c8             	cmp    %r9,%rax
    7e67:	73 31                	jae    7e9a <fwp_drop0+0x13a>
    7e69:	49 01 c2             	add    %rax,%r10
    7e6c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7e70:	75 28                	jne    7e9a <fwp_drop0+0x13a>
    7e72:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7e77:	e8 94 db ff ff       	call   5a10 <fwp_mem_free>
    7e7c:	48 8d 35 9d 39 06 00 	lea    0x6399d(%rip),%rsi        # 6b820 <fwp_heap>
    7e83:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7e88:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e8f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e96:	48 c1 e2 10          	shl    $0x10,%rdx
    7e9a:	4c 89 c0             	mov    %r8,%rax
    7e9d:	48 29 c8             	sub    %rcx,%rax
    7ea0:	48 39 d0             	cmp    %rdx,%rax
    7ea3:	0f 83 45 ff ff ff    	jae    7dee <fwp_drop0+0x8e>
    7ea9:	4c 89 c7             	mov    %r8,%rdi
    7eac:	e9 dc fe ff ff       	jmp    7d8d <fwp_drop0+0x2d>
    7eb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7eb8:	c3                   	ret
    7eb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ec0:	66 85 c0             	test   %ax,%ax
    7ec3:	75 d5                	jne    7e9a <fwp_drop0+0x13a>
    7ec5:	eb a5                	jmp    7e6c <fwp_drop0+0x10c>
    7ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ece:	00 00 
    7ed0:	48 89 d0             	mov    %rdx,%rax
    7ed3:	48 c1 e8 11          	shr    $0x11,%rax
    7ed7:	48 31 d0             	xor    %rdx,%rax
    7eda:	48 89 c1             	mov    %rax,%rcx
    7edd:	48 c1 e9 09          	shr    $0x9,%rcx
    7ee1:	48 31 c8             	xor    %rcx,%rax
    7ee4:	0f b6 c8             	movzbl %al,%ecx
    7ee7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7eee:	00 
    7eef:	48 85 c0             	test   %rax,%rax
    7ef2:	75 15                	jne    7f09 <fwp_drop0+0x1a9>
    7ef4:	eb 4e                	jmp    7f44 <fwp_drop0+0x1e4>
    7ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7efd:	00 00 00 
    7f00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7f04:	48 85 c0             	test   %rax,%rax
    7f07:	74 3b                	je     7f44 <fwp_drop0+0x1e4>
    7f09:	48 89 c1             	mov    %rax,%rcx
    7f0c:	48 39 10             	cmp    %rdx,(%rax)
    7f0f:	75 ef                	jne    7f00 <fwp_drop0+0x1a0>
    7f11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7f15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7f19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7f1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7f24:	0f 85 c4 fe ff ff    	jne    7dee <fwp_drop0+0x8e>
    7f2a:	48 89 d7             	mov    %rdx,%rdi
    7f2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7f32:	e8 99 d8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7f37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7f3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7f3f:	e9 aa fe ff ff       	jmp    7dee <fwp_drop0+0x8e>
    7f44:	48 8d 3d a5 7a 00 00 	lea    0x7aa5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7f4b:	e8 00 c5 ff ff       	call   4450 <fwp_trap>

0000000000007f50 <fwp_drop1>:
    7f50:	f3 0f 1e fa          	endbr64
    7f54:	48 8b 15 9d 4c 06 00 	mov    0x64c9d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7f5b:	48 89 f8             	mov    %rdi,%rax
    7f5e:	48 2b 05 6b 4c 06 00 	sub    0x64c6b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7f65:	48 c1 e2 10          	shl    $0x10,%rdx
    7f69:	48 39 d0             	cmp    %rdx,%rax
    7f6c:	0f 83 36 01 00 00    	jae    80a8 <fwp_drop1+0x158>
    7f72:	48 83 ec 18          	sub    $0x18,%rsp
    7f76:	48 8d 35 a3 38 06 00 	lea    0x638a3(%rip),%rsi        # 6b820 <fwp_heap>
    7f7d:	48 89 c2             	mov    %rax,%rdx
    7f80:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7f87:	48 c1 ea 10          	shr    $0x10,%rdx
    7f8b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7f8f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7f93:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7f97:	48 85 d2             	test   %rdx,%rdx
    7f9a:	74 42                	je     7fde <fwp_drop1+0x8e>
    7f9c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7fa0:	41 80 f8 02          	cmp    $0x2,%r8b
    7fa4:	74 42                	je     7fe8 <fwp_drop1+0x98>
    7fa6:	41 80 f8 01          	cmp    $0x1,%r8b
    7faa:	75 32                	jne    7fde <fwp_drop1+0x8e>
    7fac:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7fb0:	0f b7 c0             	movzwl %ax,%eax
    7fb3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7fb6:	49 0f af c0          	imul   %r8,%rax
    7fba:	48 c1 e8 20          	shr    $0x20,%rax
    7fbe:	48 39 c8             	cmp    %rcx,%rax
    7fc1:	73 1b                	jae    7fde <fwp_drop1+0x8e>
    7fc3:	48 01 c2             	add    %rax,%rdx
    7fc6:	0f b6 02             	movzbl (%rdx),%eax
    7fc9:	84 c0                	test   %al,%al
    7fcb:	74 11                	je     7fde <fwp_drop1+0x8e>
    7fcd:	3c 01                	cmp    $0x1,%al
    7fcf:	74 27                	je     7ff8 <fwp_drop1+0xa8>
    7fd1:	3c ff                	cmp    $0xff,%al
    7fd3:	0f 84 e7 00 00 00    	je     80c0 <fwp_drop1+0x170>
    7fd9:	83 e8 01             	sub    $0x1,%eax
    7fdc:	88 02                	mov    %al,(%rdx)
    7fde:	48 83 c4 18          	add    $0x18,%rsp
    7fe2:	c3                   	ret
    7fe3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7fe8:	66 85 c0             	test   %ax,%ax
    7feb:	74 d9                	je     7fc6 <fwp_drop1+0x76>
    7fed:	48 83 c4 18          	add    $0x18,%rsp
    7ff1:	c3                   	ret
    7ff2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ff8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7fff:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    8006:	48 89 f8             	mov    %rdi,%rax
    8009:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    800d:	48 29 c8             	sub    %rcx,%rax
    8010:	48 c1 e2 10          	shl    $0x10,%rdx
    8014:	48 39 d0             	cmp    %rdx,%rax
    8017:	73 71                	jae    808a <fwp_drop1+0x13a>
    8019:	49 89 c2             	mov    %rax,%r10
    801c:	49 c1 ea 10          	shr    $0x10,%r10
    8020:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8024:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    8028:	4d 8b 51 20          	mov    0x20(%r9),%r10
    802c:	4d 85 d2             	test   %r10,%r10
    802f:	74 59                	je     808a <fwp_drop1+0x13a>
    8031:	45 0f b6 19          	movzbl (%r9),%r11d
    8035:	41 80 fb 02          	cmp    $0x2,%r11b
    8039:	74 75                	je     80b0 <fwp_drop1+0x160>
    803b:	41 80 fb 01          	cmp    $0x1,%r11b
    803f:	75 49                	jne    808a <fwp_drop1+0x13a>
    8041:	45 8b 59 18          	mov    0x18(%r9),%r11d
    8045:	0f b7 c0             	movzwl %ax,%eax
    8048:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    804c:	49 0f af c3          	imul   %r11,%rax
    8050:	48 c1 e8 20          	shr    $0x20,%rax
    8054:	4c 39 c8             	cmp    %r9,%rax
    8057:	73 31                	jae    808a <fwp_drop1+0x13a>
    8059:	49 01 c2             	add    %rax,%r10
    805c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8060:	75 28                	jne    808a <fwp_drop1+0x13a>
    8062:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8067:	e8 a4 d9 ff ff       	call   5a10 <fwp_mem_free>
    806c:	48 8d 35 ad 37 06 00 	lea    0x637ad(%rip),%rsi        # 6b820 <fwp_heap>
    8073:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    8078:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    807f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    8086:	48 c1 e2 10          	shl    $0x10,%rdx
    808a:	4c 89 c0             	mov    %r8,%rax
    808d:	48 29 c8             	sub    %rcx,%rax
    8090:	48 39 d0             	cmp    %rdx,%rax
    8093:	0f 83 45 ff ff ff    	jae    7fde <fwp_drop1+0x8e>
    8099:	4c 89 c7             	mov    %r8,%rdi
    809c:	e9 dc fe ff ff       	jmp    7f7d <fwp_drop1+0x2d>
    80a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80a8:	c3                   	ret
    80a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80b0:	66 85 c0             	test   %ax,%ax
    80b3:	75 d5                	jne    808a <fwp_drop1+0x13a>
    80b5:	eb a5                	jmp    805c <fwp_drop1+0x10c>
    80b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    80be:	00 00 
    80c0:	48 89 d0             	mov    %rdx,%rax
    80c3:	48 c1 e8 11          	shr    $0x11,%rax
    80c7:	48 31 d0             	xor    %rdx,%rax
    80ca:	48 89 c1             	mov    %rax,%rcx
    80cd:	48 c1 e9 09          	shr    $0x9,%rcx
    80d1:	48 31 c8             	xor    %rcx,%rax
    80d4:	0f b6 c8             	movzbl %al,%ecx
    80d7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    80de:	00 
    80df:	48 85 c0             	test   %rax,%rax
    80e2:	75 25                	jne    8109 <fwp_drop1+0x1b9>
    80e4:	eb 5e                	jmp    8144 <fwp_drop1+0x1f4>
    80e6:	0f 1f 40 00          	nopl   0x0(%rax)
    80ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80f1:	00 00 00 00 
    80f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80fc:	00 00 00 00 
    8100:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8104:	48 85 c0             	test   %rax,%rax
    8107:	74 3b                	je     8144 <fwp_drop1+0x1f4>
    8109:	48 89 c1             	mov    %rax,%rcx
    810c:	48 39 10             	cmp    %rdx,(%rax)
    810f:	75 ef                	jne    8100 <fwp_drop1+0x1b0>
    8111:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8115:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8119:	48 89 48 08          	mov    %rcx,0x8(%rax)
    811d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8124:	0f 85 b4 fe ff ff    	jne    7fde <fwp_drop1+0x8e>
    812a:	48 89 d7             	mov    %rdx,%rdi
    812d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8132:	e8 99 d6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8137:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    813c:	c6 02 fe             	movb   $0xfe,(%rdx)
    813f:	e9 9a fe ff ff       	jmp    7fde <fwp_drop1+0x8e>
    8144:	48 8d 3d a5 78 00 00 	lea    0x78a5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    814b:	e8 00 c3 ff ff       	call   4450 <fwp_trap>

0000000000008150 <fwp_drop10>:
    8150:	48 8b 0d a1 4a 06 00 	mov    0x64aa1(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    8157:	48 89 f8             	mov    %rdi,%rax
    815a:	48 2b 05 6f 4a 06 00 	sub    0x64a6f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8161:	48 c1 e1 10          	shl    $0x10,%rcx
    8165:	48 39 c8             	cmp    %rcx,%rax
    8168:	0f 83 c2 01 00 00    	jae    8330 <fwp_drop10+0x1e0>
    816e:	48 83 ec 18          	sub    $0x18,%rsp
    8172:	48 89 fa             	mov    %rdi,%rdx
    8175:	48 8d 35 a4 36 06 00 	lea    0x636a4(%rip),%rsi        # 6b820 <fwp_heap>
    817c:	48 89 c1             	mov    %rax,%rcx
    817f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    8186:	48 c1 e9 10          	shr    $0x10,%rcx
    818a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    818e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    8192:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    8196:	48 85 c9             	test   %rcx,%rcx
    8199:	74 46                	je     81e1 <fwp_drop10+0x91>
    819b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    819f:	41 80 f9 02          	cmp    $0x2,%r9b
    81a3:	0f 84 d7 00 00 00    	je     8280 <fwp_drop10+0x130>
    81a9:	41 80 f9 01          	cmp    $0x1,%r9b
    81ad:	75 32                	jne    81e1 <fwp_drop10+0x91>
    81af:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    81b3:	0f b7 c0             	movzwl %ax,%eax
    81b6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    81b9:	49 0f af c1          	imul   %r9,%rax
    81bd:	48 c1 e8 20          	shr    $0x20,%rax
    81c1:	48 39 f8             	cmp    %rdi,%rax
    81c4:	73 1b                	jae    81e1 <fwp_drop10+0x91>
    81c6:	48 01 c1             	add    %rax,%rcx
    81c9:	0f b6 01             	movzbl (%rcx),%eax
    81cc:	84 c0                	test   %al,%al
    81ce:	74 11                	je     81e1 <fwp_drop10+0x91>
    81d0:	3c 01                	cmp    $0x1,%al
    81d2:	74 1c                	je     81f0 <fwp_drop10+0xa0>
    81d4:	3c ff                	cmp    $0xff,%al
    81d6:	0f 84 5c 01 00 00    	je     8338 <fwp_drop10+0x1e8>
    81dc:	83 e8 01             	sub    $0x1,%eax
    81df:	88 01                	mov    %al,(%rcx)
    81e1:	48 83 c4 18          	add    $0x18,%rsp
    81e5:	c3                   	ret
    81e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    81ed:	00 00 00 
    81f0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    81f7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    81fe:	48 89 d0             	mov    %rdx,%rax
    8201:	49 89 d1             	mov    %rdx,%r9
    8204:	48 c1 e1 10          	shl    $0x10,%rcx
    8208:	48 29 f8             	sub    %rdi,%rax
    820b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    820f:	78 7f                	js     8290 <fwp_drop10+0x140>
    8211:	48 39 c8             	cmp    %rcx,%rax
    8214:	73 cb                	jae    81e1 <fwp_drop10+0x91>
    8216:	48 89 c1             	mov    %rax,%rcx
    8219:	48 c1 e9 10          	shr    $0x10,%rcx
    821d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8221:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8225:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8229:	48 85 f6             	test   %rsi,%rsi
    822c:	74 b3                	je     81e1 <fwp_drop10+0x91>
    822e:	0f b6 39             	movzbl (%rcx),%edi
    8231:	40 80 ff 02          	cmp    $0x2,%dil
    8235:	74 39                	je     8270 <fwp_drop10+0x120>
    8237:	40 80 ff 01          	cmp    $0x1,%dil
    823b:	75 a4                	jne    81e1 <fwp_drop10+0x91>
    823d:	8b 79 18             	mov    0x18(%rcx),%edi
    8240:	0f b7 c0             	movzwl %ax,%eax
    8243:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8246:	48 0f af c7          	imul   %rdi,%rax
    824a:	48 c1 e8 20          	shr    $0x20,%rax
    824e:	48 39 c8             	cmp    %rcx,%rax
    8251:	73 8e                	jae    81e1 <fwp_drop10+0x91>
    8253:	48 01 c6             	add    %rax,%rsi
    8256:	80 3e 01             	cmpb   $0x1,(%rsi)
    8259:	75 86                	jne    81e1 <fwp_drop10+0x91>
    825b:	48 89 d7             	mov    %rdx,%rdi
    825e:	48 83 c4 18          	add    $0x18,%rsp
    8262:	e9 a9 d7 ff ff       	jmp    5a10 <fwp_mem_free>
    8267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    826e:	00 00 
    8270:	66 85 c0             	test   %ax,%ax
    8273:	74 e1                	je     8256 <fwp_drop10+0x106>
    8275:	48 83 c4 18          	add    $0x18,%rsp
    8279:	c3                   	ret
    827a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8280:	66 85 c0             	test   %ax,%ax
    8283:	0f 84 40 ff ff ff    	je     81c9 <fwp_drop10+0x79>
    8289:	48 83 c4 18          	add    $0x18,%rsp
    828d:	c3                   	ret
    828e:	66 90                	xchg   %ax,%ax
    8290:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8294:	48 39 c8             	cmp    %rcx,%rax
    8297:	73 74                	jae    830d <fwp_drop10+0x1bd>
    8299:	49 89 c2             	mov    %rax,%r10
    829c:	49 c1 ea 10          	shr    $0x10,%r10
    82a0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    82a4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    82a8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    82ac:	4d 85 d2             	test   %r10,%r10
    82af:	74 5c                	je     830d <fwp_drop10+0x1bd>
    82b1:	45 0f b6 18          	movzbl (%r8),%r11d
    82b5:	41 80 fb 02          	cmp    $0x2,%r11b
    82b9:	74 6d                	je     8328 <fwp_drop10+0x1d8>
    82bb:	41 80 fb 01          	cmp    $0x1,%r11b
    82bf:	75 4c                	jne    830d <fwp_drop10+0x1bd>
    82c1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    82c5:	0f b7 c0             	movzwl %ax,%eax
    82c8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    82cc:	49 0f af c3          	imul   %r11,%rax
    82d0:	48 c1 e8 20          	shr    $0x20,%rax
    82d4:	4c 39 c0             	cmp    %r8,%rax
    82d7:	73 34                	jae    830d <fwp_drop10+0x1bd>
    82d9:	49 01 c2             	add    %rax,%r10
    82dc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    82e0:	75 2b                	jne    830d <fwp_drop10+0x1bd>
    82e2:	4c 89 cf             	mov    %r9,%rdi
    82e5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    82ea:	e8 21 d7 ff ff       	call   5a10 <fwp_mem_free>
    82ef:	48 8d 35 2a 35 06 00 	lea    0x6352a(%rip),%rsi        # 6b820 <fwp_heap>
    82f6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    82fb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8302:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8309:	48 c1 e1 10          	shl    $0x10,%rcx
    830d:	48 89 d0             	mov    %rdx,%rax
    8310:	48 29 f8             	sub    %rdi,%rax
    8313:	48 39 c8             	cmp    %rcx,%rax
    8316:	0f 82 60 fe ff ff    	jb     817c <fwp_drop10+0x2c>
    831c:	e9 c0 fe ff ff       	jmp    81e1 <fwp_drop10+0x91>
    8321:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8328:	66 85 c0             	test   %ax,%ax
    832b:	75 e0                	jne    830d <fwp_drop10+0x1bd>
    832d:	eb ad                	jmp    82dc <fwp_drop10+0x18c>
    832f:	90                   	nop
    8330:	c3                   	ret
    8331:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8338:	48 89 c8             	mov    %rcx,%rax
    833b:	48 c1 e8 11          	shr    $0x11,%rax
    833f:	48 31 c8             	xor    %rcx,%rax
    8342:	48 89 c2             	mov    %rax,%rdx
    8345:	48 c1 ea 09          	shr    $0x9,%rdx
    8349:	48 31 d0             	xor    %rdx,%rax
    834c:	0f b6 d0             	movzbl %al,%edx
    834f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8356:	00 
    8357:	48 85 c0             	test   %rax,%rax
    835a:	75 0d                	jne    8369 <fwp_drop10+0x219>
    835c:	eb 46                	jmp    83a4 <fwp_drop10+0x254>
    835e:	66 90                	xchg   %ax,%ax
    8360:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8364:	48 85 c0             	test   %rax,%rax
    8367:	74 3b                	je     83a4 <fwp_drop10+0x254>
    8369:	48 89 c2             	mov    %rax,%rdx
    836c:	48 39 08             	cmp    %rcx,(%rax)
    836f:	75 ef                	jne    8360 <fwp_drop10+0x210>
    8371:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8375:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8379:	48 89 50 08          	mov    %rdx,0x8(%rax)
    837d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8384:	0f 85 57 fe ff ff    	jne    81e1 <fwp_drop10+0x91>
    838a:	48 89 cf             	mov    %rcx,%rdi
    838d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8392:	e8 39 d4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8397:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    839c:	c6 01 fe             	movb   $0xfe,(%rcx)
    839f:	e9 3d fe ff ff       	jmp    81e1 <fwp_drop10+0x91>
    83a4:	48 8d 3d 45 76 00 00 	lea    0x7645(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    83ab:	e8 a0 c0 ff ff       	call   4450 <fwp_trap>

00000000000083b0 <f37>:
    83b0:	41 57                	push   %r15
    83b2:	41 56                	push   %r14
    83b4:	41 55                	push   %r13
    83b6:	41 54                	push   %r12
    83b8:	55                   	push   %rbp
    83b9:	53                   	push   %rbx
    83ba:	48 83 ec 38          	sub    $0x38,%rsp
    83be:	48 8b 15 33 48 06 00 	mov    0x64833(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    83c5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    83ca:	48 c1 e2 10          	shl    $0x10,%rdx
    83ce:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    83d5:	00 00 
    83d7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    83dc:	48 8b 0d ed 47 06 00 	mov    0x647ed(%rip),%rcx        # 6cbd0 <fwp_heap+0x13b0>
    83e3:	48 85 ff             	test   %rdi,%rdi
    83e6:	0f 84 1e 03 00 00    	je     870a <f37+0x35a>
    83ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    83f1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    83f5:	4c 89 e8             	mov    %r13,%rax
    83f8:	48 29 c8             	sub    %rcx,%rax
    83fb:	48 39 d0             	cmp    %rdx,%rax
    83fe:	0f 83 ec 02 00 00    	jae    86f0 <f37+0x340>
    8404:	48 89 c2             	mov    %rax,%rdx
    8407:	48 c1 ea 10          	shr    $0x10,%rdx
    840b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    840f:	48 8b 15 02 48 06 00 	mov    0x64802(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    8416:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    841a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    841e:	48 85 ff             	test   %rdi,%rdi
    8421:	0f 84 c9 02 00 00    	je     86f0 <f37+0x340>
    8427:	0f b6 0a             	movzbl (%rdx),%ecx
    842a:	80 f9 02             	cmp    $0x2,%cl
    842d:	0f 84 4d 02 00 00    	je     8680 <f37+0x2d0>
    8433:	80 f9 01             	cmp    $0x1,%cl
    8436:	75 24                	jne    845c <f37+0xac>
    8438:	8b 4a 18             	mov    0x18(%rdx),%ecx
    843b:	0f b7 c0             	movzwl %ax,%eax
    843e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8441:	48 0f af c1          	imul   %rcx,%rax
    8445:	48 c1 e8 20          	shr    $0x20,%rax
    8449:	48 39 d0             	cmp    %rdx,%rax
    844c:	73 0e                	jae    845c <f37+0xac>
    844e:	48 01 c7             	add    %rax,%rdi
    8451:	0f b6 07             	movzbl (%rdi),%eax
    8454:	84 c0                	test   %al,%al
    8456:	0f 85 44 02 00 00    	jne    86a0 <f37+0x2f0>
    845c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8461:	48 8b 40 10          	mov    0x10(%rax),%rax
    8465:	ba 01 00 00 00       	mov    $0x1,%edx
    846a:	48 85 c0             	test   %rax,%rax
    846d:	74 0e                	je     847d <f37+0xcd>
    846f:	90                   	nop
    8470:	48 8b 40 10          	mov    0x10(%rax),%rax
    8474:	48 83 c2 01          	add    $0x1,%rdx
    8478:	48 85 c0             	test   %rax,%rax
    847b:	75 f3                	jne    8470 <f37+0xc0>
    847d:	4d 85 ed             	test   %r13,%r13
    8480:	0f 84 9a 02 00 00    	je     8720 <f37+0x370>
    8486:	4c 89 e8             	mov    %r13,%rax
    8489:	31 db                	xor    %ebx,%ebx
    848b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8490:	48 8b 40 10          	mov    0x10(%rax),%rax
    8494:	48 83 c3 01          	add    $0x1,%rbx
    8498:	48 85 c0             	test   %rax,%rax
    849b:	75 f3                	jne    8490 <f37+0xe0>
    849d:	48 39 d3             	cmp    %rdx,%rbx
    84a0:	48 0f 47 da          	cmova  %rdx,%rbx
    84a4:	48 89 d8             	mov    %rbx,%rax
    84a7:	48 c1 e8 3c          	shr    $0x3c,%rax
    84ab:	0f 85 7d 03 00 00    	jne    882e <f37+0x47e>
    84b1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    84b5:	be 02 00 00 00       	mov    $0x2,%esi
    84ba:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    84c1:	00 
    84c2:	e8 49 da ff ff       	call   5f10 <fwp_heap_alloc>
    84c7:	48 89 28             	mov    %rbp,(%rax)
    84ca:	48 8b 15 27 47 06 00 	mov    0x64727(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    84d1:	49 89 c4             	mov    %rax,%r12
    84d4:	48 2b 05 f5 46 06 00 	sub    0x646f5(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    84db:	48 c1 e2 10          	shl    $0x10,%rdx
    84df:	48 39 d0             	cmp    %rdx,%rax
    84e2:	73 57                	jae    853b <f37+0x18b>
    84e4:	48 89 c2             	mov    %rax,%rdx
    84e7:	48 c1 ea 10          	shr    $0x10,%rdx
    84eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84ef:	48 8b 15 22 47 06 00 	mov    0x64722(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    84f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84fa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    84fe:	48 85 ed             	test   %rbp,%rbp
    8501:	74 38                	je     853b <f37+0x18b>
    8503:	0f b6 0a             	movzbl (%rdx),%ecx
    8506:	80 f9 02             	cmp    $0x2,%cl
    8509:	0f 84 d1 01 00 00    	je     86e0 <f37+0x330>
    850f:	80 f9 01             	cmp    $0x1,%cl
    8512:	75 27                	jne    853b <f37+0x18b>
    8514:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8517:	0f b7 c0             	movzwl %ax,%eax
    851a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    851d:	48 0f af c1          	imul   %rcx,%rax
    8521:	48 c1 e8 20          	shr    $0x20,%rax
    8525:	48 39 d0             	cmp    %rdx,%rax
    8528:	73 11                	jae    853b <f37+0x18b>
    852a:	48 01 c5             	add    %rax,%rbp
    852d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8531:	0f 84 57 02 00 00    	je     878e <f37+0x3de>
    8537:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    853b:	48 85 db             	test   %rbx,%rbx
    853e:	74 5d                	je     859d <f37+0x1ed>
    8540:	48 c1 e3 04          	shl    $0x4,%rbx
    8544:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8549:	4c 89 e5             	mov    %r12,%rbp
    854c:	4d 89 ef             	mov    %r13,%r15
    854f:	4c 01 e3             	add    %r12,%rbx
    8552:	0f 1f 00             	nopl   (%rax)
    8555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    855c:	00 00 00 00 
    8560:	49 8b 46 08          	mov    0x8(%r14),%rax
    8564:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8568:	48 83 c5 10          	add    $0x10,%rbp
    856c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8571:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8575:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8579:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    857e:	e8 6d e2 ff ff       	call   67f0 <w120>
    8583:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8588:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    858c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8590:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8594:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8598:	48 39 dd             	cmp    %rbx,%rbp
    859b:	75 c3                	jne    8560 <f37+0x1b0>
    859d:	4c 89 ef             	mov    %r13,%rdi
    85a0:	e8 8b ed ff ff       	call   7330 <fwp_drop4>
    85a5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    85aa:	e8 81 ed ff ff       	call   7330 <fwp_drop4>
    85af:	4c 89 e7             	mov    %r12,%rdi
    85b2:	e8 f9 e3 ff ff       	call   69b0 <w176.constprop.0>
    85b7:	4c 89 e7             	mov    %r12,%rdi
    85ba:	48 89 c3             	mov    %rax,%rbx
    85bd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    85c3:	e8 88 fb ff ff       	call   8150 <fwp_drop10>
    85c8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    85ce:	66 48 0f 6e db       	movq   %rbx,%xmm3
    85d3:	31 ff                	xor    %edi,%edi
    85d5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    85da:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    85de:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    85e3:	e8 18 db ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    85e8:	48 8b 15 09 46 06 00 	mov    0x64609(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    85ef:	48 89 c5             	mov    %rax,%rbp
    85f2:	48 2b 05 d7 45 06 00 	sub    0x645d7(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    85f9:	48 c1 e2 10          	shl    $0x10,%rdx
    85fd:	48 39 d0             	cmp    %rdx,%rax
    8600:	73 55                	jae    8657 <f37+0x2a7>
    8602:	48 89 c2             	mov    %rax,%rdx
    8605:	48 c1 ea 10          	shr    $0x10,%rdx
    8609:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    860d:	48 8b 15 04 46 06 00 	mov    0x64604(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    8614:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8618:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    861c:	48 85 db             	test   %rbx,%rbx
    861f:	74 36                	je     8657 <f37+0x2a7>
    8621:	0f b6 0a             	movzbl (%rdx),%ecx
    8624:	80 f9 02             	cmp    $0x2,%cl
    8627:	0f 84 a3 00 00 00    	je     86d0 <f37+0x320>
    862d:	80 f9 01             	cmp    $0x1,%cl
    8630:	75 25                	jne    8657 <f37+0x2a7>
    8632:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8635:	0f b7 c0             	movzwl %ax,%eax
    8638:	8b 52 1c             	mov    0x1c(%rdx),%edx
    863b:	48 0f af c1          	imul   %rcx,%rax
    863f:	48 c1 e8 20          	shr    $0x20,%rax
    8643:	48 39 d0             	cmp    %rdx,%rax
    8646:	73 0f                	jae    8657 <f37+0x2a7>
    8648:	48 01 c3             	add    %rax,%rbx
    864b:	80 3b ff             	cmpb   $0xff,(%rbx)
    864e:	0f 84 2d 01 00 00    	je     8781 <f37+0x3d1>
    8654:	c6 03 01             	movb   $0x1,(%rbx)
    8657:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    865c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8663:	00 00 
    8665:	0f 85 cf 01 00 00    	jne    883a <f37+0x48a>
    866b:	48 83 c4 38          	add    $0x38,%rsp
    866f:	48 89 e8             	mov    %rbp,%rax
    8672:	5b                   	pop    %rbx
    8673:	5d                   	pop    %rbp
    8674:	41 5c                	pop    %r12
    8676:	41 5d                	pop    %r13
    8678:	41 5e                	pop    %r14
    867a:	41 5f                	pop    %r15
    867c:	c3                   	ret
    867d:	0f 1f 00             	nopl   (%rax)
    8680:	66 85 c0             	test   %ax,%ax
    8683:	0f 85 d3 fd ff ff    	jne    845c <f37+0xac>
    8689:	0f b6 07             	movzbl (%rdi),%eax
    868c:	84 c0                	test   %al,%al
    868e:	0f 84 c8 fd ff ff    	je     845c <f37+0xac>
    8694:	90                   	nop
    8695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    869c:	00 00 00 00 
    86a0:	8b 15 42 4e 06 00    	mov    0x64e42(%rip),%edx        # 6d4e8 <iteration_active>
    86a6:	85 d2                	test   %edx,%edx
    86a8:	75 56                	jne    8700 <f37+0x350>
    86aa:	3c fd                	cmp    $0xfd,%al
    86ac:	0f 87 4b 01 00 00    	ja     87fd <f37+0x44d>
    86b2:	83 c0 01             	add    $0x1,%eax
    86b5:	88 07                	mov    %al,(%rdi)
    86b7:	31 d2                	xor    %edx,%edx
    86b9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    86bf:	0f 85 97 fd ff ff    	jne    845c <f37+0xac>
    86c5:	e9 b3 fd ff ff       	jmp    847d <f37+0xcd>
    86ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86d0:	66 85 c0             	test   %ax,%ax
    86d3:	0f 85 7e ff ff ff    	jne    8657 <f37+0x2a7>
    86d9:	e9 6d ff ff ff       	jmp    864b <f37+0x29b>
    86de:	66 90                	xchg   %ax,%ax
    86e0:	66 85 c0             	test   %ax,%ax
    86e3:	0f 85 52 fe ff ff    	jne    853b <f37+0x18b>
    86e9:	e9 3f fe ff ff       	jmp    852d <f37+0x17d>
    86ee:	66 90                	xchg   %ax,%ax
    86f0:	4c 89 e8             	mov    %r13,%rax
    86f3:	e9 6d fd ff ff       	jmp    8465 <f37+0xb5>
    86f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    86ff:	00 
    8700:	48 83 05 c8 4d 06 00 	addq   $0x1,0x64dc8(%rip)        # 6d4d0 <iteration_retains>
    8707:	01 
    8708:	eb a0                	jmp    86aa <f37+0x2fa>
    870a:	48 f7 d9             	neg    %rcx
    870d:	48 39 d1             	cmp    %rdx,%rcx
    8710:	0f 82 85 00 00 00    	jb     879b <f37+0x3eb>
    8716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    871d:	00 00 00 
    8720:	be 02 00 00 00       	mov    $0x2,%esi
    8725:	bf 08 00 00 00       	mov    $0x8,%edi
    872a:	e8 e1 d7 ff ff       	call   5f10 <fwp_heap_alloc>
    872f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8736:	48 8b 15 bb 44 06 00 	mov    0x644bb(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    873d:	49 89 c4             	mov    %rax,%r12
    8740:	48 2b 05 89 44 06 00 	sub    0x64489(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8747:	48 c1 e2 10          	shl    $0x10,%rdx
    874b:	48 39 d0             	cmp    %rdx,%rax
    874e:	0f 83 b3 00 00 00    	jae    8807 <f37+0x457>
    8754:	48 89 c2             	mov    %rax,%rdx
    8757:	48 c1 ea 10          	shr    $0x10,%rdx
    875b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    875f:	48 8b 15 b2 44 06 00 	mov    0x644b2(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    8766:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    876a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    876e:	48 85 ed             	test   %rbp,%rbp
    8771:	0f 84 90 00 00 00    	je     8807 <f37+0x457>
    8777:	31 db                	xor    %ebx,%ebx
    8779:	45 31 ed             	xor    %r13d,%r13d
    877c:	e9 82 fd ff ff       	jmp    8503 <f37+0x153>
    8781:	48 89 df             	mov    %rbx,%rdi
    8784:	e8 47 d0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8789:	e9 c6 fe ff ff       	jmp    8654 <f37+0x2a4>
    878e:	48 89 ef             	mov    %rbp,%rdi
    8791:	e8 3a d0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8796:	e9 9c fd ff ff       	jmp    8537 <f37+0x187>
    879b:	48 89 c8             	mov    %rcx,%rax
    879e:	48 c1 e8 10          	shr    $0x10,%rax
    87a2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    87a6:	48 8b 05 6b 44 06 00 	mov    0x6446b(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    87ad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    87b1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    87b5:	48 85 ff             	test   %rdi,%rdi
    87b8:	0f 84 62 ff ff ff    	je     8720 <f37+0x370>
    87be:	0f b6 02             	movzbl (%rdx),%eax
    87c1:	3c 02                	cmp    $0x2,%al
    87c3:	74 4a                	je     880f <f37+0x45f>
    87c5:	3c 01                	cmp    $0x1,%al
    87c7:	0f 85 53 ff ff ff    	jne    8720 <f37+0x370>
    87cd:	0f b7 c1             	movzwl %cx,%eax
    87d0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    87d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87d6:	48 0f af c1          	imul   %rcx,%rax
    87da:	48 c1 e8 20          	shr    $0x20,%rax
    87de:	48 39 d0             	cmp    %rdx,%rax
    87e1:	0f 83 39 ff ff ff    	jae    8720 <f37+0x370>
    87e7:	48 01 c7             	add    %rax,%rdi
    87ea:	0f b6 07             	movzbl (%rdi),%eax
    87ed:	84 c0                	test   %al,%al
    87ef:	0f 84 2b ff ff ff    	je     8720 <f37+0x370>
    87f5:	45 31 ed             	xor    %r13d,%r13d
    87f8:	e9 a3 fe ff ff       	jmp    86a0 <f37+0x2f0>
    87fd:	e8 ae ce ff ff       	call   56b0 <fwp_rc_wide_dup>
    8802:	e9 b0 fe ff ff       	jmp    86b7 <f37+0x307>
    8807:	45 31 ed             	xor    %r13d,%r13d
    880a:	e9 8e fd ff ff       	jmp    859d <f37+0x1ed>
    880f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8815:	49 89 cd             	mov    %rcx,%r13
    8818:	0f 85 02 ff ff ff    	jne    8720 <f37+0x370>
    881e:	0f b6 07             	movzbl (%rdi),%eax
    8821:	84 c0                	test   %al,%al
    8823:	0f 85 77 fe ff ff    	jne    86a0 <f37+0x2f0>
    8829:	e9 f2 fe ff ff       	jmp    8720 <f37+0x370>
    882e:	48 8d 3d b6 69 00 00 	lea    0x69b6(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    8835:	e8 16 bc ff ff       	call   4450 <fwp_trap>
    883a:	e8 11 ac ff ff       	call   3450 <__stack_chk_fail@plt>
    883f:	90                   	nop

0000000000008840 <fwp_owned_entry37>:
    8840:	f3 0f 1e fa          	endbr64
    8844:	48 8b 3f             	mov    (%rdi),%rdi
    8847:	e9 64 fb ff ff       	jmp    83b0 <f37>
    884c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008850 <e37>:
    8850:	f3 0f 1e fa          	endbr64
    8854:	53                   	push   %rbx
    8855:	48 8b 1f             	mov    (%rdi),%rbx
    8858:	48 89 df             	mov    %rbx,%rdi
    885b:	e8 d0 e1 ff ff       	call   6a30 <fwp_rc_share>
    8860:	48 89 df             	mov    %rbx,%rdi
    8863:	e8 48 fb ff ff       	call   83b0 <f37>
    8868:	48 89 c3             	mov    %rax,%rbx
    886b:	48 89 c7             	mov    %rax,%rdi
    886e:	e8 bd e1 ff ff       	call   6a30 <fwp_rc_share>
    8873:	48 89 d8             	mov    %rbx,%rax
    8876:	5b                   	pop    %rbx
    8877:	c3                   	ret
    8878:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    887f:	00 

0000000000008880 <fwp_write>:
    8880:	41 57                	push   %r15
    8882:	41 56                	push   %r14
    8884:	41 55                	push   %r13
    8886:	41 54                	push   %r12
    8888:	55                   	push   %rbp
    8889:	53                   	push   %rbx
    888a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8891:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8898:	00 00 
    889a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    88a1:	00 
    88a2:	49 89 d4             	mov    %rdx,%r12
    88a5:	8b 12                	mov    (%rdx),%edx
    88a7:	83 fa 19             	cmp    $0x19,%edx
    88aa:	77 6a                	ja     8916 <fwp_write+0x96>
    88ac:	48 89 f5             	mov    %rsi,%rbp
    88af:	89 d0                	mov    %edx,%eax
    88b1:	89 ce                	mov    %ecx,%esi
    88b3:	48 89 fb             	mov    %rdi,%rbx
    88b6:	48 8d 0d 13 74 00 00 	lea    0x7413(%rip),%rcx        # fcd0 <_IO_stdin_used+0xcd0>
    88bd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    88c1:	48 01 c8             	add    %rcx,%rax
    88c4:	3e ff e0             	notrack jmp *%rax
    88c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    88ce:	00 00 
    88d0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    88d4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    88d8:	48 89 ca             	mov    %rcx,%rdx
    88db:	48 85 c9             	test   %rcx,%rcx
    88de:	0f 88 9c 0c 00 00    	js     9580 <fwp_write+0xd00>
    88e4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    88eb:	00 
    88ec:	48 89 c6             	mov    %rax,%rsi
    88ef:	4c 89 e7             	mov    %r12,%rdi
    88f2:	e8 49 b1 ff ff       	call   3a40 <fwp_fmt_u128>
    88f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    88fe:	00 00 
    8900:	4c 89 e7             	mov    %r12,%rdi
    8903:	e8 38 ab ff ff       	call   3440 <strlen@plt>
    8908:	4c 89 e6             	mov    %r12,%rsi
    890b:	48 89 df             	mov    %rbx,%rdi
    890e:	48 89 c2             	mov    %rax,%rdx
    8911:	e8 da b7 ff ff       	call   40f0 <buf_put>
    8916:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    891d:	00 
    891e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8925:	00 00 
    8927:	0f 85 28 04 00 00    	jne    8d55 <fwp_write+0x4d5>
    892d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8934:	5b                   	pop    %rbx
    8935:	5d                   	pop    %rbp
    8936:	41 5c                	pop    %r12
    8938:	41 5d                	pop    %r13
    893a:	41 5e                	pop    %r14
    893c:	41 5f                	pop    %r15
    893e:	c3                   	ret
    893f:	90                   	nop
    8940:	49 89 e9             	mov    %rbp,%r9
    8943:	4c 8d 05 cb 68 00 00 	lea    0x68cb(%rip),%r8        # f215 <_IO_stdin_used+0x215>
    894a:	b9 00 02 00 00       	mov    $0x200,%ecx
    894f:	ba 02 00 00 00       	mov    $0x2,%edx
    8954:	be 00 02 00 00       	mov    $0x200,%esi
    8959:	31 c0                	xor    %eax,%eax
    895b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8962:	00 
    8963:	e8 38 aa ff ff       	call   33a0 <__snprintf_chk@plt>
    8968:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    896f:	00 
    8970:	e8 cb aa ff ff       	call   3440 <strlen@plt>
    8975:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    897c:	00 
    897d:	48 89 df             	mov    %rbx,%rdi
    8980:	48 89 c2             	mov    %rax,%rdx
    8983:	e8 68 b7 ff ff       	call   40f0 <buf_put>
    8988:	eb 8c                	jmp    8916 <fwp_write+0x96>
    898a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8990:	49 89 e9             	mov    %rbp,%r9
    8993:	4c 8d 05 76 68 00 00 	lea    0x6876(%rip),%r8        # f210 <_IO_stdin_used+0x210>
    899a:	eb ae                	jmp    894a <fwp_write+0xca>
    899c:	0f 1f 40 00          	nopl   0x0(%rax)
    89a0:	83 fa 13             	cmp    $0x13,%edx
    89a3:	48 8d 05 5c 68 00 00 	lea    0x685c(%rip),%rax        # f206 <_IO_stdin_used+0x206>
    89aa:	48 8d 35 5a 68 00 00 	lea    0x685a(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    89b1:	ba 04 00 00 00       	mov    $0x4,%edx
    89b6:	48 0f 44 f0          	cmove  %rax,%rsi
    89ba:	45 31 ed             	xor    %r13d,%r13d
    89bd:	e8 2e b7 ff ff       	call   40f0 <buf_put>
    89c2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    89c7:	0f 84 a3 08 00 00    	je     9270 <fwp_write+0x9f0>
    89cd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    89d2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    89d7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    89dc:	48 89 df             	mov    %rbx,%rdi
    89df:	49 0f 44 c5          	cmove  %r13,%rax
    89e3:	31 c9                	xor    %ecx,%ecx
    89e5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    89ea:	e8 91 fe ff ff       	call   8880 <fwp_write>
    89ef:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    89f4:	0f 84 6e 09 00 00    	je     9368 <fwp_write+0xae8>
    89fa:	49 83 c5 01          	add    $0x1,%r13
    89fe:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8a02:	0f 83 68 08 00 00    	jae    9270 <fwp_write+0x9f0>
    8a08:	ba 02 00 00 00       	mov    $0x2,%edx
    8a0d:	48 8d 35 41 68 00 00 	lea    0x6841(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8a14:	48 89 df             	mov    %rbx,%rdi
    8a17:	e8 d4 b6 ff ff       	call   40f0 <buf_put>
    8a1c:	eb af                	jmp    89cd <fwp_write+0x14d>
    8a1e:	66 90                	xchg   %ax,%ax
    8a20:	ba 06 00 00 00       	mov    $0x6,%edx
    8a25:	48 8d 35 02 68 00 00 	lea    0x6802(%rip),%rsi        # f22e <_IO_stdin_used+0x22e>
    8a2c:	48 83 c5 10          	add    $0x10,%rbp
    8a30:	e8 bb b6 ff ff       	call   40f0 <buf_put>
    8a35:	48 89 ef             	mov    %rbp,%rdi
    8a38:	e8 03 aa ff ff       	call   3440 <strlen@plt>
    8a3d:	48 89 ee             	mov    %rbp,%rsi
    8a40:	48 89 df             	mov    %rbx,%rdi
    8a43:	48 89 c2             	mov    %rax,%rdx
    8a46:	e8 a5 b6 ff ff       	call   40f0 <buf_put>
    8a4b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a50:	ba 01 00 00 00       	mov    $0x1,%edx
    8a55:	48 89 df             	mov    %rbx,%rdi
    8a58:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8a5d:	e8 8e b6 ff ff       	call   40f0 <buf_put>
    8a62:	e9 af fe ff ff       	jmp    8916 <fwp_write+0x96>
    8a67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a6e:	00 00 
    8a70:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a77:	00 
    8a78:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a7f:	00 00 
    8a81:	0f 85 ce 02 00 00    	jne    8d55 <fwp_write+0x4d5>
    8a87:	ba 0a 00 00 00       	mov    $0xa,%edx
    8a8c:	48 8d 35 87 67 00 00 	lea    0x6787(%rip),%rsi        # f21a <_IO_stdin_used+0x21a>
    8a93:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8a9a:	48 89 df             	mov    %rbx,%rdi
    8a9d:	5b                   	pop    %rbx
    8a9e:	5d                   	pop    %rbp
    8a9f:	41 5c                	pop    %r12
    8aa1:	41 5d                	pop    %r13
    8aa3:	41 5e                	pop    %r14
    8aa5:	41 5f                	pop    %r15
    8aa7:	e9 44 b6 ff ff       	jmp    40f0 <buf_put>
    8aac:	0f 1f 40 00          	nopl   0x0(%rax)
    8ab0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8ab5:	4d 85 ed             	test   %r13,%r13
    8ab8:	0f 84 02 0c 00 00    	je     96c0 <fwp_write+0xe40>
    8abe:	48 8d 35 9d 67 00 00 	lea    0x679d(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    8ac5:	4c 89 ef             	mov    %r13,%rdi
    8ac8:	e8 53 aa ff ff       	call   3520 <strcmp@plt>
    8acd:	41 89 c1             	mov    %eax,%r9d
    8ad0:	85 c0                	test   %eax,%eax
    8ad2:	0f 84 6c 0c 00 00    	je     9744 <fwp_write+0xec4>
    8ad8:	4c 89 ef             	mov    %r13,%rdi
    8adb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8ae0:	e8 5b a9 ff ff       	call   3440 <strlen@plt>
    8ae5:	4c 89 ee             	mov    %r13,%rsi
    8ae8:	48 89 df             	mov    %rbx,%rdi
    8aeb:	48 89 c2             	mov    %rax,%rdx
    8aee:	e8 fd b5 ff ff       	call   40f0 <buf_put>
    8af3:	ba 01 00 00 00       	mov    $0x1,%edx
    8af8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8afd:	48 89 df             	mov    %rbx,%rdi
    8b00:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8b05:	e8 e6 b5 ff ff       	call   40f0 <buf_put>
    8b0a:	ba 01 00 00 00       	mov    $0x1,%edx
    8b0f:	4c 89 fe             	mov    %r15,%rsi
    8b12:	48 89 df             	mov    %rbx,%rdi
    8b15:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8b1a:	e8 d1 b5 ff ff       	call   40f0 <buf_put>
    8b1f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8b24:	45 31 f6             	xor    %r14d,%r14d
    8b27:	85 d2                	test   %edx,%edx
    8b29:	0f 8e 81 0a 00 00    	jle    95b0 <fwp_write+0xd30>
    8b2f:	45 31 ed             	xor    %r13d,%r13d
    8b32:	4d 85 ed             	test   %r13,%r13
    8b35:	0f 85 75 07 00 00    	jne    92b0 <fwp_write+0xa30>
    8b3b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8b42:	00 
    8b43:	45 85 f6             	test   %r14d,%r14d
    8b46:	0f 84 84 07 00 00    	je     92d0 <fwp_write+0xa50>
    8b4c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8b51:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8b56:	48 89 df             	mov    %rbx,%rdi
    8b59:	49 83 c5 01          	add    $0x1,%r13
    8b5d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8b61:	31 c9                	xor    %ecx,%ecx
    8b63:	e8 18 fd ff ff       	call   8880 <fwp_write>
    8b68:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8b6d:	7f c3                	jg     8b32 <fwp_write+0x2b2>
    8b6f:	45 85 f6             	test   %r14d,%r14d
    8b72:	0f 84 38 0a 00 00    	je     95b0 <fwp_write+0xd30>
    8b78:	b8 29 00 00 00       	mov    $0x29,%eax
    8b7d:	ba 01 00 00 00       	mov    $0x1,%edx
    8b82:	4c 89 fe             	mov    %r15,%rsi
    8b85:	48 89 df             	mov    %rbx,%rdi
    8b88:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8b8c:	e8 5f b5 ff ff       	call   40f0 <buf_put>
    8b91:	e9 80 fd ff ff       	jmp    8916 <fwp_write+0x96>
    8b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b9d:	00 00 00 
    8ba0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ba5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8baa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8baf:	e8 3c b5 ff ff       	call   40f0 <buf_put>
    8bb4:	48 85 ed             	test   %rbp,%rbp
    8bb7:	0f 84 93 06 00 00    	je     9250 <fwp_write+0x9d0>
    8bbd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8bc1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8bc6:	31 c9                	xor    %ecx,%ecx
    8bc8:	48 89 df             	mov    %rbx,%rdi
    8bcb:	e8 b0 fc ff ff       	call   8880 <fwp_write>
    8bd0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8bd4:	48 85 ed             	test   %rbp,%rbp
    8bd7:	0f 84 73 06 00 00    	je     9250 <fwp_write+0x9d0>
    8bdd:	ba 02 00 00 00       	mov    $0x2,%edx
    8be2:	48 8d 35 6c 66 00 00 	lea    0x666c(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8be9:	48 89 df             	mov    %rbx,%rdi
    8bec:	e8 ff b4 ff ff       	call   40f0 <buf_put>
    8bf1:	eb ca                	jmp    8bbd <fwp_write+0x33d>
    8bf3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8bf8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8bfc:	85 f6                	test   %esi,%esi
    8bfe:	0f 84 fc 07 00 00    	je     9400 <fwp_write+0xb80>
    8c04:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8c0b:	00 
    8c0c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8c13:	00 00 
    8c15:	0f 85 3a 01 00 00    	jne    8d55 <fwp_write+0x4d5>
    8c1b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8c1f:	4c 89 ea             	mov    %r13,%rdx
    8c22:	e9 6c fe ff ff       	jmp    8a93 <fwp_write+0x213>
    8c27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c2e:	00 00 
    8c30:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8c35:	ba 01 00 00 00       	mov    $0x1,%edx
    8c3a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8c3f:	48 89 ee             	mov    %rbp,%rsi
    8c42:	e8 a9 b4 ff ff       	call   40f0 <buf_put>
    8c47:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8c4c:	4c 89 e7             	mov    %r12,%rdi
    8c4f:	e8 ec a7 ff ff       	call   3440 <strlen@plt>
    8c54:	4c 89 e6             	mov    %r12,%rsi
    8c57:	48 89 df             	mov    %rbx,%rdi
    8c5a:	48 89 c2             	mov    %rax,%rdx
    8c5d:	e8 8e b4 ff ff       	call   40f0 <buf_put>
    8c62:	ba 01 00 00 00       	mov    $0x1,%edx
    8c67:	48 89 ee             	mov    %rbp,%rsi
    8c6a:	48 89 df             	mov    %rbx,%rdi
    8c6d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8c72:	e8 79 b4 ff ff       	call   40f0 <buf_put>
    8c77:	e9 9a fc ff ff       	jmp    8916 <fwp_write+0x96>
    8c7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c80:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8c85:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8c89:	0f 8a 8e 0b 00 00    	jp     981d <fwp_write+0xf9d>
    8c8f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8c93:	66 0f 54 05 65 71 00 	andpd  0x7165(%rip),%xmm0        # fe00 <msg.4+0xc0>
    8c9a:	00 
    8c9b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8ca0:	66 0f 2e 05 d0 70 00 	ucomisd 0x70d0(%rip),%xmm0        # fd78 <msg.4+0x38>
    8ca7:	00 
    8ca8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8caf:	00 
    8cb0:	0f 87 b2 09 00 00    	ja     9668 <fwp_write+0xde8>
    8cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8cbd:	00 00 00 
    8cc0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8cc4:	89 ee                	mov    %ebp,%esi
    8cc6:	4c 89 e7             	mov    %r12,%rdi
    8cc9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8cce:	e8 9d ba ff ff       	call   4770 <fwp_format_g.constprop.0>
    8cd3:	31 f6                	xor    %esi,%esi
    8cd5:	4c 89 e7             	mov    %r12,%rdi
    8cd8:	e8 23 a7 ff ff       	call   3400 <strtod@plt>
    8cdd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8ce2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8ce6:	7a 06                	jp     8cee <fwp_write+0x46e>
    8ce8:	0f 84 e9 01 00 00    	je     8ed7 <fwp_write+0x657>
    8cee:	83 c5 01             	add    $0x1,%ebp
    8cf1:	83 fd 12             	cmp    $0x12,%ebp
    8cf4:	75 ca                	jne    8cc0 <fwp_write+0x440>
    8cf6:	be 11 00 00 00       	mov    $0x11,%esi
    8cfb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8cff:	4c 89 e7             	mov    %r12,%rdi
    8d02:	e8 69 ba ff ff       	call   4770 <fwp_format_g.constprop.0>
    8d07:	e9 cb 01 00 00       	jmp    8ed7 <fwp_write+0x657>
    8d0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d10:	48 83 fd 01          	cmp    $0x1,%rbp
    8d14:	0f 84 e6 08 00 00    	je     9600 <fwp_write+0xd80>
    8d1a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8d1e:	b8 02 00 00 00       	mov    $0x2,%eax
    8d23:	ba 01 00 00 00       	mov    $0x1,%edx
    8d28:	48 0f 44 d0          	cmove  %rax,%rdx
    8d2c:	48 8d 35 cb 64 00 00 	lea    0x64cb(%rip),%rsi        # f1fe <_IO_stdin_used+0x1fe>
    8d33:	48 8d 05 c9 64 00 00 	lea    0x64c9(%rip),%rax        # f203 <_IO_stdin_used+0x203>
    8d3a:	48 0f 44 f0          	cmove  %rax,%rsi
    8d3e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8d45:	00 
    8d46:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8d4d:	00 00 
    8d4f:	0f 84 3e fd ff ff    	je     8a93 <fwp_write+0x213>
    8d55:	e8 f6 a6 ff ff       	call   3450 <__stack_chk_fail@plt>
    8d5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d60:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8d65:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8d6a:	e8 c1 b2 ff ff       	call   4030 <buf_grow>
    8d6f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8d73:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8d79:	4c 03 0b             	add    (%rbx),%r9
    8d7c:	66 45 89 11          	mov    %r10w,(%r9)
    8d80:	45 85 e4             	test   %r12d,%r12d
    8d83:	0f 8e 07 05 00 00    	jle    9290 <fwp_write+0xa10>
    8d89:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8d90:	55 55 55 
    8d93:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8d98:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8d9f:	aa aa aa 
    8da2:	49 83 c1 01          	add    $0x1,%r9
    8da6:	eb 45                	jmp    8ded <fwp_write+0x56d>
    8da8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8daf:	00 
    8db0:	be 01 00 00 00       	mov    $0x1,%esi
    8db5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8dba:	88 07                	mov    %al,(%rdi)
    8dbc:	48 89 e8             	mov    %rbp,%rax
    8dbf:	49 f7 e8             	imul   %r8
    8dc2:	48 89 e8             	mov    %rbp,%rax
    8dc5:	48 c1 f8 3f          	sar    $0x3f,%rax
    8dc9:	48 29 c2             	sub    %rax,%rdx
    8dcc:	48 85 c9             	test   %rcx,%rcx
    8dcf:	0f 95 c0             	setne  %al
    8dd2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8dd6:	48 83 ef 01          	sub    $0x1,%rdi
    8dda:	48 21 c5             	and    %rax,%rbp
    8ddd:	48 29 ea             	sub    %rbp,%rdx
    8de0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8de4:	49 39 f9             	cmp    %rdi,%r9
    8de7:	0f 84 a3 04 00 00    	je     9290 <fwp_write+0xa10>
    8ded:	48 89 e8             	mov    %rbp,%rax
    8df0:	49 f7 e8             	imul   %r8
    8df3:	48 89 e8             	mov    %rbp,%rax
    8df6:	48 c1 f8 3f          	sar    $0x3f,%rax
    8dfa:	48 89 d1             	mov    %rdx,%rcx
    8dfd:	48 29 c1             	sub    %rax,%rcx
    8e00:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8e04:	48 89 e9             	mov    %rbp,%rcx
    8e07:	48 29 c1             	sub    %rax,%rcx
    8e0a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8e0e:	49 f7 e2             	mul    %r10
    8e11:	b8 30 00 00 00       	mov    $0x30,%eax
    8e16:	48 89 d6             	mov    %rdx,%rsi
    8e19:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8e1d:	48 d1 ee             	shr    $1,%rsi
    8e20:	48 01 f2             	add    %rsi,%rdx
    8e23:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8e27:	48 29 d6             	sub    %rdx,%rsi
    8e2a:	74 8e                	je     8dba <fwp_write+0x53a>
    8e2c:	48 83 fe 01          	cmp    $0x1,%rsi
    8e30:	0f 85 7a ff ff ff    	jne    8db0 <fwp_write+0x530>
    8e36:	31 f6                	xor    %esi,%esi
    8e38:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8e3d:	e9 78 ff ff ff       	jmp    8dba <fwp_write+0x53a>
    8e42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e48:	66 0f 6e cd          	movd   %ebp,%xmm1
    8e4c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8e4f:	0f 8a c8 09 00 00    	jp     981d <fwp_write+0xf9d>
    8e55:	0f 28 c1             	movaps %xmm1,%xmm0
    8e58:	0f 54 05 91 6f 00 00 	andps  0x6f91(%rip),%xmm0        # fdf0 <msg.4+0xb0>
    8e5f:	0f 2e 05 9e 61 00 00 	ucomiss 0x619e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8e66:	0f 87 24 08 00 00    	ja     9690 <fwp_write+0xe10>
    8e6c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8e70:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8e76:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8e7d:	00 
    8e7e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8e82:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e8e:	00 00 
    8e90:	44 89 ee             	mov    %r13d,%esi
    8e93:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8e98:	4c 89 e7             	mov    %r12,%rdi
    8e9b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8ea0:	e8 cb b8 ff ff       	call   4770 <fwp_format_g.constprop.0>
    8ea5:	31 f6                	xor    %esi,%esi
    8ea7:	4c 89 e7             	mov    %r12,%rdi
    8eaa:	e8 f1 a5 ff ff       	call   34a0 <strtof@plt>
    8eaf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8eb4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8eb7:	7a 02                	jp     8ebb <fwp_write+0x63b>
    8eb9:	74 1c                	je     8ed7 <fwp_write+0x657>
    8ebb:	41 83 c5 01          	add    $0x1,%r13d
    8ebf:	41 83 fd 0a          	cmp    $0xa,%r13d
    8ec3:	75 cb                	jne    8e90 <fwp_write+0x610>
    8ec5:	be 09 00 00 00       	mov    $0x9,%esi
    8eca:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8ecf:	4c 89 e7             	mov    %r12,%rdi
    8ed2:	e8 99 b8 ff ff       	call   4770 <fwp_format_g.constprop.0>
    8ed7:	4c 89 e7             	mov    %r12,%rdi
    8eda:	e8 d1 b2 ff ff       	call   41b0 <fwp_finish_float>
    8edf:	e9 1c fa ff ff       	jmp    8900 <fwp_write+0x80>
    8ee4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ee8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8eec:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8ef0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8ef7:	00 
    8ef8:	48 89 ef             	mov    %rbp,%rdi
    8efb:	e8 40 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8f00:	48 89 ef             	mov    %rbp,%rdi
    8f03:	e8 38 a5 ff ff       	call   3440 <strlen@plt>
    8f08:	48 89 ee             	mov    %rbp,%rsi
    8f0b:	48 89 df             	mov    %rbx,%rdi
    8f0e:	48 89 c2             	mov    %rax,%rdx
    8f11:	e8 da b1 ff ff       	call   40f0 <buf_put>
    8f16:	e9 fb f9 ff ff       	jmp    8916 <fwp_write+0x96>
    8f1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8f20:	ba 06 00 00 00       	mov    $0x6,%edx
    8f25:	48 8d 35 2c 63 00 00 	lea    0x632c(%rip),%rsi        # f258 <_IO_stdin_used+0x258>
    8f2c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8f32:	e8 b9 b1 ff ff       	call   40f0 <buf_put>
    8f37:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8f3e:	ff ff 7f 
    8f41:	48 23 55 00          	and    0x0(%rbp),%rdx
    8f45:	0f 84 86 02 00 00    	je     91d1 <fwp_write+0x951>
    8f4b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8f50:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8f54:	48 85 d2             	test   %rdx,%rdx
    8f57:	0f 84 ae 00 00 00    	je     900b <fwp_write+0x78b>
    8f5d:	8b 0a                	mov    (%rdx),%ecx
    8f5f:	83 f9 1c             	cmp    $0x1c,%ecx
    8f62:	0f 84 58 06 00 00    	je     95c0 <fwp_write+0xd40>
    8f68:	83 f9 1b             	cmp    $0x1b,%ecx
    8f6b:	0f 87 9a 00 00 00    	ja     900b <fwp_write+0x78b>
    8f71:	be 01 00 00 00       	mov    $0x1,%esi
    8f76:	48 d3 e6             	shl    %cl,%rsi
    8f79:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8f7f:	0f 85 4b 04 00 00    	jne    93d0 <fwp_write+0xb50>
    8f85:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8f8b:	0f 85 0f 04 00 00    	jne    93a0 <fwp_write+0xb20>
    8f91:	83 e6 21             	and    $0x21,%esi
    8f94:	74 75                	je     900b <fwp_write+0x78b>
    8f96:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8f9b:	48 85 ff             	test   %rdi,%rdi
    8f9e:	79 07                	jns    8fa7 <fwp_write+0x727>
    8fa0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8fa4:	4c 01 ee             	add    %r13,%rsi
    8fa7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8fab:	85 c9                	test   %ecx,%ecx
    8fad:	40 0f b6 f7          	movzbl %dil,%esi
    8fb1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8fbc:	00 00 00 00 
    8fc0:	31 c9                	xor    %ecx,%ecx
    8fc2:	48 89 df             	mov    %rbx,%rdi
    8fc5:	49 83 c5 01          	add    $0x1,%r13
    8fc9:	e8 b2 f8 ff ff       	call   8880 <fwp_write>
    8fce:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8fd5:	ff ff 7f 
    8fd8:	48 23 55 00          	and    0x0(%rbp),%rdx
    8fdc:	49 39 d5             	cmp    %rdx,%r13
    8fdf:	0f 83 ec 01 00 00    	jae    91d1 <fwp_write+0x951>
    8fe5:	ba 02 00 00 00       	mov    $0x2,%edx
    8fea:	48 89 df             	mov    %rbx,%rdi
    8fed:	48 8d 35 61 62 00 00 	lea    0x6261(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8ff4:	e8 f7 b0 ff ff       	call   40f0 <buf_put>
    8ff9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8ffe:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9002:	48 85 d2             	test   %rdx,%rdx
    9005:	0f 85 52 ff ff ff    	jne    8f5d <fwp_write+0x6dd>
    900b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9010:	48 85 ff             	test   %rdi,%rdi
    9013:	0f 88 cf 05 00 00    	js     95e8 <fwp_write+0xd68>
    9019:	48 8b 31             	mov    (%rcx),%rsi
    901c:	eb a2                	jmp    8fc0 <fwp_write+0x740>
    901e:	66 90                	xchg   %ax,%ax
    9020:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9027:	00 
    9028:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    902f:	00 00 
    9031:	0f 85 1e fd ff ff    	jne    8d55 <fwp_write+0x4d5>
    9037:	ba 08 00 00 00       	mov    $0x8,%edx
    903c:	48 8d 35 e2 61 00 00 	lea    0x61e2(%rip),%rsi        # f225 <_IO_stdin_used+0x225>
    9043:	e9 4b fa ff ff       	jmp    8a93 <fwp_write+0x213>
    9048:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    904f:	00 
    9050:	89 e8                	mov    %ebp,%eax
    9052:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9059:	76 03                	jbe    905e <fwp_write+0x7de>
    905b:	8b 45 00             	mov    0x0(%rbp),%eax
    905e:	41 89 c6             	mov    %eax,%r14d
    9061:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9066:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    906b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    906f:	4c 89 ef             	mov    %r13,%rdi
    9072:	e8 c9 a3 ff ff       	call   3440 <strlen@plt>
    9077:	4c 89 ee             	mov    %r13,%rsi
    907a:	48 89 df             	mov    %rbx,%rdi
    907d:	48 89 c2             	mov    %rax,%rdx
    9080:	e8 6b b0 ff ff       	call   40f0 <buf_put>
    9085:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    908a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    908e:	85 f6                	test   %esi,%esi
    9090:	0f 8e 80 f8 ff ff    	jle    8916 <fwp_write+0x96>
    9096:	45 31 ed             	xor    %r13d,%r13d
    9099:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    909e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    90a3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    90a8:	ba 01 00 00 00       	mov    $0x1,%edx
    90ad:	4c 89 fe             	mov    %r15,%rsi
    90b0:	48 89 04 24          	mov    %rax,(%rsp)
    90b4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    90b9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    90bd:	48 89 df             	mov    %rbx,%rdi
    90c0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    90c4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    90c9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    90ce:	e8 1d b0 ff ff       	call   40f0 <buf_put>
    90d3:	41 8b 06             	mov    (%r14),%eax
    90d6:	83 f8 0e             	cmp    $0xe,%eax
    90d9:	0f 84 71 02 00 00    	je     9350 <fwp_write+0xad0>
    90df:	83 f8 10             	cmp    $0x10,%eax
    90e2:	0f 84 38 02 00 00    	je     9320 <fwp_write+0xaa0>
    90e8:	83 f8 0a             	cmp    $0xa,%eax
    90eb:	0f 84 7f 04 00 00    	je     9570 <fwp_write+0xcf0>
    90f1:	0f 8f f9 00 00 00    	jg     91f0 <fwp_write+0x970>
    90f7:	83 f8 03             	cmp    $0x3,%eax
    90fa:	0f 8f 50 04 00 00    	jg     9550 <fwp_write+0xcd0>
    9100:	85 c0                	test   %eax,%eax
    9102:	78 10                	js     9114 <fwp_write+0x894>
    9104:	48 8b 04 24          	mov    (%rsp),%rax
    9108:	48 c1 e8 3f          	shr    $0x3f,%rax
    910c:	85 c0                	test   %eax,%eax
    910e:	0f 85 f9 00 00 00    	jne    920d <fwp_write+0x98d>
    9114:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9119:	48 8b 34 24          	mov    (%rsp),%rsi
    911d:	31 c9                	xor    %ecx,%ecx
    911f:	48 89 df             	mov    %rbx,%rdi
    9122:	e8 59 f7 ff ff       	call   8880 <fwp_write>
    9127:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    912c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9131:	49 83 c5 01          	add    $0x1,%r13
    9135:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9139:	0f 8f 5f ff ff ff    	jg     909e <fwp_write+0x81e>
    913f:	e9 d2 f7 ff ff       	jmp    8916 <fwp_write+0x96>
    9144:	0f 1f 40 00          	nopl   0x0(%rax)
    9148:	ba 06 00 00 00       	mov    $0x6,%edx
    914d:	48 8d 35 f7 60 00 00 	lea    0x60f7(%rip),%rsi        # f24b <_IO_stdin_used+0x24b>
    9154:	45 31 ed             	xor    %r13d,%r13d
    9157:	e8 94 af ff ff       	call   40f0 <buf_put>
    915c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9161:	75 19                	jne    917c <fwp_write+0x8fc>
    9163:	eb 6c                	jmp    91d1 <fwp_write+0x951>
    9165:	0f 1f 00             	nopl   (%rax)
    9168:	ba 02 00 00 00       	mov    $0x2,%edx
    916d:	48 8d 35 e1 60 00 00 	lea    0x60e1(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    9174:	48 89 df             	mov    %rbx,%rdi
    9177:	e8 74 af ff ff       	call   40f0 <buf_put>
    917c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    9182:	b9 00 02 00 00       	mov    $0x200,%ecx
    9187:	31 c0                	xor    %eax,%eax
    9189:	49 83 c5 01          	add    $0x1,%r13
    918d:	4c 8d 05 be 60 00 00 	lea    0x60be(%rip),%r8        # f252 <_IO_stdin_used+0x252>
    9194:	ba 02 00 00 00       	mov    $0x2,%edx
    9199:	be 00 02 00 00       	mov    $0x200,%esi
    919e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    91a5:	00 
    91a6:	e8 f5 a1 ff ff       	call   33a0 <__snprintf_chk@plt>
    91ab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    91b2:	00 
    91b3:	e8 88 a2 ff ff       	call   3440 <strlen@plt>
    91b8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    91bf:	00 
    91c0:	48 89 df             	mov    %rbx,%rdi
    91c3:	48 89 c2             	mov    %rax,%rdx
    91c6:	e8 25 af ff ff       	call   40f0 <buf_put>
    91cb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    91cf:	72 97                	jb     9168 <fwp_write+0x8e8>
    91d1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    91d6:	ba 01 00 00 00       	mov    $0x1,%edx
    91db:	48 89 df             	mov    %rbx,%rdi
    91de:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    91e3:	e8 08 af ff ff       	call   40f0 <buf_put>
    91e8:	e9 29 f7 ff ff       	jmp    8916 <fwp_write+0x96>
    91ed:	0f 1f 00             	nopl   (%rax)
    91f0:	83 f8 0b             	cmp    $0xb,%eax
    91f3:	0f 85 1b ff ff ff    	jne    9114 <fwp_write+0x894>
    91f9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    91fe:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9202:	83 e0 01             	and    $0x1,%eax
    9205:	85 c0                	test   %eax,%eax
    9207:	0f 84 07 ff ff ff    	je     9114 <fwp_write+0x894>
    920d:	4c 89 fe             	mov    %r15,%rsi
    9210:	48 89 df             	mov    %rbx,%rdi
    9213:	ba 01 00 00 00       	mov    $0x1,%edx
    9218:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    921d:	e8 ce ae ff ff       	call   40f0 <buf_put>
    9222:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9227:	48 8b 34 24          	mov    (%rsp),%rsi
    922b:	31 c9                	xor    %ecx,%ecx
    922d:	48 89 df             	mov    %rbx,%rdi
    9230:	e8 4b f6 ff ff       	call   8880 <fwp_write>
    9235:	ba 01 00 00 00       	mov    $0x1,%edx
    923a:	4c 89 fe             	mov    %r15,%rsi
    923d:	48 89 df             	mov    %rbx,%rdi
    9240:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9245:	e8 a6 ae ff ff       	call   40f0 <buf_put>
    924a:	e9 d8 fe ff ff       	jmp    9127 <fwp_write+0x8a7>
    924f:	90                   	nop
    9250:	ba 01 00 00 00       	mov    $0x1,%edx
    9255:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    925a:	48 89 df             	mov    %rbx,%rdi
    925d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9262:	e8 89 ae ff ff       	call   40f0 <buf_put>
    9267:	e9 aa f6 ff ff       	jmp    8916 <fwp_write+0x96>
    926c:	0f 1f 40 00          	nopl   0x0(%rax)
    9270:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9275:	ba 01 00 00 00       	mov    $0x1,%edx
    927a:	48 89 df             	mov    %rbx,%rdi
    927d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9282:	e8 69 ae ff ff       	call   40f0 <buf_put>
    9287:	e9 8a f6 ff ff       	jmp    8916 <fwp_write+0x96>
    928c:	0f 1f 40 00          	nopl   0x0(%rax)
    9290:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9294:	48 8b 13             	mov    (%rbx),%rdx
    9297:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    929c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    92a0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    92a4:	e9 6d f6 ff ff       	jmp    8916 <fwp_write+0x96>
    92a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    92b0:	ba 02 00 00 00       	mov    $0x2,%edx
    92b5:	48 8d 35 99 5f 00 00 	lea    0x5f99(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    92bc:	48 89 df             	mov    %rbx,%rdi
    92bf:	e8 2c ae ff ff       	call   40f0 <buf_put>
    92c4:	e9 72 f8 ff ff       	jmp    8b3b <fwp_write+0x2bb>
    92c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    92d0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    92d5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    92da:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    92de:	48 89 f7             	mov    %rsi,%rdi
    92e1:	48 89 34 24          	mov    %rsi,(%rsp)
    92e5:	e8 56 a1 ff ff       	call   3440 <strlen@plt>
    92ea:	48 8b 34 24          	mov    (%rsp),%rsi
    92ee:	48 89 df             	mov    %rbx,%rdi
    92f1:	48 89 c2             	mov    %rax,%rdx
    92f4:	e8 f7 ad ff ff       	call   40f0 <buf_put>
    92f9:	ba 03 00 00 00       	mov    $0x3,%edx
    92fe:	48 8d 35 73 5f 00 00 	lea    0x5f73(%rip),%rsi        # f278 <_IO_stdin_used+0x278>
    9305:	48 89 df             	mov    %rbx,%rdi
    9308:	e8 e3 ad ff ff       	call   40f0 <buf_put>
    930d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9312:	e9 35 f8 ff ff       	jmp    8b4c <fwp_write+0x2cc>
    9317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    931e:	00 00 
    9320:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9325:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9329:	48 85 ff             	test   %rdi,%rdi
    932c:	0f 84 e2 fd ff ff    	je     9114 <fwp_write+0x894>
    9332:	48 8d 35 29 5f 00 00 	lea    0x5f29(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    9339:	e8 e2 a1 ff ff       	call   3520 <strcmp@plt>
    933e:	85 c0                	test   %eax,%eax
    9340:	0f 95 c0             	setne  %al
    9343:	0f b6 c0             	movzbl %al,%eax
    9346:	e9 c1 fd ff ff       	jmp    910c <fwp_write+0x88c>
    934b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9350:	31 c0                	xor    %eax,%eax
    9352:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9359:	00 
    935a:	0f 97 c0             	seta   %al
    935d:	e9 aa fd ff ff       	jmp    910c <fwp_write+0x88c>
    9362:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9368:	48 89 df             	mov    %rbx,%rdi
    936b:	ba 02 00 00 00       	mov    $0x2,%edx
    9370:	48 8d 35 e8 5e 00 00 	lea    0x5ee8(%rip),%rsi        # f25f <_IO_stdin_used+0x25f>
    9377:	e8 74 ad ff ff       	call   40f0 <buf_put>
    937c:	4c 89 e8             	mov    %r13,%rax
    937f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9384:	31 c9                	xor    %ecx,%ecx
    9386:	48 c1 e0 04          	shl    $0x4,%rax
    938a:	48 89 df             	mov    %rbx,%rdi
    938d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9392:	e8 e9 f4 ff ff       	call   8880 <fwp_write>
    9397:	e9 5e f6 ff ff       	jmp    89fa <fwp_write+0x17a>
    939c:	0f 1f 40 00          	nopl   0x0(%rax)
    93a0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    93a5:	48 85 ff             	test   %rdi,%rdi
    93a8:	79 0c                	jns    93b6 <fwp_write+0xb36>
    93aa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    93b1:	00 
    93b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    93b6:	48 63 3e             	movslq (%rsi),%rdi
    93b9:	83 f9 02             	cmp    $0x2,%ecx
    93bc:	89 fe                	mov    %edi,%esi
    93be:	48 0f 44 f7          	cmove  %rdi,%rsi
    93c2:	e9 f9 fb ff ff       	jmp    8fc0 <fwp_write+0x740>
    93c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    93ce:	00 00 
    93d0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    93d5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    93da:	48 85 ff             	test   %rdi,%rdi
    93dd:	0f 88 0f 03 00 00    	js     96f2 <fwp_write+0xe72>
    93e3:	49 0f bf 38          	movswq (%r8),%rdi
    93e7:	83 f9 01             	cmp    $0x1,%ecx
    93ea:	0f b7 f7             	movzwl %di,%esi
    93ed:	48 0f 44 f7          	cmove  %rdi,%rsi
    93f1:	e9 ca fb ff ff       	jmp    8fc0 <fwp_write+0x740>
    93f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93fd:	00 00 00 
    9400:	ba 01 00 00 00       	mov    $0x1,%edx
    9405:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    940a:	48 83 c5 08          	add    $0x8,%rbp
    940e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9413:	e8 d8 ac ff ff       	call   40f0 <buf_put>
    9418:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    941d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9422:	4d 85 ed             	test   %r13,%r13
    9425:	75 46                	jne    946d <fwp_write+0xbed>
    9427:	e9 04 01 00 00       	jmp    9530 <fwp_write+0xcb0>
    942c:	0f 1f 40 00          	nopl   0x0(%rax)
    9430:	41 80 f9 09          	cmp    $0x9,%r9b
    9434:	0f 84 d6 00 00 00    	je     9510 <fwp_write+0xc90>
    943a:	41 80 f9 0a          	cmp    $0xa,%r9b
    943e:	0f 85 9c 00 00 00    	jne    94e0 <fwp_write+0xc60>
    9444:	ba 02 00 00 00       	mov    $0x2,%edx
    9449:	48 8d 35 eb 5d 00 00 	lea    0x5deb(%rip),%rsi        # f23b <_IO_stdin_used+0x23b>
    9450:	48 89 df             	mov    %rbx,%rdi
    9453:	e8 98 ac ff ff       	call   40f0 <buf_put>
    9458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    945f:	00 
    9460:	48 83 c5 01          	add    $0x1,%rbp
    9464:	49 39 ec             	cmp    %rbp,%r12
    9467:	0f 84 c3 00 00 00    	je     9530 <fwp_write+0xcb0>
    946d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9472:	41 80 f9 0d          	cmp    $0xd,%r9b
    9476:	74 28                	je     94a0 <fwp_write+0xc20>
    9478:	7e b6                	jle    9430 <fwp_write+0xbb0>
    947a:	41 80 f9 22          	cmp    $0x22,%r9b
    947e:	74 40                	je     94c0 <fwp_write+0xc40>
    9480:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9484:	75 5a                	jne    94e0 <fwp_write+0xc60>
    9486:	ba 02 00 00 00       	mov    $0x2,%edx
    948b:	48 8d 35 a6 5d 00 00 	lea    0x5da6(%rip),%rsi        # f238 <_IO_stdin_used+0x238>
    9492:	48 89 df             	mov    %rbx,%rdi
    9495:	e8 56 ac ff ff       	call   40f0 <buf_put>
    949a:	eb c4                	jmp    9460 <fwp_write+0xbe0>
    949c:	0f 1f 40 00          	nopl   0x0(%rax)
    94a0:	ba 02 00 00 00       	mov    $0x2,%edx
    94a5:	48 8d 35 95 5d 00 00 	lea    0x5d95(%rip),%rsi        # f241 <_IO_stdin_used+0x241>
    94ac:	48 89 df             	mov    %rbx,%rdi
    94af:	e8 3c ac ff ff       	call   40f0 <buf_put>
    94b4:	eb aa                	jmp    9460 <fwp_write+0xbe0>
    94b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    94bd:	00 00 00 
    94c0:	ba 02 00 00 00       	mov    $0x2,%edx
    94c5:	48 8d 35 69 5d 00 00 	lea    0x5d69(%rip),%rsi        # f235 <_IO_stdin_used+0x235>
    94cc:	48 89 df             	mov    %rbx,%rdi
    94cf:	e8 1c ac ff ff       	call   40f0 <buf_put>
    94d4:	eb 8a                	jmp    9460 <fwp_write+0xbe0>
    94d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    94dd:	00 00 00 
    94e0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    94e4:	0f 86 2e 01 00 00    	jbe    9618 <fwp_write+0xd98>
    94ea:	41 80 f9 7f          	cmp    $0x7f,%r9b
    94ee:	0f 84 24 01 00 00    	je     9618 <fwp_write+0xd98>
    94f4:	ba 01 00 00 00       	mov    $0x1,%edx
    94f9:	4c 89 fe             	mov    %r15,%rsi
    94fc:	48 89 df             	mov    %rbx,%rdi
    94ff:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9504:	e8 e7 ab ff ff       	call   40f0 <buf_put>
    9509:	e9 52 ff ff ff       	jmp    9460 <fwp_write+0xbe0>
    950e:	66 90                	xchg   %ax,%ax
    9510:	ba 02 00 00 00       	mov    $0x2,%edx
    9515:	48 8d 35 22 5d 00 00 	lea    0x5d22(%rip),%rsi        # f23e <_IO_stdin_used+0x23e>
    951c:	48 89 df             	mov    %rbx,%rdi
    951f:	e8 cc ab ff ff       	call   40f0 <buf_put>
    9524:	e9 37 ff ff ff       	jmp    9460 <fwp_write+0xbe0>
    9529:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9530:	ba 01 00 00 00       	mov    $0x1,%edx
    9535:	4c 89 fe             	mov    %r15,%rsi
    9538:	48 89 df             	mov    %rbx,%rdi
    953b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9540:	e8 ab ab ff ff       	call   40f0 <buf_put>
    9545:	e9 cc f3 ff ff       	jmp    8916 <fwp_write+0x96>
    954a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9550:	83 f8 04             	cmp    $0x4,%eax
    9553:	0f 85 bb fb ff ff    	jne    9114 <fwp_write+0x894>
    9559:	48 8b 04 24          	mov    (%rsp),%rax
    955d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9561:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9566:	48 c1 e8 3f          	shr    $0x3f,%rax
    956a:	e9 96 fc ff ff       	jmp    9205 <fwp_write+0x985>
    956f:	90                   	nop
    9570:	8b 0c 24             	mov    (%rsp),%ecx
    9573:	31 c0                	xor    %eax,%eax
    9575:	85 c9                	test   %ecx,%ecx
    9577:	0f 98 c0             	sets   %al
    957a:	e9 86 fc ff ff       	jmp    9205 <fwp_write+0x985>
    957f:	90                   	nop
    9580:	48 f7 d8             	neg    %rax
    9583:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    958a:	00 
    958b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9592:	2d 
    9593:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    959a:	00 
    959b:	48 83 d2 00          	adc    $0x0,%rdx
    959f:	48 89 c6             	mov    %rax,%rsi
    95a2:	48 f7 da             	neg    %rdx
    95a5:	e8 96 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    95aa:	e9 51 f3 ff ff       	jmp    8900 <fwp_write+0x80>
    95af:	90                   	nop
    95b0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    95b5:	e9 c3 f5 ff ff       	jmp    8b7d <fwp_write+0x2fd>
    95ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95c0:	4c 89 e9             	mov    %r13,%rcx
    95c3:	48 c1 e1 04          	shl    $0x4,%rcx
    95c7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    95cc:	48 85 ff             	test   %rdi,%rdi
    95cf:	0f 89 eb f9 ff ff    	jns    8fc0 <fwp_write+0x740>
    95d5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    95d9:	48 89 ce             	mov    %rcx,%rsi
    95dc:	e9 df f9 ff ff       	jmp    8fc0 <fwp_write+0x740>
    95e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95e8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    95ef:	00 
    95f0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    95f4:	e9 20 fa ff ff       	jmp    9019 <fwp_write+0x799>
    95f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9600:	ba 02 00 00 00       	mov    $0x2,%edx
    9605:	48 8d 35 f4 5b 00 00 	lea    0x5bf4(%rip),%rsi        # f200 <_IO_stdin_used+0x200>
    960c:	e9 2d f7 ff ff       	jmp    8d3e <fwp_write+0x4be>
    9611:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9618:	4c 8d 05 25 5c 00 00 	lea    0x5c25(%rip),%r8        # f244 <_IO_stdin_used+0x244>
    961f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9624:	31 c0                	xor    %eax,%eax
    9626:	ba 02 00 00 00       	mov    $0x2,%edx
    962b:	be 10 00 00 00       	mov    $0x10,%esi
    9630:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9637:	00 
    9638:	e8 63 9d ff ff       	call   33a0 <__snprintf_chk@plt>
    963d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9644:	00 
    9645:	e8 f6 9d ff ff       	call   3440 <strlen@plt>
    964a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9651:	00 
    9652:	48 89 df             	mov    %rbx,%rdi
    9655:	48 89 c2             	mov    %rax,%rdx
    9658:	e8 93 aa ff ff       	call   40f0 <buf_put>
    965d:	e9 fe fd ff ff       	jmp    9460 <fwp_write+0xbe0>
    9662:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9668:	66 0f ef c0          	pxor   %xmm0,%xmm0
    966c:	48 8d 35 87 5b 00 00 	lea    0x5b87(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    9673:	48 8d 05 7f 5b 00 00 	lea    0x5b7f(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    967a:	4c 89 e7             	mov    %r12,%rdi
    967d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9681:	48 0f 46 f0          	cmovbe %rax,%rsi
    9685:	e8 56 9d ff ff       	call   33e0 <strcpy@plt>
    968a:	e9 71 f2 ff ff       	jmp    8900 <fwp_write+0x80>
    968f:	90                   	nop
    9690:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9694:	48 8d 35 5f 5b 00 00 	lea    0x5b5f(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    969b:	48 8d 05 57 5b 00 00 	lea    0x5b57(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    96a2:	0f 2f c8             	comiss %xmm0,%xmm1
    96a5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    96ac:	00 
    96ad:	4c 89 e7             	mov    %r12,%rdi
    96b0:	48 0f 46 f0          	cmovbe %rax,%rsi
    96b4:	e8 27 9d ff ff       	call   33e0 <strcpy@plt>
    96b9:	e9 42 f2 ff ff       	jmp    8900 <fwp_write+0x80>
    96be:	66 90                	xchg   %ax,%ax
    96c0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    96c5:	45 85 c0             	test   %r8d,%r8d
    96c8:	75 34                	jne    96fe <fwp_write+0xe7e>
    96ca:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    96d1:	00 
    96d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    96d9:	00 00 
    96db:	0f 85 74 f6 ff ff    	jne    8d55 <fwp_write+0x4d5>
    96e1:	ba 02 00 00 00       	mov    $0x2,%edx
    96e6:	48 8d 35 88 5b 00 00 	lea    0x5b88(%rip),%rsi        # f275 <_IO_stdin_used+0x275>
    96ed:	e9 a1 f3 ff ff       	jmp    8a93 <fwp_write+0x213>
    96f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    96f6:	49 89 f0             	mov    %rsi,%r8
    96f9:	e9 e5 fc ff ff       	jmp    93e3 <fwp_write+0xb63>
    96fe:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9703:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9708:	85 ff                	test   %edi,%edi
    970a:	0f 84 fa f3 ff ff    	je     8b0a <fwp_write+0x28a>
    9710:	ba 01 00 00 00       	mov    $0x1,%edx
    9715:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    971a:	48 89 df             	mov    %rbx,%rdi
    971d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9722:	e8 c9 a9 ff ff       	call   40f0 <buf_put>
    9727:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    972c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9731:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9737:	85 c0                	test   %eax,%eax
    9739:	0f 8f f0 f3 ff ff    	jg     8b2f <fwp_write+0x2af>
    973f:	e9 34 f4 ff ff       	jmp    8b78 <fwp_write+0x2f8>
    9744:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9748:	49 89 c5             	mov    %rax,%r13
    974b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9750:	49 89 c4             	mov    %rax,%r12
    9753:	49 c1 fd 3f          	sar    $0x3f,%r13
    9757:	4c 09 e8             	or     %r13,%rax
    975a:	0f 84 a7 00 00 00    	je     9807 <fwp_write+0xf87>
    9760:	48 8d 2d 59 7b 00 00 	lea    0x7b59(%rip),%rbp        # 112c0 <units.0>
    9767:	4d 89 e7             	mov    %r12,%r15
    976a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    976e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9773:	4c 89 ff             	mov    %r15,%rdi
    9776:	4c 89 ee             	mov    %r13,%rsi
    9779:	44 89 0c 24          	mov    %r9d,(%rsp)
    977d:	48 99                	cqto
    977f:	48 89 d1             	mov    %rdx,%rcx
    9782:	48 89 c2             	mov    %rax,%rdx
    9785:	e8 f6 4f 00 00       	call   e780 <__divmodti4>
    978a:	44 8b 0c 24          	mov    (%rsp),%r9d
    978e:	48 89 c1             	mov    %rax,%rcx
    9791:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9796:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    979b:	0f 84 94 00 00 00    	je     9835 <fwp_write+0xfb5>
    97a1:	41 83 c1 01          	add    $0x1,%r9d
    97a5:	48 83 c5 10          	add    $0x10,%rbp
    97a9:	41 83 f9 05          	cmp    $0x5,%r9d
    97ad:	75 bb                	jne    976a <fwp_write+0xeea>
    97af:	4d 85 ed             	test   %r13,%r13
    97b2:	79 53                	jns    9807 <fwp_write+0xf87>
    97b4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    97b9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    97be:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    97c3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    97c8:	48 99                	cqto
    97ca:	48 f7 d8             	neg    %rax
    97cd:	48 83 d2 00          	adc    $0x0,%rdx
    97d1:	48 89 c6             	mov    %rax,%rsi
    97d4:	48 f7 da             	neg    %rdx
    97d7:	e8 64 a2 ff ff       	call   3a40 <fwp_fmt_u128>
    97dc:	49 89 e8             	mov    %rbp,%r8
    97df:	ba 00 02 00 00       	mov    $0x200,%edx
    97e4:	be 02 00 00 00       	mov    $0x2,%esi
    97e9:	31 c0                	xor    %eax,%eax
    97eb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    97f2:	00 
    97f3:	48 8d 0d 76 5a 00 00 	lea    0x5a76(%rip),%rcx        # f270 <_IO_stdin_used+0x270>
    97fa:	4c 89 e7             	mov    %r12,%rdi
    97fd:	e8 be 9e ff ff       	call   36c0 <__sprintf_chk@plt>
    9802:	e9 f9 f0 ff ff       	jmp    8900 <fwp_write+0x80>
    9807:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    980c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9811:	31 d2                	xor    %edx,%edx
    9813:	48 89 ef             	mov    %rbp,%rdi
    9816:	e8 25 a2 ff ff       	call   3a40 <fwp_fmt_u128>
    981b:	eb bf                	jmp    97dc <fwp_write+0xf5c>
    981d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9824:	4e 61 4e 00 
    9828:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    982f:	00 
    9830:	e9 cb f0 ff ff       	jmp    8900 <fwp_write+0x80>
    9835:	44 89 0c 24          	mov    %r9d,(%rsp)
    9839:	48 89 c8             	mov    %rcx,%rax
    983c:	48 85 d2             	test   %rdx,%rdx
    983f:	78 51                	js     9892 <fwp_write+0x1012>
    9841:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9846:	48 89 c6             	mov    %rax,%rsi
    9849:	48 89 ef             	mov    %rbp,%rdi
    984c:	e8 ef a1 ff ff       	call   3a40 <fwp_fmt_u128>
    9851:	44 8b 0c 24          	mov    (%rsp),%r9d
    9855:	49 63 c1             	movslq %r9d,%rax
    9858:	49 89 e8             	mov    %rbp,%r8
    985b:	ba 00 02 00 00       	mov    $0x200,%edx
    9860:	be 02 00 00 00       	mov    $0x2,%esi
    9865:	48 c1 e0 04          	shl    $0x4,%rax
    9869:	48 8d 3d 50 7a 00 00 	lea    0x7a50(%rip),%rdi        # 112c0 <units.0>
    9870:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9877:	00 
    9878:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    987c:	48 8d 0d e8 59 00 00 	lea    0x59e8(%rip),%rcx        # f26b <_IO_stdin_used+0x26b>
    9883:	4c 89 e7             	mov    %r12,%rdi
    9886:	31 c0                	xor    %eax,%eax
    9888:	e8 33 9e ff ff       	call   36c0 <__sprintf_chk@plt>
    988d:	e9 6e f0 ff ff       	jmp    8900 <fwp_write+0x80>
    9892:	48 f7 d8             	neg    %rax
    9895:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    989a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    989f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    98a4:	48 83 d2 00          	adc    $0x0,%rdx
    98a8:	48 89 c6             	mov    %rax,%rsi
    98ab:	48 f7 da             	neg    %rdx
    98ae:	e8 8d a1 ff ff       	call   3a40 <fwp_fmt_u128>
    98b3:	44 8b 0c 24          	mov    (%rsp),%r9d
    98b7:	eb 9c                	jmp    9855 <fwp_write+0xfd5>
    98b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000098c0 <fwp_hof0.constprop.0>:
    98c0:	41 57                	push   %r15
    98c2:	41 56                	push   %r14
    98c4:	41 55                	push   %r13
    98c6:	41 54                	push   %r12
    98c8:	55                   	push   %rbp
    98c9:	53                   	push   %rbx
    98ca:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    98d1:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    98d6:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    98dd:	00 00 
    98df:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    98e6:	00 
    98e7:	31 c0                	xor    %eax,%eax
    98e9:	48 85 f6             	test   %rsi,%rsi
    98ec:	0f 84 65 0f 00 00    	je     a857 <fwp_hof0.constprop.0+0xf97>
    98f2:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
    98f7:	48 8d 2d 22 1f 06 00 	lea    0x61f22(%rip),%rbp        # 6b820 <fwp_heap>
    98fe:	66 90                	xchg   %ax,%ax
    9900:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9907:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    990c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9913:	48 c1 e2 10          	shl    $0x10,%rdx
    9917:	48 39 d0             	cmp    %rdx,%rax
    991a:	73 71                	jae    998d <fwp_hof0.constprop.0+0xcd>
    991c:	48 89 c2             	mov    %rax,%rdx
    991f:	48 c1 ea 10          	shr    $0x10,%rdx
    9923:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9927:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    992e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9932:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9936:	48 85 ff             	test   %rdi,%rdi
    9939:	74 52                	je     998d <fwp_hof0.constprop.0+0xcd>
    993b:	0f b6 0a             	movzbl (%rdx),%ecx
    993e:	80 f9 02             	cmp    $0x2,%cl
    9941:	0f 84 81 15 00 00    	je     aec8 <fwp_hof0.constprop.0+0x1608>
    9947:	80 f9 01             	cmp    $0x1,%cl
    994a:	75 41                	jne    998d <fwp_hof0.constprop.0+0xcd>
    994c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    994f:	0f b7 c0             	movzwl %ax,%eax
    9952:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9955:	48 0f af c1          	imul   %rcx,%rax
    9959:	48 c1 e8 20          	shr    $0x20,%rax
    995d:	48 39 d0             	cmp    %rdx,%rax
    9960:	73 2b                	jae    998d <fwp_hof0.constprop.0+0xcd>
    9962:	48 01 c7             	add    %rax,%rdi
    9965:	0f b6 07             	movzbl (%rdi),%eax
    9968:	84 c0                	test   %al,%al
    996a:	74 21                	je     998d <fwp_hof0.constprop.0+0xcd>
    996c:	44 8b 0d 75 3b 06 00 	mov    0x63b75(%rip),%r9d        # 6d4e8 <iteration_active>
    9973:	45 85 c9             	test   %r9d,%r9d
    9976:	74 08                	je     9980 <fwp_hof0.constprop.0+0xc0>
    9978:	48 83 05 50 3b 06 00 	addq   $0x1,0x63b50(%rip)        # 6d4d0 <iteration_retains>
    997f:	01 
    9980:	3c fd                	cmp    $0xfd,%al
    9982:	0f 87 0e 17 00 00    	ja     b096 <fwp_hof0.constprop.0+0x17d6>
    9988:	83 c0 01             	add    $0x1,%eax
    998b:	88 07                	mov    %al,(%rdi)
    998d:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    9992:	45 31 c9             	xor    %r9d,%r9d
    9995:	48 c7 44 24 28 c6 00 	movq   $0xc6,0x28(%rsp)
    999c:	00 00 
    999e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    99a3:	4c 89 cb             	mov    %r9,%rbx
    99a6:	4d 85 c9             	test   %r9,%r9
    99a9:	0f 85 a1 9d ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    99af:	48 8b 05 02 3b 06 00 	mov    0x63b02(%rip),%rax        # 6d4b8 <fwp_cleanups>
    99b6:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    99bd:	4c 8d 2d 3c d8 ff ff 	lea    -0x27c4(%rip),%r13        # 7200 <fwp_tape_scope_release>
    99c4:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    99cb:	ff 
    99cc:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    99d3:	00 
    99d4:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    99db:	00 
    99dc:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    99e1:	48 c1 e2 10          	shl    $0x10,%rdx
    99e5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    99ea:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    99f1:	00 
    99f2:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    99f9:	00 
    99fa:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    99ff:	48 89 05 b2 3a 06 00 	mov    %rax,0x63ab2(%rip)        # 6d4b8 <fwp_cleanups>
    9a06:	48 8d 05 03 96 00 00 	lea    0x9603(%rip),%rax        # 13010 <fc37>
    9a0d:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9a14:	48 39 d0             	cmp    %rdx,%rax
    9a17:	73 71                	jae    9a8a <fwp_hof0.constprop.0+0x1ca>
    9a19:	48 89 c2             	mov    %rax,%rdx
    9a1c:	48 c1 ea 10          	shr    $0x10,%rdx
    9a20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a24:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9a2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a2f:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9a33:	48 85 ff             	test   %rdi,%rdi
    9a36:	74 52                	je     9a8a <fwp_hof0.constprop.0+0x1ca>
    9a38:	0f b6 0a             	movzbl (%rdx),%ecx
    9a3b:	80 f9 02             	cmp    $0x2,%cl
    9a3e:	0f 84 7c 12 00 00    	je     acc0 <fwp_hof0.constprop.0+0x1400>
    9a44:	80 f9 01             	cmp    $0x1,%cl
    9a47:	75 41                	jne    9a8a <fwp_hof0.constprop.0+0x1ca>
    9a49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a4c:	0f b7 c0             	movzwl %ax,%eax
    9a4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a52:	48 0f af c1          	imul   %rcx,%rax
    9a56:	48 c1 e8 20          	shr    $0x20,%rax
    9a5a:	48 39 d0             	cmp    %rdx,%rax
    9a5d:	73 2b                	jae    9a8a <fwp_hof0.constprop.0+0x1ca>
    9a5f:	48 01 c7             	add    %rax,%rdi
    9a62:	0f b6 07             	movzbl (%rdi),%eax
    9a65:	84 c0                	test   %al,%al
    9a67:	74 21                	je     9a8a <fwp_hof0.constprop.0+0x1ca>
    9a69:	44 8b 05 78 3a 06 00 	mov    0x63a78(%rip),%r8d        # 6d4e8 <iteration_active>
    9a70:	45 85 c0             	test   %r8d,%r8d
    9a73:	74 08                	je     9a7d <fwp_hof0.constprop.0+0x1bd>
    9a75:	48 83 05 53 3a 06 00 	addq   $0x1,0x63a53(%rip)        # 6d4d0 <iteration_retains>
    9a7c:	01 
    9a7d:	3c fd                	cmp    $0xfd,%al
    9a7f:	0f 87 b7 15 00 00    	ja     b03c <fwp_hof0.constprop.0+0x177c>
    9a85:	83 c0 01             	add    $0x1,%eax
    9a88:	88 07                	mov    %al,(%rdi)
    9a8a:	48 8d 3d 7f 95 00 00 	lea    0x957f(%rip),%rdi        # 13010 <fc37>
    9a91:	e8 fa d3 ff ff       	call   6e90 <fwp_closure_drop>
    9a96:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9a9b:	48 85 c0             	test   %rax,%rax
    9a9e:	0f 84 a7 14 00 00    	je     af4b <fwp_hof0.constprop.0+0x168b>
    9aa4:	31 d2                	xor    %edx,%edx
    9aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9aad:	00 00 00 
    9ab0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9ab4:	48 83 c2 01          	add    $0x1,%rdx
    9ab8:	48 85 c0             	test   %rax,%rax
    9abb:	75 f3                	jne    9ab0 <fwp_hof0.constprop.0+0x1f0>
    9abd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    9ac4:	0f 87 95 16 00 00    	ja     b15f <fwp_hof0.constprop.0+0x189f>
    9aca:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    9acf:	8b 35 8b 95 00 00    	mov    0x958b(%rip),%esi        # 13060 <registered_finish.1>
    9ad5:	85 f6                	test   %esi,%esi
    9ad7:	0f 84 a3 11 00 00    	je     ac80 <fwp_hof0.constprop.0+0x13c0>
    9add:	4c 8b 35 f4 95 01 00 	mov    0x195f4(%rip),%r14        # 230d8 <fwp_tape_next_slot>
    9ae4:	4c 8b 25 fd 95 01 00 	mov    0x195fd(%rip),%r12        # 230e8 <fwp_ntapes>
    9aeb:	4d 39 f4             	cmp    %r14,%r12
    9aee:	0f 8e 3c 0e 00 00    	jle    a930 <fwp_hof0.constprop.0+0x1070>
    9af4:	49 6b c6 68          	imul   $0x68,%r14,%rax
    9af8:	48 03 05 f1 95 01 00 	add    0x195f1(%rip),%rax        # 230f0 <fwp_tapes>
    9aff:	90                   	nop
    9b00:	8b 48 04             	mov    0x4(%rax),%ecx
    9b03:	85 c9                	test   %ecx,%ecx
    9b05:	75 0c                	jne    9b13 <fwp_hof0.constprop.0+0x253>
    9b07:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    9b0d:	0f 86 1d 0e 00 00    	jbe    a930 <fwp_hof0.constprop.0+0x1070>
    9b13:	49 83 c6 01          	add    $0x1,%r14
    9b17:	48 83 c0 68          	add    $0x68,%rax
    9b1b:	4d 39 f4             	cmp    %r14,%r12
    9b1e:	75 e0                	jne    9b00 <fwp_hof0.constprop.0+0x240>
    9b20:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    9b27:	0f 8f 4a 16 00 00    	jg     b177 <fwp_hof0.constprop.0+0x18b7>
    9b2d:	4c 3b 25 ac 95 01 00 	cmp    0x195ac(%rip),%r12        # 230e0 <fwp_tapes_cap>
    9b34:	4c 8b 3d b5 95 01 00 	mov    0x195b5(%rip),%r15        # 230f0 <fwp_tapes>
    9b3b:	75 4d                	jne    9b8a <fwp_hof0.constprop.0+0x2ca>
    9b3d:	4d 85 e4             	test   %r12,%r12
    9b40:	0f 84 6b 14 00 00    	je     afb1 <fwp_hof0.constprop.0+0x16f1>
    9b46:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    9b4a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9b4f:	49 39 c6             	cmp    %rax,%r14
    9b52:	4c 0f 4f f0          	cmovg  %rax,%r14
    9b56:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    9b5a:	31 d2                	xor    %edx,%edx
    9b5c:	4c 89 ff             	mov    %r15,%rdi
    9b5f:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    9b65:	e8 26 b6 ff ff       	call   5190 <ad_raw_realloc>
    9b6a:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9b70:	48 85 c0             	test   %rax,%rax
    9b73:	49 89 c7             	mov    %rax,%r15
    9b76:	0f 84 50 16 00 00    	je     b1cc <fwp_hof0.constprop.0+0x190c>
    9b7c:	48 89 05 6d 95 01 00 	mov    %rax,0x1956d(%rip)        # 230f0 <fwp_tapes>
    9b83:	4c 89 35 56 95 01 00 	mov    %r14,0x19556(%rip)        # 230e0 <fwp_tapes_cap>
    9b8a:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    9b8e:	31 c0                	xor    %eax,%eax
    9b90:	4d 89 e6             	mov    %r12,%r14
    9b93:	4c 01 f9             	add    %r15,%rcx
    9b96:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    9b9a:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    9ba1:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9ba5:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    9bac:	00 
    9bad:	48 29 f9             	sub    %rdi,%rcx
    9bb0:	83 c1 68             	add    $0x68,%ecx
    9bb3:	c1 e9 03             	shr    $0x3,%ecx
    9bb6:	f3 48 ab             	rep stos %rax,(%rdi)
    9bb9:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    9bbe:	48 89 05 23 95 01 00 	mov    %rax,0x19523(%rip)        # 230e8 <fwp_ntapes>
    9bc5:	4d 6b e6 68          	imul   $0x68,%r14,%r12
    9bc9:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9bcd:	48 8d 3d 8c 55 00 00 	lea    0x558c(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    9bd4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9bd9:	4d 01 fc             	add    %r15,%r12
    9bdc:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    9be3:	00 00 
    9be5:	e8 a6 97 ff ff       	call   3390 <getenv@plt>
    9bea:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    9bf0:	48 85 c0             	test   %rax,%rax
    9bf3:	0f 84 4f 0d 00 00    	je     a948 <fwp_hof0.constprop.0+0x1088>
    9bf9:	80 38 30             	cmpb   $0x30,(%rax)
    9bfc:	0f 85 46 0d 00 00    	jne    a948 <fwp_hof0.constprop.0+0x1088>
    9c02:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9c06:	0f 85 3c 0d 00 00    	jne    a948 <fwp_hof0.constprop.0+0x1088>
    9c0c:	41 8b 04 24          	mov    (%r12),%eax
    9c10:	49 8d 76 01          	lea    0x1(%r14),%rsi
    9c14:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    9c1b:	00 00 
    9c1d:	48 89 35 b4 94 01 00 	mov    %rsi,0x194b4(%rip)        # 230d8 <fwp_tape_next_slot>
    9c24:	8d 48 01             	lea    0x1(%rax),%ecx
    9c27:	48 8b 05 32 61 00 00 	mov    0x6132(%rip),%rax        # fd60 <msg.4+0x20>
    9c2e:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    9c35:	00 00 
    9c37:	41 89 0c 24          	mov    %ecx,(%r12)
    9c3b:	49 89 44 24 58       	mov    %rax,0x58(%r12)
    9c40:	48 8b 05 71 38 06 00 	mov    0x63871(%rip),%rax        # 6d4b8 <fwp_cleanups>
    9c47:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    9c4d:	48 85 c0             	test   %rax,%rax
    9c50:	75 1a                	jne    9c6c <fwp_hof0.constprop.0+0x3ac>
    9c52:	e9 69 15 00 00       	jmp    b1c0 <fwp_hof0.constprop.0+0x1900>
    9c57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c5e:	00 00 
    9c60:	48 8b 00             	mov    (%rax),%rax
    9c63:	48 85 c0             	test   %rax,%rax
    9c66:	0f 84 54 15 00 00    	je     b1c0 <fwp_hof0.constprop.0+0x1900>
    9c6c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    9c70:	75 ee                	jne    9c60 <fwp_hof0.constprop.0+0x3a0>
    9c72:	4c 8b 40 10          	mov    0x10(%rax),%r8
    9c76:	44 89 f7             	mov    %r14d,%edi
    9c79:	49 63 00             	movslq (%r8),%rax
    9c7c:	4d 89 44 24 50       	mov    %r8,0x50(%r12)
    9c81:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    9c86:	85 c0                	test   %eax,%eax
    9c88:	78 09                	js     9c93 <fwp_hof0.constprop.0+0x3d3>
    9c8a:	48 6b c0 68          	imul   $0x68,%rax,%rax
    9c8e:	45 89 74 07 58       	mov    %r14d,0x58(%r15,%rax,1)
    9c93:	41 89 38             	mov    %edi,(%r8)
    9c96:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9c9b:	45 31 ed             	xor    %r13d,%r13d
    9c9e:	48 89 f8             	mov    %rdi,%rax
    9ca1:	48 85 ff             	test   %rdi,%rdi
    9ca4:	0f 84 e6 0d 00 00    	je     aa90 <fwp_hof0.constprop.0+0x11d0>
    9caa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9cb0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9cb4:	49 83 c5 01          	add    $0x1,%r13
    9cb8:	48 85 c0             	test   %rax,%rax
    9cbb:	75 f3                	jne    9cb0 <fwp_hof0.constprop.0+0x3f0>
    9cbd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9cc2:	0f 1f 00             	nopl   (%rax)
    9cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9ccc:	00 00 00 00 
    9cd0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9cd4:	48 83 c0 01          	add    $0x1,%rax
    9cd8:	48 85 d2             	test   %rdx,%rdx
    9cdb:	75 f3                	jne    9cd0 <fwp_hof0.constprop.0+0x410>
    9cdd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9ce4:	ff ff 1f 
    9ce7:	48 39 c2             	cmp    %rax,%rdx
    9cea:	0f 82 63 14 00 00    	jb     b153 <fwp_hof0.constprop.0+0x1893>
    9cf0:	4d 85 ed             	test   %r13,%r13
    9cf3:	0f 8e 97 0d 00 00    	jle    aa90 <fwp_hof0.constprop.0+0x11d0>
    9cf9:	49 39 c5             	cmp    %rax,%r13
    9cfc:	4c 0f 47 e8          	cmova  %rax,%r13
    9d00:	4c 89 e8             	mov    %r13,%rax
    9d03:	48 c1 e8 3c          	shr    $0x3c,%rax
    9d07:	0f 85 46 14 00 00    	jne    b153 <fwp_hof0.constprop.0+0x1893>
    9d0d:	4f 8d 7c 2d 00       	lea    0x0(%r13,%r13,1),%r15
    9d12:	48 c1 e1 10          	shl    $0x10,%rcx
    9d16:	48 09 f1             	or     %rsi,%rcx
    9d19:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    9d20:	00 
    9d21:	be 02 00 00 00       	mov    $0x2,%esi
    9d26:	49 89 cc             	mov    %rcx,%r12
    9d29:	e8 e2 c1 ff ff       	call   5f10 <fwp_heap_alloc>
    9d2e:	4c 89 38             	mov    %r15,(%rax)
    9d31:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9d38:	49 89 c6             	mov    %rax,%r14
    9d3b:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9d42:	48 c1 e2 10          	shl    $0x10,%rdx
    9d46:	48 39 d0             	cmp    %rdx,%rax
    9d49:	0f 83 f1 0d 00 00    	jae    ab40 <fwp_hof0.constprop.0+0x1280>
    9d4f:	48 89 c2             	mov    %rax,%rdx
    9d52:	48 c1 ea 10          	shr    $0x10,%rdx
    9d56:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    9d5a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9d61:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    9d65:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9d69:	4d 85 ff             	test   %r15,%r15
    9d6c:	74 3a                	je     9da8 <fwp_hof0.constprop.0+0x4e8>
    9d6e:	0f b6 32             	movzbl (%rdx),%esi
    9d71:	40 80 fe 02          	cmp    $0x2,%sil
    9d75:	0f 84 86 0d 00 00    	je     ab01 <fwp_hof0.constprop.0+0x1241>
    9d7b:	40 80 fe 01          	cmp    $0x1,%sil
    9d7f:	75 27                	jne    9da8 <fwp_hof0.constprop.0+0x4e8>
    9d81:	8b 72 18             	mov    0x18(%rdx),%esi
    9d84:	0f b7 c0             	movzwl %ax,%eax
    9d87:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d8a:	48 0f af c6          	imul   %rsi,%rax
    9d8e:	48 c1 e8 20          	shr    $0x20,%rax
    9d92:	48 39 d0             	cmp    %rdx,%rax
    9d95:	73 11                	jae    9da8 <fwp_hof0.constprop.0+0x4e8>
    9d97:	49 01 c7             	add    %rax,%r15
    9d9a:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9d9e:	0f 84 70 0d 00 00    	je     ab14 <fwp_hof0.constprop.0+0x1254>
    9da4:	41 c6 07 01          	movb   $0x1,(%r15)
    9da8:	4d 85 ed             	test   %r13,%r13
    9dab:	74 47                	je     9df4 <fwp_hof0.constprop.0+0x534>
    9dad:	4c 89 e6             	mov    %r12,%rsi
    9db0:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9db5:	31 c0                	xor    %eax,%eax
    9db7:	48 c1 e6 20          	shl    $0x20,%rsi
    9dbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9dc0:	48 89 c1             	mov    %rax,%rcx
    9dc3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9dc8:	48 01 f1             	add    %rsi,%rcx
    9dcb:	0f 80 7f 99 ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9dd1:	66 48 0f 6e e1       	movq   %rcx,%xmm4
    9dd6:	48 89 c1             	mov    %rax,%rcx
    9dd9:	48 83 c0 01          	add    $0x1,%rax
    9ddd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9de1:	48 c1 e1 04          	shl    $0x4,%rcx
    9de5:	41 0f 11 44 0e 08    	movups %xmm0,0x8(%r14,%rcx,1)
    9deb:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9def:	4c 39 e8             	cmp    %r13,%rax
    9df2:	72 cc                	jb     9dc0 <fwp_hof0.constprop.0+0x500>
    9df4:	49 8b 06             	mov    (%r14),%rax
    9df7:	48 d1 e8             	shr    $1,%rax
    9dfa:	0f 84 50 0d 00 00    	je     ab50 <fwp_hof0.constprop.0+0x1290>
    9e00:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9e04:	48 89 f7             	mov    %rsi,%rdi
    9e07:	48 c1 ef 3c          	shr    $0x3c,%rdi
    9e0b:	0f 85 42 13 00 00    	jne    b153 <fwp_hof0.constprop.0+0x1893>
    9e11:	48 8d 14 36          	lea    (%rsi,%rsi,1),%rdx
    9e15:	48 85 f6             	test   %rsi,%rsi
    9e18:	74 49                	je     9e63 <fwp_hof0.constprop.0+0x5a3>
    9e1a:	48 c1 e0 04          	shl    $0x4,%rax
    9e1e:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    9e23:	49 89 d7             	mov    %rdx,%r15
    9e26:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    9e2a:	4d 8d 6c 06 f8       	lea    -0x8(%r14,%rax,1),%r13
    9e2f:	90                   	nop
    9e30:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    9e34:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    9e38:	48 83 c3 10          	add    $0x10,%rbx
    9e3c:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    9e40:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    9e44:	e8 a7 c9 ff ff       	call   67f0 <w120>
    9e49:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9e4e:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9e52:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    9e56:	49 39 dd             	cmp    %rbx,%r13
    9e59:	75 d5                	jne    9e30 <fwp_hof0.constprop.0+0x570>
    9e5b:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    9e60:	4c 89 fa             	mov    %r15,%rdx
    9e63:	49 89 16             	mov    %rdx,(%r14)
    9e66:	4c 89 f7             	mov    %r14,%rdi
    9e69:	4d 63 fc             	movslq %r12d,%r15
    9e6c:	e8 3f cb ff ff       	call   69b0 <w176.constprop.0>
    9e71:	4c 89 f7             	mov    %r14,%rdi
    9e74:	49 89 c5             	mov    %rax,%r13
    9e77:	e8 d4 e2 ff ff       	call   8150 <fwp_drop10>
    9e7c:	4c 89 ff             	mov    %r15,%rdi
    9e7f:	e8 ac a8 ff ff       	call   4730 <fwp_tape_of>
    9e84:	48 89 c6             	mov    %rax,%rsi
    9e87:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9e8c:	0f 85 af 13 00 00    	jne    b241 <fwp_hof0.constprop.0+0x1981>
    9e92:	48 89 c7             	mov    %rax,%rdi
    9e95:	e8 f6 9d ff ff       	call   3c90 <fwp_tape_unlink_scope>
    9e9a:	4c 8b 46 48          	mov    0x48(%rsi),%r8
    9e9e:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9ea3:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9eaa:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    9eae:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    9eb2:	66 49 0f 6e f8       	movq   %r8,%xmm7
    9eb7:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    9ebc:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    9ec1:	4c 8b 56 40          	mov    0x40(%rsi),%r10
    9ec5:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    9ec9:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    9ecf:	77 19                	ja     9eea <fwp_hof0.constprop.0+0x62a>
    9ed1:	41 0f b7 c4          	movzwl %r12w,%eax
    9ed5:	83 e8 01             	sub    $0x1,%eax
    9ed8:	48 98                	cltq
    9eda:	48 3b 05 f7 91 01 00 	cmp    0x191f7(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    9ee1:	7d 07                	jge    9eea <fwp_hof0.constprop.0+0x62a>
    9ee3:	48 89 05 ee 91 01 00 	mov    %rax,0x191ee(%rip)        # 230d8 <fwp_tape_next_slot>
    9eea:	48 8b 05 c7 35 06 00 	mov    0x635c7(%rip),%rax        # 6d4b8 <fwp_cleanups>
    9ef1:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9ef5:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9efc:	00 
    9efd:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9f01:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9f08:	00 
    9f09:	48 8d 05 50 b3 ff ff 	lea    -0x4cb0(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    9f10:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9f17:	00 
    9f18:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    9f1f:	00 
    9f20:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9f25:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9f2c:	00 
    9f2d:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    9f34:	00 
    9f35:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9f3c:	00 
    9f3d:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9f44:	00 
    9f45:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9f49:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9f4d:	48 89 05 64 35 06 00 	mov    %rax,0x63564(%rip)        # 6d4b8 <fwp_cleanups>
    9f54:	4c 89 94 24 e0 00 00 	mov    %r10,0xe0(%rsp)
    9f5b:	00 
    9f5c:	0f 29 9c 24 c0 00 00 	movaps %xmm3,0xc0(%rsp)
    9f63:	00 
    9f64:	0f 29 94 24 d0 00 00 	movaps %xmm2,0xd0(%rsp)
    9f6b:	00 
    9f6c:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    9f73:	00 
    9f74:	4d 85 ed             	test   %r13,%r13
    9f77:	0f 88 53 0d 00 00    	js     acd0 <fwp_hof0.constprop.0+0x1410>
    9f7d:	4c 89 e8             	mov    %r13,%rax
    9f80:	48 c1 f8 20          	sar    $0x20,%rax
    9f84:	49 39 c7             	cmp    %rax,%r15
    9f87:	0f 85 9b 11 00 00    	jne    b128 <fwp_hof0.constprop.0+0x1868>
    9f8d:	44 89 e9             	mov    %r13d,%ecx
    9f90:	49 89 cf             	mov    %rcx,%r15
    9f93:	48 39 ca             	cmp    %rcx,%rdx
    9f96:	0f 8e 98 11 00 00    	jle    b134 <fwp_hof0.constprop.0+0x1874>
    9f9c:	49 39 ce             	cmp    %rcx,%r14
    9f9f:	0f 8e d3 0b 00 00    	jle    ab78 <fwp_hof0.constprop.0+0x12b8>
    9fa5:	4d 39 c6             	cmp    %r8,%r14
    9fa8:	0f 8f 02 0c 00 00    	jg     abb0 <fwp_hof0.constprop.0+0x12f0>
    9fae:	4d 85 d2             	test   %r10,%r10
    9fb1:	0f 84 43 12 00 00    	je     b1fa <fwp_hof0.constprop.0+0x193a>
    9fb7:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
    9fbc:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    9fc0:	31 f6                	xor    %esi,%esi
    9fc2:	4c 89 d7             	mov    %r10,%rdi
    9fc5:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    9fca:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9fd1:	00 
    9fd2:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    9fd7:	e8 d4 94 ff ff       	call   34b0 <memset@plt>
    9fdc:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    9fe2:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    9fe8:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
    9fed:	49 89 c2             	mov    %rax,%r10
    9ff0:	f2 0f 10 05 70 5d 00 	movsd  0x5d70(%rip),%xmm0        # fd68 <msg.4+0x28>
    9ff7:	00 
    9ff8:	f2 41 0f 58 04 ca    	addsd  (%r10,%rcx,8),%xmm0
    9ffe:	f2 41 0f 11 04 ca    	movsd  %xmm0,(%r10,%rcx,8)
    a004:	4d 39 fe             	cmp    %r15,%r14
    a007:	0f 8f 8c 00 00 00    	jg     a099 <fwp_hof0.constprop.0+0x7d9>
    a00d:	0f 12 fb             	movhlps %xmm3,%xmm7
    a010:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    a015:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    a01a:	4d 29 f7             	sub    %r14,%r15
    a01d:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    a022:	0f 12 fa             	movhlps %xmm2,%xmm7
    a025:	4f 8d 24 f2          	lea    (%r10,%r14,8),%r12
    a029:	66 49 0f 7e f8       	movq   %xmm7,%r8
    a02e:	4a 8d 04 be          	lea    (%rsi,%r15,4),%rax
    a032:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a036:	48 29 f1             	sub    %rsi,%rcx
    a039:	4b 8d 14 f8          	lea    (%r8,%r15,8),%rdx
    a03d:	4d 29 c4             	sub    %r8,%r12
    a040:	4c 29 c7             	sub    %r8,%rdi
    a043:	eb 07                	jmp    a04c <fwp_hof0.constprop.0+0x78c>
    a045:	0f 1f 00             	nopl   (%rax)
    a048:	48 83 e8 04          	sub    $0x4,%rax
    a04c:	f2 41 0f 10 04 14    	movsd  (%r12,%rdx,1),%xmm0
    a052:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a056:	7a 02                	jp     a05a <fwp_hof0.constprop.0+0x79a>
    a058:	74 36                	je     a090 <fwp_hof0.constprop.0+0x7d0>
    a05a:	4c 63 04 01          	movslq (%rcx,%rax,1),%r8
    a05e:	45 85 c0             	test   %r8d,%r8d
    a061:	78 15                	js     a078 <fwp_hof0.constprop.0+0x7b8>
    a063:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    a068:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a06c:	f2 43 0f 58 0c c2    	addsd  (%r10,%r8,8),%xmm1
    a072:	f2 43 0f 11 0c c2    	movsd  %xmm1,(%r10,%r8,8)
    a078:	4c 63 00             	movslq (%rax),%r8
    a07b:	45 85 c0             	test   %r8d,%r8d
    a07e:	78 10                	js     a090 <fwp_hof0.constprop.0+0x7d0>
    a080:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    a084:	f2 43 0f 58 04 c2    	addsd  (%r10,%r8,8),%xmm0
    a08a:	f2 43 0f 11 04 c2    	movsd  %xmm0,(%r10,%r8,8)
    a090:	48 83 ea 08          	sub    $0x8,%rdx
    a094:	48 39 c6             	cmp    %rax,%rsi
    a097:	75 af                	jne    a048 <fwp_hof0.constprop.0+0x788>
    a099:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a0a0:	ff ff 1f 
    a0a3:	4c 39 f0             	cmp    %r14,%rax
    a0a6:	0f 82 bf 10 00 00    	jb     b16b <fwp_hof0.constprop.0+0x18ab>
    a0ac:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a0b3:	00 
    a0b4:	be 02 00 00 00       	mov    $0x2,%esi
    a0b9:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    a0be:	e8 4d be ff ff       	call   5f10 <fwp_heap_alloc>
    a0c3:	4d 85 f6             	test   %r14,%r14
    a0c6:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    a0cb:	4c 89 30             	mov    %r14,(%rax)
    a0ce:	49 89 c7             	mov    %rax,%r15
    a0d1:	74 1f                	je     a0f2 <fwp_hof0.constprop.0+0x832>
    a0d3:	66 90                	xchg   %ax,%ax
    a0d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a0dc:	00 00 00 00 
    a0e0:	49 8b 04 da          	mov    (%r10,%rbx,8),%rax
    a0e4:	49 89 44 df 08       	mov    %rax,0x8(%r15,%rbx,8)
    a0e9:	48 83 c3 01          	add    $0x1,%rbx
    a0ed:	49 39 de             	cmp    %rbx,%r14
    a0f0:	75 ee                	jne    a0e0 <fwp_hof0.constprop.0+0x820>
    a0f2:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
    a0f9:	00 
    a0fa:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a0ff:	4c 89 2d b2 33 06 00 	mov    %r13,0x633b2(%rip)        # 6d4b8 <fwp_cleanups>
    a106:	e8 55 b1 ff ff       	call   5260 <fwp_tape_buffers_release>
    a10b:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a112:	4c 89 f8             	mov    %r15,%rax
    a115:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a11c:	48 c1 e2 10          	shl    $0x10,%rdx
    a120:	48 39 d0             	cmp    %rdx,%rax
    a123:	73 59                	jae    a17e <fwp_hof0.constprop.0+0x8be>
    a125:	48 89 c2             	mov    %rax,%rdx
    a128:	48 c1 ea 10          	shr    $0x10,%rdx
    a12c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a130:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a137:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a13b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a13f:	4d 85 e4             	test   %r12,%r12
    a142:	74 3a                	je     a17e <fwp_hof0.constprop.0+0x8be>
    a144:	0f b6 0a             	movzbl (%rdx),%ecx
    a147:	80 f9 02             	cmp    $0x2,%cl
    a14a:	0f 84 b0 0b 00 00    	je     ad00 <fwp_hof0.constprop.0+0x1440>
    a150:	80 f9 01             	cmp    $0x1,%cl
    a153:	75 29                	jne    a17e <fwp_hof0.constprop.0+0x8be>
    a155:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a158:	0f b7 c0             	movzwl %ax,%eax
    a15b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a15e:	48 0f af c1          	imul   %rcx,%rax
    a162:	48 c1 e8 20          	shr    $0x20,%rax
    a166:	48 39 d0             	cmp    %rdx,%rax
    a169:	73 13                	jae    a17e <fwp_hof0.constprop.0+0x8be>
    a16b:	49 01 c4             	add    %rax,%r12
    a16e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a173:	0f 84 9b 0b 00 00    	je     ad14 <fwp_hof0.constprop.0+0x1454>
    a179:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a17e:	4c 3b 6c 24 38       	cmp    0x38(%rsp),%r13
    a183:	0f 85 c2 95 ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    a189:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    a190:	00 
    a191:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    a196:	48 89 05 1b 33 06 00 	mov    %rax,0x6331b(%rip)        # 6d4b8 <fwp_cleanups>
    a19d:	e8 5e d0 ff ff       	call   7200 <fwp_tape_scope_release>
    a1a2:	49 8b 07             	mov    (%r15),%rax
    a1a5:	49 89 c6             	mov    %rax,%r14
    a1a8:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a1ad:	48 85 c0             	test   %rax,%rax
    a1b0:	0f 88 2a 08 00 00    	js     a9e0 <fwp_hof0.constprop.0+0x1120>
    a1b6:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a1bd:	4c 89 f8             	mov    %r15,%rax
    a1c0:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a1c7:	48 c1 e2 10          	shl    $0x10,%rdx
    a1cb:	48 39 d0             	cmp    %rdx,%rax
    a1ce:	0f 83 0c 08 00 00    	jae    a9e0 <fwp_hof0.constprop.0+0x1120>
    a1d4:	48 89 c2             	mov    %rax,%rdx
    a1d7:	48 c1 ea 10          	shr    $0x10,%rdx
    a1db:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a1df:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a1e6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1ea:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a1ee:	48 85 c9             	test   %rcx,%rcx
    a1f1:	0f 84 e9 07 00 00    	je     a9e0 <fwp_hof0.constprop.0+0x1120>
    a1f7:	0f b6 32             	movzbl (%rdx),%esi
    a1fa:	40 80 fe 02          	cmp    $0x2,%sil
    a1fe:	0f 84 cc 07 00 00    	je     a9d0 <fwp_hof0.constprop.0+0x1110>
    a204:	40 80 fe 01          	cmp    $0x1,%sil
    a208:	0f 85 d2 07 00 00    	jne    a9e0 <fwp_hof0.constprop.0+0x1120>
    a20e:	8b 72 18             	mov    0x18(%rdx),%esi
    a211:	0f b7 c0             	movzwl %ax,%eax
    a214:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a217:	48 0f af c6          	imul   %rsi,%rax
    a21b:	48 c1 e8 20          	shr    $0x20,%rax
    a21f:	48 39 d0             	cmp    %rdx,%rax
    a222:	0f 83 b8 07 00 00    	jae    a9e0 <fwp_hof0.constprop.0+0x1120>
    a228:	48 01 c1             	add    %rax,%rcx
    a22b:	80 39 01             	cmpb   $0x1,(%rcx)
    a22e:	0f 85 ac 07 00 00    	jne    a9e0 <fwp_hof0.constprop.0+0x1120>
    a234:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    a239:	4d 89 fc             	mov    %r15,%r12
    a23c:	31 ff                	xor    %edi,%edi
    a23e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a243:	48 8d 50 08          	lea    0x8(%rax),%rdx
    a247:	31 c0                	xor    %eax,%eax
    a249:	4d 85 f6             	test   %r14,%r14
    a24c:	75 2c                	jne    a27a <fwp_hof0.constprop.0+0x9ba>
    a24e:	eb 40                	jmp    a290 <fwp_hof0.constprop.0+0x9d0>
    a250:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a255:	0f 88 e5 0e 00 00    	js     b140 <fwp_hof0.constprop.0+0x1880>
    a25b:	f2 0f 10 05 1d 5b 00 	movsd  0x5b1d(%rip),%xmm0        # fd80 <msg.4+0x40>
    a262:	00 
    a263:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    a268:	48 83 c0 01          	add    $0x1,%rax
    a26c:	48 83 c2 08          	add    $0x8,%rdx
    a270:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    a275:	49 39 c6             	cmp    %rax,%r14
    a278:	74 16                	je     a290 <fwp_hof0.constprop.0+0x9d0>
    a27a:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    a27e:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a282:	79 cc                	jns    a250 <fwp_hof0.constprop.0+0x990>
    a284:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    a288:	eb c6                	jmp    a250 <fwp_hof0.constprop.0+0x990>
    a28a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a290:	e8 bb de ff ff       	call   8150 <fwp_drop10>
    a295:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a29a:	31 d2                	xor    %edx,%edx
    a29c:	48 89 f8             	mov    %rdi,%rax
    a29f:	48 85 ff             	test   %rdi,%rdi
    a2a2:	0f 84 ac 0c 00 00    	je     af54 <fwp_hof0.constprop.0+0x1694>
    a2a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a2af:	00 
    a2b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a2b4:	48 83 c2 01          	add    $0x1,%rdx
    a2b8:	48 85 c0             	test   %rax,%rax
    a2bb:	75 f3                	jne    a2b0 <fwp_hof0.constprop.0+0x9f0>
    a2bd:	49 8b 04 24          	mov    (%r12),%rax
    a2c1:	49 89 c7             	mov    %rax,%r15
    a2c4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    a2c9:	48 85 c0             	test   %rax,%rax
    a2cc:	0f 88 cb 05 00 00    	js     a89d <fwp_hof0.constprop.0+0xfdd>
    a2d2:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    a2d9:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a2de:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    a2e5:	48 c1 e0 10          	shl    $0x10,%rax
    a2e9:	48 39 c1             	cmp    %rax,%rcx
    a2ec:	0f 83 ab 05 00 00    	jae    a89d <fwp_hof0.constprop.0+0xfdd>
    a2f2:	48 89 c8             	mov    %rcx,%rax
    a2f5:	48 c1 e8 10          	shr    $0x10,%rax
    a2f9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    a2fd:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    a304:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    a308:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a30c:	48 85 ff             	test   %rdi,%rdi
    a30f:	0f 84 88 05 00 00    	je     a89d <fwp_hof0.constprop.0+0xfdd>
    a315:	0f b6 06             	movzbl (%rsi),%eax
    a318:	3c 02                	cmp    $0x2,%al
    a31a:	0f 84 68 05 00 00    	je     a888 <fwp_hof0.constprop.0+0xfc8>
    a320:	3c 01                	cmp    $0x1,%al
    a322:	0f 85 69 05 00 00    	jne    a891 <fwp_hof0.constprop.0+0xfd1>
    a328:	8b 46 18             	mov    0x18(%rsi),%eax
    a32b:	0f b7 c9             	movzwl %cx,%ecx
    a32e:	48 0f af c8          	imul   %rax,%rcx
    a332:	8b 46 1c             	mov    0x1c(%rsi),%eax
    a335:	48 c1 e9 20          	shr    $0x20,%rcx
    a339:	48 39 c1             	cmp    %rax,%rcx
    a33c:	0f 83 4f 05 00 00    	jae    a891 <fwp_hof0.constprop.0+0xfd1>
    a342:	48 01 cf             	add    %rcx,%rdi
    a345:	80 3f 01             	cmpb   $0x1,(%rdi)
    a348:	0f 85 43 05 00 00    	jne    a891 <fwp_hof0.constprop.0+0xfd1>
    a34e:	49 39 d7             	cmp    %rdx,%r15
    a351:	48 89 d0             	mov    %rdx,%rax
    a354:	49 0f 46 c7          	cmovbe %r15,%rax
    a358:	48 85 c0             	test   %rax,%rax
    a35b:	0f 84 eb 0d 00 00    	je     b14c <fwp_hof0.constprop.0+0x188c>
    a361:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
    a368:	00 
    a369:	49 8d 5c 24 08       	lea    0x8(%r12),%rbx
    a36e:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a373:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a378:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    a37f:	00 
    a380:	31 d2                	xor    %edx,%edx
    a382:	49 8d 78 08          	lea    0x8(%r8),%rdi
    a386:	eb 54                	jmp    a3dc <fwp_hof0.constprop.0+0xb1c>
    a388:	90                   	nop
    a389:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a390:	00 00 00 00 
    a394:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a39b:	00 00 00 00 
    a39f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3a6:	00 00 00 00 
    a3aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3b1:	00 00 00 00 
    a3b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3bc:	00 00 00 00 
    a3c0:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a3c5:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a3ca:	f2 0f 11 04 13       	movsd  %xmm0,(%rbx,%rdx,1)
    a3cf:	48 83 c2 08          	add    $0x8,%rdx
    a3d3:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a3d7:	49 39 d1             	cmp    %rdx,%r9
    a3da:	74 14                	je     a3f0 <fwp_hof0.constprop.0+0xb30>
    a3dc:	48 89 fe             	mov    %rdi,%rsi
    a3df:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a3e4:	79 da                	jns    a3c0 <fwp_hof0.constprop.0+0xb00>
    a3e6:	49 8b 70 10          	mov    0x10(%r8),%rsi
    a3ea:	eb d4                	jmp    a3c0 <fwp_hof0.constprop.0+0xb00>
    a3ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a3f0:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a3f5:	48 85 c9             	test   %rcx,%rcx
    a3f8:	0f 84 22 0d 00 00    	je     b120 <fwp_hof0.constprop.0+0x1860>
    a3fe:	4c 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%r9
    a405:	4c 8b 95 b0 13 00 00 	mov    0x13b0(%rbp),%r10
    a40c:	45 31 ff             	xor    %r15d,%r15d
    a40f:	4c 8b 9d f8 13 00 00 	mov    0x13f8(%rbp),%r11
    a416:	49 c1 e1 10          	shl    $0x10,%r9
    a41a:	eb 1a                	jmp    a436 <fwp_hof0.constprop.0+0xb76>
    a41c:	0f 1f 40 00          	nopl   0x0(%rax)
    a420:	49 83 c7 01          	add    $0x1,%r15
    a424:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a428:	49 39 c7             	cmp    %rax,%r15
    a42b:	0f 83 5f 01 00 00    	jae    a590 <fwp_hof0.constprop.0+0xcd0>
    a431:	48 85 c9             	test   %rcx,%rcx
    a434:	74 56                	je     a48c <fwp_hof0.constprop.0+0xbcc>
    a436:	48 89 ca             	mov    %rcx,%rdx
    a439:	4c 29 d2             	sub    %r10,%rdx
    a43c:	4c 39 ca             	cmp    %r9,%rdx
    a43f:	73 4b                	jae    a48c <fwp_hof0.constprop.0+0xbcc>
    a441:	48 89 d6             	mov    %rdx,%rsi
    a444:	48 c1 ee 10          	shr    $0x10,%rsi
    a448:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a44c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a450:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a454:	48 85 ff             	test   %rdi,%rdi
    a457:	74 33                	je     a48c <fwp_hof0.constprop.0+0xbcc>
    a459:	44 0f b6 06          	movzbl (%rsi),%r8d
    a45d:	41 80 f8 02          	cmp    $0x2,%r8b
    a461:	0f 84 11 01 00 00    	je     a578 <fwp_hof0.constprop.0+0xcb8>
    a467:	41 80 f8 01          	cmp    $0x1,%r8b
    a46b:	75 1f                	jne    a48c <fwp_hof0.constprop.0+0xbcc>
    a46d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a471:	0f b7 d2             	movzwl %dx,%edx
    a474:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a477:	49 0f af d0          	imul   %r8,%rdx
    a47b:	48 c1 ea 20          	shr    $0x20,%rdx
    a47f:	48 39 f2             	cmp    %rsi,%rdx
    a482:	73 08                	jae    a48c <fwp_hof0.constprop.0+0xbcc>
    a484:	48 01 d7             	add    %rdx,%rdi
    a487:	80 3f 01             	cmpb   $0x1,(%rdi)
    a48a:	74 94                	je     a420 <fwp_hof0.constprop.0+0xb60>
    a48c:	49 39 c7             	cmp    %rax,%r15
    a48f:	0f 83 fb 00 00 00    	jae    a590 <fwp_hof0.constprop.0+0xcd0>
    a495:	49 89 c5             	mov    %rax,%r13
    a498:	45 31 f6             	xor    %r14d,%r14d
    a49b:	eb 37                	jmp    a4d4 <fwp_hof0.constprop.0+0xc14>
    a49d:	0f 1f 00             	nopl   (%rax)
    a4a0:	40 80 fe 01          	cmp    $0x1,%sil
    a4a4:	75 25                	jne    a4cb <fwp_hof0.constprop.0+0xc0b>
    a4a6:	8b 71 18             	mov    0x18(%rcx),%esi
    a4a9:	0f b7 c0             	movzwl %ax,%eax
    a4ac:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a4af:	48 0f af c6          	imul   %rsi,%rax
    a4b3:	48 c1 e8 20          	shr    $0x20,%rax
    a4b7:	48 39 c8             	cmp    %rcx,%rax
    a4ba:	73 0f                	jae    a4cb <fwp_hof0.constprop.0+0xc0b>
    a4bc:	48 01 c2             	add    %rax,%rdx
    a4bf:	80 3a ff             	cmpb   $0xff,(%rdx)
    a4c2:	0f 84 60 06 00 00    	je     ab28 <fwp_hof0.constprop.0+0x1268>
    a4c8:	c6 02 01             	movb   $0x1,(%rdx)
    a4cb:	4d 39 ef             	cmp    %r13,%r15
    a4ce:	0f 83 8c 00 00 00    	jae    a560 <fwp_hof0.constprop.0+0xca0>
    a4d4:	49 83 ed 01          	sub    $0x1,%r13
    a4d8:	66 49 0f 6e f6       	movq   %r14,%xmm6
    a4dd:	bf 01 00 00 00       	mov    $0x1,%edi
    a4e2:	f3 42 0f 7e 04 eb    	movq   (%rbx,%r13,8),%xmm0
    a4e8:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    a4ef:	00 
    a4f0:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a4f4:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    a4fb:	00 
    a4fc:	e8 ff bb ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a501:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a508:	49 89 c6             	mov    %rax,%r14
    a50b:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a512:	48 c1 e2 10          	shl    $0x10,%rdx
    a516:	48 39 d0             	cmp    %rdx,%rax
    a519:	73 b0                	jae    a4cb <fwp_hof0.constprop.0+0xc0b>
    a51b:	48 89 c2             	mov    %rax,%rdx
    a51e:	48 c1 ea 10          	shr    $0x10,%rdx
    a522:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a526:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a52d:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a531:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a535:	48 85 d2             	test   %rdx,%rdx
    a538:	74 91                	je     a4cb <fwp_hof0.constprop.0+0xc0b>
    a53a:	0f b6 31             	movzbl (%rcx),%esi
    a53d:	40 80 fe 02          	cmp    $0x2,%sil
    a541:	0f 85 59 ff ff ff    	jne    a4a0 <fwp_hof0.constprop.0+0xbe0>
    a547:	66 85 c0             	test   %ax,%ax
    a54a:	0f 84 6f ff ff ff    	je     a4bf <fwp_hof0.constprop.0+0xbff>
    a550:	4d 39 ef             	cmp    %r13,%r15
    a553:	0f 82 7b ff ff ff    	jb     a4d4 <fwp_hof0.constprop.0+0xc14>
    a559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a560:	4d 85 ff             	test   %r15,%r15
    a563:	75 2e                	jne    a593 <fwp_hof0.constprop.0+0xcd3>
    a565:	8b 44 24 30          	mov    0x30(%rsp),%eax
    a569:	85 c0                	test   %eax,%eax
    a56b:	49 0f 45 df          	cmovne %r15,%rbx
    a56f:	eb 62                	jmp    a5d3 <fwp_hof0.constprop.0+0xd13>
    a571:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a578:	66 85 d2             	test   %dx,%dx
    a57b:	0f 84 06 ff ff ff    	je     a487 <fwp_hof0.constprop.0+0xbc7>
    a581:	49 39 c7             	cmp    %rax,%r15
    a584:	0f 82 0b ff ff ff    	jb     a495 <fwp_hof0.constprop.0+0xbd5>
    a58a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a590:	45 31 f6             	xor    %r14d,%r14d
    a593:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a598:	48 89 da             	mov    %rbx,%rdx
    a59b:	4e 8d 0c fb          	lea    (%rbx,%r15,8),%r9
    a59f:	90                   	nop
    a5a0:	48 8b 0a             	mov    (%rdx),%rcx
    a5a3:	48 83 c2 08          	add    $0x8,%rdx
    a5a7:	48 89 c7             	mov    %rax,%rdi
    a5aa:	48 89 48 08          	mov    %rcx,0x8(%rax)
    a5ae:	48 8b 40 10          	mov    0x10(%rax),%rax
    a5b2:	49 39 d1             	cmp    %rdx,%r9
    a5b5:	75 e9                	jne    a5a0 <fwp_hof0.constprop.0+0xce0>
    a5b7:	8b 54 24 30          	mov    0x30(%rsp),%edx
    a5bb:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    a5bf:	85 d2                	test   %edx,%edx
    a5c1:	0f 84 61 07 00 00    	je     ad28 <fwp_hof0.constprop.0+0x1468>
    a5c7:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    a5cc:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a5d1:	31 db                	xor    %ebx,%ebx
    a5d3:	48 89 df             	mov    %rbx,%rdi
    a5d6:	e8 35 b4 ff ff       	call   5a10 <fwp_mem_free>
    a5db:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a5e0:	e8 6b db ff ff       	call   8150 <fwp_drop10>
    a5e5:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a5ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a5f1:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a5f8:	48 c1 e2 10          	shl    $0x10,%rdx
    a5fc:	48 39 d0             	cmp    %rdx,%rax
    a5ff:	73 6f                	jae    a670 <fwp_hof0.constprop.0+0xdb0>
    a601:	48 89 c2             	mov    %rax,%rdx
    a604:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a60b:	48 c1 ea 10          	shr    $0x10,%rdx
    a60f:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a613:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a617:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a61b:	4d 85 e4             	test   %r12,%r12
    a61e:	74 50                	je     a670 <fwp_hof0.constprop.0+0xdb0>
    a620:	0f b6 0a             	movzbl (%rdx),%ecx
    a623:	80 f9 02             	cmp    $0x2,%cl
    a626:	0f 84 84 06 00 00    	je     acb0 <fwp_hof0.constprop.0+0x13f0>
    a62c:	80 f9 01             	cmp    $0x1,%cl
    a62f:	75 3f                	jne    a670 <fwp_hof0.constprop.0+0xdb0>
    a631:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a634:	0f b7 c0             	movzwl %ax,%eax
    a637:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a63a:	48 0f af c1          	imul   %rcx,%rax
    a63e:	48 c1 e8 20          	shr    $0x20,%rax
    a642:	48 39 d0             	cmp    %rdx,%rax
    a645:	73 29                	jae    a670 <fwp_hof0.constprop.0+0xdb0>
    a647:	49 01 c4             	add    %rax,%r12
    a64a:	41 0f b6 04 24       	movzbl (%r12),%eax
    a64f:	84 c0                	test   %al,%al
    a651:	74 1d                	je     a670 <fwp_hof0.constprop.0+0xdb0>
    a653:	3c 01                	cmp    $0x1,%al
    a655:	0f 84 e5 06 00 00    	je     ad40 <fwp_hof0.constprop.0+0x1480>
    a65b:	3c ff                	cmp    $0xff,%al
    a65d:	0f 84 6c 09 00 00    	je     afcf <fwp_hof0.constprop.0+0x170f>
    a663:	83 e8 01             	sub    $0x1,%eax
    a666:	41 88 04 24          	mov    %al,(%r12)
    a66a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a670:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    a676:	0f 85 dc 05 00 00    	jne    ac58 <fwp_hof0.constprop.0+0x1398>
    a67c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a681:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a685:	4c 89 f6             	mov    %r14,%rsi
    a688:	4d 89 f4             	mov    %r14,%r12
    a68b:	b9 01 00 00 00       	mov    $0x1,%ecx
    a690:	48 8d 15 09 85 00 00 	lea    0x8509(%rip),%rdx        # 12ba0 <d0>
    a697:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a69e:	00 00 00 00 00 
    a6a3:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    a6aa:	00 
    a6ab:	e8 d0 e1 ff ff       	call   8880 <fwp_write>
    a6b0:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
    a6b7:	00 
    a6b8:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
    a6bf:	00 
    a6c0:	48 8d 05 a5 49 00 00 	lea    0x49a5(%rip),%rax        # f06c <_IO_stdin_used+0x6c>
    a6c7:	4d 85 f6             	test   %r14,%r14
    a6ca:	4c 0f 44 f0          	cmove  %rax,%r14
    a6ce:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a6d2:	0f 87 d9 0a 00 00    	ja     b1b1 <fwp_hof0.constprop.0+0x18f1>
    a6d8:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a6dc:	be 01 00 00 00       	mov    $0x1,%esi
    a6e1:	e8 2a b8 ff ff       	call   5f10 <fwp_heap_alloc>
    a6e6:	4c 89 fa             	mov    %r15,%rdx
    a6e9:	4c 89 f6             	mov    %r14,%rsi
    a6ec:	4c 89 38             	mov    %r15,(%rax)
    a6ef:	48 89 c3             	mov    %rax,%rbx
    a6f2:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a6f6:	4c 8d 68 08          	lea    0x8(%rax),%r13
    a6fa:	e8 81 8e ff ff       	call   3580 <memcpy@plt>
    a6ff:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a705:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    a70c:	00 
    a70d:	e8 9e 8c ff ff       	call   33b0 <free@plt>
    a712:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a719:	48 89 d8             	mov    %rbx,%rax
    a71c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a723:	48 c1 e2 10          	shl    $0x10,%rdx
    a727:	48 39 d0             	cmp    %rdx,%rax
    a72a:	73 57                	jae    a783 <fwp_hof0.constprop.0+0xec3>
    a72c:	48 89 c2             	mov    %rax,%rdx
    a72f:	48 c1 ea 10          	shr    $0x10,%rdx
    a733:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a737:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a73e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a742:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a746:	4d 85 ff             	test   %r15,%r15
    a749:	74 38                	je     a783 <fwp_hof0.constprop.0+0xec3>
    a74b:	0f b6 0a             	movzbl (%rdx),%ecx
    a74e:	80 f9 02             	cmp    $0x2,%cl
    a751:	0f 84 a1 07 00 00    	je     aef8 <fwp_hof0.constprop.0+0x1638>
    a757:	80 f9 01             	cmp    $0x1,%cl
    a75a:	75 27                	jne    a783 <fwp_hof0.constprop.0+0xec3>
    a75c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a75f:	0f b7 c0             	movzwl %ax,%eax
    a762:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a765:	48 0f af c1          	imul   %rcx,%rax
    a769:	48 c1 e8 20          	shr    $0x20,%rax
    a76d:	48 39 d0             	cmp    %rdx,%rax
    a770:	73 11                	jae    a783 <fwp_hof0.constprop.0+0xec3>
    a772:	49 01 c7             	add    %rax,%r15
    a775:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a779:	0f 84 8c 07 00 00    	je     af0b <fwp_hof0.constprop.0+0x164b>
    a77f:	41 c6 07 01          	movb   $0x1,(%r15)
    a783:	4c 89 e7             	mov    %r12,%rdi
    a786:	e8 d5 d5 ff ff       	call   7d60 <fwp_drop0>
    a78b:	48 8b 13             	mov    (%rbx),%rdx
    a78e:	be 01 00 00 00       	mov    $0x1,%esi
    a793:	4c 89 ef             	mov    %r13,%rdi
    a796:	48 8b 0d e3 2c 06 00 	mov    0x62ce3(%rip),%rcx        # 6d480 <fwp_prog_out>
    a79d:	e8 be 8e ff ff       	call   3660 <fwrite@plt>
    a7a2:	48 8b 35 d7 2c 06 00 	mov    0x62cd7(%rip),%rsi        # 6d480 <fwp_prog_out>
    a7a9:	bf 0a 00 00 00       	mov    $0xa,%edi
    a7ae:	e8 1d 8d ff ff       	call   34d0 <fputc@plt>
    a7b3:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a7ba:	48 89 d8             	mov    %rbx,%rax
    a7bd:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a7c4:	48 c1 e2 10          	shl    $0x10,%rdx
    a7c8:	48 39 d0             	cmp    %rdx,%rax
    a7cb:	73 73                	jae    a840 <fwp_hof0.constprop.0+0xf80>
    a7cd:	48 89 c2             	mov    %rax,%rdx
    a7d0:	48 c1 ea 10          	shr    $0x10,%rdx
    a7d4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a7d8:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a7df:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a7e3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a7e7:	4d 85 e4             	test   %r12,%r12
    a7ea:	74 54                	je     a840 <fwp_hof0.constprop.0+0xf80>
    a7ec:	0f b6 0a             	movzbl (%rdx),%ecx
    a7ef:	80 f9 02             	cmp    $0x2,%cl
    a7f2:	0f 84 28 07 00 00    	je     af20 <fwp_hof0.constprop.0+0x1660>
    a7f8:	80 f9 01             	cmp    $0x1,%cl
    a7fb:	75 43                	jne    a840 <fwp_hof0.constprop.0+0xf80>
    a7fd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a800:	0f b7 c0             	movzwl %ax,%eax
    a803:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a806:	48 0f af c1          	imul   %rcx,%rax
    a80a:	48 c1 e8 20          	shr    $0x20,%rax
    a80e:	48 39 d0             	cmp    %rdx,%rax
    a811:	73 2d                	jae    a840 <fwp_hof0.constprop.0+0xf80>
    a813:	49 01 c4             	add    %rax,%r12
    a816:	41 0f b6 04 24       	movzbl (%r12),%eax
    a81b:	84 c0                	test   %al,%al
    a81d:	74 21                	je     a840 <fwp_hof0.constprop.0+0xf80>
    a81f:	3c 01                	cmp    $0x1,%al
    a821:	0f 84 17 07 00 00    	je     af3e <fwp_hof0.constprop.0+0x167e>
    a827:	3c ff                	cmp    $0xff,%al
    a829:	0f 84 71 08 00 00    	je     b0a0 <fwp_hof0.constprop.0+0x17e0>
    a82f:	83 e8 01             	sub    $0x1,%eax
    a832:	41 88 04 24          	mov    %al,(%r12)
    a836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a83d:	00 00 00 
    a840:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a845:	48 8b 40 10          	mov    0x10(%rax),%rax
    a849:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a84e:	48 85 c0             	test   %rax,%rax
    a851:	0f 85 a9 f0 ff ff    	jne    9900 <fwp_hof0.constprop.0+0x40>
    a857:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    a85e:	00 
    a85f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a866:	00 00 
    a868:	0f 85 eb 09 00 00    	jne    b259 <fwp_hof0.constprop.0+0x1999>
    a86e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    a875:	31 c0                	xor    %eax,%eax
    a877:	5b                   	pop    %rbx
    a878:	5d                   	pop    %rbp
    a879:	41 5c                	pop    %r12
    a87b:	41 5d                	pop    %r13
    a87d:	41 5e                	pop    %r14
    a87f:	41 5f                	pop    %r15
    a881:	c3                   	ret
    a882:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a888:	66 85 c9             	test   %cx,%cx
    a88b:	0f 84 b4 fa ff ff    	je     a345 <fwp_hof0.constprop.0+0xa85>
    a891:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    a897:	0f 84 ba 02 00 00    	je     ab57 <fwp_hof0.constprop.0+0x1297>
    a89d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a8a2:	45 31 f6             	xor    %r14d,%r14d
    a8a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8ac:	00 00 00 00 
    a8b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a8b4:	4c 89 f2             	mov    %r14,%rdx
    a8b7:	49 83 c6 01          	add    $0x1,%r14
    a8bb:	48 85 c0             	test   %rax,%rax
    a8be:	75 f0                	jne    a8b0 <fwp_hof0.constprop.0+0xff0>
    a8c0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a8c7:	ff ff 1f 
    a8ca:	4c 39 f0             	cmp    %r14,%rax
    a8cd:	0f 82 80 08 00 00    	jb     b153 <fwp_hof0.constprop.0+0x1893>
    a8d3:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a8da:	00 
    a8db:	be 02 00 00 00       	mov    $0x2,%esi
    a8e0:	e8 2b b6 ff ff       	call   5f10 <fwp_heap_alloc>
    a8e5:	4d 39 f7             	cmp    %r14,%r15
    a8e8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a8ed:	48 89 c3             	mov    %rax,%rbx
    a8f0:	4c 89 f0             	mov    %r14,%rax
    a8f3:	49 0f 46 c7          	cmovbe %r15,%rax
    a8f7:	48 89 d9             	mov    %rbx,%rcx
    a8fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a900:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a904:	48 83 c1 08          	add    $0x8,%rcx
    a908:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a90c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a910:	48 85 d2             	test   %rdx,%rdx
    a913:	75 eb                	jne    a900 <fwp_hof0.constprop.0+0x1040>
    a915:	48 85 c0             	test   %rax,%rax
    a918:	0f 84 4b 02 00 00    	je     ab69 <fwp_hof0.constprop.0+0x12a9>
    a91e:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    a925:	00 
    a926:	e9 43 fa ff ff       	jmp    a36e <fwp_hof0.constprop.0+0xaae>
    a92b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a930:	4d 39 f4             	cmp    %r14,%r12
    a933:	0f 84 e7 f1 ff ff    	je     9b20 <fwp_hof0.constprop.0+0x260>
    a939:	4c 8b 3d b0 87 01 00 	mov    0x187b0(%rip),%r15        # 230f0 <fwp_tapes>
    a940:	e9 80 f2 ff ff       	jmp    9bc5 <fwp_hof0.constprop.0+0x305>
    a945:	0f 1f 00             	nopl   (%rax)
    a948:	48 83 3d 38 87 01 00 	cmpq   $0x0,0x18738(%rip)        # 23088 <fwp_tape_cached_bytes>
    a94f:	00 
    a950:	0f 84 b6 f2 ff ff    	je     9c0c <fwp_hof0.constprop.0+0x34c>
    a956:	66 0f 6f 0d 42 87 01 	movdqa 0x18742(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a95d:	00 
    a95e:	48 c7 05 1f 87 01 00 	movq   $0x0,0x1871f(%rip)        # 23088 <fwp_tape_cached_bytes>
    a965:	00 00 00 00 
    a969:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    a96f:	48 8b 05 4a 87 01 00 	mov    0x1874a(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a976:	66 0f 6f 0d 32 87 01 	movdqa 0x18732(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    a97d:	00 
    a97e:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    a983:	48 8b 05 3e 87 01 00 	mov    0x1873e(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    a98a:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    a990:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a994:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    a999:	48 8b 05 30 87 01 00 	mov    0x18730(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    a9a0:	0f 29 0d f9 86 01 00 	movaps %xmm1,0x186f9(%rip)        # 230a0 <fwp_tape_workspace>
    a9a7:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    a9ac:	0f 29 0d fd 86 01 00 	movaps %xmm1,0x186fd(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a9b3:	48 c7 05 12 87 01 00 	movq   $0x0,0x18712(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    a9ba:	00 00 00 00 
    a9be:	0f 29 0d fb 86 01 00 	movaps %xmm1,0x186fb(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a9c5:	e9 42 f2 ff ff       	jmp    9c0c <fwp_hof0.constprop.0+0x34c>
    a9ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9d0:	66 85 c0             	test   %ax,%ax
    a9d3:	0f 84 52 f8 ff ff    	je     a22b <fwp_hof0.constprop.0+0x96b>
    a9d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9e0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a9e7:	ff ff 1f 
    a9ea:	4c 39 f0             	cmp    %r14,%rax
    a9ed:	0f 82 78 07 00 00    	jb     b16b <fwp_hof0.constprop.0+0x18ab>
    a9f3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a9fa:	00 
    a9fb:	be 01 00 00 00       	mov    $0x1,%esi
    aa00:	e8 0b b5 ff ff       	call   5f10 <fwp_heap_alloc>
    aa05:	4c 89 30             	mov    %r14,(%rax)
    aa08:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aa0f:	49 89 c4             	mov    %rax,%r12
    aa12:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    aa17:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aa1e:	48 c1 e2 10          	shl    $0x10,%rdx
    aa22:	48 39 d0             	cmp    %rdx,%rax
    aa25:	73 57                	jae    aa7e <fwp_hof0.constprop.0+0x11be>
    aa27:	48 89 c2             	mov    %rax,%rdx
    aa2a:	48 c1 ea 10          	shr    $0x10,%rdx
    aa2e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa32:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aa39:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    aa3d:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    aa41:	48 85 db             	test   %rbx,%rbx
    aa44:	74 38                	je     aa7e <fwp_hof0.constprop.0+0x11be>
    aa46:	0f b6 31             	movzbl (%rcx),%esi
    aa49:	40 80 fe 02          	cmp    $0x2,%sil
    aa4d:	0f 84 95 03 00 00    	je     ade8 <fwp_hof0.constprop.0+0x1528>
    aa53:	40 80 fe 01          	cmp    $0x1,%sil
    aa57:	75 25                	jne    aa7e <fwp_hof0.constprop.0+0x11be>
    aa59:	8b 71 18             	mov    0x18(%rcx),%esi
    aa5c:	0f b7 c0             	movzwl %ax,%eax
    aa5f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aa62:	48 0f af c6          	imul   %rsi,%rax
    aa66:	48 c1 e8 20          	shr    $0x20,%rax
    aa6a:	48 39 c8             	cmp    %rcx,%rax
    aa6d:	73 0f                	jae    aa7e <fwp_hof0.constprop.0+0x11be>
    aa6f:	48 01 c3             	add    %rax,%rbx
    aa72:	80 3b ff             	cmpb   $0xff,(%rbx)
    aa75:	0f 84 7f 03 00 00    	je     adfa <fwp_hof0.constprop.0+0x153a>
    aa7b:	c6 03 01             	movb   $0x1,(%rbx)
    aa7e:	4c 89 ff             	mov    %r15,%rdi
    aa81:	e9 b8 f7 ff ff       	jmp    a23e <fwp_hof0.constprop.0+0x97e>
    aa86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa8d:	00 00 00 
    aa90:	48 c1 e1 10          	shl    $0x10,%rcx
    aa94:	bf 08 00 00 00       	mov    $0x8,%edi
    aa99:	48 09 f1             	or     %rsi,%rcx
    aa9c:	be 02 00 00 00       	mov    $0x2,%esi
    aaa1:	49 89 cc             	mov    %rcx,%r12
    aaa4:	e8 67 b4 ff ff       	call   5f10 <fwp_heap_alloc>
    aaa9:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    aab0:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aab7:	49 89 c6             	mov    %rax,%r14
    aaba:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aac1:	48 c1 e2 10          	shl    $0x10,%rdx
    aac5:	48 39 d0             	cmp    %rdx,%rax
    aac8:	0f 83 82 00 00 00    	jae    ab50 <fwp_hof0.constprop.0+0x1290>
    aace:	48 89 c2             	mov    %rax,%rdx
    aad1:	48 c1 ea 10          	shr    $0x10,%rdx
    aad5:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    aad9:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aae0:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    aae4:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    aae8:	4d 85 ff             	test   %r15,%r15
    aaeb:	0f 84 03 f3 ff ff    	je     9df4 <fwp_hof0.constprop.0+0x534>
    aaf1:	0f b6 32             	movzbl (%rdx),%esi
    aaf4:	45 31 ed             	xor    %r13d,%r13d
    aaf7:	40 80 fe 02          	cmp    $0x2,%sil
    aafb:	0f 85 7a f2 ff ff    	jne    9d7b <fwp_hof0.constprop.0+0x4bb>
    ab01:	66 85 c0             	test   %ax,%ax
    ab04:	0f 85 9e f2 ff ff    	jne    9da8 <fwp_hof0.constprop.0+0x4e8>
    ab0a:	41 80 3f ff          	cmpb   $0xff,(%r15)
    ab0e:	0f 85 90 f2 ff ff    	jne    9da4 <fwp_hof0.constprop.0+0x4e4>
    ab14:	4c 89 ff             	mov    %r15,%rdi
    ab17:	e8 b4 ac ff ff       	call   57d0 <fwp_rc_forget_slot>
    ab1c:	e9 83 f2 ff ff       	jmp    9da4 <fwp_hof0.constprop.0+0x4e4>
    ab21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab28:	48 89 d7             	mov    %rdx,%rdi
    ab2b:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    ab30:	e8 9b ac ff ff       	call   57d0 <fwp_rc_forget_slot>
    ab35:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    ab3a:	e9 89 f9 ff ff       	jmp    a4c8 <fwp_hof0.constprop.0+0xc08>
    ab3f:	90                   	nop
    ab40:	4d 85 ed             	test   %r13,%r13
    ab43:	0f 85 64 f2 ff ff    	jne    9dad <fwp_hof0.constprop.0+0x4ed>
    ab49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab50:	31 d2                	xor    %edx,%edx
    ab52:	e9 0c f3 ff ff       	jmp    9e63 <fwp_hof0.constprop.0+0x5a3>
    ab57:	be 02 00 00 00       	mov    $0x2,%esi
    ab5c:	bf 08 00 00 00       	mov    $0x8,%edi
    ab61:	e8 aa b3 ff ff       	call   5f10 <fwp_heap_alloc>
    ab66:	48 89 c3             	mov    %rax,%rbx
    ab69:	45 31 f6             	xor    %r14d,%r14d
    ab6c:	e9 62 fa ff ff       	jmp    a5d3 <fwp_hof0.constprop.0+0xd13>
    ab71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab78:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    ab7c:	4d 39 e0             	cmp    %r12,%r8
    ab7f:	7c 32                	jl     abb3 <fwp_hof0.constprop.0+0x12f3>
    ab81:	4d 85 d2             	test   %r10,%r10
    ab84:	0f 84 70 06 00 00    	je     b1fa <fwp_hof0.constprop.0+0x193a>
    ab8a:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
    ab8f:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    ab96:	00 
    ab97:	31 f6                	xor    %esi,%esi
    ab99:	4c 89 d7             	mov    %r10,%rdi
    ab9c:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    aba1:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    aba6:	e9 2c f4 ff ff       	jmp    9fd7 <fwp_hof0.constprop.0+0x717>
    abab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    abb0:	4d 89 f4             	mov    %r14,%r12
    abb3:	4d 85 c0             	test   %r8,%r8
    abb6:	4d 0f 44 c4          	cmove  %r12,%r8
    abba:	eb 19                	jmp    abd5 <fwp_hof0.constprop.0+0x1315>
    abbc:	0f 1f 40 00          	nopl   0x0(%rax)
    abc0:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    abc4:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    abcb:	4c 89 e0             	mov    %r12,%rax
    abce:	48 0f 4c c2          	cmovl  %rdx,%rax
    abd2:	49 89 c0             	mov    %rax,%r8
    abd5:	4d 39 e0             	cmp    %r12,%r8
    abd8:	7c e6                	jl     abc0 <fwp_hof0.constprop.0+0x1300>
    abda:	4d 85 d2             	test   %r10,%r10
    abdd:	0f 84 2d 02 00 00    	je     ae10 <fwp_hof0.constprop.0+0x1550>
    abe3:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    abea:	00 
    abeb:	4c 89 d7             	mov    %r10,%rdi
    abee:	ba 03 00 00 00       	mov    $0x3,%edx
    abf3:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    abf8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    abfd:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    ac02:	e8 89 a5 ff ff       	call   5190 <ad_raw_realloc>
    ac07:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    ac0c:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    ac12:	48 85 c0             	test   %rax,%rax
    ac15:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    ac1b:	49 89 c2             	mov    %rax,%r10
    ac1e:	0f 84 bc 02 00 00    	je     aee0 <fwp_hof0.constprop.0+0x1620>
    ac24:	4c 89 94 24 e0 00 00 	mov    %r10,0xe0(%rsp)
    ac2b:	00 
    ac2c:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    ac33:	00 
    ac34:	4d 85 e4             	test   %r12,%r12
    ac37:	0f 85 18 04 00 00    	jne    b055 <fwp_hof0.constprop.0+0x1795>
    ac3d:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    ac44:	4d 85 ed             	test   %r13,%r13
    ac47:	0f 88 b7 f3 ff ff    	js     a004 <fwp_hof0.constprop.0+0x744>
    ac4d:	44 89 e9             	mov    %r13d,%ecx
    ac50:	e9 9b f3 ff ff       	jmp    9ff0 <fwp_hof0.constprop.0+0x730>
    ac55:	0f 1f 00             	nopl   (%rax)
    ac58:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    ac5d:	45 31 c9             	xor    %r9d,%r9d
    ac60:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    ac65:	48 83 e8 01          	sub    $0x1,%rax
    ac69:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    ac6e:	41 0f 90 c1          	seto   %r9b
    ac72:	e9 2c ed ff ff       	jmp    99a3 <fwp_hof0.constprop.0+0xe3>
    ac77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac7e:	00 00 
    ac80:	48 8d 3d 59 c4 ff ff 	lea    -0x3ba7(%rip),%rdi        # 70e0 <fwp_tape_finish>
    ac87:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    ac8d:	e8 fe 3c 00 00       	call   e990 <atexit>
    ac92:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    ac98:	85 c0                	test   %eax,%eax
    ac9a:	0f 85 e3 04 00 00    	jne    b183 <fwp_hof0.constprop.0+0x18c3>
    aca0:	c7 05 b6 83 00 00 01 	movl   $0x1,0x83b6(%rip)        # 13060 <registered_finish.1>
    aca7:	00 00 00 
    acaa:	e9 2e ee ff ff       	jmp    9add <fwp_hof0.constprop.0+0x21d>
    acaf:	90                   	nop
    acb0:	66 85 c0             	test   %ax,%ax
    acb3:	0f 85 b7 f9 ff ff    	jne    a670 <fwp_hof0.constprop.0+0xdb0>
    acb9:	e9 8c f9 ff ff       	jmp    a64a <fwp_hof0.constprop.0+0xd8a>
    acbe:	66 90                	xchg   %ax,%ax
    acc0:	66 85 c0             	test   %ax,%ax
    acc3:	0f 85 c1 ed ff ff    	jne    9a8a <fwp_hof0.constprop.0+0x1ca>
    acc9:	e9 94 ed ff ff       	jmp    9a62 <fwp_hof0.constprop.0+0x1a2>
    acce:	66 90                	xchg   %ax,%ax
    acd0:	4d 39 c6             	cmp    %r8,%r14
    acd3:	0f 8f d7 fe ff ff    	jg     abb0 <fwp_hof0.constprop.0+0x12f0>
    acd9:	4d 85 f6             	test   %r14,%r14
    acdc:	74 12                	je     acf0 <fwp_hof0.constprop.0+0x1430>
    acde:	4d 85 d2             	test   %r10,%r10
    ace1:	0f 84 13 05 00 00    	je     b1fa <fwp_hof0.constprop.0+0x193a>
    ace7:	4d 85 f6             	test   %r14,%r14
    acea:	0f 85 62 03 00 00    	jne    b052 <fwp_hof0.constprop.0+0x1792>
    acf0:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    acf7:	e9 08 f3 ff ff       	jmp    a004 <fwp_hof0.constprop.0+0x744>
    acfc:	0f 1f 40 00          	nopl   0x0(%rax)
    ad00:	66 85 c0             	test   %ax,%ax
    ad03:	0f 85 75 f4 ff ff    	jne    a17e <fwp_hof0.constprop.0+0x8be>
    ad09:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ad0e:	0f 85 65 f4 ff ff    	jne    a179 <fwp_hof0.constprop.0+0x8b9>
    ad14:	4c 89 e7             	mov    %r12,%rdi
    ad17:	e8 b4 aa ff ff       	call   57d0 <fwp_rc_forget_slot>
    ad1c:	e9 58 f4 ff ff       	jmp    a179 <fwp_hof0.constprop.0+0x8b9>
    ad21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ad28:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    ad2d:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ad32:	e9 9c f8 ff ff       	jmp    a5d3 <fwp_hof0.constprop.0+0xd13>
    ad37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ad3e:	00 00 
    ad40:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ad45:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ad4c:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ad53:	48 8b 58 10          	mov    0x10(%rax),%rbx
    ad57:	48 29 c8             	sub    %rcx,%rax
    ad5a:	48 c1 e2 10          	shl    $0x10,%rdx
    ad5e:	48 39 d0             	cmp    %rdx,%rax
    ad61:	73 67                	jae    adca <fwp_hof0.constprop.0+0x150a>
    ad63:	48 89 c7             	mov    %rax,%rdi
    ad66:	48 c1 ef 10          	shr    $0x10,%rdi
    ad6a:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    ad6e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    ad72:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    ad76:	48 85 ff             	test   %rdi,%rdi
    ad79:	74 4f                	je     adca <fwp_hof0.constprop.0+0x150a>
    ad7b:	44 0f b6 06          	movzbl (%rsi),%r8d
    ad7f:	41 80 f8 02          	cmp    $0x2,%r8b
    ad83:	0f 84 38 02 00 00    	je     afc1 <fwp_hof0.constprop.0+0x1701>
    ad89:	41 80 f8 01          	cmp    $0x1,%r8b
    ad8d:	75 3b                	jne    adca <fwp_hof0.constprop.0+0x150a>
    ad8f:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    ad93:	0f b7 c0             	movzwl %ax,%eax
    ad96:	8b 76 1c             	mov    0x1c(%rsi),%esi
    ad99:	49 0f af c0          	imul   %r8,%rax
    ad9d:	48 c1 e8 20          	shr    $0x20,%rax
    ada1:	48 39 f0             	cmp    %rsi,%rax
    ada4:	73 24                	jae    adca <fwp_hof0.constprop.0+0x150a>
    ada6:	48 01 c7             	add    %rax,%rdi
    ada9:	80 3f 01             	cmpb   $0x1,(%rdi)
    adac:	75 1c                	jne    adca <fwp_hof0.constprop.0+0x150a>
    adae:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    adb3:	e8 58 ac ff ff       	call   5a10 <fwp_mem_free>
    adb8:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    adbf:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    adc6:	48 c1 e2 10          	shl    $0x10,%rdx
    adca:	48 89 d8             	mov    %rbx,%rax
    adcd:	48 29 c8             	sub    %rcx,%rax
    add0:	48 39 d0             	cmp    %rdx,%rax
    add3:	0f 83 97 f8 ff ff    	jae    a670 <fwp_hof0.constprop.0+0xdb0>
    add9:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    adde:	e9 1e f8 ff ff       	jmp    a601 <fwp_hof0.constprop.0+0xd41>
    ade3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ade8:	66 85 c0             	test   %ax,%ax
    adeb:	0f 85 8d fc ff ff    	jne    aa7e <fwp_hof0.constprop.0+0x11be>
    adf1:	80 3b ff             	cmpb   $0xff,(%rbx)
    adf4:	0f 85 81 fc ff ff    	jne    aa7b <fwp_hof0.constprop.0+0x11bb>
    adfa:	48 89 df             	mov    %rbx,%rdi
    adfd:	e8 ce a9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    ae02:	e9 74 fc ff ff       	jmp    aa7b <fwp_hof0.constprop.0+0x11bb>
    ae07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ae0e:	00 00 
    ae10:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    ae17:	ff ff 1f 
    ae1a:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    ae1e:	48 39 c2             	cmp    %rax,%rdx
    ae21:	0f 82 26 04 00 00    	jb     b24d <fwp_hof0.constprop.0+0x198d>
    ae27:	48 8d 05 92 83 04 00 	lea    0x48392(%rip),%rax        # 531c0 <ad_raw_blocks>
    ae2e:	45 31 ff             	xor    %r15d,%r15d
    ae31:	eb 22                	jmp    ae55 <fwp_hof0.constprop.0+0x1595>
    ae33:	66 90                	xchg   %ax,%ax
    ae35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ae3c:	00 00 00 00 
    ae40:	49 83 c7 01          	add    $0x1,%r15
    ae44:	48 83 c0 18          	add    $0x18,%rax
    ae48:	49 81 ff 00 10 00 00 	cmp    $0x1000,%r15
    ae4f:	0f 84 35 02 00 00    	je     b08a <fwp_hof0.constprop.0+0x17ca>
    ae55:	48 83 38 00          	cmpq   $0x0,(%rax)
    ae59:	75 e5                	jne    ae40 <fwp_hof0.constprop.0+0x1580>
    ae5b:	4c 89 c7             	mov    %r8,%rdi
    ae5e:	be 08 00 00 00       	mov    $0x8,%esi
    ae63:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    ae68:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    ae6d:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    ae72:	e8 99 86 ff ff       	call   3510 <calloc@plt>
    ae77:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    ae7c:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    ae82:	48 8d 15 37 83 04 00 	lea    0x48337(%rip),%rdx        # 531c0 <ad_raw_blocks>
    ae89:	48 85 c0             	test   %rax,%rax
    ae8c:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    ae92:	49 89 c2             	mov    %rax,%r10
    ae95:	74 49                	je     aee0 <fwp_hof0.constprop.0+0x1620>
    ae97:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
    ae9b:	48 89 c6             	mov    %rax,%rsi
    ae9e:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    aea3:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    aea7:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    aeae:	00 
    aeaf:	b9 03 00 00 00       	mov    $0x3,%ecx
    aeb4:	e8 47 8d ff ff       	call   3c00 <ad_raw_record>
    aeb9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    aebe:	e9 61 fd ff ff       	jmp    ac24 <fwp_hof0.constprop.0+0x1364>
    aec3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aec8:	66 85 c0             	test   %ax,%ax
    aecb:	0f 85 bc ea ff ff    	jne    998d <fwp_hof0.constprop.0+0xcd>
    aed1:	e9 8f ea ff ff       	jmp    9965 <fwp_hof0.constprop.0+0xa5>
    aed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aedd:	00 00 00 
    aee0:	4d 85 e4             	test   %r12,%r12
    aee3:	0f 85 11 03 00 00    	jne    b1fa <fwp_hof0.constprop.0+0x193a>
    aee9:	45 31 d2             	xor    %r10d,%r10d
    aeec:	e9 4c fd ff ff       	jmp    ac3d <fwp_hof0.constprop.0+0x137d>
    aef1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aef8:	66 85 c0             	test   %ax,%ax
    aefb:	0f 85 82 f8 ff ff    	jne    a783 <fwp_hof0.constprop.0+0xec3>
    af01:	41 80 3f ff          	cmpb   $0xff,(%r15)
    af05:	0f 85 74 f8 ff ff    	jne    a77f <fwp_hof0.constprop.0+0xebf>
    af0b:	4c 89 ff             	mov    %r15,%rdi
    af0e:	e8 bd a8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    af13:	e9 67 f8 ff ff       	jmp    a77f <fwp_hof0.constprop.0+0xebf>
    af18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    af1f:	00 
    af20:	66 85 c0             	test   %ax,%ax
    af23:	0f 85 17 f9 ff ff    	jne    a840 <fwp_hof0.constprop.0+0xf80>
    af29:	41 0f b6 04 24       	movzbl (%r12),%eax
    af2e:	84 c0                	test   %al,%al
    af30:	0f 84 0a f9 ff ff    	je     a840 <fwp_hof0.constprop.0+0xf80>
    af36:	3c 01                	cmp    $0x1,%al
    af38:	0f 85 e9 f8 ff ff    	jne    a827 <fwp_hof0.constprop.0+0xf67>
    af3e:	48 89 df             	mov    %rbx,%rdi
    af41:	e8 ca aa ff ff       	call   5a10 <fwp_mem_free>
    af46:	e9 f5 f8 ff ff       	jmp    a840 <fwp_hof0.constprop.0+0xf80>
    af4b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af4f:	e9 7b eb ff ff       	jmp    9acf <fwp_hof0.constprop.0+0x20f>
    af54:	49 8b 04 24          	mov    (%r12),%rax
    af58:	48 85 c0             	test   %rax,%rax
    af5b:	0f 88 f6 fb ff ff    	js     ab57 <fwp_hof0.constprop.0+0x1297>
    af61:	48 8b b5 d8 13 00 00 	mov    0x13d8(%rbp),%rsi
    af68:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    af6d:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    af74:	48 c1 e6 10          	shl    $0x10,%rsi
    af78:	48 39 f1             	cmp    %rsi,%rcx
    af7b:	0f 83 d6 fb ff ff    	jae    ab57 <fwp_hof0.constprop.0+0x1297>
    af81:	48 89 ce             	mov    %rcx,%rsi
    af84:	48 c1 ee 10          	shr    $0x10,%rsi
    af88:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    af8c:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    af93:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    af97:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    af9b:	48 85 ff             	test   %rdi,%rdi
    af9e:	0f 84 b3 fb ff ff    	je     ab57 <fwp_hof0.constprop.0+0x1297>
    afa4:	48 0f ba f0 3f       	btr    $0x3f,%rax
    afa9:	49 89 c7             	mov    %rax,%r15
    afac:	e9 64 f3 ff ff       	jmp    a315 <fwp_hof0.constprop.0+0xa55>
    afb1:	be 68 00 00 00       	mov    $0x68,%esi
    afb6:	41 be 01 00 00 00    	mov    $0x1,%r14d
    afbc:	e9 99 eb ff ff       	jmp    9b5a <fwp_hof0.constprop.0+0x29a>
    afc1:	66 85 c0             	test   %ax,%ax
    afc4:	0f 85 00 fe ff ff    	jne    adca <fwp_hof0.constprop.0+0x150a>
    afca:	e9 da fd ff ff       	jmp    ada9 <fwp_hof0.constprop.0+0x14e9>
    afcf:	4c 89 e2             	mov    %r12,%rdx
    afd2:	48 c1 ea 11          	shr    $0x11,%rdx
    afd6:	4c 31 e2             	xor    %r12,%rdx
    afd9:	48 89 d0             	mov    %rdx,%rax
    afdc:	48 c1 e8 09          	shr    $0x9,%rax
    afe0:	48 31 c2             	xor    %rax,%rdx
    afe3:	0f b6 d2             	movzbl %dl,%edx
    afe6:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    afed:	00 
    afee:	48 85 c0             	test   %rax,%rax
    aff1:	75 16                	jne    b009 <fwp_hof0.constprop.0+0x1749>
    aff3:	eb 51                	jmp    b046 <fwp_hof0.constprop.0+0x1786>
    aff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    affc:	00 00 00 00 
    b000:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b004:	48 85 c0             	test   %rax,%rax
    b007:	74 3d                	je     b046 <fwp_hof0.constprop.0+0x1786>
    b009:	48 89 c2             	mov    %rax,%rdx
    b00c:	4c 39 20             	cmp    %r12,(%rax)
    b00f:	75 ef                	jne    b000 <fwp_hof0.constprop.0+0x1740>
    b011:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b015:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b019:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b01d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b024:	0f 85 46 f6 ff ff    	jne    a670 <fwp_hof0.constprop.0+0xdb0>
    b02a:	4c 89 e7             	mov    %r12,%rdi
    b02d:	e8 9e a7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b032:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b037:	e9 34 f6 ff ff       	jmp    a670 <fwp_hof0.constprop.0+0xdb0>
    b03c:	e8 6f a6 ff ff       	call   56b0 <fwp_rc_wide_dup>
    b041:	e9 44 ea ff ff       	jmp    9a8a <fwp_hof0.constprop.0+0x1ca>
    b046:	48 8d 3d a3 49 00 00 	lea    0x49a3(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    b04d:	e8 fe 93 ff ff       	call   4450 <fwp_trap>
    b052:	4d 89 f4             	mov    %r14,%r12
    b055:	4c 89 d7             	mov    %r10,%rdi
    b058:	31 f6                	xor    %esi,%esi
    b05a:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    b05f:	4d 8d 7c 24 ff       	lea    -0x1(%r12),%r15
    b064:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    b06b:	00 
    b06c:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    b071:	e8 3a 84 ff ff       	call   34b0 <memset@plt>
    b076:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    b07c:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    b082:	49 89 c2             	mov    %rax,%r10
    b085:	e9 ba fb ff ff       	jmp    ac44 <fwp_hof0.constprop.0+0x1384>
    b08a:	48 8d 3d 81 40 00 00 	lea    0x4081(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    b091:	e8 6a 8f ff ff       	call   4000 <ad_raw_fail>
    b096:	e8 15 a6 ff ff       	call   56b0 <fwp_rc_wide_dup>
    b09b:	e9 ed e8 ff ff       	jmp    998d <fwp_hof0.constprop.0+0xcd>
    b0a0:	4c 89 e0             	mov    %r12,%rax
    b0a3:	48 c1 e8 11          	shr    $0x11,%rax
    b0a7:	4c 31 e0             	xor    %r12,%rax
    b0aa:	48 89 c2             	mov    %rax,%rdx
    b0ad:	48 c1 ea 09          	shr    $0x9,%rdx
    b0b1:	48 31 d0             	xor    %rdx,%rax
    b0b4:	0f b6 d0             	movzbl %al,%edx
    b0b7:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b0be:	00 
    b0bf:	48 85 c0             	test   %rax,%rax
    b0c2:	75 29                	jne    b0ed <fwp_hof0.constprop.0+0x182d>
    b0c4:	eb 80                	jmp    b046 <fwp_hof0.constprop.0+0x1786>
    b0c6:	0f 1f 40 00          	nopl   0x0(%rax)
    b0ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b0d1:	00 00 00 00 
    b0d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b0dc:	00 00 00 00 
    b0e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b0e4:	48 85 c0             	test   %rax,%rax
    b0e7:	0f 84 59 ff ff ff    	je     b046 <fwp_hof0.constprop.0+0x1786>
    b0ed:	48 89 c2             	mov    %rax,%rdx
    b0f0:	4c 3b 20             	cmp    (%rax),%r12
    b0f3:	75 eb                	jne    b0e0 <fwp_hof0.constprop.0+0x1820>
    b0f5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b0f9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b0fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b101:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b108:	0f 85 32 f7 ff ff    	jne    a840 <fwp_hof0.constprop.0+0xf80>
    b10e:	4c 89 e7             	mov    %r12,%rdi
    b111:	e8 ba a6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b116:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b11b:	e9 20 f7 ff ff       	jmp    a840 <fwp_hof0.constprop.0+0xf80>
    b120:	45 31 ff             	xor    %r15d,%r15d
    b123:	e9 6d f3 ff ff       	jmp    a495 <fwp_hof0.constprop.0+0xbd5>
    b128:	48 8d 3d e9 48 00 00 	lea    0x48e9(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    b12f:	e8 1c 93 ff ff       	call   4450 <fwp_trap>
    b134:	48 8d 3d 87 40 00 00 	lea    0x4087(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    b13b:	e8 10 93 ff ff       	call   4450 <fwp_trap>
    b140:	48 8d 3d a9 49 00 00 	lea    0x49a9(%rip),%rdi        # faf0 <_IO_stdin_used+0xaf0>
    b147:	e8 04 93 ff ff       	call   4450 <fwp_trap>
    b14c:	31 db                	xor    %ebx,%ebx
    b14e:	e9 16 fa ff ff       	jmp    ab69 <fwp_hof0.constprop.0+0x12a9>
    b153:	48 8d 3d 91 40 00 00 	lea    0x4091(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    b15a:	e8 f1 92 ff ff       	call   4450 <fwp_trap>
    b15f:	48 8d 3d 16 41 00 00 	lea    0x4116(%rip),%rdi        # f27c <_IO_stdin_used+0x27c>
    b166:	e8 e5 92 ff ff       	call   4450 <fwp_trap>
    b16b:	48 8d 3d 40 41 00 00 	lea    0x4140(%rip),%rdi        # f2b2 <_IO_stdin_used+0x2b2>
    b172:	e8 d9 92 ff ff       	call   4450 <fwp_trap>
    b177:	48 8d 3d 42 49 00 00 	lea    0x4942(%rip),%rdi        # fac0 <_IO_stdin_used+0xac0>
    b17e:	e8 cd 92 ff ff       	call   4450 <fwp_trap>
    b183:	48 8b 0d b6 7e 00 00 	mov    0x7eb6(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b18a:	ba 13 00 00 00       	mov    $0x13,%edx
    b18f:	be 01 00 00 00       	mov    $0x1,%esi
    b194:	48 8d 3d 6d 3e 00 00 	lea    0x3e6d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b19b:	e8 c0 84 ff ff       	call   3660 <fwrite@plt>
    b1a0:	31 ff                	xor    %edi,%edi
    b1a2:	e8 f9 83 ff ff       	call   35a0 <fflush@plt>
    b1a7:	bf 66 00 00 00       	mov    $0x66,%edi
    b1ac:	e8 cf 84 ff ff       	call   3680 <_Exit@plt>
    b1b1:	48 8d 3d 0a 41 00 00 	lea    0x410a(%rip),%rdi        # f2c2 <_IO_stdin_used+0x2c2>
    b1b8:	e8 93 92 ff ff       	call   4450 <fwp_trap>
    b1bd:	0f 1f 00             	nopl   (%rax)
    b1c0:	48 8d 3d 51 49 00 00 	lea    0x4951(%rip),%rdi        # fb18 <_IO_stdin_used+0xb18>
    b1c7:	e8 84 92 ff ff       	call   4450 <fwp_trap>
    b1cc:	48 8b 0d 6d 7e 00 00 	mov    0x7e6d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b1d3:	ba 13 00 00 00       	mov    $0x13,%edx
    b1d8:	be 01 00 00 00       	mov    $0x1,%esi
    b1dd:	48 8d 3d 24 3e 00 00 	lea    0x3e24(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b1e4:	e8 77 84 ff ff       	call   3660 <fwrite@plt>
    b1e9:	31 ff                	xor    %edi,%edi
    b1eb:	e8 b0 83 ff ff       	call   35a0 <fflush@plt>
    b1f0:	bf 66 00 00 00       	mov    $0x66,%edi
    b1f5:	e8 86 84 ff ff       	call   3680 <_Exit@plt>
    b1fa:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    b201:	00 
    b202:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    b207:	48 89 05 aa 22 06 00 	mov    %rax,0x622aa(%rip)        # 6d4b8 <fwp_cleanups>
    b20e:	e8 4d a0 ff ff       	call   5260 <fwp_tape_buffers_release>
    b213:	ba 13 00 00 00       	mov    $0x13,%edx
    b218:	48 8b 0d 21 7e 00 00 	mov    0x7e21(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b21f:	be 01 00 00 00       	mov    $0x1,%esi
    b224:	48 8d 3d dd 3d 00 00 	lea    0x3ddd(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b22b:	e8 30 84 ff ff       	call   3660 <fwrite@plt>
    b230:	31 ff                	xor    %edi,%edi
    b232:	e8 69 83 ff ff       	call   35a0 <fflush@plt>
    b237:	bf 66 00 00 00       	mov    $0x66,%edi
    b23c:	e8 3f 84 ff ff       	call   3680 <_Exit@plt>
    b241:	48 8d 3d 18 48 00 00 	lea    0x4818(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    b248:	e8 03 92 ff ff       	call   4450 <fwp_trap>
    b24d:	48 8d 3d 42 40 00 00 	lea    0x4042(%rip),%rdi        # f296 <_IO_stdin_used+0x296>
    b254:	e8 a7 8d ff ff       	call   4000 <ad_raw_fail>
    b259:	e8 f2 81 ff ff       	call   3450 <__stack_chk_fail@plt>
    b25e:	66 90                	xchg   %ax,%ax

000000000000b260 <f0>:
    b260:	41 56                	push   %r14
    b262:	4c 8d 35 b7 05 06 00 	lea    0x605b7(%rip),%r14        # 6b820 <fwp_heap>
    b269:	41 55                	push   %r13
    b26b:	41 54                	push   %r12
    b26d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b273:	55                   	push   %rbp
    b274:	53                   	push   %rbx
    b275:	31 db                	xor    %ebx,%ebx
    b277:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b27e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b285:	00 00 
    b287:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b28e:	00 
    b28f:	31 c0                	xor    %eax,%eax
    b291:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b298:	00 
    b299:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b2a0:	00 00 
    b2a2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b2a7:	48 8d 05 a2 cc ff ff 	lea    -0x335e(%rip),%rax        # 7f50 <fwp_drop1>
    b2ae:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b2b3:	48 8b 05 fe 21 06 00 	mov    0x621fe(%rip),%rax        # 6d4b8 <fwp_cleanups>
    b2ba:	48 89 25 f7 21 06 00 	mov    %rsp,0x621f7(%rip)        # 6d4b8 <fwp_cleanups>
    b2c1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b2c5:	48 89 04 24          	mov    %rax,(%rsp)
    b2c9:	48 8d 05 00 89 ff ff 	lea    -0x7700(%rip),%rax        # 3bd0 <fwp_range_release>
    b2d0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b2d5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b2da:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b2df:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b2e4:	eb 47                	jmp    b32d <f0+0xcd>
    b2e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b2ed:	00 00 00 
    b2f0:	80 f9 01             	cmp    $0x1,%cl
    b2f3:	75 29                	jne    b31e <f0+0xbe>
    b2f5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b2f8:	0f b7 c0             	movzwl %ax,%eax
    b2fb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b2fe:	48 0f af c1          	imul   %rcx,%rax
    b302:	48 c1 e8 20          	shr    $0x20,%rax
    b306:	48 39 d0             	cmp    %rdx,%rax
    b309:	73 13                	jae    b31e <f0+0xbe>
    b30b:	49 01 c5             	add    %rax,%r13
    b30e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b313:	0f 84 c7 27 00 00    	je     dae0 <f0+0x2880>
    b319:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b31e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b323:	49 83 ec 01          	sub    $0x1,%r12
    b327:	0f 82 83 00 00 00    	jb     b3b0 <f0+0x150>
    b32d:	48 89 ee             	mov    %rbp,%rsi
    b330:	bf 01 00 00 00       	mov    $0x1,%edi
    b335:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b33c:	00 
    b33d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b342:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b349:	00 
    b34a:	e8 b1 ad ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b34f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b356:	48 89 c3             	mov    %rax,%rbx
    b359:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b360:	48 c1 e2 10          	shl    $0x10,%rdx
    b364:	48 39 d0             	cmp    %rdx,%rax
    b367:	73 b5                	jae    b31e <f0+0xbe>
    b369:	48 89 c2             	mov    %rax,%rdx
    b36c:	48 c1 ea 10          	shr    $0x10,%rdx
    b370:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b374:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b37b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b37f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b383:	4d 85 ed             	test   %r13,%r13
    b386:	74 96                	je     b31e <f0+0xbe>
    b388:	0f b6 0a             	movzbl (%rdx),%ecx
    b38b:	80 f9 02             	cmp    $0x2,%cl
    b38e:	0f 85 5c ff ff ff    	jne    b2f0 <f0+0x90>
    b394:	66 85 c0             	test   %ax,%ax
    b397:	0f 84 71 ff ff ff    	je     b30e <f0+0xae>
    b39d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b3a2:	49 83 ec 01          	sub    $0x1,%r12
    b3a6:	73 85                	jae    b32d <f0+0xcd>
    b3a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b3af:	00 
    b3b0:	48 8b 04 24          	mov    (%rsp),%rax
    b3b4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b3b9:	bf 01 00 00 00       	mov    $0x1,%edi
    b3be:	66 0f 6f 05 4a 4a 00 	movdqa 0x4a4a(%rip),%xmm0        # fe10 <msg.4+0xd0>
    b3c5:	00 
    b3c6:	48 89 05 eb 20 06 00 	mov    %rax,0x620eb(%rip)        # 6d4b8 <fwp_cleanups>
    b3cd:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b3d2:	e8 29 ad ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b3d7:	48 8b 15 1a 18 06 00 	mov    0x6181a(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b3de:	49 89 c5             	mov    %rax,%r13
    b3e1:	48 2b 05 e8 17 06 00 	sub    0x617e8(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b3e8:	48 c1 e2 10          	shl    $0x10,%rdx
    b3ec:	48 39 d0             	cmp    %rdx,%rax
    b3ef:	73 59                	jae    b44a <f0+0x1ea>
    b3f1:	48 89 c2             	mov    %rax,%rdx
    b3f4:	48 c1 ea 10          	shr    $0x10,%rdx
    b3f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3fc:	48 8b 15 15 18 06 00 	mov    0x61815(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b403:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b407:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b40b:	4d 85 e4             	test   %r12,%r12
    b40e:	74 3a                	je     b44a <f0+0x1ea>
    b410:	0f b6 0a             	movzbl (%rdx),%ecx
    b413:	80 f9 02             	cmp    $0x2,%cl
    b416:	0f 84 74 27 00 00    	je     db90 <f0+0x2930>
    b41c:	80 f9 01             	cmp    $0x1,%cl
    b41f:	75 29                	jne    b44a <f0+0x1ea>
    b421:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b424:	0f b7 c0             	movzwl %ax,%eax
    b427:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b42a:	48 0f af c1          	imul   %rcx,%rax
    b42e:	48 c1 e8 20          	shr    $0x20,%rax
    b432:	48 39 d0             	cmp    %rdx,%rax
    b435:	73 13                	jae    b44a <f0+0x1ea>
    b437:	49 01 c4             	add    %rax,%r12
    b43a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b43f:	0f 84 26 29 00 00    	je     dd6b <f0+0x2b0b>
    b445:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b44a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b44f:	bf 01 00 00 00       	mov    $0x1,%edi
    b454:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b459:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b460:	00 f0 3f 
    b463:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b468:	e8 93 ac ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b46d:	48 8b 15 84 17 06 00 	mov    0x61784(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b474:	49 89 c5             	mov    %rax,%r13
    b477:	48 2b 05 52 17 06 00 	sub    0x61752(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b47e:	48 c1 e2 10          	shl    $0x10,%rdx
    b482:	48 39 d0             	cmp    %rdx,%rax
    b485:	73 59                	jae    b4e0 <f0+0x280>
    b487:	48 89 c2             	mov    %rax,%rdx
    b48a:	48 c1 ea 10          	shr    $0x10,%rdx
    b48e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b492:	48 8b 15 7f 17 06 00 	mov    0x6177f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b499:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b49d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b4a1:	4d 85 e4             	test   %r12,%r12
    b4a4:	74 3a                	je     b4e0 <f0+0x280>
    b4a6:	0f b6 0a             	movzbl (%rdx),%ecx
    b4a9:	80 f9 02             	cmp    $0x2,%cl
    b4ac:	0f 84 ce 26 00 00    	je     db80 <f0+0x2920>
    b4b2:	80 f9 01             	cmp    $0x1,%cl
    b4b5:	75 29                	jne    b4e0 <f0+0x280>
    b4b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b4ba:	0f b7 c0             	movzwl %ax,%eax
    b4bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4c0:	48 0f af c1          	imul   %rcx,%rax
    b4c4:	48 c1 e8 20          	shr    $0x20,%rax
    b4c8:	48 39 d0             	cmp    %rdx,%rax
    b4cb:	73 13                	jae    b4e0 <f0+0x280>
    b4cd:	49 01 c4             	add    %rax,%r12
    b4d0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b4d5:	0f 84 9d 28 00 00    	je     dd78 <f0+0x2b18>
    b4db:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b4e0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b4e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b4ea:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b4ef:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b4f6:	33 f3 bf 
    b4f9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b4fe:	e8 fd ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b503:	48 8b 15 ee 16 06 00 	mov    0x616ee(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b50a:	49 89 c5             	mov    %rax,%r13
    b50d:	48 2b 05 bc 16 06 00 	sub    0x616bc(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b514:	48 c1 e2 10          	shl    $0x10,%rdx
    b518:	48 39 d0             	cmp    %rdx,%rax
    b51b:	73 59                	jae    b576 <f0+0x316>
    b51d:	48 89 c2             	mov    %rax,%rdx
    b520:	48 c1 ea 10          	shr    $0x10,%rdx
    b524:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b528:	48 8b 15 e9 16 06 00 	mov    0x616e9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b52f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b533:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b537:	4d 85 e4             	test   %r12,%r12
    b53a:	74 3a                	je     b576 <f0+0x316>
    b53c:	0f b6 0a             	movzbl (%rdx),%ecx
    b53f:	80 f9 02             	cmp    $0x2,%cl
    b542:	0f 84 28 26 00 00    	je     db70 <f0+0x2910>
    b548:	80 f9 01             	cmp    $0x1,%cl
    b54b:	75 29                	jne    b576 <f0+0x316>
    b54d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b550:	0f b7 c0             	movzwl %ax,%eax
    b553:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b556:	48 0f af c1          	imul   %rcx,%rax
    b55a:	48 c1 e8 20          	shr    $0x20,%rax
    b55e:	48 39 d0             	cmp    %rdx,%rax
    b561:	73 13                	jae    b576 <f0+0x316>
    b563:	49 01 c4             	add    %rax,%r12
    b566:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b56b:	0f 84 14 28 00 00    	je     dd85 <f0+0x2b25>
    b571:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b576:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b57b:	bf 01 00 00 00       	mov    $0x1,%edi
    b580:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b585:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b58c:	00 f0 3f 
    b58f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b594:	e8 67 ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b599:	48 8b 15 58 16 06 00 	mov    0x61658(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b5a0:	49 89 c5             	mov    %rax,%r13
    b5a3:	48 2b 05 26 16 06 00 	sub    0x61626(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b5aa:	48 c1 e2 10          	shl    $0x10,%rdx
    b5ae:	48 39 d0             	cmp    %rdx,%rax
    b5b1:	73 59                	jae    b60c <f0+0x3ac>
    b5b3:	48 89 c2             	mov    %rax,%rdx
    b5b6:	48 c1 ea 10          	shr    $0x10,%rdx
    b5ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b5be:	48 8b 15 53 16 06 00 	mov    0x61653(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b5c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5c9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b5cd:	4d 85 e4             	test   %r12,%r12
    b5d0:	74 3a                	je     b60c <f0+0x3ac>
    b5d2:	0f b6 0a             	movzbl (%rdx),%ecx
    b5d5:	80 f9 02             	cmp    $0x2,%cl
    b5d8:	0f 84 f2 25 00 00    	je     dbd0 <f0+0x2970>
    b5de:	80 f9 01             	cmp    $0x1,%cl
    b5e1:	75 29                	jne    b60c <f0+0x3ac>
    b5e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5e6:	0f b7 c0             	movzwl %ax,%eax
    b5e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5ec:	48 0f af c1          	imul   %rcx,%rax
    b5f0:	48 c1 e8 20          	shr    $0x20,%rax
    b5f4:	48 39 d0             	cmp    %rdx,%rax
    b5f7:	73 13                	jae    b60c <f0+0x3ac>
    b5f9:	49 01 c4             	add    %rax,%r12
    b5fc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b601:	0f 84 8b 27 00 00    	je     dd92 <f0+0x2b32>
    b607:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b60c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b613:	33 f3 bf 
    b616:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b61d:	00 
    b61e:	bf 01 00 00 00       	mov    $0x1,%edi
    b623:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b62a:	00 
    b62b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b632:	00 
    b633:	e8 c8 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b638:	48 8b 15 b9 15 06 00 	mov    0x615b9(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b63f:	49 89 c5             	mov    %rax,%r13
    b642:	48 2b 05 87 15 06 00 	sub    0x61587(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b649:	48 c1 e2 10          	shl    $0x10,%rdx
    b64d:	48 39 d0             	cmp    %rdx,%rax
    b650:	73 59                	jae    b6ab <f0+0x44b>
    b652:	48 89 c2             	mov    %rax,%rdx
    b655:	48 c1 ea 10          	shr    $0x10,%rdx
    b659:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b65d:	48 8b 15 b4 15 06 00 	mov    0x615b4(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b664:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b668:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b66c:	4d 85 e4             	test   %r12,%r12
    b66f:	74 3a                	je     b6ab <f0+0x44b>
    b671:	0f b6 0a             	movzbl (%rdx),%ecx
    b674:	80 f9 02             	cmp    $0x2,%cl
    b677:	0f 84 43 25 00 00    	je     dbc0 <f0+0x2960>
    b67d:	80 f9 01             	cmp    $0x1,%cl
    b680:	75 29                	jne    b6ab <f0+0x44b>
    b682:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b685:	0f b7 c0             	movzwl %ax,%eax
    b688:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b68b:	48 0f af c1          	imul   %rcx,%rax
    b68f:	48 c1 e8 20          	shr    $0x20,%rax
    b693:	48 39 d0             	cmp    %rdx,%rax
    b696:	73 13                	jae    b6ab <f0+0x44b>
    b698:	49 01 c4             	add    %rax,%r12
    b69b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b6a0:	0f 84 f9 26 00 00    	je     dd9f <f0+0x2b3f>
    b6a6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b6ab:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b6b2:	00 f0 3f 
    b6b5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b6bc:	00 
    b6bd:	bf 01 00 00 00       	mov    $0x1,%edi
    b6c2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b6c9:	00 
    b6ca:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b6d1:	00 
    b6d2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b6d9:	33 f3 bf 
    b6dc:	e8 1f aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b6e1:	48 89 c7             	mov    %rax,%rdi
    b6e4:	e8 c7 b3 ff ff       	call   6ab0 <fwp_rc_fresh>
    b6e9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b6f0:	00 
    b6f1:	bf 01 00 00 00       	mov    $0x1,%edi
    b6f6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b6fd:	00 
    b6fe:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b705:	00 
    b706:	e8 f5 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b70b:	48 89 c7             	mov    %rax,%rdi
    b70e:	e8 9d b3 ff ff       	call   6ab0 <fwp_rc_fresh>
    b713:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b71a:	00 
    b71b:	bf 01 00 00 00       	mov    $0x1,%edi
    b720:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b727:	00 
    b728:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b72f:	00 
    b730:	e8 cb a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b735:	48 89 c7             	mov    %rax,%rdi
    b738:	e8 73 b3 ff ff       	call   6ab0 <fwp_rc_fresh>
    b73d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b744:	00 
    b745:	bf 01 00 00 00       	mov    $0x1,%edi
    b74a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b751:	00 
    b752:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b759:	00 
    b75a:	e8 a1 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b75f:	48 89 c7             	mov    %rax,%rdi
    b762:	e8 49 b3 ff ff       	call   6ab0 <fwp_rc_fresh>
    b767:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b76e:	00 
    b76f:	bf 01 00 00 00       	mov    $0x1,%edi
    b774:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b77b:	00 
    b77c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b783:	00 
    b784:	e8 77 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b789:	48 89 c7             	mov    %rax,%rdi
    b78c:	e8 1f b3 ff ff       	call   6ab0 <fwp_rc_fresh>
    b791:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b798:	00 
    b799:	bf 01 00 00 00       	mov    $0x1,%edi
    b79e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b7a5:	00 
    b7a6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b7ad:	00 
    b7ae:	e8 4d a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b7b3:	48 89 c7             	mov    %rax,%rdi
    b7b6:	e8 f5 b2 ff ff       	call   6ab0 <fwp_rc_fresh>
    b7bb:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b7c2:	00 
    b7c3:	bf 01 00 00 00       	mov    $0x1,%edi
    b7c8:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b7cf:	00 
    b7d0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b7d7:	00 
    b7d8:	e8 23 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b7dd:	48 89 c7             	mov    %rax,%rdi
    b7e0:	e8 cb b2 ff ff       	call   6ab0 <fwp_rc_fresh>
    b7e5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b7ec:	00 
    b7ed:	bf 01 00 00 00       	mov    $0x1,%edi
    b7f2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b7f9:	00 
    b7fa:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b801:	00 
    b802:	e8 f9 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b807:	48 89 c7             	mov    %rax,%rdi
    b80a:	e8 a1 b2 ff ff       	call   6ab0 <fwp_rc_fresh>
    b80f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b816:	00 
    b817:	bf 01 00 00 00       	mov    $0x1,%edi
    b81c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b823:	00 
    b824:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b82b:	00 
    b82c:	e8 cf a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b831:	48 89 c7             	mov    %rax,%rdi
    b834:	e8 77 b2 ff ff       	call   6ab0 <fwp_rc_fresh>
    b839:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b840:	00 
    b841:	bf 01 00 00 00       	mov    $0x1,%edi
    b846:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b84d:	00 
    b84e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b855:	00 
    b856:	e8 a5 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b85b:	48 89 c7             	mov    %rax,%rdi
    b85e:	e8 4d b2 ff ff       	call   6ab0 <fwp_rc_fresh>
    b863:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b86a:	00 
    b86b:	bf 01 00 00 00       	mov    $0x1,%edi
    b870:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b877:	00 
    b878:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b87f:	00 
    b880:	e8 7b a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b885:	48 89 c7             	mov    %rax,%rdi
    b888:	e8 23 b2 ff ff       	call   6ab0 <fwp_rc_fresh>
    b88d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b894:	00 
    b895:	bf 01 00 00 00       	mov    $0x1,%edi
    b89a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b8a1:	00 
    b8a2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b8a9:	00 
    b8aa:	e8 51 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b8af:	48 89 c7             	mov    %rax,%rdi
    b8b2:	e8 f9 b1 ff ff       	call   6ab0 <fwp_rc_fresh>
    b8b7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b8be:	00 
    b8bf:	bf 01 00 00 00       	mov    $0x1,%edi
    b8c4:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b8cb:	00 
    b8cc:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b8d3:	00 
    b8d4:	e8 27 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b8d9:	48 89 c7             	mov    %rax,%rdi
    b8dc:	e8 cf b1 ff ff       	call   6ab0 <fwp_rc_fresh>
    b8e1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b8e8:	00 
    b8e9:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ee:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b8f5:	00 
    b8f6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b8fd:	00 
    b8fe:	e8 fd a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b903:	48 89 c7             	mov    %rax,%rdi
    b906:	e8 a5 b1 ff ff       	call   6ab0 <fwp_rc_fresh>
    b90b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b912:	00 
    b913:	bf 01 00 00 00       	mov    $0x1,%edi
    b918:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b91f:	00 
    b920:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b927:	00 
    b928:	e8 d3 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b92d:	48 89 c7             	mov    %rax,%rdi
    b930:	e8 7b b1 ff ff       	call   6ab0 <fwp_rc_fresh>
    b935:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b93c:	00 
    b93d:	bf 01 00 00 00       	mov    $0x1,%edi
    b942:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b949:	00 
    b94a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b951:	00 
    b952:	e8 a9 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b957:	48 89 c7             	mov    %rax,%rdi
    b95a:	e8 51 b1 ff ff       	call   6ab0 <fwp_rc_fresh>
    b95f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b966:	00 
    b967:	bf 01 00 00 00       	mov    $0x1,%edi
    b96c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b973:	00 
    b974:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b97b:	00 
    b97c:	e8 7f a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b981:	48 89 c7             	mov    %rax,%rdi
    b984:	e8 27 b1 ff ff       	call   6ab0 <fwp_rc_fresh>
    b989:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b990:	00 
    b991:	bf 01 00 00 00       	mov    $0x1,%edi
    b996:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b99d:	00 
    b99e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b9a5:	00 
    b9a6:	e8 55 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b9ab:	48 89 c7             	mov    %rax,%rdi
    b9ae:	e8 fd b0 ff ff       	call   6ab0 <fwp_rc_fresh>
    b9b3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b9ba:	00 
    b9bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b9c0:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b9c7:	00 
    b9c8:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b9cf:	00 
    b9d0:	e8 2b a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b9d5:	48 89 c7             	mov    %rax,%rdi
    b9d8:	e8 d3 b0 ff ff       	call   6ab0 <fwp_rc_fresh>
    b9dd:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b9e4:	00 
    b9e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b9ea:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b9f1:	00 
    b9f2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b9f9:	00 
    b9fa:	e8 01 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b9ff:	48 89 c7             	mov    %rax,%rdi
    ba02:	e8 a9 b0 ff ff       	call   6ab0 <fwp_rc_fresh>
    ba07:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    ba0e:	00 
    ba0f:	bf 01 00 00 00       	mov    $0x1,%edi
    ba14:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    ba1b:	00 
    ba1c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    ba23:	00 
    ba24:	e8 d7 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba29:	48 89 c7             	mov    %rax,%rdi
    ba2c:	e8 7f b0 ff ff       	call   6ab0 <fwp_rc_fresh>
    ba31:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    ba38:	00 
    ba39:	bf 01 00 00 00       	mov    $0x1,%edi
    ba3e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    ba45:	00 
    ba46:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    ba4d:	00 
    ba4e:	e8 ad a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba53:	48 89 c7             	mov    %rax,%rdi
    ba56:	e8 55 b0 ff ff       	call   6ab0 <fwp_rc_fresh>
    ba5b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    ba62:	00 
    ba63:	bf 01 00 00 00       	mov    $0x1,%edi
    ba68:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    ba6f:	00 
    ba70:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    ba77:	00 
    ba78:	e8 83 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba7d:	48 89 c7             	mov    %rax,%rdi
    ba80:	e8 2b b0 ff ff       	call   6ab0 <fwp_rc_fresh>
    ba85:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    ba8c:	00 
    ba8d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba92:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    ba99:	00 
    ba9a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    baa1:	00 
    baa2:	e8 59 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    baa7:	48 89 c7             	mov    %rax,%rdi
    baaa:	e8 01 b0 ff ff       	call   6ab0 <fwp_rc_fresh>
    baaf:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bab6:	00 
    bab7:	bf 01 00 00 00       	mov    $0x1,%edi
    babc:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    bac3:	00 
    bac4:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    bacb:	00 
    bacc:	e8 2f a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bad1:	48 89 c7             	mov    %rax,%rdi
    bad4:	e8 d7 af ff ff       	call   6ab0 <fwp_rc_fresh>
    bad9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bae0:	00 
    bae1:	bf 01 00 00 00       	mov    $0x1,%edi
    bae6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    baed:	00 
    baee:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    baf5:	00 
    baf6:	e8 05 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bafb:	48 89 c7             	mov    %rax,%rdi
    bafe:	e8 ad af ff ff       	call   6ab0 <fwp_rc_fresh>
    bb03:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    bb0a:	00 
    bb0b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb10:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bb17:	00 
    bb18:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    bb1f:	00 
    bb20:	e8 db a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb25:	48 89 c7             	mov    %rax,%rdi
    bb28:	e8 83 af ff ff       	call   6ab0 <fwp_rc_fresh>
    bb2d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    bb34:	00 
    bb35:	bf 01 00 00 00       	mov    $0x1,%edi
    bb3a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bb41:	00 
    bb42:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bb49:	00 
    bb4a:	e8 b1 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb4f:	48 89 c7             	mov    %rax,%rdi
    bb52:	e8 59 af ff ff       	call   6ab0 <fwp_rc_fresh>
    bb57:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bb5e:	00 
    bb5f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb64:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bb6b:	00 
    bb6c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bb73:	00 
    bb74:	e8 87 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb79:	48 89 c7             	mov    %rax,%rdi
    bb7c:	e8 2f af ff ff       	call   6ab0 <fwp_rc_fresh>
    bb81:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bb88:	00 
    bb89:	bf 01 00 00 00       	mov    $0x1,%edi
    bb8e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bb95:	00 
    bb96:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    bb9d:	00 
    bb9e:	e8 5d a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bba3:	48 89 c7             	mov    %rax,%rdi
    bba6:	e8 05 af ff ff       	call   6ab0 <fwp_rc_fresh>
    bbab:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    bbb2:	00 
    bbb3:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    bbbf:	00 
    bbc0:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    bbc7:	00 
    bbc8:	e8 33 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bbcd:	48 89 c7             	mov    %rax,%rdi
    bbd0:	e8 db ae ff ff       	call   6ab0 <fwp_rc_fresh>
    bbd5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    bbdc:	00 
    bbdd:	bf 01 00 00 00       	mov    $0x1,%edi
    bbe2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    bbe9:	00 
    bbea:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    bbf1:	00 
    bbf2:	e8 09 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bbf7:	48 89 c7             	mov    %rax,%rdi
    bbfa:	e8 b1 ae ff ff       	call   6ab0 <fwp_rc_fresh>
    bbff:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    bc06:	00 
    bc07:	bf 01 00 00 00       	mov    $0x1,%edi
    bc0c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    bc13:	00 
    bc14:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    bc1b:	00 
    bc1c:	e8 df a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc21:	48 89 c7             	mov    %rax,%rdi
    bc24:	e8 87 ae ff ff       	call   6ab0 <fwp_rc_fresh>
    bc29:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    bc30:	00 
    bc31:	bf 01 00 00 00       	mov    $0x1,%edi
    bc36:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bc3d:	00 
    bc3e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bc45:	00 
    bc46:	e8 b5 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc4b:	48 89 c7             	mov    %rax,%rdi
    bc4e:	e8 5d ae ff ff       	call   6ab0 <fwp_rc_fresh>
    bc53:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    bc5a:	00 
    bc5b:	bf 01 00 00 00       	mov    $0x1,%edi
    bc60:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    bc67:	00 
    bc68:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    bc6f:	00 
    bc70:	e8 8b a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc75:	48 89 c7             	mov    %rax,%rdi
    bc78:	e8 33 ae ff ff       	call   6ab0 <fwp_rc_fresh>
    bc7d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bc84:	00 
    bc85:	bf 01 00 00 00       	mov    $0x1,%edi
    bc8a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bc91:	00 
    bc92:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bc99:	00 
    bc9a:	e8 61 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc9f:	48 89 c7             	mov    %rax,%rdi
    bca2:	e8 09 ae ff ff       	call   6ab0 <fwp_rc_fresh>
    bca7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bcae:	00 
    bcaf:	bf 01 00 00 00       	mov    $0x1,%edi
    bcb4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bcbb:	00 
    bcbc:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bcc3:	00 
    bcc4:	e8 37 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bcc9:	48 89 c7             	mov    %rax,%rdi
    bccc:	e8 df ad ff ff       	call   6ab0 <fwp_rc_fresh>
    bcd1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bcd8:	00 
    bcd9:	bf 01 00 00 00       	mov    $0x1,%edi
    bcde:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bce5:	00 
    bce6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bced:	00 
    bcee:	e8 0d a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bcf3:	48 89 c7             	mov    %rax,%rdi
    bcf6:	e8 b5 ad ff ff       	call   6ab0 <fwp_rc_fresh>
    bcfb:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bd02:	00 
    bd03:	bf 01 00 00 00       	mov    $0x1,%edi
    bd08:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bd0f:	00 
    bd10:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bd17:	00 
    bd18:	e8 e3 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd1d:	48 89 c7             	mov    %rax,%rdi
    bd20:	e8 8b ad ff ff       	call   6ab0 <fwp_rc_fresh>
    bd25:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bd2c:	00 
    bd2d:	bf 01 00 00 00       	mov    $0x1,%edi
    bd32:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bd39:	00 
    bd3a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bd41:	00 
    bd42:	e8 b9 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd47:	48 89 c7             	mov    %rax,%rdi
    bd4a:	e8 61 ad ff ff       	call   6ab0 <fwp_rc_fresh>
    bd4f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bd56:	00 
    bd57:	bf 01 00 00 00       	mov    $0x1,%edi
    bd5c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bd63:	00 
    bd64:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bd6b:	00 
    bd6c:	e8 8f a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd71:	48 89 c7             	mov    %rax,%rdi
    bd74:	e8 37 ad ff ff       	call   6ab0 <fwp_rc_fresh>
    bd79:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bd80:	00 
    bd81:	bf 01 00 00 00       	mov    $0x1,%edi
    bd86:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bd8d:	00 
    bd8e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bd95:	00 
    bd96:	e8 65 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd9b:	48 89 c7             	mov    %rax,%rdi
    bd9e:	e8 0d ad ff ff       	call   6ab0 <fwp_rc_fresh>
    bda3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bdaa:	00 
    bdab:	bf 01 00 00 00       	mov    $0x1,%edi
    bdb0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bdb7:	00 
    bdb8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bdbf:	00 
    bdc0:	e8 3b a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bdc5:	48 89 c7             	mov    %rax,%rdi
    bdc8:	e8 e3 ac ff ff       	call   6ab0 <fwp_rc_fresh>
    bdcd:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bdd4:	00 
    bdd5:	bf 01 00 00 00       	mov    $0x1,%edi
    bdda:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    bde1:	00 
    bde2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    bde9:	00 
    bdea:	e8 11 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bdef:	48 89 c7             	mov    %rax,%rdi
    bdf2:	e8 b9 ac ff ff       	call   6ab0 <fwp_rc_fresh>
    bdf7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    bdfe:	00 
    bdff:	bf 01 00 00 00       	mov    $0x1,%edi
    be04:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    be0b:	00 
    be0c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    be13:	00 
    be14:	e8 e7 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be19:	48 89 c7             	mov    %rax,%rdi
    be1c:	e8 8f ac ff ff       	call   6ab0 <fwp_rc_fresh>
    be21:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    be28:	00 
    be29:	bf 01 00 00 00       	mov    $0x1,%edi
    be2e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    be35:	00 
    be36:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    be3d:	00 
    be3e:	e8 bd a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be43:	48 89 c7             	mov    %rax,%rdi
    be46:	e8 65 ac ff ff       	call   6ab0 <fwp_rc_fresh>
    be4b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    be52:	00 
    be53:	bf 01 00 00 00       	mov    $0x1,%edi
    be58:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    be5f:	00 
    be60:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    be67:	00 
    be68:	e8 93 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be6d:	48 89 c7             	mov    %rax,%rdi
    be70:	e8 3b ac ff ff       	call   6ab0 <fwp_rc_fresh>
    be75:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    be7c:	00 
    be7d:	bf 01 00 00 00       	mov    $0x1,%edi
    be82:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    be89:	00 
    be8a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    be91:	00 
    be92:	e8 69 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be97:	48 89 c7             	mov    %rax,%rdi
    be9a:	e8 11 ac ff ff       	call   6ab0 <fwp_rc_fresh>
    be9f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    bea6:	00 
    bea7:	bf 01 00 00 00       	mov    $0x1,%edi
    beac:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    beb3:	00 
    beb4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    bebb:	00 
    bebc:	e8 3f a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bec1:	48 89 c7             	mov    %rax,%rdi
    bec4:	e8 e7 ab ff ff       	call   6ab0 <fwp_rc_fresh>
    bec9:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    bed0:	00 
    bed1:	bf 01 00 00 00       	mov    $0x1,%edi
    bed6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    bedd:	00 
    bede:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    bee5:	00 
    bee6:	e8 15 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    beeb:	48 89 c7             	mov    %rax,%rdi
    beee:	e8 bd ab ff ff       	call   6ab0 <fwp_rc_fresh>
    bef3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    befa:	00 
    befb:	bf 01 00 00 00       	mov    $0x1,%edi
    bf00:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    bf07:	00 
    bf08:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    bf0f:	00 
    bf10:	e8 eb a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf15:	48 89 c7             	mov    %rax,%rdi
    bf18:	e8 93 ab ff ff       	call   6ab0 <fwp_rc_fresh>
    bf1d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bf24:	00 
    bf25:	bf 01 00 00 00       	mov    $0x1,%edi
    bf2a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bf31:	00 
    bf32:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bf39:	00 
    bf3a:	e8 c1 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf3f:	48 89 c7             	mov    %rax,%rdi
    bf42:	e8 69 ab ff ff       	call   6ab0 <fwp_rc_fresh>
    bf47:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    bf4e:	00 
    bf4f:	bf 01 00 00 00       	mov    $0x1,%edi
    bf54:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    bf5b:	00 
    bf5c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    bf63:	00 
    bf64:	e8 97 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf69:	48 89 c7             	mov    %rax,%rdi
    bf6c:	e8 3f ab ff ff       	call   6ab0 <fwp_rc_fresh>
    bf71:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    bf78:	00 
    bf79:	bf 01 00 00 00       	mov    $0x1,%edi
    bf7e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    bf85:	00 
    bf86:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    bf8d:	00 
    bf8e:	e8 6d a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf93:	48 89 c7             	mov    %rax,%rdi
    bf96:	e8 15 ab ff ff       	call   6ab0 <fwp_rc_fresh>
    bf9b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    bfa2:	00 
    bfa3:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    bfaf:	00 
    bfb0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    bfb7:	00 
    bfb8:	e8 43 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bfbd:	48 89 c7             	mov    %rax,%rdi
    bfc0:	e8 eb aa ff ff       	call   6ab0 <fwp_rc_fresh>
    bfc5:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    bfcc:	00 
    bfcd:	bf 01 00 00 00       	mov    $0x1,%edi
    bfd2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    bfd9:	00 
    bfda:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    bfe1:	00 
    bfe2:	e8 19 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bfe7:	48 89 c7             	mov    %rax,%rdi
    bfea:	e8 c1 aa ff ff       	call   6ab0 <fwp_rc_fresh>
    bfef:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    bff6:	00 
    bff7:	bf 01 00 00 00       	mov    $0x1,%edi
    bffc:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c003:	00 
    c004:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c00b:	00 
    c00c:	e8 ef a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c011:	48 89 c7             	mov    %rax,%rdi
    c014:	e8 97 aa ff ff       	call   6ab0 <fwp_rc_fresh>
    c019:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c020:	00 
    c021:	bf 01 00 00 00       	mov    $0x1,%edi
    c026:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c02d:	00 
    c02e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c035:	00 
    c036:	e8 c5 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c03b:	48 89 c7             	mov    %rax,%rdi
    c03e:	e8 6d aa ff ff       	call   6ab0 <fwp_rc_fresh>
    c043:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c04a:	00 
    c04b:	bf 01 00 00 00       	mov    $0x1,%edi
    c050:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c057:	00 
    c058:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c05f:	00 
    c060:	e8 9b a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c065:	48 89 c7             	mov    %rax,%rdi
    c068:	e8 43 aa ff ff       	call   6ab0 <fwp_rc_fresh>
    c06d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c074:	00 
    c075:	bf 01 00 00 00       	mov    $0x1,%edi
    c07a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c081:	00 
    c082:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c089:	00 
    c08a:	e8 71 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c08f:	48 89 c7             	mov    %rax,%rdi
    c092:	e8 19 aa ff ff       	call   6ab0 <fwp_rc_fresh>
    c097:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c09e:	00 
    c09f:	bf 01 00 00 00       	mov    $0x1,%edi
    c0a4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c0ab:	00 
    c0ac:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c0b3:	00 
    c0b4:	e8 47 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c0b9:	48 89 c7             	mov    %rax,%rdi
    c0bc:	e8 ef a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c0c1:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c0c8:	00 
    c0c9:	bf 01 00 00 00       	mov    $0x1,%edi
    c0ce:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c0d5:	00 
    c0d6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c0dd:	00 
    c0de:	e8 1d a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c0e3:	48 89 c7             	mov    %rax,%rdi
    c0e6:	e8 c5 a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c0eb:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c0f2:	00 
    c0f3:	bf 01 00 00 00       	mov    $0x1,%edi
    c0f8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c0ff:	00 
    c100:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c107:	00 
    c108:	e8 f3 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c10d:	48 89 c7             	mov    %rax,%rdi
    c110:	e8 9b a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c115:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c11c:	00 
    c11d:	bf 01 00 00 00       	mov    $0x1,%edi
    c122:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c129:	00 
    c12a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c131:	00 
    c132:	e8 c9 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c137:	48 89 c7             	mov    %rax,%rdi
    c13a:	e8 71 a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c13f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c146:	00 
    c147:	bf 01 00 00 00       	mov    $0x1,%edi
    c14c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c153:	00 
    c154:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c15b:	00 
    c15c:	e8 9f 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c161:	48 89 c7             	mov    %rax,%rdi
    c164:	e8 47 a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c169:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c170:	00 
    c171:	bf 01 00 00 00       	mov    $0x1,%edi
    c176:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c17d:	00 
    c17e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c185:	00 
    c186:	e8 75 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c18b:	48 89 c7             	mov    %rax,%rdi
    c18e:	e8 1d a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c193:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c19a:	00 
    c19b:	bf 01 00 00 00       	mov    $0x1,%edi
    c1a0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c1a7:	00 
    c1a8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c1af:	00 
    c1b0:	e8 4b 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c1b5:	48 89 c7             	mov    %rax,%rdi
    c1b8:	e8 f3 a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c1bd:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c1c4:	00 
    c1c5:	bf 01 00 00 00       	mov    $0x1,%edi
    c1ca:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c1d1:	00 
    c1d2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c1d9:	00 
    c1da:	e8 21 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c1df:	48 89 c7             	mov    %rax,%rdi
    c1e2:	e8 c9 a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c1e7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c1ee:	00 
    c1ef:	bf 01 00 00 00       	mov    $0x1,%edi
    c1f4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c1fb:	00 
    c1fc:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c203:	00 
    c204:	e8 f7 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c209:	48 89 c7             	mov    %rax,%rdi
    c20c:	e8 9f a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c211:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c218:	00 
    c219:	bf 01 00 00 00       	mov    $0x1,%edi
    c21e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c225:	00 
    c226:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c22d:	00 
    c22e:	e8 cd 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c233:	48 89 c7             	mov    %rax,%rdi
    c236:	e8 75 a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c23b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c242:	00 
    c243:	bf 01 00 00 00       	mov    $0x1,%edi
    c248:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c24f:	00 
    c250:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c257:	00 
    c258:	e8 a3 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c25d:	48 89 c7             	mov    %rax,%rdi
    c260:	e8 4b a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c265:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c26c:	00 
    c26d:	bf 01 00 00 00       	mov    $0x1,%edi
    c272:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c279:	00 
    c27a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c281:	00 
    c282:	e8 79 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c287:	48 89 c7             	mov    %rax,%rdi
    c28a:	e8 21 a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c28f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c296:	00 
    c297:	bf 01 00 00 00       	mov    $0x1,%edi
    c29c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c2a3:	00 
    c2a4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c2ab:	00 
    c2ac:	e8 4f 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c2b1:	48 89 c7             	mov    %rax,%rdi
    c2b4:	e8 f7 a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c2b9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c2c0:	00 
    c2c1:	bf 01 00 00 00       	mov    $0x1,%edi
    c2c6:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c2cd:	00 
    c2ce:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c2d5:	00 
    c2d6:	e8 25 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c2db:	48 89 c7             	mov    %rax,%rdi
    c2de:	e8 cd a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c2e3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c2ea:	00 
    c2eb:	bf 01 00 00 00       	mov    $0x1,%edi
    c2f0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c2f7:	00 
    c2f8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c2ff:	00 
    c300:	e8 fb 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c305:	48 89 c7             	mov    %rax,%rdi
    c308:	e8 a3 a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c30d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c314:	00 
    c315:	bf 01 00 00 00       	mov    $0x1,%edi
    c31a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c321:	00 
    c322:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c329:	00 
    c32a:	e8 d1 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c32f:	48 89 c7             	mov    %rax,%rdi
    c332:	e8 79 a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c337:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c33e:	00 
    c33f:	bf 01 00 00 00       	mov    $0x1,%edi
    c344:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c34b:	00 
    c34c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c353:	00 
    c354:	e8 a7 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c359:	48 89 c7             	mov    %rax,%rdi
    c35c:	e8 4f a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c361:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c368:	00 
    c369:	bf 01 00 00 00       	mov    $0x1,%edi
    c36e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c375:	00 
    c376:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c37d:	00 
    c37e:	e8 7d 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c383:	48 89 c7             	mov    %rax,%rdi
    c386:	e8 25 a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c38b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c392:	00 
    c393:	bf 01 00 00 00       	mov    $0x1,%edi
    c398:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c39f:	00 
    c3a0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c3a7:	00 
    c3a8:	e8 53 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c3ad:	48 89 c7             	mov    %rax,%rdi
    c3b0:	e8 fb a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c3b5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c3bc:	00 
    c3bd:	bf 01 00 00 00       	mov    $0x1,%edi
    c3c2:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c3c9:	00 
    c3ca:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c3d1:	00 
    c3d2:	e8 29 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c3d7:	48 89 c7             	mov    %rax,%rdi
    c3da:	e8 d1 a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c3df:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c3e6:	00 
    c3e7:	bf 01 00 00 00       	mov    $0x1,%edi
    c3ec:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c3f3:	00 
    c3f4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c3fb:	00 
    c3fc:	e8 ff 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c401:	48 89 c7             	mov    %rax,%rdi
    c404:	e8 a7 a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c409:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c410:	00 
    c411:	bf 01 00 00 00       	mov    $0x1,%edi
    c416:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c41d:	00 
    c41e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c425:	00 
    c426:	e8 d5 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c42b:	48 89 c7             	mov    %rax,%rdi
    c42e:	e8 7d a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c433:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c43a:	00 
    c43b:	bf 01 00 00 00       	mov    $0x1,%edi
    c440:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c447:	00 
    c448:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c44f:	00 
    c450:	e8 ab 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c455:	48 89 c7             	mov    %rax,%rdi
    c458:	e8 53 a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c45d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c464:	00 
    c465:	bf 01 00 00 00       	mov    $0x1,%edi
    c46a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c471:	00 
    c472:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c479:	00 
    c47a:	e8 81 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c47f:	48 89 c7             	mov    %rax,%rdi
    c482:	e8 29 a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c487:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c48e:	00 
    c48f:	bf 01 00 00 00       	mov    $0x1,%edi
    c494:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c49b:	00 
    c49c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c4a3:	00 
    c4a4:	e8 57 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c4a9:	48 89 c7             	mov    %rax,%rdi
    c4ac:	e8 ff a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c4b1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c4b8:	00 
    c4b9:	bf 01 00 00 00       	mov    $0x1,%edi
    c4be:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c4c5:	00 
    c4c6:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c4cd:	00 
    c4ce:	e8 2d 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c4d3:	48 89 c7             	mov    %rax,%rdi
    c4d6:	e8 d5 a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c4db:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c4e2:	00 
    c4e3:	bf 01 00 00 00       	mov    $0x1,%edi
    c4e8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c4ef:	00 
    c4f0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c4f7:	00 
    c4f8:	e8 03 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c4fd:	48 89 c7             	mov    %rax,%rdi
    c500:	e8 ab a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c505:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c50c:	00 
    c50d:	bf 01 00 00 00       	mov    $0x1,%edi
    c512:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c519:	00 
    c51a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c521:	00 
    c522:	e8 d9 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c527:	48 89 c7             	mov    %rax,%rdi
    c52a:	e8 81 a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c52f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c536:	00 
    c537:	bf 01 00 00 00       	mov    $0x1,%edi
    c53c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c543:	00 
    c544:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c54b:	00 
    c54c:	e8 af 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c551:	48 89 c7             	mov    %rax,%rdi
    c554:	e8 57 a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c559:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c560:	00 
    c561:	bf 01 00 00 00       	mov    $0x1,%edi
    c566:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c56d:	00 
    c56e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c575:	00 
    c576:	e8 85 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c57b:	48 89 c7             	mov    %rax,%rdi
    c57e:	e8 2d a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c583:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c58a:	00 
    c58b:	bf 01 00 00 00       	mov    $0x1,%edi
    c590:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c597:	00 
    c598:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c59f:	00 
    c5a0:	e8 5b 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c5a5:	48 8b 15 4c 06 06 00 	mov    0x6064c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c5ac:	49 89 c5             	mov    %rax,%r13
    c5af:	48 2b 05 1a 06 06 00 	sub    0x6061a(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c5b6:	48 c1 e2 10          	shl    $0x10,%rdx
    c5ba:	48 39 d0             	cmp    %rdx,%rax
    c5bd:	73 59                	jae    c618 <f0+0x13b8>
    c5bf:	48 89 c2             	mov    %rax,%rdx
    c5c2:	48 c1 ea 10          	shr    $0x10,%rdx
    c5c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5ca:	48 8b 15 47 06 06 00 	mov    0x60647(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c5d1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5d5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5d9:	4d 85 e4             	test   %r12,%r12
    c5dc:	74 3a                	je     c618 <f0+0x13b8>
    c5de:	0f b6 0a             	movzbl (%rdx),%ecx
    c5e1:	80 f9 02             	cmp    $0x2,%cl
    c5e4:	0f 84 c6 15 00 00    	je     dbb0 <f0+0x2950>
    c5ea:	80 f9 01             	cmp    $0x1,%cl
    c5ed:	75 29                	jne    c618 <f0+0x13b8>
    c5ef:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5f2:	0f b7 c0             	movzwl %ax,%eax
    c5f5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5f8:	48 0f af c1          	imul   %rcx,%rax
    c5fc:	48 c1 e8 20          	shr    $0x20,%rax
    c600:	48 39 d0             	cmp    %rdx,%rax
    c603:	73 13                	jae    c618 <f0+0x13b8>
    c605:	49 01 c4             	add    %rax,%r12
    c608:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c60d:	0f 84 99 17 00 00    	je     ddac <f0+0x2b4c>
    c613:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c618:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c61f:	33 f3 bf 
    c622:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c629:	00 
    c62a:	bf 01 00 00 00       	mov    $0x1,%edi
    c62f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c636:	00 
    c637:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c63e:	00 
    c63f:	e8 bc 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c644:	48 8b 15 ad 05 06 00 	mov    0x605ad(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c64b:	49 89 c5             	mov    %rax,%r13
    c64e:	48 2b 05 7b 05 06 00 	sub    0x6057b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c655:	48 c1 e2 10          	shl    $0x10,%rdx
    c659:	48 39 d0             	cmp    %rdx,%rax
    c65c:	73 59                	jae    c6b7 <f0+0x1457>
    c65e:	48 89 c2             	mov    %rax,%rdx
    c661:	48 c1 ea 10          	shr    $0x10,%rdx
    c665:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c669:	48 8b 15 a8 05 06 00 	mov    0x605a8(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c670:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c674:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c678:	4d 85 e4             	test   %r12,%r12
    c67b:	74 3a                	je     c6b7 <f0+0x1457>
    c67d:	0f b6 0a             	movzbl (%rdx),%ecx
    c680:	80 f9 02             	cmp    $0x2,%cl
    c683:	0f 84 17 15 00 00    	je     dba0 <f0+0x2940>
    c689:	80 f9 01             	cmp    $0x1,%cl
    c68c:	75 29                	jne    c6b7 <f0+0x1457>
    c68e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c691:	0f b7 c0             	movzwl %ax,%eax
    c694:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c697:	48 0f af c1          	imul   %rcx,%rax
    c69b:	48 c1 e8 20          	shr    $0x20,%rax
    c69f:	48 39 d0             	cmp    %rdx,%rax
    c6a2:	73 13                	jae    c6b7 <f0+0x1457>
    c6a4:	49 01 c4             	add    %rax,%r12
    c6a7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6ac:	0f 84 07 17 00 00    	je     ddb9 <f0+0x2b59>
    c6b2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6b7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c6be:	00 f0 3f 
    c6c1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c6c8:	00 
    c6c9:	bf 01 00 00 00       	mov    $0x1,%edi
    c6ce:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c6d5:	00 
    c6d6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c6dd:	00 
    c6de:	e8 1d 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c6e3:	48 8b 15 0e 05 06 00 	mov    0x6050e(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c6ea:	49 89 c5             	mov    %rax,%r13
    c6ed:	48 2b 05 dc 04 06 00 	sub    0x604dc(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c6f4:	48 c1 e2 10          	shl    $0x10,%rdx
    c6f8:	48 39 d0             	cmp    %rdx,%rax
    c6fb:	73 59                	jae    c756 <f0+0x14f6>
    c6fd:	48 89 c2             	mov    %rax,%rdx
    c700:	48 c1 ea 10          	shr    $0x10,%rdx
    c704:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c708:	48 8b 15 09 05 06 00 	mov    0x60509(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c70f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c713:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c717:	4d 85 e4             	test   %r12,%r12
    c71a:	74 3a                	je     c756 <f0+0x14f6>
    c71c:	0f b6 0a             	movzbl (%rdx),%ecx
    c71f:	80 f9 02             	cmp    $0x2,%cl
    c722:	0f 84 28 15 00 00    	je     dc50 <f0+0x29f0>
    c728:	80 f9 01             	cmp    $0x1,%cl
    c72b:	75 29                	jne    c756 <f0+0x14f6>
    c72d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c730:	0f b7 c0             	movzwl %ax,%eax
    c733:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c736:	48 0f af c1          	imul   %rcx,%rax
    c73a:	48 c1 e8 20          	shr    $0x20,%rax
    c73e:	48 39 d0             	cmp    %rdx,%rax
    c741:	73 13                	jae    c756 <f0+0x14f6>
    c743:	49 01 c4             	add    %rax,%r12
    c746:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c74b:	0f 84 75 16 00 00    	je     ddc6 <f0+0x2b66>
    c751:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c756:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c75d:	33 f3 bf 
    c760:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c767:	00 
    c768:	bf 01 00 00 00       	mov    $0x1,%edi
    c76d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c774:	00 
    c775:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c77c:	00 
    c77d:	e8 7e 99 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c782:	48 8b 15 6f 04 06 00 	mov    0x6046f(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c789:	49 89 c5             	mov    %rax,%r13
    c78c:	48 2b 05 3d 04 06 00 	sub    0x6043d(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c793:	48 c1 e2 10          	shl    $0x10,%rdx
    c797:	48 39 d0             	cmp    %rdx,%rax
    c79a:	73 59                	jae    c7f5 <f0+0x1595>
    c79c:	48 89 c2             	mov    %rax,%rdx
    c79f:	48 c1 ea 10          	shr    $0x10,%rdx
    c7a3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7a7:	48 8b 15 6a 04 06 00 	mov    0x6046a(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c7ae:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7b2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7b6:	4d 85 e4             	test   %r12,%r12
    c7b9:	74 3a                	je     c7f5 <f0+0x1595>
    c7bb:	0f b6 0a             	movzbl (%rdx),%ecx
    c7be:	80 f9 02             	cmp    $0x2,%cl
    c7c1:	0f 84 79 14 00 00    	je     dc40 <f0+0x29e0>
    c7c7:	80 f9 01             	cmp    $0x1,%cl
    c7ca:	75 29                	jne    c7f5 <f0+0x1595>
    c7cc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7cf:	0f b7 c0             	movzwl %ax,%eax
    c7d2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7d5:	48 0f af c1          	imul   %rcx,%rax
    c7d9:	48 c1 e8 20          	shr    $0x20,%rax
    c7dd:	48 39 d0             	cmp    %rdx,%rax
    c7e0:	73 13                	jae    c7f5 <f0+0x1595>
    c7e2:	49 01 c4             	add    %rax,%r12
    c7e5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7ea:	0f 84 e3 15 00 00    	je     ddd3 <f0+0x2b73>
    c7f0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7f5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c7fc:	00 f0 3f 
    c7ff:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c806:	00 
    c807:	bf 01 00 00 00       	mov    $0x1,%edi
    c80c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c813:	00 
    c814:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c81b:	00 
    c81c:	e8 df 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c821:	48 8b 15 d0 03 06 00 	mov    0x603d0(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c828:	49 89 c5             	mov    %rax,%r13
    c82b:	48 2b 05 9e 03 06 00 	sub    0x6039e(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c832:	48 c1 e2 10          	shl    $0x10,%rdx
    c836:	48 39 d0             	cmp    %rdx,%rax
    c839:	73 59                	jae    c894 <f0+0x1634>
    c83b:	48 89 c2             	mov    %rax,%rdx
    c83e:	48 c1 ea 10          	shr    $0x10,%rdx
    c842:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c846:	48 8b 15 cb 03 06 00 	mov    0x603cb(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c84d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c851:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c855:	4d 85 e4             	test   %r12,%r12
    c858:	74 3a                	je     c894 <f0+0x1634>
    c85a:	0f b6 0a             	movzbl (%rdx),%ecx
    c85d:	80 f9 02             	cmp    $0x2,%cl
    c860:	0f 84 ca 13 00 00    	je     dc30 <f0+0x29d0>
    c866:	80 f9 01             	cmp    $0x1,%cl
    c869:	75 29                	jne    c894 <f0+0x1634>
    c86b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c86e:	0f b7 c0             	movzwl %ax,%eax
    c871:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c874:	48 0f af c1          	imul   %rcx,%rax
    c878:	48 c1 e8 20          	shr    $0x20,%rax
    c87c:	48 39 d0             	cmp    %rdx,%rax
    c87f:	73 13                	jae    c894 <f0+0x1634>
    c881:	49 01 c4             	add    %rax,%r12
    c884:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c889:	0f 84 51 15 00 00    	je     dde0 <f0+0x2b80>
    c88f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c894:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c89b:	33 f3 bf 
    c89e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c8a5:	00 
    c8a6:	bf 01 00 00 00       	mov    $0x1,%edi
    c8ab:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c8b2:	00 
    c8b3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c8ba:	00 
    c8bb:	e8 40 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c8c0:	48 8b 15 31 03 06 00 	mov    0x60331(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c8c7:	49 89 c5             	mov    %rax,%r13
    c8ca:	48 2b 05 ff 02 06 00 	sub    0x602ff(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c8d1:	48 c1 e2 10          	shl    $0x10,%rdx
    c8d5:	48 39 d0             	cmp    %rdx,%rax
    c8d8:	73 59                	jae    c933 <f0+0x16d3>
    c8da:	48 89 c2             	mov    %rax,%rdx
    c8dd:	48 c1 ea 10          	shr    $0x10,%rdx
    c8e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8e5:	48 8b 15 2c 03 06 00 	mov    0x6032c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c8ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8f0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8f4:	4d 85 e4             	test   %r12,%r12
    c8f7:	74 3a                	je     c933 <f0+0x16d3>
    c8f9:	0f b6 0a             	movzbl (%rdx),%ecx
    c8fc:	80 f9 02             	cmp    $0x2,%cl
    c8ff:	0f 84 1b 13 00 00    	je     dc20 <f0+0x29c0>
    c905:	80 f9 01             	cmp    $0x1,%cl
    c908:	75 29                	jne    c933 <f0+0x16d3>
    c90a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c90d:	0f b7 c0             	movzwl %ax,%eax
    c910:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c913:	48 0f af c1          	imul   %rcx,%rax
    c917:	48 c1 e8 20          	shr    $0x20,%rax
    c91b:	48 39 d0             	cmp    %rdx,%rax
    c91e:	73 13                	jae    c933 <f0+0x16d3>
    c920:	49 01 c4             	add    %rax,%r12
    c923:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c928:	0f 84 bf 14 00 00    	je     dded <f0+0x2b8d>
    c92e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c933:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c93a:	00 f0 3f 
    c93d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c944:	00 
    c945:	bf 01 00 00 00       	mov    $0x1,%edi
    c94a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c951:	00 
    c952:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c959:	00 
    c95a:	e8 a1 97 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c95f:	48 8b 15 92 02 06 00 	mov    0x60292(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c966:	49 89 c5             	mov    %rax,%r13
    c969:	48 2b 05 60 02 06 00 	sub    0x60260(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c970:	48 c1 e2 10          	shl    $0x10,%rdx
    c974:	48 39 d0             	cmp    %rdx,%rax
    c977:	73 59                	jae    c9d2 <f0+0x1772>
    c979:	48 89 c2             	mov    %rax,%rdx
    c97c:	48 c1 ea 10          	shr    $0x10,%rdx
    c980:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c984:	48 8b 15 8d 02 06 00 	mov    0x6028d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c98b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c98f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c993:	4d 85 e4             	test   %r12,%r12
    c996:	74 3a                	je     c9d2 <f0+0x1772>
    c998:	0f b6 0a             	movzbl (%rdx),%ecx
    c99b:	80 f9 02             	cmp    $0x2,%cl
    c99e:	0f 84 6c 12 00 00    	je     dc10 <f0+0x29b0>
    c9a4:	80 f9 01             	cmp    $0x1,%cl
    c9a7:	75 29                	jne    c9d2 <f0+0x1772>
    c9a9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9ac:	0f b7 c0             	movzwl %ax,%eax
    c9af:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9b2:	48 0f af c1          	imul   %rcx,%rax
    c9b6:	48 c1 e8 20          	shr    $0x20,%rax
    c9ba:	48 39 d0             	cmp    %rdx,%rax
    c9bd:	73 13                	jae    c9d2 <f0+0x1772>
    c9bf:	49 01 c4             	add    %rax,%r12
    c9c2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9c7:	0f 84 2d 14 00 00    	je     ddfa <f0+0x2b9a>
    c9cd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9d2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c9d9:	33 f3 bf 
    c9dc:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c9e3:	00 
    c9e4:	bf 01 00 00 00       	mov    $0x1,%edi
    c9e9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c9f0:	00 
    c9f1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c9f8:	00 
    c9f9:	e8 02 97 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c9fe:	48 8b 15 f3 01 06 00 	mov    0x601f3(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    ca05:	49 89 c5             	mov    %rax,%r13
    ca08:	48 2b 05 c1 01 06 00 	sub    0x601c1(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    ca0f:	48 c1 e2 10          	shl    $0x10,%rdx
    ca13:	48 39 d0             	cmp    %rdx,%rax
    ca16:	73 59                	jae    ca71 <f0+0x1811>
    ca18:	48 89 c2             	mov    %rax,%rdx
    ca1b:	48 c1 ea 10          	shr    $0x10,%rdx
    ca1f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca23:	48 8b 15 ee 01 06 00 	mov    0x601ee(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ca2a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca2e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca32:	4d 85 e4             	test   %r12,%r12
    ca35:	74 3a                	je     ca71 <f0+0x1811>
    ca37:	0f b6 0a             	movzbl (%rdx),%ecx
    ca3a:	80 f9 02             	cmp    $0x2,%cl
    ca3d:	0f 84 bd 11 00 00    	je     dc00 <f0+0x29a0>
    ca43:	80 f9 01             	cmp    $0x1,%cl
    ca46:	75 29                	jne    ca71 <f0+0x1811>
    ca48:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca4b:	0f b7 c0             	movzwl %ax,%eax
    ca4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca51:	48 0f af c1          	imul   %rcx,%rax
    ca55:	48 c1 e8 20          	shr    $0x20,%rax
    ca59:	48 39 d0             	cmp    %rdx,%rax
    ca5c:	73 13                	jae    ca71 <f0+0x1811>
    ca5e:	49 01 c4             	add    %rax,%r12
    ca61:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca66:	0f 84 9b 13 00 00    	je     de07 <f0+0x2ba7>
    ca6c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca71:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca78:	00 f0 3f 
    ca7b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    ca82:	00 
    ca83:	bf 01 00 00 00       	mov    $0x1,%edi
    ca88:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    ca8f:	00 
    ca90:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    ca97:	00 
    ca98:	e8 63 96 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ca9d:	48 8b 15 54 01 06 00 	mov    0x60154(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    caa4:	49 89 c5             	mov    %rax,%r13
    caa7:	48 2b 05 22 01 06 00 	sub    0x60122(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    caae:	48 c1 e2 10          	shl    $0x10,%rdx
    cab2:	48 39 d0             	cmp    %rdx,%rax
    cab5:	73 59                	jae    cb10 <f0+0x18b0>
    cab7:	48 89 c2             	mov    %rax,%rdx
    caba:	48 c1 ea 10          	shr    $0x10,%rdx
    cabe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cac2:	48 8b 15 4f 01 06 00 	mov    0x6014f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cac9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cacd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cad1:	4d 85 e4             	test   %r12,%r12
    cad4:	74 3a                	je     cb10 <f0+0x18b0>
    cad6:	0f b6 0a             	movzbl (%rdx),%ecx
    cad9:	80 f9 02             	cmp    $0x2,%cl
    cadc:	0f 84 0e 11 00 00    	je     dbf0 <f0+0x2990>
    cae2:	80 f9 01             	cmp    $0x1,%cl
    cae5:	75 29                	jne    cb10 <f0+0x18b0>
    cae7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caea:	0f b7 c0             	movzwl %ax,%eax
    caed:	8b 52 1c             	mov    0x1c(%rdx),%edx
    caf0:	48 0f af c1          	imul   %rcx,%rax
    caf4:	48 c1 e8 20          	shr    $0x20,%rax
    caf8:	48 39 d0             	cmp    %rdx,%rax
    cafb:	73 13                	jae    cb10 <f0+0x18b0>
    cafd:	49 01 c4             	add    %rax,%r12
    cb00:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb05:	0f 84 09 13 00 00    	je     de14 <f0+0x2bb4>
    cb0b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb10:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb17:	33 f3 bf 
    cb1a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    cb21:	00 
    cb22:	bf 01 00 00 00       	mov    $0x1,%edi
    cb27:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    cb2e:	00 
    cb2f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    cb36:	00 
    cb37:	e8 c4 95 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cb3c:	48 8b 15 b5 00 06 00 	mov    0x600b5(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cb43:	49 89 c5             	mov    %rax,%r13
    cb46:	48 2b 05 83 00 06 00 	sub    0x60083(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cb4d:	48 c1 e2 10          	shl    $0x10,%rdx
    cb51:	48 39 d0             	cmp    %rdx,%rax
    cb54:	73 59                	jae    cbaf <f0+0x194f>
    cb56:	48 89 c2             	mov    %rax,%rdx
    cb59:	48 c1 ea 10          	shr    $0x10,%rdx
    cb5d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb61:	48 8b 15 b0 00 06 00 	mov    0x600b0(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cb68:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb6c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb70:	4d 85 e4             	test   %r12,%r12
    cb73:	74 3a                	je     cbaf <f0+0x194f>
    cb75:	0f b6 0a             	movzbl (%rdx),%ecx
    cb78:	80 f9 02             	cmp    $0x2,%cl
    cb7b:	0f 84 5f 10 00 00    	je     dbe0 <f0+0x2980>
    cb81:	80 f9 01             	cmp    $0x1,%cl
    cb84:	75 29                	jne    cbaf <f0+0x194f>
    cb86:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb89:	0f b7 c0             	movzwl %ax,%eax
    cb8c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb8f:	48 0f af c1          	imul   %rcx,%rax
    cb93:	48 c1 e8 20          	shr    $0x20,%rax
    cb97:	48 39 d0             	cmp    %rdx,%rax
    cb9a:	73 13                	jae    cbaf <f0+0x194f>
    cb9c:	49 01 c4             	add    %rax,%r12
    cb9f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cba4:	0f 84 77 12 00 00    	je     de21 <f0+0x2bc1>
    cbaa:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbaf:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cbb6:	00 f0 3f 
    cbb9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    cbc0:	00 
    cbc1:	bf 01 00 00 00       	mov    $0x1,%edi
    cbc6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    cbcd:	00 
    cbce:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    cbd5:	00 
    cbd6:	e8 25 95 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cbdb:	48 8b 15 16 00 06 00 	mov    0x60016(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cbe2:	49 89 c5             	mov    %rax,%r13
    cbe5:	48 2b 05 e4 ff 05 00 	sub    0x5ffe4(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cbec:	48 c1 e2 10          	shl    $0x10,%rdx
    cbf0:	48 39 d0             	cmp    %rdx,%rax
    cbf3:	73 59                	jae    cc4e <f0+0x19ee>
    cbf5:	48 89 c2             	mov    %rax,%rdx
    cbf8:	48 c1 ea 10          	shr    $0x10,%rdx
    cbfc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc00:	48 8b 15 11 00 06 00 	mov    0x60011(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cc07:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc0b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc0f:	4d 85 e4             	test   %r12,%r12
    cc12:	74 3a                	je     cc4e <f0+0x19ee>
    cc14:	0f b6 0a             	movzbl (%rdx),%ecx
    cc17:	80 f9 02             	cmp    $0x2,%cl
    cc1a:	0f 84 40 0f 00 00    	je     db60 <f0+0x2900>
    cc20:	80 f9 01             	cmp    $0x1,%cl
    cc23:	75 29                	jne    cc4e <f0+0x19ee>
    cc25:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc28:	0f b7 c0             	movzwl %ax,%eax
    cc2b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc2e:	48 0f af c1          	imul   %rcx,%rax
    cc32:	48 c1 e8 20          	shr    $0x20,%rax
    cc36:	48 39 d0             	cmp    %rdx,%rax
    cc39:	73 13                	jae    cc4e <f0+0x19ee>
    cc3b:	49 01 c4             	add    %rax,%r12
    cc3e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc43:	0f 84 e5 11 00 00    	je     de2e <f0+0x2bce>
    cc49:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc4e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cc55:	33 f3 bf 
    cc58:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    cc5f:	00 
    cc60:	bf 01 00 00 00       	mov    $0x1,%edi
    cc65:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    cc6c:	00 
    cc6d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cc74:	00 
    cc75:	e8 86 94 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cc7a:	48 8b 15 77 ff 05 00 	mov    0x5ff77(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cc81:	49 89 c5             	mov    %rax,%r13
    cc84:	48 2b 05 45 ff 05 00 	sub    0x5ff45(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cc8b:	48 c1 e2 10          	shl    $0x10,%rdx
    cc8f:	48 39 d0             	cmp    %rdx,%rax
    cc92:	73 59                	jae    cced <f0+0x1a8d>
    cc94:	48 89 c2             	mov    %rax,%rdx
    cc97:	48 c1 ea 10          	shr    $0x10,%rdx
    cc9b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc9f:	48 8b 15 72 ff 05 00 	mov    0x5ff72(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cca6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccaa:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccae:	4d 85 e4             	test   %r12,%r12
    ccb1:	74 3a                	je     cced <f0+0x1a8d>
    ccb3:	0f b6 0a             	movzbl (%rdx),%ecx
    ccb6:	80 f9 02             	cmp    $0x2,%cl
    ccb9:	0f 84 91 0e 00 00    	je     db50 <f0+0x28f0>
    ccbf:	80 f9 01             	cmp    $0x1,%cl
    ccc2:	75 29                	jne    cced <f0+0x1a8d>
    ccc4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccc7:	0f b7 c0             	movzwl %ax,%eax
    ccca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cccd:	48 0f af c1          	imul   %rcx,%rax
    ccd1:	48 c1 e8 20          	shr    $0x20,%rax
    ccd5:	48 39 d0             	cmp    %rdx,%rax
    ccd8:	73 13                	jae    cced <f0+0x1a8d>
    ccda:	49 01 c4             	add    %rax,%r12
    ccdd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cce2:	0f 84 53 11 00 00    	je     de3b <f0+0x2bdb>
    cce8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cced:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ccf4:	00 f0 3f 
    ccf7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    ccfe:	00 
    ccff:	bf 01 00 00 00       	mov    $0x1,%edi
    cd04:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cd0b:	00 
    cd0c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cd13:	00 
    cd14:	e8 e7 93 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cd19:	48 8b 15 d8 fe 05 00 	mov    0x5fed8(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cd20:	49 89 c5             	mov    %rax,%r13
    cd23:	48 2b 05 a6 fe 05 00 	sub    0x5fea6(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cd2a:	48 c1 e2 10          	shl    $0x10,%rdx
    cd2e:	48 39 d0             	cmp    %rdx,%rax
    cd31:	73 59                	jae    cd8c <f0+0x1b2c>
    cd33:	48 89 c2             	mov    %rax,%rdx
    cd36:	48 c1 ea 10          	shr    $0x10,%rdx
    cd3a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd3e:	48 8b 15 d3 fe 05 00 	mov    0x5fed3(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cd45:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd49:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd4d:	4d 85 e4             	test   %r12,%r12
    cd50:	74 3a                	je     cd8c <f0+0x1b2c>
    cd52:	0f b6 0a             	movzbl (%rdx),%ecx
    cd55:	80 f9 02             	cmp    $0x2,%cl
    cd58:	0f 84 e2 0d 00 00    	je     db40 <f0+0x28e0>
    cd5e:	80 f9 01             	cmp    $0x1,%cl
    cd61:	75 29                	jne    cd8c <f0+0x1b2c>
    cd63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd66:	0f b7 c0             	movzwl %ax,%eax
    cd69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd6c:	48 0f af c1          	imul   %rcx,%rax
    cd70:	48 c1 e8 20          	shr    $0x20,%rax
    cd74:	48 39 d0             	cmp    %rdx,%rax
    cd77:	73 13                	jae    cd8c <f0+0x1b2c>
    cd79:	49 01 c4             	add    %rax,%r12
    cd7c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd81:	0f 84 c1 10 00 00    	je     de48 <f0+0x2be8>
    cd87:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd8c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd93:	33 f3 bf 
    cd96:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cd9d:	00 
    cd9e:	bf 01 00 00 00       	mov    $0x1,%edi
    cda3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    cdaa:	00 
    cdab:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cdb2:	00 
    cdb3:	e8 48 93 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cdb8:	48 8b 15 39 fe 05 00 	mov    0x5fe39(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cdbf:	49 89 c5             	mov    %rax,%r13
    cdc2:	48 2b 05 07 fe 05 00 	sub    0x5fe07(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cdc9:	48 c1 e2 10          	shl    $0x10,%rdx
    cdcd:	48 39 d0             	cmp    %rdx,%rax
    cdd0:	73 59                	jae    ce2b <f0+0x1bcb>
    cdd2:	48 89 c2             	mov    %rax,%rdx
    cdd5:	48 c1 ea 10          	shr    $0x10,%rdx
    cdd9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cddd:	48 8b 15 34 fe 05 00 	mov    0x5fe34(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cde4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cde8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdec:	4d 85 e4             	test   %r12,%r12
    cdef:	74 3a                	je     ce2b <f0+0x1bcb>
    cdf1:	0f b6 0a             	movzbl (%rdx),%ecx
    cdf4:	80 f9 02             	cmp    $0x2,%cl
    cdf7:	0f 84 33 0d 00 00    	je     db30 <f0+0x28d0>
    cdfd:	80 f9 01             	cmp    $0x1,%cl
    ce00:	75 29                	jne    ce2b <f0+0x1bcb>
    ce02:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce05:	0f b7 c0             	movzwl %ax,%eax
    ce08:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce0b:	48 0f af c1          	imul   %rcx,%rax
    ce0f:	48 c1 e8 20          	shr    $0x20,%rax
    ce13:	48 39 d0             	cmp    %rdx,%rax
    ce16:	73 13                	jae    ce2b <f0+0x1bcb>
    ce18:	49 01 c4             	add    %rax,%r12
    ce1b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce20:	0f 84 2f 10 00 00    	je     de55 <f0+0x2bf5>
    ce26:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce2b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce32:	00 f0 3f 
    ce35:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    ce3c:	00 
    ce3d:	bf 01 00 00 00       	mov    $0x1,%edi
    ce42:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    ce49:	00 
    ce4a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    ce51:	00 
    ce52:	e8 a9 92 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ce57:	48 8b 15 9a fd 05 00 	mov    0x5fd9a(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    ce5e:	49 89 c5             	mov    %rax,%r13
    ce61:	48 2b 05 68 fd 05 00 	sub    0x5fd68(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    ce68:	48 c1 e2 10          	shl    $0x10,%rdx
    ce6c:	48 39 d0             	cmp    %rdx,%rax
    ce6f:	73 59                	jae    ceca <f0+0x1c6a>
    ce71:	48 89 c2             	mov    %rax,%rdx
    ce74:	48 c1 ea 10          	shr    $0x10,%rdx
    ce78:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce7c:	48 8b 15 95 fd 05 00 	mov    0x5fd95(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ce83:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce87:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce8b:	4d 85 e4             	test   %r12,%r12
    ce8e:	74 3a                	je     ceca <f0+0x1c6a>
    ce90:	0f b6 0a             	movzbl (%rdx),%ecx
    ce93:	80 f9 02             	cmp    $0x2,%cl
    ce96:	0f 84 84 0c 00 00    	je     db20 <f0+0x28c0>
    ce9c:	80 f9 01             	cmp    $0x1,%cl
    ce9f:	75 29                	jne    ceca <f0+0x1c6a>
    cea1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cea4:	0f b7 c0             	movzwl %ax,%eax
    cea7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ceaa:	48 0f af c1          	imul   %rcx,%rax
    ceae:	48 c1 e8 20          	shr    $0x20,%rax
    ceb2:	48 39 d0             	cmp    %rdx,%rax
    ceb5:	73 13                	jae    ceca <f0+0x1c6a>
    ceb7:	49 01 c4             	add    %rax,%r12
    ceba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cebf:	0f 84 9d 0f 00 00    	je     de62 <f0+0x2c02>
    cec5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ceca:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ced1:	33 f3 bf 
    ced4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    cedb:	00 
    cedc:	bf 01 00 00 00       	mov    $0x1,%edi
    cee1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    cee8:	00 
    cee9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    cef0:	00 
    cef1:	e8 0a 92 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cef6:	48 8b 15 fb fc 05 00 	mov    0x5fcfb(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cefd:	49 89 c5             	mov    %rax,%r13
    cf00:	48 2b 05 c9 fc 05 00 	sub    0x5fcc9(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cf07:	48 c1 e2 10          	shl    $0x10,%rdx
    cf0b:	48 39 d0             	cmp    %rdx,%rax
    cf0e:	73 59                	jae    cf69 <f0+0x1d09>
    cf10:	48 89 c2             	mov    %rax,%rdx
    cf13:	48 c1 ea 10          	shr    $0x10,%rdx
    cf17:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf1b:	48 8b 15 f6 fc 05 00 	mov    0x5fcf6(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cf22:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf26:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf2a:	4d 85 e4             	test   %r12,%r12
    cf2d:	74 3a                	je     cf69 <f0+0x1d09>
    cf2f:	0f b6 0a             	movzbl (%rdx),%ecx
    cf32:	80 f9 02             	cmp    $0x2,%cl
    cf35:	0f 84 d5 0b 00 00    	je     db10 <f0+0x28b0>
    cf3b:	80 f9 01             	cmp    $0x1,%cl
    cf3e:	75 29                	jne    cf69 <f0+0x1d09>
    cf40:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf43:	0f b7 c0             	movzwl %ax,%eax
    cf46:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf49:	48 0f af c1          	imul   %rcx,%rax
    cf4d:	48 c1 e8 20          	shr    $0x20,%rax
    cf51:	48 39 d0             	cmp    %rdx,%rax
    cf54:	73 13                	jae    cf69 <f0+0x1d09>
    cf56:	49 01 c4             	add    %rax,%r12
    cf59:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf5e:	0f 84 0b 0f 00 00    	je     de6f <f0+0x2c0f>
    cf64:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf69:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf70:	00 f0 3f 
    cf73:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    cf7a:	00 
    cf7b:	bf 01 00 00 00       	mov    $0x1,%edi
    cf80:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    cf87:	00 
    cf88:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    cf8f:	00 
    cf90:	e8 6b 91 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cf95:	48 8b 15 5c fc 05 00 	mov    0x5fc5c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cf9c:	49 89 c5             	mov    %rax,%r13
    cf9f:	48 2b 05 2a fc 05 00 	sub    0x5fc2a(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cfa6:	48 c1 e2 10          	shl    $0x10,%rdx
    cfaa:	48 39 d0             	cmp    %rdx,%rax
    cfad:	73 59                	jae    d008 <f0+0x1da8>
    cfaf:	48 89 c2             	mov    %rax,%rdx
    cfb2:	48 c1 ea 10          	shr    $0x10,%rdx
    cfb6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfba:	48 8b 15 57 fc 05 00 	mov    0x5fc57(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cfc1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfc5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfc9:	4d 85 e4             	test   %r12,%r12
    cfcc:	74 3a                	je     d008 <f0+0x1da8>
    cfce:	0f b6 0a             	movzbl (%rdx),%ecx
    cfd1:	80 f9 02             	cmp    $0x2,%cl
    cfd4:	0f 84 26 0b 00 00    	je     db00 <f0+0x28a0>
    cfda:	80 f9 01             	cmp    $0x1,%cl
    cfdd:	75 29                	jne    d008 <f0+0x1da8>
    cfdf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfe2:	0f b7 c0             	movzwl %ax,%eax
    cfe5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfe8:	48 0f af c1          	imul   %rcx,%rax
    cfec:	48 c1 e8 20          	shr    $0x20,%rax
    cff0:	48 39 d0             	cmp    %rdx,%rax
    cff3:	73 13                	jae    d008 <f0+0x1da8>
    cff5:	49 01 c4             	add    %rax,%r12
    cff8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cffd:	0f 84 79 0e 00 00    	je     de7c <f0+0x2c1c>
    d003:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d008:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d00f:	33 f3 bf 
    d012:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d019:	00 
    d01a:	bf 01 00 00 00       	mov    $0x1,%edi
    d01f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d026:	00 
    d027:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d02e:	00 
    d02f:	e8 cc 90 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d034:	48 8b 15 bd fb 05 00 	mov    0x5fbbd(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d03b:	49 89 c5             	mov    %rax,%r13
    d03e:	48 2b 05 8b fb 05 00 	sub    0x5fb8b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d045:	48 c1 e2 10          	shl    $0x10,%rdx
    d049:	48 39 d0             	cmp    %rdx,%rax
    d04c:	73 59                	jae    d0a7 <f0+0x1e47>
    d04e:	48 89 c2             	mov    %rax,%rdx
    d051:	48 c1 ea 10          	shr    $0x10,%rdx
    d055:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d059:	48 8b 15 b8 fb 05 00 	mov    0x5fbb8(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d060:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d064:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d068:	4d 85 e4             	test   %r12,%r12
    d06b:	74 3a                	je     d0a7 <f0+0x1e47>
    d06d:	0f b6 0a             	movzbl (%rdx),%ecx
    d070:	80 f9 02             	cmp    $0x2,%cl
    d073:	0f 84 77 0a 00 00    	je     daf0 <f0+0x2890>
    d079:	80 f9 01             	cmp    $0x1,%cl
    d07c:	75 29                	jne    d0a7 <f0+0x1e47>
    d07e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d081:	0f b7 c0             	movzwl %ax,%eax
    d084:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d087:	48 0f af c1          	imul   %rcx,%rax
    d08b:	48 c1 e8 20          	shr    $0x20,%rax
    d08f:	48 39 d0             	cmp    %rdx,%rax
    d092:	73 13                	jae    d0a7 <f0+0x1e47>
    d094:	49 01 c4             	add    %rax,%r12
    d097:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d09c:	0f 84 e7 0d 00 00    	je     de89 <f0+0x2c29>
    d0a2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0a7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d0ae:	00 f0 3f 
    d0b1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d0b8:	00 
    d0b9:	bf 01 00 00 00       	mov    $0x1,%edi
    d0be:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d0c5:	00 
    d0c6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d0cd:	00 
    d0ce:	e8 2d 90 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d0d3:	48 8b 15 1e fb 05 00 	mov    0x5fb1e(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d0da:	49 89 c5             	mov    %rax,%r13
    d0dd:	48 2b 05 ec fa 05 00 	sub    0x5faec(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d0e4:	48 c1 e2 10          	shl    $0x10,%rdx
    d0e8:	48 39 d0             	cmp    %rdx,%rax
    d0eb:	73 59                	jae    d146 <f0+0x1ee6>
    d0ed:	48 89 c2             	mov    %rax,%rdx
    d0f0:	48 c1 ea 10          	shr    $0x10,%rdx
    d0f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0f8:	48 8b 15 19 fb 05 00 	mov    0x5fb19(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d0ff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d103:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d107:	4d 85 e4             	test   %r12,%r12
    d10a:	74 3a                	je     d146 <f0+0x1ee6>
    d10c:	0f b6 0a             	movzbl (%rdx),%ecx
    d10f:	80 f9 02             	cmp    $0x2,%cl
    d112:	0f 84 38 0c 00 00    	je     dd50 <f0+0x2af0>
    d118:	80 f9 01             	cmp    $0x1,%cl
    d11b:	75 29                	jne    d146 <f0+0x1ee6>
    d11d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d120:	0f b7 c0             	movzwl %ax,%eax
    d123:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d126:	48 0f af c1          	imul   %rcx,%rax
    d12a:	48 c1 e8 20          	shr    $0x20,%rax
    d12e:	48 39 d0             	cmp    %rdx,%rax
    d131:	73 13                	jae    d146 <f0+0x1ee6>
    d133:	49 01 c4             	add    %rax,%r12
    d136:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d13b:	0f 84 55 0d 00 00    	je     de96 <f0+0x2c36>
    d141:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d146:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d14d:	33 f3 bf 
    d150:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d157:	00 
    d158:	bf 01 00 00 00       	mov    $0x1,%edi
    d15d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d164:	00 
    d165:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d16c:	00 
    d16d:	e8 8e 8f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d172:	48 8b 15 7f fa 05 00 	mov    0x5fa7f(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d179:	49 89 c5             	mov    %rax,%r13
    d17c:	48 2b 05 4d fa 05 00 	sub    0x5fa4d(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d183:	48 c1 e2 10          	shl    $0x10,%rdx
    d187:	48 39 d0             	cmp    %rdx,%rax
    d18a:	73 59                	jae    d1e5 <f0+0x1f85>
    d18c:	48 89 c2             	mov    %rax,%rdx
    d18f:	48 c1 ea 10          	shr    $0x10,%rdx
    d193:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d197:	48 8b 15 7a fa 05 00 	mov    0x5fa7a(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d19e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1a2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1a6:	4d 85 e4             	test   %r12,%r12
    d1a9:	74 3a                	je     d1e5 <f0+0x1f85>
    d1ab:	0f b6 0a             	movzbl (%rdx),%ecx
    d1ae:	80 f9 02             	cmp    $0x2,%cl
    d1b1:	0f 84 89 0b 00 00    	je     dd40 <f0+0x2ae0>
    d1b7:	80 f9 01             	cmp    $0x1,%cl
    d1ba:	75 29                	jne    d1e5 <f0+0x1f85>
    d1bc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1bf:	0f b7 c0             	movzwl %ax,%eax
    d1c2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1c5:	48 0f af c1          	imul   %rcx,%rax
    d1c9:	48 c1 e8 20          	shr    $0x20,%rax
    d1cd:	48 39 d0             	cmp    %rdx,%rax
    d1d0:	73 13                	jae    d1e5 <f0+0x1f85>
    d1d2:	49 01 c4             	add    %rax,%r12
    d1d5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1da:	0f 84 c3 0c 00 00    	je     dea3 <f0+0x2c43>
    d1e0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1e5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d1ec:	00 f0 3f 
    d1ef:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d1f6:	00 
    d1f7:	bf 01 00 00 00       	mov    $0x1,%edi
    d1fc:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d203:	00 
    d204:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d20b:	00 
    d20c:	e8 ef 8e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d211:	48 8b 15 e0 f9 05 00 	mov    0x5f9e0(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d218:	49 89 c5             	mov    %rax,%r13
    d21b:	48 2b 05 ae f9 05 00 	sub    0x5f9ae(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d222:	48 c1 e2 10          	shl    $0x10,%rdx
    d226:	48 39 d0             	cmp    %rdx,%rax
    d229:	73 59                	jae    d284 <f0+0x2024>
    d22b:	48 89 c2             	mov    %rax,%rdx
    d22e:	48 c1 ea 10          	shr    $0x10,%rdx
    d232:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d236:	48 8b 15 db f9 05 00 	mov    0x5f9db(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d23d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d241:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d245:	4d 85 e4             	test   %r12,%r12
    d248:	74 3a                	je     d284 <f0+0x2024>
    d24a:	0f b6 0a             	movzbl (%rdx),%ecx
    d24d:	80 f9 02             	cmp    $0x2,%cl
    d250:	0f 84 da 0a 00 00    	je     dd30 <f0+0x2ad0>
    d256:	80 f9 01             	cmp    $0x1,%cl
    d259:	75 29                	jne    d284 <f0+0x2024>
    d25b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d25e:	0f b7 c0             	movzwl %ax,%eax
    d261:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d264:	48 0f af c1          	imul   %rcx,%rax
    d268:	48 c1 e8 20          	shr    $0x20,%rax
    d26c:	48 39 d0             	cmp    %rdx,%rax
    d26f:	73 13                	jae    d284 <f0+0x2024>
    d271:	49 01 c4             	add    %rax,%r12
    d274:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d279:	0f 84 31 0c 00 00    	je     deb0 <f0+0x2c50>
    d27f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d284:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d28b:	33 f3 bf 
    d28e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d295:	00 
    d296:	bf 01 00 00 00       	mov    $0x1,%edi
    d29b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d2a2:	00 
    d2a3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d2aa:	00 
    d2ab:	e8 50 8e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d2b0:	48 8b 15 41 f9 05 00 	mov    0x5f941(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d2b7:	49 89 c5             	mov    %rax,%r13
    d2ba:	48 2b 05 0f f9 05 00 	sub    0x5f90f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d2c1:	48 c1 e2 10          	shl    $0x10,%rdx
    d2c5:	48 39 d0             	cmp    %rdx,%rax
    d2c8:	73 59                	jae    d323 <f0+0x20c3>
    d2ca:	48 89 c2             	mov    %rax,%rdx
    d2cd:	48 c1 ea 10          	shr    $0x10,%rdx
    d2d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2d5:	48 8b 15 3c f9 05 00 	mov    0x5f93c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d2dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2e0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2e4:	4d 85 e4             	test   %r12,%r12
    d2e7:	74 3a                	je     d323 <f0+0x20c3>
    d2e9:	0f b6 0a             	movzbl (%rdx),%ecx
    d2ec:	80 f9 02             	cmp    $0x2,%cl
    d2ef:	0f 84 2b 0a 00 00    	je     dd20 <f0+0x2ac0>
    d2f5:	80 f9 01             	cmp    $0x1,%cl
    d2f8:	75 29                	jne    d323 <f0+0x20c3>
    d2fa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2fd:	0f b7 c0             	movzwl %ax,%eax
    d300:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d303:	48 0f af c1          	imul   %rcx,%rax
    d307:	48 c1 e8 20          	shr    $0x20,%rax
    d30b:	48 39 d0             	cmp    %rdx,%rax
    d30e:	73 13                	jae    d323 <f0+0x20c3>
    d310:	49 01 c4             	add    %rax,%r12
    d313:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d318:	0f 84 9f 0b 00 00    	je     debd <f0+0x2c5d>
    d31e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d323:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d32a:	00 f0 3f 
    d32d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d334:	00 
    d335:	bf 01 00 00 00       	mov    $0x1,%edi
    d33a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d341:	00 
    d342:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d349:	00 
    d34a:	e8 b1 8d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d34f:	48 8b 15 a2 f8 05 00 	mov    0x5f8a2(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d356:	49 89 c5             	mov    %rax,%r13
    d359:	48 2b 05 70 f8 05 00 	sub    0x5f870(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d360:	48 c1 e2 10          	shl    $0x10,%rdx
    d364:	48 39 d0             	cmp    %rdx,%rax
    d367:	73 59                	jae    d3c2 <f0+0x2162>
    d369:	48 89 c2             	mov    %rax,%rdx
    d36c:	48 c1 ea 10          	shr    $0x10,%rdx
    d370:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d374:	48 8b 15 9d f8 05 00 	mov    0x5f89d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d37b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d37f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d383:	4d 85 e4             	test   %r12,%r12
    d386:	74 3a                	je     d3c2 <f0+0x2162>
    d388:	0f b6 0a             	movzbl (%rdx),%ecx
    d38b:	80 f9 02             	cmp    $0x2,%cl
    d38e:	0f 84 7c 09 00 00    	je     dd10 <f0+0x2ab0>
    d394:	80 f9 01             	cmp    $0x1,%cl
    d397:	75 29                	jne    d3c2 <f0+0x2162>
    d399:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d39c:	0f b7 c0             	movzwl %ax,%eax
    d39f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3a2:	48 0f af c1          	imul   %rcx,%rax
    d3a6:	48 c1 e8 20          	shr    $0x20,%rax
    d3aa:	48 39 d0             	cmp    %rdx,%rax
    d3ad:	73 13                	jae    d3c2 <f0+0x2162>
    d3af:	49 01 c4             	add    %rax,%r12
    d3b2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3b7:	0f 84 0d 0b 00 00    	je     deca <f0+0x2c6a>
    d3bd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3c2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d3c9:	33 f3 bf 
    d3cc:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d3d3:	00 
    d3d4:	bf 01 00 00 00       	mov    $0x1,%edi
    d3d9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d3e0:	00 
    d3e1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d3e8:	00 
    d3e9:	e8 12 8d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d3ee:	48 8b 15 03 f8 05 00 	mov    0x5f803(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d3f5:	49 89 c5             	mov    %rax,%r13
    d3f8:	48 2b 05 d1 f7 05 00 	sub    0x5f7d1(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d3ff:	48 c1 e2 10          	shl    $0x10,%rdx
    d403:	48 39 d0             	cmp    %rdx,%rax
    d406:	73 59                	jae    d461 <f0+0x2201>
    d408:	48 89 c2             	mov    %rax,%rdx
    d40b:	48 c1 ea 10          	shr    $0x10,%rdx
    d40f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d413:	48 8b 15 fe f7 05 00 	mov    0x5f7fe(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d41a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d41e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d422:	4d 85 e4             	test   %r12,%r12
    d425:	74 3a                	je     d461 <f0+0x2201>
    d427:	0f b6 0a             	movzbl (%rdx),%ecx
    d42a:	80 f9 02             	cmp    $0x2,%cl
    d42d:	0f 84 cd 08 00 00    	je     dd00 <f0+0x2aa0>
    d433:	80 f9 01             	cmp    $0x1,%cl
    d436:	75 29                	jne    d461 <f0+0x2201>
    d438:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d43b:	0f b7 c0             	movzwl %ax,%eax
    d43e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d441:	48 0f af c1          	imul   %rcx,%rax
    d445:	48 c1 e8 20          	shr    $0x20,%rax
    d449:	48 39 d0             	cmp    %rdx,%rax
    d44c:	73 13                	jae    d461 <f0+0x2201>
    d44e:	49 01 c4             	add    %rax,%r12
    d451:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d456:	0f 84 7b 0a 00 00    	je     ded7 <f0+0x2c77>
    d45c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d461:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d468:	00 f0 3f 
    d46b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d472:	00 
    d473:	bf 01 00 00 00       	mov    $0x1,%edi
    d478:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d47f:	00 
    d480:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d487:	00 
    d488:	e8 73 8c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d48d:	48 8b 15 64 f7 05 00 	mov    0x5f764(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d494:	49 89 c5             	mov    %rax,%r13
    d497:	48 2b 05 32 f7 05 00 	sub    0x5f732(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d49e:	48 c1 e2 10          	shl    $0x10,%rdx
    d4a2:	48 39 d0             	cmp    %rdx,%rax
    d4a5:	73 59                	jae    d500 <f0+0x22a0>
    d4a7:	48 89 c2             	mov    %rax,%rdx
    d4aa:	48 c1 ea 10          	shr    $0x10,%rdx
    d4ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4b2:	48 8b 15 5f f7 05 00 	mov    0x5f75f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d4b9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4bd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4c1:	4d 85 e4             	test   %r12,%r12
    d4c4:	74 3a                	je     d500 <f0+0x22a0>
    d4c6:	0f b6 0a             	movzbl (%rdx),%ecx
    d4c9:	80 f9 02             	cmp    $0x2,%cl
    d4cc:	0f 84 1e 08 00 00    	je     dcf0 <f0+0x2a90>
    d4d2:	80 f9 01             	cmp    $0x1,%cl
    d4d5:	75 29                	jne    d500 <f0+0x22a0>
    d4d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4da:	0f b7 c0             	movzwl %ax,%eax
    d4dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4e0:	48 0f af c1          	imul   %rcx,%rax
    d4e4:	48 c1 e8 20          	shr    $0x20,%rax
    d4e8:	48 39 d0             	cmp    %rdx,%rax
    d4eb:	73 13                	jae    d500 <f0+0x22a0>
    d4ed:	49 01 c4             	add    %rax,%r12
    d4f0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4f5:	0f 84 e9 09 00 00    	je     dee4 <f0+0x2c84>
    d4fb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d500:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d507:	33 f3 bf 
    d50a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d511:	00 
    d512:	bf 01 00 00 00       	mov    $0x1,%edi
    d517:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d51e:	00 
    d51f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d526:	00 
    d527:	e8 d4 8b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d52c:	48 8b 15 c5 f6 05 00 	mov    0x5f6c5(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d533:	49 89 c5             	mov    %rax,%r13
    d536:	48 2b 05 93 f6 05 00 	sub    0x5f693(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d53d:	48 c1 e2 10          	shl    $0x10,%rdx
    d541:	48 39 d0             	cmp    %rdx,%rax
    d544:	73 59                	jae    d59f <f0+0x233f>
    d546:	48 89 c2             	mov    %rax,%rdx
    d549:	48 c1 ea 10          	shr    $0x10,%rdx
    d54d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d551:	48 8b 15 c0 f6 05 00 	mov    0x5f6c0(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d558:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d55c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d560:	4d 85 e4             	test   %r12,%r12
    d563:	74 3a                	je     d59f <f0+0x233f>
    d565:	0f b6 0a             	movzbl (%rdx),%ecx
    d568:	80 f9 02             	cmp    $0x2,%cl
    d56b:	0f 84 6f 07 00 00    	je     dce0 <f0+0x2a80>
    d571:	80 f9 01             	cmp    $0x1,%cl
    d574:	75 29                	jne    d59f <f0+0x233f>
    d576:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d579:	0f b7 c0             	movzwl %ax,%eax
    d57c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d57f:	48 0f af c1          	imul   %rcx,%rax
    d583:	48 c1 e8 20          	shr    $0x20,%rax
    d587:	48 39 d0             	cmp    %rdx,%rax
    d58a:	73 13                	jae    d59f <f0+0x233f>
    d58c:	49 01 c4             	add    %rax,%r12
    d58f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d594:	0f 84 57 09 00 00    	je     def1 <f0+0x2c91>
    d59a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d59f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d5a6:	00 f0 3f 
    d5a9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d5b0:	00 
    d5b1:	bf 01 00 00 00       	mov    $0x1,%edi
    d5b6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d5bd:	00 
    d5be:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d5c5:	00 
    d5c6:	e8 35 8b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d5cb:	48 8b 15 26 f6 05 00 	mov    0x5f626(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d5d2:	49 89 c5             	mov    %rax,%r13
    d5d5:	48 2b 05 f4 f5 05 00 	sub    0x5f5f4(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d5dc:	48 c1 e2 10          	shl    $0x10,%rdx
    d5e0:	48 39 d0             	cmp    %rdx,%rax
    d5e3:	73 59                	jae    d63e <f0+0x23de>
    d5e5:	48 89 c2             	mov    %rax,%rdx
    d5e8:	48 c1 ea 10          	shr    $0x10,%rdx
    d5ec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5f0:	48 8b 15 21 f6 05 00 	mov    0x5f621(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d5f7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5fb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5ff:	4d 85 e4             	test   %r12,%r12
    d602:	74 3a                	je     d63e <f0+0x23de>
    d604:	0f b6 0a             	movzbl (%rdx),%ecx
    d607:	80 f9 02             	cmp    $0x2,%cl
    d60a:	0f 84 c0 06 00 00    	je     dcd0 <f0+0x2a70>
    d610:	80 f9 01             	cmp    $0x1,%cl
    d613:	75 29                	jne    d63e <f0+0x23de>
    d615:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d618:	0f b7 c0             	movzwl %ax,%eax
    d61b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d61e:	48 0f af c1          	imul   %rcx,%rax
    d622:	48 c1 e8 20          	shr    $0x20,%rax
    d626:	48 39 d0             	cmp    %rdx,%rax
    d629:	73 13                	jae    d63e <f0+0x23de>
    d62b:	49 01 c4             	add    %rax,%r12
    d62e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d633:	0f 84 c5 08 00 00    	je     defe <f0+0x2c9e>
    d639:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d63e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d645:	33 f3 bf 
    d648:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d64f:	00 
    d650:	bf 01 00 00 00       	mov    $0x1,%edi
    d655:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d65c:	00 
    d65d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d664:	00 
    d665:	e8 96 8a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d66a:	48 8b 15 87 f5 05 00 	mov    0x5f587(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d671:	49 89 c5             	mov    %rax,%r13
    d674:	48 2b 05 55 f5 05 00 	sub    0x5f555(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d67b:	48 c1 e2 10          	shl    $0x10,%rdx
    d67f:	48 39 d0             	cmp    %rdx,%rax
    d682:	73 59                	jae    d6dd <f0+0x247d>
    d684:	48 89 c2             	mov    %rax,%rdx
    d687:	48 c1 ea 10          	shr    $0x10,%rdx
    d68b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d68f:	48 8b 15 82 f5 05 00 	mov    0x5f582(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d696:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d69a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d69e:	4d 85 e4             	test   %r12,%r12
    d6a1:	74 3a                	je     d6dd <f0+0x247d>
    d6a3:	0f b6 0a             	movzbl (%rdx),%ecx
    d6a6:	80 f9 02             	cmp    $0x2,%cl
    d6a9:	0f 84 11 06 00 00    	je     dcc0 <f0+0x2a60>
    d6af:	80 f9 01             	cmp    $0x1,%cl
    d6b2:	75 29                	jne    d6dd <f0+0x247d>
    d6b4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6b7:	0f b7 c0             	movzwl %ax,%eax
    d6ba:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6bd:	48 0f af c1          	imul   %rcx,%rax
    d6c1:	48 c1 e8 20          	shr    $0x20,%rax
    d6c5:	48 39 d0             	cmp    %rdx,%rax
    d6c8:	73 13                	jae    d6dd <f0+0x247d>
    d6ca:	49 01 c4             	add    %rax,%r12
    d6cd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6d2:	0f 84 33 08 00 00    	je     df0b <f0+0x2cab>
    d6d8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6dd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d6e4:	00 f0 3f 
    d6e7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d6ee:	00 
    d6ef:	bf 01 00 00 00       	mov    $0x1,%edi
    d6f4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d6fb:	00 
    d6fc:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d703:	00 
    d704:	e8 f7 89 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d709:	48 8b 15 e8 f4 05 00 	mov    0x5f4e8(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d710:	49 89 c5             	mov    %rax,%r13
    d713:	48 2b 05 b6 f4 05 00 	sub    0x5f4b6(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d71a:	48 c1 e2 10          	shl    $0x10,%rdx
    d71e:	48 39 d0             	cmp    %rdx,%rax
    d721:	73 59                	jae    d77c <f0+0x251c>
    d723:	48 89 c2             	mov    %rax,%rdx
    d726:	48 c1 ea 10          	shr    $0x10,%rdx
    d72a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d72e:	48 8b 15 e3 f4 05 00 	mov    0x5f4e3(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d735:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d739:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d73d:	4d 85 e4             	test   %r12,%r12
    d740:	74 3a                	je     d77c <f0+0x251c>
    d742:	0f b6 0a             	movzbl (%rdx),%ecx
    d745:	80 f9 02             	cmp    $0x2,%cl
    d748:	0f 84 62 05 00 00    	je     dcb0 <f0+0x2a50>
    d74e:	80 f9 01             	cmp    $0x1,%cl
    d751:	75 29                	jne    d77c <f0+0x251c>
    d753:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d756:	0f b7 c0             	movzwl %ax,%eax
    d759:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d75c:	48 0f af c1          	imul   %rcx,%rax
    d760:	48 c1 e8 20          	shr    $0x20,%rax
    d764:	48 39 d0             	cmp    %rdx,%rax
    d767:	73 13                	jae    d77c <f0+0x251c>
    d769:	49 01 c4             	add    %rax,%r12
    d76c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d771:	0f 84 a1 07 00 00    	je     df18 <f0+0x2cb8>
    d777:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d77c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d783:	33 f3 bf 
    d786:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d78d:	00 
    d78e:	bf 01 00 00 00       	mov    $0x1,%edi
    d793:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d79a:	00 
    d79b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d7a2:	00 
    d7a3:	e8 58 89 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d7a8:	48 8b 15 49 f4 05 00 	mov    0x5f449(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d7af:	49 89 c5             	mov    %rax,%r13
    d7b2:	48 2b 05 17 f4 05 00 	sub    0x5f417(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d7b9:	48 c1 e2 10          	shl    $0x10,%rdx
    d7bd:	48 39 d0             	cmp    %rdx,%rax
    d7c0:	73 59                	jae    d81b <f0+0x25bb>
    d7c2:	48 89 c2             	mov    %rax,%rdx
    d7c5:	48 c1 ea 10          	shr    $0x10,%rdx
    d7c9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7cd:	48 8b 15 44 f4 05 00 	mov    0x5f444(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d7d4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7d8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7dc:	4d 85 e4             	test   %r12,%r12
    d7df:	74 3a                	je     d81b <f0+0x25bb>
    d7e1:	0f b6 0a             	movzbl (%rdx),%ecx
    d7e4:	80 f9 02             	cmp    $0x2,%cl
    d7e7:	0f 84 b3 04 00 00    	je     dca0 <f0+0x2a40>
    d7ed:	80 f9 01             	cmp    $0x1,%cl
    d7f0:	75 29                	jne    d81b <f0+0x25bb>
    d7f2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7f5:	0f b7 c0             	movzwl %ax,%eax
    d7f8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7fb:	48 0f af c1          	imul   %rcx,%rax
    d7ff:	48 c1 e8 20          	shr    $0x20,%rax
    d803:	48 39 d0             	cmp    %rdx,%rax
    d806:	73 13                	jae    d81b <f0+0x25bb>
    d808:	49 01 c4             	add    %rax,%r12
    d80b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d810:	0f 84 0f 07 00 00    	je     df25 <f0+0x2cc5>
    d816:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d81b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d822:	00 f0 3f 
    d825:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d82c:	00 
    d82d:	bf 01 00 00 00       	mov    $0x1,%edi
    d832:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d839:	00 
    d83a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d841:	00 
    d842:	e8 b9 88 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d847:	48 8b 15 aa f3 05 00 	mov    0x5f3aa(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d84e:	49 89 c5             	mov    %rax,%r13
    d851:	48 2b 05 78 f3 05 00 	sub    0x5f378(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d858:	48 c1 e2 10          	shl    $0x10,%rdx
    d85c:	48 39 d0             	cmp    %rdx,%rax
    d85f:	73 59                	jae    d8ba <f0+0x265a>
    d861:	48 89 c2             	mov    %rax,%rdx
    d864:	48 c1 ea 10          	shr    $0x10,%rdx
    d868:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d86c:	48 8b 15 a5 f3 05 00 	mov    0x5f3a5(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d873:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d877:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d87b:	4d 85 e4             	test   %r12,%r12
    d87e:	74 3a                	je     d8ba <f0+0x265a>
    d880:	0f b6 0a             	movzbl (%rdx),%ecx
    d883:	80 f9 02             	cmp    $0x2,%cl
    d886:	0f 84 04 04 00 00    	je     dc90 <f0+0x2a30>
    d88c:	80 f9 01             	cmp    $0x1,%cl
    d88f:	75 29                	jne    d8ba <f0+0x265a>
    d891:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d894:	0f b7 c0             	movzwl %ax,%eax
    d897:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d89a:	48 0f af c1          	imul   %rcx,%rax
    d89e:	48 c1 e8 20          	shr    $0x20,%rax
    d8a2:	48 39 d0             	cmp    %rdx,%rax
    d8a5:	73 13                	jae    d8ba <f0+0x265a>
    d8a7:	49 01 c4             	add    %rax,%r12
    d8aa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8af:	0f 84 7d 06 00 00    	je     df32 <f0+0x2cd2>
    d8b5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8ba:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d8c1:	33 f3 bf 
    d8c4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d8cb:	00 
    d8cc:	bf 01 00 00 00       	mov    $0x1,%edi
    d8d1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d8d8:	00 
    d8d9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d8e0:	00 
    d8e1:	e8 1a 88 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d8e6:	48 8b 15 0b f3 05 00 	mov    0x5f30b(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d8ed:	49 89 c5             	mov    %rax,%r13
    d8f0:	48 2b 05 d9 f2 05 00 	sub    0x5f2d9(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d8f7:	48 c1 e2 10          	shl    $0x10,%rdx
    d8fb:	48 39 d0             	cmp    %rdx,%rax
    d8fe:	73 59                	jae    d959 <f0+0x26f9>
    d900:	48 89 c2             	mov    %rax,%rdx
    d903:	48 c1 ea 10          	shr    $0x10,%rdx
    d907:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d90b:	48 8b 15 06 f3 05 00 	mov    0x5f306(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d912:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d916:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d91a:	4d 85 e4             	test   %r12,%r12
    d91d:	74 3a                	je     d959 <f0+0x26f9>
    d91f:	0f b6 0a             	movzbl (%rdx),%ecx
    d922:	80 f9 02             	cmp    $0x2,%cl
    d925:	0f 84 55 03 00 00    	je     dc80 <f0+0x2a20>
    d92b:	80 f9 01             	cmp    $0x1,%cl
    d92e:	75 29                	jne    d959 <f0+0x26f9>
    d930:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d933:	0f b7 c0             	movzwl %ax,%eax
    d936:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d939:	48 0f af c1          	imul   %rcx,%rax
    d93d:	48 c1 e8 20          	shr    $0x20,%rax
    d941:	48 39 d0             	cmp    %rdx,%rax
    d944:	73 13                	jae    d959 <f0+0x26f9>
    d946:	49 01 c4             	add    %rax,%r12
    d949:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d94e:	0f 84 eb 05 00 00    	je     df3f <f0+0x2cdf>
    d954:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d959:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d960:	00 f0 3f 
    d963:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d96a:	00 
    d96b:	bf 01 00 00 00       	mov    $0x1,%edi
    d970:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d977:	00 
    d978:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d97f:	00 
    d980:	e8 7b 87 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d985:	48 8b 15 6c f2 05 00 	mov    0x5f26c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d98c:	49 89 c5             	mov    %rax,%r13
    d98f:	48 2b 05 3a f2 05 00 	sub    0x5f23a(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d996:	48 c1 e2 10          	shl    $0x10,%rdx
    d99a:	48 39 d0             	cmp    %rdx,%rax
    d99d:	73 59                	jae    d9f8 <f0+0x2798>
    d99f:	48 89 c2             	mov    %rax,%rdx
    d9a2:	48 c1 ea 10          	shr    $0x10,%rdx
    d9a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9aa:	48 8b 15 67 f2 05 00 	mov    0x5f267(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d9b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d9b5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9b9:	4d 85 e4             	test   %r12,%r12
    d9bc:	74 3a                	je     d9f8 <f0+0x2798>
    d9be:	0f b6 0a             	movzbl (%rdx),%ecx
    d9c1:	80 f9 02             	cmp    $0x2,%cl
    d9c4:	0f 84 a6 02 00 00    	je     dc70 <f0+0x2a10>
    d9ca:	80 f9 01             	cmp    $0x1,%cl
    d9cd:	75 29                	jne    d9f8 <f0+0x2798>
    d9cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d9d2:	0f b7 c0             	movzwl %ax,%eax
    d9d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d9d8:	48 0f af c1          	imul   %rcx,%rax
    d9dc:	48 c1 e8 20          	shr    $0x20,%rax
    d9e0:	48 39 d0             	cmp    %rdx,%rax
    d9e3:	73 13                	jae    d9f8 <f0+0x2798>
    d9e5:	49 01 c4             	add    %rax,%r12
    d9e8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9ed:	0f 84 59 05 00 00    	je     df4c <f0+0x2cec>
    d9f3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9f8:	48 89 ee             	mov    %rbp,%rsi
    d9fb:	bf 01 00 00 00       	mov    $0x1,%edi
    da00:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    da07:	33 f3 bf 
    da0a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    da11:	00 
    da12:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    da19:	00 
    da1a:	e8 e1 86 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    da1f:	48 8b 15 d2 f1 05 00 	mov    0x5f1d2(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    da26:	48 89 c5             	mov    %rax,%rbp
    da29:	48 2b 05 a0 f1 05 00 	sub    0x5f1a0(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    da30:	48 c1 e2 10          	shl    $0x10,%rdx
    da34:	48 39 d0             	cmp    %rdx,%rax
    da37:	73 59                	jae    da92 <f0+0x2832>
    da39:	48 89 c2             	mov    %rax,%rdx
    da3c:	48 c1 ea 10          	shr    $0x10,%rdx
    da40:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da44:	48 8b 15 cd f1 05 00 	mov    0x5f1cd(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    da4b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da4f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da53:	4d 85 e4             	test   %r12,%r12
    da56:	74 3a                	je     da92 <f0+0x2832>
    da58:	0f b6 0a             	movzbl (%rdx),%ecx
    da5b:	80 f9 02             	cmp    $0x2,%cl
    da5e:	0f 84 fc 01 00 00    	je     dc60 <f0+0x2a00>
    da64:	80 f9 01             	cmp    $0x1,%cl
    da67:	75 29                	jne    da92 <f0+0x2832>
    da69:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da6c:	0f b7 c0             	movzwl %ax,%eax
    da6f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da72:	48 0f af c1          	imul   %rcx,%rax
    da76:	48 c1 e8 20          	shr    $0x20,%rax
    da7a:	48 39 d0             	cmp    %rdx,%rax
    da7d:	73 13                	jae    da92 <f0+0x2832>
    da7f:	49 01 c4             	add    %rax,%r12
    da82:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da87:	0f 84 d1 02 00 00    	je     dd5e <f0+0x2afe>
    da8d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da92:	48 89 de             	mov    %rbx,%rsi
    da95:	48 89 ef             	mov    %rbp,%rdi
    da98:	e8 23 be ff ff       	call   98c0 <fwp_hof0.constprop.0>
    da9d:	48 89 ef             	mov    %rbp,%rdi
    daa0:	e8 bb a2 ff ff       	call   7d60 <fwp_drop0>
    daa5:	48 89 df             	mov    %rbx,%rdi
    daa8:	e8 b3 a2 ff ff       	call   7d60 <fwp_drop0>
    daad:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    dab4:	00 
    dab5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    dabc:	00 00 
    dabe:	0f 85 95 04 00 00    	jne    df59 <f0+0x2cf9>
    dac4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    dacb:	31 c0                	xor    %eax,%eax
    dacd:	5b                   	pop    %rbx
    dace:	5d                   	pop    %rbp
    dacf:	41 5c                	pop    %r12
    dad1:	41 5d                	pop    %r13
    dad3:	41 5e                	pop    %r14
    dad5:	c3                   	ret
    dad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dadd:	00 00 00 
    dae0:	4c 89 ef             	mov    %r13,%rdi
    dae3:	e8 e8 7c ff ff       	call   57d0 <fwp_rc_forget_slot>
    dae8:	e9 2c d8 ff ff       	jmp    b319 <f0+0xb9>
    daed:	0f 1f 00             	nopl   (%rax)
    daf0:	66 85 c0             	test   %ax,%ax
    daf3:	0f 85 ae f5 ff ff    	jne    d0a7 <f0+0x1e47>
    daf9:	e9 99 f5 ff ff       	jmp    d097 <f0+0x1e37>
    dafe:	66 90                	xchg   %ax,%ax
    db00:	66 85 c0             	test   %ax,%ax
    db03:	0f 85 ff f4 ff ff    	jne    d008 <f0+0x1da8>
    db09:	e9 ea f4 ff ff       	jmp    cff8 <f0+0x1d98>
    db0e:	66 90                	xchg   %ax,%ax
    db10:	66 85 c0             	test   %ax,%ax
    db13:	0f 85 50 f4 ff ff    	jne    cf69 <f0+0x1d09>
    db19:	e9 3b f4 ff ff       	jmp    cf59 <f0+0x1cf9>
    db1e:	66 90                	xchg   %ax,%ax
    db20:	66 85 c0             	test   %ax,%ax
    db23:	0f 85 a1 f3 ff ff    	jne    ceca <f0+0x1c6a>
    db29:	e9 8c f3 ff ff       	jmp    ceba <f0+0x1c5a>
    db2e:	66 90                	xchg   %ax,%ax
    db30:	66 85 c0             	test   %ax,%ax
    db33:	0f 85 f2 f2 ff ff    	jne    ce2b <f0+0x1bcb>
    db39:	e9 dd f2 ff ff       	jmp    ce1b <f0+0x1bbb>
    db3e:	66 90                	xchg   %ax,%ax
    db40:	66 85 c0             	test   %ax,%ax
    db43:	0f 85 43 f2 ff ff    	jne    cd8c <f0+0x1b2c>
    db49:	e9 2e f2 ff ff       	jmp    cd7c <f0+0x1b1c>
    db4e:	66 90                	xchg   %ax,%ax
    db50:	66 85 c0             	test   %ax,%ax
    db53:	0f 85 94 f1 ff ff    	jne    cced <f0+0x1a8d>
    db59:	e9 7f f1 ff ff       	jmp    ccdd <f0+0x1a7d>
    db5e:	66 90                	xchg   %ax,%ax
    db60:	66 85 c0             	test   %ax,%ax
    db63:	0f 85 e5 f0 ff ff    	jne    cc4e <f0+0x19ee>
    db69:	e9 d0 f0 ff ff       	jmp    cc3e <f0+0x19de>
    db6e:	66 90                	xchg   %ax,%ax
    db70:	66 85 c0             	test   %ax,%ax
    db73:	0f 85 fd d9 ff ff    	jne    b576 <f0+0x316>
    db79:	e9 e8 d9 ff ff       	jmp    b566 <f0+0x306>
    db7e:	66 90                	xchg   %ax,%ax
    db80:	66 85 c0             	test   %ax,%ax
    db83:	0f 85 57 d9 ff ff    	jne    b4e0 <f0+0x280>
    db89:	e9 42 d9 ff ff       	jmp    b4d0 <f0+0x270>
    db8e:	66 90                	xchg   %ax,%ax
    db90:	66 85 c0             	test   %ax,%ax
    db93:	0f 85 b1 d8 ff ff    	jne    b44a <f0+0x1ea>
    db99:	e9 9c d8 ff ff       	jmp    b43a <f0+0x1da>
    db9e:	66 90                	xchg   %ax,%ax
    dba0:	66 85 c0             	test   %ax,%ax
    dba3:	0f 85 0e eb ff ff    	jne    c6b7 <f0+0x1457>
    dba9:	e9 f9 ea ff ff       	jmp    c6a7 <f0+0x1447>
    dbae:	66 90                	xchg   %ax,%ax
    dbb0:	66 85 c0             	test   %ax,%ax
    dbb3:	0f 85 5f ea ff ff    	jne    c618 <f0+0x13b8>
    dbb9:	e9 4a ea ff ff       	jmp    c608 <f0+0x13a8>
    dbbe:	66 90                	xchg   %ax,%ax
    dbc0:	66 85 c0             	test   %ax,%ax
    dbc3:	0f 85 e2 da ff ff    	jne    b6ab <f0+0x44b>
    dbc9:	e9 cd da ff ff       	jmp    b69b <f0+0x43b>
    dbce:	66 90                	xchg   %ax,%ax
    dbd0:	66 85 c0             	test   %ax,%ax
    dbd3:	0f 85 33 da ff ff    	jne    b60c <f0+0x3ac>
    dbd9:	e9 1e da ff ff       	jmp    b5fc <f0+0x39c>
    dbde:	66 90                	xchg   %ax,%ax
    dbe0:	66 85 c0             	test   %ax,%ax
    dbe3:	0f 85 c6 ef ff ff    	jne    cbaf <f0+0x194f>
    dbe9:	e9 b1 ef ff ff       	jmp    cb9f <f0+0x193f>
    dbee:	66 90                	xchg   %ax,%ax
    dbf0:	66 85 c0             	test   %ax,%ax
    dbf3:	0f 85 17 ef ff ff    	jne    cb10 <f0+0x18b0>
    dbf9:	e9 02 ef ff ff       	jmp    cb00 <f0+0x18a0>
    dbfe:	66 90                	xchg   %ax,%ax
    dc00:	66 85 c0             	test   %ax,%ax
    dc03:	0f 85 68 ee ff ff    	jne    ca71 <f0+0x1811>
    dc09:	e9 53 ee ff ff       	jmp    ca61 <f0+0x1801>
    dc0e:	66 90                	xchg   %ax,%ax
    dc10:	66 85 c0             	test   %ax,%ax
    dc13:	0f 85 b9 ed ff ff    	jne    c9d2 <f0+0x1772>
    dc19:	e9 a4 ed ff ff       	jmp    c9c2 <f0+0x1762>
    dc1e:	66 90                	xchg   %ax,%ax
    dc20:	66 85 c0             	test   %ax,%ax
    dc23:	0f 85 0a ed ff ff    	jne    c933 <f0+0x16d3>
    dc29:	e9 f5 ec ff ff       	jmp    c923 <f0+0x16c3>
    dc2e:	66 90                	xchg   %ax,%ax
    dc30:	66 85 c0             	test   %ax,%ax
    dc33:	0f 85 5b ec ff ff    	jne    c894 <f0+0x1634>
    dc39:	e9 46 ec ff ff       	jmp    c884 <f0+0x1624>
    dc3e:	66 90                	xchg   %ax,%ax
    dc40:	66 85 c0             	test   %ax,%ax
    dc43:	0f 85 ac eb ff ff    	jne    c7f5 <f0+0x1595>
    dc49:	e9 97 eb ff ff       	jmp    c7e5 <f0+0x1585>
    dc4e:	66 90                	xchg   %ax,%ax
    dc50:	66 85 c0             	test   %ax,%ax
    dc53:	0f 85 fd ea ff ff    	jne    c756 <f0+0x14f6>
    dc59:	e9 e8 ea ff ff       	jmp    c746 <f0+0x14e6>
    dc5e:	66 90                	xchg   %ax,%ax
    dc60:	66 85 c0             	test   %ax,%ax
    dc63:	0f 85 29 fe ff ff    	jne    da92 <f0+0x2832>
    dc69:	e9 14 fe ff ff       	jmp    da82 <f0+0x2822>
    dc6e:	66 90                	xchg   %ax,%ax
    dc70:	66 85 c0             	test   %ax,%ax
    dc73:	0f 85 7f fd ff ff    	jne    d9f8 <f0+0x2798>
    dc79:	e9 6a fd ff ff       	jmp    d9e8 <f0+0x2788>
    dc7e:	66 90                	xchg   %ax,%ax
    dc80:	66 85 c0             	test   %ax,%ax
    dc83:	0f 85 d0 fc ff ff    	jne    d959 <f0+0x26f9>
    dc89:	e9 bb fc ff ff       	jmp    d949 <f0+0x26e9>
    dc8e:	66 90                	xchg   %ax,%ax
    dc90:	66 85 c0             	test   %ax,%ax
    dc93:	0f 85 21 fc ff ff    	jne    d8ba <f0+0x265a>
    dc99:	e9 0c fc ff ff       	jmp    d8aa <f0+0x264a>
    dc9e:	66 90                	xchg   %ax,%ax
    dca0:	66 85 c0             	test   %ax,%ax
    dca3:	0f 85 72 fb ff ff    	jne    d81b <f0+0x25bb>
    dca9:	e9 5d fb ff ff       	jmp    d80b <f0+0x25ab>
    dcae:	66 90                	xchg   %ax,%ax
    dcb0:	66 85 c0             	test   %ax,%ax
    dcb3:	0f 85 c3 fa ff ff    	jne    d77c <f0+0x251c>
    dcb9:	e9 ae fa ff ff       	jmp    d76c <f0+0x250c>
    dcbe:	66 90                	xchg   %ax,%ax
    dcc0:	66 85 c0             	test   %ax,%ax
    dcc3:	0f 85 14 fa ff ff    	jne    d6dd <f0+0x247d>
    dcc9:	e9 ff f9 ff ff       	jmp    d6cd <f0+0x246d>
    dcce:	66 90                	xchg   %ax,%ax
    dcd0:	66 85 c0             	test   %ax,%ax
    dcd3:	0f 85 65 f9 ff ff    	jne    d63e <f0+0x23de>
    dcd9:	e9 50 f9 ff ff       	jmp    d62e <f0+0x23ce>
    dcde:	66 90                	xchg   %ax,%ax
    dce0:	66 85 c0             	test   %ax,%ax
    dce3:	0f 85 b6 f8 ff ff    	jne    d59f <f0+0x233f>
    dce9:	e9 a1 f8 ff ff       	jmp    d58f <f0+0x232f>
    dcee:	66 90                	xchg   %ax,%ax
    dcf0:	66 85 c0             	test   %ax,%ax
    dcf3:	0f 85 07 f8 ff ff    	jne    d500 <f0+0x22a0>
    dcf9:	e9 f2 f7 ff ff       	jmp    d4f0 <f0+0x2290>
    dcfe:	66 90                	xchg   %ax,%ax
    dd00:	66 85 c0             	test   %ax,%ax
    dd03:	0f 85 58 f7 ff ff    	jne    d461 <f0+0x2201>
    dd09:	e9 43 f7 ff ff       	jmp    d451 <f0+0x21f1>
    dd0e:	66 90                	xchg   %ax,%ax
    dd10:	66 85 c0             	test   %ax,%ax
    dd13:	0f 85 a9 f6 ff ff    	jne    d3c2 <f0+0x2162>
    dd19:	e9 94 f6 ff ff       	jmp    d3b2 <f0+0x2152>
    dd1e:	66 90                	xchg   %ax,%ax
    dd20:	66 85 c0             	test   %ax,%ax
    dd23:	0f 85 fa f5 ff ff    	jne    d323 <f0+0x20c3>
    dd29:	e9 e5 f5 ff ff       	jmp    d313 <f0+0x20b3>
    dd2e:	66 90                	xchg   %ax,%ax
    dd30:	66 85 c0             	test   %ax,%ax
    dd33:	0f 85 4b f5 ff ff    	jne    d284 <f0+0x2024>
    dd39:	e9 36 f5 ff ff       	jmp    d274 <f0+0x2014>
    dd3e:	66 90                	xchg   %ax,%ax
    dd40:	66 85 c0             	test   %ax,%ax
    dd43:	0f 85 9c f4 ff ff    	jne    d1e5 <f0+0x1f85>
    dd49:	e9 87 f4 ff ff       	jmp    d1d5 <f0+0x1f75>
    dd4e:	66 90                	xchg   %ax,%ax
    dd50:	66 85 c0             	test   %ax,%ax
    dd53:	0f 85 ed f3 ff ff    	jne    d146 <f0+0x1ee6>
    dd59:	e9 d8 f3 ff ff       	jmp    d136 <f0+0x1ed6>
    dd5e:	4c 89 e7             	mov    %r12,%rdi
    dd61:	e8 6a 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd66:	e9 22 fd ff ff       	jmp    da8d <f0+0x282d>
    dd6b:	4c 89 e7             	mov    %r12,%rdi
    dd6e:	e8 5d 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd73:	e9 cd d6 ff ff       	jmp    b445 <f0+0x1e5>
    dd78:	4c 89 e7             	mov    %r12,%rdi
    dd7b:	e8 50 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd80:	e9 56 d7 ff ff       	jmp    b4db <f0+0x27b>
    dd85:	4c 89 e7             	mov    %r12,%rdi
    dd88:	e8 43 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd8d:	e9 df d7 ff ff       	jmp    b571 <f0+0x311>
    dd92:	4c 89 e7             	mov    %r12,%rdi
    dd95:	e8 36 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd9a:	e9 68 d8 ff ff       	jmp    b607 <f0+0x3a7>
    dd9f:	4c 89 e7             	mov    %r12,%rdi
    dda2:	e8 29 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dda7:	e9 fa d8 ff ff       	jmp    b6a6 <f0+0x446>
    ddac:	4c 89 e7             	mov    %r12,%rdi
    ddaf:	e8 1c 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ddb4:	e9 5a e8 ff ff       	jmp    c613 <f0+0x13b3>
    ddb9:	4c 89 e7             	mov    %r12,%rdi
    ddbc:	e8 0f 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ddc1:	e9 ec e8 ff ff       	jmp    c6b2 <f0+0x1452>
    ddc6:	4c 89 e7             	mov    %r12,%rdi
    ddc9:	e8 02 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ddce:	e9 7e e9 ff ff       	jmp    c751 <f0+0x14f1>
    ddd3:	4c 89 e7             	mov    %r12,%rdi
    ddd6:	e8 f5 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    dddb:	e9 10 ea ff ff       	jmp    c7f0 <f0+0x1590>
    dde0:	4c 89 e7             	mov    %r12,%rdi
    dde3:	e8 e8 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    dde8:	e9 a2 ea ff ff       	jmp    c88f <f0+0x162f>
    dded:	4c 89 e7             	mov    %r12,%rdi
    ddf0:	e8 db 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    ddf5:	e9 34 eb ff ff       	jmp    c92e <f0+0x16ce>
    ddfa:	4c 89 e7             	mov    %r12,%rdi
    ddfd:	e8 ce 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de02:	e9 c6 eb ff ff       	jmp    c9cd <f0+0x176d>
    de07:	4c 89 e7             	mov    %r12,%rdi
    de0a:	e8 c1 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de0f:	e9 58 ec ff ff       	jmp    ca6c <f0+0x180c>
    de14:	4c 89 e7             	mov    %r12,%rdi
    de17:	e8 b4 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de1c:	e9 ea ec ff ff       	jmp    cb0b <f0+0x18ab>
    de21:	4c 89 e7             	mov    %r12,%rdi
    de24:	e8 a7 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de29:	e9 7c ed ff ff       	jmp    cbaa <f0+0x194a>
    de2e:	4c 89 e7             	mov    %r12,%rdi
    de31:	e8 9a 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de36:	e9 0e ee ff ff       	jmp    cc49 <f0+0x19e9>
    de3b:	4c 89 e7             	mov    %r12,%rdi
    de3e:	e8 8d 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de43:	e9 a0 ee ff ff       	jmp    cce8 <f0+0x1a88>
    de48:	4c 89 e7             	mov    %r12,%rdi
    de4b:	e8 80 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de50:	e9 32 ef ff ff       	jmp    cd87 <f0+0x1b27>
    de55:	4c 89 e7             	mov    %r12,%rdi
    de58:	e8 73 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de5d:	e9 c4 ef ff ff       	jmp    ce26 <f0+0x1bc6>
    de62:	4c 89 e7             	mov    %r12,%rdi
    de65:	e8 66 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de6a:	e9 56 f0 ff ff       	jmp    cec5 <f0+0x1c65>
    de6f:	4c 89 e7             	mov    %r12,%rdi
    de72:	e8 59 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de77:	e9 e8 f0 ff ff       	jmp    cf64 <f0+0x1d04>
    de7c:	4c 89 e7             	mov    %r12,%rdi
    de7f:	e8 4c 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de84:	e9 7a f1 ff ff       	jmp    d003 <f0+0x1da3>
    de89:	4c 89 e7             	mov    %r12,%rdi
    de8c:	e8 3f 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de91:	e9 0c f2 ff ff       	jmp    d0a2 <f0+0x1e42>
    de96:	4c 89 e7             	mov    %r12,%rdi
    de99:	e8 32 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de9e:	e9 9e f2 ff ff       	jmp    d141 <f0+0x1ee1>
    dea3:	4c 89 e7             	mov    %r12,%rdi
    dea6:	e8 25 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    deab:	e9 30 f3 ff ff       	jmp    d1e0 <f0+0x1f80>
    deb0:	4c 89 e7             	mov    %r12,%rdi
    deb3:	e8 18 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    deb8:	e9 c2 f3 ff ff       	jmp    d27f <f0+0x201f>
    debd:	4c 89 e7             	mov    %r12,%rdi
    dec0:	e8 0b 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    dec5:	e9 54 f4 ff ff       	jmp    d31e <f0+0x20be>
    deca:	4c 89 e7             	mov    %r12,%rdi
    decd:	e8 fe 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    ded2:	e9 e6 f4 ff ff       	jmp    d3bd <f0+0x215d>
    ded7:	4c 89 e7             	mov    %r12,%rdi
    deda:	e8 f1 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    dedf:	e9 78 f5 ff ff       	jmp    d45c <f0+0x21fc>
    dee4:	4c 89 e7             	mov    %r12,%rdi
    dee7:	e8 e4 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    deec:	e9 0a f6 ff ff       	jmp    d4fb <f0+0x229b>
    def1:	4c 89 e7             	mov    %r12,%rdi
    def4:	e8 d7 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    def9:	e9 9c f6 ff ff       	jmp    d59a <f0+0x233a>
    defe:	4c 89 e7             	mov    %r12,%rdi
    df01:	e8 ca 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    df06:	e9 2e f7 ff ff       	jmp    d639 <f0+0x23d9>
    df0b:	4c 89 e7             	mov    %r12,%rdi
    df0e:	e8 bd 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    df13:	e9 c0 f7 ff ff       	jmp    d6d8 <f0+0x2478>
    df18:	4c 89 e7             	mov    %r12,%rdi
    df1b:	e8 b0 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    df20:	e9 52 f8 ff ff       	jmp    d777 <f0+0x2517>
    df25:	4c 89 e7             	mov    %r12,%rdi
    df28:	e8 a3 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    df2d:	e9 e4 f8 ff ff       	jmp    d816 <f0+0x25b6>
    df32:	4c 89 e7             	mov    %r12,%rdi
    df35:	e8 96 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    df3a:	e9 76 f9 ff ff       	jmp    d8b5 <f0+0x2655>
    df3f:	4c 89 e7             	mov    %r12,%rdi
    df42:	e8 89 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    df47:	e9 08 fa ff ff       	jmp    d954 <f0+0x26f4>
    df4c:	4c 89 e7             	mov    %r12,%rdi
    df4f:	e8 7c 78 ff ff       	call   57d0 <fwp_rc_forget_slot>
    df54:	e9 9a fa ff ff       	jmp    d9f3 <f0+0x2793>
    df59:	e8 f2 54 ff ff       	call   3450 <__stack_chk_fail@plt>
    df5e:	66 90                	xchg   %ax,%ax

000000000000df60 <fwp_main_thread>:
    df60:	f3 0f 1e fa          	endbr64
    df64:	41 54                	push   %r12
    df66:	55                   	push   %rbp
    df67:	53                   	push   %rbx
    df68:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    df6f:	8b 0d 4f ec 05 00    	mov    0x5ec4f(%rip),%ecx        # 6cbc4 <fwp_heap+0x13a4>
    df75:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    df7c:	00 00 
    df7e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    df85:	00 
    df86:	31 c0                	xor    %eax,%eax
    df88:	85 c9                	test   %ecx,%ecx
    df8a:	0f 84 58 07 00 00    	je     e6e8 <fwp_main_thread+0x788>
    df90:	8b 15 32 ec 05 00    	mov    0x5ec32(%rip),%edx        # 6cbc8 <fwp_heap+0x13a8>
    df96:	85 d2                	test   %edx,%edx
    df98:	0f 85 32 07 00 00    	jne    e6d0 <fwp_main_thread+0x770>
    df9e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    dfa3:	31 f6                	xor    %esi,%esi
    dfa5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    dfaa:	48 c7 05 0b d2 05 00 	movq   $0x40000000,0x5d20b(%rip)        # 6b1c0 <fwp_main_stack_size>
    dfb1:	00 00 00 40 
    dfb5:	48 89 05 0c d2 05 00 	mov    %rax,0x5d20c(%rip)        # 6b1c8 <fwp_main_stack_top>
    dfbc:	48 8d 05 bd 50 00 00 	lea    0x50bd(%rip),%rax        # 13080 <alt.5>
    dfc3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    dfc8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    dfcf:	01 00 
    dfd1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    dfd8:	00 
    dfd9:	e8 c2 56 ff ff       	call   36a0 <sigaltstack@plt>
    dfde:	85 c0                	test   %eax,%eax
    dfe0:	0f 85 6a 07 00 00    	jne    e750 <fwp_main_thread+0x7f0>
    dfe6:	31 c0                	xor    %eax,%eax
    dfe8:	b9 12 00 00 00       	mov    $0x12,%ecx
    dfed:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dff2:	f3 48 ab             	rep stos %rax,(%rdi)
    dff5:	48 8d 05 44 5d ff ff 	lea    -0xa2bc(%rip),%rax        # 3d40 <fwp_segv>
    dffc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e001:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e008:	04 00 00 08 
    e00c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e011:	e8 4a 55 ff ff       	call   3560 <sigemptyset@plt>
    e016:	85 c0                	test   %eax,%eax
    e018:	0f 85 32 07 00 00    	jne    e750 <fwp_main_thread+0x7f0>
    e01e:	31 d2                	xor    %edx,%edx
    e020:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e025:	bf 0b 00 00 00       	mov    $0xb,%edi
    e02a:	e8 c1 53 ff ff       	call   33f0 <sigaction@plt>
    e02f:	85 c0                	test   %eax,%eax
    e031:	0f 85 19 07 00 00    	jne    e750 <fwp_main_thread+0x7f0>
    e037:	31 d2                	xor    %edx,%edx
    e039:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e03e:	bf 07 00 00 00       	mov    $0x7,%edi
    e043:	e8 a8 53 ff ff       	call   33f0 <sigaction@plt>
    e048:	85 c0                	test   %eax,%eax
    e04a:	0f 85 00 07 00 00    	jne    e750 <fwp_main_thread+0x7f0>
    e050:	48 8b 05 e9 eb 05 00 	mov    0x5ebe9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    e057:	48 85 c0             	test   %rax,%rax
    e05a:	0f 88 50 06 00 00    	js     e6b0 <fwp_main_thread+0x750>
    e060:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e064:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    e069:	48 8d 3d b0 61 ff ff 	lea    -0x9e50(%rip),%rdi        # 4220 <ad_raw_report>
    e070:	f2 0f 11 05 50 f4 05 	movsd  %xmm0,0x5f450(%rip)        # 6d4c8 <iteration_start_charge>
    e077:	00 
    e078:	c7 05 66 f4 05 00 01 	movl   $0x1,0x5f466(%rip)        # 6d4e8 <iteration_active>
    e07f:	00 00 00 
    e082:	e8 09 09 00 00       	call   e990 <atexit>
    e087:	85 c0                	test   %eax,%eax
    e089:	0f 85 cd 06 00 00    	jne    e75c <fwp_main_thread+0x7fc>
    e08f:	8b 05 db 4f 00 00    	mov    0x4fdb(%rip),%eax        # 13070 <st.3>
    e095:	85 c0                	test   %eax,%eax
    e097:	0f 84 5b 06 00 00    	je     e6f8 <fwp_main_thread+0x798>
    e09d:	48 8b 2d 5c d7 05 00 	mov    0x5d75c(%rip),%rbp        # 6b800 <fwp_cur>
    e0a4:	48 85 ed             	test   %rbp,%rbp
    e0a7:	0f 84 03 03 00 00    	je     e3b0 <fwp_main_thread+0x450>
    e0ad:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e0b2:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e0b6:	48 89 eb             	mov    %rbp,%rbx
    e0b9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e0be:	0f 84 41 01 00 00    	je     e205 <fwp_main_thread+0x2a5>
    e0c4:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e0c9:	0f 84 11 02 00 00    	je     e2e0 <fwp_main_thread+0x380>
    e0cf:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e0d3:	0f 84 f7 01 00 00    	je     e2d0 <fwp_main_thread+0x370>
    e0d9:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e0dd:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e0e1:	0f 85 79 02 00 00    	jne    e360 <fwp_main_thread+0x400>
    e0e7:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e0eb:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e0f2:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e0f6:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e0fd:	00 00 00 00 
    e101:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e108:	48 85 d2             	test   %rdx,%rdx
    e10b:	74 07                	je     e114 <fwp_main_thread+0x1b4>
    e10d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e114:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e118:	48 85 c0             	test   %rax,%rax
    e11b:	74 34                	je     e151 <fwp_main_thread+0x1f1>
    e11d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e121:	48 8b 05 b0 d6 05 00 	mov    0x5d6b0(%rip),%rax        # 6b7d8 <fwp_timers>
    e128:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e12c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e133:	00 00 00 00 
    e137:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e13e:	48 85 c0             	test   %rax,%rax
    e141:	74 07                	je     e14a <fwp_main_thread+0x1ea>
    e143:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e14a:	48 89 1d 87 d6 05 00 	mov    %rbx,0x5d687(%rip)        # 6b7d8 <fwp_timers>
    e151:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e155:	e8 96 97 ff ff       	call   78f0 <fwp_block>
    e15a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e161:	48 85 c9             	test   %rcx,%rcx
    e164:	74 47                	je     e1ad <fwp_main_thread+0x24d>
    e166:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e16d:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e174:	48 85 d2             	test   %rdx,%rdx
    e177:	0f 84 23 02 00 00    	je     e3a0 <fwp_main_thread+0x440>
    e17d:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e184:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e18b:	48 85 c0             	test   %rax,%rax
    e18e:	74 07                	je     e197 <fwp_main_thread+0x237>
    e190:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e197:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e19e:	00 00 00 00 
    e1a2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    e1a6:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    e1ad:	48 8b 0d 4c d6 05 00 	mov    0x5d64c(%rip),%rcx        # 6b800 <fwp_cur>
    e1b4:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e1b8:	0f 84 92 01 00 00    	je     e350 <fwp_main_thread+0x3f0>
    e1be:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e1c5:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e1cc:	48 85 d2             	test   %rdx,%rdx
    e1cf:	0f 84 1b 04 00 00    	je     e5f0 <fwp_main_thread+0x690>
    e1d5:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e1dc:	48 85 c0             	test   %rax,%rax
    e1df:	74 07                	je     e1e8 <fwp_main_thread+0x288>
    e1e1:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e1e8:	66 0f ef db          	pxor   %xmm3,%xmm3
    e1ec:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e1f0:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    e1f7:	48 89 cb             	mov    %rcx,%rbx
    e1fa:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e1ff:	0f 85 bf fe ff ff    	jne    e0c4 <fwp_main_thread+0x164>
    e205:	48 83 3d 8b f2 05 00 	cmpq   $0x0,0x5f28b(%rip)        # 6d498 <fwp_state_len>
    e20c:	00 
    e20d:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e211:	0f 84 0b 04 00 00    	je     e622 <fwp_main_thread+0x6c2>
    e217:	48 3b 1d da d5 05 00 	cmp    0x5d5da(%rip),%rbx        # 6b7f8 <fwp_root>
    e21e:	c7 05 58 4e 01 00 00 	movl   $0x0,0x14e58(%rip)        # 23080 <fwp_exit_code>
    e225:	00 00 00 
    e228:	0f 85 4c 05 00 00    	jne    e77a <fwp_main_thread+0x81a>
    e22e:	48 85 db             	test   %rbx,%rbx
    e231:	0f 84 9f 01 00 00    	je     e3d6 <fwp_main_thread+0x476>
    e237:	48 8b 15 8a d5 05 00 	mov    0x5d58a(%rip),%rdx        # 6b7c8 <fwp_tasks_active>
    e23e:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e242:	48 85 d2             	test   %rdx,%rdx
    e245:	0f 84 8b 01 00 00    	je     e3d6 <fwp_main_thread+0x476>
    e24b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e250:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e254:	75 08                	jne    e25e <fwp_main_thread+0x2fe>
    e256:	48 89 d7             	mov    %rdx,%rdi
    e259:	e8 d2 5e ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e25e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e265:	48 85 d2             	test   %rdx,%rdx
    e268:	75 e6                	jne    e250 <fwp_main_thread+0x2f0>
    e26a:	eb 31                	jmp    e29d <fwp_main_thread+0x33d>
    e26c:	0f 1f 40 00          	nopl   0x0(%rax)
    e270:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e277:	48 89 1d 62 d5 05 00 	mov    %rbx,0x5d562(%rip)        # 6b7e0 <fwp_ready_tail>
    e27e:	e8 6d 96 ff ff       	call   78f0 <fwp_block>
    e283:	e8 58 94 ff ff       	call   76e0 <fwp_free_zombie>
    e288:	48 83 3d 38 d5 05 00 	cmpq   $0x0,0x5d538(%rip)        # 6b7c8 <fwp_tasks_active>
    e28f:	00 
    e290:	0f 84 40 01 00 00    	je     e3d6 <fwp_main_thread+0x476>
    e296:	48 8b 1d 5b d5 05 00 	mov    0x5d55b(%rip),%rbx        # 6b7f8 <fwp_root>
    e29d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e2a1:	75 db                	jne    e27e <fwp_main_thread+0x31e>
    e2a3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e2a7:	75 d5                	jne    e27e <fwp_main_thread+0x31e>
    e2a9:	48 8b 05 30 d5 05 00 	mov    0x5d530(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    e2b0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e2b4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e2bb:	00 00 00 00 
    e2bf:	48 85 c0             	test   %rax,%rax
    e2c2:	75 ac                	jne    e270 <fwp_main_thread+0x310>
    e2c4:	48 89 1d 1d d5 05 00 	mov    %rbx,0x5d51d(%rip)        # 6b7e8 <fwp_ready_head>
    e2cb:	eb aa                	jmp    e277 <fwp_main_thread+0x317>
    e2cd:	0f 1f 00             	nopl   (%rax)
    e2d0:	e8 eb 62 ff ff       	call   45c0 <fwp_now_ns>
    e2d5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e2d9:	0f 8d 21 03 00 00    	jge    e600 <fwp_main_thread+0x6a0>
    e2df:	90                   	nop
    e2e0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e2e4:	0f 85 ef fd ff ff    	jne    e0d9 <fwp_main_thread+0x179>
    e2ea:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e2ee:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e2f2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e2f6:	0f 85 ef fd ff ff    	jne    e0eb <fwp_main_thread+0x18b>
    e2fc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e300:	48 85 c9             	test   %rcx,%rcx
    e303:	0f 84 e2 fd ff ff    	je     e0eb <fwp_main_thread+0x18b>
    e309:	48 85 c0             	test   %rax,%rax
    e30c:	0f 84 5b 04 00 00    	je     e76d <fwp_main_thread+0x80d>
    e312:	48 39 c8             	cmp    %rcx,%rax
    e315:	48 0f 4f c1          	cmovg  %rcx,%rax
    e319:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e320:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e324:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e32b:	00 00 00 00 
    e32f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e336:	48 85 d2             	test   %rdx,%rdx
    e339:	74 07                	je     e342 <fwp_main_thread+0x3e2>
    e33b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e342:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e346:	e9 d2 fd ff ff       	jmp    e11d <fwp_main_thread+0x1bd>
    e34b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e350:	48 89 cb             	mov    %rcx,%rbx
    e353:	e9 61 fd ff ff       	jmp    e0b9 <fwp_main_thread+0x159>
    e358:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e35f:	00 
    e360:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e364:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e36b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e372:	00 00 00 00 
    e376:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e37d:	48 85 c0             	test   %rax,%rax
    e380:	0f 84 9a 03 00 00    	je     e720 <fwp_main_thread+0x7c0>
    e386:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e38d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e391:	e9 bb fd ff ff       	jmp    e151 <fwp_main_thread+0x1f1>
    e396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e39d:	00 00 00 
    e3a0:	48 89 01             	mov    %rax,(%rcx)
    e3a3:	e9 e3 fd ff ff       	jmp    e18b <fwp_main_thread+0x22b>
    e3a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e3af:	00 
    e3b0:	48 83 3d e0 f0 05 00 	cmpq   $0x0,0x5f0e0(%rip)        # 6d498 <fwp_state_len>
    e3b7:	00 
    e3b8:	0f 84 62 02 00 00    	je     e620 <fwp_main_thread+0x6c0>
    e3be:	48 83 3d 32 d4 05 00 	cmpq   $0x0,0x5d432(%rip)        # 6b7f8 <fwp_root>
    e3c5:	00 
    e3c6:	c7 05 b0 4c 01 00 00 	movl   $0x0,0x14cb0(%rip)        # 23080 <fwp_exit_code>
    e3cd:	00 00 00 
    e3d0:	0f 85 9f 03 00 00    	jne    e775 <fwp_main_thread+0x815>
    e3d6:	e8 05 93 ff ff       	call   76e0 <fwp_free_zombie>
    e3db:	48 83 3d 05 d4 05 00 	cmpq   $0x0,0x5d405(%rip)        # 6b7e8 <fwp_ready_head>
    e3e2:	00 
    e3e3:	0f 85 6c 53 ff ff    	jne    3755 <fwp_main_thread.cold>
    e3e9:	48 83 3d e7 d3 05 00 	cmpq   $0x0,0x5d3e7(%rip)        # 6b7d8 <fwp_timers>
    e3f0:	00 
    e3f1:	0f 85 5e 53 ff ff    	jne    3755 <fwp_main_thread.cold>
    e3f7:	8b 1d d7 cd 05 00    	mov    0x5cdd7(%rip),%ebx        # 6b1d4 <fwp_stack_pool_n>
    e3fd:	85 db                	test   %ebx,%ebx
    e3ff:	74 36                	je     e437 <fwp_main_thread+0x4d7>
    e401:	83 eb 01             	sub    $0x1,%ebx
    e404:	48 8d 05 d5 cd 05 00 	lea    0x5cdd5(%rip),%rax        # 6b1e0 <fwp_stack_pool>
    e40b:	48 63 d3             	movslq %ebx,%rdx
    e40e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e412:	eb 07                	jmp    e41b <fwp_main_thread+0x4bb>
    e414:	0f 1f 40 00          	nopl   0x0(%rax)
    e418:	83 eb 01             	sub    $0x1,%ebx
    e41b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e41f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e424:	89 1d aa cd 05 00    	mov    %ebx,0x5cdaa(%rip)        # 6b1d4 <fwp_stack_pool_n>
    e42a:	48 83 ed 08          	sub    $0x8,%rbp
    e42e:	e8 8d 51 ff ff       	call   35c0 <munmap@plt>
    e433:	85 db                	test   %ebx,%ebx
    e435:	75 e1                	jne    e418 <fwp_main_thread+0x4b8>
    e437:	8b 3d db 4b 00 00    	mov    0x4bdb(%rip),%edi        # 13018 <fwp_epfd>
    e43d:	85 ff                	test   %edi,%edi
    e43f:	78 05                	js     e446 <fwp_main_thread+0x4e6>
    e441:	e8 7a 50 ff ff       	call   34c0 <close@plt>
    e446:	4c 8b 25 93 cf 05 00 	mov    0x5cf93(%rip),%r12        # 6b3e0 <fwp_nfdws>
    e44d:	48 8b 2d 94 cf 05 00 	mov    0x5cf94(%rip),%rbp        # 6b3e8 <fwp_fdws>
    e454:	31 db                	xor    %ebx,%ebx
    e456:	c7 05 b8 4b 00 00 ff 	movl   $0xffffffff,0x4bb8(%rip)        # 13018 <fwp_epfd>
    e45d:	ff ff ff 
    e460:	4d 85 e4             	test   %r12,%r12
    e463:	74 38                	je     e49d <fwp_main_thread+0x53d>
    e465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e46c:	00 00 00 00 
    e470:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e475:	48 85 ff             	test   %rdi,%rdi
    e478:	74 1a                	je     e494 <fwp_main_thread+0x534>
    e47a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e47e:	0f 85 d1 52 ff ff    	jne    3755 <fwp_main_thread.cold>
    e484:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e489:	0f 85 c6 52 ff ff    	jne    3755 <fwp_main_thread.cold>
    e48f:	e8 7c 75 ff ff       	call   5a10 <fwp_mem_free>
    e494:	48 83 c3 01          	add    $0x1,%rbx
    e498:	49 39 dc             	cmp    %rbx,%r12
    e49b:	75 d3                	jne    e470 <fwp_main_thread+0x510>
    e49d:	48 89 ef             	mov    %rbp,%rdi
    e4a0:	e8 6b 75 ff ff       	call   5a10 <fwp_mem_free>
    e4a5:	48 8b 15 4c d3 05 00 	mov    0x5d34c(%rip),%rdx        # 6b7f8 <fwp_root>
    e4ac:	48 c7 05 31 cf 05 00 	movq   $0x0,0x5cf31(%rip)        # 6b3e8 <fwp_fdws>
    e4b3:	00 00 00 00 
    e4b7:	48 c7 05 1e cf 05 00 	movq   $0x0,0x5cf1e(%rip)        # 6b3e0 <fwp_nfdws>
    e4be:	00 00 00 00 
    e4c2:	48 85 d2             	test   %rdx,%rdx
    e4c5:	74 4e                	je     e515 <fwp_main_thread+0x5b5>
    e4c7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e4cc:	0f 85 83 52 ff ff    	jne    3755 <fwp_main_thread.cold>
    e4d2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e4d9:	00 
    e4da:	0f 85 75 52 ff ff    	jne    3755 <fwp_main_thread.cold>
    e4e0:	48 83 3d b0 ef 05 00 	cmpq   $0x0,0x5efb0(%rip)        # 6d498 <fwp_state_len>
    e4e7:	00 
    e4e8:	0f 85 67 52 ff ff    	jne    3755 <fwp_main_thread.cold>
    e4ee:	48 83 3d 92 ef 05 00 	cmpq   $0x0,0x5ef92(%rip)        # 6d488 <fwp_state_owners>
    e4f5:	00 
    e4f6:	0f 85 59 52 ff ff    	jne    3755 <fwp_main_thread.cold>
    e4fc:	b9 79 00 00 00       	mov    $0x79,%ecx
    e501:	31 c0                	xor    %eax,%eax
    e503:	48 8d 3d f6 ce 05 00 	lea    0x5cef6(%rip),%rdi        # 6b400 <fwp_root_context>
    e50a:	f3 48 ab             	rep stos %rax,(%rdi)
    e50d:	48 89 d7             	mov    %rdx,%rdi
    e510:	e8 fb 74 ff ff       	call   5a10 <fwp_mem_free>
    e515:	66 0f 6f 05 93 4c 04 	movdqa 0x44c93(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    e51c:	00 
    e51d:	66 0f d4 05 7b 4c 04 	paddq  0x44c7b(%rip),%xmm0        # 531a0 <ad_raw_live>
    e524:	00 
    e525:	48 c7 05 d0 d2 05 00 	movq   $0x0,0x5d2d0(%rip)        # 6b800 <fwp_cur>
    e52c:	00 00 00 00 
    e530:	48 8b 05 09 e7 05 00 	mov    0x5e709(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    e537:	48 c7 05 b6 d2 05 00 	movq   $0x0,0x5d2b6(%rip)        # 6b7f8 <fwp_root>
    e53e:	00 00 00 00 
    e542:	c7 05 9c ef 05 00 00 	movl   $0x0,0x5ef9c(%rip)        # 6d4e8 <iteration_active>
    e549:	00 00 00 
    e54c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    e550:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    e555:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    e559:	66 0f d6 05 97 4b 01 	movq   %xmm0,0x14b97(%rip)        # 230f8 <ad_raw_before_shutdown>
    e560:	00 
    e561:	48 85 c0             	test   %rax,%rax
    e564:	0f 88 26 01 00 00    	js     e690 <fwp_main_thread+0x730>
    e56a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e56e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    e573:	f2 0f 5c 0d 4d ef 05 	subsd  0x5ef4d(%rip),%xmm1        # 6d4c8 <iteration_start_charge>
    e57a:	00 
    e57b:	48 8b 3d be 4a 00 00 	mov    0x4abe(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    e582:	48 8d 15 e7 15 00 00 	lea    0x15e7(%rip),%rdx        # fb70 <_IO_stdin_used+0xb70>
    e589:	be 02 00 00 00       	mov    $0x2,%esi
    e58e:	f2 0f 10 05 2a ef 05 	movsd  0x5ef2a(%rip),%xmm0        # 6d4c0 <iteration_peak>
    e595:	00 
    e596:	4c 8b 0d 33 ef 05 00 	mov    0x5ef33(%rip),%r9        # 6d4d0 <iteration_retains>
    e59d:	b8 02 00 00 00       	mov    $0x2,%eax
    e5a2:	4c 8b 05 2f ef 05 00 	mov    0x5ef2f(%rip),%r8        # 6d4d8 <iteration_bytes>
    e5a9:	48 8b 0d 30 ef 05 00 	mov    0x5ef30(%rip),%rcx        # 6d4e0 <iteration_requests>
    e5b0:	e8 bb 50 ff ff       	call   3670 <__fprintf_chk@plt>
    e5b5:	48 8b 3d 64 4a 00 00 	mov    0x4a64(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e5bc:	e8 df 4f ff ff       	call   35a0 <fflush@plt>
    e5c1:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e5c8:	00 
    e5c9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e5d0:	00 00 
    e5d2:	0f 85 90 01 00 00    	jne    e768 <fwp_main_thread+0x808>
    e5d8:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e5df:	31 c0                	xor    %eax,%eax
    e5e1:	5b                   	pop    %rbx
    e5e2:	5d                   	pop    %rbp
    e5e3:	41 5c                	pop    %r12
    e5e5:	c3                   	ret
    e5e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e5ed:	00 00 00 
    e5f0:	48 89 05 e1 d1 05 00 	mov    %rax,0x5d1e1(%rip)        # 6b7d8 <fwp_timers>
    e5f7:	e9 e0 fb ff ff       	jmp    e1dc <fwp_main_thread+0x27c>
    e5fc:	0f 1f 40 00          	nopl   0x0(%rax)
    e600:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e604:	0f 85 d6 fc ff ff    	jne    e2e0 <fwp_main_thread+0x380>
    e60a:	48 89 ef             	mov    %rbp,%rdi
    e60d:	e8 1e 5b ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e612:	e9 c9 fc ff ff       	jmp    e2e0 <fwp_main_thread+0x380>
    e617:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e61e:	00 00 
    e620:	31 db                	xor    %ebx,%ebx
    e622:	48 83 3d 5e ee 05 00 	cmpq   $0x0,0x5ee5e(%rip)        # 6d488 <fwp_state_owners>
    e629:	00 
    e62a:	0f 85 e7 fb ff ff    	jne    e217 <fwp_main_thread+0x2b7>
    e630:	48 8b 3d 69 ee 05 00 	mov    0x5ee69(%rip),%rdi        # 6d4a0 <fwp_state>
    e637:	e8 d4 73 ff ff       	call   5a10 <fwp_mem_free>
    e63c:	48 c7 05 59 ee 05 00 	movq   $0x0,0x5ee59(%rip)        # 6d4a0 <fwp_state>
    e643:	00 00 00 00 
    e647:	48 c7 05 3e ee 05 00 	movq   $0x0,0x5ee3e(%rip)        # 6d490 <fwp_state_cap>
    e64e:	00 00 00 00 
    e652:	48 85 db             	test   %rbx,%rbx
    e655:	0f 84 ce 00 00 00    	je     e729 <fwp_main_thread+0x7c9>
    e65b:	48 39 1d 96 d1 05 00 	cmp    %rbx,0x5d196(%rip)        # 6b7f8 <fwp_root>
    e662:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e669:	00 00 00 00 
    e66d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e674:	00 00 00 00 
    e678:	c7 05 fe 49 01 00 00 	movl   $0x0,0x149fe(%rip)        # 23080 <fwp_exit_code>
    e67f:	00 00 00 
    e682:	0f 84 af fb ff ff    	je     e237 <fwp_main_thread+0x2d7>
    e688:	e9 c8 50 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e68d:	0f 1f 00             	nopl   (%rax)
    e690:	48 89 c2             	mov    %rax,%rdx
    e693:	83 e0 01             	and    $0x1,%eax
    e696:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e69a:	48 d1 ea             	shr    $1,%rdx
    e69d:	48 09 c2             	or     %rax,%rdx
    e6a0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    e6a5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    e6a9:	e9 c5 fe ff ff       	jmp    e573 <fwp_main_thread+0x613>
    e6ae:	66 90                	xchg   %ax,%ax
    e6b0:	48 89 c2             	mov    %rax,%rdx
    e6b3:	83 e0 01             	and    $0x1,%eax
    e6b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e6ba:	48 d1 ea             	shr    $1,%rdx
    e6bd:	48 09 c2             	or     %rax,%rdx
    e6c0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    e6c5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    e6c9:	e9 9b f9 ff ff       	jmp    e069 <fwp_main_thread+0x109>
    e6ce:	66 90                	xchg   %ax,%ax
    e6d0:	48 8d 3d e9 65 ff ff 	lea    -0x9a17(%rip),%rdi        # 4cc0 <fwp_heap_report>
    e6d7:	e8 b4 02 00 00       	call   e990 <atexit>
    e6dc:	e9 bd f8 ff ff       	jmp    df9e <fwp_main_thread+0x3e>
    e6e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e6e8:	e8 e3 66 ff ff       	call   4dd0 <fwp_heap_init>
    e6ed:	e9 9e f8 ff ff       	jmp    df90 <fwp_main_thread+0x30>
    e6f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e6f8:	e8 63 cb ff ff       	call   b260 <f0>
    e6fd:	48 c7 05 60 49 00 00 	movq   $0x0,0x4960(%rip)        # 13068 <v.2>
    e704:	00 00 00 00 
    e708:	c7 05 5e 49 00 00 01 	movl   $0x1,0x495e(%rip)        # 13070 <st.3>
    e70f:	00 00 00 
    e712:	e9 86 f9 ff ff       	jmp    e09d <fwp_main_thread+0x13d>
    e717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e71e:	00 00 
    e720:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e724:	e9 28 fa ff ff       	jmp    e151 <fwp_main_thread+0x1f1>
    e729:	48 83 3d c7 d0 05 00 	cmpq   $0x0,0x5d0c7(%rip)        # 6b7f8 <fwp_root>
    e730:	00 
    e731:	c7 05 45 49 01 00 00 	movl   $0x0,0x14945(%rip)        # 23080 <fwp_exit_code>
    e738:	00 00 00 
    e73b:	0f 84 95 fc ff ff    	je     e3d6 <fwp_main_thread+0x476>
    e741:	e9 0f 50 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e746:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e74d:	00 00 00 
    e750:	48 8d 3d f1 13 00 00 	lea    0x13f1(%rip),%rdi        # fb48 <_IO_stdin_used+0xb48>
    e757:	e8 f4 5c ff ff       	call   4450 <fwp_trap>
    e75c:	48 8d 3d 70 0b 00 00 	lea    0xb70(%rip),%rdi        # f2d3 <_IO_stdin_used+0x2d3>
    e763:	e8 98 58 ff ff       	call   4000 <ad_raw_fail>
    e768:	e8 e3 4c ff ff       	call   3450 <__stack_chk_fail@plt>
    e76d:	48 89 c8             	mov    %rcx,%rax
    e770:	e9 a4 fb ff ff       	jmp    e319 <fwp_main_thread+0x3b9>
    e775:	e9 db 4f ff ff       	jmp    3755 <fwp_main_thread.cold>
    e77a:	e9 d6 4f ff ff       	jmp    3755 <fwp_main_thread.cold>
    e77f:	90                   	nop

000000000000e780 <__divmodti4>:
    e780:	f3 0f 1e fa          	endbr64
    e784:	55                   	push   %rbp
    e785:	49 89 f1             	mov    %rsi,%r9
    e788:	49 89 d2             	mov    %rdx,%r10
    e78b:	48 89 fe             	mov    %rdi,%rsi
    e78e:	49 89 cb             	mov    %rcx,%r11
    e791:	48 89 e5             	mov    %rsp,%rbp
    e794:	41 57                	push   %r15
    e796:	41 56                	push   %r14
    e798:	41 55                	push   %r13
    e79a:	41 54                	push   %r12
    e79c:	53                   	push   %rbx
    e79d:	4c 89 c3             	mov    %r8,%rbx
    e7a0:	45 31 c0             	xor    %r8d,%r8d
    e7a3:	4d 85 c9             	test   %r9,%r9
    e7a6:	79 12                	jns    e7ba <__divmodti4+0x3a>
    e7a8:	31 ff                	xor    %edi,%edi
    e7aa:	48 f7 de             	neg    %rsi
    e7ad:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e7b4:	4c 19 cf             	sbb    %r9,%rdi
    e7b7:	49 89 f9             	mov    %rdi,%r9
    e7ba:	4c 89 d8             	mov    %r11,%rax
    e7bd:	4d 85 db             	test   %r11,%r11
    e7c0:	0f 88 1a 01 00 00    	js     e8e0 <__divmodti4+0x160>
    e7c6:	4c 89 d9             	mov    %r11,%rcx
    e7c9:	49 89 f3             	mov    %rsi,%r11
    e7cc:	75 62                	jne    e830 <__divmodti4+0xb0>
    e7ce:	4d 89 c4             	mov    %r8,%r12
    e7d1:	4d 39 d1             	cmp    %r10,%r9
    e7d4:	0f 83 46 01 00 00    	jae    e920 <__divmodti4+0x1a0>
    e7da:	4c 89 d8             	mov    %r11,%rax
    e7dd:	4c 89 ca             	mov    %r9,%rdx
    e7e0:	49 f7 f2             	div    %r10
    e7e3:	49 89 c3             	mov    %rax,%r11
    e7e6:	31 c0                	xor    %eax,%eax
    e7e8:	48 89 d6             	mov    %rdx,%rsi
    e7eb:	31 ff                	xor    %edi,%edi
    e7ed:	4c 89 d9             	mov    %r11,%rcx
    e7f0:	48 89 c2             	mov    %rax,%rdx
    e7f3:	48 89 c8             	mov    %rcx,%rax
    e7f6:	4d 85 e4             	test   %r12,%r12
    e7f9:	74 0a                	je     e805 <__divmodti4+0x85>
    e7fb:	48 f7 d8             	neg    %rax
    e7fe:	48 83 d2 00          	adc    $0x0,%rdx
    e802:	48 f7 da             	neg    %rdx
    e805:	4d 85 c0             	test   %r8,%r8
    e808:	74 0a                	je     e814 <__divmodti4+0x94>
    e80a:	48 f7 de             	neg    %rsi
    e80d:	48 83 d7 00          	adc    $0x0,%rdi
    e811:	48 f7 df             	neg    %rdi
    e814:	48 89 33             	mov    %rsi,(%rbx)
    e817:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e81b:	5b                   	pop    %rbx
    e81c:	41 5c                	pop    %r12
    e81e:	41 5d                	pop    %r13
    e820:	41 5e                	pop    %r14
    e822:	41 5f                	pop    %r15
    e824:	5d                   	pop    %rbp
    e825:	c3                   	ret
    e826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e82d:	00 00 00 
    e830:	4d 89 c4             	mov    %r8,%r12
    e833:	49 39 c1             	cmp    %rax,%r9
    e836:	0f 82 ce 00 00 00    	jb     e90a <__divmodti4+0x18a>
    e83c:	31 ff                	xor    %edi,%edi
    e83e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e843:	48 63 c7             	movslq %edi,%rax
    e846:	be 40 00 00 00       	mov    $0x40,%esi
    e84b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e850:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e855:	48 29 c6             	sub    %rax,%rsi
    e858:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e85d:	48 09 c8             	or     %rcx,%rax
    e860:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e865:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e86a:	49 89 c6             	mov    %rax,%r14
    e86d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e871:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e876:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e87b:	49 09 c1             	or     %rax,%r9
    e87e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e882:	4c 89 c8             	mov    %r9,%rax
    e885:	49 f7 f6             	div    %r14
    e888:	48 89 d1             	mov    %rdx,%rcx
    e88b:	49 89 c3             	mov    %rax,%r11
    e88e:	49 89 c1             	mov    %rax,%r9
    e891:	49 f7 e2             	mul    %r10
    e894:	49 89 c6             	mov    %rax,%r14
    e897:	49 89 d2             	mov    %rdx,%r10
    e89a:	48 39 d1             	cmp    %rdx,%rcx
    e89d:	72 07                	jb     e8a6 <__divmodti4+0x126>
    e89f:	75 17                	jne    e8b8 <__divmodti4+0x138>
    e8a1:	49 39 c7             	cmp    %rax,%r15
    e8a4:	73 12                	jae    e8b8 <__divmodti4+0x138>
    e8a6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e8aa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e8ae:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e8b2:	49 89 d2             	mov    %rdx,%r10
    e8b5:	49 89 c6             	mov    %rax,%r14
    e8b8:	4c 89 f8             	mov    %r15,%rax
    e8bb:	4c 29 f0             	sub    %r14,%rax
    e8be:	4c 19 d1             	sbb    %r10,%rcx
    e8c1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e8c6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e8cb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e8d0:	48 09 c6             	or     %rax,%rsi
    e8d3:	48 89 cf             	mov    %rcx,%rdi
    e8d6:	31 c0                	xor    %eax,%eax
    e8d8:	4c 89 c9             	mov    %r9,%rcx
    e8db:	e9 10 ff ff ff       	jmp    e7f0 <__divmodti4+0x70>
    e8e0:	4c 89 d0             	mov    %r10,%rax
    e8e3:	4c 89 da             	mov    %r11,%rdx
    e8e6:	4d 89 c4             	mov    %r8,%r12
    e8e9:	49 89 f3             	mov    %rsi,%r11
    e8ec:	48 f7 d8             	neg    %rax
    e8ef:	49 f7 d4             	not    %r12
    e8f2:	48 83 d2 00          	adc    $0x0,%rdx
    e8f6:	49 89 c2             	mov    %rax,%r10
    e8f9:	48 f7 da             	neg    %rdx
    e8fc:	48 89 d1             	mov    %rdx,%rcx
    e8ff:	0f 84 cc fe ff ff    	je     e7d1 <__divmodti4+0x51>
    e905:	49 39 d1             	cmp    %rdx,%r9
    e908:	73 46                	jae    e950 <__divmodti4+0x1d0>
    e90a:	4c 89 cf             	mov    %r9,%rdi
    e90d:	31 c0                	xor    %eax,%eax
    e90f:	31 c9                	xor    %ecx,%ecx
    e911:	e9 da fe ff ff       	jmp    e7f0 <__divmodti4+0x70>
    e916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e91d:	00 00 00 
    e920:	4d 85 d2             	test   %r10,%r10
    e923:	75 0d                	jne    e932 <__divmodti4+0x1b2>
    e925:	b8 01 00 00 00       	mov    $0x1,%eax
    e92a:	31 d2                	xor    %edx,%edx
    e92c:	49 f7 f2             	div    %r10
    e92f:	49 89 c2             	mov    %rax,%r10
    e932:	4c 89 c8             	mov    %r9,%rax
    e935:	31 d2                	xor    %edx,%edx
    e937:	49 f7 f2             	div    %r10
    e93a:	49 89 c1             	mov    %rax,%r9
    e93d:	4c 89 d8             	mov    %r11,%rax
    e940:	49 f7 f2             	div    %r10
    e943:	49 89 c3             	mov    %rax,%r11
    e946:	4c 89 c8             	mov    %r9,%rax
    e949:	e9 9a fe ff ff       	jmp    e7e8 <__divmodti4+0x68>
    e94e:	66 90                	xchg   %ax,%ax
    e950:	45 31 f6             	xor    %r14d,%r14d
    e953:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e958:	44 89 f7             	mov    %r14d,%edi
    e95b:	45 85 f6             	test   %r14d,%r14d
    e95e:	0f 85 df fe ff ff    	jne    e843 <__divmodti4+0xc3>
    e964:	4c 39 ca             	cmp    %r9,%rdx
    e967:	72 17                	jb     e980 <__divmodti4+0x200>
    e969:	31 c9                	xor    %ecx,%ecx
    e96b:	48 39 c6             	cmp    %rax,%rsi
    e96e:	73 10                	jae    e980 <__divmodti4+0x200>
    e970:	4c 89 cf             	mov    %r9,%rdi
    e973:	31 c0                	xor    %eax,%eax
    e975:	e9 76 fe ff ff       	jmp    e7f0 <__divmodti4+0x70>
    e97a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e980:	4c 89 de             	mov    %r11,%rsi
    e983:	b9 01 00 00 00       	mov    $0x1,%ecx
    e988:	48 29 c6             	sub    %rax,%rsi
    e98b:	49 19 d1             	sbb    %rdx,%r9
    e98e:	eb e0                	jmp    e970 <__divmodti4+0x1f0>

000000000000e990 <atexit>:
    e990:	f3 0f 1e fa          	endbr64
    e994:	48 8b 15 6d 46 00 00 	mov    0x466d(%rip),%rdx        # 13008 <__dso_handle>
    e99b:	31 f6                	xor    %esi,%esi
    e99d:	e9 9e 4c ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e9a4 <_fini>:
    e9a4:	f3 0f 1e fa          	endbr64
    e9a8:	48 83 ec 08          	sub    $0x8,%rsp
    e9ac:	48 83 c4 08          	add    $0x8,%rsp
    e9b0:	c3                   	ret
