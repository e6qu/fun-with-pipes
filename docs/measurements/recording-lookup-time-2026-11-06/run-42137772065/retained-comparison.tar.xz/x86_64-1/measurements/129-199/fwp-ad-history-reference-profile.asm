
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 0f 01 00 	mov    0x10fd1(%rip),%rax        # 13fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 0d 01 00    	push   0x10df2(%rip)        # 13e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 0d 01 00    	jmp    *0x10df4(%rip)        # 13e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 0c 01 00    	jmp    *0x10c66(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e 0a 01 00    	jmp    *0x10a8e(%rip)        # 13e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 0a 01 00    	jmp    *0x10a86(%rip)        # 13e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e 0a 01 00    	jmp    *0x10a7e(%rip)        # 13e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 0a 01 00    	jmp    *0x10a76(%rip)        # 13e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e 0a 01 00    	jmp    *0x10a6e(%rip)        # 13e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 0a 01 00    	jmp    *0x10a66(%rip)        # 13e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e 0a 01 00    	jmp    *0x10a5e(%rip)        # 13e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 0a 01 00    	jmp    *0x10a56(%rip)        # 13e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e 0a 01 00    	jmp    *0x10a4e(%rip)        # 13e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 0a 01 00    	jmp    *0x10a46(%rip)        # 13e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e 0a 01 00    	jmp    *0x10a3e(%rip)        # 13e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 0a 01 00    	jmp    *0x10a36(%rip)        # 13e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e 0a 01 00    	jmp    *0x10a2e(%rip)        # 13e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 0a 01 00    	jmp    *0x10a26(%rip)        # 13e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e 0a 01 00    	jmp    *0x10a1e(%rip)        # 13e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 0a 01 00    	jmp    *0x10a16(%rip)        # 13ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e 0a 01 00    	jmp    *0x10a0e(%rip)        # 13ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 0a 01 00    	jmp    *0x10a06(%rip)        # 13eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe 09 01 00    	jmp    *0x109fe(%rip)        # 13eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 09 01 00    	jmp    *0x109f6(%rip)        # 13ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee 09 01 00    	jmp    *0x109ee(%rip)        # 13ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 09 01 00    	jmp    *0x109e6(%rip)        # 13ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de 09 01 00    	jmp    *0x109de(%rip)        # 13ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 09 01 00    	jmp    *0x109d6(%rip)        # 13ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce 09 01 00    	jmp    *0x109ce(%rip)        # 13ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 09 01 00    	jmp    *0x109c6(%rip)        # 13ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be 09 01 00    	jmp    *0x109be(%rip)        # 13ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 09 01 00    	jmp    *0x109b6(%rip)        # 13f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae 09 01 00    	jmp    *0x109ae(%rip)        # 13f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 09 01 00    	jmp    *0x109a6(%rip)        # 13f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e 09 01 00    	jmp    *0x1099e(%rip)        # 13f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 09 01 00    	jmp    *0x10996(%rip)        # 13f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e 09 01 00    	jmp    *0x1098e(%rip)        # 13f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 09 01 00    	jmp    *0x10986(%rip)        # 13f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e 09 01 00    	jmp    *0x1097e(%rip)        # 13f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 09 01 00    	jmp    *0x10976(%rip)        # 13f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e 09 01 00    	jmp    *0x1096e(%rip)        # 13f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 09 01 00    	jmp    *0x10966(%rip)        # 13f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e 09 01 00    	jmp    *0x1095e(%rip)        # 13f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 09 01 00    	jmp    *0x10956(%rip)        # 13f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e 09 01 00    	jmp    *0x1094e(%rip)        # 13f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 09 01 00    	jmp    *0x10946(%rip)        # 13f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e 09 01 00    	jmp    *0x1093e(%rip)        # 13f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 09 01 00    	jmp    *0x10936(%rip)        # 13f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e 09 01 00    	jmp    *0x1092e(%rip)        # 13f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 09 01 00    	jmp    *0x10926(%rip)        # 13f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e 09 01 00    	jmp    *0x1091e(%rip)        # 13f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 09 01 00    	jmp    *0x10916(%rip)        # 13fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e 09 01 00    	jmp    *0x1090e(%rip)        # 13fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 09 01 00    	jmp    *0x10906(%rip)        # 13fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe 08 01 00    	jmp    *0x108fe(%rip)        # 13fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 08 01 00    	jmp    *0x108f6(%rip)        # 13fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee 08 01 00    	jmp    *0x108ee(%rip)        # 13fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 c9 00 00 	lea    0xc9b8(%rip),%r9        # 100cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 c9 00 00 	lea    0xc9b5(%rip),%r8        # 100d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ed 00 00 	lea    0xed01(%rip),%rax        # 12480 <fwp_fn_table>
    377f:	48 89 05 12 ad 06 00 	mov    %rax,0x6ad12(%rip)        # 6e498 <fwp_fns>
    3786:	48 8b 05 b3 08 01 00 	mov    0x108b3(%rip),%rax        # 14040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 0c ad 06 00 	mov    %rax,0x6ad0c(%rip)        # 6e4a0 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e cb 00 00 	lea    0xcb4e(%rip),%rdi        # 102ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 08 01 00 	mov    0x10838(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 7f b0 00 00 	lea    0xb07f(%rip),%rdx        # e8e0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 07 01 00 	mov    0x107a3(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 f8 07 02 00    	mov    0x207f8(%rip),%eax        # 240a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe c9 00 00 	lea    0xc9fe(%rip),%rdi        # 102f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 d3 00 00 	lea    0xd346(%rip),%rdi        # 10c50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 d3 00 00 	lea    0xd300(%rip),%rdi        # 10c28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 d2 00 00 	lea    0xd2c4(%rip),%rdi        # 10bf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 d2 00 00 	lea    0xd290(%rip),%rdi        # 10bd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b 06 01 00    	call   *0x1065b(%rip)        # 13fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 06 01 00 	lea    0x106a1(%rip),%rdi        # 14028 <__TMC_END__>
    3987:	48 8d 05 9a 06 01 00 	lea    0x1069a(%rip),%rax        # 14028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e 06 01 00 	mov    0x1063e(%rip),%rax        # 13fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 06 01 00 	lea    0x10671(%rip),%rdi        # 14028 <__TMC_END__>
    39b7:	48 8d 35 6a 06 01 00 	lea    0x1066a(%rip),%rsi        # 14028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d 06 01 00 	mov    0x1060d(%rip),%rax        # 13fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d 06 01 00 00 	cmpb   $0x0,0x1066d(%rip)        # 14068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea 05 01 00 	cmpq   $0x0,0x105ea(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 05 01 00 	mov    0x105f6(%rip),%rdi        # 14008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 06 01 00 01 	movb   $0x1,0x10645(%rip)        # 14068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 b7 05 05 00 	lea    0x505b7(%rip),%r8        # 541c0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 5b 05 05 00 	lea    0x5055b(%rip),%rcx        # 54180 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 2f 05 05 00 	lea    0x5052f(%rip),%rcx        # 54160 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 61 05 05 00 	lea    0x50561(%rip),%rcx        # 541a0 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 70 05 05 	movdqa 0x50570(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 58 05 05 	paddq  0x50558(%rip),%xmm0        # 541c0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 bf 04 05 00 	cmp    %rax,0x504bf(%rip)        # 54140 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 b5 04 05 	movq   %xmm0,0x504b5(%rip)        # 54140 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 5e 04 02 00 	add    0x2045e(%rip),%rdx        # 24110 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 4c 04 02 00 	add    0x2044c(%rip),%rax        # 24110 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 99 a7 06 00 	mov    0x6a799(%rip),%rdi        # 6e4a0 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 24 03 01 00 	mov    0x10324(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d 11 03 01 00 	mov    0x10311(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 d1 8a 06 00 	mov    0x68ad1(%rip),%rax        # 6c820 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 19 84 06 00 	mov    0x68419(%rip),%rax        # 6c1e8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 05 84 06 00 	sub    0x68405(%rip),%rax        # 6c1e0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d cf 00 00 	lea    0xcf1d(%rip),%rsi        # 10d30 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 c1 00 00 	lea    0xc1c5(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d 12 02 01 00 	mov    0x10212(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 ab 9d 06 00 	mov    0x69dab(%rip),%rax        # 6dc30 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 a4 9d 06 00 	lea    0x69da4(%rip),%r8        # 6dc30 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 85 9d 06 00 	mov    0x69d85(%rip),%rbx        # 6dc18 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 95 9d 06 00 	mov    0x69d95(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 31 9d 06 00 	mov    0x69d31(%rip),%rdi        # 6dc20 <fwp_heap+0x13e0>
    3eef:	48 29 35 7a 9d 06 00 	sub    %rsi,0x69d7a(%rip)        # 6dc70 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 0a 9d 06 00 	mov    0x69d0a(%rip),%rax        # 6dc10 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d c0 9c 06 00 	add    0x69cc0(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ce 9c 06 00 	mov    0x69cce(%rip),%rsi        # 6dc20 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 dc 9c 06 00 	mov    0x69cdc(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 8b 9c 06 00 	mov    %r12,0x69c8b(%rip)        # 6dc20 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 79 9c 06 00 	mov    %rbp,0x69c79(%rip)        # 6dc18 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 5e 9c 06 00 	cmp    %rdi,0x69c5e(%rip)        # 6dc08 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 55 9c 06 00 	mov    %rdi,0x69c55(%rip)        # 6dc08 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 99 9c 06 00 	sub    %rdi,0x69c99(%rip)        # 6dc70 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 41 9c 06 00 	mov    0x69c41(%rip),%rax        # 6dc28 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 3a 9c 06 00 	lea    0x69c3a(%rip),%r8        # 6dc28 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef c6 00 00 	lea    0xc6ef(%rip),%rdx        # 106f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 42 00 01 00 	mov    0x10042(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 9d ff 00 00 	mov    0xff9d(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 bf 00 00 	lea    0xbf34(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d e9 86 06 00 	cmp    0x686e9(%rip),%rdi        # 6c820 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 af 86 06 00 	mov    0x686af(%rip),%rax        # 6c800 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 8d 86 06 00 	mov    %rdi,0x6868d(%rip)        # 6c800 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 69 86 06 00 	mov    %rdi,0x68669(%rip)        # 6c808 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f c0 00 00 	lea    0xc05f(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 be 00 00 	lea    0xbe27(%rip),%rsi        # 1001c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 96 ff 04 	movdqa 0x4ff96(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 7e ff 04 	paddq  0x4ff7e(%rip),%xmm0        # 541c0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 a4 fe 01 00 	mov    0x1fea4(%rip),%r8        # 24118 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d be fe 04 00 	mov    0x4febe(%rip),%rcx        # 54140 <ad_raw_total_peak>
    4282:	48 8b 3d d7 fd 00 00 	mov    0xfdd7(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 c4 00 00 	lea    0xc4b5(%rip),%rdx        # 10748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d 01 ff 04 00 	lea    0x4ff01(%rip),%r15        # 541a0 <ad_raw_peak>
    429f:	4c 8d 35 ba fe 04 00 	lea    0x4feba(%rip),%r14        # 54160 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 bd 00 00 	lea    0xbd79(%rip),%rax        # 1002b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 f9 00 	movq   0xf956(%rip),%xmm0        # 13c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d bf fe 04 00 	lea    0x4febf(%rip),%r13        # 54180 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f bd 00 00 	lea    0xbd6f(%rip),%rax        # 1003c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 f9 00 	movq   0xf936(%rip),%xmm0        # 13c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 53 fd 00 00 	mov    0xfd53(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c bd 00 00 	lea    0xbd0c(%rip),%rcx        # 10020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d c4 00 00 	lea    0xc48d(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 24 fd 00 00 	mov    0xfd24(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 bc 00 00 	lea    0xbcf8(%rip),%rdi        # 10045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d c6 fd 01 00 	cmpq   $0x0,0x1fdc6(%rip)        # 24120 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 dd fd 01 00 	mov    0x1fddd(%rip),%r8        # 24140 <ad_raw_checkpoints>
    4363:	4c 8b 0d de fd 01 00 	mov    0x1fdde(%rip),%r9        # 24148 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d cf fd 01 00 	lea    0x1fdcf(%rip),%rbx        # 24140 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 bc 00 00 	lea    0xbcf4(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 d1 fd 01 00 	mov    0x1fdd1(%rip),%rax        # 24150 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a bc 00 00 	lea    0xbc9a(%rip),%r12        # 10020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d a9 fc 00 00 	mov    0xfca9(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 c4 00 00 	lea    0xc429(%rip),%rdx        # 107e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 53 fd 01 00 	cmp    0x1fd53(%rip),%rbp        # 24120 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 78 fc 00 00 	mov    0xfc78(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b bc 00 00 	lea    0xbc5b(%rip),%rdi        # 10059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 43 fc 00 00 	mov    0xfc43(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 c3 00 00 	lea    0xc384(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 bc 00 00 	lea    0xbc40(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da c2 00 00 	lea    0xc2da(%rip),%rdi        # 10720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d e8 fb 00 00 	mov    0xfbe8(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df bb 00 00 	lea    0xbbdf(%rip),%rdx        # 1005e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d d0 fb 00 00 	mov    0xfbd0(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d e1 fa 00 00 	mov    0xfae1(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 ba 00 00 	lea    0xba78(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 ba 00 00 	lea    0xbac0(%rip),%rdi        # 1006d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 ba 00 00 	lea    0xba48(%rip),%rdi        # 10087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 c1 00 00 	lea    0xc1d8(%rip),%rdi        # 10828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 c6 00 	movdqa 0xc6e0(%rip),%xmm0        # 10d50 <msg.4+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 ca 9d 06 00 	add    0x69dca(%rip),%rax        # 6e498 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c c1 00 00 	lea    0xc12c(%rip),%rdi        # 10850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 c5 f9 01 00 	cmp    %rax,0x1f9c5(%rip)        # 24108 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 c0 f9 01 00 	add    0x1f9c0(%rip),%rax        # 24110 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 c1 00 00 	lea    0xc115(%rip),%rdi        # 10880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 b9 00 00 	lea    0xb920(%rip),%r8        # 100a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 b7 00 00 	lea    0xb775(%rip),%r8        # 100b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 b6 00 00 	lea    0xb612(%rip),%r8        # 100a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea b3 00 00 	lea    0xb3ea(%rip),%rdi        # 100b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a b5 00 00 	lea    0xb59a(%rip),%rsi        # 10288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d a5 8e 06 00 	mov    0x68ea5(%rip),%r9        # 6dc08 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 fe 8e 06 00 	mov    0x68efe(%rip),%r8        # 6dc68 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f bb 00 00 	lea    0xbb5f(%rip),%rdx        # 108d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d e6 8e 06 00 	mov    0x68ee6(%rip),%rcx        # 6dc60 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d f4 8e 06 	movsd  0x68ef4(%rip),%xmm1        # 6dc80 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 e4 8e 06 	movsd  0x68ee4(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d c5 f2 00 00 	mov    0xf2c5(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 bf 00 	movdqa 0xbf88(%rip),%xmm0        # 10d60 <msg.4+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 9f 89 06 00 	lea    0x6899f(%rip),%rax        # 6d780 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 bf 00 	movdqa 0xbfb1(%rip),%xmm2        # 10da0 <msg.4+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 45 89 06 00 	movaps %xmm0,0x68945(%rip)        # 6d740 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d bf 00 	movdqa 0xbf6d(%rip),%xmm0        # 10d70 <msg.4+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 d3 8d 06 00 01 	movl   $0x1,0x68dd3(%rip)        # 6dbe4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 33 89 06 00 	movaps %xmm0,0x68933(%rip)        # 6d750 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b bf 00 	movdqa 0xbf5b(%rip),%xmm0        # 10d80 <msg.4+0x50>
    4e24:	00 
    4e25:	0f 29 05 34 89 06 00 	movaps %xmm0,0x68934(%rip)        # 6d760 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c bf 00 	movdqa 0xbf5c(%rip),%xmm0        # 10d90 <msg.4+0x60>
    4e33:	00 
    4e34:	0f 29 05 35 89 06 00 	movaps %xmm0,0x68935(%rip)        # 6d770 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 b5 79 06 00 	lea    0x679b5(%rip),%r8        # 6c840 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 d0 8c 06 00 	mov    %rax,0x68cd0(%rip)        # 6dbf8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 ae 8c 06 00 	mov    %r12,0x68cae(%rip)        # 6dc00 <fwp_heap+0x13c0>
    4f52:	48 89 05 97 8c 06 00 	mov    %rax,0x68c97(%rip)        # 6dbf0 <fwp_heap+0x13b0>
    4f59:	48 89 1d b0 8c 06 00 	mov    %rbx,0x68cb0(%rip)        # 6dc10 <fwp_heap+0x13d0>
    4f60:	48 89 35 d9 8c 06 00 	mov    %rsi,0x68cd9(%rip)        # 6dc40 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 b1 00 00 	lea    0xb174(%rip),%rdi        # 100ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 b8 8c 06 00 	mov    %rax,0x68cb8(%rip)        # 6dc38 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 3c 8c 06 00    	mov    %eax,0x68c3c(%rip)        # 6dbe8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 2c 78 06 00 	mov    0x6782c(%rip),%r8        # 6c800 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 5c 77 06 00 	mov    %rbx,0x6775c(%rip)        # 6c808 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 48 77 06 00 	mov    %r8,0x67748(%rip)        # 6c800 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d 09 f1 04 00 	lea    0x4f109(%rip),%rcx        # 541e0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d b8 f0 04 00 	lea    0x4f0b8(%rip),%rcx        # 541c0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 af 00 00 	lea    0xafc2(%rip),%rdi        # 100fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 36 f0 04 00 	lea    0x4f036(%rip),%r12        # 541e0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 ae 00 00 	lea    0xaee8(%rip),%rax        # 10112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc ae 00 00 	lea    0xaecc(%rip),%rdx        # 100fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 af 00 00 	lea    0xaf04(%rip),%rdi        # 10148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd ae 00 00 	lea    0xaedd(%rip),%rdi        # 1012d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa ae 00 00 	lea    0xaeaa(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ce ed 01 00 	lea    0x1edce(%rip),%rdi        # 240c0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 b6 ed 01 00 	movaps %xmm0,0x1edb6(%rip)        # 240c0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 92 ed 01 00 	mov    %rsi,0x1ed92(%rip)        # 240a8 <fwp_tape_cached_bytes>
    5316:	0f 29 05 b3 ed 01 00 	movaps %xmm0,0x1edb3(%rip)        # 240d0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 b7 ed 01 00 	movaps %xmm0,0x1edb7(%rip)        # 240e0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 b8 ed 01 00 	mov    %rax,0x1edb8(%rip)        # 240f0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 ae 00 00 	lea    0xae09(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 3d ed 01 00 	mov    0x1ed3d(%rip),%rsi        # 240a8 <fwp_tape_cached_bytes>
    536b:	48 6b 15 8d ed 01 00 	imul   $0x68,0x1ed8d(%rip),%rdx        # 24100 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 46 ee 04 00 	cmp    0x4ee46(%rip),%rdx        # 541c0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 45 ee 04 00 	mov    0x4ee45(%rip),%rax        # 541c8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 3f ee 04 00 	add    0x4ee3f(%rip),%rax        # 541d0 <ad_raw_live+0x10>
    5391:	48 03 05 40 ee 04 00 	add    0x4ee40(%rip),%rax        # 541d8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 7c ed 01 00 	mov    0x1ed7c(%rip),%rcx        # 24120 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 65 ed 01 00 	mov    %rdi,0x1ed65(%rip)        # 24120 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 77 ed 01 00 	lea    0x1ed77(%rip),%rcx        # 24140 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 62 b5 00 00 	lea    0xb562(%rip),%rdi        # 10958 <_IO_stdin_used+0x958>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f ad 00 00 	lea    0xad6f(%rip),%rdi        # 10171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d c7 73 06 00 	mov    0x673c7(%rip),%rbx        # 6c7f8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 2a eb 00 00 	mov    0xeb2a(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 4b b4 00 00 	lea    0xb44b(%rip),%rdi        # 10988 <_IO_stdin_used+0x988>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 8d 72 06 00 	mov    0x6728d(%rip),%rax        # 6c800 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 67 72 06 00 	mov    %rdx,0x67267(%rip)        # 6c800 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d b4 71 06 00 	mov    0x671b4(%rip),%rbx        # 6c7f8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 71 71 06 00 	mov    %rbx,0x67171(%rip)        # 6c7f8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 71 71 06 00 	mov    %rdx,0x67171(%rip)        # 6c808 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 86 71 06 00 	lea    0x67186(%rip),%rsi        # 6c840 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 05 8d 06 00 	addq   $0x1,0x68d05(%rip)        # 6e488 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 1f b2 00 00 	lea    0xb21f(%rip),%rdi        # 109b8 <_IO_stdin_used+0x9b8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 30 b2 00 00 	lea    0xb230(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 a9 00 00 	lea    0xa9d2(%rip),%rdi        # 1018e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 3e 70 06 00 	lea    0x6703e(%rip),%rcx        # 6c840 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 3f 8c 06 00 	subq   $0x1,0x68c3f(%rip)        # 6e488 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 8b b1 00 00 	lea    0xb18b(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 20 8c 06 00 	cmpq   $0x0,0x68c20(%rip)        # 6e488 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 75 8b 06 00 	sub    %rax,0x68b75(%rip)        # 6e490 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 53 8b 06 00 	add    %r12,0x68b53(%rip)        # 6e490 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 af 82 06 00 	mov    0x682af(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 ac 6e 06 00 	lea    0x66eac(%rip),%rax        # 6c840 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 03 82 06 00 	add    0x68203(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 d0 81 06 00 	mov    0x681d0(%rip),%rsi        # 6dbf0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 f1 81 06 00 	mov    0x681f1(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 e5 81 06 00 	add    0x681e5(%rip),%r8        # 6dc38 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 ad 81 06 	addsd  0x681ad(%rip),%xmm0        # 6dc80 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 62 6d 06 00 	lea    0x66d62(%rip),%rax        # 6c840 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 6c 81 06 00 	sub    %rdi,0x6816c(%rip)        # 6dc60 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 84 81 06 	movsd  %xmm0,0x68184(%rip)        # 6dc80 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 3e 81 06 00 	sub    %rdx,0x6813e(%rip)        # 6dc60 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 44 81 06 	addsd  0x68144(%rip),%xmm0        # 6dc80 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 38 81 06 	movsd  %xmm0,0x68138(%rip)        # 6dc80 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 cf 80 06 00 	mov    0x680cf(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d c9 80 06 00 	add    %rcx,0x680c9(%rip)        # 6dc70 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 82 80 06 00 	cmp    0x68082(%rip),%r9        # 6dc30 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 79 80 06 00 	mov    %r9,0x68079(%rip)        # 6dc30 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 6a 80 06 00 	cmp    0x6806a(%rip),%r9        # 6dc28 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 5d 80 06 00 	mov    %r9,0x6805d(%rip)        # 6dc28 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 73 7f 06 00 	add    0x67f73(%rip),%rdi        # 6dc38 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 50 6b 06 00 	lea    0x66b50(%rip),%r15        # 6c840 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 c0 7e 06 00 	add    0x67ec0(%rip),%r12        # 6dbf0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 19 7f 06 00 	add    0x67f19(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 18 7f 06 00 	cmp    %rax,0x67f18(%rip)        # 6dc68 <fwp_heap+0x1428>
    5d50:	48 89 05 09 7f 06 00 	mov    %rax,0x67f09(%rip)        # 6dc60 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 08 7f 06 00 	mov    %rax,0x67f08(%rip)        # 6dc68 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 04 7f 06 	addsd  0x67f04(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 fc 7e 06 	movsd  %xmm0,0x67efc(%rip)        # 6dc78 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 43 7e 06 00    	mov    0x67e43(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 7f 6a 06 00 	lea    0x66a7f(%rip),%rdi        # 6c840 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 38 7e 06 00 	add    0x67e38(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 33 7e 06 00 	cmp    %rax,0x67e33(%rip)        # 6dc68 <fwp_heap+0x1428>
    5e35:	48 89 05 24 7e 06 00 	mov    %rax,0x67e24(%rip)        # 6dc60 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 23 7e 06 00 	mov    %rax,0x67e23(%rip)        # 6dc68 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 1f 7e 06 	addsd  0x67e1f(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 17 7e 06 	movsd  %xmm0,0x67e17(%rip)        # 6dc78 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ea 85 06 00    	mov    0x685ea(%rip),%ebx        # 6e508 <iteration_active>
    5f1e:	8b 05 c0 7c 06 00    	mov    0x67cc0(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 f4 68 06 00 	lea    0x668f4(%rip),%rax        # 6c840 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 ae 7c 06 00 	add    0x67cae(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 a9 7c 06 00 	cmp    %rax,0x67ca9(%rip)        # 6dc68 <fwp_heap+0x1428>
    5fbf:	48 89 05 9a 7c 06 00 	mov    %rax,0x67c9a(%rip)        # 6dc60 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 99 7c 06 00 	mov    %rax,0x67c99(%rip)        # 6dc68 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 98 7c 06 	addsd  0x67c98(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 90 7c 06 	movsd  %xmm0,0x67c90(%rip)        # 6dc78 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 6d 7c 06 00 	mov    0x67c6d(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 db 84 06 	subsd  0x684db(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 cb 84 06 	comisd 0x684cb(%rip),%xmm0        # 6e4e0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 c1 84 06 	movsd  %xmm0,0x684c1(%rip)        # 6e4e0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 c4 84 06 00 	addq   $0x1,0x684c4(%rip)        # 6e500 <iteration_requests>
    603b:	01 
    603c:	48 01 3d b5 84 06 00 	add    %rdi,0x684b5(%rip)        # 6e4f8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_apply>:
    6100:	55                   	push   %rbp
    6101:	48 89 f9             	mov    %rdi,%rcx
    6104:	48 89 e5             	mov    %rsp,%rbp
    6107:	41 57                	push   %r15
    6109:	41 56                	push   %r14
    610b:	41 55                	push   %r13
    610d:	41 89 f5             	mov    %esi,%r13d
    6110:	41 54                	push   %r12
    6112:	53                   	push   %rbx
    6113:	48 83 ec 28          	sub    $0x28,%rsp
    6117:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    611e:	00 00 
    6120:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6124:	49 89 d6             	mov    %rdx,%r14
    6127:	44 8b 09             	mov    (%rcx),%r9d
    612a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    612e:	49 89 e0             	mov    %rsp,%r8
    6131:	49 c1 e1 05          	shl    $0x5,%r9
    6135:	4c 03 0d 5c 83 06 00 	add    0x6835c(%rip),%r9        # 6e498 <fwp_fns>
    613c:	41 8b 19             	mov    (%r9),%ebx
    613f:	45 85 e4             	test   %r12d,%r12d
    6142:	75 2c                	jne    6170 <fwp_apply+0x70>
    6144:	41 39 dd             	cmp    %ebx,%r13d
    6147:	72 27                	jb     6170 <fwp_apply+0x70>
    6149:	85 db                	test   %ebx,%ebx
    614b:	0f 84 b7 01 00 00    	je     6308 <fwp_apply+0x208>
    6151:	4c 89 f7             	mov    %r14,%rdi
    6154:	41 ff 51 08          	call   *0x8(%r9)
    6158:	48 89 c1             	mov    %rax,%rcx
    615b:	41 39 dd             	cmp    %ebx,%r13d
    615e:	0f 84 7c 01 00 00    	je     62e0 <fwp_apply+0x1e0>
    6164:	89 d8                	mov    %ebx,%eax
    6166:	41 29 dd             	sub    %ebx,%r13d
    6169:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    616d:	eb b8                	jmp    6127 <fwp_apply+0x27>
    616f:	90                   	nop
    6170:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    6175:	41 39 df             	cmp    %ebx,%r15d
    6178:	0f 82 dc 00 00 00    	jb     625a <fwp_apply+0x15a>
    617e:	41 89 df             	mov    %ebx,%r15d
    6181:	b8 01 00 00 00       	mov    $0x1,%eax
    6186:	48 89 e2             	mov    %rsp,%rdx
    6189:	45 29 e7             	sub    %r12d,%r15d
    618c:	85 db                	test   %ebx,%ebx
    618e:	0f 45 c3             	cmovne %ebx,%eax
    6191:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    6198:	00 
    6199:	48 c1 e8 04          	shr    $0x4,%rax
    619d:	48 c1 e0 04          	shl    $0x4,%rax
    61a1:	48 89 c6             	mov    %rax,%rsi
    61a4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    61ab:	48 29 f2             	sub    %rsi,%rdx
    61ae:	48 39 d4             	cmp    %rdx,%rsp
    61b1:	74 15                	je     61c8 <fwp_apply+0xc8>
    61b3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    61ba:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    61c1:	00 00 
    61c3:	48 39 d4             	cmp    %rdx,%rsp
    61c6:	75 eb                	jne    61b3 <fwp_apply+0xb3>
    61c8:	25 ff 0f 00 00       	and    $0xfff,%eax
    61cd:	48 29 c4             	sub    %rax,%rsp
    61d0:	48 85 c0             	test   %rax,%rax
    61d3:	0f 85 59 01 00 00    	jne    6332 <fwp_apply+0x232>
    61d9:	45 89 e2             	mov    %r12d,%r10d
    61dc:	48 89 e6             	mov    %rsp,%rsi
    61df:	48 89 e7             	mov    %rsp,%rdi
    61e2:	31 c0                	xor    %eax,%eax
    61e4:	49 c1 e2 03          	shl    $0x3,%r10
    61e8:	45 85 e4             	test   %r12d,%r12d
    61eb:	74 25                	je     6212 <fwp_apply+0x112>
    61ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61f4:	00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6205:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6209:	48 83 c0 08          	add    $0x8,%rax
    620d:	4c 39 d0             	cmp    %r10,%rax
    6210:	75 ee                	jne    6200 <fwp_apply+0x100>
    6212:	45 85 ff             	test   %r15d,%r15d
    6215:	0f 84 f4 00 00 00    	je     630f <fwp_apply+0x20f>
    621b:	44 89 fa             	mov    %r15d,%edx
    621e:	4c 89 f0             	mov    %r14,%rax
    6221:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6225:	44 89 e2             	mov    %r12d,%edx
    6228:	66 90                	xchg   %ax,%ax
    622a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6231:	00 00 00 00 
    6235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    623c:	00 00 00 00 
    6240:	4c 8b 10             	mov    (%rax),%r10
    6243:	89 d1                	mov    %edx,%ecx
    6245:	48 83 c0 08          	add    $0x8,%rax
    6249:	83 c2 01             	add    $0x1,%edx
    624c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    6250:	4c 39 d8             	cmp    %r11,%rax
    6253:	75 eb                	jne    6240 <fwp_apply+0x140>
    6255:	e9 b5 00 00 00       	jmp    630f <fwp_apply+0x20f>
    625a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    625e:	be 02 00 00 00       	mov    $0x2,%esi
    6263:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    6267:	48 c1 e7 03          	shl    $0x3,%rdi
    626b:	e8 a0 fc ff ff       	call   5f10 <fwp_heap_alloc>
    6270:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    6274:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    6279:	48 89 c3             	mov    %rax,%rbx
    627c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    6280:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6284:	66 0f d6 00          	movq   %xmm0,(%rax)
    6288:	45 85 e4             	test   %r12d,%r12d
    628b:	74 14                	je     62a1 <fwp_apply+0x1a1>
    628d:	44 89 e2             	mov    %r12d,%edx
    6290:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    6294:	48 8d 78 08          	lea    0x8(%rax),%rdi
    6298:	48 c1 e2 03          	shl    $0x3,%rdx
    629c:	e8 4f d3 ff ff       	call   35f0 <memmove@plt>
    62a1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    62a5:	45 85 ed             	test   %r13d,%r13d
    62a8:	74 2e                	je     62d8 <fwp_apply+0x1d8>
    62aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62b1:	00 00 00 00 
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 
    62c0:	49 8b 16             	mov    (%r14),%rdx
    62c3:	44 89 e0             	mov    %r12d,%eax
    62c6:	49 83 c6 08          	add    $0x8,%r14
    62ca:	41 83 c4 01          	add    $0x1,%r12d
    62ce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    62d3:	49 39 ce             	cmp    %rcx,%r14
    62d6:	75 e8                	jne    62c0 <fwp_apply+0x1c0>
    62d8:	48 89 d9             	mov    %rbx,%rcx
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    62e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62eb:	00 00 
    62ed:	75 4e                	jne    633d <fwp_apply+0x23d>
    62ef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    62f3:	48 89 c8             	mov    %rcx,%rax
    62f6:	5b                   	pop    %rbx
    62f7:	41 5c                	pop    %r12
    62f9:	41 5d                	pop    %r13
    62fb:	41 5e                	pop    %r14
    62fd:	41 5f                	pop    %r15
    62ff:	5d                   	pop    %rbp
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	45 31 ff             	xor    %r15d,%r15d
    630b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    630f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6313:	41 ff 51 08          	call   *0x8(%r9)
    6317:	48 89 c1             	mov    %rax,%rcx
    631a:	45 39 fd             	cmp    %r15d,%r13d
    631d:	74 c1                	je     62e0 <fwp_apply+0x1e0>
    631f:	45 01 e5             	add    %r12d,%r13d
    6322:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6326:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    632a:	41 29 dd             	sub    %ebx,%r13d
    632d:	e9 f5 fd ff ff       	jmp    6127 <fwp_apply+0x27>
    6332:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6338:	e9 9c fe ff ff       	jmp    61d9 <fwp_apply+0xd9>
    633d:	e8 0e d1 ff ff       	call   3450 <__stack_chk_fail@plt>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_p_ad_push.constprop.0>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	49 89 d5             	mov    %rdx,%r13
    6359:	41 54                	push   %r12
    635b:	49 89 fc             	mov    %rdi,%r12
    635e:	55                   	push   %rbp
    635f:	53                   	push   %rbx
    6360:	48 83 ec 38          	sub    $0x38,%rsp
    6364:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6369:	48 85 ff             	test   %rdi,%rdi
    636c:	79 09                	jns    6377 <fwp_p_ad_push.constprop.0+0x27>
    636e:	48 85 d2             	test   %rdx,%rdx
    6371:	0f 88 a9 01 00 00    	js     6520 <fwp_p_ad_push.constprop.0+0x1d0>
    6377:	48 89 f8             	mov    %rdi,%rax
    637a:	48 89 0c 24          	mov    %rcx,(%rsp)
    637e:	48 09 d0             	or     %rdx,%rax
    6381:	0f 89 79 01 00 00    	jns    6500 <fwp_p_ad_push.constprop.0+0x1b0>
    6387:	48 89 f8             	mov    %rdi,%rax
    638a:	48 c1 f8 20          	sar    $0x20,%rax
    638e:	48 85 ff             	test   %rdi,%rdi
    6391:	79 24                	jns    63b7 <fwp_p_ad_push.constprop.0+0x67>
    6393:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6398:	48 89 d0             	mov    %rdx,%rax
    639b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    63a2:	00 
    63a3:	49 89 d4             	mov    %rdx,%r12
    63a6:	48 c1 f8 20          	sar    $0x20,%rax
    63aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    63b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63b7:	48 89 c7             	mov    %rax,%rdi
    63ba:	e8 71 e3 ff ff       	call   4730 <fwp_tape_of>
    63bf:	48 89 c3             	mov    %rax,%rbx
    63c2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63c7:	0f 85 f7 02 00 00    	jne    66c4 <fwp_p_ad_push.constprop.0+0x374>
    63cd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    63d1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63d8:	0f 8f 49 02 00 00    	jg     6627 <fwp_p_ad_push.constprop.0+0x2d7>
    63de:	44 89 e0             	mov    %r12d,%eax
    63e1:	49 39 c7             	cmp    %rax,%r15
    63e4:	0f 8e 49 02 00 00    	jle    6633 <fwp_p_ad_push.constprop.0+0x2e3>
    63ea:	4d 85 ed             	test   %r13,%r13
    63ed:	78 0c                	js     63fb <fwp_p_ad_push.constprop.0+0xab>
    63ef:	44 89 e8             	mov    %r13d,%eax
    63f2:	49 39 c7             	cmp    %rax,%r15
    63f5:	0f 8e 38 02 00 00    	jle    6633 <fwp_p_ad_push.constprop.0+0x2e3>
    63fb:	4d 89 fe             	mov    %r15,%r14
    63fe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6402:	49 8d 46 01          	lea    0x1(%r14),%rax
    6406:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    640c:	0f 87 15 02 00 00    	ja     6627 <fwp_p_ad_push.constprop.0+0x2d7>
    6412:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6416:	48 39 e8             	cmp    %rbp,%rax
    6419:	0f 8e 31 01 00 00    	jle    6550 <fwp_p_ad_push.constprop.0+0x200>
    641f:	48 85 ed             	test   %rbp,%rbp
    6422:	ba 40 00 00 00       	mov    $0x40,%edx
    6427:	48 0f 44 ea          	cmove  %rdx,%rbp
    642b:	48 39 e8             	cmp    %rbp,%rax
    642e:	7e 20                	jle    6450 <fwp_p_ad_push.constprop.0+0x100>
    6430:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6437:	0f 8f 03 01 00 00    	jg     6540 <fwp_p_ad_push.constprop.0+0x1f0>
    643d:	48 01 ed             	add    %rbp,%rbp
    6440:	48 39 e8             	cmp    %rbp,%rax
    6443:	7f eb                	jg     6430 <fwp_p_ad_push.constprop.0+0xe0>
    6445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    644c:	00 00 00 00 
    6450:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6457:	00 
    6458:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    645c:	ba 01 00 00 00       	mov    $0x1,%edx
    6461:	48 89 c6             	mov    %rax,%rsi
    6464:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6469:	e8 22 ed ff ff       	call   5190 <ad_raw_realloc>
    646e:	48 85 c0             	test   %rax,%rax
    6471:	0f 84 c8 01 00 00    	je     663f <fwp_p_ad_push.constprop.0+0x2ef>
    6477:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    647b:	48 89 e9             	mov    %rbp,%rcx
    647e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6482:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6486:	48 c1 e1 04          	shl    $0x4,%rcx
    648a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    648e:	48 89 ce             	mov    %rcx,%rsi
    6491:	ba 02 00 00 00       	mov    $0x2,%edx
    6496:	48 89 43 28          	mov    %rax,0x28(%rbx)
    649a:	e8 f1 ec ff ff       	call   5190 <ad_raw_realloc>
    649f:	48 85 c0             	test   %rax,%rax
    64a2:	0f 84 97 01 00 00    	je     663f <fwp_p_ad_push.constprop.0+0x2ef>
    64a8:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64ac:	48 89 43 30          	mov    %rax,0x30(%rbx)
    64b0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    64b7:	00 
    64b8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64bf:	00 
    64c0:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    64c7:	00 
    64c8:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64cc:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64d1:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    64d5:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    64d9:	4d 85 f6             	test   %r14,%r14
    64dc:	0f 85 e6 00 00 00    	jne    65c8 <fwp_p_ad_push.constprop.0+0x278>
    64e2:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    64e6:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64ea:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    64ee:	48 01 d1             	add    %rdx,%rcx
    64f1:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    64f5:	eb 79                	jmp    6570 <fwp_p_ad_push.constprop.0+0x220>
    64f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    64fe:	00 00 
    6500:	48 89 d0             	mov    %rdx,%rax
    6503:	48 c1 ff 20          	sar    $0x20,%rdi
    6507:	48 c1 f8 20          	sar    $0x20,%rax
    650b:	48 39 c7             	cmp    %rax,%rdi
    650e:	0f 84 a3 fe ff ff    	je     63b7 <fwp_p_ad_push.constprop.0+0x67>
    6514:	48 8d 3d ed a4 00 00 	lea    0xa4ed(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    651b:	e8 30 df ff ff       	call   4450 <fwp_trap>
    6520:	48 83 c4 38          	add    $0x38,%rsp
    6524:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652b:	5b                   	pop    %rbx
    652c:	5d                   	pop    %rbp
    652d:	41 5c                	pop    %r12
    652f:	41 5d                	pop    %r13
    6531:	41 5e                	pop    %r14
    6533:	41 5f                	pop    %r15
    6535:	c3                   	ret
    6536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    653d:	00 00 00 
    6540:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6545:	e9 06 ff ff ff       	jmp    6450 <fwp_p_ad_push.constprop.0+0x100>
    654a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6550:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6554:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6558:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    655f:	00 
    6560:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6567:	00 
    6568:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    656c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6570:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6576:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    657a:	4d 85 ed             	test   %r13,%r13
    657d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6582:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6588:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    658f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6593:	49 8d 47 01          	lea    0x1(%r15),%rax
    6597:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    659b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    65a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65a5:	48 83 c4 38          	add    $0x38,%rsp
    65a9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65b0:	ff ff ff 
    65b3:	4c 21 e0             	and    %r12,%rax
    65b6:	5b                   	pop    %rbx
    65b7:	5d                   	pop    %rbp
    65b8:	4c 09 f8             	or     %r15,%rax
    65bb:	41 5c                	pop    %r12
    65bd:	41 5d                	pop    %r13
    65bf:	41 5e                	pop    %r14
    65c1:	41 5f                	pop    %r15
    65c3:	c3                   	ret
    65c4:	0f 1f 40 00          	nopl   0x0(%rax)
    65c8:	4c 89 ca             	mov    %r9,%rdx
    65cb:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    65d0:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    65d5:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    65da:	e8 11 d0 ff ff       	call   35f0 <memmove@plt>
    65df:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    65e4:	4c 03 73 30          	add    0x30(%rbx),%r14
    65e8:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    65ed:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    65f1:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    65f5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    65fa:	48 03 7b 20          	add    0x20(%rbx),%rdi
    65fe:	4c 89 d2             	mov    %r10,%rdx
    6601:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6606:	e8 e5 cf ff ff       	call   35f0 <memmove@plt>
    660b:	48 8b 43 30          	mov    0x30(%rbx),%rax
    660f:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6613:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6618:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    661d:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6622:	e9 bf fe ff ff       	jmp    64e6 <fwp_p_ad_push.constprop.0+0x196>
    6627:	48 8d 3d 79 9b 00 00 	lea    0x9b79(%rip),%rdi        # 101a7 <_IO_stdin_used+0x1a7>
    662e:	e8 1d de ff ff       	call   4450 <fwp_trap>
    6633:	48 8d 3d 88 9b 00 00 	lea    0x9b88(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    663a:	e8 11 de ff ff       	call   4450 <fwp_trap>
    663f:	48 89 df             	mov    %rbx,%rdi
    6642:	e8 49 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6647:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    664b:	48 85 ff             	test   %rdi,%rdi
    664e:	74 05                	je     6655 <fwp_p_ad_push.constprop.0+0x305>
    6650:	e8 7b ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6655:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6659:	48 85 ff             	test   %rdi,%rdi
    665c:	74 05                	je     6663 <fwp_p_ad_push.constprop.0+0x313>
    665e:	e8 6d ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6663:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6667:	48 85 ff             	test   %rdi,%rdi
    666a:	74 05                	je     6671 <fwp_p_ad_push.constprop.0+0x321>
    666c:	e8 5f ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6671:	31 c9                	xor    %ecx,%ecx
    6673:	31 c0                	xor    %eax,%eax
    6675:	31 d2                	xor    %edx,%edx
    6677:	be 01 00 00 00       	mov    $0x1,%esi
    667c:	89 53 04             	mov    %edx,0x4(%rbx)
    667f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6683:	ba 13 00 00 00       	mov    $0x13,%edx
    6688:	48 8d 3d 79 99 00 00 	lea    0x9979(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    668f:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6693:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6697:	48 8b 0d c2 d9 00 00 	mov    0xd9c2(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    669e:	48 89 43 40          	mov    %rax,0x40(%rbx)
    66a2:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    66a6:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    66aa:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    66ae:	e8 ad cf ff ff       	call   3660 <fwrite@plt>
    66b3:	31 ff                	xor    %edi,%edi
    66b5:	e8 e6 ce ff ff       	call   35a0 <fflush@plt>
    66ba:	bf 66 00 00 00       	mov    $0x66,%edi
    66bf:	e8 bc cf ff ff       	call   3680 <_Exit@plt>
    66c4:	48 8d 3d 85 a3 00 00 	lea    0xa385(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    66cb:	e8 80 dd ff ff       	call   4450 <fwp_trap>

00000000000066d0 <w107>:
    66d0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    66d4:	41 55                	push   %r13
    66d6:	48 89 fa             	mov    %rdi,%rdx
    66d9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    66dd:	41 54                	push   %r12
    66df:	49 89 fc             	mov    %rdi,%r12
    66e2:	55                   	push   %rbp
    66e3:	53                   	push   %rbx
    66e4:	48 89 f3             	mov    %rsi,%rbx
    66e7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    66ec:	48 89 f1             	mov    %rsi,%rcx
    66ef:	48 83 ec 28          	sub    $0x28,%rsp
    66f3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    66f9:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66ff:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6705:	e8 46 fc ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    670a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6710:	48 89 da             	mov    %rbx,%rdx
    6713:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6719:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6720:	00 f0 3f 
    6723:	48 89 c7             	mov    %rax,%rdi
    6726:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    672d:	00 f0 bf 
    6730:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6735:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    673b:	e8 10 fc ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    6740:	f2 0f 10 05 98 a6 00 	movsd  0xa698(%rip),%xmm0        # 10de0 <msg.4+0xb0>
    6747:	00 
    6748:	4c 89 e7             	mov    %r12,%rdi
    674b:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6751:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6758:	00 f0 3f 
    675b:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6762:	49 89 c5             	mov    %rax,%r13
    6765:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    676c:	00 f0 bf 
    676f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6774:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    677a:	e8 d1 fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    677f:	48 89 e9             	mov    %rbp,%rcx
    6782:	4c 89 ea             	mov    %r13,%rdx
    6785:	48 89 ee             	mov    %rbp,%rsi
    6788:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    678e:	4c 89 ef             	mov    %r13,%rdi
    6791:	49 89 c4             	mov    %rax,%r12
    6794:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6798:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    679e:	e8 ad fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    67a3:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67a9:	f2 0f 59 1d 37 a6 00 	mulsd  0xa637(%rip),%xmm3        # 10de8 <msg.4+0xb8>
    67b0:	00 
    67b1:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    67b8:	00 59 40 
    67bb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67c0:	48 89 c2             	mov    %rax,%rdx
    67c3:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67ca:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    67d0:	e8 7b fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    67d5:	48 89 d9             	mov    %rbx,%rcx
    67d8:	4c 89 e2             	mov    %r12,%rdx
    67db:	48 89 de             	mov    %rbx,%rsi
    67de:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    67e4:	4c 89 e7             	mov    %r12,%rdi
    67e7:	48 89 c5             	mov    %rax,%rbp
    67ea:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    67ee:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    67f4:	e8 57 fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    67f9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67ff:	48 89 ea             	mov    %rbp,%rdx
    6802:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6808:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    680f:	00 f0 3f 
    6812:	48 89 c7             	mov    %rax,%rdi
    6815:	48 89 ce             	mov    %rcx,%rsi
    6818:	66 48 0f 7e db       	movq   %xmm3,%rbx
    681d:	e8 2e fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    6822:	48 83 c4 28          	add    $0x28,%rsp
    6826:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    682b:	5b                   	pop    %rbx
    682c:	5d                   	pop    %rbp
    682d:	41 5c                	pop    %r12
    682f:	41 5d                	pop    %r13
    6831:	c3                   	ret
    6832:	0f 1f 00             	nopl   (%rax)
    6835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    683c:	00 00 00 00 

0000000000006840 <w164.constprop.0>:
    6840:	41 54                	push   %r12
    6842:	55                   	push   %rbp
    6843:	53                   	push   %rbx
    6844:	48 83 ec 10          	sub    $0x10,%rsp
    6848:	4c 8b 27             	mov    (%rdi),%r12
    684b:	4d 85 e4             	test   %r12,%r12
    684e:	74 58                	je     68a8 <w164.constprop.0+0x68>
    6850:	48 89 fd             	mov    %rdi,%rbp
    6853:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6857:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    685e:	31 db                	xor    %ebx,%ebx
    6860:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6866:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    686b:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6872:	00 f0 3f 
    6875:	48 83 c3 02          	add    $0x2,%rbx
    6879:	48 89 ce             	mov    %rcx,%rsi
    687c:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6882:	e8 c9 fa ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    6887:	4c 39 e3             	cmp    %r12,%rbx
    688a:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6890:	48 89 c7             	mov    %rax,%rdi
    6893:	72 cb                	jb     6860 <w164.constprop.0+0x20>
    6895:	48 83 c4 10          	add    $0x10,%rsp
    6899:	48 89 f8             	mov    %rdi,%rax
    689c:	5b                   	pop    %rbx
    689d:	5d                   	pop    %rbp
    689e:	41 5c                	pop    %r12
    68a0:	c3                   	ret
    68a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68a8:	48 83 c4 10          	add    $0x10,%rsp
    68ac:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    68b3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    68b7:	5b                   	pop    %rbx
    68b8:	48 89 f8             	mov    %rdi,%rax
    68bb:	5d                   	pop    %rbp
    68bc:	41 5c                	pop    %r12
    68be:	c3                   	ret
    68bf:	90                   	nop

00000000000068c0 <fwp_data.part.0.constprop.0>:
    68c0:	41 56                	push   %r14
    68c2:	8b 05 1c 73 06 00    	mov    0x6731c(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    68c8:	41 89 fe             	mov    %edi,%r14d
    68cb:	41 55                	push   %r13
    68cd:	44 8b 2d 34 7c 06 00 	mov    0x67c34(%rip),%r13d        # 6e508 <iteration_active>
    68d4:	41 54                	push   %r12
    68d6:	49 89 f4             	mov    %rsi,%r12
    68d9:	55                   	push   %rbp
    68da:	53                   	push   %rbx
    68db:	45 85 ed             	test   %r13d,%r13d
    68de:	0f 84 1c 01 00 00    	je     6a00 <fwp_data.part.0.constprop.0+0x140>
    68e4:	48 83 05 14 7c 06 00 	addq   $0x1,0x67c14(%rip)        # 6e500 <iteration_requests>
    68eb:	01 
    68ec:	48 83 05 04 7c 06 00 	addq   $0x18,0x67c04(%rip)        # 6e4f8 <iteration_bytes>
    68f3:	18 
    68f4:	85 c0                	test   %eax,%eax
    68f6:	0f 84 8c 01 00 00    	je     6a88 <fwp_data.part.0.constprop.0+0x1c8>
    68fc:	0f b6 05 df 6e 06 00 	movzbl 0x66edf(%rip),%eax        # 6d7e2 <fwp_heap+0xfa2>
    6903:	48 8d 15 36 5f 06 00 	lea    0x65f36(%rip),%rdx        # 6c840 <fwp_heap>
    690a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6911:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6915:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6919:	48 8b 18             	mov    (%rax),%rbx
    691c:	48 85 db             	test   %rbx,%rbx
    691f:	0f 84 fb 00 00 00    	je     6a20 <fwp_data.part.0.constprop.0+0x160>
    6925:	48 8b 13             	mov    (%rbx),%rdx
    6928:	48 f7 d2             	not    %rdx
    692b:	48 89 10             	mov    %rdx,(%rax)
    692e:	48 83 fd 18          	cmp    $0x18,%rbp
    6932:	76 1b                	jbe    694f <fwp_data.part.0.constprop.0+0x8f>
    6934:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6938:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    693c:	31 f6                	xor    %esi,%esi
    693e:	48 c1 e8 03          	shr    $0x3,%rax
    6942:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6949:	00 
    694a:	e8 61 cb ff ff       	call   34b0 <memset@plt>
    694f:	48 89 e8             	mov    %rbp,%rax
    6952:	48 03 05 07 73 06 00 	add    0x67307(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    6959:	0f 82 3d 01 00 00    	jb     6a9c <fwp_data.part.0.constprop.0+0x1dc>
    695f:	48 39 05 02 73 06 00 	cmp    %rax,0x67302(%rip)        # 6dc68 <fwp_heap+0x1428>
    6966:	48 89 05 f3 72 06 00 	mov    %rax,0x672f3(%rip)        # 6dc60 <fwp_heap+0x1420>
    696d:	73 07                	jae    6976 <fwp_data.part.0.constprop.0+0xb6>
    696f:	48 89 05 f2 72 06 00 	mov    %rax,0x672f2(%rip)        # 6dc68 <fwp_heap+0x1428>
    6976:	66 0f ef c0          	pxor   %xmm0,%xmm0
    697a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    697f:	f2 0f 58 05 f1 72 06 	addsd  0x672f1(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    6986:	00 
    6987:	f2 0f 11 05 e9 72 06 	movsd  %xmm0,0x672e9(%rip)        # 6dc78 <fwp_heap+0x1438>
    698e:	00 
    698f:	45 85 ed             	test   %r13d,%r13d
    6992:	74 33                	je     69c7 <fwp_data.part.0.constprop.0+0x107>
    6994:	48 8b 05 c5 72 06 00 	mov    0x672c5(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    699b:	48 85 c0             	test   %rax,%rax
    699e:	0f 88 a4 00 00 00    	js     6a48 <fwp_data.part.0.constprop.0+0x188>
    69a4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69a8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    69ad:	f2 0f 5c 05 33 7b 06 	subsd  0x67b33(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    69b4:	00 
    69b5:	66 0f 2f 05 23 7b 06 	comisd 0x67b23(%rip),%xmm0        # 6e4e0 <iteration_peak>
    69bc:	00 
    69bd:	76 08                	jbe    69c7 <fwp_data.part.0.constprop.0+0x107>
    69bf:	f2 0f 11 05 19 7b 06 	movsd  %xmm0,0x67b19(%rip)        # 6e4e0 <iteration_peak>
    69c6:	00 
    69c7:	b8 02 00 00 00       	mov    $0x2,%eax
    69cc:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    69d1:	66 0f 6e c8          	movd   %eax,%xmm1
    69d5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    69d9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    69dd:	49 8b 04 24          	mov    (%r12),%rax
    69e1:	48 89 43 08          	mov    %rax,0x8(%rbx)
    69e5:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    69ea:	48 89 43 10          	mov    %rax,0x10(%rbx)
    69ee:	48 89 d8             	mov    %rbx,%rax
    69f1:	5b                   	pop    %rbx
    69f2:	5d                   	pop    %rbp
    69f3:	41 5c                	pop    %r12
    69f5:	41 5d                	pop    %r13
    69f7:	41 5e                	pop    %r14
    69f9:	c3                   	ret
    69fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a00:	85 c0                	test   %eax,%eax
    6a02:	0f 85 f4 fe ff ff    	jne    68fc <fwp_data.part.0.constprop.0+0x3c>
    6a08:	31 f6                	xor    %esi,%esi
    6a0a:	bf 18 00 00 00       	mov    $0x18,%edi
    6a0f:	e8 fc f4 ff ff       	call   5f10 <fwp_heap_alloc>
    6a14:	48 89 c3             	mov    %rax,%rbx
    6a17:	eb ae                	jmp    69c7 <fwp_data.part.0.constprop.0+0x107>
    6a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a20:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6a24:	48 85 db             	test   %rbx,%rbx
    6a27:	74 47                	je     6a70 <fwp_data.part.0.constprop.0+0x1b0>
    6a29:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6a2d:	48 29 da             	sub    %rbx,%rdx
    6a30:	48 39 ea             	cmp    %rbp,%rdx
    6a33:	72 3b                	jb     6a70 <fwp_data.part.0.constprop.0+0x1b0>
    6a35:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6a39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6a3d:	e9 ec fe ff ff       	jmp    692e <fwp_data.part.0.constprop.0+0x6e>
    6a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a48:	48 89 c2             	mov    %rax,%rdx
    6a4b:	83 e0 01             	and    $0x1,%eax
    6a4e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a52:	48 d1 ea             	shr    $1,%rdx
    6a55:	48 09 c2             	or     %rax,%rdx
    6a58:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    6a5d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6a61:	e9 47 ff ff ff       	jmp    69ad <fwp_data.part.0.constprop.0+0xed>
    6a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a6d:	00 00 00 
    6a70:	31 f6                	xor    %esi,%esi
    6a72:	bf 18 00 00 00       	mov    $0x18,%edi
    6a77:	e8 94 f4 ff ff       	call   5f10 <fwp_heap_alloc>
    6a7c:	48 89 c3             	mov    %rax,%rbx
    6a7f:	e9 0b ff ff ff       	jmp    698f <fwp_data.part.0.constprop.0+0xcf>
    6a84:	0f 1f 40 00          	nopl   0x0(%rax)
    6a88:	31 f6                	xor    %esi,%esi
    6a8a:	bf 18 00 00 00       	mov    $0x18,%edi
    6a8f:	e8 7c f4 ff ff       	call   5f10 <fwp_heap_alloc>
    6a94:	48 89 c3             	mov    %rax,%rbx
    6a97:	e9 f8 fe ff ff       	jmp    6994 <fwp_data.part.0.constprop.0+0xd4>
    6a9c:	e8 8f d3 ff ff       	call   3e30 <fwp_heap_oom>
    6aa1:	0f 1f 40 00          	nopl   0x0(%rax)
    6aa5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6aac:	00 00 00 00 

0000000000006ab0 <fwp_rc_share>:
    6ab0:	48 8b 05 61 71 06 00 	mov    0x67161(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    6ab7:	48 2b 3d 32 71 06 00 	sub    0x67132(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    6abe:	48 c1 e0 10          	shl    $0x10,%rax
    6ac2:	48 39 c7             	cmp    %rax,%rdi
    6ac5:	73 4a                	jae    6b11 <fwp_rc_share+0x61>
    6ac7:	48 89 f8             	mov    %rdi,%rax
    6aca:	48 c1 e8 10          	shr    $0x10,%rax
    6ace:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6ad2:	48 8b 05 5f 71 06 00 	mov    0x6715f(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    6ad9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6add:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6ae1:	48 85 d2             	test   %rdx,%rdx
    6ae4:	74 2b                	je     6b11 <fwp_rc_share+0x61>
    6ae6:	0f b6 08             	movzbl (%rax),%ecx
    6ae9:	80 f9 02             	cmp    $0x2,%cl
    6aec:	74 2a                	je     6b18 <fwp_rc_share+0x68>
    6aee:	80 f9 01             	cmp    $0x1,%cl
    6af1:	75 1e                	jne    6b11 <fwp_rc_share+0x61>
    6af3:	8b 48 18             	mov    0x18(%rax),%ecx
    6af6:	0f b7 ff             	movzwl %di,%edi
    6af9:	8b 40 1c             	mov    0x1c(%rax),%eax
    6afc:	48 0f af f9          	imul   %rcx,%rdi
    6b00:	48 c1 ef 20          	shr    $0x20,%rdi
    6b04:	48 39 c7             	cmp    %rax,%rdi
    6b07:	73 08                	jae    6b11 <fwp_rc_share+0x61>
    6b09:	48 01 fa             	add    %rdi,%rdx
    6b0c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6b0f:	75 0d                	jne    6b1e <fwp_rc_share+0x6e>
    6b11:	c3                   	ret
    6b12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b18:	66 85 ff             	test   %di,%di
    6b1b:	74 ef                	je     6b0c <fwp_rc_share+0x5c>
    6b1d:	c3                   	ret
    6b1e:	50                   	push   %rax
    6b1f:	48 8d 3d 5a 9f 00 00 	lea    0x9f5a(%rip),%rdi        # 10a80 <_IO_stdin_used+0xa80>
    6b26:	e8 25 d9 ff ff       	call   4450 <fwp_trap>
    6b2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006b30 <fwp_rc_fresh>:
    6b30:	48 8b 15 e1 70 06 00 	mov    0x670e1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6b37:	48 89 f8             	mov    %rdi,%rax
    6b3a:	48 89 fe             	mov    %rdi,%rsi
    6b3d:	48 2b 05 ac 70 06 00 	sub    0x670ac(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6b44:	48 c1 e2 10          	shl    $0x10,%rdx
    6b48:	48 39 d0             	cmp    %rdx,%rax
    6b4b:	73 4f                	jae    6b9c <fwp_rc_fresh+0x6c>
    6b4d:	48 89 c2             	mov    %rax,%rdx
    6b50:	48 c1 ea 10          	shr    $0x10,%rdx
    6b54:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b58:	48 8b 15 d9 70 06 00 	mov    0x670d9(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6b5f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b63:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b67:	48 85 d2             	test   %rdx,%rdx
    6b6a:	74 30                	je     6b9c <fwp_rc_fresh+0x6c>
    6b6c:	0f b6 39             	movzbl (%rcx),%edi
    6b6f:	40 80 ff 02          	cmp    $0x2,%dil
    6b73:	74 2b                	je     6ba0 <fwp_rc_fresh+0x70>
    6b75:	40 80 ff 01          	cmp    $0x1,%dil
    6b79:	75 21                	jne    6b9c <fwp_rc_fresh+0x6c>
    6b7b:	8b 79 18             	mov    0x18(%rcx),%edi
    6b7e:	0f b7 c0             	movzwl %ax,%eax
    6b81:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b84:	48 0f af c7          	imul   %rdi,%rax
    6b88:	48 c1 e8 20          	shr    $0x20,%rax
    6b8c:	48 39 c8             	cmp    %rcx,%rax
    6b8f:	73 0b                	jae    6b9c <fwp_rc_fresh+0x6c>
    6b91:	48 01 c2             	add    %rax,%rdx
    6b94:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b97:	74 17                	je     6bb0 <fwp_rc_fresh+0x80>
    6b99:	c6 02 01             	movb   $0x1,(%rdx)
    6b9c:	48 89 f0             	mov    %rsi,%rax
    6b9f:	c3                   	ret
    6ba0:	66 85 c0             	test   %ax,%ax
    6ba3:	74 ef                	je     6b94 <fwp_rc_fresh+0x64>
    6ba5:	48 89 f0             	mov    %rsi,%rax
    6ba8:	c3                   	ret
    6ba9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bb0:	48 83 ec 18          	sub    $0x18,%rsp
    6bb4:	48 89 d7             	mov    %rdx,%rdi
    6bb7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6bbc:	48 89 14 24          	mov    %rdx,(%rsp)
    6bc0:	e8 0b ec ff ff       	call   57d0 <fwp_rc_forget_slot>
    6bc5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6bca:	48 8b 14 24          	mov    (%rsp),%rdx
    6bce:	48 89 f0             	mov    %rsi,%rax
    6bd1:	c6 02 01             	movb   $0x1,(%rdx)
    6bd4:	48 83 c4 18          	add    $0x18,%rsp
    6bd8:	c3                   	ret
    6bd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006be0 <fwp_rc_free_arr>:
    6be0:	48 8b 15 31 70 06 00 	mov    0x67031(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6be7:	48 89 f8             	mov    %rdi,%rax
    6bea:	48 2b 05 ff 6f 06 00 	sub    0x66fff(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6bf1:	48 c1 e2 10          	shl    $0x10,%rdx
    6bf5:	48 39 d0             	cmp    %rdx,%rax
    6bf8:	73 5b                	jae    6c55 <fwp_rc_free_arr+0x75>
    6bfa:	48 89 c2             	mov    %rax,%rdx
    6bfd:	48 c1 ea 10          	shr    $0x10,%rdx
    6c01:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c05:	48 8b 15 2c 70 06 00 	mov    0x6702c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6c0c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6c10:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6c14:	48 85 c9             	test   %rcx,%rcx
    6c17:	74 3c                	je     6c55 <fwp_rc_free_arr+0x75>
    6c19:	0f b6 32             	movzbl (%rdx),%esi
    6c1c:	40 80 fe 02          	cmp    $0x2,%sil
    6c20:	74 2e                	je     6c50 <fwp_rc_free_arr+0x70>
    6c22:	40 80 fe 01          	cmp    $0x1,%sil
    6c26:	75 2d                	jne    6c55 <fwp_rc_free_arr+0x75>
    6c28:	8b 72 18             	mov    0x18(%rdx),%esi
    6c2b:	0f b7 c0             	movzwl %ax,%eax
    6c2e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c31:	48 0f af c6          	imul   %rsi,%rax
    6c35:	48 c1 e8 20          	shr    $0x20,%rax
    6c39:	48 39 d0             	cmp    %rdx,%rax
    6c3c:	73 17                	jae    6c55 <fwp_rc_free_arr+0x75>
    6c3e:	48 01 c1             	add    %rax,%rcx
    6c41:	80 39 01             	cmpb   $0x1,(%rcx)
    6c44:	75 0f                	jne    6c55 <fwp_rc_free_arr+0x75>
    6c46:	e9 c5 ed ff ff       	jmp    5a10 <fwp_mem_free>
    6c4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c50:	66 85 c0             	test   %ax,%ax
    6c53:	74 ec                	je     6c41 <fwp_rc_free_arr+0x61>
    6c55:	c3                   	ret
    6c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c5d:	00 00 00 

0000000000006c60 <fwp_rc_dup>:
    6c60:	f3 0f 1e fa          	endbr64
    6c64:	48 8b 05 ad 6f 06 00 	mov    0x66fad(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    6c6b:	48 2b 3d 7e 6f 06 00 	sub    0x66f7e(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    6c72:	48 c1 e0 10          	shl    $0x10,%rax
    6c76:	48 39 c7             	cmp    %rax,%rdi
    6c79:	73 60                	jae    6cdb <fwp_rc_dup+0x7b>
    6c7b:	48 89 f8             	mov    %rdi,%rax
    6c7e:	48 c1 e8 10          	shr    $0x10,%rax
    6c82:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6c86:	48 8b 05 ab 6f 06 00 	mov    0x66fab(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    6c8d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6c91:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6c95:	48 85 c0             	test   %rax,%rax
    6c98:	74 41                	je     6cdb <fwp_rc_dup+0x7b>
    6c9a:	0f b6 0a             	movzbl (%rdx),%ecx
    6c9d:	80 f9 02             	cmp    $0x2,%cl
    6ca0:	74 3e                	je     6ce0 <fwp_rc_dup+0x80>
    6ca2:	80 f9 01             	cmp    $0x1,%cl
    6ca5:	75 34                	jne    6cdb <fwp_rc_dup+0x7b>
    6ca7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6caa:	0f b7 ff             	movzwl %di,%edi
    6cad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6cb0:	48 0f af f9          	imul   %rcx,%rdi
    6cb4:	48 c1 ef 20          	shr    $0x20,%rdi
    6cb8:	48 39 d7             	cmp    %rdx,%rdi
    6cbb:	73 1e                	jae    6cdb <fwp_rc_dup+0x7b>
    6cbd:	48 01 f8             	add    %rdi,%rax
    6cc0:	0f b6 10             	movzbl (%rax),%edx
    6cc3:	84 d2                	test   %dl,%dl
    6cc5:	74 14                	je     6cdb <fwp_rc_dup+0x7b>
    6cc7:	8b 0d 3b 78 06 00    	mov    0x6783b(%rip),%ecx        # 6e508 <iteration_active>
    6ccd:	85 c9                	test   %ecx,%ecx
    6ccf:	75 1f                	jne    6cf0 <fwp_rc_dup+0x90>
    6cd1:	80 fa fd             	cmp    $0xfd,%dl
    6cd4:	77 2a                	ja     6d00 <fwp_rc_dup+0xa0>
    6cd6:	83 c2 01             	add    $0x1,%edx
    6cd9:	88 10                	mov    %dl,(%rax)
    6cdb:	c3                   	ret
    6cdc:	0f 1f 40 00          	nopl   0x0(%rax)
    6ce0:	66 85 ff             	test   %di,%di
    6ce3:	74 db                	je     6cc0 <fwp_rc_dup+0x60>
    6ce5:	c3                   	ret
    6ce6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ced:	00 00 00 
    6cf0:	48 83 05 f8 77 06 00 	addq   $0x1,0x677f8(%rip)        # 6e4f0 <iteration_retains>
    6cf7:	01 
    6cf8:	eb d7                	jmp    6cd1 <fwp_rc_dup+0x71>
    6cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d00:	48 89 c7             	mov    %rax,%rdi
    6d03:	e9 a8 e9 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6d08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d0f:	00 

0000000000006d10 <fwp_owned_entry161>:
    6d10:	f3 0f 1e fa          	endbr64
    6d14:	48 83 ec 38          	sub    $0x38,%rsp
    6d18:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6d1d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6d24:	00 00 
    6d26:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6d2b:	31 c0                	xor    %eax,%eax
    6d2d:	48 8b 07             	mov    (%rdi),%rax
    6d30:	48 03 47 10          	add    0x10(%rdi),%rax
    6d34:	0f 80 c2 00 00 00    	jo     6dfc <fwp_owned_entry161+0xec>
    6d3a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6d3f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6d44:	31 ff                	xor    %edi,%edi
    6d46:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6d4a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6d4f:	e8 6c fb ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    6d54:	48 8b 15 bd 6e 06 00 	mov    0x66ebd(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6d5b:	48 89 c6             	mov    %rax,%rsi
    6d5e:	48 2b 05 8b 6e 06 00 	sub    0x66e8b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6d65:	48 c1 e2 10          	shl    $0x10,%rdx
    6d69:	48 39 d0             	cmp    %rdx,%rax
    6d6c:	73 4f                	jae    6dbd <fwp_owned_entry161+0xad>
    6d6e:	48 89 c2             	mov    %rax,%rdx
    6d71:	48 c1 ea 10          	shr    $0x10,%rdx
    6d75:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d79:	48 8b 15 b8 6e 06 00 	mov    0x66eb8(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6d80:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d84:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d88:	48 85 d2             	test   %rdx,%rdx
    6d8b:	74 30                	je     6dbd <fwp_owned_entry161+0xad>
    6d8d:	0f b6 39             	movzbl (%rcx),%edi
    6d90:	40 80 ff 02          	cmp    $0x2,%dil
    6d94:	74 42                	je     6dd8 <fwp_owned_entry161+0xc8>
    6d96:	40 80 ff 01          	cmp    $0x1,%dil
    6d9a:	75 21                	jne    6dbd <fwp_owned_entry161+0xad>
    6d9c:	8b 79 18             	mov    0x18(%rcx),%edi
    6d9f:	0f b7 c0             	movzwl %ax,%eax
    6da2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6da5:	48 0f af c7          	imul   %rdi,%rax
    6da9:	48 c1 e8 20          	shr    $0x20,%rax
    6dad:	48 39 c8             	cmp    %rcx,%rax
    6db0:	73 0b                	jae    6dbd <fwp_owned_entry161+0xad>
    6db2:	48 01 c2             	add    %rax,%rdx
    6db5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6db8:	74 26                	je     6de0 <fwp_owned_entry161+0xd0>
    6dba:	c6 02 01             	movb   $0x1,(%rdx)
    6dbd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6dc2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6dc9:	00 00 
    6dcb:	75 34                	jne    6e01 <fwp_owned_entry161+0xf1>
    6dcd:	48 89 f0             	mov    %rsi,%rax
    6dd0:	48 83 c4 38          	add    $0x38,%rsp
    6dd4:	c3                   	ret
    6dd5:	0f 1f 00             	nopl   (%rax)
    6dd8:	66 85 c0             	test   %ax,%ax
    6ddb:	75 e0                	jne    6dbd <fwp_owned_entry161+0xad>
    6ddd:	eb d6                	jmp    6db5 <fwp_owned_entry161+0xa5>
    6ddf:	90                   	nop
    6de0:	48 89 d7             	mov    %rdx,%rdi
    6de3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6de8:	48 89 14 24          	mov    %rdx,(%rsp)
    6dec:	e8 df e9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6df1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6df6:	48 8b 14 24          	mov    (%rsp),%rdx
    6dfa:	eb be                	jmp    6dba <fwp_owned_entry161+0xaa>
    6dfc:	e8 ff c8 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6e01:	e8 4a c6 ff ff       	call   3450 <__stack_chk_fail@plt>
    6e06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e0d:	00 00 00 

0000000000006e10 <e161>:
    6e10:	f3 0f 1e fa          	endbr64
    6e14:	53                   	push   %rbx
    6e15:	48 83 ec 30          	sub    $0x30,%rsp
    6e19:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6e1e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6e25:	00 00 
    6e27:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6e2c:	31 c0                	xor    %eax,%eax
    6e2e:	48 8b 07             	mov    (%rdi),%rax
    6e31:	48 03 47 10          	add    0x10(%rdi),%rax
    6e35:	0f 80 c9 00 00 00    	jo     6f04 <e161+0xf4>
    6e3b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6e40:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6e45:	31 ff                	xor    %edi,%edi
    6e47:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6e4b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6e50:	e8 6b fa ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    6e55:	48 8b 15 bc 6d 06 00 	mov    0x66dbc(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6e5c:	48 89 c3             	mov    %rax,%rbx
    6e5f:	48 2b 05 8a 6d 06 00 	sub    0x66d8a(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6e66:	48 c1 e2 10          	shl    $0x10,%rdx
    6e6a:	48 39 d0             	cmp    %rdx,%rax
    6e6d:	73 4f                	jae    6ebe <e161+0xae>
    6e6f:	48 89 c2             	mov    %rax,%rdx
    6e72:	48 c1 ea 10          	shr    $0x10,%rdx
    6e76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e7a:	48 8b 15 b7 6d 06 00 	mov    0x66db7(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6e81:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e85:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e89:	48 85 d2             	test   %rdx,%rdx
    6e8c:	74 30                	je     6ebe <e161+0xae>
    6e8e:	0f b6 31             	movzbl (%rcx),%esi
    6e91:	40 80 fe 02          	cmp    $0x2,%sil
    6e95:	74 49                	je     6ee0 <e161+0xd0>
    6e97:	40 80 fe 01          	cmp    $0x1,%sil
    6e9b:	75 21                	jne    6ebe <e161+0xae>
    6e9d:	8b 71 18             	mov    0x18(%rcx),%esi
    6ea0:	0f b7 c0             	movzwl %ax,%eax
    6ea3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ea6:	48 0f af c6          	imul   %rsi,%rax
    6eaa:	48 c1 e8 20          	shr    $0x20,%rax
    6eae:	48 39 c8             	cmp    %rcx,%rax
    6eb1:	73 0b                	jae    6ebe <e161+0xae>
    6eb3:	48 01 c2             	add    %rax,%rdx
    6eb6:	80 3a ff             	cmpb   $0xff,(%rdx)
    6eb9:	74 35                	je     6ef0 <e161+0xe0>
    6ebb:	c6 02 01             	movb   $0x1,(%rdx)
    6ebe:	48 89 df             	mov    %rbx,%rdi
    6ec1:	e8 ea fb ff ff       	call   6ab0 <fwp_rc_share>
    6ec6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6ecb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ed2:	00 00 
    6ed4:	75 33                	jne    6f09 <e161+0xf9>
    6ed6:	48 83 c4 30          	add    $0x30,%rsp
    6eda:	48 89 d8             	mov    %rbx,%rax
    6edd:	5b                   	pop    %rbx
    6ede:	c3                   	ret
    6edf:	90                   	nop
    6ee0:	66 85 c0             	test   %ax,%ax
    6ee3:	75 d9                	jne    6ebe <e161+0xae>
    6ee5:	eb cf                	jmp    6eb6 <e161+0xa6>
    6ee7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6eee:	00 00 
    6ef0:	48 89 d7             	mov    %rdx,%rdi
    6ef3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ef8:	e8 d3 e8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6efd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f02:	eb b7                	jmp    6ebb <e161+0xab>
    6f04:	e8 f7 c7 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6f09:	e8 42 c5 ff ff       	call   3450 <__stack_chk_fail@plt>
    6f0e:	66 90                	xchg   %ax,%ax

0000000000006f10 <fwp_drop0>:
    6f10:	f3 0f 1e fa          	endbr64
    6f14:	48 8b 15 fd 6c 06 00 	mov    0x66cfd(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6f1b:	48 89 f8             	mov    %rdi,%rax
    6f1e:	48 2b 05 cb 6c 06 00 	sub    0x66ccb(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6f25:	48 c1 e2 10          	shl    $0x10,%rdx
    6f29:	48 39 d0             	cmp    %rdx,%rax
    6f2c:	0f 83 be 00 00 00    	jae    6ff0 <fwp_drop0+0xe0>
    6f32:	48 83 ec 18          	sub    $0x18,%rsp
    6f36:	4c 8d 05 03 59 06 00 	lea    0x65903(%rip),%r8        # 6c840 <fwp_heap>
    6f3d:	48 89 c2             	mov    %rax,%rdx
    6f40:	48 c1 ea 10          	shr    $0x10,%rdx
    6f44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f48:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6f4f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6f53:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6f57:	48 85 d2             	test   %rdx,%rdx
    6f5a:	74 3c                	je     6f98 <fwp_drop0+0x88>
    6f5c:	0f b6 31             	movzbl (%rcx),%esi
    6f5f:	40 80 fe 02          	cmp    $0x2,%sil
    6f63:	74 3b                	je     6fa0 <fwp_drop0+0x90>
    6f65:	40 80 fe 01          	cmp    $0x1,%sil
    6f69:	75 2d                	jne    6f98 <fwp_drop0+0x88>
    6f6b:	8b 71 18             	mov    0x18(%rcx),%esi
    6f6e:	0f b7 c0             	movzwl %ax,%eax
    6f71:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6f74:	48 0f af c6          	imul   %rsi,%rax
    6f78:	48 c1 e8 20          	shr    $0x20,%rax
    6f7c:	48 39 c8             	cmp    %rcx,%rax
    6f7f:	73 17                	jae    6f98 <fwp_drop0+0x88>
    6f81:	48 01 c2             	add    %rax,%rdx
    6f84:	0f b6 02             	movzbl (%rdx),%eax
    6f87:	84 c0                	test   %al,%al
    6f89:	74 0d                	je     6f98 <fwp_drop0+0x88>
    6f8b:	3c 01                	cmp    $0x1,%al
    6f8d:	74 21                	je     6fb0 <fwp_drop0+0xa0>
    6f8f:	3c ff                	cmp    $0xff,%al
    6f91:	74 65                	je     6ff8 <fwp_drop0+0xe8>
    6f93:	83 e8 01             	sub    $0x1,%eax
    6f96:	88 02                	mov    %al,(%rdx)
    6f98:	48 83 c4 18          	add    $0x18,%rsp
    6f9c:	c3                   	ret
    6f9d:	0f 1f 00             	nopl   (%rax)
    6fa0:	66 85 c0             	test   %ax,%ax
    6fa3:	74 df                	je     6f84 <fwp_drop0+0x74>
    6fa5:	48 83 c4 18          	add    $0x18,%rsp
    6fa9:	c3                   	ret
    6faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fb0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6fb4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6fb9:	e8 22 fc ff ff       	call   6be0 <fwp_rc_free_arr>
    6fbe:	4c 8d 05 7b 58 06 00 	lea    0x6587b(%rip),%r8        # 6c840 <fwp_heap>
    6fc5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6fca:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6fd1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6fd8:	48 c1 e2 10          	shl    $0x10,%rdx
    6fdc:	48 39 d0             	cmp    %rdx,%rax
    6fdf:	73 b7                	jae    6f98 <fwp_drop0+0x88>
    6fe1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6fe6:	e9 52 ff ff ff       	jmp    6f3d <fwp_drop0+0x2d>
    6feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ff0:	c3                   	ret
    6ff1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ff8:	48 89 d0             	mov    %rdx,%rax
    6ffb:	48 c1 e8 11          	shr    $0x11,%rax
    6fff:	48 31 d0             	xor    %rdx,%rax
    7002:	48 89 c1             	mov    %rax,%rcx
    7005:	48 c1 e9 09          	shr    $0x9,%rcx
    7009:	48 31 c8             	xor    %rcx,%rax
    700c:	0f b6 c8             	movzbl %al,%ecx
    700f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7016:	00 
    7017:	48 85 c0             	test   %rax,%rax
    701a:	75 0d                	jne    7029 <fwp_drop0+0x119>
    701c:	eb 46                	jmp    7064 <fwp_drop0+0x154>
    701e:	66 90                	xchg   %ax,%ax
    7020:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7024:	48 85 c0             	test   %rax,%rax
    7027:	74 3b                	je     7064 <fwp_drop0+0x154>
    7029:	48 89 c1             	mov    %rax,%rcx
    702c:	48 39 10             	cmp    %rdx,(%rax)
    702f:	75 ef                	jne    7020 <fwp_drop0+0x110>
    7031:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7035:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7039:	48 89 48 08          	mov    %rcx,0x8(%rax)
    703d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7044:	0f 85 4e ff ff ff    	jne    6f98 <fwp_drop0+0x88>
    704a:	48 89 d7             	mov    %rdx,%rdi
    704d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7052:	e8 79 e7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7057:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    705c:	c6 02 fe             	movb   $0xfe,(%rdx)
    705f:	e9 34 ff ff ff       	jmp    6f98 <fwp_drop0+0x88>
    7064:	48 8d 3d 75 99 00 00 	lea    0x9975(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    706b:	e8 e0 d3 ff ff       	call   4450 <fwp_trap>

0000000000007070 <fwp_arg_drop12>:
    7070:	f3 0f 1e fa          	endbr64
    7074:	85 f6                	test   %esi,%esi
    7076:	75 04                	jne    707c <fwp_arg_drop12+0xc>
    7078:	85 d2                	test   %edx,%edx
    707a:	75 04                	jne    7080 <fwp_arg_drop12+0x10>
    707c:	c3                   	ret
    707d:	0f 1f 00             	nopl   (%rax)
    7080:	48 8b 3f             	mov    (%rdi),%rdi
    7083:	e9 88 fe ff ff       	jmp    6f10 <fwp_drop0>
    7088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    708f:	00 

0000000000007090 <fwp_drop1>:
    7090:	f3 0f 1e fa          	endbr64
    7094:	48 8b 15 7d 6b 06 00 	mov    0x66b7d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    709b:	48 89 f8             	mov    %rdi,%rax
    709e:	48 2b 05 4b 6b 06 00 	sub    0x66b4b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    70a5:	48 c1 e2 10          	shl    $0x10,%rdx
    70a9:	48 39 d0             	cmp    %rdx,%rax
    70ac:	0f 83 be 00 00 00    	jae    7170 <fwp_drop1+0xe0>
    70b2:	48 83 ec 18          	sub    $0x18,%rsp
    70b6:	4c 8d 05 83 57 06 00 	lea    0x65783(%rip),%r8        # 6c840 <fwp_heap>
    70bd:	48 89 c2             	mov    %rax,%rdx
    70c0:	48 c1 ea 10          	shr    $0x10,%rdx
    70c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70c8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    70cf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    70d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    70d7:	48 85 d2             	test   %rdx,%rdx
    70da:	74 3c                	je     7118 <fwp_drop1+0x88>
    70dc:	0f b6 31             	movzbl (%rcx),%esi
    70df:	40 80 fe 02          	cmp    $0x2,%sil
    70e3:	74 3b                	je     7120 <fwp_drop1+0x90>
    70e5:	40 80 fe 01          	cmp    $0x1,%sil
    70e9:	75 2d                	jne    7118 <fwp_drop1+0x88>
    70eb:	8b 71 18             	mov    0x18(%rcx),%esi
    70ee:	0f b7 c0             	movzwl %ax,%eax
    70f1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    70f4:	48 0f af c6          	imul   %rsi,%rax
    70f8:	48 c1 e8 20          	shr    $0x20,%rax
    70fc:	48 39 c8             	cmp    %rcx,%rax
    70ff:	73 17                	jae    7118 <fwp_drop1+0x88>
    7101:	48 01 c2             	add    %rax,%rdx
    7104:	0f b6 02             	movzbl (%rdx),%eax
    7107:	84 c0                	test   %al,%al
    7109:	74 0d                	je     7118 <fwp_drop1+0x88>
    710b:	3c 01                	cmp    $0x1,%al
    710d:	74 21                	je     7130 <fwp_drop1+0xa0>
    710f:	3c ff                	cmp    $0xff,%al
    7111:	74 65                	je     7178 <fwp_drop1+0xe8>
    7113:	83 e8 01             	sub    $0x1,%eax
    7116:	88 02                	mov    %al,(%rdx)
    7118:	48 83 c4 18          	add    $0x18,%rsp
    711c:	c3                   	ret
    711d:	0f 1f 00             	nopl   (%rax)
    7120:	66 85 c0             	test   %ax,%ax
    7123:	74 df                	je     7104 <fwp_drop1+0x74>
    7125:	48 83 c4 18          	add    $0x18,%rsp
    7129:	c3                   	ret
    712a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7130:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7134:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7139:	e8 a2 fa ff ff       	call   6be0 <fwp_rc_free_arr>
    713e:	4c 8d 05 fb 56 06 00 	lea    0x656fb(%rip),%r8        # 6c840 <fwp_heap>
    7145:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    714a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7151:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7158:	48 c1 e2 10          	shl    $0x10,%rdx
    715c:	48 39 d0             	cmp    %rdx,%rax
    715f:	73 b7                	jae    7118 <fwp_drop1+0x88>
    7161:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7166:	e9 52 ff ff ff       	jmp    70bd <fwp_drop1+0x2d>
    716b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7170:	c3                   	ret
    7171:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7178:	48 89 d0             	mov    %rdx,%rax
    717b:	48 c1 e8 11          	shr    $0x11,%rax
    717f:	48 31 d0             	xor    %rdx,%rax
    7182:	48 89 c1             	mov    %rax,%rcx
    7185:	48 c1 e9 09          	shr    $0x9,%rcx
    7189:	48 31 c8             	xor    %rcx,%rax
    718c:	0f b6 c8             	movzbl %al,%ecx
    718f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7196:	00 
    7197:	48 85 c0             	test   %rax,%rax
    719a:	75 0d                	jne    71a9 <fwp_drop1+0x119>
    719c:	eb 46                	jmp    71e4 <fwp_drop1+0x154>
    719e:	66 90                	xchg   %ax,%ax
    71a0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    71a4:	48 85 c0             	test   %rax,%rax
    71a7:	74 3b                	je     71e4 <fwp_drop1+0x154>
    71a9:	48 89 c1             	mov    %rax,%rcx
    71ac:	48 39 10             	cmp    %rdx,(%rax)
    71af:	75 ef                	jne    71a0 <fwp_drop1+0x110>
    71b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71b5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    71b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    71bd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    71c4:	0f 85 4e ff ff ff    	jne    7118 <fwp_drop1+0x88>
    71ca:	48 89 d7             	mov    %rdx,%rdi
    71cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    71d2:	e8 f9 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    71d7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    71dc:	c6 02 fe             	movb   $0xfe,(%rdx)
    71df:	e9 34 ff ff ff       	jmp    7118 <fwp_drop1+0x88>
    71e4:	48 8d 3d f5 97 00 00 	lea    0x97f5(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    71eb:	e8 60 d2 ff ff       	call   4450 <fwp_trap>

00000000000071f0 <fwp_closure_drop>:
    71f0:	48 8b 15 21 6a 06 00 	mov    0x66a21(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    71f7:	48 89 f8             	mov    %rdi,%rax
    71fa:	48 2b 05 ef 69 06 00 	sub    0x669ef(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7201:	48 c1 e2 10          	shl    $0x10,%rdx
    7205:	48 39 d0             	cmp    %rdx,%rax
    7208:	73 6b                	jae    7275 <fwp_closure_drop+0x85>
    720a:	48 89 c2             	mov    %rax,%rdx
    720d:	48 c1 ea 10          	shr    $0x10,%rdx
    7211:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7215:	48 8b 15 1c 6a 06 00 	mov    0x66a1c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    721c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7220:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7224:	48 85 d2             	test   %rdx,%rdx
    7227:	74 4c                	je     7275 <fwp_closure_drop+0x85>
    7229:	0f b6 31             	movzbl (%rcx),%esi
    722c:	40 80 fe 02          	cmp    $0x2,%sil
    7230:	74 3e                	je     7270 <fwp_closure_drop+0x80>
    7232:	40 80 fe 01          	cmp    $0x1,%sil
    7236:	75 3d                	jne    7275 <fwp_closure_drop+0x85>
    7238:	8b 71 18             	mov    0x18(%rcx),%esi
    723b:	0f b7 c0             	movzwl %ax,%eax
    723e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7241:	48 0f af c6          	imul   %rsi,%rax
    7245:	48 c1 e8 20          	shr    $0x20,%rax
    7249:	48 39 c8             	cmp    %rcx,%rax
    724c:	73 27                	jae    7275 <fwp_closure_drop+0x85>
    724e:	48 01 c2             	add    %rax,%rdx
    7251:	0f b6 02             	movzbl (%rdx),%eax
    7254:	84 c0                	test   %al,%al
    7256:	74 1d                	je     7275 <fwp_closure_drop+0x85>
    7258:	3c 01                	cmp    $0x1,%al
    725a:	74 24                	je     7280 <fwp_closure_drop+0x90>
    725c:	3c ff                	cmp    $0xff,%al
    725e:	74 48                	je     72a8 <fwp_closure_drop+0xb8>
    7260:	83 e8 01             	sub    $0x1,%eax
    7263:	88 02                	mov    %al,(%rdx)
    7265:	c3                   	ret
    7266:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    726d:	00 00 00 
    7270:	66 85 c0             	test   %ax,%ax
    7273:	74 dc                	je     7251 <fwp_closure_drop+0x61>
    7275:	c3                   	ret
    7276:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    727d:	00 00 00 
    7280:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7287:	ff ff 
    7289:	48 85 c0             	test   %rax,%rax
    728c:	74 12                	je     72a0 <fwp_closure_drop+0xb0>
    728e:	48 89 fe             	mov    %rdi,%rsi
    7291:	48 89 c7             	mov    %rax,%rdi
    7294:	e9 17 d2 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72a0:	e9 bb d3 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    72a5:	0f 1f 00             	nopl   (%rax)
    72a8:	48 89 d0             	mov    %rdx,%rax
    72ab:	48 8d 35 8e 55 06 00 	lea    0x6558e(%rip),%rsi        # 6c840 <fwp_heap>
    72b2:	48 83 ec 18          	sub    $0x18,%rsp
    72b6:	48 c1 e8 11          	shr    $0x11,%rax
    72ba:	48 31 d0             	xor    %rdx,%rax
    72bd:	48 89 c1             	mov    %rax,%rcx
    72c0:	48 c1 e9 09          	shr    $0x9,%rcx
    72c4:	48 31 c8             	xor    %rcx,%rax
    72c7:	0f b6 c8             	movzbl %al,%ecx
    72ca:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    72d1:	00 
    72d2:	48 85 c0             	test   %rax,%rax
    72d5:	75 12                	jne    72e9 <fwp_closure_drop+0xf9>
    72d7:	eb 49                	jmp    7322 <fwp_closure_drop+0x132>
    72d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    72e4:	48 85 c0             	test   %rax,%rax
    72e7:	74 39                	je     7322 <fwp_closure_drop+0x132>
    72e9:	48 89 c1             	mov    %rax,%rcx
    72ec:	48 39 10             	cmp    %rdx,(%rax)
    72ef:	75 ef                	jne    72e0 <fwp_closure_drop+0xf0>
    72f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    72f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    72f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    72fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7304:	74 05                	je     730b <fwp_closure_drop+0x11b>
    7306:	48 83 c4 18          	add    $0x18,%rsp
    730a:	c3                   	ret
    730b:	48 89 d7             	mov    %rdx,%rdi
    730e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7313:	e8 b8 e4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7318:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    731d:	c6 02 fe             	movb   $0xfe,(%rdx)
    7320:	eb e4                	jmp    7306 <fwp_closure_drop+0x116>
    7322:	48 8d 3d b7 96 00 00 	lea    0x96b7(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7329:	e8 22 d1 ff ff       	call   4450 <fwp_trap>
    732e:	66 90                	xchg   %ax,%ax

0000000000007330 <fwp_owned_tape_release>:
    7330:	48 85 ff             	test   %rdi,%rdi
    7333:	0f 84 f7 00 00 00    	je     7430 <fwp_owned_tape_release+0x100>
    7339:	41 54                	push   %r12
    733b:	55                   	push   %rbp
    733c:	53                   	push   %rbx
    733d:	48 8b 07             	mov    (%rdi),%rax
    7340:	48 85 c0             	test   %rax,%rax
    7343:	74 08                	je     734d <fwp_owned_tape_release+0x1d>
    7345:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7349:	48 89 50 08          	mov    %rdx,0x8(%rax)
    734d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7351:	48 85 d2             	test   %rdx,%rdx
    7354:	74 03                	je     7359 <fwp_owned_tape_release+0x29>
    7356:	48 89 02             	mov    %rax,(%rdx)
    7359:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    735d:	48 89 fb             	mov    %rdi,%rbx
    7360:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7364:	48 85 c0             	test   %rax,%rax
    7367:	0f 84 89 00 00 00    	je     73f6 <fwp_owned_tape_release+0xc6>
    736d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7371:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7375:	7e 47                	jle    73be <fwp_owned_tape_release+0x8e>
    7377:	31 ed                	xor    %ebp,%ebp
    7379:	eb 0d                	jmp    7388 <fwp_owned_tape_release+0x58>
    737b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7380:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7384:	48 8b 40 68          	mov    0x68(%rax),%rax
    7388:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    738c:	49 89 ec             	mov    %rbp,%r12
    738f:	48 83 c5 01          	add    $0x1,%rbp
    7393:	49 c1 e4 04          	shl    $0x4,%r12
    7397:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    739b:	ff d0                	call   *%rax
    739d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    73a1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    73a6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    73aa:	ff 50 68             	call   *0x68(%rax)
    73ad:	48 8b 43 58          	mov    0x58(%rbx),%rax
    73b1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    73b5:	48 39 e8             	cmp    %rbp,%rax
    73b8:	7f c6                	jg     7380 <fwp_owned_tape_release+0x50>
    73ba:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    73be:	31 ed                	xor    %ebp,%ebp
    73c0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    73c5:	7e 28                	jle    73ef <fwp_owned_tape_release+0xbf>
    73c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    73ce:	00 00 
    73d0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    73d4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    73d8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    73dc:	74 07                	je     73e5 <fwp_owned_tape_release+0xb5>
    73de:	ff 52 68             	call   *0x68(%rdx)
    73e1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    73e5:	48 83 c5 01          	add    $0x1,%rbp
    73e9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    73ed:	7f e1                	jg     73d0 <fwp_owned_tape_release+0xa0>
    73ef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    73f3:	ff 52 68             	call   *0x68(%rdx)
    73f6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    73fa:	e8 f1 fd ff ff       	call   71f0 <fwp_closure_drop>
    73ff:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7403:	e8 e8 fd ff ff       	call   71f0 <fwp_closure_drop>
    7408:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    740c:	e8 df fd ff ff       	call   71f0 <fwp_closure_drop>
    7411:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7415:	e8 f6 e5 ff ff       	call   5a10 <fwp_mem_free>
    741a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    741e:	e8 ed e5 ff ff       	call   5a10 <fwp_mem_free>
    7423:	48 89 df             	mov    %rbx,%rdi
    7426:	5b                   	pop    %rbx
    7427:	5d                   	pop    %rbp
    7428:	41 5c                	pop    %r12
    742a:	e9 e1 e5 ff ff       	jmp    5a10 <fwp_mem_free>
    742f:	90                   	nop
    7430:	c3                   	ret
    7431:	0f 1f 40 00          	nopl   0x0(%rax)
    7435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    743c:	00 00 00 00 

0000000000007440 <fwp_tape_finish>:
    7440:	f3 0f 1e fa          	endbr64
    7444:	41 55                	push   %r13
    7446:	41 54                	push   %r12
    7448:	55                   	push   %rbp
    7449:	53                   	push   %rbx
    744a:	48 83 ec 48          	sub    $0x48,%rsp
    744e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7455:	00 00 
    7457:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    745c:	48 8d 3d 5d cc 01 00 	lea    0x1cc5d(%rip),%rdi        # 240c0 <fwp_tape_workspace>
    7463:	e8 d8 dc ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7468:	48 83 3d 98 cc 01 00 	cmpq   $0x0,0x1cc98(%rip)        # 24108 <fwp_ntapes>
    746f:	00 
    7470:	48 c7 05 2d cc 01 00 	movq   $0x0,0x1cc2d(%rip)        # 240a8 <fwp_tape_cached_bytes>
    7477:	00 00 00 00 
    747b:	7e 79                	jle    74f6 <fwp_tape_finish+0xb6>
    747d:	45 31 e4             	xor    %r12d,%r12d
    7480:	31 ed                	xor    %ebp,%ebp
    7482:	0f 1f 00             	nopl   (%rax)
    7485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    748c:	00 00 00 00 
    7490:	48 8b 1d 79 cc 01 00 	mov    0x1cc79(%rip),%rbx        # 24110 <fwp_tapes>
    7497:	48 83 c5 01          	add    $0x1,%rbp
    749b:	4c 01 e3             	add    %r12,%rbx
    749e:	49 83 c4 68          	add    $0x68,%r12
    74a2:	48 89 df             	mov    %rbx,%rdi
    74a5:	e8 e6 c7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    74aa:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    74af:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    74b4:	48 89 e7             	mov    %rsp,%rdi
    74b7:	48 8b 43 40          	mov    0x40(%rbx),%rax
    74bb:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    74bf:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    74c4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    74c9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    74ce:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    74d2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    74d7:	e8 64 dc ff ff       	call   5140 <fwp_tape_buffers_dispose>
    74dc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    74e0:	e8 4b fe ff ff       	call   7330 <fwp_owned_tape_release>
    74e5:	48 39 2d 1c cc 01 00 	cmp    %rbp,0x1cc1c(%rip)        # 24108 <fwp_ntapes>
    74ec:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    74f3:	00 
    74f4:	7f 9a                	jg     7490 <fwp_tape_finish+0x50>
    74f6:	48 8b 3d 13 cc 01 00 	mov    0x1cc13(%rip),%rdi        # 24110 <fwp_tapes>
    74fd:	48 85 ff             	test   %rdi,%rdi
    7500:	74 05                	je     7507 <fwp_tape_finish+0xc7>
    7502:	e8 c9 db ff ff       	call   50d0 <ad_raw_free.part.0>
    7507:	48 c7 05 fe cb 01 00 	movq   $0x0,0x1cbfe(%rip)        # 24110 <fwp_tapes>
    750e:	00 00 00 00 
    7512:	48 c7 05 e3 cb 01 00 	movq   $0x0,0x1cbe3(%rip)        # 24100 <fwp_tapes_cap>
    7519:	00 00 00 00 
    751d:	48 c7 05 e0 cb 01 00 	movq   $0x0,0x1cbe0(%rip)        # 24108 <fwp_ntapes>
    7524:	00 00 00 00 
    7528:	48 c7 05 c5 cb 01 00 	movq   $0x0,0x1cbc5(%rip)        # 240f8 <fwp_tape_next_slot>
    752f:	00 00 00 00 
    7533:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7538:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    753f:	00 00 
    7541:	75 0b                	jne    754e <fwp_tape_finish+0x10e>
    7543:	48 83 c4 48          	add    $0x48,%rsp
    7547:	5b                   	pop    %rbx
    7548:	5d                   	pop    %rbp
    7549:	41 5c                	pop    %r12
    754b:	41 5d                	pop    %r13
    754d:	c3                   	ret
    754e:	e8 fd be ff ff       	call   3450 <__stack_chk_fail@plt>
    7553:	66 90                	xchg   %ax,%ax
    7555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    755c:	00 00 00 00 

0000000000007560 <fwp_tape_scope_release>:
    7560:	f3 0f 1e fa          	endbr64
    7564:	41 55                	push   %r13
    7566:	41 54                	push   %r12
    7568:	55                   	push   %rbp
    7569:	53                   	push   %rbx
    756a:	48 83 ec 48          	sub    $0x48,%rsp
    756e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7575:	00 00 
    7577:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    757c:	48 63 07             	movslq (%rdi),%rax
    757f:	85 c0                	test   %eax,%eax
    7581:	0f 88 e8 00 00 00    	js     766f <fwp_tape_scope_release+0x10f>
    7587:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    758e:	ec c4 4e 
    7591:	48 89 fb             	mov    %rdi,%rbx
    7594:	48 89 e5             	mov    %rsp,%rbp
    7597:	eb 1f                	jmp    75b8 <fwp_tape_scope_release+0x58>
    7599:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75a0:	e8 9b db ff ff       	call   5140 <fwp_tape_buffers_dispose>
    75a5:	4c 89 ef             	mov    %r13,%rdi
    75a8:	e8 83 fd ff ff       	call   7330 <fwp_owned_tape_release>
    75ad:	48 63 03             	movslq (%rbx),%rax
    75b0:	85 c0                	test   %eax,%eax
    75b2:	0f 88 b7 00 00 00    	js     766f <fwp_tape_scope_release+0x10f>
    75b8:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    75bc:	48 8b 35 4d cb 01 00 	mov    0x1cb4d(%rip),%rsi        # 24110 <fwp_tapes>
    75c3:	4c 01 c6             	add    %r8,%rsi
    75c6:	48 89 f7             	mov    %rsi,%rdi
    75c9:	e8 c2 c6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    75ce:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    75d3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    75d8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    75df:	48 8b 46 40          	mov    0x40(%rsi),%rax
    75e3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    75e7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    75ee:	00 
    75ef:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    75f4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    75f9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    75fd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7602:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7606:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    760b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7612:	00 
    7613:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    761a:	00 
    761b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7622:	00 
    7623:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7627:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    762b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    762f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7633:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7639:	77 18                	ja     7653 <fwp_tape_scope_release+0xf3>
    763b:	49 c1 f8 03          	sar    $0x3,%r8
    763f:	4d 0f af c4          	imul   %r12,%r8
    7643:	4c 3b 05 ae ca 01 00 	cmp    0x1caae(%rip),%r8        # 240f8 <fwp_tape_next_slot>
    764a:	7d 07                	jge    7653 <fwp_tape_scope_release+0xf3>
    764c:	4c 89 05 a5 ca 01 00 	mov    %r8,0x1caa5(%rip)        # 240f8 <fwp_tape_next_slot>
    7653:	48 89 ef             	mov    %rbp,%rdi
    7656:	4d 85 ed             	test   %r13,%r13
    7659:	0f 85 41 ff ff ff    	jne    75a0 <fwp_tape_scope_release+0x40>
    765f:	e8 fc db ff ff       	call   5260 <fwp_tape_buffers_release>
    7664:	48 63 03             	movslq (%rbx),%rax
    7667:	85 c0                	test   %eax,%eax
    7669:	0f 89 49 ff ff ff    	jns    75b8 <fwp_tape_scope_release+0x58>
    766f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7674:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    767b:	00 00 
    767d:	75 0b                	jne    768a <fwp_tape_scope_release+0x12a>
    767f:	48 83 c4 48          	add    $0x48,%rsp
    7683:	5b                   	pop    %rbx
    7684:	5d                   	pop    %rbp
    7685:	41 5c                	pop    %r12
    7687:	41 5d                	pop    %r13
    7689:	c3                   	ret
    768a:	e8 c1 bd ff ff       	call   3450 <__stack_chk_fail@plt>
    768f:	90                   	nop

0000000000007690 <fwp_task_dispose>:
    7690:	53                   	push   %rbx
    7691:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7695:	0f 84 ab c0 ff ff    	je     3746 <fwp_task_dispose.cold>
    769b:	48 89 fb             	mov    %rdi,%rbx
    769e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    76a3:	0f 85 9d c0 ff ff    	jne    3746 <fwp_task_dispose.cold>
    76a9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    76ad:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    76b4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    76bb:	00 
    76bc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    76c0:	48 85 ff             	test   %rdi,%rdi
    76c3:	74 07                	je     76cc <fwp_task_dispose+0x3c>
    76c5:	48 85 c0             	test   %rax,%rax
    76c8:	74 02                	je     76cc <fwp_task_dispose+0x3c>
    76ca:	ff d0                	call   *%rax
    76cc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    76d3:	e8 38 e3 ff ff       	call   5a10 <fwp_mem_free>
    76d8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    76df:	00 00 00 00 
    76e3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    76e7:	74 6f                	je     7758 <fwp_task_dispose+0xc8>
    76e9:	48 8b 15 28 65 06 00 	mov    0x66528(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    76f0:	48 89 d8             	mov    %rbx,%rax
    76f3:	48 2b 05 f6 64 06 00 	sub    0x664f6(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    76fa:	48 c1 e2 10          	shl    $0x10,%rdx
    76fe:	48 39 d0             	cmp    %rdx,%rax
    7701:	73 4c                	jae    774f <fwp_task_dispose+0xbf>
    7703:	48 89 c2             	mov    %rax,%rdx
    7706:	48 c1 ea 10          	shr    $0x10,%rdx
    770a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    770e:	48 8b 15 23 65 06 00 	mov    0x66523(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    7715:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7719:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    771d:	48 85 c9             	test   %rcx,%rcx
    7720:	74 2d                	je     774f <fwp_task_dispose+0xbf>
    7722:	0f b6 32             	movzbl (%rdx),%esi
    7725:	40 80 fe 02          	cmp    $0x2,%sil
    7729:	74 3d                	je     7768 <fwp_task_dispose+0xd8>
    772b:	40 80 fe 01          	cmp    $0x1,%sil
    772f:	75 1e                	jne    774f <fwp_task_dispose+0xbf>
    7731:	8b 72 18             	mov    0x18(%rdx),%esi
    7734:	0f b7 c0             	movzwl %ax,%eax
    7737:	8b 52 1c             	mov    0x1c(%rdx),%edx
    773a:	48 0f af c6          	imul   %rsi,%rax
    773e:	48 c1 e8 20          	shr    $0x20,%rax
    7742:	48 39 d0             	cmp    %rdx,%rax
    7745:	73 08                	jae    774f <fwp_task_dispose+0xbf>
    7747:	48 01 c1             	add    %rax,%rcx
    774a:	80 39 01             	cmpb   $0x1,(%rcx)
    774d:	74 09                	je     7758 <fwp_task_dispose+0xc8>
    774f:	5b                   	pop    %rbx
    7750:	c3                   	ret
    7751:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7758:	48 89 df             	mov    %rbx,%rdi
    775b:	5b                   	pop    %rbx
    775c:	e9 af e2 ff ff       	jmp    5a10 <fwp_mem_free>
    7761:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7768:	66 85 c0             	test   %ax,%ax
    776b:	74 dd                	je     774a <fwp_task_dispose+0xba>
    776d:	5b                   	pop    %rbx
    776e:	c3                   	ret
    776f:	90                   	nop

0000000000007770 <fwp_free_zombie>:
    7770:	48 8b 15 99 50 06 00 	mov    0x65099(%rip),%rdx        # 6c810 <fwp_zombie>
    7777:	48 85 d2             	test   %rdx,%rdx
    777a:	0f 84 98 00 00 00    	je     7818 <fwp_free_zombie+0xa8>
    7780:	48 3b 15 99 50 06 00 	cmp    0x65099(%rip),%rdx        # 6c820 <fwp_cur>
    7787:	0f 84 8b 00 00 00    	je     7818 <fwp_free_zombie+0xa8>
    778d:	48 83 ec 18          	sub    $0x18,%rsp
    7791:	48 63 05 5c 4a 06 00 	movslq 0x64a5c(%rip),%rax        # 6c1f4 <fwp_stack_pool_n>
    7798:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    779c:	83 f8 3f             	cmp    $0x3f,%eax
    779f:	7f 7f                	jg     7820 <fwp_free_zombie+0xb0>
    77a1:	8d 48 01             	lea    0x1(%rax),%ecx
    77a4:	89 0d 4a 4a 06 00    	mov    %ecx,0x64a4a(%rip)        # 6c1f4 <fwp_stack_pool_n>
    77aa:	48 8d 0d 4f 4a 06 00 	lea    0x64a4f(%rip),%rcx        # 6c200 <fwp_stack_pool>
    77b1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    77b5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    77bc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    77c0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    77c7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    77cb:	48 85 c9             	test   %rcx,%rcx
    77ce:	0f 84 fc 00 00 00    	je     78d0 <fwp_free_zombie+0x160>
    77d4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    77db:	48 85 c0             	test   %rax,%rax
    77de:	74 07                	je     77e7 <fwp_free_zombie+0x77>
    77e0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    77e7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    77ea:	66 0f ef c0          	pxor   %xmm0,%xmm0
    77ee:	48 c7 05 17 50 06 00 	movq   $0x0,0x65017(%rip)        # 6c810 <fwp_zombie>
    77f5:	00 00 00 00 
    77f9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7800:	85 c0                	test   %eax,%eax
    7802:	74 34                	je     7838 <fwp_free_zombie+0xc8>
    7804:	83 f8 01             	cmp    $0x1,%eax
    7807:	0f 84 b3 00 00 00    	je     78c0 <fwp_free_zombie+0x150>
    780d:	48 83 c4 18          	add    $0x18,%rsp
    7811:	c3                   	ret
    7812:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7818:	c3                   	ret
    7819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7820:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7824:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7829:	e8 92 bd ff ff       	call   35c0 <munmap@plt>
    782e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7833:	eb 80                	jmp    77b5 <fwp_free_zombie+0x45>
    7835:	0f 1f 00             	nopl   (%rax)
    7838:	48 8b 0d d9 63 06 00 	mov    0x663d9(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    783f:	48 89 d0             	mov    %rdx,%rax
    7842:	48 2b 05 a7 63 06 00 	sub    0x663a7(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7849:	48 c1 e1 10          	shl    $0x10,%rcx
    784d:	48 39 c8             	cmp    %rcx,%rax
    7850:	73 bb                	jae    780d <fwp_free_zombie+0x9d>
    7852:	48 89 c1             	mov    %rax,%rcx
    7855:	48 c1 e9 10          	shr    $0x10,%rcx
    7859:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    785d:	48 8b 0d d4 63 06 00 	mov    0x663d4(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    7864:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7868:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    786c:	48 85 c9             	test   %rcx,%rcx
    786f:	74 9c                	je     780d <fwp_free_zombie+0x9d>
    7871:	0f b6 3e             	movzbl (%rsi),%edi
    7874:	40 80 ff 02          	cmp    $0x2,%dil
    7878:	74 66                	je     78e0 <fwp_free_zombie+0x170>
    787a:	40 80 ff 01          	cmp    $0x1,%dil
    787e:	75 8d                	jne    780d <fwp_free_zombie+0x9d>
    7880:	8b 7e 18             	mov    0x18(%rsi),%edi
    7883:	0f b7 c0             	movzwl %ax,%eax
    7886:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7889:	48 0f af c7          	imul   %rdi,%rax
    788d:	48 c1 e8 20          	shr    $0x20,%rax
    7891:	48 39 f0             	cmp    %rsi,%rax
    7894:	0f 83 73 ff ff ff    	jae    780d <fwp_free_zombie+0x9d>
    789a:	48 01 c1             	add    %rax,%rcx
    789d:	0f b6 01             	movzbl (%rcx),%eax
    78a0:	84 c0                	test   %al,%al
    78a2:	0f 84 65 ff ff ff    	je     780d <fwp_free_zombie+0x9d>
    78a8:	3c 01                	cmp    $0x1,%al
    78aa:	74 14                	je     78c0 <fwp_free_zombie+0x150>
    78ac:	3c ff                	cmp    $0xff,%al
    78ae:	74 3b                	je     78eb <fwp_free_zombie+0x17b>
    78b0:	83 e8 01             	sub    $0x1,%eax
    78b3:	88 01                	mov    %al,(%rcx)
    78b5:	e9 53 ff ff ff       	jmp    780d <fwp_free_zombie+0x9d>
    78ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78c0:	48 89 d7             	mov    %rdx,%rdi
    78c3:	48 83 c4 18          	add    $0x18,%rsp
    78c7:	e9 c4 fd ff ff       	jmp    7690 <fwp_task_dispose>
    78cc:	0f 1f 40 00          	nopl   0x0(%rax)
    78d0:	48 89 05 11 4f 06 00 	mov    %rax,0x64f11(%rip)        # 6c7e8 <fwp_tasks_active>
    78d7:	e9 ff fe ff ff       	jmp    77db <fwp_free_zombie+0x6b>
    78dc:	0f 1f 40 00          	nopl   0x0(%rax)
    78e0:	66 85 c0             	test   %ax,%ax
    78e3:	0f 85 24 ff ff ff    	jne    780d <fwp_free_zombie+0x9d>
    78e9:	eb b2                	jmp    789d <fwp_free_zombie+0x12d>
    78eb:	48 89 ca             	mov    %rcx,%rdx
    78ee:	48 8d 35 4b 4f 06 00 	lea    0x64f4b(%rip),%rsi        # 6c840 <fwp_heap>
    78f5:	48 c1 ea 11          	shr    $0x11,%rdx
    78f9:	48 31 ca             	xor    %rcx,%rdx
    78fc:	48 89 d0             	mov    %rdx,%rax
    78ff:	48 c1 e8 09          	shr    $0x9,%rax
    7903:	48 31 c2             	xor    %rax,%rdx
    7906:	0f b6 d2             	movzbl %dl,%edx
    7909:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7910:	00 
    7911:	48 85 c0             	test   %rax,%rax
    7914:	75 13                	jne    7929 <fwp_free_zombie+0x1b9>
    7916:	eb 4c                	jmp    7964 <fwp_free_zombie+0x1f4>
    7918:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    791f:	00 
    7920:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7924:	48 85 c0             	test   %rax,%rax
    7927:	74 3b                	je     7964 <fwp_free_zombie+0x1f4>
    7929:	48 89 c2             	mov    %rax,%rdx
    792c:	48 39 08             	cmp    %rcx,(%rax)
    792f:	75 ef                	jne    7920 <fwp_free_zombie+0x1b0>
    7931:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7935:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7939:	48 89 50 08          	mov    %rdx,0x8(%rax)
    793d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7944:	0f 85 c3 fe ff ff    	jne    780d <fwp_free_zombie+0x9d>
    794a:	48 89 cf             	mov    %rcx,%rdi
    794d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7952:	e8 79 de ff ff       	call   57d0 <fwp_rc_forget_slot>
    7957:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    795c:	c6 01 fe             	movb   $0xfe,(%rcx)
    795f:	e9 a9 fe ff ff       	jmp    780d <fwp_free_zombie+0x9d>
    7964:	48 8d 3d 75 90 00 00 	lea    0x9075(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    796b:	e8 e0 ca ff ff       	call   4450 <fwp_trap>

0000000000007970 <fwp_block>:
    7970:	48 83 ec 08          	sub    $0x8,%rsp
    7974:	48 8b 05 8d 4e 06 00 	mov    0x64e8d(%rip),%rax        # 6c808 <fwp_ready_head>
    797b:	48 85 c0             	test   %rax,%rax
    797e:	0f 84 1c 01 00 00    	je     7aa0 <fwp_block+0x130>
    7984:	90                   	nop
    7985:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    798c:	00 00 00 00 
    7990:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7997:	48 89 15 6a 4e 06 00 	mov    %rdx,0x64e6a(%rip)        # 6c808 <fwp_ready_head>
    799e:	48 85 d2             	test   %rdx,%rdx
    79a1:	0f 84 19 01 00 00    	je     7ac0 <fwp_block+0x150>
    79a7:	48 8b 15 72 4e 06 00 	mov    0x64e72(%rip),%rdx        # 6c820 <fwp_cur>
    79ae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    79b2:	48 39 c2             	cmp    %rax,%rdx
    79b5:	0f 84 d5 00 00 00    	je     7a90 <fwp_block+0x120>
    79bb:	48 8b 0d e6 6a 06 00 	mov    0x66ae6(%rip),%rcx        # 6e4a8 <fwp_state_owners>
    79c2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    79c6:	48 89 05 53 4e 06 00 	mov    %rax,0x64e53(%rip)        # 6c820 <fwp_cur>
    79cd:	f3 0f 7e 05 fb 6a 06 	movq   0x66afb(%rip),%xmm0        # 6e4d0 <fwp_foreign_callbacks>
    79d4:	00 
    79d5:	0f 16 05 e4 6a 06 00 	movhps 0x66ae4(%rip),%xmm0        # 6e4c0 <fwp_state>
    79dc:	f3 0f 7e 0d e4 6a 06 	movq   0x66ae4(%rip),%xmm1        # 6e4c8 <fwp_handlers>
    79e3:	00 
    79e4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    79eb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    79f2:	0f 16 0d df 6a 06 00 	movhps 0x66adf(%rip),%xmm1        # 6e4d8 <fwp_cleanups>
    79f9:	f3 0f 7e 05 b7 6a 06 	movq   0x66ab7(%rip),%xmm0        # 6e4b8 <fwp_state_len>
    7a00:	00 
    7a01:	0f 16 05 a8 6a 06 00 	movhps 0x66aa8(%rip),%xmm0        # 6e4b0 <fwp_state_cap>
    7a08:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7a0f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7a16:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a1a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7a21:	48 89 0d a0 6a 06 00 	mov    %rcx,0x66aa0(%rip)        # 6e4c8 <fwp_handlers>
    7a28:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7a2f:	48 89 0d a2 6a 06 00 	mov    %rcx,0x66aa2(%rip)        # 6e4d8 <fwp_cleanups>
    7a36:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7a3d:	48 89 0d 8c 6a 06 00 	mov    %rcx,0x66a8c(%rip)        # 6e4d0 <fwp_foreign_callbacks>
    7a44:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7a4b:	48 89 0d 6e 6a 06 00 	mov    %rcx,0x66a6e(%rip)        # 6e4c0 <fwp_state>
    7a52:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7a59:	48 89 0d 58 6a 06 00 	mov    %rcx,0x66a58(%rip)        # 6e4b8 <fwp_state_len>
    7a60:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7a67:	48 89 0d 42 6a 06 00 	mov    %rcx,0x66a42(%rip)        # 6e4b0 <fwp_state_cap>
    7a6e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7a75:	48 89 0d 2c 6a 06 00 	mov    %rcx,0x66a2c(%rip)        # 6e4a8 <fwp_state_owners>
    7a7c:	e8 ff b9 ff ff       	call   3480 <swapcontext@plt>
    7a81:	f3 0f 1e fa          	endbr64
    7a85:	e8 e6 fc ff ff       	call   7770 <fwp_free_zombie>
    7a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a90:	8b 05 5a 47 06 00    	mov    0x6475a(%rip),%eax        # 6c1f0 <fwp_slice>
    7a96:	85 c0                	test   %eax,%eax
    7a98:	74 36                	je     7ad0 <fwp_block+0x160>
    7a9a:	48 83 c4 08          	add    $0x8,%rsp
    7a9e:	c3                   	ret
    7a9f:	90                   	nop
    7aa0:	e8 6b d9 ff ff       	call   5410 <fwp_poll_events>
    7aa5:	48 8b 05 5c 4d 06 00 	mov    0x64d5c(%rip),%rax        # 6c808 <fwp_ready_head>
    7aac:	48 85 c0             	test   %rax,%rax
    7aaf:	0f 85 db fe ff ff    	jne    7990 <fwp_block+0x20>
    7ab5:	eb e9                	jmp    7aa0 <fwp_block+0x130>
    7ab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7abe:	00 00 
    7ac0:	48 c7 05 35 4d 06 00 	movq   $0x0,0x64d35(%rip)        # 6c800 <fwp_ready_tail>
    7ac7:	00 00 00 00 
    7acb:	e9 d7 fe ff ff       	jmp    79a7 <fwp_block+0x37>
    7ad0:	48 8d 3d 08 87 00 00 	lea    0x8708(%rip),%rdi        # 101df <_IO_stdin_used+0x1df>
    7ad7:	e8 b4 b8 ff ff       	call   3390 <getenv@plt>
    7adc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7ae1:	48 85 c0             	test   %rax,%rax
    7ae4:	74 05                	je     7aeb <fwp_block+0x17b>
    7ae6:	80 38 00             	cmpb   $0x0,(%rax)
    7ae9:	75 0b                	jne    7af6 <fwp_block+0x186>
    7aeb:	89 15 ff 46 06 00    	mov    %edx,0x646ff(%rip)        # 6c1f0 <fwp_slice>
    7af1:	48 83 c4 08          	add    $0x8,%rsp
    7af5:	c3                   	ret
    7af6:	ba 0a 00 00 00       	mov    $0xa,%edx
    7afb:	31 f6                	xor    %esi,%esi
    7afd:	48 89 c7             	mov    %rax,%rdi
    7b00:	e8 3b ba ff ff       	call   3540 <strtoll@plt>
    7b05:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7b09:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7b10:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7b15:	0f 46 d0             	cmovbe %eax,%edx
    7b18:	eb d1                	jmp    7aeb <fwp_block+0x17b>
    7b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007b20 <fwp_drop4>:
    7b20:	48 8b 15 f1 60 06 00 	mov    0x660f1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7b27:	48 89 f8             	mov    %rdi,%rax
    7b2a:	48 2b 05 bf 60 06 00 	sub    0x660bf(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7b31:	48 c1 e2 10          	shl    $0x10,%rdx
    7b35:	48 39 d0             	cmp    %rdx,%rax
    7b38:	0f 83 52 01 00 00    	jae    7c90 <fwp_drop4+0x170>
    7b3e:	48 83 ec 18          	sub    $0x18,%rsp
    7b42:	4c 8d 05 f7 4c 06 00 	lea    0x64cf7(%rip),%r8        # 6c840 <fwp_heap>
    7b49:	48 89 c2             	mov    %rax,%rdx
    7b4c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7b53:	48 c1 ea 10          	shr    $0x10,%rdx
    7b57:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b5b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7b5f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b63:	48 85 d2             	test   %rdx,%rdx
    7b66:	74 46                	je     7bae <fwp_drop4+0x8e>
    7b68:	44 0f b6 09          	movzbl (%rcx),%r9d
    7b6c:	41 80 f9 02          	cmp    $0x2,%r9b
    7b70:	0f 84 ca 00 00 00    	je     7c40 <fwp_drop4+0x120>
    7b76:	41 80 f9 01          	cmp    $0x1,%r9b
    7b7a:	75 32                	jne    7bae <fwp_drop4+0x8e>
    7b7c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7b80:	0f b7 c0             	movzwl %ax,%eax
    7b83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b86:	49 0f af c1          	imul   %r9,%rax
    7b8a:	48 c1 e8 20          	shr    $0x20,%rax
    7b8e:	48 39 c8             	cmp    %rcx,%rax
    7b91:	73 1b                	jae    7bae <fwp_drop4+0x8e>
    7b93:	48 01 c2             	add    %rax,%rdx
    7b96:	0f b6 02             	movzbl (%rdx),%eax
    7b99:	84 c0                	test   %al,%al
    7b9b:	74 11                	je     7bae <fwp_drop4+0x8e>
    7b9d:	3c 01                	cmp    $0x1,%al
    7b9f:	74 17                	je     7bb8 <fwp_drop4+0x98>
    7ba1:	3c ff                	cmp    $0xff,%al
    7ba3:	0f 84 ef 00 00 00    	je     7c98 <fwp_drop4+0x178>
    7ba9:	83 e8 01             	sub    $0x1,%eax
    7bac:	88 02                	mov    %al,(%rdx)
    7bae:	48 83 c4 18          	add    $0x18,%rsp
    7bb2:	c3                   	ret
    7bb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7bb8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7bbc:	0f 88 8e 00 00 00    	js     7c50 <fwp_drop4+0x130>
    7bc2:	48 8b 15 4f 60 06 00 	mov    0x6604f(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7bc9:	48 89 f8             	mov    %rdi,%rax
    7bcc:	48 2b 05 1d 60 06 00 	sub    0x6601d(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7bd3:	48 c1 e2 10          	shl    $0x10,%rdx
    7bd7:	48 39 d0             	cmp    %rdx,%rax
    7bda:	73 d2                	jae    7bae <fwp_drop4+0x8e>
    7bdc:	48 89 c2             	mov    %rax,%rdx
    7bdf:	48 c1 ea 10          	shr    $0x10,%rdx
    7be3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7be7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7beb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7bef:	48 85 c9             	test   %rcx,%rcx
    7bf2:	74 ba                	je     7bae <fwp_drop4+0x8e>
    7bf4:	0f b6 32             	movzbl (%rdx),%esi
    7bf7:	40 80 fe 02          	cmp    $0x2,%sil
    7bfb:	74 33                	je     7c30 <fwp_drop4+0x110>
    7bfd:	40 80 fe 01          	cmp    $0x1,%sil
    7c01:	75 ab                	jne    7bae <fwp_drop4+0x8e>
    7c03:	8b 72 18             	mov    0x18(%rdx),%esi
    7c06:	0f b7 c0             	movzwl %ax,%eax
    7c09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c0c:	48 0f af c6          	imul   %rsi,%rax
    7c10:	48 c1 e8 20          	shr    $0x20,%rax
    7c14:	48 39 d0             	cmp    %rdx,%rax
    7c17:	73 95                	jae    7bae <fwp_drop4+0x8e>
    7c19:	48 01 c1             	add    %rax,%rcx
    7c1c:	80 39 01             	cmpb   $0x1,(%rcx)
    7c1f:	75 8d                	jne    7bae <fwp_drop4+0x8e>
    7c21:	48 83 c4 18          	add    $0x18,%rsp
    7c25:	e9 e6 dd ff ff       	jmp    5a10 <fwp_mem_free>
    7c2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c30:	66 85 c0             	test   %ax,%ax
    7c33:	74 e7                	je     7c1c <fwp_drop4+0xfc>
    7c35:	48 83 c4 18          	add    $0x18,%rsp
    7c39:	c3                   	ret
    7c3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c40:	66 85 c0             	test   %ax,%ax
    7c43:	0f 84 4d ff ff ff    	je     7b96 <fwp_drop4+0x76>
    7c49:	48 83 c4 18          	add    $0x18,%rsp
    7c4d:	c3                   	ret
    7c4e:	66 90                	xchg   %ax,%ax
    7c50:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7c54:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7c59:	e8 82 ef ff ff       	call   6be0 <fwp_rc_free_arr>
    7c5e:	4c 8d 05 db 4b 06 00 	lea    0x64bdb(%rip),%r8        # 6c840 <fwp_heap>
    7c65:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c6a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7c71:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7c78:	48 c1 e2 10          	shl    $0x10,%rdx
    7c7c:	48 39 d0             	cmp    %rdx,%rax
    7c7f:	0f 83 29 ff ff ff    	jae    7bae <fwp_drop4+0x8e>
    7c85:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7c8a:	e9 ba fe ff ff       	jmp    7b49 <fwp_drop4+0x29>
    7c8f:	90                   	nop
    7c90:	c3                   	ret
    7c91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c98:	48 89 d0             	mov    %rdx,%rax
    7c9b:	48 c1 e8 11          	shr    $0x11,%rax
    7c9f:	48 31 d0             	xor    %rdx,%rax
    7ca2:	48 89 c1             	mov    %rax,%rcx
    7ca5:	48 c1 e9 09          	shr    $0x9,%rcx
    7ca9:	48 31 c8             	xor    %rcx,%rax
    7cac:	0f b6 c8             	movzbl %al,%ecx
    7caf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7cb6:	00 
    7cb7:	48 85 c0             	test   %rax,%rax
    7cba:	75 0d                	jne    7cc9 <fwp_drop4+0x1a9>
    7cbc:	eb 46                	jmp    7d04 <fwp_drop4+0x1e4>
    7cbe:	66 90                	xchg   %ax,%ax
    7cc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7cc4:	48 85 c0             	test   %rax,%rax
    7cc7:	74 3b                	je     7d04 <fwp_drop4+0x1e4>
    7cc9:	48 89 c1             	mov    %rax,%rcx
    7ccc:	48 39 10             	cmp    %rdx,(%rax)
    7ccf:	75 ef                	jne    7cc0 <fwp_drop4+0x1a0>
    7cd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7cd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7cd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7cdd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ce4:	0f 85 c4 fe ff ff    	jne    7bae <fwp_drop4+0x8e>
    7cea:	48 89 d7             	mov    %rdx,%rdi
    7ced:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7cf2:	e8 d9 da ff ff       	call   57d0 <fwp_rc_forget_slot>
    7cf7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7cfc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7cff:	e9 aa fe ff ff       	jmp    7bae <fwp_drop4+0x8e>
    7d04:	48 8d 3d d5 8c 00 00 	lea    0x8cd5(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7d0b:	e8 40 c7 ff ff       	call   4450 <fwp_trap>

0000000000007d10 <fwp_caps161>:
    7d10:	f3 0f 1e fa          	endbr64
    7d14:	85 f6                	test   %esi,%esi
    7d16:	74 08                	je     7d20 <fwp_caps161+0x10>
    7d18:	c3                   	ret
    7d19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d20:	48 8b 15 f1 5e 06 00 	mov    0x65ef1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7d27:	48 89 f8             	mov    %rdi,%rax
    7d2a:	48 2b 05 bf 5e 06 00 	sub    0x65ebf(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7d31:	48 c1 e2 10          	shl    $0x10,%rdx
    7d35:	48 39 d0             	cmp    %rdx,%rax
    7d38:	73 de                	jae    7d18 <fwp_caps161+0x8>
    7d3a:	48 89 c2             	mov    %rax,%rdx
    7d3d:	48 c1 ea 10          	shr    $0x10,%rdx
    7d41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d45:	48 8b 15 ec 5e 06 00 	mov    0x65eec(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    7d4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d50:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7d54:	48 85 c9             	test   %rcx,%rcx
    7d57:	74 bf                	je     7d18 <fwp_caps161+0x8>
    7d59:	0f b6 32             	movzbl (%rdx),%esi
    7d5c:	40 80 fe 02          	cmp    $0x2,%sil
    7d60:	74 2e                	je     7d90 <fwp_caps161+0x80>
    7d62:	40 80 fe 01          	cmp    $0x1,%sil
    7d66:	75 b0                	jne    7d18 <fwp_caps161+0x8>
    7d68:	8b 72 18             	mov    0x18(%rdx),%esi
    7d6b:	0f b7 c0             	movzwl %ax,%eax
    7d6e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d71:	48 0f af c6          	imul   %rsi,%rax
    7d75:	48 c1 e8 20          	shr    $0x20,%rax
    7d79:	48 39 d0             	cmp    %rdx,%rax
    7d7c:	73 9a                	jae    7d18 <fwp_caps161+0x8>
    7d7e:	48 01 c1             	add    %rax,%rcx
    7d81:	80 39 01             	cmpb   $0x1,(%rcx)
    7d84:	75 92                	jne    7d18 <fwp_caps161+0x8>
    7d86:	e9 85 dc ff ff       	jmp    5a10 <fwp_mem_free>
    7d8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d90:	66 85 c0             	test   %ax,%ax
    7d93:	74 ec                	je     7d81 <fwp_caps161+0x71>
    7d95:	c3                   	ret
    7d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d9d:	00 00 00 

0000000000007da0 <fwp_drop2>:
    7da0:	48 8b 0d 71 5e 06 00 	mov    0x65e71(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    7da7:	48 89 f8             	mov    %rdi,%rax
    7daa:	48 2b 05 3f 5e 06 00 	sub    0x65e3f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7db1:	48 c1 e1 10          	shl    $0x10,%rcx
    7db5:	48 39 c8             	cmp    %rcx,%rax
    7db8:	0f 83 42 01 00 00    	jae    7f00 <fwp_drop2+0x160>
    7dbe:	48 83 ec 18          	sub    $0x18,%rsp
    7dc2:	48 89 fa             	mov    %rdi,%rdx
    7dc5:	4c 8d 05 74 4a 06 00 	lea    0x64a74(%rip),%r8        # 6c840 <fwp_heap>
    7dcc:	48 89 c1             	mov    %rax,%rcx
    7dcf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7dd6:	48 c1 e9 10          	shr    $0x10,%rcx
    7dda:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7dde:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7de2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7de6:	48 85 c9             	test   %rcx,%rcx
    7de9:	74 40                	je     7e2b <fwp_drop2+0x8b>
    7deb:	0f b6 3e             	movzbl (%rsi),%edi
    7dee:	40 80 ff 02          	cmp    $0x2,%dil
    7df2:	74 3c                	je     7e30 <fwp_drop2+0x90>
    7df4:	40 80 ff 01          	cmp    $0x1,%dil
    7df8:	75 31                	jne    7e2b <fwp_drop2+0x8b>
    7dfa:	8b 7e 18             	mov    0x18(%rsi),%edi
    7dfd:	0f b7 c0             	movzwl %ax,%eax
    7e00:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7e03:	48 0f af c7          	imul   %rdi,%rax
    7e07:	48 c1 e8 20          	shr    $0x20,%rax
    7e0b:	48 39 f0             	cmp    %rsi,%rax
    7e0e:	73 1b                	jae    7e2b <fwp_drop2+0x8b>
    7e10:	48 01 c1             	add    %rax,%rcx
    7e13:	0f b6 01             	movzbl (%rcx),%eax
    7e16:	84 c0                	test   %al,%al
    7e18:	74 11                	je     7e2b <fwp_drop2+0x8b>
    7e1a:	3c 01                	cmp    $0x1,%al
    7e1c:	74 22                	je     7e40 <fwp_drop2+0xa0>
    7e1e:	3c ff                	cmp    $0xff,%al
    7e20:	0f 84 0a 01 00 00    	je     7f30 <fwp_drop2+0x190>
    7e26:	83 e8 01             	sub    $0x1,%eax
    7e29:	88 01                	mov    %al,(%rcx)
    7e2b:	48 83 c4 18          	add    $0x18,%rsp
    7e2f:	c3                   	ret
    7e30:	66 85 c0             	test   %ax,%ax
    7e33:	74 de                	je     7e13 <fwp_drop2+0x73>
    7e35:	48 83 c4 18          	add    $0x18,%rsp
    7e39:	c3                   	ret
    7e3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e40:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7e44:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7e4b:	48 89 f8             	mov    %rdi,%rax
    7e4e:	48 c1 e1 10          	shl    $0x10,%rcx
    7e52:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7e59:	48 39 c8             	cmp    %rcx,%rax
    7e5c:	73 62                	jae    7ec0 <fwp_drop2+0x120>
    7e5e:	48 89 c1             	mov    %rax,%rcx
    7e61:	48 c1 e9 10          	shr    $0x10,%rcx
    7e65:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7e69:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7e6d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7e71:	48 85 c9             	test   %rcx,%rcx
    7e74:	74 4a                	je     7ec0 <fwp_drop2+0x120>
    7e76:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7e7a:	41 80 f9 02          	cmp    $0x2,%r9b
    7e7e:	0f 84 9c 00 00 00    	je     7f20 <fwp_drop2+0x180>
    7e84:	41 80 f9 01          	cmp    $0x1,%r9b
    7e88:	75 36                	jne    7ec0 <fwp_drop2+0x120>
    7e8a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7e8e:	0f b7 c0             	movzwl %ax,%eax
    7e91:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7e94:	49 0f af c1          	imul   %r9,%rax
    7e98:	48 c1 e8 20          	shr    $0x20,%rax
    7e9c:	48 39 f0             	cmp    %rsi,%rax
    7e9f:	73 1f                	jae    7ec0 <fwp_drop2+0x120>
    7ea1:	48 01 c1             	add    %rax,%rcx
    7ea4:	0f b6 01             	movzbl (%rcx),%eax
    7ea7:	84 c0                	test   %al,%al
    7ea9:	74 15                	je     7ec0 <fwp_drop2+0x120>
    7eab:	3c 01                	cmp    $0x1,%al
    7ead:	74 59                	je     7f08 <fwp_drop2+0x168>
    7eaf:	3c ff                	cmp    $0xff,%al
    7eb1:	0f 84 ef 00 00 00    	je     7fa6 <fwp_drop2+0x206>
    7eb7:	83 e8 01             	sub    $0x1,%eax
    7eba:	88 01                	mov    %al,(%rcx)
    7ebc:	0f 1f 40 00          	nopl   0x0(%rax)
    7ec0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7ec4:	48 89 d7             	mov    %rdx,%rdi
    7ec7:	48 89 0c 24          	mov    %rcx,(%rsp)
    7ecb:	e8 10 ed ff ff       	call   6be0 <fwp_rc_free_arr>
    7ed0:	4c 8d 05 69 49 06 00 	lea    0x64969(%rip),%r8        # 6c840 <fwp_heap>
    7ed7:	48 8b 04 24          	mov    (%rsp),%rax
    7edb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7ee2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7ee9:	48 c1 e2 10          	shl    $0x10,%rdx
    7eed:	48 39 d0             	cmp    %rdx,%rax
    7ef0:	0f 83 35 ff ff ff    	jae    7e2b <fwp_drop2+0x8b>
    7ef6:	48 8b 14 24          	mov    (%rsp),%rdx
    7efa:	e9 cd fe ff ff       	jmp    7dcc <fwp_drop2+0x2c>
    7eff:	90                   	nop
    7f00:	c3                   	ret
    7f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f08:	48 89 14 24          	mov    %rdx,(%rsp)
    7f0c:	e8 cf ec ff ff       	call   6be0 <fwp_rc_free_arr>
    7f11:	48 8b 14 24          	mov    (%rsp),%rdx
    7f15:	eb a9                	jmp    7ec0 <fwp_drop2+0x120>
    7f17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f1e:	00 00 
    7f20:	66 85 c0             	test   %ax,%ax
    7f23:	75 9b                	jne    7ec0 <fwp_drop2+0x120>
    7f25:	e9 7a ff ff ff       	jmp    7ea4 <fwp_drop2+0x104>
    7f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f30:	48 89 c8             	mov    %rcx,%rax
    7f33:	48 c1 e8 11          	shr    $0x11,%rax
    7f37:	48 31 c8             	xor    %rcx,%rax
    7f3a:	48 89 c2             	mov    %rax,%rdx
    7f3d:	48 c1 ea 09          	shr    $0x9,%rdx
    7f41:	48 31 d0             	xor    %rdx,%rax
    7f44:	0f b6 d0             	movzbl %al,%edx
    7f47:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7f4e:	00 
    7f4f:	48 85 c0             	test   %rax,%rax
    7f52:	75 19                	jne    7f6d <fwp_drop2+0x1cd>
    7f54:	e9 d3 00 00 00       	jmp    802c <fwp_drop2+0x28c>
    7f59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7f64:	48 85 c0             	test   %rax,%rax
    7f67:	0f 84 bf 00 00 00    	je     802c <fwp_drop2+0x28c>
    7f6d:	48 89 c2             	mov    %rax,%rdx
    7f70:	48 39 08             	cmp    %rcx,(%rax)
    7f73:	75 eb                	jne    7f60 <fwp_drop2+0x1c0>
    7f75:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7f79:	48 83 ea 01          	sub    $0x1,%rdx
    7f7d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7f81:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7f88:	0f 85 9d fe ff ff    	jne    7e2b <fwp_drop2+0x8b>
    7f8e:	48 89 cf             	mov    %rcx,%rdi
    7f91:	48 89 0c 24          	mov    %rcx,(%rsp)
    7f95:	e8 36 d8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7f9a:	48 8b 0c 24          	mov    (%rsp),%rcx
    7f9e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7fa1:	e9 85 fe ff ff       	jmp    7e2b <fwp_drop2+0x8b>
    7fa6:	48 89 ce             	mov    %rcx,%rsi
    7fa9:	48 c1 ee 11          	shr    $0x11,%rsi
    7fad:	48 31 ce             	xor    %rcx,%rsi
    7fb0:	48 89 f0             	mov    %rsi,%rax
    7fb3:	48 c1 e8 09          	shr    $0x9,%rax
    7fb7:	48 31 c6             	xor    %rax,%rsi
    7fba:	40 0f b6 f6          	movzbl %sil,%esi
    7fbe:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7fc5:	00 
    7fc6:	48 85 c0             	test   %rax,%rax
    7fc9:	75 1e                	jne    7fe9 <fwp_drop2+0x249>
    7fcb:	eb 5f                	jmp    802c <fwp_drop2+0x28c>
    7fcd:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7fd4:	00 
    7fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7fdc:	00 00 00 00 
    7fe0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7fe4:	48 85 c0             	test   %rax,%rax
    7fe7:	74 43                	je     802c <fwp_drop2+0x28c>
    7fe9:	48 89 c6             	mov    %rax,%rsi
    7fec:	48 39 08             	cmp    %rcx,(%rax)
    7fef:	75 ef                	jne    7fe0 <fwp_drop2+0x240>
    7ff1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ff5:	48 83 ee 01          	sub    $0x1,%rsi
    7ff9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7ffd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    8004:	0f 85 b6 fe ff ff    	jne    7ec0 <fwp_drop2+0x120>
    800a:	48 89 cf             	mov    %rcx,%rdi
    800d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8012:	48 89 0c 24          	mov    %rcx,(%rsp)
    8016:	e8 b5 d7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    801b:	48 8b 0c 24          	mov    (%rsp),%rcx
    801f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8024:	c6 01 fe             	movb   $0xfe,(%rcx)
    8027:	e9 94 fe ff ff       	jmp    7ec0 <fwp_drop2+0x120>
    802c:	48 8d 3d ad 89 00 00 	lea    0x89ad(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    8033:	e8 18 c4 ff ff       	call   4450 <fwp_trap>
    8038:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    803f:	00 

0000000000008040 <fwp_arg_drop23>:
    8040:	f3 0f 1e fa          	endbr64
    8044:	85 f6                	test   %esi,%esi
    8046:	75 04                	jne    804c <fwp_arg_drop23+0xc>
    8048:	85 d2                	test   %edx,%edx
    804a:	75 04                	jne    8050 <fwp_arg_drop23+0x10>
    804c:	c3                   	ret
    804d:	0f 1f 00             	nopl   (%rax)
    8050:	48 8b 3f             	mov    (%rdi),%rdi
    8053:	e9 48 fd ff ff       	jmp    7da0 <fwp_drop2>
    8058:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    805f:	00 

0000000000008060 <fwp_args12>:
    8060:	f3 0f 1e fa          	endbr64
    8064:	85 d2                	test   %edx,%edx
    8066:	74 04                	je     806c <fwp_args12+0xc>
    8068:	85 f6                	test   %esi,%esi
    806a:	74 04                	je     8070 <fwp_args12+0x10>
    806c:	c3                   	ret
    806d:	0f 1f 00             	nopl   (%rax)
    8070:	48 8b 15 a1 5b 06 00 	mov    0x65ba1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8077:	48 8b 07             	mov    (%rdi),%rax
    807a:	48 2b 05 6f 5b 06 00 	sub    0x65b6f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8081:	48 c1 e2 10          	shl    $0x10,%rdx
    8085:	48 39 d0             	cmp    %rdx,%rax
    8088:	73 e2                	jae    806c <fwp_args12+0xc>
    808a:	48 89 c2             	mov    %rax,%rdx
    808d:	48 c1 ea 10          	shr    $0x10,%rdx
    8091:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8095:	48 8b 15 9c 5b 06 00 	mov    0x65b9c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    809c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80a0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    80a4:	48 85 ff             	test   %rdi,%rdi
    80a7:	74 c3                	je     806c <fwp_args12+0xc>
    80a9:	0f b6 0a             	movzbl (%rdx),%ecx
    80ac:	80 f9 02             	cmp    $0x2,%cl
    80af:	74 4f                	je     8100 <fwp_args12+0xa0>
    80b1:	80 f9 01             	cmp    $0x1,%cl
    80b4:	75 b6                	jne    806c <fwp_args12+0xc>
    80b6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80b9:	0f b7 c0             	movzwl %ax,%eax
    80bc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80bf:	48 0f af c1          	imul   %rcx,%rax
    80c3:	48 c1 e8 20          	shr    $0x20,%rax
    80c7:	48 39 d0             	cmp    %rdx,%rax
    80ca:	73 a0                	jae    806c <fwp_args12+0xc>
    80cc:	48 01 c7             	add    %rax,%rdi
    80cf:	0f b6 07             	movzbl (%rdi),%eax
    80d2:	84 c0                	test   %al,%al
    80d4:	74 96                	je     806c <fwp_args12+0xc>
    80d6:	8b 15 2c 64 06 00    	mov    0x6642c(%rip),%edx        # 6e508 <iteration_active>
    80dc:	85 d2                	test   %edx,%edx
    80de:	75 10                	jne    80f0 <fwp_args12+0x90>
    80e0:	3c fd                	cmp    $0xfd,%al
    80e2:	77 22                	ja     8106 <fwp_args12+0xa6>
    80e4:	83 c0 01             	add    $0x1,%eax
    80e7:	88 07                	mov    %al,(%rdi)
    80e9:	c3                   	ret
    80ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80f0:	48 83 05 f8 63 06 00 	addq   $0x1,0x663f8(%rip)        # 6e4f0 <iteration_retains>
    80f7:	01 
    80f8:	eb e6                	jmp    80e0 <fwp_args12+0x80>
    80fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8100:	66 85 c0             	test   %ax,%ax
    8103:	74 ca                	je     80cf <fwp_args12+0x6f>
    8105:	c3                   	ret
    8106:	e9 a5 d5 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    810b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000008110 <fwp_args23>:
    8110:	f3 0f 1e fa          	endbr64
    8114:	85 d2                	test   %edx,%edx
    8116:	74 04                	je     811c <fwp_args23+0xc>
    8118:	85 f6                	test   %esi,%esi
    811a:	74 04                	je     8120 <fwp_args23+0x10>
    811c:	c3                   	ret
    811d:	0f 1f 00             	nopl   (%rax)
    8120:	48 8b 15 f1 5a 06 00 	mov    0x65af1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8127:	48 8b 07             	mov    (%rdi),%rax
    812a:	48 2b 05 bf 5a 06 00 	sub    0x65abf(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8131:	48 c1 e2 10          	shl    $0x10,%rdx
    8135:	48 39 d0             	cmp    %rdx,%rax
    8138:	73 e2                	jae    811c <fwp_args23+0xc>
    813a:	48 89 c2             	mov    %rax,%rdx
    813d:	48 c1 ea 10          	shr    $0x10,%rdx
    8141:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8145:	48 8b 15 ec 5a 06 00 	mov    0x65aec(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    814c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8150:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8154:	48 85 ff             	test   %rdi,%rdi
    8157:	74 c3                	je     811c <fwp_args23+0xc>
    8159:	0f b6 0a             	movzbl (%rdx),%ecx
    815c:	80 f9 02             	cmp    $0x2,%cl
    815f:	74 4f                	je     81b0 <fwp_args23+0xa0>
    8161:	80 f9 01             	cmp    $0x1,%cl
    8164:	75 b6                	jne    811c <fwp_args23+0xc>
    8166:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8169:	0f b7 c0             	movzwl %ax,%eax
    816c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    816f:	48 0f af c1          	imul   %rcx,%rax
    8173:	48 c1 e8 20          	shr    $0x20,%rax
    8177:	48 39 d0             	cmp    %rdx,%rax
    817a:	73 a0                	jae    811c <fwp_args23+0xc>
    817c:	48 01 c7             	add    %rax,%rdi
    817f:	0f b6 07             	movzbl (%rdi),%eax
    8182:	84 c0                	test   %al,%al
    8184:	74 96                	je     811c <fwp_args23+0xc>
    8186:	8b 15 7c 63 06 00    	mov    0x6637c(%rip),%edx        # 6e508 <iteration_active>
    818c:	85 d2                	test   %edx,%edx
    818e:	75 10                	jne    81a0 <fwp_args23+0x90>
    8190:	3c fd                	cmp    $0xfd,%al
    8192:	77 22                	ja     81b6 <fwp_args23+0xa6>
    8194:	83 c0 01             	add    $0x1,%eax
    8197:	88 07                	mov    %al,(%rdi)
    8199:	c3                   	ret
    819a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81a0:	48 83 05 48 63 06 00 	addq   $0x1,0x66348(%rip)        # 6e4f0 <iteration_retains>
    81a7:	01 
    81a8:	eb e6                	jmp    8190 <fwp_args23+0x80>
    81aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81b0:	66 85 c0             	test   %ax,%ax
    81b3:	74 ca                	je     817f <fwp_args23+0x6f>
    81b5:	c3                   	ret
    81b6:	e9 f5 d4 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    81bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000081c0 <fwp_caps12>:
    81c0:	f3 0f 1e fa          	endbr64
    81c4:	48 83 ec 18          	sub    $0x18,%rsp
    81c8:	48 89 f8             	mov    %rdi,%rax
    81cb:	8b 7f 04             	mov    0x4(%rdi),%edi
    81ce:	85 ff                	test   %edi,%edi
    81d0:	0f 84 9a 00 00 00    	je     8270 <fwp_caps12+0xb0>
    81d6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    81da:	85 f6                	test   %esi,%esi
    81dc:	0f 85 9e 00 00 00    	jne    8280 <fwp_caps12+0xc0>
    81e2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    81e7:	e8 24 ed ff ff       	call   6f10 <fwp_drop0>
    81ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    81f1:	48 8b 0d 20 5a 06 00 	mov    0x65a20(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    81f8:	48 89 c2             	mov    %rax,%rdx
    81fb:	48 2b 15 ee 59 06 00 	sub    0x659ee(%rip),%rdx        # 6dbf0 <fwp_heap+0x13b0>
    8202:	48 c1 e1 10          	shl    $0x10,%rcx
    8206:	48 39 ca             	cmp    %rcx,%rdx
    8209:	73 6d                	jae    8278 <fwp_caps12+0xb8>
    820b:	48 89 d1             	mov    %rdx,%rcx
    820e:	48 c1 e9 10          	shr    $0x10,%rcx
    8212:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8216:	48 8b 0d 1b 5a 06 00 	mov    0x65a1b(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    821d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8221:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8225:	48 85 f6             	test   %rsi,%rsi
    8228:	74 4e                	je     8278 <fwp_caps12+0xb8>
    822a:	0f b6 39             	movzbl (%rcx),%edi
    822d:	40 80 ff 02          	cmp    $0x2,%dil
    8231:	0f 84 c9 00 00 00    	je     8300 <fwp_caps12+0x140>
    8237:	40 80 ff 01          	cmp    $0x1,%dil
    823b:	75 3b                	jne    8278 <fwp_caps12+0xb8>
    823d:	8b 79 18             	mov    0x18(%rcx),%edi
    8240:	0f b7 d2             	movzwl %dx,%edx
    8243:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8246:	48 0f af d7          	imul   %rdi,%rdx
    824a:	48 c1 ea 20          	shr    $0x20,%rdx
    824e:	48 39 ca             	cmp    %rcx,%rdx
    8251:	73 25                	jae    8278 <fwp_caps12+0xb8>
    8253:	48 01 d6             	add    %rdx,%rsi
    8256:	80 3e 01             	cmpb   $0x1,(%rsi)
    8259:	75 1d                	jne    8278 <fwp_caps12+0xb8>
    825b:	48 89 c7             	mov    %rax,%rdi
    825e:	48 83 c4 18          	add    $0x18,%rsp
    8262:	e9 a9 d7 ff ff       	jmp    5a10 <fwp_mem_free>
    8267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    826e:	00 00 
    8270:	85 f6                	test   %esi,%esi
    8272:	0f 84 79 ff ff ff    	je     81f1 <fwp_caps12+0x31>
    8278:	48 83 c4 18          	add    $0x18,%rsp
    827c:	c3                   	ret
    827d:	0f 1f 00             	nopl   (%rax)
    8280:	48 8b 05 91 59 06 00 	mov    0x65991(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    8287:	48 2b 3d 62 59 06 00 	sub    0x65962(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    828e:	48 c1 e0 10          	shl    $0x10,%rax
    8292:	48 39 c7             	cmp    %rax,%rdi
    8295:	73 e1                	jae    8278 <fwp_caps12+0xb8>
    8297:	48 89 f8             	mov    %rdi,%rax
    829a:	48 c1 e8 10          	shr    $0x10,%rax
    829e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    82a2:	48 8b 05 8f 59 06 00 	mov    0x6598f(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    82a9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    82ad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    82b1:	48 85 c0             	test   %rax,%rax
    82b4:	74 c2                	je     8278 <fwp_caps12+0xb8>
    82b6:	0f b6 0a             	movzbl (%rdx),%ecx
    82b9:	80 f9 02             	cmp    $0x2,%cl
    82bc:	74 52                	je     8310 <fwp_caps12+0x150>
    82be:	80 f9 01             	cmp    $0x1,%cl
    82c1:	75 b5                	jne    8278 <fwp_caps12+0xb8>
    82c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    82c6:	0f b7 ff             	movzwl %di,%edi
    82c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    82cc:	48 0f af f9          	imul   %rcx,%rdi
    82d0:	48 c1 ef 20          	shr    $0x20,%rdi
    82d4:	48 39 d7             	cmp    %rdx,%rdi
    82d7:	73 9f                	jae    8278 <fwp_caps12+0xb8>
    82d9:	48 01 f8             	add    %rdi,%rax
    82dc:	0f b6 10             	movzbl (%rax),%edx
    82df:	84 d2                	test   %dl,%dl
    82e1:	74 95                	je     8278 <fwp_caps12+0xb8>
    82e3:	8b 0d 1f 62 06 00    	mov    0x6621f(%rip),%ecx        # 6e508 <iteration_active>
    82e9:	85 c9                	test   %ecx,%ecx
    82eb:	75 33                	jne    8320 <fwp_caps12+0x160>
    82ed:	80 fa fd             	cmp    $0xfd,%dl
    82f0:	77 38                	ja     832a <fwp_caps12+0x16a>
    82f2:	83 c2 01             	add    $0x1,%edx
    82f5:	88 10                	mov    %dl,(%rax)
    82f7:	e9 7c ff ff ff       	jmp    8278 <fwp_caps12+0xb8>
    82fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8300:	66 85 d2             	test   %dx,%dx
    8303:	0f 85 6f ff ff ff    	jne    8278 <fwp_caps12+0xb8>
    8309:	e9 48 ff ff ff       	jmp    8256 <fwp_caps12+0x96>
    830e:	66 90                	xchg   %ax,%ax
    8310:	66 85 ff             	test   %di,%di
    8313:	0f 85 5f ff ff ff    	jne    8278 <fwp_caps12+0xb8>
    8319:	eb c1                	jmp    82dc <fwp_caps12+0x11c>
    831b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8320:	48 83 05 c8 61 06 00 	addq   $0x1,0x661c8(%rip)        # 6e4f0 <iteration_retains>
    8327:	01 
    8328:	eb c3                	jmp    82ed <fwp_caps12+0x12d>
    832a:	48 89 c7             	mov    %rax,%rdi
    832d:	48 83 c4 18          	add    $0x18,%rsp
    8331:	e9 7a d3 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    8336:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    833d:	00 00 00 

0000000000008340 <fwp_caps23>:
    8340:	f3 0f 1e fa          	endbr64
    8344:	48 83 ec 18          	sub    $0x18,%rsp
    8348:	48 89 f8             	mov    %rdi,%rax
    834b:	8b 7f 04             	mov    0x4(%rdi),%edi
    834e:	85 ff                	test   %edi,%edi
    8350:	0f 84 9a 00 00 00    	je     83f0 <fwp_caps23+0xb0>
    8356:	48 8b 78 08          	mov    0x8(%rax),%rdi
    835a:	85 f6                	test   %esi,%esi
    835c:	0f 85 9e 00 00 00    	jne    8400 <fwp_caps23+0xc0>
    8362:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8367:	e8 34 fa ff ff       	call   7da0 <fwp_drop2>
    836c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8371:	48 8b 0d a0 58 06 00 	mov    0x658a0(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    8378:	48 89 c2             	mov    %rax,%rdx
    837b:	48 2b 15 6e 58 06 00 	sub    0x6586e(%rip),%rdx        # 6dbf0 <fwp_heap+0x13b0>
    8382:	48 c1 e1 10          	shl    $0x10,%rcx
    8386:	48 39 ca             	cmp    %rcx,%rdx
    8389:	73 6d                	jae    83f8 <fwp_caps23+0xb8>
    838b:	48 89 d1             	mov    %rdx,%rcx
    838e:	48 c1 e9 10          	shr    $0x10,%rcx
    8392:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8396:	48 8b 0d 9b 58 06 00 	mov    0x6589b(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    839d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    83a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    83a5:	48 85 f6             	test   %rsi,%rsi
    83a8:	74 4e                	je     83f8 <fwp_caps23+0xb8>
    83aa:	0f b6 39             	movzbl (%rcx),%edi
    83ad:	40 80 ff 02          	cmp    $0x2,%dil
    83b1:	0f 84 c9 00 00 00    	je     8480 <fwp_caps23+0x140>
    83b7:	40 80 ff 01          	cmp    $0x1,%dil
    83bb:	75 3b                	jne    83f8 <fwp_caps23+0xb8>
    83bd:	8b 79 18             	mov    0x18(%rcx),%edi
    83c0:	0f b7 d2             	movzwl %dx,%edx
    83c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    83c6:	48 0f af d7          	imul   %rdi,%rdx
    83ca:	48 c1 ea 20          	shr    $0x20,%rdx
    83ce:	48 39 ca             	cmp    %rcx,%rdx
    83d1:	73 25                	jae    83f8 <fwp_caps23+0xb8>
    83d3:	48 01 d6             	add    %rdx,%rsi
    83d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    83d9:	75 1d                	jne    83f8 <fwp_caps23+0xb8>
    83db:	48 89 c7             	mov    %rax,%rdi
    83de:	48 83 c4 18          	add    $0x18,%rsp
    83e2:	e9 29 d6 ff ff       	jmp    5a10 <fwp_mem_free>
    83e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    83ee:	00 00 
    83f0:	85 f6                	test   %esi,%esi
    83f2:	0f 84 79 ff ff ff    	je     8371 <fwp_caps23+0x31>
    83f8:	48 83 c4 18          	add    $0x18,%rsp
    83fc:	c3                   	ret
    83fd:	0f 1f 00             	nopl   (%rax)
    8400:	48 8b 05 11 58 06 00 	mov    0x65811(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    8407:	48 2b 3d e2 57 06 00 	sub    0x657e2(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    840e:	48 c1 e0 10          	shl    $0x10,%rax
    8412:	48 39 c7             	cmp    %rax,%rdi
    8415:	73 e1                	jae    83f8 <fwp_caps23+0xb8>
    8417:	48 89 f8             	mov    %rdi,%rax
    841a:	48 c1 e8 10          	shr    $0x10,%rax
    841e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8422:	48 8b 05 0f 58 06 00 	mov    0x6580f(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    8429:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    842d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8431:	48 85 c0             	test   %rax,%rax
    8434:	74 c2                	je     83f8 <fwp_caps23+0xb8>
    8436:	0f b6 0a             	movzbl (%rdx),%ecx
    8439:	80 f9 02             	cmp    $0x2,%cl
    843c:	74 52                	je     8490 <fwp_caps23+0x150>
    843e:	80 f9 01             	cmp    $0x1,%cl
    8441:	75 b5                	jne    83f8 <fwp_caps23+0xb8>
    8443:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8446:	0f b7 ff             	movzwl %di,%edi
    8449:	8b 52 1c             	mov    0x1c(%rdx),%edx
    844c:	48 0f af f9          	imul   %rcx,%rdi
    8450:	48 c1 ef 20          	shr    $0x20,%rdi
    8454:	48 39 d7             	cmp    %rdx,%rdi
    8457:	73 9f                	jae    83f8 <fwp_caps23+0xb8>
    8459:	48 01 f8             	add    %rdi,%rax
    845c:	0f b6 10             	movzbl (%rax),%edx
    845f:	84 d2                	test   %dl,%dl
    8461:	74 95                	je     83f8 <fwp_caps23+0xb8>
    8463:	8b 0d 9f 60 06 00    	mov    0x6609f(%rip),%ecx        # 6e508 <iteration_active>
    8469:	85 c9                	test   %ecx,%ecx
    846b:	75 33                	jne    84a0 <fwp_caps23+0x160>
    846d:	80 fa fd             	cmp    $0xfd,%dl
    8470:	77 38                	ja     84aa <fwp_caps23+0x16a>
    8472:	83 c2 01             	add    $0x1,%edx
    8475:	88 10                	mov    %dl,(%rax)
    8477:	e9 7c ff ff ff       	jmp    83f8 <fwp_caps23+0xb8>
    847c:	0f 1f 40 00          	nopl   0x0(%rax)
    8480:	66 85 d2             	test   %dx,%dx
    8483:	0f 85 6f ff ff ff    	jne    83f8 <fwp_caps23+0xb8>
    8489:	e9 48 ff ff ff       	jmp    83d6 <fwp_caps23+0x96>
    848e:	66 90                	xchg   %ax,%ax
    8490:	66 85 ff             	test   %di,%di
    8493:	0f 85 5f ff ff ff    	jne    83f8 <fwp_caps23+0xb8>
    8499:	eb c1                	jmp    845c <fwp_caps23+0x11c>
    849b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    84a0:	48 83 05 48 60 06 00 	addq   $0x1,0x66048(%rip)        # 6e4f0 <iteration_retains>
    84a7:	01 
    84a8:	eb c3                	jmp    846d <fwp_caps23+0x12d>
    84aa:	48 89 c7             	mov    %rax,%rdi
    84ad:	48 83 c4 18          	add    $0x18,%rsp
    84b1:	e9 fa d1 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    84b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    84bd:	00 00 00 

00000000000084c0 <f23>:
    84c0:	41 57                	push   %r15
    84c2:	41 56                	push   %r14
    84c4:	41 55                	push   %r13
    84c6:	41 54                	push   %r12
    84c8:	55                   	push   %rbp
    84c9:	53                   	push   %rbx
    84ca:	48 83 ec 38          	sub    $0x38,%rsp
    84ce:	48 8b 15 43 57 06 00 	mov    0x65743(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    84d5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    84da:	48 c1 e2 10          	shl    $0x10,%rdx
    84de:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    84e5:	00 00 
    84e7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    84ec:	48 8b 0d fd 56 06 00 	mov    0x656fd(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    84f3:	48 85 ff             	test   %rdi,%rdi
    84f6:	0f 84 1e 03 00 00    	je     881a <f23+0x35a>
    84fc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8501:	4c 8b 68 10          	mov    0x10(%rax),%r13
    8505:	4c 89 e8             	mov    %r13,%rax
    8508:	48 29 c8             	sub    %rcx,%rax
    850b:	48 39 d0             	cmp    %rdx,%rax
    850e:	0f 83 ec 02 00 00    	jae    8800 <f23+0x340>
    8514:	48 89 c2             	mov    %rax,%rdx
    8517:	48 c1 ea 10          	shr    $0x10,%rdx
    851b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    851f:	48 8b 15 12 57 06 00 	mov    0x65712(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8526:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    852a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    852e:	48 85 ff             	test   %rdi,%rdi
    8531:	0f 84 c9 02 00 00    	je     8800 <f23+0x340>
    8537:	0f b6 0a             	movzbl (%rdx),%ecx
    853a:	80 f9 02             	cmp    $0x2,%cl
    853d:	0f 84 4d 02 00 00    	je     8790 <f23+0x2d0>
    8543:	80 f9 01             	cmp    $0x1,%cl
    8546:	75 24                	jne    856c <f23+0xac>
    8548:	8b 4a 18             	mov    0x18(%rdx),%ecx
    854b:	0f b7 c0             	movzwl %ax,%eax
    854e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8551:	48 0f af c1          	imul   %rcx,%rax
    8555:	48 c1 e8 20          	shr    $0x20,%rax
    8559:	48 39 d0             	cmp    %rdx,%rax
    855c:	73 0e                	jae    856c <f23+0xac>
    855e:	48 01 c7             	add    %rax,%rdi
    8561:	0f b6 07             	movzbl (%rdi),%eax
    8564:	84 c0                	test   %al,%al
    8566:	0f 85 44 02 00 00    	jne    87b0 <f23+0x2f0>
    856c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8571:	48 8b 40 10          	mov    0x10(%rax),%rax
    8575:	ba 01 00 00 00       	mov    $0x1,%edx
    857a:	48 85 c0             	test   %rax,%rax
    857d:	74 0e                	je     858d <f23+0xcd>
    857f:	90                   	nop
    8580:	48 8b 40 10          	mov    0x10(%rax),%rax
    8584:	48 83 c2 01          	add    $0x1,%rdx
    8588:	48 85 c0             	test   %rax,%rax
    858b:	75 f3                	jne    8580 <f23+0xc0>
    858d:	4d 85 ed             	test   %r13,%r13
    8590:	0f 84 9a 02 00 00    	je     8830 <f23+0x370>
    8596:	4c 89 e8             	mov    %r13,%rax
    8599:	31 db                	xor    %ebx,%ebx
    859b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    85a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    85a4:	48 83 c3 01          	add    $0x1,%rbx
    85a8:	48 85 c0             	test   %rax,%rax
    85ab:	75 f3                	jne    85a0 <f23+0xe0>
    85ad:	48 39 d3             	cmp    %rdx,%rbx
    85b0:	48 0f 47 da          	cmova  %rdx,%rbx
    85b4:	48 89 d8             	mov    %rbx,%rax
    85b7:	48 c1 e8 3c          	shr    $0x3c,%rax
    85bb:	0f 85 7d 03 00 00    	jne    893e <f23+0x47e>
    85c1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    85c5:	be 02 00 00 00       	mov    $0x2,%esi
    85ca:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    85d1:	00 
    85d2:	e8 39 d9 ff ff       	call   5f10 <fwp_heap_alloc>
    85d7:	48 89 28             	mov    %rbp,(%rax)
    85da:	48 8b 15 37 56 06 00 	mov    0x65637(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    85e1:	49 89 c4             	mov    %rax,%r12
    85e4:	48 2b 05 05 56 06 00 	sub    0x65605(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    85eb:	48 c1 e2 10          	shl    $0x10,%rdx
    85ef:	48 39 d0             	cmp    %rdx,%rax
    85f2:	73 57                	jae    864b <f23+0x18b>
    85f4:	48 89 c2             	mov    %rax,%rdx
    85f7:	48 c1 ea 10          	shr    $0x10,%rdx
    85fb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85ff:	48 8b 15 32 56 06 00 	mov    0x65632(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8606:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    860a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    860e:	48 85 ed             	test   %rbp,%rbp
    8611:	74 38                	je     864b <f23+0x18b>
    8613:	0f b6 0a             	movzbl (%rdx),%ecx
    8616:	80 f9 02             	cmp    $0x2,%cl
    8619:	0f 84 d1 01 00 00    	je     87f0 <f23+0x330>
    861f:	80 f9 01             	cmp    $0x1,%cl
    8622:	75 27                	jne    864b <f23+0x18b>
    8624:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8627:	0f b7 c0             	movzwl %ax,%eax
    862a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    862d:	48 0f af c1          	imul   %rcx,%rax
    8631:	48 c1 e8 20          	shr    $0x20,%rax
    8635:	48 39 d0             	cmp    %rdx,%rax
    8638:	73 11                	jae    864b <f23+0x18b>
    863a:	48 01 c5             	add    %rax,%rbp
    863d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8641:	0f 84 57 02 00 00    	je     889e <f23+0x3de>
    8647:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    864b:	48 85 db             	test   %rbx,%rbx
    864e:	74 5d                	je     86ad <f23+0x1ed>
    8650:	48 c1 e3 04          	shl    $0x4,%rbx
    8654:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8659:	4c 89 e5             	mov    %r12,%rbp
    865c:	4d 89 ef             	mov    %r13,%r15
    865f:	4c 01 e3             	add    %r12,%rbx
    8662:	0f 1f 00             	nopl   (%rax)
    8665:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    866c:	00 00 00 00 
    8670:	49 8b 46 08          	mov    0x8(%r14),%rax
    8674:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8678:	48 83 c5 10          	add    $0x10,%rbp
    867c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8681:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8685:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8689:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    868e:	e8 3d e0 ff ff       	call   66d0 <w107>
    8693:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8698:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    869c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    86a0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    86a4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    86a8:	48 39 dd             	cmp    %rbx,%rbp
    86ab:	75 c3                	jne    8670 <f23+0x1b0>
    86ad:	4c 89 ef             	mov    %r13,%rdi
    86b0:	e8 eb f6 ff ff       	call   7da0 <fwp_drop2>
    86b5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    86ba:	e8 e1 f6 ff ff       	call   7da0 <fwp_drop2>
    86bf:	4c 89 e7             	mov    %r12,%rdi
    86c2:	e8 79 e1 ff ff       	call   6840 <w164.constprop.0>
    86c7:	4c 89 e7             	mov    %r12,%rdi
    86ca:	48 89 c3             	mov    %rax,%rbx
    86cd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    86d3:	e8 48 f4 ff ff       	call   7b20 <fwp_drop4>
    86d8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    86de:	66 48 0f 6e db       	movq   %rbx,%xmm3
    86e3:	31 ff                	xor    %edi,%edi
    86e5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    86ea:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    86ee:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    86f3:	e8 c8 e1 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    86f8:	48 8b 15 19 55 06 00 	mov    0x65519(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    86ff:	48 89 c5             	mov    %rax,%rbp
    8702:	48 2b 05 e7 54 06 00 	sub    0x654e7(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8709:	48 c1 e2 10          	shl    $0x10,%rdx
    870d:	48 39 d0             	cmp    %rdx,%rax
    8710:	73 55                	jae    8767 <f23+0x2a7>
    8712:	48 89 c2             	mov    %rax,%rdx
    8715:	48 c1 ea 10          	shr    $0x10,%rdx
    8719:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    871d:	48 8b 15 14 55 06 00 	mov    0x65514(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8724:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8728:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    872c:	48 85 db             	test   %rbx,%rbx
    872f:	74 36                	je     8767 <f23+0x2a7>
    8731:	0f b6 0a             	movzbl (%rdx),%ecx
    8734:	80 f9 02             	cmp    $0x2,%cl
    8737:	0f 84 a3 00 00 00    	je     87e0 <f23+0x320>
    873d:	80 f9 01             	cmp    $0x1,%cl
    8740:	75 25                	jne    8767 <f23+0x2a7>
    8742:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8745:	0f b7 c0             	movzwl %ax,%eax
    8748:	8b 52 1c             	mov    0x1c(%rdx),%edx
    874b:	48 0f af c1          	imul   %rcx,%rax
    874f:	48 c1 e8 20          	shr    $0x20,%rax
    8753:	48 39 d0             	cmp    %rdx,%rax
    8756:	73 0f                	jae    8767 <f23+0x2a7>
    8758:	48 01 c3             	add    %rax,%rbx
    875b:	80 3b ff             	cmpb   $0xff,(%rbx)
    875e:	0f 84 2d 01 00 00    	je     8891 <f23+0x3d1>
    8764:	c6 03 01             	movb   $0x1,(%rbx)
    8767:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    876c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8773:	00 00 
    8775:	0f 85 cf 01 00 00    	jne    894a <f23+0x48a>
    877b:	48 83 c4 38          	add    $0x38,%rsp
    877f:	48 89 e8             	mov    %rbp,%rax
    8782:	5b                   	pop    %rbx
    8783:	5d                   	pop    %rbp
    8784:	41 5c                	pop    %r12
    8786:	41 5d                	pop    %r13
    8788:	41 5e                	pop    %r14
    878a:	41 5f                	pop    %r15
    878c:	c3                   	ret
    878d:	0f 1f 00             	nopl   (%rax)
    8790:	66 85 c0             	test   %ax,%ax
    8793:	0f 85 d3 fd ff ff    	jne    856c <f23+0xac>
    8799:	0f b6 07             	movzbl (%rdi),%eax
    879c:	84 c0                	test   %al,%al
    879e:	0f 84 c8 fd ff ff    	je     856c <f23+0xac>
    87a4:	90                   	nop
    87a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    87ac:	00 00 00 00 
    87b0:	8b 15 52 5d 06 00    	mov    0x65d52(%rip),%edx        # 6e508 <iteration_active>
    87b6:	85 d2                	test   %edx,%edx
    87b8:	75 56                	jne    8810 <f23+0x350>
    87ba:	3c fd                	cmp    $0xfd,%al
    87bc:	0f 87 4b 01 00 00    	ja     890d <f23+0x44d>
    87c2:	83 c0 01             	add    $0x1,%eax
    87c5:	88 07                	mov    %al,(%rdi)
    87c7:	31 d2                	xor    %edx,%edx
    87c9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    87cf:	0f 85 97 fd ff ff    	jne    856c <f23+0xac>
    87d5:	e9 b3 fd ff ff       	jmp    858d <f23+0xcd>
    87da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87e0:	66 85 c0             	test   %ax,%ax
    87e3:	0f 85 7e ff ff ff    	jne    8767 <f23+0x2a7>
    87e9:	e9 6d ff ff ff       	jmp    875b <f23+0x29b>
    87ee:	66 90                	xchg   %ax,%ax
    87f0:	66 85 c0             	test   %ax,%ax
    87f3:	0f 85 52 fe ff ff    	jne    864b <f23+0x18b>
    87f9:	e9 3f fe ff ff       	jmp    863d <f23+0x17d>
    87fe:	66 90                	xchg   %ax,%ax
    8800:	4c 89 e8             	mov    %r13,%rax
    8803:	e9 6d fd ff ff       	jmp    8575 <f23+0xb5>
    8808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    880f:	00 
    8810:	48 83 05 d8 5c 06 00 	addq   $0x1,0x65cd8(%rip)        # 6e4f0 <iteration_retains>
    8817:	01 
    8818:	eb a0                	jmp    87ba <f23+0x2fa>
    881a:	48 f7 d9             	neg    %rcx
    881d:	48 39 d1             	cmp    %rdx,%rcx
    8820:	0f 82 85 00 00 00    	jb     88ab <f23+0x3eb>
    8826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    882d:	00 00 00 
    8830:	be 02 00 00 00       	mov    $0x2,%esi
    8835:	bf 08 00 00 00       	mov    $0x8,%edi
    883a:	e8 d1 d6 ff ff       	call   5f10 <fwp_heap_alloc>
    883f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8846:	48 8b 15 cb 53 06 00 	mov    0x653cb(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    884d:	49 89 c4             	mov    %rax,%r12
    8850:	48 2b 05 99 53 06 00 	sub    0x65399(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8857:	48 c1 e2 10          	shl    $0x10,%rdx
    885b:	48 39 d0             	cmp    %rdx,%rax
    885e:	0f 83 b3 00 00 00    	jae    8917 <f23+0x457>
    8864:	48 89 c2             	mov    %rax,%rdx
    8867:	48 c1 ea 10          	shr    $0x10,%rdx
    886b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    886f:	48 8b 15 c2 53 06 00 	mov    0x653c2(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8876:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    887a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    887e:	48 85 ed             	test   %rbp,%rbp
    8881:	0f 84 90 00 00 00    	je     8917 <f23+0x457>
    8887:	31 db                	xor    %ebx,%ebx
    8889:	45 31 ed             	xor    %r13d,%r13d
    888c:	e9 82 fd ff ff       	jmp    8613 <f23+0x153>
    8891:	48 89 df             	mov    %rbx,%rdi
    8894:	e8 37 cf ff ff       	call   57d0 <fwp_rc_forget_slot>
    8899:	e9 c6 fe ff ff       	jmp    8764 <f23+0x2a4>
    889e:	48 89 ef             	mov    %rbp,%rdi
    88a1:	e8 2a cf ff ff       	call   57d0 <fwp_rc_forget_slot>
    88a6:	e9 9c fd ff ff       	jmp    8647 <f23+0x187>
    88ab:	48 89 c8             	mov    %rcx,%rax
    88ae:	48 c1 e8 10          	shr    $0x10,%rax
    88b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    88b6:	48 8b 05 7b 53 06 00 	mov    0x6537b(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    88bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    88c1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    88c5:	48 85 ff             	test   %rdi,%rdi
    88c8:	0f 84 62 ff ff ff    	je     8830 <f23+0x370>
    88ce:	0f b6 02             	movzbl (%rdx),%eax
    88d1:	3c 02                	cmp    $0x2,%al
    88d3:	74 4a                	je     891f <f23+0x45f>
    88d5:	3c 01                	cmp    $0x1,%al
    88d7:	0f 85 53 ff ff ff    	jne    8830 <f23+0x370>
    88dd:	0f b7 c1             	movzwl %cx,%eax
    88e0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    88e3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    88e6:	48 0f af c1          	imul   %rcx,%rax
    88ea:	48 c1 e8 20          	shr    $0x20,%rax
    88ee:	48 39 d0             	cmp    %rdx,%rax
    88f1:	0f 83 39 ff ff ff    	jae    8830 <f23+0x370>
    88f7:	48 01 c7             	add    %rax,%rdi
    88fa:	0f b6 07             	movzbl (%rdi),%eax
    88fd:	84 c0                	test   %al,%al
    88ff:	0f 84 2b ff ff ff    	je     8830 <f23+0x370>
    8905:	45 31 ed             	xor    %r13d,%r13d
    8908:	e9 a3 fe ff ff       	jmp    87b0 <f23+0x2f0>
    890d:	e8 9e cd ff ff       	call   56b0 <fwp_rc_wide_dup>
    8912:	e9 b0 fe ff ff       	jmp    87c7 <f23+0x307>
    8917:	45 31 ed             	xor    %r13d,%r13d
    891a:	e9 8e fd ff ff       	jmp    86ad <f23+0x1ed>
    891f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8925:	49 89 cd             	mov    %rcx,%r13
    8928:	0f 85 02 ff ff ff    	jne    8830 <f23+0x370>
    892e:	0f b6 07             	movzbl (%rdi),%eax
    8931:	84 c0                	test   %al,%al
    8933:	0f 85 77 fe ff ff    	jne    87b0 <f23+0x2f0>
    8939:	e9 f2 fe ff ff       	jmp    8830 <f23+0x370>
    893e:	48 8d 3d a6 78 00 00 	lea    0x78a6(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    8945:	e8 06 bb ff ff       	call   4450 <fwp_trap>
    894a:	e8 01 ab ff ff       	call   3450 <__stack_chk_fail@plt>
    894f:	90                   	nop

0000000000008950 <fwp_owned_entry23>:
    8950:	f3 0f 1e fa          	endbr64
    8954:	48 8b 3f             	mov    (%rdi),%rdi
    8957:	e9 64 fb ff ff       	jmp    84c0 <f23>
    895c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008960 <e23>:
    8960:	f3 0f 1e fa          	endbr64
    8964:	53                   	push   %rbx
    8965:	48 8b 1f             	mov    (%rdi),%rbx
    8968:	48 89 df             	mov    %rbx,%rdi
    896b:	e8 40 e1 ff ff       	call   6ab0 <fwp_rc_share>
    8970:	48 89 df             	mov    %rbx,%rdi
    8973:	e8 48 fb ff ff       	call   84c0 <f23>
    8978:	48 89 c3             	mov    %rax,%rbx
    897b:	48 89 c7             	mov    %rax,%rdi
    897e:	e8 2d e1 ff ff       	call   6ab0 <fwp_rc_share>
    8983:	48 89 d8             	mov    %rbx,%rax
    8986:	5b                   	pop    %rbx
    8987:	c3                   	ret
    8988:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    898f:	00 

0000000000008990 <f12>:
    8990:	41 57                	push   %r15
    8992:	41 56                	push   %r14
    8994:	41 55                	push   %r13
    8996:	4c 8d 2d c3 eb ff ff 	lea    -0x143d(%rip),%r13        # 7560 <fwp_tape_scope_release>
    899d:	41 54                	push   %r12
    899f:	55                   	push   %rbp
    89a0:	53                   	push   %rbx
    89a1:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    89a8:	48 8b 05 29 5b 06 00 	mov    0x65b29(%rip),%rax        # 6e4d8 <fwp_cleanups>
    89af:	48 8b 15 62 52 06 00 	mov    0x65262(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    89b6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    89bd:	00 00 
    89bf:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    89c6:	00 
    89c7:	48 89 fd             	mov    %rdi,%rbp
    89ca:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
    89cf:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    89d6:	ff 
    89d7:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    89dc:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    89e1:	48 c1 e2 10          	shl    $0x10,%rdx
    89e5:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    89ea:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    89ef:	48 8d 05 1a b6 00 00 	lea    0xb61a(%rip),%rax        # 14010 <fc23>
    89f6:	48 2b 05 f3 51 06 00 	sub    0x651f3(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    89fd:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    8a02:	4c 89 3d cf 5a 06 00 	mov    %r15,0x65acf(%rip)        # 6e4d8 <fwp_cleanups>
    8a09:	48 39 d0             	cmp    %rdx,%rax
    8a0c:	73 6d                	jae    8a7b <f12+0xeb>
    8a0e:	48 89 c2             	mov    %rax,%rdx
    8a11:	48 c1 ea 10          	shr    $0x10,%rdx
    8a15:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a19:	48 8b 15 18 52 06 00 	mov    0x65218(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8a20:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a24:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8a28:	48 85 ff             	test   %rdi,%rdi
    8a2b:	74 4e                	je     8a7b <f12+0xeb>
    8a2d:	0f b6 0a             	movzbl (%rdx),%ecx
    8a30:	80 f9 02             	cmp    $0x2,%cl
    8a33:	0f 84 47 0f 00 00    	je     9980 <f12+0xff0>
    8a39:	80 f9 01             	cmp    $0x1,%cl
    8a3c:	75 3d                	jne    8a7b <f12+0xeb>
    8a3e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a41:	0f b7 c0             	movzwl %ax,%eax
    8a44:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a47:	48 0f af c1          	imul   %rcx,%rax
    8a4b:	48 c1 e8 20          	shr    $0x20,%rax
    8a4f:	48 39 d0             	cmp    %rdx,%rax
    8a52:	73 27                	jae    8a7b <f12+0xeb>
    8a54:	48 01 c7             	add    %rax,%rdi
    8a57:	0f b6 07             	movzbl (%rdi),%eax
    8a5a:	84 c0                	test   %al,%al
    8a5c:	74 1d                	je     8a7b <f12+0xeb>
    8a5e:	44 8b 05 a3 5a 06 00 	mov    0x65aa3(%rip),%r8d        # 6e508 <iteration_active>
    8a65:	45 85 c0             	test   %r8d,%r8d
    8a68:	0f 85 42 10 00 00    	jne    9ab0 <f12+0x1120>
    8a6e:	3c fd                	cmp    $0xfd,%al
    8a70:	0f 87 f6 11 00 00    	ja     9c6c <f12+0x12dc>
    8a76:	83 c0 01             	add    $0x1,%eax
    8a79:	88 07                	mov    %al,(%rdi)
    8a7b:	48 8d 3d 8e b5 00 00 	lea    0xb58e(%rip),%rdi        # 14010 <fc23>
    8a82:	e8 69 e7 ff ff       	call   71f0 <fwp_closure_drop>
    8a87:	48 85 ed             	test   %rbp,%rbp
    8a8a:	0f 84 31 11 00 00    	je     9bc1 <f12+0x1231>
    8a90:	48 89 e8             	mov    %rbp,%rax
    8a93:	31 d2                	xor    %edx,%edx
    8a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a9c:	00 00 00 00 
    8aa0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8aa4:	48 83 c2 01          	add    $0x1,%rdx
    8aa8:	48 85 c0             	test   %rax,%rax
    8aab:	75 f3                	jne    8aa0 <f12+0x110>
    8aad:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8ab4:	0f 87 40 12 00 00    	ja     9cfa <f12+0x136a>
    8aba:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    8abf:	8b 35 bb b5 00 00    	mov    0xb5bb(%rip),%esi        # 14080 <registered_finish.0>
    8ac5:	85 f6                	test   %esi,%esi
    8ac7:	0f 84 83 0e 00 00    	je     9950 <f12+0xfc0>
    8acd:	48 8b 1d 24 b6 01 00 	mov    0x1b624(%rip),%rbx        # 240f8 <fwp_tape_next_slot>
    8ad4:	4c 8b 25 2d b6 01 00 	mov    0x1b62d(%rip),%r12        # 24108 <fwp_ntapes>
    8adb:	4c 39 e3             	cmp    %r12,%rbx
    8ade:	0f 8d d4 00 00 00    	jge    8bb8 <f12+0x228>
    8ae4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8ae8:	48 03 05 21 b6 01 00 	add    0x1b621(%rip),%rax        # 24110 <fwp_tapes>
    8aef:	90                   	nop
    8af0:	8b 48 04             	mov    0x4(%rax),%ecx
    8af3:	85 c9                	test   %ecx,%ecx
    8af5:	75 0c                	jne    8b03 <f12+0x173>
    8af7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    8afd:	0f 86 b5 00 00 00    	jbe    8bb8 <f12+0x228>
    8b03:	48 83 c3 01          	add    $0x1,%rbx
    8b07:	48 83 c0 68          	add    $0x68,%rax
    8b0b:	4c 39 e3             	cmp    %r12,%rbx
    8b0e:	75 e0                	jne    8af0 <f12+0x160>
    8b10:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    8b17:	0f 8f 52 12 00 00    	jg     9d6f <f12+0x13df>
    8b1d:	4c 39 25 dc b5 01 00 	cmp    %r12,0x1b5dc(%rip)        # 24100 <fwp_tapes_cap>
    8b24:	4c 8b 35 e5 b5 01 00 	mov    0x1b5e5(%rip),%r14        # 24110 <fwp_tapes>
    8b2b:	75 4b                	jne    8b78 <f12+0x1e8>
    8b2d:	4d 85 e4             	test   %r12,%r12
    8b30:	0f 84 f0 10 00 00    	je     9c26 <f12+0x1296>
    8b36:	4b 8d 1c 24          	lea    (%r12,%r12,1),%rbx
    8b3a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    8b3f:	48 39 c3             	cmp    %rax,%rbx
    8b42:	48 0f 4f d8          	cmovg  %rax,%rbx
    8b46:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    8b4a:	31 d2                	xor    %edx,%edx
    8b4c:	4c 89 f7             	mov    %r14,%rdi
    8b4f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8b54:	e8 37 c6 ff ff       	call   5190 <ad_raw_realloc>
    8b59:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8b5e:	48 85 c0             	test   %rax,%rax
    8b61:	49 89 c6             	mov    %rax,%r14
    8b64:	0f 84 cb 11 00 00    	je     9d35 <f12+0x13a5>
    8b6a:	48 89 05 9f b5 01 00 	mov    %rax,0x1b59f(%rip)        # 24110 <fwp_tapes>
    8b71:	48 89 1d 88 b5 01 00 	mov    %rbx,0x1b588(%rip)        # 24100 <fwp_tapes_cap>
    8b78:	49 6b c4 68          	imul   $0x68,%r12,%rax
    8b7c:	4c 89 e3             	mov    %r12,%rbx
    8b7f:	4c 01 f0             	add    %r14,%rax
    8b82:	48 8d 78 08          	lea    0x8(%rax),%rdi
    8b86:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8b8d:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8b91:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8b98:	00 
    8b99:	48 29 f8             	sub    %rdi,%rax
    8b9c:	8d 48 68             	lea    0x68(%rax),%ecx
    8b9f:	31 c0                	xor    %eax,%eax
    8ba1:	c1 e9 03             	shr    $0x3,%ecx
    8ba4:	f3 48 ab             	rep stos %rax,(%rdi)
    8ba7:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    8bac:	48 89 05 55 b5 01 00 	mov    %rax,0x1b555(%rip)        # 24108 <fwp_ntapes>
    8bb3:	eb 13                	jmp    8bc8 <f12+0x238>
    8bb5:	0f 1f 00             	nopl   (%rax)
    8bb8:	49 39 dc             	cmp    %rbx,%r12
    8bbb:	0f 84 4f ff ff ff    	je     8b10 <f12+0x180>
    8bc1:	4c 8b 35 48 b5 01 00 	mov    0x1b548(%rip),%r14        # 24110 <fwp_tapes>
    8bc8:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    8bcc:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8bd0:	48 8d 3d 89 75 00 00 	lea    0x7589(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    8bd7:	0f 29 04 24          	movaps %xmm0,(%rsp)
    8bdb:	4d 01 f4             	add    %r14,%r12
    8bde:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    8be5:	00 00 
    8be7:	e8 a4 a7 ff ff       	call   3390 <getenv@plt>
    8bec:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    8bf1:	48 85 c0             	test   %rax,%rax
    8bf4:	74 09                	je     8bff <f12+0x26f>
    8bf6:	80 38 30             	cmpb   $0x30,(%rax)
    8bf9:	0f 84 01 07 00 00    	je     9300 <f12+0x970>
    8bff:	48 83 3d a1 b4 01 00 	cmpq   $0x0,0x1b4a1(%rip)        # 240a8 <fwp_tape_cached_bytes>
    8c06:	00 
    8c07:	0f 85 d3 0d 00 00    	jne    99e0 <f12+0x1050>
    8c0d:	41 8b 04 24          	mov    (%r12),%eax
    8c11:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    8c15:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    8c1c:	00 00 
    8c1e:	48 89 3d d3 b4 01 00 	mov    %rdi,0x1b4d3(%rip)        # 240f8 <fwp_tape_next_slot>
    8c25:	8d 70 01             	lea    0x1(%rax),%esi
    8c28:	48 8b 05 a9 58 06 00 	mov    0x658a9(%rip),%rax        # 6e4d8 <fwp_cleanups>
    8c2f:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    8c36:	00 00 
    8c38:	41 89 34 24          	mov    %esi,(%r12)
    8c3c:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    8c43:	ff ff 
    8c45:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    8c4b:	48 85 c0             	test   %rax,%rax
    8c4e:	75 1c                	jne    8c6c <f12+0x2dc>
    8c50:	e9 37 11 00 00       	jmp    9d8c <f12+0x13fc>
    8c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c5c:	00 00 00 00 
    8c60:	48 8b 00             	mov    (%rax),%rax
    8c63:	48 85 c0             	test   %rax,%rax
    8c66:	0f 84 20 11 00 00    	je     9d8c <f12+0x13fc>
    8c6c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8c70:	75 ee                	jne    8c60 <f12+0x2d0>
    8c72:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8c76:	89 d9                	mov    %ebx,%ecx
    8c78:	48 63 02             	movslq (%rdx),%rax
    8c7b:	49 89 54 24 50       	mov    %rdx,0x50(%r12)
    8c80:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8c85:	85 c0                	test   %eax,%eax
    8c87:	78 09                	js     8c92 <f12+0x302>
    8c89:	48 6b c0 68          	imul   $0x68,%rax,%rax
    8c8d:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8c92:	89 0a                	mov    %ecx,(%rdx)
    8c94:	48 89 e8             	mov    %rbp,%rax
    8c97:	31 c9                	xor    %ecx,%ecx
    8c99:	48 85 ed             	test   %rbp,%rbp
    8c9c:	0f 84 8e 0b 00 00    	je     9830 <f12+0xea0>
    8ca2:	0f 1f 00             	nopl   (%rax)
    8ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8cac:	00 00 00 00 
    8cb0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8cb4:	48 83 c1 01          	add    $0x1,%rcx
    8cb8:	48 85 c0             	test   %rax,%rax
    8cbb:	75 f3                	jne    8cb0 <f12+0x320>
    8cbd:	48 89 ea             	mov    %rbp,%rdx
    8cc0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8cc4:	48 83 c0 01          	add    $0x1,%rax
    8cc8:	48 85 d2             	test   %rdx,%rdx
    8ccb:	75 f3                	jne    8cc0 <f12+0x330>
    8ccd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8cd4:	ff ff 1f 
    8cd7:	48 39 c2             	cmp    %rax,%rdx
    8cda:	0f 82 26 10 00 00    	jb     9d06 <f12+0x1376>
    8ce0:	48 85 c9             	test   %rcx,%rcx
    8ce3:	0f 8e 47 0b 00 00    	jle    9830 <f12+0xea0>
    8ce9:	48 39 c1             	cmp    %rax,%rcx
    8cec:	48 0f 46 c1          	cmovbe %rcx,%rax
    8cf0:	49 89 c5             	mov    %rax,%r13
    8cf3:	48 c1 e8 3c          	shr    $0x3c,%rax
    8cf7:	0f 85 09 10 00 00    	jne    9d06 <f12+0x1376>
    8cfd:	48 c1 e6 10          	shl    $0x10,%rsi
    8d01:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    8d06:	48 09 fe             	or     %rdi,%rsi
    8d09:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8d10:	00 
    8d11:	49 89 f4             	mov    %rsi,%r12
    8d14:	be 02 00 00 00       	mov    $0x2,%esi
    8d19:	e8 f2 d1 ff ff       	call   5f10 <fwp_heap_alloc>
    8d1e:	4c 89 30             	mov    %r14,(%rax)
    8d21:	48 8b 15 f0 4e 06 00 	mov    0x64ef0(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8d28:	48 89 c3             	mov    %rax,%rbx
    8d2b:	48 2b 05 be 4e 06 00 	sub    0x64ebe(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8d32:	48 c1 e2 10          	shl    $0x10,%rdx
    8d36:	48 39 d0             	cmp    %rdx,%rax
    8d39:	0f 83 89 0b 00 00    	jae    98c8 <f12+0xf38>
    8d3f:	48 89 c2             	mov    %rax,%rdx
    8d42:	48 c1 ea 10          	shr    $0x10,%rdx
    8d46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d4a:	48 8b 15 e7 4e 06 00 	mov    0x64ee7(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8d51:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8d55:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8d59:	48 85 d2             	test   %rdx,%rdx
    8d5c:	74 38                	je     8d96 <f12+0x406>
    8d5e:	0f b6 31             	movzbl (%rcx),%esi
    8d61:	40 80 fe 02          	cmp    $0x2,%sil
    8d65:	0f 84 32 0b 00 00    	je     989d <f12+0xf0d>
    8d6b:	40 80 fe 01          	cmp    $0x1,%sil
    8d6f:	75 25                	jne    8d96 <f12+0x406>
    8d71:	8b 71 18             	mov    0x18(%rcx),%esi
    8d74:	0f b7 c0             	movzwl %ax,%eax
    8d77:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8d7a:	48 0f af c6          	imul   %rsi,%rax
    8d7e:	48 c1 e8 20          	shr    $0x20,%rax
    8d82:	48 39 c8             	cmp    %rcx,%rax
    8d85:	73 0f                	jae    8d96 <f12+0x406>
    8d87:	48 01 c2             	add    %rax,%rdx
    8d8a:	80 3a ff             	cmpb   $0xff,(%rdx)
    8d8d:	0f 84 a2 0e 00 00    	je     9c35 <f12+0x12a5>
    8d93:	c6 02 01             	movb   $0x1,(%rdx)
    8d96:	4d 85 ed             	test   %r13,%r13
    8d99:	74 58                	je     8df3 <f12+0x463>
    8d9b:	4c 89 e1             	mov    %r12,%rcx
    8d9e:	48 89 ea             	mov    %rbp,%rdx
    8da1:	31 c0                	xor    %eax,%eax
    8da3:	48 c1 e1 20          	shl    $0x20,%rcx
    8da7:	0f 1f 00             	nopl   (%rax)
    8daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8db1:	00 00 00 00 
    8db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dbc:	00 00 00 00 
    8dc0:	48 89 c6             	mov    %rax,%rsi
    8dc3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8dc8:	48 01 ce             	add    %rcx,%rsi
    8dcb:	0f 80 1c 0f 00 00    	jo     9ced <f12+0x135d>
    8dd1:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8dd6:	48 89 c6             	mov    %rax,%rsi
    8dd9:	48 83 c0 01          	add    $0x1,%rax
    8ddd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8de1:	48 c1 e6 04          	shl    $0x4,%rsi
    8de5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    8dea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8dee:	4c 39 e8             	cmp    %r13,%rax
    8df1:	72 cd                	jb     8dc0 <f12+0x430>
    8df3:	48 8b 03             	mov    (%rbx),%rax
    8df6:	48 d1 e8             	shr    $1,%rax
    8df9:	0f 84 e1 0a 00 00    	je     98e0 <f12+0xf50>
    8dff:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8e03:	48 89 d1             	mov    %rdx,%rcx
    8e06:	48 c1 e9 3c          	shr    $0x3c,%rcx
    8e0a:	0f 85 f6 0e 00 00    	jne    9d06 <f12+0x1376>
    8e10:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    8e14:	48 89 0c 24          	mov    %rcx,(%rsp)
    8e18:	48 85 d2             	test   %rdx,%rdx
    8e1b:	74 41                	je     8e5e <f12+0x4ce>
    8e1d:	48 c1 e0 04          	shl    $0x4,%rax
    8e21:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    8e25:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    8e2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e30:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    8e35:	49 8b 76 18          	mov    0x18(%r14),%rsi
    8e39:	49 83 c6 10          	add    $0x10,%r14
    8e3d:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    8e41:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    8e46:	e8 85 d8 ff ff       	call   66d0 <w107>
    8e4b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8e50:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8e54:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    8e59:	4d 39 f5             	cmp    %r14,%r13
    8e5c:	75 d2                	jne    8e30 <f12+0x4a0>
    8e5e:	48 8b 04 24          	mov    (%rsp),%rax
    8e62:	48 89 df             	mov    %rbx,%rdi
    8e65:	48 89 03             	mov    %rax,(%rbx)
    8e68:	e8 d3 d9 ff ff       	call   6840 <w164.constprop.0>
    8e6d:	48 89 df             	mov    %rbx,%rdi
    8e70:	49 63 dc             	movslq %r12d,%rbx
    8e73:	49 89 c5             	mov    %rax,%r13
    8e76:	e8 a5 ec ff ff       	call   7b20 <fwp_drop4>
    8e7b:	48 89 df             	mov    %rbx,%rdi
    8e7e:	e8 ad b8 ff ff       	call   4730 <fwp_tape_of>
    8e83:	48 89 c6             	mov    %rax,%rsi
    8e86:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8e8b:	0f 85 ef 0e 00 00    	jne    9d80 <f12+0x13f0>
    8e91:	48 89 c7             	mov    %rax,%rdi
    8e94:	e8 f7 ad ff ff       	call   3c90 <fwp_tape_unlink_scope>
    8e99:	4c 8b 46 48          	mov    0x48(%rsi),%r8
    8e9d:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8ea2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8ea9:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    8ead:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8eb1:	66 49 0f 6e f8       	movq   %r8,%xmm7
    8eb6:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    8ebb:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8ec0:	4c 8b 4e 40          	mov    0x40(%rsi),%r9
    8ec4:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8ec8:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8ece:	77 19                	ja     8ee9 <f12+0x559>
    8ed0:	41 0f b7 c4          	movzwl %r12w,%eax
    8ed4:	83 e8 01             	sub    $0x1,%eax
    8ed7:	48 98                	cltq
    8ed9:	48 3b 05 18 b2 01 00 	cmp    0x1b218(%rip),%rax        # 240f8 <fwp_tape_next_slot>
    8ee0:	7d 07                	jge    8ee9 <f12+0x559>
    8ee2:	48 89 05 0f b2 01 00 	mov    %rax,0x1b20f(%rip)        # 240f8 <fwp_tape_next_slot>
    8ee9:	48 8b 05 e8 55 06 00 	mov    0x655e8(%rip),%rax        # 6e4d8 <fwp_cleanups>
    8ef0:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8ef4:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    8efb:	00 
    8efc:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8f03:	00 
    8f04:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8f08:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8f0f:	00 
    8f10:	48 8d 05 49 c3 ff ff 	lea    -0x3cb7(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    8f17:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8f1e:	00 
    8f1f:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8f26:	00 
    8f27:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8f2b:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8f2f:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8f36:	00 
    8f37:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8f3e:	00 
    8f3f:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
    8f46:	00 
    8f47:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    8f4e:	00 
    8f4f:	48 89 05 82 55 06 00 	mov    %rax,0x65582(%rip)        # 6e4d8 <fwp_cleanups>
    8f56:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    8f5d:	00 
    8f5e:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    8f65:	00 
    8f66:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8f6d:	00 
    8f6e:	4d 85 ed             	test   %r13,%r13
    8f71:	0f 88 19 0a 00 00    	js     9990 <f12+0x1000>
    8f77:	4c 89 e8             	mov    %r13,%rax
    8f7a:	48 c1 f8 20          	sar    $0x20,%rax
    8f7e:	48 39 c3             	cmp    %rax,%rbx
    8f81:	0f 85 42 0d 00 00    	jne    9cc9 <f12+0x1339>
    8f87:	44 89 e9             	mov    %r13d,%ecx
    8f8a:	48 39 ca             	cmp    %rcx,%rdx
    8f8d:	0f 8e 42 0d 00 00    	jle    9cd5 <f12+0x1345>
    8f93:	49 39 ce             	cmp    %rcx,%r14
    8f96:	0f 8e 54 09 00 00    	jle    98f0 <f12+0xf60>
    8f9c:	4d 39 c6             	cmp    %r8,%r14
    8f9f:	0f 8e b3 0a 00 00    	jle    9a58 <f12+0x10c8>
    8fa5:	4c 89 f3             	mov    %r14,%rbx
    8fa8:	4d 85 c0             	test   %r8,%r8
    8fab:	4c 0f 44 c3          	cmove  %rbx,%r8
    8faf:	eb 24                	jmp    8fd5 <f12+0x645>
    8fb1:	0f 1f 40 00          	nopl   0x0(%rax)
    8fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8fbc:	00 00 00 00 
    8fc0:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    8fc4:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    8fcb:	48 89 d8             	mov    %rbx,%rax
    8fce:	48 0f 4c c2          	cmovl  %rdx,%rax
    8fd2:	49 89 c0             	mov    %rax,%r8
    8fd5:	49 39 d8             	cmp    %rbx,%r8
    8fd8:	7c e6                	jl     8fc0 <f12+0x630>
    8fda:	4d 85 c9             	test   %r9,%r9
    8fdd:	0f 84 0d 0b 00 00    	je     9af0 <f12+0x1160>
    8fe3:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    8fea:	00 
    8feb:	4c 89 cf             	mov    %r9,%rdi
    8fee:	ba 03 00 00 00       	mov    $0x3,%edx
    8ff3:	4c 89 04 24          	mov    %r8,(%rsp)
    8ff7:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8ffc:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9001:	e8 8a c1 ff ff       	call   5190 <ad_raw_realloc>
    9006:	4c 8b 04 24          	mov    (%rsp),%r8
    900a:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9010:	48 85 c0             	test   %rax,%rax
    9013:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9019:	49 89 c1             	mov    %rax,%r9
    901c:	0f 84 8e 0b 00 00    	je     9bb0 <f12+0x1220>
    9022:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
    9029:	00 
    902a:	4c 89 84 24 d0 00 00 	mov    %r8,0xd0(%rsp)
    9031:	00 
    9032:	48 85 db             	test   %rbx,%rbx
    9035:	0f 85 3e 0c 00 00    	jne    9c79 <f12+0x12e9>
    903b:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
    9042:	4d 85 ed             	test   %r13,%r13
    9045:	78 17                	js     905e <f12+0x6ce>
    9047:	44 89 e9             	mov    %r13d,%ecx
    904a:	f2 0f 10 05 8e 7d 00 	movsd  0x7d8e(%rip),%xmm0        # 10de0 <msg.4+0xb0>
    9051:	00 
    9052:	f2 41 0f 58 04 c9    	addsd  (%r9,%rcx,8),%xmm0
    9058:	f2 41 0f 11 04 c9    	movsd  %xmm0,(%r9,%rcx,8)
    905e:	4d 39 de             	cmp    %r11,%r14
    9061:	0f 8f 8a 00 00 00    	jg     90f1 <f12+0x761>
    9067:	0f 12 fb             	movhlps %xmm3,%xmm7
    906a:	66 49 0f 7e d0       	movq   %xmm2,%r8
    906f:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    9074:	4d 29 f3             	sub    %r14,%r11
    9077:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    907c:	0f 12 fa             	movhlps %xmm2,%xmm7
    907f:	4b 8d 3c f1          	lea    (%r9,%r14,8),%rdi
    9083:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    9088:	4a 8d 04 9e          	lea    (%rsi,%r11,4),%rax
    908c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9090:	48 29 f1             	sub    %rsi,%rcx
    9093:	4a 8d 14 db          	lea    (%rbx,%r11,8),%rdx
    9097:	48 29 df             	sub    %rbx,%rdi
    909a:	49 29 d8             	sub    %rbx,%r8
    909d:	eb 05                	jmp    90a4 <f12+0x714>
    909f:	90                   	nop
    90a0:	48 83 e8 04          	sub    $0x4,%rax
    90a4:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    90a9:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    90ad:	7a 02                	jp     90b1 <f12+0x721>
    90af:	74 37                	je     90e8 <f12+0x758>
    90b1:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    90b5:	45 85 db             	test   %r11d,%r11d
    90b8:	78 16                	js     90d0 <f12+0x740>
    90ba:	f2 41 0f 10 0c 10    	movsd  (%r8,%rdx,1),%xmm1
    90c0:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    90c4:	f2 43 0f 58 0c d9    	addsd  (%r9,%r11,8),%xmm1
    90ca:	f2 43 0f 11 0c d9    	movsd  %xmm1,(%r9,%r11,8)
    90d0:	4c 63 18             	movslq (%rax),%r11
    90d3:	45 85 db             	test   %r11d,%r11d
    90d6:	78 10                	js     90e8 <f12+0x758>
    90d8:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    90dc:	f2 43 0f 58 04 d9    	addsd  (%r9,%r11,8),%xmm0
    90e2:	f2 43 0f 11 04 d9    	movsd  %xmm0,(%r9,%r11,8)
    90e8:	48 83 ea 08          	sub    $0x8,%rdx
    90ec:	48 39 c6             	cmp    %rax,%rsi
    90ef:	75 af                	jne    90a0 <f12+0x710>
    90f1:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    90f8:	ff ff 1f 
    90fb:	4c 39 f0             	cmp    %r14,%rax
    90fe:	0f 82 0e 0c 00 00    	jb     9d12 <f12+0x1382>
    9104:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    910b:	00 
    910c:	be 02 00 00 00       	mov    $0x2,%esi
    9111:	4c 89 0c 24          	mov    %r9,(%rsp)
    9115:	e8 f6 cd ff ff       	call   5f10 <fwp_heap_alloc>
    911a:	4c 8b 0c 24          	mov    (%rsp),%r9
    911e:	4c 89 30             	mov    %r14,(%rax)
    9121:	49 89 c5             	mov    %rax,%r13
    9124:	31 c0                	xor    %eax,%eax
    9126:	4d 85 f6             	test   %r14,%r14
    9129:	74 27                	je     9152 <f12+0x7c2>
    912b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9132:	00 00 00 
    9135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    913c:	00 00 00 00 
    9140:	49 8b 14 c1          	mov    (%r9,%rax,8),%rdx
    9144:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    9149:	48 83 c0 01          	add    $0x1,%rax
    914d:	49 39 c6             	cmp    %rax,%r14
    9150:	75 ee                	jne    9140 <f12+0x7b0>
    9152:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    9159:	00 
    915a:	4c 89 e7             	mov    %r12,%rdi
    915d:	48 89 0d 74 53 06 00 	mov    %rcx,0x65374(%rip)        # 6e4d8 <fwp_cleanups>
    9164:	48 89 0c 24          	mov    %rcx,(%rsp)
    9168:	e8 f3 c0 ff ff       	call   5260 <fwp_tape_buffers_release>
    916d:	48 8b 15 a4 4a 06 00 	mov    0x64aa4(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    9174:	4c 89 e8             	mov    %r13,%rax
    9177:	48 8b 0c 24          	mov    (%rsp),%rcx
    917b:	48 2b 05 6e 4a 06 00 	sub    0x64a6e(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9182:	48 c1 e2 10          	shl    $0x10,%rdx
    9186:	48 39 d0             	cmp    %rdx,%rax
    9189:	73 57                	jae    91e2 <f12+0x852>
    918b:	48 89 c2             	mov    %rax,%rdx
    918e:	48 c1 ea 10          	shr    $0x10,%rdx
    9192:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    9196:	48 8b 15 9b 4a 06 00 	mov    0x64a9b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    919d:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    91a1:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    91a5:	48 85 db             	test   %rbx,%rbx
    91a8:	74 38                	je     91e2 <f12+0x852>
    91aa:	0f b6 32             	movzbl (%rdx),%esi
    91ad:	40 80 fe 02          	cmp    $0x2,%sil
    91b1:	0f 84 09 08 00 00    	je     99c0 <f12+0x1030>
    91b7:	40 80 fe 01          	cmp    $0x1,%sil
    91bb:	75 25                	jne    91e2 <f12+0x852>
    91bd:	8b 72 18             	mov    0x18(%rdx),%esi
    91c0:	0f b7 c0             	movzwl %ax,%eax
    91c3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    91c6:	48 0f af c6          	imul   %rsi,%rax
    91ca:	48 c1 e8 20          	shr    $0x20,%rax
    91ce:	48 39 d0             	cmp    %rdx,%rax
    91d1:	73 0f                	jae    91e2 <f12+0x852>
    91d3:	48 01 c3             	add    %rax,%rbx
    91d6:	80 3b ff             	cmpb   $0xff,(%rbx)
    91d9:	0f 84 6b 0a 00 00    	je     9c4a <f12+0x12ba>
    91df:	c6 03 01             	movb   $0x1,(%rbx)
    91e2:	4c 39 f9             	cmp    %r15,%rcx
    91e5:	0f 85 60 a5 ff ff    	jne    374b <f12.cold>
    91eb:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    91f0:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    91f5:	48 89 05 dc 52 06 00 	mov    %rax,0x652dc(%rip)        # 6e4d8 <fwp_cleanups>
    91fc:	e8 5f e3 ff ff       	call   7560 <fwp_tape_scope_release>
    9201:	49 8b 45 00          	mov    0x0(%r13),%rax
    9205:	49 89 c4             	mov    %rax,%r12
    9208:	49 0f ba f4 3f       	btr    $0x3f,%r12
    920d:	48 85 c0             	test   %rax,%rax
    9210:	0f 88 6a 05 00 00    	js     9780 <f12+0xdf0>
    9216:	48 8b 15 fb 49 06 00 	mov    0x649fb(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    921d:	4c 89 e8             	mov    %r13,%rax
    9220:	48 2b 05 c9 49 06 00 	sub    0x649c9(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9227:	48 c1 e2 10          	shl    $0x10,%rdx
    922b:	48 39 d0             	cmp    %rdx,%rax
    922e:	0f 83 4c 05 00 00    	jae    9780 <f12+0xdf0>
    9234:	48 89 c2             	mov    %rax,%rdx
    9237:	48 c1 ea 10          	shr    $0x10,%rdx
    923b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    923f:	48 8b 15 f2 49 06 00 	mov    0x649f2(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    9246:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    924a:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    924e:	48 85 c9             	test   %rcx,%rcx
    9251:	0f 84 29 05 00 00    	je     9780 <f12+0xdf0>
    9257:	0f b6 32             	movzbl (%rdx),%esi
    925a:	40 80 fe 02          	cmp    $0x2,%sil
    925e:	0f 84 0c 05 00 00    	je     9770 <f12+0xde0>
    9264:	40 80 fe 01          	cmp    $0x1,%sil
    9268:	0f 85 12 05 00 00    	jne    9780 <f12+0xdf0>
    926e:	8b 72 18             	mov    0x18(%rdx),%esi
    9271:	0f b7 c0             	movzwl %ax,%eax
    9274:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9277:	48 0f af c6          	imul   %rsi,%rax
    927b:	48 c1 e8 20          	shr    $0x20,%rax
    927f:	48 39 d0             	cmp    %rdx,%rax
    9282:	0f 83 f8 04 00 00    	jae    9780 <f12+0xdf0>
    9288:	48 01 c1             	add    %rax,%rcx
    928b:	80 39 01             	cmpb   $0x1,(%rcx)
    928e:	0f 85 ec 04 00 00    	jne    9780 <f12+0xdf0>
    9294:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    9299:	4d 89 ef             	mov    %r13,%r15
    929c:	31 ff                	xor    %edi,%edi
    929e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    92a3:	f2 0f 10 0d 45 7b 00 	movsd  0x7b45(%rip),%xmm1        # 10df0 <msg.4+0xc0>
    92aa:	00 
    92ab:	48 8d 50 08          	lea    0x8(%rax),%rdx
    92af:	31 c0                	xor    %eax,%eax
    92b1:	4d 85 e4             	test   %r12,%r12
    92b4:	75 2f                	jne    92e5 <f12+0x955>
    92b6:	eb 58                	jmp    9310 <f12+0x980>
    92b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92bf:	00 
    92c0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    92c4:	0f 88 17 0a 00 00    	js     9ce1 <f12+0x1351>
    92ca:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    92cf:	48 83 c0 01          	add    $0x1,%rax
    92d3:	48 83 c2 08          	add    $0x8,%rdx
    92d7:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    92db:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    92e0:	49 39 c4             	cmp    %rax,%r12
    92e3:	74 2b                	je     9310 <f12+0x980>
    92e5:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    92e9:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    92ee:	79 d0                	jns    92c0 <f12+0x930>
    92f0:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    92f4:	eb ca                	jmp    92c0 <f12+0x930>
    92f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92fd:	00 00 00 
    9300:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9304:	0f 84 03 f9 ff ff    	je     8c0d <f12+0x27d>
    930a:	e9 f0 f8 ff ff       	jmp    8bff <f12+0x26f>
    930f:	90                   	nop
    9310:	e8 0b e8 ff ff       	call   7b20 <fwp_drop4>
    9315:	48 89 e8             	mov    %rbp,%rax
    9318:	31 d2                	xor    %edx,%edx
    931a:	48 85 ed             	test   %rbp,%rbp
    931d:	0f 84 a7 08 00 00    	je     9bca <f12+0x123a>
    9323:	66 90                	xchg   %ax,%ax
    9325:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    932c:	00 00 00 00 
    9330:	48 8b 40 10          	mov    0x10(%rax),%rax
    9334:	48 83 c2 01          	add    $0x1,%rdx
    9338:	48 85 c0             	test   %rax,%rax
    933b:	75 f3                	jne    9330 <f12+0x9a0>
    933d:	49 8b 07             	mov    (%r15),%rax
    9340:	49 89 c5             	mov    %rax,%r13
    9343:	49 0f ba f5 3f       	btr    $0x3f,%r13
    9348:	48 85 c0             	test   %rax,%rax
    934b:	0f 88 81 03 00 00    	js     96d2 <f12+0xd42>
    9351:	48 8b 05 c0 48 06 00 	mov    0x648c0(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    9358:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    935d:	48 2b 0d 8c 48 06 00 	sub    0x6488c(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    9364:	48 c1 e0 10          	shl    $0x10,%rax
    9368:	48 39 c1             	cmp    %rax,%rcx
    936b:	0f 83 61 03 00 00    	jae    96d2 <f12+0xd42>
    9371:	48 89 c8             	mov    %rcx,%rax
    9374:	48 c1 e8 10          	shr    $0x10,%rax
    9378:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    937c:	48 8b 05 b5 48 06 00 	mov    0x648b5(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    9383:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9387:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    938b:	48 85 ff             	test   %rdi,%rdi
    938e:	0f 84 3e 03 00 00    	je     96d2 <f12+0xd42>
    9394:	0f b6 06             	movzbl (%rsi),%eax
    9397:	3c 02                	cmp    $0x2,%al
    9399:	0f 84 21 03 00 00    	je     96c0 <f12+0xd30>
    939f:	3c 01                	cmp    $0x1,%al
    93a1:	0f 85 22 03 00 00    	jne    96c9 <f12+0xd39>
    93a7:	8b 46 18             	mov    0x18(%rsi),%eax
    93aa:	0f b7 c9             	movzwl %cx,%ecx
    93ad:	48 0f af c8          	imul   %rax,%rcx
    93b1:	8b 46 1c             	mov    0x1c(%rsi),%eax
    93b4:	48 c1 e9 20          	shr    $0x20,%rcx
    93b8:	48 39 c1             	cmp    %rax,%rcx
    93bb:	0f 83 08 03 00 00    	jae    96c9 <f12+0xd39>
    93c1:	48 01 cf             	add    %rcx,%rdi
    93c4:	80 3f 01             	cmpb   $0x1,(%rdi)
    93c7:	0f 85 fc 02 00 00    	jne    96c9 <f12+0xd39>
    93cd:	4c 39 ea             	cmp    %r13,%rdx
    93d0:	4c 89 e8             	mov    %r13,%rax
    93d3:	48 0f 46 c2          	cmovbe %rdx,%rax
    93d7:	48 85 c0             	test   %rax,%rax
    93da:	0f 84 12 09 00 00    	je     9cf2 <f12+0x1362>
    93e0:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    93e7:	00 
    93e8:	4d 8d 77 08          	lea    0x8(%r15),%r14
    93ec:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    93f1:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    93f8:	00 
    93f9:	48 89 e9             	mov    %rbp,%rcx
    93fc:	31 d2                	xor    %edx,%edx
    93fe:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    9402:	eb 59                	jmp    945d <f12+0xacd>
    9404:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9409:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9410:	00 00 00 00 
    9414:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    941b:	00 00 00 00 
    941f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9426:	00 00 00 00 
    942a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9431:	00 00 00 00 
    9435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    943c:	00 00 00 00 
    9440:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9445:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    944a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9450:	48 83 c2 08          	add    $0x8,%rdx
    9454:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9458:	49 39 d0             	cmp    %rdx,%r8
    945b:	74 1b                	je     9478 <f12+0xae8>
    945d:	48 89 fe             	mov    %rdi,%rsi
    9460:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9464:	79 da                	jns    9440 <f12+0xab0>
    9466:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    946b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    946f:	eb cf                	jmp    9440 <f12+0xab0>
    9471:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9478:	48 85 ed             	test   %rbp,%rbp
    947b:	0f 84 40 08 00 00    	je     9cc1 <f12+0x1331>
    9481:	4c 8b 05 90 47 06 00 	mov    0x64790(%rip),%r8        # 6dc18 <fwp_heap+0x13d8>
    9488:	4c 8b 0d 61 47 06 00 	mov    0x64761(%rip),%r9        # 6dbf0 <fwp_heap+0x13b0>
    948f:	48 89 e9             	mov    %rbp,%rcx
    9492:	45 31 ed             	xor    %r13d,%r13d
    9495:	4c 8b 15 9c 47 06 00 	mov    0x6479c(%rip),%r10        # 6dc38 <fwp_heap+0x13f8>
    949c:	49 c1 e0 10          	shl    $0x10,%r8
    94a0:	eb 1c                	jmp    94be <f12+0xb2e>
    94a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    94a8:	49 83 c5 01          	add    $0x1,%r13
    94ac:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    94b0:	49 39 c5             	cmp    %rax,%r13
    94b3:	0f 83 67 01 00 00    	jae    9620 <f12+0xc90>
    94b9:	48 85 c9             	test   %rcx,%rcx
    94bc:	74 56                	je     9514 <f12+0xb84>
    94be:	48 89 ca             	mov    %rcx,%rdx
    94c1:	4c 29 ca             	sub    %r9,%rdx
    94c4:	4c 39 c2             	cmp    %r8,%rdx
    94c7:	73 4b                	jae    9514 <f12+0xb84>
    94c9:	48 89 d6             	mov    %rdx,%rsi
    94cc:	48 c1 ee 10          	shr    $0x10,%rsi
    94d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    94d4:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    94d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    94dc:	48 85 ff             	test   %rdi,%rdi
    94df:	74 33                	je     9514 <f12+0xb84>
    94e1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    94e5:	41 80 fb 02          	cmp    $0x2,%r11b
    94e9:	0f 84 19 01 00 00    	je     9608 <f12+0xc78>
    94ef:	41 80 fb 01          	cmp    $0x1,%r11b
    94f3:	75 1f                	jne    9514 <f12+0xb84>
    94f5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    94f9:	0f b7 d2             	movzwl %dx,%edx
    94fc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    94ff:	49 0f af d3          	imul   %r11,%rdx
    9503:	48 c1 ea 20          	shr    $0x20,%rdx
    9507:	48 39 f2             	cmp    %rsi,%rdx
    950a:	73 08                	jae    9514 <f12+0xb84>
    950c:	48 01 d7             	add    %rdx,%rdi
    950f:	80 3f 01             	cmpb   $0x1,(%rdi)
    9512:	74 94                	je     94a8 <f12+0xb18>
    9514:	49 39 c5             	cmp    %rax,%r13
    9517:	0f 83 03 01 00 00    	jae    9620 <f12+0xc90>
    951d:	49 89 c7             	mov    %rax,%r15
    9520:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    9527:	00 
    9528:	45 31 e4             	xor    %r12d,%r12d
    952b:	48 89 04 24          	mov    %rax,(%rsp)
    952f:	48 8d 1d 0a 33 06 00 	lea    0x6330a(%rip),%rbx        # 6c840 <fwp_heap>
    9536:	eb 3a                	jmp    9572 <f12+0xbe2>
    9538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    953f:	00 
    9540:	41 80 f9 01          	cmp    $0x1,%r9b
    9544:	75 27                	jne    956d <f12+0xbdd>
    9546:	45 8b 48 18          	mov    0x18(%r8),%r9d
    954a:	0f b7 c0             	movzwl %ax,%eax
    954d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9551:	49 0f af c1          	imul   %r9,%rax
    9555:	48 c1 e8 20          	shr    $0x20,%rax
    9559:	4c 39 c0             	cmp    %r8,%rax
    955c:	73 0f                	jae    956d <f12+0xbdd>
    955e:	48 01 c7             	add    %rax,%rdi
    9561:	80 3f ff             	cmpb   $0xff,(%rdi)
    9564:	0f 84 46 03 00 00    	je     98b0 <f12+0xf20>
    956a:	c6 07 01             	movb   $0x1,(%rdi)
    956d:	4d 39 fd             	cmp    %r15,%r13
    9570:	73 7e                	jae    95f0 <f12+0xc60>
    9572:	49 83 ef 01          	sub    $0x1,%r15
    9576:	66 49 0f 6e f4       	movq   %r12,%xmm6
    957b:	48 8b 34 24          	mov    (%rsp),%rsi
    957f:	bf 01 00 00 00       	mov    $0x1,%edi
    9584:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    958a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    958e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9595:	00 
    9596:	e8 25 d3 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    959b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    95a2:	49 89 c4             	mov    %rax,%r12
    95a5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    95ac:	48 c1 e7 10          	shl    $0x10,%rdi
    95b0:	48 39 f8             	cmp    %rdi,%rax
    95b3:	73 b8                	jae    956d <f12+0xbdd>
    95b5:	48 89 c7             	mov    %rax,%rdi
    95b8:	48 c1 ef 10          	shr    $0x10,%rdi
    95bc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    95c0:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    95c7:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    95cb:	49 8b 78 20          	mov    0x20(%r8),%rdi
    95cf:	48 85 ff             	test   %rdi,%rdi
    95d2:	74 99                	je     956d <f12+0xbdd>
    95d4:	45 0f b6 08          	movzbl (%r8),%r9d
    95d8:	41 80 f9 02          	cmp    $0x2,%r9b
    95dc:	0f 85 5e ff ff ff    	jne    9540 <f12+0xbb0>
    95e2:	66 85 c0             	test   %ax,%ax
    95e5:	0f 84 76 ff ff ff    	je     9561 <f12+0xbd1>
    95eb:	4d 39 fd             	cmp    %r15,%r13
    95ee:	72 82                	jb     9572 <f12+0xbe2>
    95f0:	4d 85 ed             	test   %r13,%r13
    95f3:	75 2e                	jne    9623 <f12+0xc93>
    95f5:	8b 44 24 20          	mov    0x20(%rsp),%eax
    95f9:	85 c0                	test   %eax,%eax
    95fb:	4d 0f 45 f5          	cmovne %r13,%r14
    95ff:	eb 6f                	jmp    9670 <f12+0xce0>
    9601:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9608:	66 85 d2             	test   %dx,%dx
    960b:	0f 84 fe fe ff ff    	je     950f <f12+0xb7f>
    9611:	49 39 c5             	cmp    %rax,%r13
    9614:	0f 82 03 ff ff ff    	jb     951d <f12+0xb8d>
    961a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9620:	45 31 e4             	xor    %r12d,%r12d
    9623:	4c 89 f2             	mov    %r14,%rdx
    9626:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    962a:	48 89 e8             	mov    %rbp,%rax
    962d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9634:	00 
    9635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    963c:	00 00 00 00 
    9640:	48 8b 0a             	mov    (%rdx),%rcx
    9643:	48 83 c2 08          	add    $0x8,%rdx
    9647:	48 89 c7             	mov    %rax,%rdi
    964a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    964e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9652:	49 39 d0             	cmp    %rdx,%r8
    9655:	75 e9                	jne    9640 <f12+0xcb0>
    9657:	8b 54 24 20          	mov    0x20(%rsp),%edx
    965b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    965f:	85 d2                	test   %edx,%edx
    9661:	0f 84 69 03 00 00    	je     99d0 <f12+0x1040>
    9667:	49 89 ec             	mov    %rbp,%r12
    966a:	45 31 f6             	xor    %r14d,%r14d
    966d:	48 89 c5             	mov    %rax,%rbp
    9670:	4c 89 f7             	mov    %r14,%rdi
    9673:	e8 98 c3 ff ff       	call   5a10 <fwp_mem_free>
    9678:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    967d:	e8 9e e4 ff ff       	call   7b20 <fwp_drop4>
    9682:	48 89 ef             	mov    %rbp,%rdi
    9685:	e8 86 d8 ff ff       	call   6f10 <fwp_drop0>
    968a:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    9691:	00 
    9692:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9699:	00 00 
    969b:	0f 85 da 06 00 00    	jne    9d7b <f12+0x13eb>
    96a1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    96a8:	4c 89 e0             	mov    %r12,%rax
    96ab:	5b                   	pop    %rbx
    96ac:	5d                   	pop    %rbp
    96ad:	41 5c                	pop    %r12
    96af:	41 5d                	pop    %r13
    96b1:	41 5e                	pop    %r14
    96b3:	41 5f                	pop    %r15
    96b5:	c3                   	ret
    96b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    96bd:	00 00 00 
    96c0:	66 85 c9             	test   %cx,%cx
    96c3:	0f 84 fb fc ff ff    	je     93c4 <f12+0xa34>
    96c9:	48 85 ed             	test   %rbp,%rbp
    96cc:	0f 84 eb 03 00 00    	je     9abd <f12+0x112d>
    96d2:	48 89 e8             	mov    %rbp,%rax
    96d5:	45 31 e4             	xor    %r12d,%r12d
    96d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    96df:	00 
    96e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    96e4:	4c 89 e2             	mov    %r12,%rdx
    96e7:	49 83 c4 01          	add    $0x1,%r12
    96eb:	48 85 c0             	test   %rax,%rax
    96ee:	75 f0                	jne    96e0 <f12+0xd50>
    96f0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    96f7:	ff ff 1f 
    96fa:	4c 39 e0             	cmp    %r12,%rax
    96fd:	0f 82 03 06 00 00    	jb     9d06 <f12+0x1376>
    9703:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    970a:	00 
    970b:	be 02 00 00 00       	mov    $0x2,%esi
    9710:	e8 fb c7 ff ff       	call   5f10 <fwp_heap_alloc>
    9715:	4d 39 e5             	cmp    %r12,%r13
    9718:	48 89 ea             	mov    %rbp,%rdx
    971b:	49 89 c6             	mov    %rax,%r14
    971e:	4c 89 e0             	mov    %r12,%rax
    9721:	49 0f 46 c5          	cmovbe %r13,%rax
    9725:	4c 89 f1             	mov    %r14,%rcx
    9728:	66 90                	xchg   %ax,%ax
    972a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9731:	00 00 00 00 
    9735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    973c:	00 00 00 00 
    9740:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9744:	48 83 c1 08          	add    $0x8,%rcx
    9748:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    974c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9750:	48 85 d2             	test   %rdx,%rdx
    9753:	75 eb                	jne    9740 <f12+0xdb0>
    9755:	48 85 c0             	test   %rax,%rax
    9758:	0f 84 71 03 00 00    	je     9acf <f12+0x113f>
    975e:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    9765:	00 
    9766:	e9 81 fc ff ff       	jmp    93ec <f12+0xa5c>
    976b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9770:	66 85 c0             	test   %ax,%ax
    9773:	0f 84 12 fb ff ff    	je     928b <f12+0x8fb>
    9779:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9780:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9787:	ff ff 1f 
    978a:	4c 39 e0             	cmp    %r12,%rax
    978d:	0f 82 7f 05 00 00    	jb     9d12 <f12+0x1382>
    9793:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    979a:	00 
    979b:	be 01 00 00 00       	mov    $0x1,%esi
    97a0:	e8 6b c7 ff ff       	call   5f10 <fwp_heap_alloc>
    97a5:	4c 89 20             	mov    %r12,(%rax)
    97a8:	48 8b 15 69 44 06 00 	mov    0x64469(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    97af:	49 89 c7             	mov    %rax,%r15
    97b2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    97b7:	48 2b 05 32 44 06 00 	sub    0x64432(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    97be:	48 c1 e2 10          	shl    $0x10,%rdx
    97c2:	48 39 d0             	cmp    %rdx,%rax
    97c5:	73 57                	jae    981e <f12+0xe8e>
    97c7:	48 89 c2             	mov    %rax,%rdx
    97ca:	48 c1 ea 10          	shr    $0x10,%rdx
    97ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97d2:	48 8b 15 5f 44 06 00 	mov    0x6445f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    97d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97dd:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    97e1:	4d 85 f6             	test   %r14,%r14
    97e4:	74 38                	je     981e <f12+0xe8e>
    97e6:	0f b6 0a             	movzbl (%rdx),%ecx
    97e9:	80 f9 02             	cmp    $0x2,%cl
    97ec:	0f 84 ee 02 00 00    	je     9ae0 <f12+0x1150>
    97f2:	80 f9 01             	cmp    $0x1,%cl
    97f5:	75 27                	jne    981e <f12+0xe8e>
    97f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97fa:	0f b7 c0             	movzwl %ax,%eax
    97fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9800:	48 0f af c1          	imul   %rcx,%rax
    9804:	48 c1 e8 20          	shr    $0x20,%rax
    9808:	48 39 d0             	cmp    %rdx,%rax
    980b:	73 11                	jae    981e <f12+0xe8e>
    980d:	49 01 c6             	add    %rax,%r14
    9810:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9814:	0f 84 45 04 00 00    	je     9c5f <f12+0x12cf>
    981a:	41 c6 06 01          	movb   $0x1,(%r14)
    981e:	4c 89 ef             	mov    %r13,%rdi
    9821:	e9 78 fa ff ff       	jmp    929e <f12+0x90e>
    9826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    982d:	00 00 00 
    9830:	48 c1 e6 10          	shl    $0x10,%rsi
    9834:	48 09 fe             	or     %rdi,%rsi
    9837:	bf 08 00 00 00       	mov    $0x8,%edi
    983c:	49 89 f4             	mov    %rsi,%r12
    983f:	be 02 00 00 00       	mov    $0x2,%esi
    9844:	e8 c7 c6 ff ff       	call   5f10 <fwp_heap_alloc>
    9849:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9850:	48 8b 15 c1 43 06 00 	mov    0x643c1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    9857:	48 89 c3             	mov    %rax,%rbx
    985a:	48 2b 05 8f 43 06 00 	sub    0x6438f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9861:	48 c1 e2 10          	shl    $0x10,%rdx
    9865:	48 39 d0             	cmp    %rdx,%rax
    9868:	73 76                	jae    98e0 <f12+0xf50>
    986a:	48 89 c2             	mov    %rax,%rdx
    986d:	48 c1 ea 10          	shr    $0x10,%rdx
    9871:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9875:	48 8b 15 bc 43 06 00 	mov    0x643bc(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    987c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9880:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9884:	48 85 d2             	test   %rdx,%rdx
    9887:	0f 84 66 f5 ff ff    	je     8df3 <f12+0x463>
    988d:	0f b6 31             	movzbl (%rcx),%esi
    9890:	45 31 ed             	xor    %r13d,%r13d
    9893:	40 80 fe 02          	cmp    $0x2,%sil
    9897:	0f 85 ce f4 ff ff    	jne    8d6b <f12+0x3db>
    989d:	66 85 c0             	test   %ax,%ax
    98a0:	0f 85 f0 f4 ff ff    	jne    8d96 <f12+0x406>
    98a6:	e9 df f4 ff ff       	jmp    8d8a <f12+0x3fa>
    98ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    98b0:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    98b5:	e8 16 bf ff ff       	call   57d0 <fwp_rc_forget_slot>
    98ba:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    98bf:	e9 a6 fc ff ff       	jmp    956a <f12+0xbda>
    98c4:	0f 1f 40 00          	nopl   0x0(%rax)
    98c8:	4d 85 ed             	test   %r13,%r13
    98cb:	0f 85 ca f4 ff ff    	jne    8d9b <f12+0x40b>
    98d1:	0f 1f 40 00          	nopl   0x0(%rax)
    98d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98dc:	00 00 00 00 
    98e0:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    98e7:	00 
    98e8:	e9 71 f5 ff ff       	jmp    8e5e <f12+0x4ce>
    98ed:	0f 1f 00             	nopl   (%rax)
    98f0:	48 8d 59 01          	lea    0x1(%rcx),%rbx
    98f4:	49 39 d8             	cmp    %rbx,%r8
    98f7:	0f 8c ab f6 ff ff    	jl     8fa8 <f12+0x618>
    98fd:	4d 85 c9             	test   %r9,%r9
    9900:	0f 84 18 04 00 00    	je     9d1e <f12+0x138e>
    9906:	4c 89 cf             	mov    %r9,%rdi
    9909:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9910:	00 
    9911:	31 f6                	xor    %esi,%esi
    9913:	0f 29 14 24          	movaps %xmm2,(%rsp)
    9917:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    991c:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
    9921:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    9926:	e8 85 9b ff ff       	call   34b0 <memset@plt>
    992b:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    9930:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    9936:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    993b:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
    9940:	49 89 c1             	mov    %rax,%r9
    9943:	e9 02 f7 ff ff       	jmp    904a <f12+0x6ba>
    9948:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    994f:	00 
    9950:	48 8d 3d e9 da ff ff 	lea    -0x2517(%rip),%rdi        # 7440 <fwp_tape_finish>
    9957:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    995c:	e8 af 59 00 00       	call   f310 <atexit>
    9961:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9966:	85 c0                	test   %eax,%eax
    9968:	0f 85 c7 03 00 00    	jne    9d35 <f12+0x13a5>
    996e:	c7 05 08 a7 00 00 01 	movl   $0x1,0xa708(%rip)        # 14080 <registered_finish.0>
    9975:	00 00 00 
    9978:	e9 50 f1 ff ff       	jmp    8acd <f12+0x13d>
    997d:	0f 1f 00             	nopl   (%rax)
    9980:	66 85 c0             	test   %ax,%ax
    9983:	0f 85 f2 f0 ff ff    	jne    8a7b <f12+0xeb>
    9989:	e9 c9 f0 ff ff       	jmp    8a57 <f12+0xc7>
    998e:	66 90                	xchg   %ax,%ax
    9990:	4d 39 c6             	cmp    %r8,%r14
    9993:	0f 8f 0c f6 ff ff    	jg     8fa5 <f12+0x615>
    9999:	4d 85 f6             	test   %r14,%r14
    999c:	74 12                	je     99b0 <f12+0x1020>
    999e:	4d 85 c9             	test   %r9,%r9
    99a1:	0f 84 77 03 00 00    	je     9d1e <f12+0x138e>
    99a7:	4d 85 f6             	test   %r14,%r14
    99aa:	0f 85 c6 02 00 00    	jne    9c76 <f12+0x12e6>
    99b0:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
    99b7:	e9 a2 f6 ff ff       	jmp    905e <f12+0x6ce>
    99bc:	0f 1f 40 00          	nopl   0x0(%rax)
    99c0:	66 85 c0             	test   %ax,%ax
    99c3:	0f 85 19 f8 ff ff    	jne    91e2 <f12+0x852>
    99c9:	e9 08 f8 ff ff       	jmp    91d6 <f12+0x846>
    99ce:	66 90                	xchg   %ax,%ax
    99d0:	49 89 ec             	mov    %rbp,%r12
    99d3:	48 89 c5             	mov    %rax,%rbp
    99d6:	e9 95 fc ff ff       	jmp    9670 <f12+0xce0>
    99db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    99e0:	66 0f 6f 0d d8 a6 01 	movdqa 0x1a6d8(%rip),%xmm1        # 240c0 <fwp_tape_workspace>
    99e7:	00 
    99e8:	48 c7 05 b5 a6 01 00 	movq   $0x0,0x1a6b5(%rip)        # 240a8 <fwp_tape_cached_bytes>
    99ef:	00 00 00 00 
    99f3:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    99f9:	48 8b 05 e0 a6 01 00 	mov    0x1a6e0(%rip),%rax        # 240e0 <fwp_tape_workspace+0x20>
    9a00:	66 0f 6f 0d c8 a6 01 	movdqa 0x1a6c8(%rip),%xmm1        # 240d0 <fwp_tape_workspace+0x10>
    9a07:	00 
    9a08:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    9a0d:	48 8b 05 d4 a6 01 00 	mov    0x1a6d4(%rip),%rax        # 240e8 <fwp_tape_workspace+0x28>
    9a14:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    9a1a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9a1e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    9a23:	48 8b 05 c6 a6 01 00 	mov    0x1a6c6(%rip),%rax        # 240f0 <fwp_tape_workspace+0x30>
    9a2a:	0f 29 0d 8f a6 01 00 	movaps %xmm1,0x1a68f(%rip)        # 240c0 <fwp_tape_workspace>
    9a31:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    9a36:	0f 29 0d 93 a6 01 00 	movaps %xmm1,0x1a693(%rip)        # 240d0 <fwp_tape_workspace+0x10>
    9a3d:	48 c7 05 a8 a6 01 00 	movq   $0x0,0x1a6a8(%rip)        # 240f0 <fwp_tape_workspace+0x30>
    9a44:	00 00 00 00 
    9a48:	0f 29 0d 91 a6 01 00 	movaps %xmm1,0x1a691(%rip)        # 240e0 <fwp_tape_workspace+0x20>
    9a4f:	e9 b9 f1 ff ff       	jmp    8c0d <f12+0x27d>
    9a54:	0f 1f 40 00          	nopl   0x0(%rax)
    9a58:	4d 85 c9             	test   %r9,%r9
    9a5b:	0f 84 bd 02 00 00    	je     9d1e <f12+0x138e>
    9a61:	4d 8d 5e ff          	lea    -0x1(%r14),%r11
    9a65:	4c 89 cf             	mov    %r9,%rdi
    9a68:	31 f6                	xor    %esi,%esi
    9a6a:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
    9a6f:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9a76:	00 
    9a77:	4c 89 1c 24          	mov    %r11,(%rsp)
    9a7b:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9a80:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9a85:	e8 26 9a ff ff       	call   34b0 <memset@plt>
    9a8a:	4c 8b 1c 24          	mov    (%rsp),%r11
    9a8e:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9a94:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9a9a:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    9a9f:	49 89 c1             	mov    %rax,%r9
    9aa2:	e9 a3 f5 ff ff       	jmp    904a <f12+0x6ba>
    9aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9aae:	00 00 
    9ab0:	48 83 05 38 4a 06 00 	addq   $0x1,0x64a38(%rip)        # 6e4f0 <iteration_retains>
    9ab7:	01 
    9ab8:	e9 b1 ef ff ff       	jmp    8a6e <f12+0xde>
    9abd:	be 02 00 00 00       	mov    $0x2,%esi
    9ac2:	bf 08 00 00 00       	mov    $0x8,%edi
    9ac7:	e8 44 c4 ff ff       	call   5f10 <fwp_heap_alloc>
    9acc:	49 89 c6             	mov    %rax,%r14
    9acf:	45 31 e4             	xor    %r12d,%r12d
    9ad2:	e9 99 fb ff ff       	jmp    9670 <f12+0xce0>
    9ad7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ade:	00 00 
    9ae0:	66 85 c0             	test   %ax,%ax
    9ae3:	0f 85 35 fd ff ff    	jne    981e <f12+0xe8e>
    9ae9:	e9 22 fd ff ff       	jmp    9810 <f12+0xe80>
    9aee:	66 90                	xchg   %ax,%ax
    9af0:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9af7:	ff ff 1f 
    9afa:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    9afe:	48 39 c2             	cmp    %rax,%rdx
    9b01:	0f 82 5c 02 00 00    	jb     9d63 <f12+0x13d3>
    9b07:	48 8d 05 d2 a6 04 00 	lea    0x4a6d2(%rip),%rax        # 541e0 <ad_raw_blocks>
    9b0e:	31 d2                	xor    %edx,%edx
    9b10:	eb 23                	jmp    9b35 <f12+0x11a5>
    9b12:	0f 1f 00             	nopl   (%rax)
    9b15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b1c:	00 00 00 00 
    9b20:	48 83 c2 01          	add    $0x1,%rdx
    9b24:	48 83 c0 18          	add    $0x18,%rax
    9b28:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
    9b2f:	0f 84 80 01 00 00    	je     9cb5 <f12+0x1325>
    9b35:	48 83 38 00          	cmpq   $0x0,(%rax)
    9b39:	75 e5                	jne    9b20 <f12+0x1190>
    9b3b:	4c 89 c7             	mov    %r8,%rdi
    9b3e:	be 08 00 00 00       	mov    $0x8,%esi
    9b43:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    9b48:	4c 89 04 24          	mov    %r8,(%rsp)
    9b4c:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    9b51:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    9b56:	e8 b5 99 ff ff       	call   3510 <calloc@plt>
    9b5b:	4c 8b 04 24          	mov    (%rsp),%r8
    9b5f:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    9b64:	48 8d 0d 75 a6 04 00 	lea    0x4a675(%rip),%rcx        # 541e0 <ad_raw_blocks>
    9b6b:	48 85 c0             	test   %rax,%rax
    9b6e:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    9b74:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    9b7a:	74 34                	je     9bb0 <f12+0x1220>
    9b7c:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    9b80:	48 89 c6             	mov    %rax,%rsi
    9b83:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    9b88:	48 8d 3c d1          	lea    (%rcx,%rdx,8),%rdi
    9b8c:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    9b93:	00 
    9b94:	b9 03 00 00 00       	mov    $0x3,%ecx
    9b99:	48 89 04 24          	mov    %rax,(%rsp)
    9b9d:	e8 5e a0 ff ff       	call   3c00 <ad_raw_record>
    9ba2:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    9ba7:	4c 8b 0c 24          	mov    (%rsp),%r9
    9bab:	e9 72 f4 ff ff       	jmp    9022 <f12+0x692>
    9bb0:	48 85 db             	test   %rbx,%rbx
    9bb3:	0f 85 65 01 00 00    	jne    9d1e <f12+0x138e>
    9bb9:	45 31 c9             	xor    %r9d,%r9d
    9bbc:	e9 7a f4 ff ff       	jmp    903b <f12+0x6ab>
    9bc1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9bc5:	e9 f5 ee ff ff       	jmp    8abf <f12+0x12f>
    9bca:	49 8b 07             	mov    (%r15),%rax
    9bcd:	48 85 c0             	test   %rax,%rax
    9bd0:	0f 88 e7 fe ff ff    	js     9abd <f12+0x112d>
    9bd6:	48 8b 35 3b 40 06 00 	mov    0x6403b(%rip),%rsi        # 6dc18 <fwp_heap+0x13d8>
    9bdd:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    9be2:	48 2b 0d 07 40 06 00 	sub    0x64007(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    9be9:	48 c1 e6 10          	shl    $0x10,%rsi
    9bed:	48 39 f1             	cmp    %rsi,%rcx
    9bf0:	0f 83 c7 fe ff ff    	jae    9abd <f12+0x112d>
    9bf6:	48 89 ce             	mov    %rcx,%rsi
    9bf9:	48 c1 ee 10          	shr    $0x10,%rsi
    9bfd:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9c01:	48 8b 35 30 40 06 00 	mov    0x64030(%rip),%rsi        # 6dc38 <fwp_heap+0x13f8>
    9c08:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9c0c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9c10:	48 85 ff             	test   %rdi,%rdi
    9c13:	0f 84 a4 fe ff ff    	je     9abd <f12+0x112d>
    9c19:	48 0f ba f0 3f       	btr    $0x3f,%rax
    9c1e:	49 89 c5             	mov    %rax,%r13
    9c21:	e9 6e f7 ff ff       	jmp    9394 <f12+0xa04>
    9c26:	be 68 00 00 00       	mov    $0x68,%esi
    9c2b:	bb 01 00 00 00       	mov    $0x1,%ebx
    9c30:	e9 15 ef ff ff       	jmp    8b4a <f12+0x1ba>
    9c35:	48 89 d7             	mov    %rdx,%rdi
    9c38:	48 89 14 24          	mov    %rdx,(%rsp)
    9c3c:	e8 8f bb ff ff       	call   57d0 <fwp_rc_forget_slot>
    9c41:	48 8b 14 24          	mov    (%rsp),%rdx
    9c45:	e9 49 f1 ff ff       	jmp    8d93 <f12+0x403>
    9c4a:	48 89 df             	mov    %rbx,%rdi
    9c4d:	48 89 0c 24          	mov    %rcx,(%rsp)
    9c51:	e8 7a bb ff ff       	call   57d0 <fwp_rc_forget_slot>
    9c56:	48 8b 0c 24          	mov    (%rsp),%rcx
    9c5a:	e9 80 f5 ff ff       	jmp    91df <f12+0x84f>
    9c5f:	4c 89 f7             	mov    %r14,%rdi
    9c62:	e8 69 bb ff ff       	call   57d0 <fwp_rc_forget_slot>
    9c67:	e9 ae fb ff ff       	jmp    981a <f12+0xe8a>
    9c6c:	e8 3f ba ff ff       	call   56b0 <fwp_rc_wide_dup>
    9c71:	e9 05 ee ff ff       	jmp    8a7b <f12+0xeb>
    9c76:	4c 89 f3             	mov    %r14,%rbx
    9c79:	4c 8d 5b ff          	lea    -0x1(%rbx),%r11
    9c7d:	4c 89 cf             	mov    %r9,%rdi
    9c80:	31 f6                	xor    %esi,%esi
    9c82:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9c87:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9c8e:	00 
    9c8f:	4c 89 1c 24          	mov    %r11,(%rsp)
    9c93:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9c98:	e8 13 98 ff ff       	call   34b0 <memset@plt>
    9c9d:	4c 8b 1c 24          	mov    (%rsp),%r11
    9ca1:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9ca7:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9cad:	49 89 c1             	mov    %rax,%r9
    9cb0:	e9 8d f3 ff ff       	jmp    9042 <f12+0x6b2>
    9cb5:	48 8d 3d 56 64 00 00 	lea    0x6456(%rip),%rdi        # 10112 <_IO_stdin_used+0x112>
    9cbc:	e8 3f a3 ff ff       	call   4000 <ad_raw_fail>
    9cc1:	45 31 ed             	xor    %r13d,%r13d
    9cc4:	e9 54 f8 ff ff       	jmp    951d <f12+0xb8d>
    9cc9:	48 8d 3d 38 6d 00 00 	lea    0x6d38(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    9cd0:	e8 7b a7 ff ff       	call   4450 <fwp_trap>
    9cd5:	48 8d 3d e6 64 00 00 	lea    0x64e6(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    9cdc:	e8 6f a7 ff ff       	call   4450 <fwp_trap>
    9ce1:	48 8d 3d 28 6e 00 00 	lea    0x6e28(%rip),%rdi        # 10b10 <_IO_stdin_used+0xb10>
    9ce8:	e8 63 a7 ff ff       	call   4450 <fwp_trap>
    9ced:	e8 0e 9a ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9cf2:	45 31 f6             	xor    %r14d,%r14d
    9cf5:	e9 d5 fd ff ff       	jmp    9acf <f12+0x113f>
    9cfa:	48 8d 3d f8 64 00 00 	lea    0x64f8(%rip),%rdi        # 101f9 <_IO_stdin_used+0x1f9>
    9d01:	e8 4a a7 ff ff       	call   4450 <fwp_trap>
    9d06:	48 8d 3d de 64 00 00 	lea    0x64de(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    9d0d:	e8 3e a7 ff ff       	call   4450 <fwp_trap>
    9d12:	48 8d 3d 16 65 00 00 	lea    0x6516(%rip),%rdi        # 1022f <_IO_stdin_used+0x22f>
    9d19:	e8 32 a7 ff ff       	call   4450 <fwp_trap>
    9d1e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9d25:	00 
    9d26:	4c 89 e7             	mov    %r12,%rdi
    9d29:	48 89 05 a8 47 06 00 	mov    %rax,0x647a8(%rip)        # 6e4d8 <fwp_cleanups>
    9d30:	e8 2b b5 ff ff       	call   5260 <fwp_tape_buffers_release>
    9d35:	48 8b 0d 24 a3 00 00 	mov    0xa324(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    9d3c:	ba 13 00 00 00       	mov    $0x13,%edx
    9d41:	be 01 00 00 00       	mov    $0x1,%esi
    9d46:	48 8d 3d bb 62 00 00 	lea    0x62bb(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    9d4d:	e8 0e 99 ff ff       	call   3660 <fwrite@plt>
    9d52:	31 ff                	xor    %edi,%edi
    9d54:	e8 47 98 ff ff       	call   35a0 <fflush@plt>
    9d59:	bf 66 00 00 00       	mov    $0x66,%edi
    9d5e:	e8 1d 99 ff ff       	call   3680 <_Exit@plt>
    9d63:	48 8d 3d a9 64 00 00 	lea    0x64a9(%rip),%rdi        # 10213 <_IO_stdin_used+0x213>
    9d6a:	e8 91 a2 ff ff       	call   4000 <ad_raw_fail>
    9d6f:	48 8d 3d 3a 6d 00 00 	lea    0x6d3a(%rip),%rdi        # 10ab0 <_IO_stdin_used+0xab0>
    9d76:	e8 d5 a6 ff ff       	call   4450 <fwp_trap>
    9d7b:	e8 d0 96 ff ff       	call   3450 <__stack_chk_fail@plt>
    9d80:	48 8d 3d c9 6c 00 00 	lea    0x6cc9(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    9d87:	e8 c4 a6 ff ff       	call   4450 <fwp_trap>
    9d8c:	48 8d 3d 4d 6d 00 00 	lea    0x6d4d(%rip),%rdi        # 10ae0 <_IO_stdin_used+0xae0>
    9d93:	e8 b8 a6 ff ff       	call   4450 <fwp_trap>
    9d98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d9f:	00 

0000000000009da0 <fwp_owned_entry12>:
    9da0:	f3 0f 1e fa          	endbr64
    9da4:	48 8b 3f             	mov    (%rdi),%rdi
    9da7:	e9 e4 eb ff ff       	jmp    8990 <f12>
    9dac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009db0 <e12>:
    9db0:	f3 0f 1e fa          	endbr64
    9db4:	53                   	push   %rbx
    9db5:	48 8b 1f             	mov    (%rdi),%rbx
    9db8:	48 89 df             	mov    %rbx,%rdi
    9dbb:	e8 f0 cc ff ff       	call   6ab0 <fwp_rc_share>
    9dc0:	48 89 df             	mov    %rbx,%rdi
    9dc3:	e8 c8 eb ff ff       	call   8990 <f12>
    9dc8:	48 89 c3             	mov    %rax,%rbx
    9dcb:	48 89 c7             	mov    %rax,%rdi
    9dce:	e8 dd cc ff ff       	call   6ab0 <fwp_rc_share>
    9dd3:	48 89 d8             	mov    %rbx,%rax
    9dd6:	5b                   	pop    %rbx
    9dd7:	c3                   	ret
    9dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9ddf:	00 

0000000000009de0 <fwp_write>:
    9de0:	41 57                	push   %r15
    9de2:	41 56                	push   %r14
    9de4:	41 55                	push   %r13
    9de6:	41 54                	push   %r12
    9de8:	55                   	push   %rbp
    9de9:	53                   	push   %rbx
    9dea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9df1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9df8:	00 00 
    9dfa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9e01:	00 
    9e02:	49 89 d4             	mov    %rdx,%r12
    9e05:	8b 12                	mov    (%rdx),%edx
    9e07:	83 fa 19             	cmp    $0x19,%edx
    9e0a:	77 6a                	ja     9e76 <fwp_write+0x96>
    9e0c:	48 89 f5             	mov    %rsi,%rbp
    9e0f:	89 d0                	mov    %edx,%eax
    9e11:	89 ce                	mov    %ecx,%esi
    9e13:	48 89 fb             	mov    %rdi,%rbx
    9e16:	48 8d 0d a3 6e 00 00 	lea    0x6ea3(%rip),%rcx        # 10cc0 <_IO_stdin_used+0xcc0>
    9e1d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9e21:	48 01 c8             	add    %rcx,%rax
    9e24:	3e ff e0             	notrack jmp *%rax
    9e27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e2e:	00 00 
    9e30:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9e34:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9e38:	48 89 ca             	mov    %rcx,%rdx
    9e3b:	48 85 c9             	test   %rcx,%rcx
    9e3e:	0f 88 9c 0c 00 00    	js     aae0 <fwp_write+0xd00>
    9e44:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9e4b:	00 
    9e4c:	48 89 c6             	mov    %rax,%rsi
    9e4f:	4c 89 e7             	mov    %r12,%rdi
    9e52:	e8 e9 9b ff ff       	call   3a40 <fwp_fmt_u128>
    9e57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e5e:	00 00 
    9e60:	4c 89 e7             	mov    %r12,%rdi
    9e63:	e8 d8 95 ff ff       	call   3440 <strlen@plt>
    9e68:	4c 89 e6             	mov    %r12,%rsi
    9e6b:	48 89 df             	mov    %rbx,%rdi
    9e6e:	48 89 c2             	mov    %rax,%rdx
    9e71:	e8 7a a2 ff ff       	call   40f0 <buf_put>
    9e76:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9e7d:	00 
    9e7e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e85:	00 00 
    9e87:	0f 85 28 04 00 00    	jne    a2b5 <fwp_write+0x4d5>
    9e8d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9e94:	5b                   	pop    %rbx
    9e95:	5d                   	pop    %rbp
    9e96:	41 5c                	pop    %r12
    9e98:	41 5d                	pop    %r13
    9e9a:	41 5e                	pop    %r14
    9e9c:	41 5f                	pop    %r15
    9e9e:	c3                   	ret
    9e9f:	90                   	nop
    9ea0:	49 89 e9             	mov    %rbp,%r9
    9ea3:	4c 8d 05 b1 63 00 00 	lea    0x63b1(%rip),%r8        # 1025b <_IO_stdin_used+0x25b>
    9eaa:	b9 00 02 00 00       	mov    $0x200,%ecx
    9eaf:	ba 02 00 00 00       	mov    $0x2,%edx
    9eb4:	be 00 02 00 00       	mov    $0x200,%esi
    9eb9:	31 c0                	xor    %eax,%eax
    9ebb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9ec2:	00 
    9ec3:	e8 d8 94 ff ff       	call   33a0 <__snprintf_chk@plt>
    9ec8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9ecf:	00 
    9ed0:	e8 6b 95 ff ff       	call   3440 <strlen@plt>
    9ed5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9edc:	00 
    9edd:	48 89 df             	mov    %rbx,%rdi
    9ee0:	48 89 c2             	mov    %rax,%rdx
    9ee3:	e8 08 a2 ff ff       	call   40f0 <buf_put>
    9ee8:	eb 8c                	jmp    9e76 <fwp_write+0x96>
    9eea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ef0:	49 89 e9             	mov    %rbp,%r9
    9ef3:	4c 8d 05 5c 63 00 00 	lea    0x635c(%rip),%r8        # 10256 <_IO_stdin_used+0x256>
    9efa:	eb ae                	jmp    9eaa <fwp_write+0xca>
    9efc:	0f 1f 40 00          	nopl   0x0(%rax)
    9f00:	83 fa 13             	cmp    $0x13,%edx
    9f03:	48 8d 05 42 63 00 00 	lea    0x6342(%rip),%rax        # 1024c <_IO_stdin_used+0x24c>
    9f0a:	48 8d 35 40 63 00 00 	lea    0x6340(%rip),%rsi        # 10251 <_IO_stdin_used+0x251>
    9f11:	ba 04 00 00 00       	mov    $0x4,%edx
    9f16:	48 0f 44 f0          	cmove  %rax,%rsi
    9f1a:	45 31 ed             	xor    %r13d,%r13d
    9f1d:	e8 ce a1 ff ff       	call   40f0 <buf_put>
    9f22:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9f27:	0f 84 a3 08 00 00    	je     a7d0 <fwp_write+0x9f0>
    9f2d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9f32:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9f37:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9f3c:	48 89 df             	mov    %rbx,%rdi
    9f3f:	49 0f 44 c5          	cmove  %r13,%rax
    9f43:	31 c9                	xor    %ecx,%ecx
    9f45:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9f4a:	e8 91 fe ff ff       	call   9de0 <fwp_write>
    9f4f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9f54:	0f 84 6e 09 00 00    	je     a8c8 <fwp_write+0xae8>
    9f5a:	49 83 c5 01          	add    $0x1,%r13
    9f5e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9f62:	0f 83 68 08 00 00    	jae    a7d0 <fwp_write+0x9f0>
    9f68:	ba 02 00 00 00       	mov    $0x2,%edx
    9f6d:	48 8d 35 27 63 00 00 	lea    0x6327(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    9f74:	48 89 df             	mov    %rbx,%rdi
    9f77:	e8 74 a1 ff ff       	call   40f0 <buf_put>
    9f7c:	eb af                	jmp    9f2d <fwp_write+0x14d>
    9f7e:	66 90                	xchg   %ax,%ax
    9f80:	ba 06 00 00 00       	mov    $0x6,%edx
    9f85:	48 8d 35 e8 62 00 00 	lea    0x62e8(%rip),%rsi        # 10274 <_IO_stdin_used+0x274>
    9f8c:	48 83 c5 10          	add    $0x10,%rbp
    9f90:	e8 5b a1 ff ff       	call   40f0 <buf_put>
    9f95:	48 89 ef             	mov    %rbp,%rdi
    9f98:	e8 a3 94 ff ff       	call   3440 <strlen@plt>
    9f9d:	48 89 ee             	mov    %rbp,%rsi
    9fa0:	48 89 df             	mov    %rbx,%rdi
    9fa3:	48 89 c2             	mov    %rax,%rdx
    9fa6:	e8 45 a1 ff ff       	call   40f0 <buf_put>
    9fab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9fb0:	ba 01 00 00 00       	mov    $0x1,%edx
    9fb5:	48 89 df             	mov    %rbx,%rdi
    9fb8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9fbd:	e8 2e a1 ff ff       	call   40f0 <buf_put>
    9fc2:	e9 af fe ff ff       	jmp    9e76 <fwp_write+0x96>
    9fc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9fce:	00 00 
    9fd0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9fd7:	00 
    9fd8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9fdf:	00 00 
    9fe1:	0f 85 ce 02 00 00    	jne    a2b5 <fwp_write+0x4d5>
    9fe7:	ba 0a 00 00 00       	mov    $0xa,%edx
    9fec:	48 8d 35 6d 62 00 00 	lea    0x626d(%rip),%rsi        # 10260 <_IO_stdin_used+0x260>
    9ff3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9ffa:	48 89 df             	mov    %rbx,%rdi
    9ffd:	5b                   	pop    %rbx
    9ffe:	5d                   	pop    %rbp
    9fff:	41 5c                	pop    %r12
    a001:	41 5d                	pop    %r13
    a003:	41 5e                	pop    %r14
    a005:	41 5f                	pop    %r15
    a007:	e9 e4 a0 ff ff       	jmp    40f0 <buf_put>
    a00c:	0f 1f 40 00          	nopl   0x0(%rax)
    a010:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a015:	4d 85 ed             	test   %r13,%r13
    a018:	0f 84 02 0c 00 00    	je     ac20 <fwp_write+0xe40>
    a01e:	48 8d 35 83 62 00 00 	lea    0x6283(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    a025:	4c 89 ef             	mov    %r13,%rdi
    a028:	e8 f3 94 ff ff       	call   3520 <strcmp@plt>
    a02d:	41 89 c1             	mov    %eax,%r9d
    a030:	85 c0                	test   %eax,%eax
    a032:	0f 84 6c 0c 00 00    	je     aca4 <fwp_write+0xec4>
    a038:	4c 89 ef             	mov    %r13,%rdi
    a03b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a040:	e8 fb 93 ff ff       	call   3440 <strlen@plt>
    a045:	4c 89 ee             	mov    %r13,%rsi
    a048:	48 89 df             	mov    %rbx,%rdi
    a04b:	48 89 c2             	mov    %rax,%rdx
    a04e:	e8 9d a0 ff ff       	call   40f0 <buf_put>
    a053:	ba 01 00 00 00       	mov    $0x1,%edx
    a058:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a05d:	48 89 df             	mov    %rbx,%rdi
    a060:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a065:	e8 86 a0 ff ff       	call   40f0 <buf_put>
    a06a:	ba 01 00 00 00       	mov    $0x1,%edx
    a06f:	4c 89 fe             	mov    %r15,%rsi
    a072:	48 89 df             	mov    %rbx,%rdi
    a075:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a07a:	e8 71 a0 ff ff       	call   40f0 <buf_put>
    a07f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a084:	45 31 f6             	xor    %r14d,%r14d
    a087:	85 d2                	test   %edx,%edx
    a089:	0f 8e 81 0a 00 00    	jle    ab10 <fwp_write+0xd30>
    a08f:	45 31 ed             	xor    %r13d,%r13d
    a092:	4d 85 ed             	test   %r13,%r13
    a095:	0f 85 75 07 00 00    	jne    a810 <fwp_write+0xa30>
    a09b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a0a2:	00 
    a0a3:	45 85 f6             	test   %r14d,%r14d
    a0a6:	0f 84 84 07 00 00    	je     a830 <fwp_write+0xa50>
    a0ac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a0b1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a0b6:	48 89 df             	mov    %rbx,%rdi
    a0b9:	49 83 c5 01          	add    $0x1,%r13
    a0bd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a0c1:	31 c9                	xor    %ecx,%ecx
    a0c3:	e8 18 fd ff ff       	call   9de0 <fwp_write>
    a0c8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a0cd:	7f c3                	jg     a092 <fwp_write+0x2b2>
    a0cf:	45 85 f6             	test   %r14d,%r14d
    a0d2:	0f 84 38 0a 00 00    	je     ab10 <fwp_write+0xd30>
    a0d8:	b8 29 00 00 00       	mov    $0x29,%eax
    a0dd:	ba 01 00 00 00       	mov    $0x1,%edx
    a0e2:	4c 89 fe             	mov    %r15,%rsi
    a0e5:	48 89 df             	mov    %rbx,%rdi
    a0e8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a0ec:	e8 ff 9f ff ff       	call   40f0 <buf_put>
    a0f1:	e9 80 fd ff ff       	jmp    9e76 <fwp_write+0x96>
    a0f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0fd:	00 00 00 
    a100:	ba 01 00 00 00       	mov    $0x1,%edx
    a105:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a10a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a10f:	e8 dc 9f ff ff       	call   40f0 <buf_put>
    a114:	48 85 ed             	test   %rbp,%rbp
    a117:	0f 84 93 06 00 00    	je     a7b0 <fwp_write+0x9d0>
    a11d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a121:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a126:	31 c9                	xor    %ecx,%ecx
    a128:	48 89 df             	mov    %rbx,%rdi
    a12b:	e8 b0 fc ff ff       	call   9de0 <fwp_write>
    a130:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a134:	48 85 ed             	test   %rbp,%rbp
    a137:	0f 84 73 06 00 00    	je     a7b0 <fwp_write+0x9d0>
    a13d:	ba 02 00 00 00       	mov    $0x2,%edx
    a142:	48 8d 35 52 61 00 00 	lea    0x6152(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a149:	48 89 df             	mov    %rbx,%rdi
    a14c:	e8 9f 9f ff ff       	call   40f0 <buf_put>
    a151:	eb ca                	jmp    a11d <fwp_write+0x33d>
    a153:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a158:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a15c:	85 f6                	test   %esi,%esi
    a15e:	0f 84 fc 07 00 00    	je     a960 <fwp_write+0xb80>
    a164:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a16b:	00 
    a16c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a173:	00 00 
    a175:	0f 85 3a 01 00 00    	jne    a2b5 <fwp_write+0x4d5>
    a17b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a17f:	4c 89 ea             	mov    %r13,%rdx
    a182:	e9 6c fe ff ff       	jmp    9ff3 <fwp_write+0x213>
    a187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a18e:	00 00 
    a190:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a195:	ba 01 00 00 00       	mov    $0x1,%edx
    a19a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a19f:	48 89 ee             	mov    %rbp,%rsi
    a1a2:	e8 49 9f ff ff       	call   40f0 <buf_put>
    a1a7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a1ac:	4c 89 e7             	mov    %r12,%rdi
    a1af:	e8 8c 92 ff ff       	call   3440 <strlen@plt>
    a1b4:	4c 89 e6             	mov    %r12,%rsi
    a1b7:	48 89 df             	mov    %rbx,%rdi
    a1ba:	48 89 c2             	mov    %rax,%rdx
    a1bd:	e8 2e 9f ff ff       	call   40f0 <buf_put>
    a1c2:	ba 01 00 00 00       	mov    $0x1,%edx
    a1c7:	48 89 ee             	mov    %rbp,%rsi
    a1ca:	48 89 df             	mov    %rbx,%rdi
    a1cd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a1d2:	e8 19 9f ff ff       	call   40f0 <buf_put>
    a1d7:	e9 9a fc ff ff       	jmp    9e76 <fwp_write+0x96>
    a1dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a1e0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a1e5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a1e9:	0f 8a 8e 0b 00 00    	jp     ad7d <fwp_write+0xf9d>
    a1ef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a1f3:	66 0f 54 05 c5 6b 00 	andpd  0x6bc5(%rip),%xmm0        # 10dc0 <msg.4+0x90>
    a1fa:	00 
    a1fb:	bd 01 00 00 00       	mov    $0x1,%ebp
    a200:	66 0f 2e 05 f0 6b 00 	ucomisd 0x6bf0(%rip),%xmm0        # 10df8 <msg.4+0xc8>
    a207:	00 
    a208:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a20f:	00 
    a210:	0f 87 b2 09 00 00    	ja     abc8 <fwp_write+0xde8>
    a216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a21d:	00 00 00 
    a220:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a224:	89 ee                	mov    %ebp,%esi
    a226:	4c 89 e7             	mov    %r12,%rdi
    a229:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a22e:	e8 3d a5 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a233:	31 f6                	xor    %esi,%esi
    a235:	4c 89 e7             	mov    %r12,%rdi
    a238:	e8 c3 91 ff ff       	call   3400 <strtod@plt>
    a23d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a242:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a246:	7a 06                	jp     a24e <fwp_write+0x46e>
    a248:	0f 84 e9 01 00 00    	je     a437 <fwp_write+0x657>
    a24e:	83 c5 01             	add    $0x1,%ebp
    a251:	83 fd 12             	cmp    $0x12,%ebp
    a254:	75 ca                	jne    a220 <fwp_write+0x440>
    a256:	be 11 00 00 00       	mov    $0x11,%esi
    a25b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a25f:	4c 89 e7             	mov    %r12,%rdi
    a262:	e8 09 a5 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a267:	e9 cb 01 00 00       	jmp    a437 <fwp_write+0x657>
    a26c:	0f 1f 40 00          	nopl   0x0(%rax)
    a270:	48 83 fd 01          	cmp    $0x1,%rbp
    a274:	0f 84 e6 08 00 00    	je     ab60 <fwp_write+0xd80>
    a27a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a27e:	b8 02 00 00 00       	mov    $0x2,%eax
    a283:	ba 01 00 00 00       	mov    $0x1,%edx
    a288:	48 0f 44 d0          	cmove  %rax,%rdx
    a28c:	48 8d 35 b1 5f 00 00 	lea    0x5fb1(%rip),%rsi        # 10244 <_IO_stdin_used+0x244>
    a293:	48 8d 05 af 5f 00 00 	lea    0x5faf(%rip),%rax        # 10249 <_IO_stdin_used+0x249>
    a29a:	48 0f 44 f0          	cmove  %rax,%rsi
    a29e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a2a5:	00 
    a2a6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a2ad:	00 00 
    a2af:	0f 84 3e fd ff ff    	je     9ff3 <fwp_write+0x213>
    a2b5:	e8 96 91 ff ff       	call   3450 <__stack_chk_fail@plt>
    a2ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2c0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a2c5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a2ca:	e8 61 9d ff ff       	call   4030 <buf_grow>
    a2cf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a2d3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a2d9:	4c 03 0b             	add    (%rbx),%r9
    a2dc:	66 45 89 11          	mov    %r10w,(%r9)
    a2e0:	45 85 e4             	test   %r12d,%r12d
    a2e3:	0f 8e 07 05 00 00    	jle    a7f0 <fwp_write+0xa10>
    a2e9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a2f0:	55 55 55 
    a2f3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a2f8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a2ff:	aa aa aa 
    a302:	49 83 c1 01          	add    $0x1,%r9
    a306:	eb 45                	jmp    a34d <fwp_write+0x56d>
    a308:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a30f:	00 
    a310:	be 01 00 00 00       	mov    $0x1,%esi
    a315:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a31a:	88 07                	mov    %al,(%rdi)
    a31c:	48 89 e8             	mov    %rbp,%rax
    a31f:	49 f7 e8             	imul   %r8
    a322:	48 89 e8             	mov    %rbp,%rax
    a325:	48 c1 f8 3f          	sar    $0x3f,%rax
    a329:	48 29 c2             	sub    %rax,%rdx
    a32c:	48 85 c9             	test   %rcx,%rcx
    a32f:	0f 95 c0             	setne  %al
    a332:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a336:	48 83 ef 01          	sub    $0x1,%rdi
    a33a:	48 21 c5             	and    %rax,%rbp
    a33d:	48 29 ea             	sub    %rbp,%rdx
    a340:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a344:	49 39 f9             	cmp    %rdi,%r9
    a347:	0f 84 a3 04 00 00    	je     a7f0 <fwp_write+0xa10>
    a34d:	48 89 e8             	mov    %rbp,%rax
    a350:	49 f7 e8             	imul   %r8
    a353:	48 89 e8             	mov    %rbp,%rax
    a356:	48 c1 f8 3f          	sar    $0x3f,%rax
    a35a:	48 89 d1             	mov    %rdx,%rcx
    a35d:	48 29 c1             	sub    %rax,%rcx
    a360:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a364:	48 89 e9             	mov    %rbp,%rcx
    a367:	48 29 c1             	sub    %rax,%rcx
    a36a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a36e:	49 f7 e2             	mul    %r10
    a371:	b8 30 00 00 00       	mov    $0x30,%eax
    a376:	48 89 d6             	mov    %rdx,%rsi
    a379:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a37d:	48 d1 ee             	shr    $1,%rsi
    a380:	48 01 f2             	add    %rsi,%rdx
    a383:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a387:	48 29 d6             	sub    %rdx,%rsi
    a38a:	74 8e                	je     a31a <fwp_write+0x53a>
    a38c:	48 83 fe 01          	cmp    $0x1,%rsi
    a390:	0f 85 7a ff ff ff    	jne    a310 <fwp_write+0x530>
    a396:	31 f6                	xor    %esi,%esi
    a398:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a39d:	e9 78 ff ff ff       	jmp    a31a <fwp_write+0x53a>
    a3a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3a8:	66 0f 6e cd          	movd   %ebp,%xmm1
    a3ac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a3af:	0f 8a c8 09 00 00    	jp     ad7d <fwp_write+0xf9d>
    a3b5:	0f 28 c1             	movaps %xmm1,%xmm0
    a3b8:	0f 54 05 f1 69 00 00 	andps  0x69f1(%rip),%xmm0        # 10db0 <msg.4+0x80>
    a3bf:	0f 2e 05 3e 5c 00 00 	ucomiss 0x5c3e(%rip),%xmm0        # 10004 <_IO_stdin_used+0x4>
    a3c6:	0f 87 24 08 00 00    	ja     abf0 <fwp_write+0xe10>
    a3cc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a3d0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a3d6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a3dd:	00 
    a3de:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a3e2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a3e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a3ee:	00 00 
    a3f0:	44 89 ee             	mov    %r13d,%esi
    a3f3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a3f8:	4c 89 e7             	mov    %r12,%rdi
    a3fb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a400:	e8 6b a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a405:	31 f6                	xor    %esi,%esi
    a407:	4c 89 e7             	mov    %r12,%rdi
    a40a:	e8 91 90 ff ff       	call   34a0 <strtof@plt>
    a40f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a414:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a417:	7a 02                	jp     a41b <fwp_write+0x63b>
    a419:	74 1c                	je     a437 <fwp_write+0x657>
    a41b:	41 83 c5 01          	add    $0x1,%r13d
    a41f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a423:	75 cb                	jne    a3f0 <fwp_write+0x610>
    a425:	be 09 00 00 00       	mov    $0x9,%esi
    a42a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a42f:	4c 89 e7             	mov    %r12,%rdi
    a432:	e8 39 a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a437:	4c 89 e7             	mov    %r12,%rdi
    a43a:	e8 71 9d ff ff       	call   41b0 <fwp_finish_float>
    a43f:	e9 1c fa ff ff       	jmp    9e60 <fwp_write+0x80>
    a444:	0f 1f 40 00          	nopl   0x0(%rax)
    a448:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a44c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a450:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a457:	00 
    a458:	48 89 ef             	mov    %rbp,%rdi
    a45b:	e8 e0 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a460:	48 89 ef             	mov    %rbp,%rdi
    a463:	e8 d8 8f ff ff       	call   3440 <strlen@plt>
    a468:	48 89 ee             	mov    %rbp,%rsi
    a46b:	48 89 df             	mov    %rbx,%rdi
    a46e:	48 89 c2             	mov    %rax,%rdx
    a471:	e8 7a 9c ff ff       	call   40f0 <buf_put>
    a476:	e9 fb f9 ff ff       	jmp    9e76 <fwp_write+0x96>
    a47b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a480:	ba 06 00 00 00       	mov    $0x6,%edx
    a485:	48 8d 35 12 5e 00 00 	lea    0x5e12(%rip),%rsi        # 1029e <_IO_stdin_used+0x29e>
    a48c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a492:	e8 59 9c ff ff       	call   40f0 <buf_put>
    a497:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a49e:	ff ff 7f 
    a4a1:	48 23 55 00          	and    0x0(%rbp),%rdx
    a4a5:	0f 84 86 02 00 00    	je     a731 <fwp_write+0x951>
    a4ab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a4b0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a4b4:	48 85 d2             	test   %rdx,%rdx
    a4b7:	0f 84 ae 00 00 00    	je     a56b <fwp_write+0x78b>
    a4bd:	8b 0a                	mov    (%rdx),%ecx
    a4bf:	83 f9 1c             	cmp    $0x1c,%ecx
    a4c2:	0f 84 58 06 00 00    	je     ab20 <fwp_write+0xd40>
    a4c8:	83 f9 1b             	cmp    $0x1b,%ecx
    a4cb:	0f 87 9a 00 00 00    	ja     a56b <fwp_write+0x78b>
    a4d1:	be 01 00 00 00       	mov    $0x1,%esi
    a4d6:	48 d3 e6             	shl    %cl,%rsi
    a4d9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a4df:	0f 85 4b 04 00 00    	jne    a930 <fwp_write+0xb50>
    a4e5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a4eb:	0f 85 0f 04 00 00    	jne    a900 <fwp_write+0xb20>
    a4f1:	83 e6 21             	and    $0x21,%esi
    a4f4:	74 75                	je     a56b <fwp_write+0x78b>
    a4f6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a4fb:	48 85 ff             	test   %rdi,%rdi
    a4fe:	79 07                	jns    a507 <fwp_write+0x727>
    a500:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a504:	4c 01 ee             	add    %r13,%rsi
    a507:	48 0f be 3e          	movsbq (%rsi),%rdi
    a50b:	85 c9                	test   %ecx,%ecx
    a50d:	40 0f b6 f7          	movzbl %dil,%esi
    a511:	48 0f 44 f7          	cmove  %rdi,%rsi
    a515:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a51c:	00 00 00 00 
    a520:	31 c9                	xor    %ecx,%ecx
    a522:	48 89 df             	mov    %rbx,%rdi
    a525:	49 83 c5 01          	add    $0x1,%r13
    a529:	e8 b2 f8 ff ff       	call   9de0 <fwp_write>
    a52e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a535:	ff ff 7f 
    a538:	48 23 55 00          	and    0x0(%rbp),%rdx
    a53c:	49 39 d5             	cmp    %rdx,%r13
    a53f:	0f 83 ec 01 00 00    	jae    a731 <fwp_write+0x951>
    a545:	ba 02 00 00 00       	mov    $0x2,%edx
    a54a:	48 89 df             	mov    %rbx,%rdi
    a54d:	48 8d 35 47 5d 00 00 	lea    0x5d47(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a554:	e8 97 9b ff ff       	call   40f0 <buf_put>
    a559:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a55e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a562:	48 85 d2             	test   %rdx,%rdx
    a565:	0f 85 52 ff ff ff    	jne    a4bd <fwp_write+0x6dd>
    a56b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a570:	48 85 ff             	test   %rdi,%rdi
    a573:	0f 88 cf 05 00 00    	js     ab48 <fwp_write+0xd68>
    a579:	48 8b 31             	mov    (%rcx),%rsi
    a57c:	eb a2                	jmp    a520 <fwp_write+0x740>
    a57e:	66 90                	xchg   %ax,%ax
    a580:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a587:	00 
    a588:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a58f:	00 00 
    a591:	0f 85 1e fd ff ff    	jne    a2b5 <fwp_write+0x4d5>
    a597:	ba 08 00 00 00       	mov    $0x8,%edx
    a59c:	48 8d 35 c8 5c 00 00 	lea    0x5cc8(%rip),%rsi        # 1026b <_IO_stdin_used+0x26b>
    a5a3:	e9 4b fa ff ff       	jmp    9ff3 <fwp_write+0x213>
    a5a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a5af:	00 
    a5b0:	89 e8                	mov    %ebp,%eax
    a5b2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a5b9:	76 03                	jbe    a5be <fwp_write+0x7de>
    a5bb:	8b 45 00             	mov    0x0(%rbp),%eax
    a5be:	41 89 c6             	mov    %eax,%r14d
    a5c1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a5c6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a5cb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a5cf:	4c 89 ef             	mov    %r13,%rdi
    a5d2:	e8 69 8e ff ff       	call   3440 <strlen@plt>
    a5d7:	4c 89 ee             	mov    %r13,%rsi
    a5da:	48 89 df             	mov    %rbx,%rdi
    a5dd:	48 89 c2             	mov    %rax,%rdx
    a5e0:	e8 0b 9b ff ff       	call   40f0 <buf_put>
    a5e5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a5ea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a5ee:	85 f6                	test   %esi,%esi
    a5f0:	0f 8e 80 f8 ff ff    	jle    9e76 <fwp_write+0x96>
    a5f6:	45 31 ed             	xor    %r13d,%r13d
    a5f9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a5fe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a603:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a608:	ba 01 00 00 00       	mov    $0x1,%edx
    a60d:	4c 89 fe             	mov    %r15,%rsi
    a610:	48 89 04 24          	mov    %rax,(%rsp)
    a614:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a619:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a61d:	48 89 df             	mov    %rbx,%rdi
    a620:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a624:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a629:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a62e:	e8 bd 9a ff ff       	call   40f0 <buf_put>
    a633:	41 8b 06             	mov    (%r14),%eax
    a636:	83 f8 0e             	cmp    $0xe,%eax
    a639:	0f 84 71 02 00 00    	je     a8b0 <fwp_write+0xad0>
    a63f:	83 f8 10             	cmp    $0x10,%eax
    a642:	0f 84 38 02 00 00    	je     a880 <fwp_write+0xaa0>
    a648:	83 f8 0a             	cmp    $0xa,%eax
    a64b:	0f 84 7f 04 00 00    	je     aad0 <fwp_write+0xcf0>
    a651:	0f 8f f9 00 00 00    	jg     a750 <fwp_write+0x970>
    a657:	83 f8 03             	cmp    $0x3,%eax
    a65a:	0f 8f 50 04 00 00    	jg     aab0 <fwp_write+0xcd0>
    a660:	85 c0                	test   %eax,%eax
    a662:	78 10                	js     a674 <fwp_write+0x894>
    a664:	48 8b 04 24          	mov    (%rsp),%rax
    a668:	48 c1 e8 3f          	shr    $0x3f,%rax
    a66c:	85 c0                	test   %eax,%eax
    a66e:	0f 85 f9 00 00 00    	jne    a76d <fwp_write+0x98d>
    a674:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a679:	48 8b 34 24          	mov    (%rsp),%rsi
    a67d:	31 c9                	xor    %ecx,%ecx
    a67f:	48 89 df             	mov    %rbx,%rdi
    a682:	e8 59 f7 ff ff       	call   9de0 <fwp_write>
    a687:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a68c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a691:	49 83 c5 01          	add    $0x1,%r13
    a695:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a699:	0f 8f 5f ff ff ff    	jg     a5fe <fwp_write+0x81e>
    a69f:	e9 d2 f7 ff ff       	jmp    9e76 <fwp_write+0x96>
    a6a4:	0f 1f 40 00          	nopl   0x0(%rax)
    a6a8:	ba 06 00 00 00       	mov    $0x6,%edx
    a6ad:	48 8d 35 dd 5b 00 00 	lea    0x5bdd(%rip),%rsi        # 10291 <_IO_stdin_used+0x291>
    a6b4:	45 31 ed             	xor    %r13d,%r13d
    a6b7:	e8 34 9a ff ff       	call   40f0 <buf_put>
    a6bc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a6c1:	75 19                	jne    a6dc <fwp_write+0x8fc>
    a6c3:	eb 6c                	jmp    a731 <fwp_write+0x951>
    a6c5:	0f 1f 00             	nopl   (%rax)
    a6c8:	ba 02 00 00 00       	mov    $0x2,%edx
    a6cd:	48 8d 35 c7 5b 00 00 	lea    0x5bc7(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a6d4:	48 89 df             	mov    %rbx,%rdi
    a6d7:	e8 14 9a ff ff       	call   40f0 <buf_put>
    a6dc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a6e2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a6e7:	31 c0                	xor    %eax,%eax
    a6e9:	49 83 c5 01          	add    $0x1,%r13
    a6ed:	4c 8d 05 a4 5b 00 00 	lea    0x5ba4(%rip),%r8        # 10298 <_IO_stdin_used+0x298>
    a6f4:	ba 02 00 00 00       	mov    $0x2,%edx
    a6f9:	be 00 02 00 00       	mov    $0x200,%esi
    a6fe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a705:	00 
    a706:	e8 95 8c ff ff       	call   33a0 <__snprintf_chk@plt>
    a70b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a712:	00 
    a713:	e8 28 8d ff ff       	call   3440 <strlen@plt>
    a718:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a71f:	00 
    a720:	48 89 df             	mov    %rbx,%rdi
    a723:	48 89 c2             	mov    %rax,%rdx
    a726:	e8 c5 99 ff ff       	call   40f0 <buf_put>
    a72b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a72f:	72 97                	jb     a6c8 <fwp_write+0x8e8>
    a731:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a736:	ba 01 00 00 00       	mov    $0x1,%edx
    a73b:	48 89 df             	mov    %rbx,%rdi
    a73e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a743:	e8 a8 99 ff ff       	call   40f0 <buf_put>
    a748:	e9 29 f7 ff ff       	jmp    9e76 <fwp_write+0x96>
    a74d:	0f 1f 00             	nopl   (%rax)
    a750:	83 f8 0b             	cmp    $0xb,%eax
    a753:	0f 85 1b ff ff ff    	jne    a674 <fwp_write+0x894>
    a759:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a75e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a762:	83 e0 01             	and    $0x1,%eax
    a765:	85 c0                	test   %eax,%eax
    a767:	0f 84 07 ff ff ff    	je     a674 <fwp_write+0x894>
    a76d:	4c 89 fe             	mov    %r15,%rsi
    a770:	48 89 df             	mov    %rbx,%rdi
    a773:	ba 01 00 00 00       	mov    $0x1,%edx
    a778:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a77d:	e8 6e 99 ff ff       	call   40f0 <buf_put>
    a782:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a787:	48 8b 34 24          	mov    (%rsp),%rsi
    a78b:	31 c9                	xor    %ecx,%ecx
    a78d:	48 89 df             	mov    %rbx,%rdi
    a790:	e8 4b f6 ff ff       	call   9de0 <fwp_write>
    a795:	ba 01 00 00 00       	mov    $0x1,%edx
    a79a:	4c 89 fe             	mov    %r15,%rsi
    a79d:	48 89 df             	mov    %rbx,%rdi
    a7a0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a7a5:	e8 46 99 ff ff       	call   40f0 <buf_put>
    a7aa:	e9 d8 fe ff ff       	jmp    a687 <fwp_write+0x8a7>
    a7af:	90                   	nop
    a7b0:	ba 01 00 00 00       	mov    $0x1,%edx
    a7b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a7ba:	48 89 df             	mov    %rbx,%rdi
    a7bd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a7c2:	e8 29 99 ff ff       	call   40f0 <buf_put>
    a7c7:	e9 aa f6 ff ff       	jmp    9e76 <fwp_write+0x96>
    a7cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a7d0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a7d5:	ba 01 00 00 00       	mov    $0x1,%edx
    a7da:	48 89 df             	mov    %rbx,%rdi
    a7dd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a7e2:	e8 09 99 ff ff       	call   40f0 <buf_put>
    a7e7:	e9 8a f6 ff ff       	jmp    9e76 <fwp_write+0x96>
    a7ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a7f0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a7f4:	48 8b 13             	mov    (%rbx),%rdx
    a7f7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a7fc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a800:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a804:	e9 6d f6 ff ff       	jmp    9e76 <fwp_write+0x96>
    a809:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a810:	ba 02 00 00 00       	mov    $0x2,%edx
    a815:	48 8d 35 7f 5a 00 00 	lea    0x5a7f(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a81c:	48 89 df             	mov    %rbx,%rdi
    a81f:	e8 cc 98 ff ff       	call   40f0 <buf_put>
    a824:	e9 72 f8 ff ff       	jmp    a09b <fwp_write+0x2bb>
    a829:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a830:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a835:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a83a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a83e:	48 89 f7             	mov    %rsi,%rdi
    a841:	48 89 34 24          	mov    %rsi,(%rsp)
    a845:	e8 f6 8b ff ff       	call   3440 <strlen@plt>
    a84a:	48 8b 34 24          	mov    (%rsp),%rsi
    a84e:	48 89 df             	mov    %rbx,%rdi
    a851:	48 89 c2             	mov    %rax,%rdx
    a854:	e8 97 98 ff ff       	call   40f0 <buf_put>
    a859:	ba 03 00 00 00       	mov    $0x3,%edx
    a85e:	48 8d 35 59 5a 00 00 	lea    0x5a59(%rip),%rsi        # 102be <_IO_stdin_used+0x2be>
    a865:	48 89 df             	mov    %rbx,%rdi
    a868:	e8 83 98 ff ff       	call   40f0 <buf_put>
    a86d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a872:	e9 35 f8 ff ff       	jmp    a0ac <fwp_write+0x2cc>
    a877:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a87e:	00 00 
    a880:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a885:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a889:	48 85 ff             	test   %rdi,%rdi
    a88c:	0f 84 e2 fd ff ff    	je     a674 <fwp_write+0x894>
    a892:	48 8d 35 0f 5a 00 00 	lea    0x5a0f(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    a899:	e8 82 8c ff ff       	call   3520 <strcmp@plt>
    a89e:	85 c0                	test   %eax,%eax
    a8a0:	0f 95 c0             	setne  %al
    a8a3:	0f b6 c0             	movzbl %al,%eax
    a8a6:	e9 c1 fd ff ff       	jmp    a66c <fwp_write+0x88c>
    a8ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a8b0:	31 c0                	xor    %eax,%eax
    a8b2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a8b9:	00 
    a8ba:	0f 97 c0             	seta   %al
    a8bd:	e9 aa fd ff ff       	jmp    a66c <fwp_write+0x88c>
    a8c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a8c8:	48 89 df             	mov    %rbx,%rdi
    a8cb:	ba 02 00 00 00       	mov    $0x2,%edx
    a8d0:	48 8d 35 ce 59 00 00 	lea    0x59ce(%rip),%rsi        # 102a5 <_IO_stdin_used+0x2a5>
    a8d7:	e8 14 98 ff ff       	call   40f0 <buf_put>
    a8dc:	4c 89 e8             	mov    %r13,%rax
    a8df:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a8e4:	31 c9                	xor    %ecx,%ecx
    a8e6:	48 c1 e0 04          	shl    $0x4,%rax
    a8ea:	48 89 df             	mov    %rbx,%rdi
    a8ed:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a8f2:	e8 e9 f4 ff ff       	call   9de0 <fwp_write>
    a8f7:	e9 5e f6 ff ff       	jmp    9f5a <fwp_write+0x17a>
    a8fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a900:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a905:	48 85 ff             	test   %rdi,%rdi
    a908:	79 0c                	jns    a916 <fwp_write+0xb36>
    a90a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a911:	00 
    a912:	48 03 75 10          	add    0x10(%rbp),%rsi
    a916:	48 63 3e             	movslq (%rsi),%rdi
    a919:	83 f9 02             	cmp    $0x2,%ecx
    a91c:	89 fe                	mov    %edi,%esi
    a91e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a922:	e9 f9 fb ff ff       	jmp    a520 <fwp_write+0x740>
    a927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a92e:	00 00 
    a930:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a935:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a93a:	48 85 ff             	test   %rdi,%rdi
    a93d:	0f 88 0f 03 00 00    	js     ac52 <fwp_write+0xe72>
    a943:	49 0f bf 38          	movswq (%r8),%rdi
    a947:	83 f9 01             	cmp    $0x1,%ecx
    a94a:	0f b7 f7             	movzwl %di,%esi
    a94d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a951:	e9 ca fb ff ff       	jmp    a520 <fwp_write+0x740>
    a956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a95d:	00 00 00 
    a960:	ba 01 00 00 00       	mov    $0x1,%edx
    a965:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a96a:	48 83 c5 08          	add    $0x8,%rbp
    a96e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a973:	e8 78 97 ff ff       	call   40f0 <buf_put>
    a978:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a97d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a982:	4d 85 ed             	test   %r13,%r13
    a985:	75 46                	jne    a9cd <fwp_write+0xbed>
    a987:	e9 04 01 00 00       	jmp    aa90 <fwp_write+0xcb0>
    a98c:	0f 1f 40 00          	nopl   0x0(%rax)
    a990:	41 80 f9 09          	cmp    $0x9,%r9b
    a994:	0f 84 d6 00 00 00    	je     aa70 <fwp_write+0xc90>
    a99a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a99e:	0f 85 9c 00 00 00    	jne    aa40 <fwp_write+0xc60>
    a9a4:	ba 02 00 00 00       	mov    $0x2,%edx
    a9a9:	48 8d 35 d1 58 00 00 	lea    0x58d1(%rip),%rsi        # 10281 <_IO_stdin_used+0x281>
    a9b0:	48 89 df             	mov    %rbx,%rdi
    a9b3:	e8 38 97 ff ff       	call   40f0 <buf_put>
    a9b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a9bf:	00 
    a9c0:	48 83 c5 01          	add    $0x1,%rbp
    a9c4:	49 39 ec             	cmp    %rbp,%r12
    a9c7:	0f 84 c3 00 00 00    	je     aa90 <fwp_write+0xcb0>
    a9cd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a9d2:	41 80 f9 0d          	cmp    $0xd,%r9b
    a9d6:	74 28                	je     aa00 <fwp_write+0xc20>
    a9d8:	7e b6                	jle    a990 <fwp_write+0xbb0>
    a9da:	41 80 f9 22          	cmp    $0x22,%r9b
    a9de:	74 40                	je     aa20 <fwp_write+0xc40>
    a9e0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a9e4:	75 5a                	jne    aa40 <fwp_write+0xc60>
    a9e6:	ba 02 00 00 00       	mov    $0x2,%edx
    a9eb:	48 8d 35 8c 58 00 00 	lea    0x588c(%rip),%rsi        # 1027e <_IO_stdin_used+0x27e>
    a9f2:	48 89 df             	mov    %rbx,%rdi
    a9f5:	e8 f6 96 ff ff       	call   40f0 <buf_put>
    a9fa:	eb c4                	jmp    a9c0 <fwp_write+0xbe0>
    a9fc:	0f 1f 40 00          	nopl   0x0(%rax)
    aa00:	ba 02 00 00 00       	mov    $0x2,%edx
    aa05:	48 8d 35 7b 58 00 00 	lea    0x587b(%rip),%rsi        # 10287 <_IO_stdin_used+0x287>
    aa0c:	48 89 df             	mov    %rbx,%rdi
    aa0f:	e8 dc 96 ff ff       	call   40f0 <buf_put>
    aa14:	eb aa                	jmp    a9c0 <fwp_write+0xbe0>
    aa16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa1d:	00 00 00 
    aa20:	ba 02 00 00 00       	mov    $0x2,%edx
    aa25:	48 8d 35 4f 58 00 00 	lea    0x584f(%rip),%rsi        # 1027b <_IO_stdin_used+0x27b>
    aa2c:	48 89 df             	mov    %rbx,%rdi
    aa2f:	e8 bc 96 ff ff       	call   40f0 <buf_put>
    aa34:	eb 8a                	jmp    a9c0 <fwp_write+0xbe0>
    aa36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa3d:	00 00 00 
    aa40:	41 80 f9 1f          	cmp    $0x1f,%r9b
    aa44:	0f 86 2e 01 00 00    	jbe    ab78 <fwp_write+0xd98>
    aa4a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    aa4e:	0f 84 24 01 00 00    	je     ab78 <fwp_write+0xd98>
    aa54:	ba 01 00 00 00       	mov    $0x1,%edx
    aa59:	4c 89 fe             	mov    %r15,%rsi
    aa5c:	48 89 df             	mov    %rbx,%rdi
    aa5f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    aa64:	e8 87 96 ff ff       	call   40f0 <buf_put>
    aa69:	e9 52 ff ff ff       	jmp    a9c0 <fwp_write+0xbe0>
    aa6e:	66 90                	xchg   %ax,%ax
    aa70:	ba 02 00 00 00       	mov    $0x2,%edx
    aa75:	48 8d 35 08 58 00 00 	lea    0x5808(%rip),%rsi        # 10284 <_IO_stdin_used+0x284>
    aa7c:	48 89 df             	mov    %rbx,%rdi
    aa7f:	e8 6c 96 ff ff       	call   40f0 <buf_put>
    aa84:	e9 37 ff ff ff       	jmp    a9c0 <fwp_write+0xbe0>
    aa89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa90:	ba 01 00 00 00       	mov    $0x1,%edx
    aa95:	4c 89 fe             	mov    %r15,%rsi
    aa98:	48 89 df             	mov    %rbx,%rdi
    aa9b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    aaa0:	e8 4b 96 ff ff       	call   40f0 <buf_put>
    aaa5:	e9 cc f3 ff ff       	jmp    9e76 <fwp_write+0x96>
    aaaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aab0:	83 f8 04             	cmp    $0x4,%eax
    aab3:	0f 85 bb fb ff ff    	jne    a674 <fwp_write+0x894>
    aab9:	48 8b 04 24          	mov    (%rsp),%rax
    aabd:	48 8b 40 08          	mov    0x8(%rax),%rax
    aac1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    aac6:	48 c1 e8 3f          	shr    $0x3f,%rax
    aaca:	e9 96 fc ff ff       	jmp    a765 <fwp_write+0x985>
    aacf:	90                   	nop
    aad0:	8b 0c 24             	mov    (%rsp),%ecx
    aad3:	31 c0                	xor    %eax,%eax
    aad5:	85 c9                	test   %ecx,%ecx
    aad7:	0f 98 c0             	sets   %al
    aada:	e9 86 fc ff ff       	jmp    a765 <fwp_write+0x985>
    aadf:	90                   	nop
    aae0:	48 f7 d8             	neg    %rax
    aae3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    aaea:	00 
    aaeb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    aaf2:	2d 
    aaf3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aafa:	00 
    aafb:	48 83 d2 00          	adc    $0x0,%rdx
    aaff:	48 89 c6             	mov    %rax,%rsi
    ab02:	48 f7 da             	neg    %rdx
    ab05:	e8 36 8f ff ff       	call   3a40 <fwp_fmt_u128>
    ab0a:	e9 51 f3 ff ff       	jmp    9e60 <fwp_write+0x80>
    ab0f:	90                   	nop
    ab10:	b8 7d 00 00 00       	mov    $0x7d,%eax
    ab15:	e9 c3 f5 ff ff       	jmp    a0dd <fwp_write+0x2fd>
    ab1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab20:	4c 89 e9             	mov    %r13,%rcx
    ab23:	48 c1 e1 04          	shl    $0x4,%rcx
    ab27:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    ab2c:	48 85 ff             	test   %rdi,%rdi
    ab2f:	0f 89 eb f9 ff ff    	jns    a520 <fwp_write+0x740>
    ab35:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ab39:	48 89 ce             	mov    %rcx,%rsi
    ab3c:	e9 df f9 ff ff       	jmp    a520 <fwp_write+0x740>
    ab41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab48:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    ab4f:	00 
    ab50:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ab54:	e9 20 fa ff ff       	jmp    a579 <fwp_write+0x799>
    ab59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab60:	ba 02 00 00 00       	mov    $0x2,%edx
    ab65:	48 8d 35 da 56 00 00 	lea    0x56da(%rip),%rsi        # 10246 <_IO_stdin_used+0x246>
    ab6c:	e9 2d f7 ff ff       	jmp    a29e <fwp_write+0x4be>
    ab71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab78:	4c 8d 05 0b 57 00 00 	lea    0x570b(%rip),%r8        # 1028a <_IO_stdin_used+0x28a>
    ab7f:	b9 10 00 00 00       	mov    $0x10,%ecx
    ab84:	31 c0                	xor    %eax,%eax
    ab86:	ba 02 00 00 00       	mov    $0x2,%edx
    ab8b:	be 10 00 00 00       	mov    $0x10,%esi
    ab90:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ab97:	00 
    ab98:	e8 03 88 ff ff       	call   33a0 <__snprintf_chk@plt>
    ab9d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aba4:	00 
    aba5:	e8 96 88 ff ff       	call   3440 <strlen@plt>
    abaa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    abb1:	00 
    abb2:	48 89 df             	mov    %rbx,%rdi
    abb5:	48 89 c2             	mov    %rax,%rdx
    abb8:	e8 33 95 ff ff       	call   40f0 <buf_put>
    abbd:	e9 fe fd ff ff       	jmp    a9c0 <fwp_write+0xbe0>
    abc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abc8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    abcc:	48 8d 35 6d 56 00 00 	lea    0x566d(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    abd3:	48 8d 05 65 56 00 00 	lea    0x5665(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    abda:	4c 89 e7             	mov    %r12,%rdi
    abdd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    abe1:	48 0f 46 f0          	cmovbe %rax,%rsi
    abe5:	e8 f6 87 ff ff       	call   33e0 <strcpy@plt>
    abea:	e9 71 f2 ff ff       	jmp    9e60 <fwp_write+0x80>
    abef:	90                   	nop
    abf0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    abf4:	48 8d 35 45 56 00 00 	lea    0x5645(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    abfb:	48 8d 05 3d 56 00 00 	lea    0x563d(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    ac02:	0f 2f c8             	comiss %xmm0,%xmm1
    ac05:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac0c:	00 
    ac0d:	4c 89 e7             	mov    %r12,%rdi
    ac10:	48 0f 46 f0          	cmovbe %rax,%rsi
    ac14:	e8 c7 87 ff ff       	call   33e0 <strcpy@plt>
    ac19:	e9 42 f2 ff ff       	jmp    9e60 <fwp_write+0x80>
    ac1e:	66 90                	xchg   %ax,%ax
    ac20:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    ac25:	45 85 c0             	test   %r8d,%r8d
    ac28:	75 34                	jne    ac5e <fwp_write+0xe7e>
    ac2a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    ac31:	00 
    ac32:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ac39:	00 00 
    ac3b:	0f 85 74 f6 ff ff    	jne    a2b5 <fwp_write+0x4d5>
    ac41:	ba 02 00 00 00       	mov    $0x2,%edx
    ac46:	48 8d 35 6e 56 00 00 	lea    0x566e(%rip),%rsi        # 102bb <_IO_stdin_used+0x2bb>
    ac4d:	e9 a1 f3 ff ff       	jmp    9ff3 <fwp_write+0x213>
    ac52:	48 03 75 10          	add    0x10(%rbp),%rsi
    ac56:	49 89 f0             	mov    %rsi,%r8
    ac59:	e9 e5 fc ff ff       	jmp    a943 <fwp_write+0xb63>
    ac5e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ac63:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ac68:	85 ff                	test   %edi,%edi
    ac6a:	0f 84 fa f3 ff ff    	je     a06a <fwp_write+0x28a>
    ac70:	ba 01 00 00 00       	mov    $0x1,%edx
    ac75:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ac7a:	48 89 df             	mov    %rbx,%rdi
    ac7d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ac82:	e8 69 94 ff ff       	call   40f0 <buf_put>
    ac87:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ac8c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ac91:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ac97:	85 c0                	test   %eax,%eax
    ac99:	0f 8f f0 f3 ff ff    	jg     a08f <fwp_write+0x2af>
    ac9f:	e9 34 f4 ff ff       	jmp    a0d8 <fwp_write+0x2f8>
    aca4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    aca8:	49 89 c5             	mov    %rax,%r13
    acab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    acb0:	49 89 c4             	mov    %rax,%r12
    acb3:	49 c1 fd 3f          	sar    $0x3f,%r13
    acb7:	4c 09 e8             	or     %r13,%rax
    acba:	0f 84 a7 00 00 00    	je     ad67 <fwp_write+0xf87>
    acc0:	48 8d 2d 59 77 00 00 	lea    0x7759(%rip),%rbp        # 12420 <units.1>
    acc7:	4d 89 e7             	mov    %r12,%r15
    acca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    acce:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    acd3:	4c 89 ff             	mov    %r15,%rdi
    acd6:	4c 89 ee             	mov    %r13,%rsi
    acd9:	44 89 0c 24          	mov    %r9d,(%rsp)
    acdd:	48 99                	cqto
    acdf:	48 89 d1             	mov    %rdx,%rcx
    ace2:	48 89 c2             	mov    %rax,%rdx
    ace5:	e8 16 44 00 00       	call   f100 <__divmodti4>
    acea:	44 8b 0c 24          	mov    (%rsp),%r9d
    acee:	48 89 c1             	mov    %rax,%rcx
    acf1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    acf6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    acfb:	0f 84 94 00 00 00    	je     ad95 <fwp_write+0xfb5>
    ad01:	41 83 c1 01          	add    $0x1,%r9d
    ad05:	48 83 c5 10          	add    $0x10,%rbp
    ad09:	41 83 f9 05          	cmp    $0x5,%r9d
    ad0d:	75 bb                	jne    acca <fwp_write+0xeea>
    ad0f:	4d 85 ed             	test   %r13,%r13
    ad12:	79 53                	jns    ad67 <fwp_write+0xf87>
    ad14:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ad19:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ad1e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ad23:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad28:	48 99                	cqto
    ad2a:	48 f7 d8             	neg    %rax
    ad2d:	48 83 d2 00          	adc    $0x0,%rdx
    ad31:	48 89 c6             	mov    %rax,%rsi
    ad34:	48 f7 da             	neg    %rdx
    ad37:	e8 04 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ad3c:	49 89 e8             	mov    %rbp,%r8
    ad3f:	ba 00 02 00 00       	mov    $0x200,%edx
    ad44:	be 02 00 00 00       	mov    $0x2,%esi
    ad49:	31 c0                	xor    %eax,%eax
    ad4b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ad52:	00 
    ad53:	48 8d 0d 5c 55 00 00 	lea    0x555c(%rip),%rcx        # 102b6 <_IO_stdin_used+0x2b6>
    ad5a:	4c 89 e7             	mov    %r12,%rdi
    ad5d:	e8 5e 89 ff ff       	call   36c0 <__sprintf_chk@plt>
    ad62:	e9 f9 f0 ff ff       	jmp    9e60 <fwp_write+0x80>
    ad67:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad6c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ad71:	31 d2                	xor    %edx,%edx
    ad73:	48 89 ef             	mov    %rbp,%rdi
    ad76:	e8 c5 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ad7b:	eb bf                	jmp    ad3c <fwp_write+0xf5c>
    ad7d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ad84:	4e 61 4e 00 
    ad88:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ad8f:	00 
    ad90:	e9 cb f0 ff ff       	jmp    9e60 <fwp_write+0x80>
    ad95:	44 89 0c 24          	mov    %r9d,(%rsp)
    ad99:	48 89 c8             	mov    %rcx,%rax
    ad9c:	48 85 d2             	test   %rdx,%rdx
    ad9f:	78 51                	js     adf2 <fwp_write+0x1012>
    ada1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ada6:	48 89 c6             	mov    %rax,%rsi
    ada9:	48 89 ef             	mov    %rbp,%rdi
    adac:	e8 8f 8c ff ff       	call   3a40 <fwp_fmt_u128>
    adb1:	44 8b 0c 24          	mov    (%rsp),%r9d
    adb5:	49 63 c1             	movslq %r9d,%rax
    adb8:	49 89 e8             	mov    %rbp,%r8
    adbb:	ba 00 02 00 00       	mov    $0x200,%edx
    adc0:	be 02 00 00 00       	mov    $0x2,%esi
    adc5:	48 c1 e0 04          	shl    $0x4,%rax
    adc9:	48 8d 3d 50 76 00 00 	lea    0x7650(%rip),%rdi        # 12420 <units.1>
    add0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    add7:	00 
    add8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    addc:	48 8d 0d ce 54 00 00 	lea    0x54ce(%rip),%rcx        # 102b1 <_IO_stdin_used+0x2b1>
    ade3:	4c 89 e7             	mov    %r12,%rdi
    ade6:	31 c0                	xor    %eax,%eax
    ade8:	e8 d3 88 ff ff       	call   36c0 <__sprintf_chk@plt>
    aded:	e9 6e f0 ff ff       	jmp    9e60 <fwp_write+0x80>
    adf2:	48 f7 d8             	neg    %rax
    adf5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    adfa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    adff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae04:	48 83 d2 00          	adc    $0x0,%rdx
    ae08:	48 89 c6             	mov    %rax,%rsi
    ae0b:	48 f7 da             	neg    %rdx
    ae0e:	e8 2d 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ae13:	44 8b 0c 24          	mov    (%rsp),%r9d
    ae17:	eb 9c                	jmp    adb5 <fwp_write+0xfd5>
    ae19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ae20 <fwp_hof0.constprop.0>:
    ae20:	55                   	push   %rbp
    ae21:	48 89 e5             	mov    %rsp,%rbp
    ae24:	41 57                	push   %r15
    ae26:	41 56                	push   %r14
    ae28:	41 55                	push   %r13
    ae2a:	41 54                	push   %r12
    ae2c:	53                   	push   %rbx
    ae2d:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    ae34:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    ae3b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ae42:	00 00 
    ae44:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ae48:	31 c0                	xor    %eax,%eax
    ae4a:	48 85 f6             	test   %rsi,%rsi
    ae4d:	0f 84 cc 06 00 00    	je     b51f <fwp_hof0.constprop.0+0x6ff>
    ae53:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    ae57:	49 89 f7             	mov    %rsi,%r15
    ae5a:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    ae61:	48 8d 35 d8 19 06 00 	lea    0x619d8(%rip),%rsi        # 6c840 <fwp_heap>
    ae68:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    ae6f:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    ae76:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ae7d:	48 89 fa             	mov    %rdi,%rdx
    ae80:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    ae84:	48 c1 e2 10          	shl    $0x10,%rdx
    ae88:	48 39 d0             	cmp    %rdx,%rax
    ae8b:	73 6b                	jae    aef8 <fwp_hof0.constprop.0+0xd8>
    ae8d:	48 89 c2             	mov    %rax,%rdx
    ae90:	48 c1 ea 10          	shr    $0x10,%rdx
    ae94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae98:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ae9f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aea3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    aea7:	48 85 ff             	test   %rdi,%rdi
    aeaa:	74 4c                	je     aef8 <fwp_hof0.constprop.0+0xd8>
    aeac:	0f b6 0a             	movzbl (%rdx),%ecx
    aeaf:	80 f9 02             	cmp    $0x2,%cl
    aeb2:	0f 84 11 0c 00 00    	je     bac9 <fwp_hof0.constprop.0+0xca9>
    aeb8:	80 f9 01             	cmp    $0x1,%cl
    aebb:	75 3b                	jne    aef8 <fwp_hof0.constprop.0+0xd8>
    aebd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aec0:	0f b7 c0             	movzwl %ax,%eax
    aec3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aec6:	48 0f af c1          	imul   %rcx,%rax
    aeca:	48 c1 e8 20          	shr    $0x20,%rax
    aece:	48 39 d0             	cmp    %rdx,%rax
    aed1:	73 25                	jae    aef8 <fwp_hof0.constprop.0+0xd8>
    aed3:	48 01 c7             	add    %rax,%rdi
    aed6:	0f b6 07             	movzbl (%rdi),%eax
    aed9:	84 c0                	test   %al,%al
    aedb:	74 1b                	je     aef8 <fwp_hof0.constprop.0+0xd8>
    aedd:	8b 35 25 36 06 00    	mov    0x63625(%rip),%esi        # 6e508 <iteration_active>
    aee3:	85 f6                	test   %esi,%esi
    aee5:	0f 85 ec 0b 00 00    	jne    bad7 <fwp_hof0.constprop.0+0xcb7>
    aeeb:	3c fd                	cmp    $0xfd,%al
    aeed:	0f 87 cd 0c 00 00    	ja     bbc0 <fwp_hof0.constprop.0+0xda0>
    aef3:	83 c0 01             	add    $0x1,%eax
    aef6:	88 07                	mov    %al,(%rdi)
    aef8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    aeff:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    af06:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    af0d:	c7 00 00 00 
    af11:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    af15:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    af19:	48 8b 15 78 35 06 00 	mov    0x63578(%rip),%rdx        # 6e498 <fwp_fns>
    af20:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    af24:	48 8d 05 ed 90 00 00 	lea    0x90ed(%rip),%rax        # 14018 <fc12>
    af2b:	44 8b 20             	mov    (%rax),%r12d
    af2e:	49 c1 e4 05          	shl    $0x5,%r12
    af32:	49 01 d4             	add    %rdx,%r12
    af35:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    af3a:	48 85 c9             	test   %rcx,%rcx
    af3d:	0f 84 53 0b 00 00    	je     ba96 <fwp_hof0.constprop.0+0xc76>
    af43:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    af48:	0f 84 2a 09 00 00    	je     b878 <fwp_hof0.constprop.0+0xa58>
    af4e:	48 8d 1d eb 18 06 00 	lea    0x618eb(%rip),%rbx        # 6c840 <fwp_heap>
    af55:	48 8d 05 bc 90 00 00 	lea    0x90bc(%rip),%rax        # 14018 <fc12>
    af5c:	48 8b b3 d8 13 00 00 	mov    0x13d8(%rbx),%rsi
    af63:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    af6a:	48 89 f1             	mov    %rsi,%rcx
    af6d:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    af71:	48 c1 e1 10          	shl    $0x10,%rcx
    af75:	48 39 c8             	cmp    %rcx,%rax
    af78:	73 71                	jae    afeb <fwp_hof0.constprop.0+0x1cb>
    af7a:	48 89 c1             	mov    %rax,%rcx
    af7d:	48 c1 e9 10          	shr    $0x10,%rcx
    af81:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    af85:	48 8b 8b f8 13 00 00 	mov    0x13f8(%rbx),%rcx
    af8c:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    af90:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    af94:	48 85 ff             	test   %rdi,%rdi
    af97:	74 52                	je     afeb <fwp_hof0.constprop.0+0x1cb>
    af99:	0f b6 31             	movzbl (%rcx),%esi
    af9c:	40 80 fe 02          	cmp    $0x2,%sil
    afa0:	0f 84 ed 09 00 00    	je     b993 <fwp_hof0.constprop.0+0xb73>
    afa6:	40 80 fe 01          	cmp    $0x1,%sil
    afaa:	75 3f                	jne    afeb <fwp_hof0.constprop.0+0x1cb>
    afac:	8b 71 18             	mov    0x18(%rcx),%esi
    afaf:	0f b7 c0             	movzwl %ax,%eax
    afb2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    afb5:	48 0f af c6          	imul   %rsi,%rax
    afb9:	48 c1 e8 20          	shr    $0x20,%rax
    afbd:	48 39 c8             	cmp    %rcx,%rax
    afc0:	73 29                	jae    afeb <fwp_hof0.constprop.0+0x1cb>
    afc2:	48 01 c7             	add    %rax,%rdi
    afc5:	0f b6 07             	movzbl (%rdi),%eax
    afc8:	84 c0                	test   %al,%al
    afca:	74 1f                	je     afeb <fwp_hof0.constprop.0+0x1cb>
    afcc:	8b 0d 36 35 06 00    	mov    0x63536(%rip),%ecx        # 6e508 <iteration_active>
    afd2:	85 c9                	test   %ecx,%ecx
    afd4:	74 08                	je     afde <fwp_hof0.constprop.0+0x1be>
    afd6:	48 83 05 12 35 06 00 	addq   $0x1,0x63512(%rip)        # 6e4f0 <iteration_retains>
    afdd:	01 
    afde:	3c fd                	cmp    $0xfd,%al
    afe0:	0f 87 8a 0a 00 00    	ja     ba70 <fwp_hof0.constprop.0+0xc50>
    afe6:	83 c0 01             	add    $0x1,%eax
    afe9:	88 07                	mov    %al,(%rdi)
    afeb:	48 8d 05 26 90 00 00 	lea    0x9026(%rip),%rax        # 14018 <fc12>
    aff2:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    aff9:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    affd:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b004:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b008:	48 8d 05 09 90 00 00 	lea    0x9009(%rip),%rax        # 14018 <fc12>
    b00f:	41 8b 0c 24          	mov    (%r12),%ecx
    b013:	2b 48 04             	sub    0x4(%rax),%ecx
    b016:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b01a:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    b01e:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    b021:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b025:	49 89 c1             	mov    %rax,%r9
    b028:	8b 00                	mov    (%rax),%eax
    b02a:	44 39 e9             	cmp    %r13d,%ecx
    b02d:	44 0f 46 e9          	cmovbe %ecx,%r13d
    b031:	4c 89 cb             	mov    %r9,%rbx
    b034:	48 c1 e0 05          	shl    $0x5,%rax
    b038:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    b03c:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    b043:	4d 8b 50 18          	mov    0x18(%r8),%r10
    b047:	4d 85 d2             	test   %r10,%r10
    b04a:	75 5c                	jne    b0a8 <fwp_hof0.constprop.0+0x288>
    b04c:	e9 12 02 00 00       	jmp    b263 <fwp_hof0.constprop.0+0x443>
    b051:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b058:	85 db                	test   %ebx,%ebx
    b05a:	74 6a                	je     b0c6 <fwp_hof0.constprop.0+0x2a6>
    b05c:	4c 89 e7             	mov    %r12,%rdi
    b05f:	41 ff 12             	call   *(%r10)
    b062:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b066:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    b06a:	e8 81 c1 ff ff       	call   71f0 <fwp_closure_drop>
    b06f:	45 39 ee             	cmp    %r13d,%r14d
    b072:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    b076:	0f 84 ec 07 00 00    	je     b868 <fwp_hof0.constprop.0+0xa48>
    b07c:	44 8b 00             	mov    (%rax),%r8d
    b07f:	41 29 df             	sub    %ebx,%r15d
    b082:	4f 8d 24 f4          	lea    (%r12,%r14,8),%r12
    b086:	49 89 c1             	mov    %rax,%r9
    b089:	45 89 fd             	mov    %r15d,%r13d
    b08c:	49 c1 e0 05          	shl    $0x5,%r8
    b090:	4c 03 05 01 34 06 00 	add    0x63401(%rip),%r8        # 6e498 <fwp_fns>
    b097:	4d 8b 50 18          	mov    0x18(%r8),%r10
    b09b:	4d 85 d2             	test   %r10,%r10
    b09e:	0f 84 bc 01 00 00    	je     b260 <fwp_hof0.constprop.0+0x440>
    b0a4:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b0a8:	41 8b 49 04          	mov    0x4(%r9),%ecx
    b0ac:	41 8b 18             	mov    (%r8),%ebx
    b0af:	46 8d 3c 29          	lea    (%rcx,%r13,1),%r15d
    b0b3:	41 39 df             	cmp    %ebx,%r15d
    b0b6:	0f 82 8c 04 00 00    	jb     b548 <fwp_hof0.constprop.0+0x728>
    b0bc:	41 89 de             	mov    %ebx,%r14d
    b0bf:	41 29 ce             	sub    %ecx,%r14d
    b0c2:	85 c9                	test   %ecx,%ecx
    b0c4:	74 92                	je     b058 <fwp_hof0.constprop.0+0x238>
    b0c6:	85 db                	test   %ebx,%ebx
    b0c8:	b8 01 00 00 00       	mov    $0x1,%eax
    b0cd:	48 89 e6             	mov    %rsp,%rsi
    b0d0:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    b0d4:	0f 45 c3             	cmovne %ebx,%eax
    b0d7:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    b0de:	00 
    b0df:	48 c1 e8 04          	shr    $0x4,%rax
    b0e3:	48 c1 e0 04          	shl    $0x4,%rax
    b0e7:	48 89 c7             	mov    %rax,%rdi
    b0ea:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b0f1:	48 29 fe             	sub    %rdi,%rsi
    b0f4:	48 39 f4             	cmp    %rsi,%rsp
    b0f7:	74 15                	je     b10e <fwp_hof0.constprop.0+0x2ee>
    b0f9:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b100:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b107:	00 00 
    b109:	48 39 f4             	cmp    %rsi,%rsp
    b10c:	75 eb                	jne    b0f9 <fwp_hof0.constprop.0+0x2d9>
    b10e:	25 ff 0f 00 00       	and    $0xfff,%eax
    b113:	48 29 c4             	sub    %rax,%rsp
    b116:	48 85 c0             	test   %rax,%rax
    b119:	74 06                	je     b121 <fwp_hof0.constprop.0+0x301>
    b11b:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    b121:	89 cf                	mov    %ecx,%edi
    b123:	49 89 e3             	mov    %rsp,%r11
    b126:	31 c0                	xor    %eax,%eax
    b128:	48 c1 e7 03          	shl    $0x3,%rdi
    b12c:	85 c9                	test   %ecx,%ecx
    b12e:	74 22                	je     b152 <fwp_hof0.constprop.0+0x332>
    b130:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b13c:	00 00 00 00 
    b140:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    b145:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    b149:	48 83 c0 08          	add    $0x8,%rax
    b14d:	48 39 c7             	cmp    %rax,%rdi
    b150:	75 ee                	jne    b140 <fwp_hof0.constprop.0+0x320>
    b152:	45 85 f6             	test   %r14d,%r14d
    b155:	74 3e                	je     b195 <fwp_hof0.constprop.0+0x375>
    b157:	44 89 f6             	mov    %r14d,%esi
    b15a:	4c 89 e0             	mov    %r12,%rax
    b15d:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    b161:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b168:	00 00 
    b16a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b171:	00 00 00 00 
    b175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b17c:	00 00 00 00 
    b180:	48 8b 30             	mov    (%rax),%rsi
    b183:	89 ca                	mov    %ecx,%edx
    b185:	48 83 c0 08          	add    $0x8,%rax
    b189:	83 c1 01             	add    $0x1,%ecx
    b18c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    b190:	48 39 c7             	cmp    %rax,%rdi
    b193:	75 eb                	jne    b180 <fwp_hof0.constprop.0+0x360>
    b195:	48 8d 15 a4 16 06 00 	lea    0x616a4(%rip),%rdx        # 6c840 <fwp_heap>
    b19c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b1a0:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b1a7:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b1ae:	48 89 f1             	mov    %rsi,%rcx
    b1b1:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    b1b5:	48 c1 e1 10          	shl    $0x10,%rcx
    b1b9:	48 39 c8             	cmp    %rcx,%rax
    b1bc:	73 4c                	jae    b20a <fwp_hof0.constprop.0+0x3ea>
    b1be:	48 89 c1             	mov    %rax,%rcx
    b1c1:	48 c1 e9 10          	shr    $0x10,%rcx
    b1c5:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b1c9:	48 8b 0d 68 2a 06 00 	mov    0x62a68(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    b1d0:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b1d4:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    b1d8:	48 85 f6             	test   %rsi,%rsi
    b1db:	74 2d                	je     b20a <fwp_hof0.constprop.0+0x3ea>
    b1dd:	0f b6 39             	movzbl (%rcx),%edi
    b1e0:	40 80 ff 02          	cmp    $0x2,%dil
    b1e4:	74 6a                	je     b250 <fwp_hof0.constprop.0+0x430>
    b1e6:	40 80 ff 01          	cmp    $0x1,%dil
    b1ea:	75 1e                	jne    b20a <fwp_hof0.constprop.0+0x3ea>
    b1ec:	8b 79 18             	mov    0x18(%rcx),%edi
    b1ef:	0f b7 c0             	movzwl %ax,%eax
    b1f2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b1f5:	48 0f af c7          	imul   %rdi,%rax
    b1f9:	48 c1 e8 20          	shr    $0x20,%rax
    b1fd:	48 39 c8             	cmp    %rcx,%rax
    b200:	73 08                	jae    b20a <fwp_hof0.constprop.0+0x3ea>
    b202:	48 01 c6             	add    %rax,%rsi
    b205:	80 3e 01             	cmpb   $0x1,(%rsi)
    b208:	74 36                	je     b240 <fwp_hof0.constprop.0+0x420>
    b20a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    b20e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b212:	be 01 00 00 00       	mov    $0x1,%esi
    b217:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    b21b:	41 ff 52 08          	call   *0x8(%r10)
    b21f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    b223:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    b227:	49 8b 40 18          	mov    0x18(%r8),%rax
    b22b:	4c 89 df             	mov    %r11,%rdi
    b22e:	ff 10                	call   *(%rax)
    b230:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    b234:	e9 29 fe ff ff       	jmp    b062 <fwp_hof0.constprop.0+0x242>
    b239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b240:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b247:	00 
    b248:	eb dd                	jmp    b227 <fwp_hof0.constprop.0+0x407>
    b24a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b250:	66 85 c0             	test   %ax,%ax
    b253:	75 b5                	jne    b20a <fwp_hof0.constprop.0+0x3ea>
    b255:	eb ae                	jmp    b205 <fwp_hof0.constprop.0+0x3e5>
    b257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b25e:	00 00 
    b260:	48 89 c3             	mov    %rax,%rbx
    b263:	48 89 df             	mov    %rbx,%rdi
    b266:	e8 45 b8 ff ff       	call   6ab0 <fwp_rc_share>
    b26b:	45 85 ed             	test   %r13d,%r13d
    b26e:	74 21                	je     b291 <fwp_hof0.constprop.0+0x471>
    b270:	44 89 ea             	mov    %r13d,%edx
    b273:	4d 89 e7             	mov    %r12,%r15
    b276:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    b27a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b280:	49 8b 3f             	mov    (%r15),%rdi
    b283:	49 83 c7 08          	add    $0x8,%r15
    b287:	e8 24 b8 ff ff       	call   6ab0 <fwp_rc_share>
    b28c:	4d 39 f7             	cmp    %r14,%r15
    b28f:	75 ef                	jne    b280 <fwp_hof0.constprop.0+0x460>
    b291:	4c 89 e2             	mov    %r12,%rdx
    b294:	44 89 ee             	mov    %r13d,%esi
    b297:	48 89 df             	mov    %rbx,%rdi
    b29a:	e8 61 ae ff ff       	call   6100 <fwp_apply>
    b29f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b2a3:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b2a6:	39 75 90             	cmp    %esi,-0x70(%rbp)
    b2a9:	0f 83 87 00 00 00    	jae    b336 <fwp_hof0.constprop.0+0x516>
    b2af:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    b2b5:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b2b9:	48 89 c3             	mov    %rax,%rbx
    b2bc:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    b2c0:	48 8b 15 d1 31 06 00 	mov    0x631d1(%rip),%rdx        # 6e498 <fwp_fns>
    b2c7:	29 de                	sub    %ebx,%esi
    b2c9:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b2cd:	89 75 94             	mov    %esi,-0x6c(%rbp)
    b2d0:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b2d4:	44 8b 26             	mov    (%rsi),%r12d
    b2d7:	48 89 f0             	mov    %rsi,%rax
    b2da:	49 c1 e4 05          	shl    $0x5,%r12
    b2de:	49 01 d4             	add    %rdx,%r12
    b2e1:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    b2e7:	0f 85 22 fd ff ff    	jne    b00f <fwp_hof0.constprop.0+0x1ef>
    b2ed:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b2f1:	e8 ba b7 ff ff       	call   6ab0 <fwp_rc_share>
    b2f6:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    b2fa:	45 85 f6             	test   %r14d,%r14d
    b2fd:	74 23                	je     b322 <fwp_hof0.constprop.0+0x502>
    b2ff:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b303:	31 db                	xor    %ebx,%ebx
    b305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b30c:	00 00 00 00 
    b310:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b314:	48 83 c3 01          	add    $0x1,%rbx
    b318:	e8 93 b7 ff ff       	call   6ab0 <fwp_rc_share>
    b31d:	44 39 f3             	cmp    %r14d,%ebx
    b320:	72 ee                	jb     b310 <fwp_hof0.constprop.0+0x4f0>
    b322:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b326:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b329:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b32d:	e8 ce ad ff ff       	call   6100 <fwp_apply>
    b332:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b336:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    b33d:	01 
    b33e:	0f 85 d1 fb ff ff    	jne    af15 <fwp_hof0.constprop.0+0xf5>
    b344:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b348:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b34f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b353:	b9 01 00 00 00       	mov    $0x1,%ecx
    b358:	48 8d 15 41 88 00 00 	lea    0x8841(%rip),%rdx        # 13ba0 <d0>
    b35f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    b366:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    b36d:	00 
    b36e:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    b372:	e8 69 ea ff ff       	call   9de0 <fwp_write>
    b377:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    b37b:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    b37f:	48 8d 05 e6 4c 00 00 	lea    0x4ce6(%rip),%rax        # 1006c <_IO_stdin_used+0x6c>
    b386:	48 85 c9             	test   %rcx,%rcx
    b389:	48 0f 44 c8          	cmove  %rax,%rcx
    b38d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    b391:	0f 87 15 08 00 00    	ja     bbac <fwp_hof0.constprop.0+0xd8c>
    b397:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    b39b:	be 01 00 00 00       	mov    $0x1,%esi
    b3a0:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    b3a4:	e8 67 ab ff ff       	call   5f10 <fwp_heap_alloc>
    b3a9:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    b3ad:	4c 89 f2             	mov    %r14,%rdx
    b3b0:	4c 89 30             	mov    %r14,(%rax)
    b3b3:	4c 8d 60 08          	lea    0x8(%rax),%r12
    b3b7:	48 89 c3             	mov    %rax,%rbx
    b3ba:	4c 89 e7             	mov    %r12,%rdi
    b3bd:	e8 be 81 ff ff       	call   3580 <memcpy@plt>
    b3c2:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    b3c8:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    b3cc:	e8 df 7f ff ff       	call   33b0 <free@plt>
    b3d1:	48 8d 35 68 14 06 00 	lea    0x61468(%rip),%rsi        # 6c840 <fwp_heap>
    b3d8:	48 89 d8             	mov    %rbx,%rax
    b3db:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b3e2:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b3e9:	48 89 fa             	mov    %rdi,%rdx
    b3ec:	48 89 7d a0          	mov    %rdi,-0x60(%rbp)
    b3f0:	48 c1 e2 10          	shl    $0x10,%rdx
    b3f4:	48 39 d0             	cmp    %rdx,%rax
    b3f7:	73 57                	jae    b450 <fwp_hof0.constprop.0+0x630>
    b3f9:	48 89 c2             	mov    %rax,%rdx
    b3fc:	48 c1 ea 10          	shr    $0x10,%rdx
    b400:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b404:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b40b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b40f:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b413:	4d 85 f6             	test   %r14,%r14
    b416:	74 38                	je     b450 <fwp_hof0.constprop.0+0x630>
    b418:	0f b6 0a             	movzbl (%rdx),%ecx
    b41b:	80 f9 02             	cmp    $0x2,%cl
    b41e:	0f 84 da 06 00 00    	je     bafe <fwp_hof0.constprop.0+0xcde>
    b424:	80 f9 01             	cmp    $0x1,%cl
    b427:	75 27                	jne    b450 <fwp_hof0.constprop.0+0x630>
    b429:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b42c:	0f b7 c0             	movzwl %ax,%eax
    b42f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b432:	48 0f af c1          	imul   %rcx,%rax
    b436:	48 c1 e8 20          	shr    $0x20,%rax
    b43a:	48 39 d0             	cmp    %rdx,%rax
    b43d:	73 11                	jae    b450 <fwp_hof0.constprop.0+0x630>
    b43f:	49 01 c6             	add    %rax,%r14
    b442:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b446:	0f 84 84 07 00 00    	je     bbd0 <fwp_hof0.constprop.0+0xdb0>
    b44c:	41 c6 06 01          	movb   $0x1,(%r14)
    b450:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b454:	e8 b7 ba ff ff       	call   6f10 <fwp_drop0>
    b459:	48 8b 13             	mov    (%rbx),%rdx
    b45c:	be 01 00 00 00       	mov    $0x1,%esi
    b461:	4c 89 e7             	mov    %r12,%rdi
    b464:	48 8b 0d 35 30 06 00 	mov    0x63035(%rip),%rcx        # 6e4a0 <fwp_prog_out>
    b46b:	e8 f0 81 ff ff       	call   3660 <fwrite@plt>
    b470:	48 8b 35 29 30 06 00 	mov    0x63029(%rip),%rsi        # 6e4a0 <fwp_prog_out>
    b477:	bf 0a 00 00 00       	mov    $0xa,%edi
    b47c:	e8 4f 80 ff ff       	call   34d0 <fputc@plt>
    b481:	48 8d 35 b8 13 06 00 	lea    0x613b8(%rip),%rsi        # 6c840 <fwp_heap>
    b488:	48 89 d8             	mov    %rbx,%rax
    b48b:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b492:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b499:	48 89 fa             	mov    %rdi,%rdx
    b49c:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    b4a0:	48 c1 e2 10          	shl    $0x10,%rdx
    b4a4:	48 39 d0             	cmp    %rdx,%rax
    b4a7:	73 69                	jae    b512 <fwp_hof0.constprop.0+0x6f2>
    b4a9:	48 89 c2             	mov    %rax,%rdx
    b4ac:	48 c1 ea 10          	shr    $0x10,%rdx
    b4b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b4b4:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b4bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b4bf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b4c3:	4d 85 e4             	test   %r12,%r12
    b4c6:	74 4a                	je     b512 <fwp_hof0.constprop.0+0x6f2>
    b4c8:	0f b6 0a             	movzbl (%rdx),%ecx
    b4cb:	80 f9 02             	cmp    $0x2,%cl
    b4ce:	0f 84 38 06 00 00    	je     bb0c <fwp_hof0.constprop.0+0xcec>
    b4d4:	80 f9 01             	cmp    $0x1,%cl
    b4d7:	75 39                	jne    b512 <fwp_hof0.constprop.0+0x6f2>
    b4d9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b4dc:	0f b7 c0             	movzwl %ax,%eax
    b4df:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4e2:	48 0f af c1          	imul   %rcx,%rax
    b4e6:	48 c1 e8 20          	shr    $0x20,%rax
    b4ea:	48 39 d0             	cmp    %rdx,%rax
    b4ed:	73 23                	jae    b512 <fwp_hof0.constprop.0+0x6f2>
    b4ef:	49 01 c4             	add    %rax,%r12
    b4f2:	41 0f b6 04 24       	movzbl (%r12),%eax
    b4f7:	84 c0                	test   %al,%al
    b4f9:	74 17                	je     b512 <fwp_hof0.constprop.0+0x6f2>
    b4fb:	3c 01                	cmp    $0x1,%al
    b4fd:	0f 84 e1 05 00 00    	je     bae4 <fwp_hof0.constprop.0+0xcc4>
    b503:	3c ff                	cmp    $0xff,%al
    b505:	0f 84 0f 06 00 00    	je     bb1a <fwp_hof0.constprop.0+0xcfa>
    b50b:	83 e8 01             	sub    $0x1,%eax
    b50e:	41 88 04 24          	mov    %al,(%r12)
    b512:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b516:	4d 85 ff             	test   %r15,%r15
    b519:	0f 85 42 f9 ff ff    	jne    ae61 <fwp_hof0.constprop.0+0x41>
    b51f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b523:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b52a:	00 00 
    b52c:	0f 85 98 06 00 00    	jne    bbca <fwp_hof0.constprop.0+0xdaa>
    b532:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b536:	31 c0                	xor    %eax,%eax
    b538:	5b                   	pop    %rbx
    b539:	41 5c                	pop    %r12
    b53b:	41 5d                	pop    %r13
    b53d:	41 5e                	pop    %r14
    b53f:	41 5f                	pop    %r15
    b541:	5d                   	pop    %rbp
    b542:	c3                   	ret
    b543:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b548:	44 8b 1d b9 2f 06 00 	mov    0x62fb9(%rip),%r11d        # 6e508 <iteration_active>
    b54f:	41 8d 77 01          	lea    0x1(%r15),%esi
    b553:	8b 05 8b 26 06 00    	mov    0x6268b(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    b559:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    b560:	00 
    b561:	45 85 db             	test   %r11d,%r11d
    b564:	0f 84 f3 03 00 00    	je     b95d <fwp_hof0.constprop.0+0xb3d>
    b56a:	48 83 05 8e 2f 06 00 	addq   $0x1,0x62f8e(%rip)        # 6e500 <iteration_requests>
    b571:	01 
    b572:	48 01 3d 7f 2f 06 00 	add    %rdi,0x62f7f(%rip)        # 6e4f8 <iteration_bytes>
    b579:	85 c0                	test   %eax,%eax
    b57b:	0f 84 ca 04 00 00    	je     ba4b <fwp_hof0.constprop.0+0xc2b>
    b581:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b588:	0f 87 bd 04 00 00    	ja     ba4b <fwp_hof0.constprop.0+0xc2b>
    b58e:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    b592:	48 8d 1d a7 12 06 00 	lea    0x612a7(%rip),%rbx        # 6c840 <fwp_heap>
    b599:	48 c1 e8 04          	shr    $0x4,%rax
    b59d:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    b5a4:	00 
    b5a5:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    b5ac:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    b5b0:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    b5b4:	4c 8b 12             	mov    (%rdx),%r10
    b5b7:	4d 85 d2             	test   %r10,%r10
    b5ba:	0f 84 e1 03 00 00    	je     b9a1 <fwp_hof0.constprop.0+0xb81>
    b5c0:	49 8b 1a             	mov    (%r10),%rbx
    b5c3:	48 f7 d3             	not    %rbx
    b5c6:	48 89 1a             	mov    %rbx,(%rdx)
    b5c9:	48 39 c7             	cmp    %rax,%rdi
    b5cc:	73 6c                	jae    b63a <fwp_hof0.constprop.0+0x81a>
    b5ce:	48 89 fa             	mov    %rdi,%rdx
    b5d1:	48 83 c7 08          	add    $0x8,%rdi
    b5d5:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    b5dc:	00 
    b5dd:	48 f7 d2             	not    %rdx
    b5e0:	48 01 c2             	add    %rax,%rdx
    b5e3:	48 c1 ea 03          	shr    $0x3,%rdx
    b5e7:	48 39 c7             	cmp    %rax,%rdi
    b5ea:	73 4e                	jae    b63a <fwp_hof0.constprop.0+0x81a>
    b5ec:	83 e2 01             	and    $0x1,%edx
    b5ef:	74 2f                	je     b620 <fwp_hof0.constprop.0+0x800>
    b5f1:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b5f8:	00 
    b5f9:	48 83 c7 08          	add    $0x8,%rdi
    b5fd:	48 39 c7             	cmp    %rax,%rdi
    b600:	73 38                	jae    b63a <fwp_hof0.constprop.0+0x81a>
    b602:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b609:	00 
    b60a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b611:	00 00 00 00 
    b615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b61c:	00 00 00 00 
    b620:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b627:	00 
    b628:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    b62f:	00 00 
    b631:	48 83 c7 10          	add    $0x10,%rdi
    b635:	48 39 c7             	cmp    %rax,%rdi
    b638:	72 e6                	jb     b620 <fwp_hof0.constprop.0+0x800>
    b63a:	48 8d 3d ff 11 06 00 	lea    0x611ff(%rip),%rdi        # 6c840 <fwp_heap>
    b641:	48 89 c2             	mov    %rax,%rdx
    b644:	48 03 97 20 14 00 00 	add    0x1420(%rdi),%rdx
    b64b:	0f 82 4a 05 00 00    	jb     bb9b <fwp_hof0.constprop.0+0xd7b>
    b651:	48 89 97 20 14 00 00 	mov    %rdx,0x1420(%rdi)
    b658:	48 39 97 28 14 00 00 	cmp    %rdx,0x1428(%rdi)
    b65f:	73 07                	jae    b668 <fwp_hof0.constprop.0+0x848>
    b661:	48 89 15 00 26 06 00 	mov    %rdx,0x62600(%rip)        # 6dc68 <fwp_heap+0x1428>
    b668:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b66c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b671:	f2 0f 58 05 ff 25 06 	addsd  0x625ff(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    b678:	00 
    b679:	f2 0f 11 05 f7 25 06 	movsd  %xmm0,0x625f7(%rip)        # 6dc78 <fwp_heap+0x1438>
    b680:	00 
    b681:	45 85 db             	test   %r11d,%r11d
    b684:	74 33                	je     b6b9 <fwp_hof0.constprop.0+0x899>
    b686:	48 8b 05 d3 25 06 00 	mov    0x625d3(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    b68d:	48 85 c0             	test   %rax,%rax
    b690:	0f 88 64 03 00 00    	js     b9fa <fwp_hof0.constprop.0+0xbda>
    b696:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b69a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b69f:	f2 0f 5c 05 41 2e 06 	subsd  0x62e41(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    b6a6:	00 
    b6a7:	66 0f 2f 05 31 2e 06 	comisd 0x62e31(%rip),%xmm0        # 6e4e0 <iteration_peak>
    b6ae:	00 
    b6af:	76 08                	jbe    b6b9 <fwp_hof0.constprop.0+0x899>
    b6b1:	f2 0f 11 05 27 2e 06 	movsd  %xmm0,0x62e27(%rip)        # 6e4e0 <iteration_peak>
    b6b8:	00 
    b6b9:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b6be:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b6c3:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b6c7:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b6cc:	85 c9                	test   %ecx,%ecx
    b6ce:	74 37                	je     b707 <fwp_hof0.constprop.0+0x8e7>
    b6d0:	89 ca                	mov    %ecx,%edx
    b6d2:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b6d6:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b6da:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b6dd:	48 c1 e2 03          	shl    $0x3,%rdx
    b6e1:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b6e8:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b6ec:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b6f0:	e8 fb 7e ff ff       	call   35f0 <memmove@plt>
    b6f5:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b6f9:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b6fd:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b700:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b707:	45 85 ed             	test   %r13d,%r13d
    b70a:	74 2b                	je     b737 <fwp_hof0.constprop.0+0x917>
    b70c:	45 89 ed             	mov    %r13d,%r13d
    b70f:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b713:	66 90                	xchg   %ax,%ax
    b715:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b71c:	00 00 00 00 
    b720:	49 8b 14 24          	mov    (%r12),%rdx
    b724:	89 c8                	mov    %ecx,%eax
    b726:	49 83 c4 08          	add    $0x8,%r12
    b72a:	83 c1 01             	add    $0x1,%ecx
    b72d:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b732:	4c 39 e6             	cmp    %r12,%rsi
    b735:	75 e9                	jne    b720 <fwp_hof0.constprop.0+0x900>
    b737:	48 8d 15 02 11 06 00 	lea    0x61102(%rip),%rdx        # 6c840 <fwp_heap>
    b73e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b742:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b749:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b750:	48 89 f2             	mov    %rsi,%rdx
    b753:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
    b757:	48 c1 e2 10          	shl    $0x10,%rdx
    b75b:	48 39 d0             	cmp    %rdx,%rax
    b75e:	73 54                	jae    b7b4 <fwp_hof0.constprop.0+0x994>
    b760:	48 89 c2             	mov    %rax,%rdx
    b763:	48 c1 ea 10          	shr    $0x10,%rdx
    b767:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b76b:	48 8b 15 c6 24 06 00 	mov    0x624c6(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    b772:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b776:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b77a:	48 85 c9             	test   %rcx,%rcx
    b77d:	74 35                	je     b7b4 <fwp_hof0.constprop.0+0x994>
    b77f:	0f b6 32             	movzbl (%rdx),%esi
    b782:	40 80 fe 02          	cmp    $0x2,%sil
    b786:	0f 84 37 02 00 00    	je     b9c3 <fwp_hof0.constprop.0+0xba3>
    b78c:	40 80 fe 01          	cmp    $0x1,%sil
    b790:	75 22                	jne    b7b4 <fwp_hof0.constprop.0+0x994>
    b792:	8b 72 18             	mov    0x18(%rdx),%esi
    b795:	0f b7 c0             	movzwl %ax,%eax
    b798:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b79b:	48 0f af c6          	imul   %rsi,%rax
    b79f:	48 c1 e8 20          	shr    $0x20,%rax
    b7a3:	48 39 d0             	cmp    %rdx,%rax
    b7a6:	73 0c                	jae    b7b4 <fwp_hof0.constprop.0+0x994>
    b7a8:	48 01 c1             	add    %rax,%rcx
    b7ab:	80 39 01             	cmpb   $0x1,(%rcx)
    b7ae:	0f 84 9c 01 00 00    	je     b950 <fwp_hof0.constprop.0+0xb30>
    b7b4:	49 8b 40 18          	mov    0x18(%r8),%rax
    b7b8:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b7bc:	be 01 00 00 00       	mov    $0x1,%esi
    b7c1:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b7c5:	ff 50 08             	call   *0x8(%rax)
    b7c8:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b7cc:	48 8d 35 6d 10 06 00 	lea    0x6106d(%rip),%rsi        # 6c840 <fwp_heap>
    b7d3:	4c 89 d0             	mov    %r10,%rax
    b7d6:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b7dd:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b7e4:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b7e8:	48 c1 e2 10          	shl    $0x10,%rdx
    b7ec:	48 39 d0             	cmp    %rdx,%rax
    b7ef:	73 59                	jae    b84a <fwp_hof0.constprop.0+0xa2a>
    b7f1:	48 89 c2             	mov    %rax,%rdx
    b7f4:	48 c1 ea 10          	shr    $0x10,%rdx
    b7f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7fc:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b803:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b807:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b80b:	4d 85 e4             	test   %r12,%r12
    b80e:	74 3a                	je     b84a <fwp_hof0.constprop.0+0xa2a>
    b810:	0f b6 0a             	movzbl (%rdx),%ecx
    b813:	80 f9 02             	cmp    $0x2,%cl
    b816:	0f 84 b5 01 00 00    	je     b9d1 <fwp_hof0.constprop.0+0xbb1>
    b81c:	80 f9 01             	cmp    $0x1,%cl
    b81f:	75 29                	jne    b84a <fwp_hof0.constprop.0+0xa2a>
    b821:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b824:	0f b7 c0             	movzwl %ax,%eax
    b827:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b82a:	48 0f af c1          	imul   %rcx,%rax
    b82e:	48 c1 e8 20          	shr    $0x20,%rax
    b832:	48 39 d0             	cmp    %rdx,%rax
    b835:	73 13                	jae    b84a <fwp_hof0.constprop.0+0xa2a>
    b837:	49 01 c4             	add    %rax,%r12
    b83a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b83f:	0f 84 a0 01 00 00    	je     b9e5 <fwp_hof0.constprop.0+0xbc5>
    b845:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b84a:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b84e:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b852:	e8 99 b9 ff ff       	call   71f0 <fwp_closure_drop>
    b857:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b85b:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b85f:	e9 3f fa ff ff       	jmp    b2a3 <fwp_hof0.constprop.0+0x483>
    b864:	0f 1f 40 00          	nopl   0x0(%rax)
    b868:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b86c:	e9 32 fa ff ff       	jmp    b2a3 <fwp_hof0.constprop.0+0x483>
    b871:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b878:	41 8b 34 24          	mov    (%r12),%esi
    b87c:	8b 05 9a 87 00 00    	mov    0x879a(%rip),%eax        # 1401c <fc12+0x4>
    b882:	89 f7                	mov    %esi,%edi
    b884:	29 c7                	sub    %eax,%edi
    b886:	83 ff 01             	cmp    $0x1,%edi
    b889:	0f 85 bf f6 ff ff    	jne    af4e <fwp_hof0.constprop.0+0x12e>
    b88f:	48 89 e3             	mov    %rsp,%rbx
    b892:	85 c0                	test   %eax,%eax
    b894:	0f 84 e7 01 00 00    	je     ba81 <fwp_hof0.constprop.0+0xc61>
    b89a:	89 f1                	mov    %esi,%ecx
    b89c:	ba 08 00 00 00       	mov    $0x8,%edx
    b8a1:	48 c1 e1 03          	shl    $0x3,%rcx
    b8a5:	85 f6                	test   %esi,%esi
    b8a7:	48 89 e6             	mov    %rsp,%rsi
    b8aa:	48 0f 45 d1          	cmovne %rcx,%rdx
    b8ae:	49 89 d7             	mov    %rdx,%r15
    b8b1:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b8b5:	48 c1 ea 04          	shr    $0x4,%rdx
    b8b9:	48 c1 e2 04          	shl    $0x4,%rdx
    b8bd:	48 89 d7             	mov    %rdx,%rdi
    b8c0:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b8c7:	48 29 fe             	sub    %rdi,%rsi
    b8ca:	48 39 f4             	cmp    %rsi,%rsp
    b8cd:	74 15                	je     b8e4 <fwp_hof0.constprop.0+0xac4>
    b8cf:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b8d6:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b8dd:	00 00 
    b8df:	48 39 f4             	cmp    %rsi,%rsp
    b8e2:	75 eb                	jne    b8cf <fwp_hof0.constprop.0+0xaaf>
    b8e4:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b8ea:	48 29 d4             	sub    %rdx,%rsp
    b8ed:	48 85 d2             	test   %rdx,%rdx
    b8f0:	74 06                	je     b8f8 <fwp_hof0.constprop.0+0xad8>
    b8f2:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b8f8:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b8ff:	00 
    b900:	4c 89 f9             	mov    %r15,%rcx
    b903:	48 8d 35 16 87 00 00 	lea    0x8716(%rip),%rsi        # 14020 <fwp_epfd>
    b90a:	48 89 e7             	mov    %rsp,%rdi
    b90d:	4c 89 f2             	mov    %r14,%rdx
    b910:	e8 3b 7c ff ff       	call   3550 <__memcpy_chk@plt>
    b915:	4d 39 f7             	cmp    %r14,%r15
    b918:	4c 89 f9             	mov    %r15,%rcx
    b91b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b91f:	49 0f 42 ce          	cmovb  %r14,%rcx
    b923:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b92a:	ba 08 00 00 00       	mov    $0x8,%edx
    b92f:	4c 29 f1             	sub    %r14,%rcx
    b932:	e8 19 7c ff ff       	call   3550 <__memcpy_chk@plt>
    b937:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b93c:	48 89 e7             	mov    %rsp,%rdi
    b93f:	ff 10                	call   *(%rax)
    b941:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b945:	e9 44 01 00 00       	jmp    ba8e <fwp_hof0.constprop.0+0xc6e>
    b94a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b950:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b957:	00 
    b958:	e9 6f fe ff ff       	jmp    b7cc <fwp_hof0.constprop.0+0x9ac>
    b95d:	85 c0                	test   %eax,%eax
    b95f:	74 0d                	je     b96e <fwp_hof0.constprop.0+0xb4e>
    b961:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b968:	0f 86 20 fc ff ff    	jbe    b58e <fwp_hof0.constprop.0+0x76e>
    b96e:	31 f6                	xor    %esi,%esi
    b970:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b973:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b977:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b97b:	e8 90 a5 ff ff       	call   5f10 <fwp_heap_alloc>
    b980:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b984:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b988:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b98b:	49 89 c2             	mov    %rax,%r10
    b98e:	e9 26 fd ff ff       	jmp    b6b9 <fwp_hof0.constprop.0+0x899>
    b993:	66 85 c0             	test   %ax,%ax
    b996:	0f 85 4f f6 ff ff    	jne    afeb <fwp_hof0.constprop.0+0x1cb>
    b99c:	e9 24 f6 ff ff       	jmp    afc5 <fwp_hof0.constprop.0+0x1a5>
    b9a1:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b9a5:	4d 85 d2             	test   %r10,%r10
    b9a8:	74 6e                	je     ba18 <fwp_hof0.constprop.0+0xbf8>
    b9aa:	48 8b 5a 10          	mov    0x10(%rdx),%rbx
    b9ae:	4c 29 d3             	sub    %r10,%rbx
    b9b1:	48 39 c3             	cmp    %rax,%rbx
    b9b4:	72 62                	jb     ba18 <fwp_hof0.constprop.0+0xbf8>
    b9b6:	49 8d 1c 02          	lea    (%r10,%rax,1),%rbx
    b9ba:	48 89 5a 08          	mov    %rbx,0x8(%rdx)
    b9be:	e9 06 fc ff ff       	jmp    b5c9 <fwp_hof0.constprop.0+0x7a9>
    b9c3:	66 85 c0             	test   %ax,%ax
    b9c6:	0f 85 e8 fd ff ff    	jne    b7b4 <fwp_hof0.constprop.0+0x994>
    b9cc:	e9 da fd ff ff       	jmp    b7ab <fwp_hof0.constprop.0+0x98b>
    b9d1:	66 85 c0             	test   %ax,%ax
    b9d4:	0f 85 70 fe ff ff    	jne    b84a <fwp_hof0.constprop.0+0xa2a>
    b9da:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b9df:	0f 85 60 fe ff ff    	jne    b845 <fwp_hof0.constprop.0+0xa25>
    b9e5:	4c 89 e7             	mov    %r12,%rdi
    b9e8:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b9ec:	e8 df 9d ff ff       	call   57d0 <fwp_rc_forget_slot>
    b9f1:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b9f5:	e9 4b fe ff ff       	jmp    b845 <fwp_hof0.constprop.0+0xa25>
    b9fa:	48 89 c2             	mov    %rax,%rdx
    b9fd:	83 e0 01             	and    $0x1,%eax
    ba00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ba04:	48 d1 ea             	shr    $1,%rdx
    ba07:	48 09 c2             	or     %rax,%rdx
    ba0a:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    ba0f:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    ba13:	e9 87 fc ff ff       	jmp    b69f <fwp_hof0.constprop.0+0x87f>
    ba18:	31 f6                	xor    %esi,%esi
    ba1a:	89 8d 68 ff ff ff    	mov    %ecx,-0x98(%rbp)
    ba20:	44 89 5d 80          	mov    %r11d,-0x80(%rbp)
    ba24:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    ba28:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    ba2c:	e8 df a4 ff ff       	call   5f10 <fwp_heap_alloc>
    ba31:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    ba37:	44 8b 5d 80          	mov    -0x80(%rbp),%r11d
    ba3b:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    ba3f:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    ba43:	49 89 c2             	mov    %rax,%r10
    ba46:	e9 36 fc ff ff       	jmp    b681 <fwp_hof0.constprop.0+0x861>
    ba4b:	31 f6                	xor    %esi,%esi
    ba4d:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    ba50:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    ba54:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    ba58:	e8 b3 a4 ff ff       	call   5f10 <fwp_heap_alloc>
    ba5d:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    ba61:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    ba65:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    ba68:	49 89 c2             	mov    %rax,%r10
    ba6b:	e9 16 fc ff ff       	jmp    b686 <fwp_hof0.constprop.0+0x866>
    ba70:	e8 3b 9c ff ff       	call   56b0 <fwp_rc_wide_dup>
    ba75:	48 8b 15 1c 2a 06 00 	mov    0x62a1c(%rip),%rdx        # 6e498 <fwp_fns>
    ba7c:	e9 6a f5 ff ff       	jmp    afeb <fwp_hof0.constprop.0+0x1cb>
    ba81:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    ba88:	ff 11                	call   *(%rcx)
    ba8a:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ba8e:	48 89 dc             	mov    %rbx,%rsp
    ba91:	e9 a0 f8 ff ff       	jmp    b336 <fwp_hof0.constprop.0+0x516>
    ba96:	48 89 c7             	mov    %rax,%rdi
    ba99:	e8 12 b0 ff ff       	call   6ab0 <fwp_rc_share>
    ba9e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    baa2:	e8 09 b0 ff ff       	call   6ab0 <fwp_rc_share>
    baa7:	48 8d 05 6a 85 00 00 	lea    0x856a(%rip),%rax        # 14018 <fc12>
    baae:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    bab5:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    bab9:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    bac0:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    bac4:	e9 59 f8 ff ff       	jmp    b322 <fwp_hof0.constprop.0+0x502>
    bac9:	66 85 c0             	test   %ax,%ax
    bacc:	0f 85 26 f4 ff ff    	jne    aef8 <fwp_hof0.constprop.0+0xd8>
    bad2:	e9 ff f3 ff ff       	jmp    aed6 <fwp_hof0.constprop.0+0xb6>
    bad7:	48 83 05 11 2a 06 00 	addq   $0x1,0x62a11(%rip)        # 6e4f0 <iteration_retains>
    bade:	01 
    badf:	e9 07 f4 ff ff       	jmp    aeeb <fwp_hof0.constprop.0+0xcb>
    bae4:	48 89 df             	mov    %rbx,%rdi
    bae7:	e8 f4 b0 ff ff       	call   6be0 <fwp_rc_free_arr>
    baec:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    baf0:	4d 85 ff             	test   %r15,%r15
    baf3:	0f 85 68 f3 ff ff    	jne    ae61 <fwp_hof0.constprop.0+0x41>
    baf9:	e9 21 fa ff ff       	jmp    b51f <fwp_hof0.constprop.0+0x6ff>
    bafe:	66 85 c0             	test   %ax,%ax
    bb01:	0f 85 49 f9 ff ff    	jne    b450 <fwp_hof0.constprop.0+0x630>
    bb07:	e9 36 f9 ff ff       	jmp    b442 <fwp_hof0.constprop.0+0x622>
    bb0c:	66 85 c0             	test   %ax,%ax
    bb0f:	0f 85 fd f9 ff ff    	jne    b512 <fwp_hof0.constprop.0+0x6f2>
    bb15:	e9 d8 f9 ff ff       	jmp    b4f2 <fwp_hof0.constprop.0+0x6d2>
    bb1a:	4c 89 e0             	mov    %r12,%rax
    bb1d:	48 8d 35 1c 0d 06 00 	lea    0x60d1c(%rip),%rsi        # 6c840 <fwp_heap>
    bb24:	48 c1 e8 11          	shr    $0x11,%rax
    bb28:	4c 31 e0             	xor    %r12,%rax
    bb2b:	48 89 c2             	mov    %rax,%rdx
    bb2e:	48 c1 ea 09          	shr    $0x9,%rdx
    bb32:	48 31 d0             	xor    %rdx,%rax
    bb35:	0f b6 c0             	movzbl %al,%eax
    bb38:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    bb3f:	00 
    bb40:	48 85 d2             	test   %rdx,%rdx
    bb43:	75 24                	jne    bb69 <fwp_hof0.constprop.0+0xd49>
    bb45:	eb 59                	jmp    bba0 <fwp_hof0.constprop.0+0xd80>
    bb47:	0f 1f 00             	nopl   (%rax)
    bb4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bb51:	00 00 00 00 
    bb55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bb5c:	00 00 00 00 
    bb60:	48 8b 50 10          	mov    0x10(%rax),%rdx
    bb64:	48 85 d2             	test   %rdx,%rdx
    bb67:	74 37                	je     bba0 <fwp_hof0.constprop.0+0xd80>
    bb69:	48 89 d0             	mov    %rdx,%rax
    bb6c:	4c 3b 22             	cmp    (%rdx),%r12
    bb6f:	75 ef                	jne    bb60 <fwp_hof0.constprop.0+0xd40>
    bb71:	48 8b 42 08          	mov    0x8(%rdx),%rax
    bb75:	48 83 e8 01          	sub    $0x1,%rax
    bb79:	48 89 42 08          	mov    %rax,0x8(%rdx)
    bb7d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    bb83:	0f 85 89 f9 ff ff    	jne    b512 <fwp_hof0.constprop.0+0x6f2>
    bb89:	4c 89 e7             	mov    %r12,%rdi
    bb8c:	e8 3f 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bb91:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    bb96:	e9 77 f9 ff ff       	jmp    b512 <fwp_hof0.constprop.0+0x6f2>
    bb9b:	e8 90 82 ff ff       	call   3e30 <fwp_heap_oom>
    bba0:	48 8d 3d 39 4e 00 00 	lea    0x4e39(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    bba7:	e8 a4 88 ff ff       	call   4450 <fwp_trap>
    bbac:	48 8d 3d 0f 47 00 00 	lea    0x470f(%rip),%rdi        # 102c2 <_IO_stdin_used+0x2c2>
    bbb3:	e8 98 88 ff ff       	call   4450 <fwp_trap>
    bbb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bbbf:	00 
    bbc0:	e8 eb 9a ff ff       	call   56b0 <fwp_rc_wide_dup>
    bbc5:	e9 2e f3 ff ff       	jmp    aef8 <fwp_hof0.constprop.0+0xd8>
    bbca:	e8 81 78 ff ff       	call   3450 <__stack_chk_fail@plt>
    bbcf:	90                   	nop
    bbd0:	4c 89 f7             	mov    %r14,%rdi
    bbd3:	e8 f8 9b ff ff       	call   57d0 <fwp_rc_forget_slot>
    bbd8:	e9 6f f8 ff ff       	jmp    b44c <fwp_hof0.constprop.0+0x62c>
    bbdd:	0f 1f 00             	nopl   (%rax)

000000000000bbe0 <f0>:
    bbe0:	41 56                	push   %r14
    bbe2:	4c 8d 35 57 0c 06 00 	lea    0x60c57(%rip),%r14        # 6c840 <fwp_heap>
    bbe9:	41 55                	push   %r13
    bbeb:	41 54                	push   %r12
    bbed:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    bbf3:	55                   	push   %rbp
    bbf4:	53                   	push   %rbx
    bbf5:	31 db                	xor    %ebx,%ebx
    bbf7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    bbfe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    bc05:	00 00 
    bc07:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    bc0e:	00 
    bc0f:	31 c0                	xor    %eax,%eax
    bc11:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    bc18:	00 
    bc19:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    bc20:	00 00 
    bc22:	66 48 0f 6e c0       	movq   %rax,%xmm0
    bc27:	48 8d 05 62 b4 ff ff 	lea    -0x4b9e(%rip),%rax        # 7090 <fwp_drop1>
    bc2e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    bc33:	48 8b 05 9e 28 06 00 	mov    0x6289e(%rip),%rax        # 6e4d8 <fwp_cleanups>
    bc3a:	48 89 25 97 28 06 00 	mov    %rsp,0x62897(%rip)        # 6e4d8 <fwp_cleanups>
    bc41:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    bc45:	48 89 04 24          	mov    %rax,(%rsp)
    bc49:	48 8d 05 80 7f ff ff 	lea    -0x8080(%rip),%rax        # 3bd0 <fwp_range_release>
    bc50:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    bc55:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    bc5a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    bc5f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    bc64:	eb 47                	jmp    bcad <f0+0xcd>
    bc66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bc6d:	00 00 00 
    bc70:	80 f9 01             	cmp    $0x1,%cl
    bc73:	75 29                	jne    bc9e <f0+0xbe>
    bc75:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bc78:	0f b7 c0             	movzwl %ax,%eax
    bc7b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bc7e:	48 0f af c1          	imul   %rcx,%rax
    bc82:	48 c1 e8 20          	shr    $0x20,%rax
    bc86:	48 39 d0             	cmp    %rdx,%rax
    bc89:	73 13                	jae    bc9e <f0+0xbe>
    bc8b:	49 01 c5             	add    %rax,%r13
    bc8e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    bc93:	0f 84 c7 27 00 00    	je     e460 <f0+0x2880>
    bc99:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    bc9e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    bca3:	49 83 ec 01          	sub    $0x1,%r12
    bca7:	0f 82 83 00 00 00    	jb     bd30 <f0+0x150>
    bcad:	48 89 ee             	mov    %rbp,%rsi
    bcb0:	bf 01 00 00 00       	mov    $0x1,%edi
    bcb5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    bcbc:	00 
    bcbd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    bcc2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    bcc9:	00 
    bcca:	e8 f1 ab ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    bccf:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bcd6:	48 89 c3             	mov    %rax,%rbx
    bcd9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bce0:	48 c1 e2 10          	shl    $0x10,%rdx
    bce4:	48 39 d0             	cmp    %rdx,%rax
    bce7:	73 b5                	jae    bc9e <f0+0xbe>
    bce9:	48 89 c2             	mov    %rax,%rdx
    bcec:	48 c1 ea 10          	shr    $0x10,%rdx
    bcf0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bcf4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bcfb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bcff:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    bd03:	4d 85 ed             	test   %r13,%r13
    bd06:	74 96                	je     bc9e <f0+0xbe>
    bd08:	0f b6 0a             	movzbl (%rdx),%ecx
    bd0b:	80 f9 02             	cmp    $0x2,%cl
    bd0e:	0f 85 5c ff ff ff    	jne    bc70 <f0+0x90>
    bd14:	66 85 c0             	test   %ax,%ax
    bd17:	0f 84 71 ff ff ff    	je     bc8e <f0+0xae>
    bd1d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    bd22:	49 83 ec 01          	sub    $0x1,%r12
    bd26:	73 85                	jae    bcad <f0+0xcd>
    bd28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bd2f:	00 
    bd30:	48 8b 04 24          	mov    (%rsp),%rax
    bd34:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    bd39:	bf 01 00 00 00       	mov    $0x1,%edi
    bd3e:	66 0f 6f 05 8a 50 00 	movdqa 0x508a(%rip),%xmm0        # 10dd0 <msg.4+0xa0>
    bd45:	00 
    bd46:	48 89 05 8b 27 06 00 	mov    %rax,0x6278b(%rip)        # 6e4d8 <fwp_cleanups>
    bd4d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    bd52:	e8 69 ab ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    bd57:	48 8b 15 ba 1e 06 00 	mov    0x61eba(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bd5e:	49 89 c5             	mov    %rax,%r13
    bd61:	48 2b 05 88 1e 06 00 	sub    0x61e88(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bd68:	48 c1 e2 10          	shl    $0x10,%rdx
    bd6c:	48 39 d0             	cmp    %rdx,%rax
    bd6f:	73 59                	jae    bdca <f0+0x1ea>
    bd71:	48 89 c2             	mov    %rax,%rdx
    bd74:	48 c1 ea 10          	shr    $0x10,%rdx
    bd78:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd7c:	48 8b 15 b5 1e 06 00 	mov    0x61eb5(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    bd83:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd87:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bd8b:	4d 85 e4             	test   %r12,%r12
    bd8e:	74 3a                	je     bdca <f0+0x1ea>
    bd90:	0f b6 0a             	movzbl (%rdx),%ecx
    bd93:	80 f9 02             	cmp    $0x2,%cl
    bd96:	0f 84 74 27 00 00    	je     e510 <f0+0x2930>
    bd9c:	80 f9 01             	cmp    $0x1,%cl
    bd9f:	75 29                	jne    bdca <f0+0x1ea>
    bda1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bda4:	0f b7 c0             	movzwl %ax,%eax
    bda7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bdaa:	48 0f af c1          	imul   %rcx,%rax
    bdae:	48 c1 e8 20          	shr    $0x20,%rax
    bdb2:	48 39 d0             	cmp    %rdx,%rax
    bdb5:	73 13                	jae    bdca <f0+0x1ea>
    bdb7:	49 01 c4             	add    %rax,%r12
    bdba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bdbf:	0f 84 26 29 00 00    	je     e6eb <f0+0x2b0b>
    bdc5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bdca:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    bdcf:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    bdd9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bde0:	00 f0 3f 
    bde3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    bde8:	e8 d3 aa ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    bded:	48 8b 15 24 1e 06 00 	mov    0x61e24(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bdf4:	49 89 c5             	mov    %rax,%r13
    bdf7:	48 2b 05 f2 1d 06 00 	sub    0x61df2(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bdfe:	48 c1 e2 10          	shl    $0x10,%rdx
    be02:	48 39 d0             	cmp    %rdx,%rax
    be05:	73 59                	jae    be60 <f0+0x280>
    be07:	48 89 c2             	mov    %rax,%rdx
    be0a:	48 c1 ea 10          	shr    $0x10,%rdx
    be0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be12:	48 8b 15 1f 1e 06 00 	mov    0x61e1f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    be19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be1d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    be21:	4d 85 e4             	test   %r12,%r12
    be24:	74 3a                	je     be60 <f0+0x280>
    be26:	0f b6 0a             	movzbl (%rdx),%ecx
    be29:	80 f9 02             	cmp    $0x2,%cl
    be2c:	0f 84 ce 26 00 00    	je     e500 <f0+0x2920>
    be32:	80 f9 01             	cmp    $0x1,%cl
    be35:	75 29                	jne    be60 <f0+0x280>
    be37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be3a:	0f b7 c0             	movzwl %ax,%eax
    be3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be40:	48 0f af c1          	imul   %rcx,%rax
    be44:	48 c1 e8 20          	shr    $0x20,%rax
    be48:	48 39 d0             	cmp    %rdx,%rax
    be4b:	73 13                	jae    be60 <f0+0x280>
    be4d:	49 01 c4             	add    %rax,%r12
    be50:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    be55:	0f 84 9d 28 00 00    	je     e6f8 <f0+0x2b18>
    be5b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    be60:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    be65:	bf 01 00 00 00       	mov    $0x1,%edi
    be6a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    be6f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    be76:	33 f3 bf 
    be79:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    be7e:	e8 3d aa ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    be83:	48 8b 15 8e 1d 06 00 	mov    0x61d8e(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    be8a:	49 89 c5             	mov    %rax,%r13
    be8d:	48 2b 05 5c 1d 06 00 	sub    0x61d5c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    be94:	48 c1 e2 10          	shl    $0x10,%rdx
    be98:	48 39 d0             	cmp    %rdx,%rax
    be9b:	73 59                	jae    bef6 <f0+0x316>
    be9d:	48 89 c2             	mov    %rax,%rdx
    bea0:	48 c1 ea 10          	shr    $0x10,%rdx
    bea4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bea8:	48 8b 15 89 1d 06 00 	mov    0x61d89(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    beaf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    beb3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    beb7:	4d 85 e4             	test   %r12,%r12
    beba:	74 3a                	je     bef6 <f0+0x316>
    bebc:	0f b6 0a             	movzbl (%rdx),%ecx
    bebf:	80 f9 02             	cmp    $0x2,%cl
    bec2:	0f 84 28 26 00 00    	je     e4f0 <f0+0x2910>
    bec8:	80 f9 01             	cmp    $0x1,%cl
    becb:	75 29                	jne    bef6 <f0+0x316>
    becd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bed0:	0f b7 c0             	movzwl %ax,%eax
    bed3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bed6:	48 0f af c1          	imul   %rcx,%rax
    beda:	48 c1 e8 20          	shr    $0x20,%rax
    bede:	48 39 d0             	cmp    %rdx,%rax
    bee1:	73 13                	jae    bef6 <f0+0x316>
    bee3:	49 01 c4             	add    %rax,%r12
    bee6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    beeb:	0f 84 14 28 00 00    	je     e705 <f0+0x2b25>
    bef1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bef6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    befb:	bf 01 00 00 00       	mov    $0x1,%edi
    bf00:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    bf05:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bf0c:	00 f0 3f 
    bf0f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    bf14:	e8 a7 a9 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    bf19:	48 8b 15 f8 1c 06 00 	mov    0x61cf8(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bf20:	49 89 c5             	mov    %rax,%r13
    bf23:	48 2b 05 c6 1c 06 00 	sub    0x61cc6(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bf2a:	48 c1 e2 10          	shl    $0x10,%rdx
    bf2e:	48 39 d0             	cmp    %rdx,%rax
    bf31:	73 59                	jae    bf8c <f0+0x3ac>
    bf33:	48 89 c2             	mov    %rax,%rdx
    bf36:	48 c1 ea 10          	shr    $0x10,%rdx
    bf3a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf3e:	48 8b 15 f3 1c 06 00 	mov    0x61cf3(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    bf45:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf49:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf4d:	4d 85 e4             	test   %r12,%r12
    bf50:	74 3a                	je     bf8c <f0+0x3ac>
    bf52:	0f b6 0a             	movzbl (%rdx),%ecx
    bf55:	80 f9 02             	cmp    $0x2,%cl
    bf58:	0f 84 f2 25 00 00    	je     e550 <f0+0x2970>
    bf5e:	80 f9 01             	cmp    $0x1,%cl
    bf61:	75 29                	jne    bf8c <f0+0x3ac>
    bf63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf66:	0f b7 c0             	movzwl %ax,%eax
    bf69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf6c:	48 0f af c1          	imul   %rcx,%rax
    bf70:	48 c1 e8 20          	shr    $0x20,%rax
    bf74:	48 39 d0             	cmp    %rdx,%rax
    bf77:	73 13                	jae    bf8c <f0+0x3ac>
    bf79:	49 01 c4             	add    %rax,%r12
    bf7c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf81:	0f 84 8b 27 00 00    	je     e712 <f0+0x2b32>
    bf87:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf8c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bf93:	33 f3 bf 
    bf96:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    bf9d:	00 
    bf9e:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    bfaa:	00 
    bfab:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    bfb2:	00 
    bfb3:	e8 08 a9 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    bfb8:	48 8b 15 59 1c 06 00 	mov    0x61c59(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bfbf:	49 89 c5             	mov    %rax,%r13
    bfc2:	48 2b 05 27 1c 06 00 	sub    0x61c27(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bfc9:	48 c1 e2 10          	shl    $0x10,%rdx
    bfcd:	48 39 d0             	cmp    %rdx,%rax
    bfd0:	73 59                	jae    c02b <f0+0x44b>
    bfd2:	48 89 c2             	mov    %rax,%rdx
    bfd5:	48 c1 ea 10          	shr    $0x10,%rdx
    bfd9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bfdd:	48 8b 15 54 1c 06 00 	mov    0x61c54(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    bfe4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bfe8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bfec:	4d 85 e4             	test   %r12,%r12
    bfef:	74 3a                	je     c02b <f0+0x44b>
    bff1:	0f b6 0a             	movzbl (%rdx),%ecx
    bff4:	80 f9 02             	cmp    $0x2,%cl
    bff7:	0f 84 43 25 00 00    	je     e540 <f0+0x2960>
    bffd:	80 f9 01             	cmp    $0x1,%cl
    c000:	75 29                	jne    c02b <f0+0x44b>
    c002:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c005:	0f b7 c0             	movzwl %ax,%eax
    c008:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c00b:	48 0f af c1          	imul   %rcx,%rax
    c00f:	48 c1 e8 20          	shr    $0x20,%rax
    c013:	48 39 d0             	cmp    %rdx,%rax
    c016:	73 13                	jae    c02b <f0+0x44b>
    c018:	49 01 c4             	add    %rax,%r12
    c01b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c020:	0f 84 f9 26 00 00    	je     e71f <f0+0x2b3f>
    c026:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c02b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c032:	00 f0 3f 
    c035:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    c03c:	00 
    c03d:	bf 01 00 00 00       	mov    $0x1,%edi
    c042:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    c049:	00 
    c04a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    c051:	00 
    c052:	e8 69 a8 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c057:	48 8b 15 ba 1b 06 00 	mov    0x61bba(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c05e:	49 89 c5             	mov    %rax,%r13
    c061:	48 2b 05 88 1b 06 00 	sub    0x61b88(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c068:	48 c1 e2 10          	shl    $0x10,%rdx
    c06c:	48 39 d0             	cmp    %rdx,%rax
    c06f:	73 59                	jae    c0ca <f0+0x4ea>
    c071:	48 89 c2             	mov    %rax,%rdx
    c074:	48 c1 ea 10          	shr    $0x10,%rdx
    c078:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c07c:	48 8b 15 b5 1b 06 00 	mov    0x61bb5(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c083:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c087:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c08b:	4d 85 e4             	test   %r12,%r12
    c08e:	74 3a                	je     c0ca <f0+0x4ea>
    c090:	0f b6 0a             	movzbl (%rdx),%ecx
    c093:	80 f9 02             	cmp    $0x2,%cl
    c096:	0f 84 94 24 00 00    	je     e530 <f0+0x2950>
    c09c:	80 f9 01             	cmp    $0x1,%cl
    c09f:	75 29                	jne    c0ca <f0+0x4ea>
    c0a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0a4:	0f b7 c0             	movzwl %ax,%eax
    c0a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0aa:	48 0f af c1          	imul   %rcx,%rax
    c0ae:	48 c1 e8 20          	shr    $0x20,%rax
    c0b2:	48 39 d0             	cmp    %rdx,%rax
    c0b5:	73 13                	jae    c0ca <f0+0x4ea>
    c0b7:	49 01 c4             	add    %rax,%r12
    c0ba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c0bf:	0f 84 67 26 00 00    	je     e72c <f0+0x2b4c>
    c0c5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c0ca:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    c0d1:	33 f3 bf 
    c0d4:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    c0db:	00 
    c0dc:	bf 01 00 00 00       	mov    $0x1,%edi
    c0e1:	4c 89 ac 24 a8 00 00 	mov    %r13,0xa8(%rsp)
    c0e8:	00 
    c0e9:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    c0f0:	00 
    c0f1:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    c0f8:	00 f0 3f 
    c0fb:	e8 c0 a7 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c100:	48 89 c7             	mov    %rax,%rdi
    c103:	e8 28 aa ff ff       	call   6b30 <fwp_rc_fresh>
    c108:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    c10f:	00 
    c110:	bf 01 00 00 00       	mov    $0x1,%edi
    c115:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    c11c:	00 
    c11d:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    c124:	00 
    c125:	e8 96 a7 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c12a:	48 89 c7             	mov    %rax,%rdi
    c12d:	e8 fe a9 ff ff       	call   6b30 <fwp_rc_fresh>
    c132:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    c139:	00 
    c13a:	bf 01 00 00 00       	mov    $0x1,%edi
    c13f:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    c146:	00 
    c147:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    c14e:	00 
    c14f:	e8 6c a7 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c154:	48 89 c7             	mov    %rax,%rdi
    c157:	e8 d4 a9 ff ff       	call   6b30 <fwp_rc_fresh>
    c15c:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    c163:	00 
    c164:	bf 01 00 00 00       	mov    $0x1,%edi
    c169:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    c170:	00 
    c171:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    c178:	00 
    c179:	e8 42 a7 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c17e:	48 89 c7             	mov    %rax,%rdi
    c181:	e8 aa a9 ff ff       	call   6b30 <fwp_rc_fresh>
    c186:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    c18d:	00 
    c18e:	bf 01 00 00 00       	mov    $0x1,%edi
    c193:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    c19a:	00 
    c19b:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    c1a2:	00 
    c1a3:	e8 18 a7 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c1a8:	48 89 c7             	mov    %rax,%rdi
    c1ab:	e8 80 a9 ff ff       	call   6b30 <fwp_rc_fresh>
    c1b0:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    c1b7:	00 
    c1b8:	bf 01 00 00 00       	mov    $0x1,%edi
    c1bd:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    c1c4:	00 
    c1c5:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    c1cc:	00 
    c1cd:	e8 ee a6 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c1d2:	48 89 c7             	mov    %rax,%rdi
    c1d5:	e8 56 a9 ff ff       	call   6b30 <fwp_rc_fresh>
    c1da:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    c1e1:	00 
    c1e2:	bf 01 00 00 00       	mov    $0x1,%edi
    c1e7:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    c1ee:	00 
    c1ef:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    c1f6:	00 
    c1f7:	e8 c4 a6 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c1fc:	48 89 c7             	mov    %rax,%rdi
    c1ff:	e8 2c a9 ff ff       	call   6b30 <fwp_rc_fresh>
    c204:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    c20b:	00 
    c20c:	bf 01 00 00 00       	mov    $0x1,%edi
    c211:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    c218:	00 
    c219:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    c220:	00 
    c221:	e8 9a a6 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c226:	48 89 c7             	mov    %rax,%rdi
    c229:	e8 02 a9 ff ff       	call   6b30 <fwp_rc_fresh>
    c22e:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    c235:	00 
    c236:	bf 01 00 00 00       	mov    $0x1,%edi
    c23b:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    c242:	00 
    c243:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    c24a:	00 
    c24b:	e8 70 a6 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c250:	48 89 c7             	mov    %rax,%rdi
    c253:	e8 d8 a8 ff ff       	call   6b30 <fwp_rc_fresh>
    c258:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    c25f:	00 
    c260:	bf 01 00 00 00       	mov    $0x1,%edi
    c265:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    c26c:	00 
    c26d:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    c274:	00 
    c275:	e8 46 a6 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c27a:	48 89 c7             	mov    %rax,%rdi
    c27d:	e8 ae a8 ff ff       	call   6b30 <fwp_rc_fresh>
    c282:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    c289:	00 
    c28a:	bf 01 00 00 00       	mov    $0x1,%edi
    c28f:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    c296:	00 
    c297:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    c29e:	00 
    c29f:	e8 1c a6 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c2a4:	48 89 c7             	mov    %rax,%rdi
    c2a7:	e8 84 a8 ff ff       	call   6b30 <fwp_rc_fresh>
    c2ac:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    c2b3:	00 
    c2b4:	bf 01 00 00 00       	mov    $0x1,%edi
    c2b9:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    c2c0:	00 
    c2c1:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    c2c8:	00 
    c2c9:	e8 f2 a5 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c2ce:	48 89 c7             	mov    %rax,%rdi
    c2d1:	e8 5a a8 ff ff       	call   6b30 <fwp_rc_fresh>
    c2d6:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    c2dd:	00 
    c2de:	bf 01 00 00 00       	mov    $0x1,%edi
    c2e3:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    c2ea:	00 
    c2eb:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    c2f2:	00 
    c2f3:	e8 c8 a5 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c2f8:	48 89 c7             	mov    %rax,%rdi
    c2fb:	e8 30 a8 ff ff       	call   6b30 <fwp_rc_fresh>
    c300:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    c307:	00 
    c308:	bf 01 00 00 00       	mov    $0x1,%edi
    c30d:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    c314:	00 
    c315:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    c31c:	00 
    c31d:	e8 9e a5 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c322:	48 89 c7             	mov    %rax,%rdi
    c325:	e8 06 a8 ff ff       	call   6b30 <fwp_rc_fresh>
    c32a:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    c331:	00 
    c332:	bf 01 00 00 00       	mov    $0x1,%edi
    c337:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    c33e:	00 
    c33f:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    c346:	00 
    c347:	e8 74 a5 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c34c:	48 89 c7             	mov    %rax,%rdi
    c34f:	e8 dc a7 ff ff       	call   6b30 <fwp_rc_fresh>
    c354:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    c35b:	00 
    c35c:	bf 01 00 00 00       	mov    $0x1,%edi
    c361:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    c368:	00 
    c369:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    c370:	00 
    c371:	e8 4a a5 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c376:	48 89 c7             	mov    %rax,%rdi
    c379:	e8 b2 a7 ff ff       	call   6b30 <fwp_rc_fresh>
    c37e:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    c385:	00 
    c386:	bf 01 00 00 00       	mov    $0x1,%edi
    c38b:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    c392:	00 
    c393:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    c39a:	00 
    c39b:	e8 20 a5 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c3a0:	48 89 c7             	mov    %rax,%rdi
    c3a3:	e8 88 a7 ff ff       	call   6b30 <fwp_rc_fresh>
    c3a8:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    c3af:	00 
    c3b0:	bf 01 00 00 00       	mov    $0x1,%edi
    c3b5:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    c3bc:	00 
    c3bd:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    c3c4:	00 
    c3c5:	e8 f6 a4 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c3ca:	48 89 c7             	mov    %rax,%rdi
    c3cd:	e8 5e a7 ff ff       	call   6b30 <fwp_rc_fresh>
    c3d2:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    c3d9:	00 
    c3da:	bf 01 00 00 00       	mov    $0x1,%edi
    c3df:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    c3e6:	00 
    c3e7:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    c3ee:	00 
    c3ef:	e8 cc a4 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c3f4:	48 89 c7             	mov    %rax,%rdi
    c3f7:	e8 34 a7 ff ff       	call   6b30 <fwp_rc_fresh>
    c3fc:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    c403:	00 
    c404:	bf 01 00 00 00       	mov    $0x1,%edi
    c409:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    c410:	00 
    c411:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    c418:	00 
    c419:	e8 a2 a4 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c41e:	48 89 c7             	mov    %rax,%rdi
    c421:	e8 0a a7 ff ff       	call   6b30 <fwp_rc_fresh>
    c426:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    c42d:	00 
    c42e:	bf 01 00 00 00       	mov    $0x1,%edi
    c433:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    c43a:	00 
    c43b:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    c442:	00 
    c443:	e8 78 a4 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c448:	48 89 c7             	mov    %rax,%rdi
    c44b:	e8 e0 a6 ff ff       	call   6b30 <fwp_rc_fresh>
    c450:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    c457:	00 
    c458:	bf 01 00 00 00       	mov    $0x1,%edi
    c45d:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    c464:	00 
    c465:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    c46c:	00 
    c46d:	e8 4e a4 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c472:	48 89 c7             	mov    %rax,%rdi
    c475:	e8 b6 a6 ff ff       	call   6b30 <fwp_rc_fresh>
    c47a:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    c481:	00 
    c482:	bf 01 00 00 00       	mov    $0x1,%edi
    c487:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    c48e:	00 
    c48f:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    c496:	00 
    c497:	e8 24 a4 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c49c:	48 89 c7             	mov    %rax,%rdi
    c49f:	e8 8c a6 ff ff       	call   6b30 <fwp_rc_fresh>
    c4a4:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    c4ab:	00 
    c4ac:	bf 01 00 00 00       	mov    $0x1,%edi
    c4b1:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    c4b8:	00 
    c4b9:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    c4c0:	00 
    c4c1:	e8 fa a3 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c4c6:	48 89 c7             	mov    %rax,%rdi
    c4c9:	e8 62 a6 ff ff       	call   6b30 <fwp_rc_fresh>
    c4ce:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    c4d5:	00 
    c4d6:	bf 01 00 00 00       	mov    $0x1,%edi
    c4db:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    c4e2:	00 
    c4e3:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    c4ea:	00 
    c4eb:	e8 d0 a3 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c4f0:	48 89 c7             	mov    %rax,%rdi
    c4f3:	e8 38 a6 ff ff       	call   6b30 <fwp_rc_fresh>
    c4f8:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    c4ff:	00 
    c500:	bf 01 00 00 00       	mov    $0x1,%edi
    c505:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    c50c:	00 
    c50d:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    c514:	00 
    c515:	e8 a6 a3 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c51a:	48 89 c7             	mov    %rax,%rdi
    c51d:	e8 0e a6 ff ff       	call   6b30 <fwp_rc_fresh>
    c522:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    c529:	00 
    c52a:	bf 01 00 00 00       	mov    $0x1,%edi
    c52f:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    c536:	00 
    c537:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    c53e:	00 
    c53f:	e8 7c a3 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c544:	48 89 c7             	mov    %rax,%rdi
    c547:	e8 e4 a5 ff ff       	call   6b30 <fwp_rc_fresh>
    c54c:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    c553:	00 
    c554:	bf 01 00 00 00       	mov    $0x1,%edi
    c559:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    c560:	00 
    c561:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    c568:	00 
    c569:	e8 52 a3 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c56e:	48 89 c7             	mov    %rax,%rdi
    c571:	e8 ba a5 ff ff       	call   6b30 <fwp_rc_fresh>
    c576:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    c57d:	00 
    c57e:	bf 01 00 00 00       	mov    $0x1,%edi
    c583:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    c58a:	00 
    c58b:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    c592:	00 
    c593:	e8 28 a3 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c598:	48 89 c7             	mov    %rax,%rdi
    c59b:	e8 90 a5 ff ff       	call   6b30 <fwp_rc_fresh>
    c5a0:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    c5a7:	00 
    c5a8:	bf 01 00 00 00       	mov    $0x1,%edi
    c5ad:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    c5b4:	00 
    c5b5:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    c5bc:	00 
    c5bd:	e8 fe a2 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c5c2:	48 89 c7             	mov    %rax,%rdi
    c5c5:	e8 66 a5 ff ff       	call   6b30 <fwp_rc_fresh>
    c5ca:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    c5d1:	00 
    c5d2:	bf 01 00 00 00       	mov    $0x1,%edi
    c5d7:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    c5de:	00 
    c5df:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    c5e6:	00 
    c5e7:	e8 d4 a2 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c5ec:	48 89 c7             	mov    %rax,%rdi
    c5ef:	e8 3c a5 ff ff       	call   6b30 <fwp_rc_fresh>
    c5f4:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    c5fb:	00 
    c5fc:	bf 01 00 00 00       	mov    $0x1,%edi
    c601:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    c608:	00 
    c609:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    c610:	00 
    c611:	e8 aa a2 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c616:	48 89 c7             	mov    %rax,%rdi
    c619:	e8 12 a5 ff ff       	call   6b30 <fwp_rc_fresh>
    c61e:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    c625:	00 
    c626:	bf 01 00 00 00       	mov    $0x1,%edi
    c62b:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    c632:	00 
    c633:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    c63a:	00 
    c63b:	e8 80 a2 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c640:	48 89 c7             	mov    %rax,%rdi
    c643:	e8 e8 a4 ff ff       	call   6b30 <fwp_rc_fresh>
    c648:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    c64f:	00 
    c650:	bf 01 00 00 00       	mov    $0x1,%edi
    c655:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    c65c:	00 
    c65d:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    c664:	00 
    c665:	e8 56 a2 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c66a:	48 89 c7             	mov    %rax,%rdi
    c66d:	e8 be a4 ff ff       	call   6b30 <fwp_rc_fresh>
    c672:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    c679:	00 
    c67a:	bf 01 00 00 00       	mov    $0x1,%edi
    c67f:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    c686:	00 
    c687:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    c68e:	00 
    c68f:	e8 2c a2 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c694:	48 89 c7             	mov    %rax,%rdi
    c697:	e8 94 a4 ff ff       	call   6b30 <fwp_rc_fresh>
    c69c:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    c6a3:	00 
    c6a4:	bf 01 00 00 00       	mov    $0x1,%edi
    c6a9:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    c6b0:	00 
    c6b1:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    c6b8:	00 
    c6b9:	e8 02 a2 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c6be:	48 89 c7             	mov    %rax,%rdi
    c6c1:	e8 6a a4 ff ff       	call   6b30 <fwp_rc_fresh>
    c6c6:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    c6cd:	00 
    c6ce:	bf 01 00 00 00       	mov    $0x1,%edi
    c6d3:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    c6da:	00 
    c6db:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    c6e2:	00 
    c6e3:	e8 d8 a1 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c6e8:	48 89 c7             	mov    %rax,%rdi
    c6eb:	e8 40 a4 ff ff       	call   6b30 <fwp_rc_fresh>
    c6f0:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    c6f7:	00 
    c6f8:	bf 01 00 00 00       	mov    $0x1,%edi
    c6fd:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    c704:	00 
    c705:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    c70c:	00 
    c70d:	e8 ae a1 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c712:	48 89 c7             	mov    %rax,%rdi
    c715:	e8 16 a4 ff ff       	call   6b30 <fwp_rc_fresh>
    c71a:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c721:	00 
    c722:	bf 01 00 00 00       	mov    $0x1,%edi
    c727:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    c72e:	00 
    c72f:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c736:	00 
    c737:	e8 84 a1 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c73c:	48 89 c7             	mov    %rax,%rdi
    c73f:	e8 ec a3 ff ff       	call   6b30 <fwp_rc_fresh>
    c744:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c74b:	00 
    c74c:	bf 01 00 00 00       	mov    $0x1,%edi
    c751:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    c758:	00 
    c759:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c760:	00 
    c761:	e8 5a a1 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c766:	48 89 c7             	mov    %rax,%rdi
    c769:	e8 c2 a3 ff ff       	call   6b30 <fwp_rc_fresh>
    c76e:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c775:	00 
    c776:	bf 01 00 00 00       	mov    $0x1,%edi
    c77b:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    c782:	00 
    c783:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c78a:	00 
    c78b:	e8 30 a1 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c790:	48 89 c7             	mov    %rax,%rdi
    c793:	e8 98 a3 ff ff       	call   6b30 <fwp_rc_fresh>
    c798:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c79f:	00 
    c7a0:	bf 01 00 00 00       	mov    $0x1,%edi
    c7a5:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    c7ac:	00 
    c7ad:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c7b4:	00 
    c7b5:	e8 06 a1 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c7ba:	48 89 c7             	mov    %rax,%rdi
    c7bd:	e8 6e a3 ff ff       	call   6b30 <fwp_rc_fresh>
    c7c2:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c7c9:	00 
    c7ca:	bf 01 00 00 00       	mov    $0x1,%edi
    c7cf:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    c7d6:	00 
    c7d7:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c7de:	00 
    c7df:	e8 dc a0 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c7e4:	48 89 c7             	mov    %rax,%rdi
    c7e7:	e8 44 a3 ff ff       	call   6b30 <fwp_rc_fresh>
    c7ec:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c7f3:	00 
    c7f4:	bf 01 00 00 00       	mov    $0x1,%edi
    c7f9:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    c800:	00 
    c801:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c808:	00 
    c809:	e8 b2 a0 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c80e:	48 89 c7             	mov    %rax,%rdi
    c811:	e8 1a a3 ff ff       	call   6b30 <fwp_rc_fresh>
    c816:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c81d:	00 
    c81e:	bf 01 00 00 00       	mov    $0x1,%edi
    c823:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    c82a:	00 
    c82b:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c832:	00 
    c833:	e8 88 a0 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c838:	48 89 c7             	mov    %rax,%rdi
    c83b:	e8 f0 a2 ff ff       	call   6b30 <fwp_rc_fresh>
    c840:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c847:	00 
    c848:	bf 01 00 00 00       	mov    $0x1,%edi
    c84d:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    c854:	00 
    c855:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c85c:	00 
    c85d:	e8 5e a0 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c862:	48 89 c7             	mov    %rax,%rdi
    c865:	e8 c6 a2 ff ff       	call   6b30 <fwp_rc_fresh>
    c86a:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c871:	00 
    c872:	bf 01 00 00 00       	mov    $0x1,%edi
    c877:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    c87e:	00 
    c87f:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c886:	00 
    c887:	e8 34 a0 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c88c:	48 89 c7             	mov    %rax,%rdi
    c88f:	e8 9c a2 ff ff       	call   6b30 <fwp_rc_fresh>
    c894:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c89b:	00 
    c89c:	bf 01 00 00 00       	mov    $0x1,%edi
    c8a1:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    c8a8:	00 
    c8a9:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c8b0:	00 
    c8b1:	e8 0a a0 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c8b6:	48 89 c7             	mov    %rax,%rdi
    c8b9:	e8 72 a2 ff ff       	call   6b30 <fwp_rc_fresh>
    c8be:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c8c5:	00 
    c8c6:	bf 01 00 00 00       	mov    $0x1,%edi
    c8cb:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    c8d2:	00 
    c8d3:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c8da:	00 
    c8db:	e8 e0 9f ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c8e0:	48 89 c7             	mov    %rax,%rdi
    c8e3:	e8 48 a2 ff ff       	call   6b30 <fwp_rc_fresh>
    c8e8:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c8ef:	00 
    c8f0:	bf 01 00 00 00       	mov    $0x1,%edi
    c8f5:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    c8fc:	00 
    c8fd:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c904:	00 
    c905:	e8 b6 9f ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c90a:	48 89 c7             	mov    %rax,%rdi
    c90d:	e8 1e a2 ff ff       	call   6b30 <fwp_rc_fresh>
    c912:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c919:	00 
    c91a:	bf 01 00 00 00       	mov    $0x1,%edi
    c91f:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    c926:	00 
    c927:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c92e:	00 
    c92f:	e8 8c 9f ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c934:	48 89 c7             	mov    %rax,%rdi
    c937:	e8 f4 a1 ff ff       	call   6b30 <fwp_rc_fresh>
    c93c:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c943:	00 
    c944:	bf 01 00 00 00       	mov    $0x1,%edi
    c949:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    c950:	00 
    c951:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c958:	00 
    c959:	e8 62 9f ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c95e:	48 89 c7             	mov    %rax,%rdi
    c961:	e8 ca a1 ff ff       	call   6b30 <fwp_rc_fresh>
    c966:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c96d:	00 
    c96e:	bf 01 00 00 00       	mov    $0x1,%edi
    c973:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    c97a:	00 
    c97b:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c982:	00 
    c983:	e8 38 9f ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c988:	48 89 c7             	mov    %rax,%rdi
    c98b:	e8 a0 a1 ff ff       	call   6b30 <fwp_rc_fresh>
    c990:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c997:	00 
    c998:	bf 01 00 00 00       	mov    $0x1,%edi
    c99d:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    c9a4:	00 
    c9a5:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c9ac:	00 
    c9ad:	e8 0e 9f ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c9b2:	48 89 c7             	mov    %rax,%rdi
    c9b5:	e8 76 a1 ff ff       	call   6b30 <fwp_rc_fresh>
    c9ba:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c9c1:	00 
    c9c2:	bf 01 00 00 00       	mov    $0x1,%edi
    c9c7:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    c9ce:	00 
    c9cf:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c9d6:	00 
    c9d7:	e8 e4 9e ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    c9dc:	48 89 c7             	mov    %rax,%rdi
    c9df:	e8 4c a1 ff ff       	call   6b30 <fwp_rc_fresh>
    c9e4:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c9eb:	00 
    c9ec:	bf 01 00 00 00       	mov    $0x1,%edi
    c9f1:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    c9f8:	00 
    c9f9:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    ca00:	00 
    ca01:	e8 ba 9e ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ca06:	48 89 c7             	mov    %rax,%rdi
    ca09:	e8 22 a1 ff ff       	call   6b30 <fwp_rc_fresh>
    ca0e:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    ca15:	00 
    ca16:	bf 01 00 00 00       	mov    $0x1,%edi
    ca1b:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    ca22:	00 
    ca23:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    ca2a:	00 
    ca2b:	e8 90 9e ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ca30:	48 89 c7             	mov    %rax,%rdi
    ca33:	e8 f8 a0 ff ff       	call   6b30 <fwp_rc_fresh>
    ca38:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    ca3f:	00 
    ca40:	bf 01 00 00 00       	mov    $0x1,%edi
    ca45:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    ca4c:	00 
    ca4d:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    ca54:	00 
    ca55:	e8 66 9e ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ca5a:	48 89 c7             	mov    %rax,%rdi
    ca5d:	e8 ce a0 ff ff       	call   6b30 <fwp_rc_fresh>
    ca62:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    ca69:	00 
    ca6a:	bf 01 00 00 00       	mov    $0x1,%edi
    ca6f:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    ca76:	00 
    ca77:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    ca7e:	00 
    ca7f:	e8 3c 9e ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ca84:	48 89 c7             	mov    %rax,%rdi
    ca87:	e8 a4 a0 ff ff       	call   6b30 <fwp_rc_fresh>
    ca8c:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    ca93:	00 
    ca94:	bf 01 00 00 00       	mov    $0x1,%edi
    ca99:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    caa0:	00 
    caa1:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    caa8:	00 
    caa9:	e8 12 9e ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    caae:	48 89 c7             	mov    %rax,%rdi
    cab1:	e8 7a a0 ff ff       	call   6b30 <fwp_rc_fresh>
    cab6:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    cabd:	00 
    cabe:	bf 01 00 00 00       	mov    $0x1,%edi
    cac3:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    caca:	00 
    cacb:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    cad2:	00 
    cad3:	e8 e8 9d ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cad8:	48 89 c7             	mov    %rax,%rdi
    cadb:	e8 50 a0 ff ff       	call   6b30 <fwp_rc_fresh>
    cae0:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    cae7:	00 
    cae8:	bf 01 00 00 00       	mov    $0x1,%edi
    caed:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    caf4:	00 
    caf5:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    cafc:	00 
    cafd:	e8 be 9d ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cb02:	48 89 c7             	mov    %rax,%rdi
    cb05:	e8 26 a0 ff ff       	call   6b30 <fwp_rc_fresh>
    cb0a:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    cb11:	00 
    cb12:	bf 01 00 00 00       	mov    $0x1,%edi
    cb17:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    cb1e:	00 
    cb1f:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    cb26:	00 
    cb27:	e8 94 9d ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cb2c:	48 89 c7             	mov    %rax,%rdi
    cb2f:	e8 fc 9f ff ff       	call   6b30 <fwp_rc_fresh>
    cb34:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    cb3b:	00 
    cb3c:	bf 01 00 00 00       	mov    $0x1,%edi
    cb41:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    cb48:	00 
    cb49:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    cb50:	00 
    cb51:	e8 6a 9d ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cb56:	48 89 c7             	mov    %rax,%rdi
    cb59:	e8 d2 9f ff ff       	call   6b30 <fwp_rc_fresh>
    cb5e:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    cb65:	00 
    cb66:	bf 01 00 00 00       	mov    $0x1,%edi
    cb6b:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    cb72:	00 
    cb73:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    cb7a:	00 
    cb7b:	e8 40 9d ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cb80:	48 89 c7             	mov    %rax,%rdi
    cb83:	e8 a8 9f ff ff       	call   6b30 <fwp_rc_fresh>
    cb88:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    cb8f:	00 
    cb90:	bf 01 00 00 00       	mov    $0x1,%edi
    cb95:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    cb9c:	00 
    cb9d:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    cba4:	00 
    cba5:	e8 16 9d ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cbaa:	48 89 c7             	mov    %rax,%rdi
    cbad:	e8 7e 9f ff ff       	call   6b30 <fwp_rc_fresh>
    cbb2:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    cbb9:	00 
    cbba:	bf 01 00 00 00       	mov    $0x1,%edi
    cbbf:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    cbc6:	00 
    cbc7:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    cbce:	00 
    cbcf:	e8 ec 9c ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cbd4:	48 89 c7             	mov    %rax,%rdi
    cbd7:	e8 54 9f ff ff       	call   6b30 <fwp_rc_fresh>
    cbdc:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    cbe3:	00 
    cbe4:	bf 01 00 00 00       	mov    $0x1,%edi
    cbe9:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    cbf0:	00 
    cbf1:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    cbf8:	00 
    cbf9:	e8 c2 9c ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cbfe:	48 89 c7             	mov    %rax,%rdi
    cc01:	e8 2a 9f ff ff       	call   6b30 <fwp_rc_fresh>
    cc06:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    cc0d:	00 
    cc0e:	bf 01 00 00 00       	mov    $0x1,%edi
    cc13:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    cc1a:	00 
    cc1b:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    cc22:	00 
    cc23:	e8 98 9c ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cc28:	48 89 c7             	mov    %rax,%rdi
    cc2b:	e8 00 9f ff ff       	call   6b30 <fwp_rc_fresh>
    cc30:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    cc37:	00 
    cc38:	bf 01 00 00 00       	mov    $0x1,%edi
    cc3d:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    cc44:	00 
    cc45:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    cc4c:	00 
    cc4d:	e8 6e 9c ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cc52:	48 89 c7             	mov    %rax,%rdi
    cc55:	e8 d6 9e ff ff       	call   6b30 <fwp_rc_fresh>
    cc5a:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    cc61:	00 
    cc62:	bf 01 00 00 00       	mov    $0x1,%edi
    cc67:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    cc6e:	00 
    cc6f:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    cc76:	00 
    cc77:	e8 44 9c ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cc7c:	48 89 c7             	mov    %rax,%rdi
    cc7f:	e8 ac 9e ff ff       	call   6b30 <fwp_rc_fresh>
    cc84:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    cc8b:	00 
    cc8c:	bf 01 00 00 00       	mov    $0x1,%edi
    cc91:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    cc98:	00 
    cc99:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    cca0:	00 
    cca1:	e8 1a 9c ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cca6:	48 89 c7             	mov    %rax,%rdi
    cca9:	e8 82 9e ff ff       	call   6b30 <fwp_rc_fresh>
    ccae:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    ccb5:	00 
    ccb6:	bf 01 00 00 00       	mov    $0x1,%edi
    ccbb:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    ccc2:	00 
    ccc3:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    ccca:	00 
    cccb:	e8 f0 9b ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ccd0:	48 89 c7             	mov    %rax,%rdi
    ccd3:	e8 58 9e ff ff       	call   6b30 <fwp_rc_fresh>
    ccd8:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    ccdf:	00 
    cce0:	bf 01 00 00 00       	mov    $0x1,%edi
    cce5:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    ccec:	00 
    cced:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    ccf4:	00 
    ccf5:	e8 c6 9b ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ccfa:	48 89 c7             	mov    %rax,%rdi
    ccfd:	e8 2e 9e ff ff       	call   6b30 <fwp_rc_fresh>
    cd02:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    cd09:	00 
    cd0a:	bf 01 00 00 00       	mov    $0x1,%edi
    cd0f:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    cd16:	00 
    cd17:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    cd1e:	00 
    cd1f:	e8 9c 9b ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cd24:	48 89 c7             	mov    %rax,%rdi
    cd27:	e8 04 9e ff ff       	call   6b30 <fwp_rc_fresh>
    cd2c:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    cd33:	00 
    cd34:	bf 01 00 00 00       	mov    $0x1,%edi
    cd39:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    cd40:	00 
    cd41:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    cd48:	00 
    cd49:	e8 72 9b ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cd4e:	48 89 c7             	mov    %rax,%rdi
    cd51:	e8 da 9d ff ff       	call   6b30 <fwp_rc_fresh>
    cd56:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    cd5d:	00 
    cd5e:	bf 01 00 00 00       	mov    $0x1,%edi
    cd63:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    cd6a:	00 
    cd6b:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    cd72:	00 
    cd73:	e8 48 9b ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cd78:	48 89 c7             	mov    %rax,%rdi
    cd7b:	e8 b0 9d ff ff       	call   6b30 <fwp_rc_fresh>
    cd80:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    cd87:	00 
    cd88:	bf 01 00 00 00       	mov    $0x1,%edi
    cd8d:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    cd94:	00 
    cd95:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    cd9c:	00 
    cd9d:	e8 1e 9b ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cda2:	48 89 c7             	mov    %rax,%rdi
    cda5:	e8 86 9d ff ff       	call   6b30 <fwp_rc_fresh>
    cdaa:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    cdb1:	00 
    cdb2:	bf 01 00 00 00       	mov    $0x1,%edi
    cdb7:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    cdbe:	00 
    cdbf:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    cdc6:	00 
    cdc7:	e8 f4 9a ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cdcc:	48 89 c7             	mov    %rax,%rdi
    cdcf:	e8 5c 9d ff ff       	call   6b30 <fwp_rc_fresh>
    cdd4:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    cddb:	00 
    cddc:	bf 01 00 00 00       	mov    $0x1,%edi
    cde1:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    cde8:	00 
    cde9:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    cdf0:	00 
    cdf1:	e8 ca 9a ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cdf6:	48 89 c7             	mov    %rax,%rdi
    cdf9:	e8 32 9d ff ff       	call   6b30 <fwp_rc_fresh>
    cdfe:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    ce05:	00 
    ce06:	bf 01 00 00 00       	mov    $0x1,%edi
    ce0b:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    ce12:	00 
    ce13:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    ce1a:	00 
    ce1b:	e8 a0 9a ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ce20:	48 89 c7             	mov    %rax,%rdi
    ce23:	e8 08 9d ff ff       	call   6b30 <fwp_rc_fresh>
    ce28:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    ce2f:	00 
    ce30:	bf 01 00 00 00       	mov    $0x1,%edi
    ce35:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    ce3c:	00 
    ce3d:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    ce44:	00 
    ce45:	e8 76 9a ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ce4a:	48 89 c7             	mov    %rax,%rdi
    ce4d:	e8 de 9c ff ff       	call   6b30 <fwp_rc_fresh>
    ce52:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    ce59:	00 
    ce5a:	bf 01 00 00 00       	mov    $0x1,%edi
    ce5f:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    ce66:	00 
    ce67:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    ce6e:	00 
    ce6f:	e8 4c 9a ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ce74:	48 89 c7             	mov    %rax,%rdi
    ce77:	e8 b4 9c ff ff       	call   6b30 <fwp_rc_fresh>
    ce7c:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    ce83:	00 
    ce84:	bf 01 00 00 00       	mov    $0x1,%edi
    ce89:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    ce90:	00 
    ce91:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    ce98:	00 
    ce99:	e8 22 9a ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    ce9e:	48 89 c7             	mov    %rax,%rdi
    cea1:	e8 8a 9c ff ff       	call   6b30 <fwp_rc_fresh>
    cea6:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    cead:	00 
    ceae:	bf 01 00 00 00       	mov    $0x1,%edi
    ceb3:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    ceba:	00 
    cebb:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    cec2:	00 
    cec3:	e8 f8 99 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cec8:	48 89 c7             	mov    %rax,%rdi
    cecb:	e8 60 9c ff ff       	call   6b30 <fwp_rc_fresh>
    ced0:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    ced7:	00 
    ced8:	bf 01 00 00 00       	mov    $0x1,%edi
    cedd:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    cee4:	00 
    cee5:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    ceec:	00 
    ceed:	e8 ce 99 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cef2:	48 89 c7             	mov    %rax,%rdi
    cef5:	e8 36 9c ff ff       	call   6b30 <fwp_rc_fresh>
    cefa:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    cf01:	00 
    cf02:	bf 01 00 00 00       	mov    $0x1,%edi
    cf07:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    cf0e:	00 
    cf0f:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    cf16:	00 
    cf17:	e8 a4 99 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cf1c:	48 89 c7             	mov    %rax,%rdi
    cf1f:	e8 0c 9c ff ff       	call   6b30 <fwp_rc_fresh>
    cf24:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    cf2b:	00 
    cf2c:	bf 01 00 00 00       	mov    $0x1,%edi
    cf31:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    cf38:	00 
    cf39:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    cf40:	00 
    cf41:	e8 7a 99 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cf46:	48 89 c7             	mov    %rax,%rdi
    cf49:	e8 e2 9b ff ff       	call   6b30 <fwp_rc_fresh>
    cf4e:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    cf55:	00 
    cf56:	bf 01 00 00 00       	mov    $0x1,%edi
    cf5b:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    cf62:	00 
    cf63:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    cf6a:	00 
    cf6b:	e8 50 99 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cf70:	48 89 c7             	mov    %rax,%rdi
    cf73:	e8 b8 9b ff ff       	call   6b30 <fwp_rc_fresh>
    cf78:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    cf7f:	00 
    cf80:	bf 01 00 00 00       	mov    $0x1,%edi
    cf85:	4c 89 ac 24 30 06 00 	mov    %r13,0x630(%rsp)
    cf8c:	00 
    cf8d:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    cf94:	00 
    cf95:	e8 26 99 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cf9a:	48 89 c7             	mov    %rax,%rdi
    cf9d:	e8 8e 9b ff ff       	call   6b30 <fwp_rc_fresh>
    cfa2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    cfa9:	00 
    cfaa:	bf 01 00 00 00       	mov    $0x1,%edi
    cfaf:	4c 89 a4 24 40 06 00 	mov    %r12,0x640(%rsp)
    cfb6:	00 
    cfb7:	48 89 84 24 48 06 00 	mov    %rax,0x648(%rsp)
    cfbe:	00 
    cfbf:	e8 fc 98 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    cfc4:	48 8b 15 4d 0c 06 00 	mov    0x60c4d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    cfcb:	49 89 c5             	mov    %rax,%r13
    cfce:	48 2b 05 1b 0c 06 00 	sub    0x60c1b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    cfd5:	48 c1 e2 10          	shl    $0x10,%rdx
    cfd9:	48 39 d0             	cmp    %rdx,%rax
    cfdc:	73 59                	jae    d037 <f0+0x1457>
    cfde:	48 89 c2             	mov    %rax,%rdx
    cfe1:	48 c1 ea 10          	shr    $0x10,%rdx
    cfe5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfe9:	48 8b 15 48 0c 06 00 	mov    0x60c48(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    cff0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cff4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cff8:	4d 85 e4             	test   %r12,%r12
    cffb:	74 3a                	je     d037 <f0+0x1457>
    cffd:	0f b6 0a             	movzbl (%rdx),%ecx
    d000:	80 f9 02             	cmp    $0x2,%cl
    d003:	0f 84 17 15 00 00    	je     e520 <f0+0x2940>
    d009:	80 f9 01             	cmp    $0x1,%cl
    d00c:	75 29                	jne    d037 <f0+0x1457>
    d00e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d011:	0f b7 c0             	movzwl %ax,%eax
    d014:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d017:	48 0f af c1          	imul   %rcx,%rax
    d01b:	48 c1 e8 20          	shr    $0x20,%rax
    d01f:	48 39 d0             	cmp    %rdx,%rax
    d022:	73 13                	jae    d037 <f0+0x1457>
    d024:	49 01 c4             	add    %rax,%r12
    d027:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d02c:	0f 84 07 17 00 00    	je     e739 <f0+0x2b59>
    d032:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d037:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d03e:	00 f0 3f 
    d041:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    d048:	00 
    d049:	bf 01 00 00 00       	mov    $0x1,%edi
    d04e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    d055:	00 
    d056:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    d05d:	00 
    d05e:	e8 5d 98 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d063:	48 8b 15 ae 0b 06 00 	mov    0x60bae(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d06a:	49 89 c5             	mov    %rax,%r13
    d06d:	48 2b 05 7c 0b 06 00 	sub    0x60b7c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d074:	48 c1 e2 10          	shl    $0x10,%rdx
    d078:	48 39 d0             	cmp    %rdx,%rax
    d07b:	73 59                	jae    d0d6 <f0+0x14f6>
    d07d:	48 89 c2             	mov    %rax,%rdx
    d080:	48 c1 ea 10          	shr    $0x10,%rdx
    d084:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d088:	48 8b 15 a9 0b 06 00 	mov    0x60ba9(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d08f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d093:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d097:	4d 85 e4             	test   %r12,%r12
    d09a:	74 3a                	je     d0d6 <f0+0x14f6>
    d09c:	0f b6 0a             	movzbl (%rdx),%ecx
    d09f:	80 f9 02             	cmp    $0x2,%cl
    d0a2:	0f 84 28 15 00 00    	je     e5d0 <f0+0x29f0>
    d0a8:	80 f9 01             	cmp    $0x1,%cl
    d0ab:	75 29                	jne    d0d6 <f0+0x14f6>
    d0ad:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0b0:	0f b7 c0             	movzwl %ax,%eax
    d0b3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0b6:	48 0f af c1          	imul   %rcx,%rax
    d0ba:	48 c1 e8 20          	shr    $0x20,%rax
    d0be:	48 39 d0             	cmp    %rdx,%rax
    d0c1:	73 13                	jae    d0d6 <f0+0x14f6>
    d0c3:	49 01 c4             	add    %rax,%r12
    d0c6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0cb:	0f 84 75 16 00 00    	je     e746 <f0+0x2b66>
    d0d1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0d6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0dd:	33 f3 bf 
    d0e0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    d0e7:	00 
    d0e8:	bf 01 00 00 00       	mov    $0x1,%edi
    d0ed:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    d0f4:	00 
    d0f5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    d0fc:	00 
    d0fd:	e8 be 97 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d102:	48 8b 15 0f 0b 06 00 	mov    0x60b0f(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d109:	49 89 c5             	mov    %rax,%r13
    d10c:	48 2b 05 dd 0a 06 00 	sub    0x60add(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d113:	48 c1 e2 10          	shl    $0x10,%rdx
    d117:	48 39 d0             	cmp    %rdx,%rax
    d11a:	73 59                	jae    d175 <f0+0x1595>
    d11c:	48 89 c2             	mov    %rax,%rdx
    d11f:	48 c1 ea 10          	shr    $0x10,%rdx
    d123:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d127:	48 8b 15 0a 0b 06 00 	mov    0x60b0a(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d12e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d132:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d136:	4d 85 e4             	test   %r12,%r12
    d139:	74 3a                	je     d175 <f0+0x1595>
    d13b:	0f b6 0a             	movzbl (%rdx),%ecx
    d13e:	80 f9 02             	cmp    $0x2,%cl
    d141:	0f 84 79 14 00 00    	je     e5c0 <f0+0x29e0>
    d147:	80 f9 01             	cmp    $0x1,%cl
    d14a:	75 29                	jne    d175 <f0+0x1595>
    d14c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d14f:	0f b7 c0             	movzwl %ax,%eax
    d152:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d155:	48 0f af c1          	imul   %rcx,%rax
    d159:	48 c1 e8 20          	shr    $0x20,%rax
    d15d:	48 39 d0             	cmp    %rdx,%rax
    d160:	73 13                	jae    d175 <f0+0x1595>
    d162:	49 01 c4             	add    %rax,%r12
    d165:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d16a:	0f 84 e3 15 00 00    	je     e753 <f0+0x2b73>
    d170:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d175:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d17c:	00 f0 3f 
    d17f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    d186:	00 
    d187:	bf 01 00 00 00       	mov    $0x1,%edi
    d18c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    d193:	00 
    d194:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    d19b:	00 
    d19c:	e8 1f 97 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d1a1:	48 8b 15 70 0a 06 00 	mov    0x60a70(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d1a8:	49 89 c5             	mov    %rax,%r13
    d1ab:	48 2b 05 3e 0a 06 00 	sub    0x60a3e(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d1b2:	48 c1 e2 10          	shl    $0x10,%rdx
    d1b6:	48 39 d0             	cmp    %rdx,%rax
    d1b9:	73 59                	jae    d214 <f0+0x1634>
    d1bb:	48 89 c2             	mov    %rax,%rdx
    d1be:	48 c1 ea 10          	shr    $0x10,%rdx
    d1c2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1c6:	48 8b 15 6b 0a 06 00 	mov    0x60a6b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d1cd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1d1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1d5:	4d 85 e4             	test   %r12,%r12
    d1d8:	74 3a                	je     d214 <f0+0x1634>
    d1da:	0f b6 0a             	movzbl (%rdx),%ecx
    d1dd:	80 f9 02             	cmp    $0x2,%cl
    d1e0:	0f 84 ca 13 00 00    	je     e5b0 <f0+0x29d0>
    d1e6:	80 f9 01             	cmp    $0x1,%cl
    d1e9:	75 29                	jne    d214 <f0+0x1634>
    d1eb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1ee:	0f b7 c0             	movzwl %ax,%eax
    d1f1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1f4:	48 0f af c1          	imul   %rcx,%rax
    d1f8:	48 c1 e8 20          	shr    $0x20,%rax
    d1fc:	48 39 d0             	cmp    %rdx,%rax
    d1ff:	73 13                	jae    d214 <f0+0x1634>
    d201:	49 01 c4             	add    %rax,%r12
    d204:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d209:	0f 84 51 15 00 00    	je     e760 <f0+0x2b80>
    d20f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d214:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d21b:	33 f3 bf 
    d21e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    d225:	00 
    d226:	bf 01 00 00 00       	mov    $0x1,%edi
    d22b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    d232:	00 
    d233:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    d23a:	00 
    d23b:	e8 80 96 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d240:	48 8b 15 d1 09 06 00 	mov    0x609d1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d247:	49 89 c5             	mov    %rax,%r13
    d24a:	48 2b 05 9f 09 06 00 	sub    0x6099f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d251:	48 c1 e2 10          	shl    $0x10,%rdx
    d255:	48 39 d0             	cmp    %rdx,%rax
    d258:	73 59                	jae    d2b3 <f0+0x16d3>
    d25a:	48 89 c2             	mov    %rax,%rdx
    d25d:	48 c1 ea 10          	shr    $0x10,%rdx
    d261:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d265:	48 8b 15 cc 09 06 00 	mov    0x609cc(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d26c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d270:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d274:	4d 85 e4             	test   %r12,%r12
    d277:	74 3a                	je     d2b3 <f0+0x16d3>
    d279:	0f b6 0a             	movzbl (%rdx),%ecx
    d27c:	80 f9 02             	cmp    $0x2,%cl
    d27f:	0f 84 1b 13 00 00    	je     e5a0 <f0+0x29c0>
    d285:	80 f9 01             	cmp    $0x1,%cl
    d288:	75 29                	jne    d2b3 <f0+0x16d3>
    d28a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d28d:	0f b7 c0             	movzwl %ax,%eax
    d290:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d293:	48 0f af c1          	imul   %rcx,%rax
    d297:	48 c1 e8 20          	shr    $0x20,%rax
    d29b:	48 39 d0             	cmp    %rdx,%rax
    d29e:	73 13                	jae    d2b3 <f0+0x16d3>
    d2a0:	49 01 c4             	add    %rax,%r12
    d2a3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2a8:	0f 84 bf 14 00 00    	je     e76d <f0+0x2b8d>
    d2ae:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2b3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2ba:	00 f0 3f 
    d2bd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    d2c4:	00 
    d2c5:	bf 01 00 00 00       	mov    $0x1,%edi
    d2ca:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    d2d1:	00 
    d2d2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    d2d9:	00 
    d2da:	e8 e1 95 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d2df:	48 8b 15 32 09 06 00 	mov    0x60932(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d2e6:	49 89 c5             	mov    %rax,%r13
    d2e9:	48 2b 05 00 09 06 00 	sub    0x60900(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d2f0:	48 c1 e2 10          	shl    $0x10,%rdx
    d2f4:	48 39 d0             	cmp    %rdx,%rax
    d2f7:	73 59                	jae    d352 <f0+0x1772>
    d2f9:	48 89 c2             	mov    %rax,%rdx
    d2fc:	48 c1 ea 10          	shr    $0x10,%rdx
    d300:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d304:	48 8b 15 2d 09 06 00 	mov    0x6092d(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d30b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d30f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d313:	4d 85 e4             	test   %r12,%r12
    d316:	74 3a                	je     d352 <f0+0x1772>
    d318:	0f b6 0a             	movzbl (%rdx),%ecx
    d31b:	80 f9 02             	cmp    $0x2,%cl
    d31e:	0f 84 6c 12 00 00    	je     e590 <f0+0x29b0>
    d324:	80 f9 01             	cmp    $0x1,%cl
    d327:	75 29                	jne    d352 <f0+0x1772>
    d329:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d32c:	0f b7 c0             	movzwl %ax,%eax
    d32f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d332:	48 0f af c1          	imul   %rcx,%rax
    d336:	48 c1 e8 20          	shr    $0x20,%rax
    d33a:	48 39 d0             	cmp    %rdx,%rax
    d33d:	73 13                	jae    d352 <f0+0x1772>
    d33f:	49 01 c4             	add    %rax,%r12
    d342:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d347:	0f 84 2d 14 00 00    	je     e77a <f0+0x2b9a>
    d34d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d352:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d359:	33 f3 bf 
    d35c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    d363:	00 
    d364:	bf 01 00 00 00       	mov    $0x1,%edi
    d369:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    d370:	00 
    d371:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    d378:	00 
    d379:	e8 42 95 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d37e:	48 8b 15 93 08 06 00 	mov    0x60893(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d385:	49 89 c5             	mov    %rax,%r13
    d388:	48 2b 05 61 08 06 00 	sub    0x60861(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d38f:	48 c1 e2 10          	shl    $0x10,%rdx
    d393:	48 39 d0             	cmp    %rdx,%rax
    d396:	73 59                	jae    d3f1 <f0+0x1811>
    d398:	48 89 c2             	mov    %rax,%rdx
    d39b:	48 c1 ea 10          	shr    $0x10,%rdx
    d39f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3a3:	48 8b 15 8e 08 06 00 	mov    0x6088e(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d3aa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3ae:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3b2:	4d 85 e4             	test   %r12,%r12
    d3b5:	74 3a                	je     d3f1 <f0+0x1811>
    d3b7:	0f b6 0a             	movzbl (%rdx),%ecx
    d3ba:	80 f9 02             	cmp    $0x2,%cl
    d3bd:	0f 84 bd 11 00 00    	je     e580 <f0+0x29a0>
    d3c3:	80 f9 01             	cmp    $0x1,%cl
    d3c6:	75 29                	jne    d3f1 <f0+0x1811>
    d3c8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3cb:	0f b7 c0             	movzwl %ax,%eax
    d3ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3d1:	48 0f af c1          	imul   %rcx,%rax
    d3d5:	48 c1 e8 20          	shr    $0x20,%rax
    d3d9:	48 39 d0             	cmp    %rdx,%rax
    d3dc:	73 13                	jae    d3f1 <f0+0x1811>
    d3de:	49 01 c4             	add    %rax,%r12
    d3e1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3e6:	0f 84 9b 13 00 00    	je     e787 <f0+0x2ba7>
    d3ec:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3f1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3f8:	00 f0 3f 
    d3fb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    d402:	00 
    d403:	bf 01 00 00 00       	mov    $0x1,%edi
    d408:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    d40f:	00 
    d410:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    d417:	00 
    d418:	e8 a3 94 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d41d:	48 8b 15 f4 07 06 00 	mov    0x607f4(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d424:	49 89 c5             	mov    %rax,%r13
    d427:	48 2b 05 c2 07 06 00 	sub    0x607c2(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d42e:	48 c1 e2 10          	shl    $0x10,%rdx
    d432:	48 39 d0             	cmp    %rdx,%rax
    d435:	73 59                	jae    d490 <f0+0x18b0>
    d437:	48 89 c2             	mov    %rax,%rdx
    d43a:	48 c1 ea 10          	shr    $0x10,%rdx
    d43e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d442:	48 8b 15 ef 07 06 00 	mov    0x607ef(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d449:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d44d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d451:	4d 85 e4             	test   %r12,%r12
    d454:	74 3a                	je     d490 <f0+0x18b0>
    d456:	0f b6 0a             	movzbl (%rdx),%ecx
    d459:	80 f9 02             	cmp    $0x2,%cl
    d45c:	0f 84 0e 11 00 00    	je     e570 <f0+0x2990>
    d462:	80 f9 01             	cmp    $0x1,%cl
    d465:	75 29                	jne    d490 <f0+0x18b0>
    d467:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d46a:	0f b7 c0             	movzwl %ax,%eax
    d46d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d470:	48 0f af c1          	imul   %rcx,%rax
    d474:	48 c1 e8 20          	shr    $0x20,%rax
    d478:	48 39 d0             	cmp    %rdx,%rax
    d47b:	73 13                	jae    d490 <f0+0x18b0>
    d47d:	49 01 c4             	add    %rax,%r12
    d480:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d485:	0f 84 09 13 00 00    	je     e794 <f0+0x2bb4>
    d48b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d490:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d497:	33 f3 bf 
    d49a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    d4a1:	00 
    d4a2:	bf 01 00 00 00       	mov    $0x1,%edi
    d4a7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    d4ae:	00 
    d4af:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    d4b6:	00 
    d4b7:	e8 04 94 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d4bc:	48 8b 15 55 07 06 00 	mov    0x60755(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d4c3:	49 89 c5             	mov    %rax,%r13
    d4c6:	48 2b 05 23 07 06 00 	sub    0x60723(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d4cd:	48 c1 e2 10          	shl    $0x10,%rdx
    d4d1:	48 39 d0             	cmp    %rdx,%rax
    d4d4:	73 59                	jae    d52f <f0+0x194f>
    d4d6:	48 89 c2             	mov    %rax,%rdx
    d4d9:	48 c1 ea 10          	shr    $0x10,%rdx
    d4dd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4e1:	48 8b 15 50 07 06 00 	mov    0x60750(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d4e8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4ec:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4f0:	4d 85 e4             	test   %r12,%r12
    d4f3:	74 3a                	je     d52f <f0+0x194f>
    d4f5:	0f b6 0a             	movzbl (%rdx),%ecx
    d4f8:	80 f9 02             	cmp    $0x2,%cl
    d4fb:	0f 84 5f 10 00 00    	je     e560 <f0+0x2980>
    d501:	80 f9 01             	cmp    $0x1,%cl
    d504:	75 29                	jne    d52f <f0+0x194f>
    d506:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d509:	0f b7 c0             	movzwl %ax,%eax
    d50c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d50f:	48 0f af c1          	imul   %rcx,%rax
    d513:	48 c1 e8 20          	shr    $0x20,%rax
    d517:	48 39 d0             	cmp    %rdx,%rax
    d51a:	73 13                	jae    d52f <f0+0x194f>
    d51c:	49 01 c4             	add    %rax,%r12
    d51f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d524:	0f 84 77 12 00 00    	je     e7a1 <f0+0x2bc1>
    d52a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d52f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d536:	00 f0 3f 
    d539:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    d540:	00 
    d541:	bf 01 00 00 00       	mov    $0x1,%edi
    d546:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    d54d:	00 
    d54e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    d555:	00 
    d556:	e8 65 93 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d55b:	48 8b 15 b6 06 06 00 	mov    0x606b6(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d562:	49 89 c5             	mov    %rax,%r13
    d565:	48 2b 05 84 06 06 00 	sub    0x60684(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d56c:	48 c1 e2 10          	shl    $0x10,%rdx
    d570:	48 39 d0             	cmp    %rdx,%rax
    d573:	73 59                	jae    d5ce <f0+0x19ee>
    d575:	48 89 c2             	mov    %rax,%rdx
    d578:	48 c1 ea 10          	shr    $0x10,%rdx
    d57c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d580:	48 8b 15 b1 06 06 00 	mov    0x606b1(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d587:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d58b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d58f:	4d 85 e4             	test   %r12,%r12
    d592:	74 3a                	je     d5ce <f0+0x19ee>
    d594:	0f b6 0a             	movzbl (%rdx),%ecx
    d597:	80 f9 02             	cmp    $0x2,%cl
    d59a:	0f 84 40 0f 00 00    	je     e4e0 <f0+0x2900>
    d5a0:	80 f9 01             	cmp    $0x1,%cl
    d5a3:	75 29                	jne    d5ce <f0+0x19ee>
    d5a5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5a8:	0f b7 c0             	movzwl %ax,%eax
    d5ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5ae:	48 0f af c1          	imul   %rcx,%rax
    d5b2:	48 c1 e8 20          	shr    $0x20,%rax
    d5b6:	48 39 d0             	cmp    %rdx,%rax
    d5b9:	73 13                	jae    d5ce <f0+0x19ee>
    d5bb:	49 01 c4             	add    %rax,%r12
    d5be:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5c3:	0f 84 e5 11 00 00    	je     e7ae <f0+0x2bce>
    d5c9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5ce:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d5d5:	33 f3 bf 
    d5d8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    d5df:	00 
    d5e0:	bf 01 00 00 00       	mov    $0x1,%edi
    d5e5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    d5ec:	00 
    d5ed:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    d5f4:	00 
    d5f5:	e8 c6 92 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d5fa:	48 8b 15 17 06 06 00 	mov    0x60617(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d601:	49 89 c5             	mov    %rax,%r13
    d604:	48 2b 05 e5 05 06 00 	sub    0x605e5(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d60b:	48 c1 e2 10          	shl    $0x10,%rdx
    d60f:	48 39 d0             	cmp    %rdx,%rax
    d612:	73 59                	jae    d66d <f0+0x1a8d>
    d614:	48 89 c2             	mov    %rax,%rdx
    d617:	48 c1 ea 10          	shr    $0x10,%rdx
    d61b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d61f:	48 8b 15 12 06 06 00 	mov    0x60612(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d626:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d62a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d62e:	4d 85 e4             	test   %r12,%r12
    d631:	74 3a                	je     d66d <f0+0x1a8d>
    d633:	0f b6 0a             	movzbl (%rdx),%ecx
    d636:	80 f9 02             	cmp    $0x2,%cl
    d639:	0f 84 91 0e 00 00    	je     e4d0 <f0+0x28f0>
    d63f:	80 f9 01             	cmp    $0x1,%cl
    d642:	75 29                	jne    d66d <f0+0x1a8d>
    d644:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d647:	0f b7 c0             	movzwl %ax,%eax
    d64a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d64d:	48 0f af c1          	imul   %rcx,%rax
    d651:	48 c1 e8 20          	shr    $0x20,%rax
    d655:	48 39 d0             	cmp    %rdx,%rax
    d658:	73 13                	jae    d66d <f0+0x1a8d>
    d65a:	49 01 c4             	add    %rax,%r12
    d65d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d662:	0f 84 53 11 00 00    	je     e7bb <f0+0x2bdb>
    d668:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d66d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d674:	00 f0 3f 
    d677:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    d67e:	00 
    d67f:	bf 01 00 00 00       	mov    $0x1,%edi
    d684:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    d68b:	00 
    d68c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    d693:	00 
    d694:	e8 27 92 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d699:	48 8b 15 78 05 06 00 	mov    0x60578(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d6a0:	49 89 c5             	mov    %rax,%r13
    d6a3:	48 2b 05 46 05 06 00 	sub    0x60546(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d6aa:	48 c1 e2 10          	shl    $0x10,%rdx
    d6ae:	48 39 d0             	cmp    %rdx,%rax
    d6b1:	73 59                	jae    d70c <f0+0x1b2c>
    d6b3:	48 89 c2             	mov    %rax,%rdx
    d6b6:	48 c1 ea 10          	shr    $0x10,%rdx
    d6ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6be:	48 8b 15 73 05 06 00 	mov    0x60573(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d6c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6c9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6cd:	4d 85 e4             	test   %r12,%r12
    d6d0:	74 3a                	je     d70c <f0+0x1b2c>
    d6d2:	0f b6 0a             	movzbl (%rdx),%ecx
    d6d5:	80 f9 02             	cmp    $0x2,%cl
    d6d8:	0f 84 e2 0d 00 00    	je     e4c0 <f0+0x28e0>
    d6de:	80 f9 01             	cmp    $0x1,%cl
    d6e1:	75 29                	jne    d70c <f0+0x1b2c>
    d6e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6e6:	0f b7 c0             	movzwl %ax,%eax
    d6e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6ec:	48 0f af c1          	imul   %rcx,%rax
    d6f0:	48 c1 e8 20          	shr    $0x20,%rax
    d6f4:	48 39 d0             	cmp    %rdx,%rax
    d6f7:	73 13                	jae    d70c <f0+0x1b2c>
    d6f9:	49 01 c4             	add    %rax,%r12
    d6fc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d701:	0f 84 c1 10 00 00    	je     e7c8 <f0+0x2be8>
    d707:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d70c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d713:	33 f3 bf 
    d716:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d71d:	00 
    d71e:	bf 01 00 00 00       	mov    $0x1,%edi
    d723:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d72a:	00 
    d72b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d732:	00 
    d733:	e8 88 91 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d738:	48 8b 15 d9 04 06 00 	mov    0x604d9(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d73f:	49 89 c5             	mov    %rax,%r13
    d742:	48 2b 05 a7 04 06 00 	sub    0x604a7(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d749:	48 c1 e2 10          	shl    $0x10,%rdx
    d74d:	48 39 d0             	cmp    %rdx,%rax
    d750:	73 59                	jae    d7ab <f0+0x1bcb>
    d752:	48 89 c2             	mov    %rax,%rdx
    d755:	48 c1 ea 10          	shr    $0x10,%rdx
    d759:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d75d:	48 8b 15 d4 04 06 00 	mov    0x604d4(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d764:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d768:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d76c:	4d 85 e4             	test   %r12,%r12
    d76f:	74 3a                	je     d7ab <f0+0x1bcb>
    d771:	0f b6 0a             	movzbl (%rdx),%ecx
    d774:	80 f9 02             	cmp    $0x2,%cl
    d777:	0f 84 33 0d 00 00    	je     e4b0 <f0+0x28d0>
    d77d:	80 f9 01             	cmp    $0x1,%cl
    d780:	75 29                	jne    d7ab <f0+0x1bcb>
    d782:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d785:	0f b7 c0             	movzwl %ax,%eax
    d788:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d78b:	48 0f af c1          	imul   %rcx,%rax
    d78f:	48 c1 e8 20          	shr    $0x20,%rax
    d793:	48 39 d0             	cmp    %rdx,%rax
    d796:	73 13                	jae    d7ab <f0+0x1bcb>
    d798:	49 01 c4             	add    %rax,%r12
    d79b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7a0:	0f 84 2f 10 00 00    	je     e7d5 <f0+0x2bf5>
    d7a6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7ab:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d7b2:	00 f0 3f 
    d7b5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d7bc:	00 
    d7bd:	bf 01 00 00 00       	mov    $0x1,%edi
    d7c2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d7c9:	00 
    d7ca:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d7d1:	00 
    d7d2:	e8 e9 90 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d7d7:	48 8b 15 3a 04 06 00 	mov    0x6043a(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d7de:	49 89 c5             	mov    %rax,%r13
    d7e1:	48 2b 05 08 04 06 00 	sub    0x60408(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d7e8:	48 c1 e2 10          	shl    $0x10,%rdx
    d7ec:	48 39 d0             	cmp    %rdx,%rax
    d7ef:	73 59                	jae    d84a <f0+0x1c6a>
    d7f1:	48 89 c2             	mov    %rax,%rdx
    d7f4:	48 c1 ea 10          	shr    $0x10,%rdx
    d7f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7fc:	48 8b 15 35 04 06 00 	mov    0x60435(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d803:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d807:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d80b:	4d 85 e4             	test   %r12,%r12
    d80e:	74 3a                	je     d84a <f0+0x1c6a>
    d810:	0f b6 0a             	movzbl (%rdx),%ecx
    d813:	80 f9 02             	cmp    $0x2,%cl
    d816:	0f 84 84 0c 00 00    	je     e4a0 <f0+0x28c0>
    d81c:	80 f9 01             	cmp    $0x1,%cl
    d81f:	75 29                	jne    d84a <f0+0x1c6a>
    d821:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d824:	0f b7 c0             	movzwl %ax,%eax
    d827:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d82a:	48 0f af c1          	imul   %rcx,%rax
    d82e:	48 c1 e8 20          	shr    $0x20,%rax
    d832:	48 39 d0             	cmp    %rdx,%rax
    d835:	73 13                	jae    d84a <f0+0x1c6a>
    d837:	49 01 c4             	add    %rax,%r12
    d83a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d83f:	0f 84 9d 0f 00 00    	je     e7e2 <f0+0x2c02>
    d845:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d84a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d851:	33 f3 bf 
    d854:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d85b:	00 
    d85c:	bf 01 00 00 00       	mov    $0x1,%edi
    d861:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d868:	00 
    d869:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d870:	00 
    d871:	e8 4a 90 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d876:	48 8b 15 9b 03 06 00 	mov    0x6039b(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d87d:	49 89 c5             	mov    %rax,%r13
    d880:	48 2b 05 69 03 06 00 	sub    0x60369(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d887:	48 c1 e2 10          	shl    $0x10,%rdx
    d88b:	48 39 d0             	cmp    %rdx,%rax
    d88e:	73 59                	jae    d8e9 <f0+0x1d09>
    d890:	48 89 c2             	mov    %rax,%rdx
    d893:	48 c1 ea 10          	shr    $0x10,%rdx
    d897:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d89b:	48 8b 15 96 03 06 00 	mov    0x60396(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d8a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8a6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8aa:	4d 85 e4             	test   %r12,%r12
    d8ad:	74 3a                	je     d8e9 <f0+0x1d09>
    d8af:	0f b6 0a             	movzbl (%rdx),%ecx
    d8b2:	80 f9 02             	cmp    $0x2,%cl
    d8b5:	0f 84 d5 0b 00 00    	je     e490 <f0+0x28b0>
    d8bb:	80 f9 01             	cmp    $0x1,%cl
    d8be:	75 29                	jne    d8e9 <f0+0x1d09>
    d8c0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8c3:	0f b7 c0             	movzwl %ax,%eax
    d8c6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8c9:	48 0f af c1          	imul   %rcx,%rax
    d8cd:	48 c1 e8 20          	shr    $0x20,%rax
    d8d1:	48 39 d0             	cmp    %rdx,%rax
    d8d4:	73 13                	jae    d8e9 <f0+0x1d09>
    d8d6:	49 01 c4             	add    %rax,%r12
    d8d9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8de:	0f 84 0b 0f 00 00    	je     e7ef <f0+0x2c0f>
    d8e4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8e9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d8f0:	00 f0 3f 
    d8f3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d8fa:	00 
    d8fb:	bf 01 00 00 00       	mov    $0x1,%edi
    d900:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d907:	00 
    d908:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d90f:	00 
    d910:	e8 ab 8f ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d915:	48 8b 15 fc 02 06 00 	mov    0x602fc(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d91c:	49 89 c5             	mov    %rax,%r13
    d91f:	48 2b 05 ca 02 06 00 	sub    0x602ca(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d926:	48 c1 e2 10          	shl    $0x10,%rdx
    d92a:	48 39 d0             	cmp    %rdx,%rax
    d92d:	73 59                	jae    d988 <f0+0x1da8>
    d92f:	48 89 c2             	mov    %rax,%rdx
    d932:	48 c1 ea 10          	shr    $0x10,%rdx
    d936:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d93a:	48 8b 15 f7 02 06 00 	mov    0x602f7(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d941:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d945:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d949:	4d 85 e4             	test   %r12,%r12
    d94c:	74 3a                	je     d988 <f0+0x1da8>
    d94e:	0f b6 0a             	movzbl (%rdx),%ecx
    d951:	80 f9 02             	cmp    $0x2,%cl
    d954:	0f 84 26 0b 00 00    	je     e480 <f0+0x28a0>
    d95a:	80 f9 01             	cmp    $0x1,%cl
    d95d:	75 29                	jne    d988 <f0+0x1da8>
    d95f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d962:	0f b7 c0             	movzwl %ax,%eax
    d965:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d968:	48 0f af c1          	imul   %rcx,%rax
    d96c:	48 c1 e8 20          	shr    $0x20,%rax
    d970:	48 39 d0             	cmp    %rdx,%rax
    d973:	73 13                	jae    d988 <f0+0x1da8>
    d975:	49 01 c4             	add    %rax,%r12
    d978:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d97d:	0f 84 79 0e 00 00    	je     e7fc <f0+0x2c1c>
    d983:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d988:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d98f:	33 f3 bf 
    d992:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d999:	00 
    d99a:	bf 01 00 00 00       	mov    $0x1,%edi
    d99f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d9a6:	00 
    d9a7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d9ae:	00 
    d9af:	e8 0c 8f ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    d9b4:	48 8b 15 5d 02 06 00 	mov    0x6025d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d9bb:	49 89 c5             	mov    %rax,%r13
    d9be:	48 2b 05 2b 02 06 00 	sub    0x6022b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d9c5:	48 c1 e2 10          	shl    $0x10,%rdx
    d9c9:	48 39 d0             	cmp    %rdx,%rax
    d9cc:	73 59                	jae    da27 <f0+0x1e47>
    d9ce:	48 89 c2             	mov    %rax,%rdx
    d9d1:	48 c1 ea 10          	shr    $0x10,%rdx
    d9d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9d9:	48 8b 15 58 02 06 00 	mov    0x60258(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d9e0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d9e4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9e8:	4d 85 e4             	test   %r12,%r12
    d9eb:	74 3a                	je     da27 <f0+0x1e47>
    d9ed:	0f b6 0a             	movzbl (%rdx),%ecx
    d9f0:	80 f9 02             	cmp    $0x2,%cl
    d9f3:	0f 84 77 0a 00 00    	je     e470 <f0+0x2890>
    d9f9:	80 f9 01             	cmp    $0x1,%cl
    d9fc:	75 29                	jne    da27 <f0+0x1e47>
    d9fe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da01:	0f b7 c0             	movzwl %ax,%eax
    da04:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da07:	48 0f af c1          	imul   %rcx,%rax
    da0b:	48 c1 e8 20          	shr    $0x20,%rax
    da0f:	48 39 d0             	cmp    %rdx,%rax
    da12:	73 13                	jae    da27 <f0+0x1e47>
    da14:	49 01 c4             	add    %rax,%r12
    da17:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da1c:	0f 84 e7 0d 00 00    	je     e809 <f0+0x2c29>
    da22:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da27:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    da2e:	00 f0 3f 
    da31:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    da38:	00 
    da39:	bf 01 00 00 00       	mov    $0x1,%edi
    da3e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    da45:	00 
    da46:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    da4d:	00 
    da4e:	e8 6d 8e ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    da53:	48 8b 15 be 01 06 00 	mov    0x601be(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    da5a:	49 89 c5             	mov    %rax,%r13
    da5d:	48 2b 05 8c 01 06 00 	sub    0x6018c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    da64:	48 c1 e2 10          	shl    $0x10,%rdx
    da68:	48 39 d0             	cmp    %rdx,%rax
    da6b:	73 59                	jae    dac6 <f0+0x1ee6>
    da6d:	48 89 c2             	mov    %rax,%rdx
    da70:	48 c1 ea 10          	shr    $0x10,%rdx
    da74:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da78:	48 8b 15 b9 01 06 00 	mov    0x601b9(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    da7f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da83:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da87:	4d 85 e4             	test   %r12,%r12
    da8a:	74 3a                	je     dac6 <f0+0x1ee6>
    da8c:	0f b6 0a             	movzbl (%rdx),%ecx
    da8f:	80 f9 02             	cmp    $0x2,%cl
    da92:	0f 84 38 0c 00 00    	je     e6d0 <f0+0x2af0>
    da98:	80 f9 01             	cmp    $0x1,%cl
    da9b:	75 29                	jne    dac6 <f0+0x1ee6>
    da9d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    daa0:	0f b7 c0             	movzwl %ax,%eax
    daa3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    daa6:	48 0f af c1          	imul   %rcx,%rax
    daaa:	48 c1 e8 20          	shr    $0x20,%rax
    daae:	48 39 d0             	cmp    %rdx,%rax
    dab1:	73 13                	jae    dac6 <f0+0x1ee6>
    dab3:	49 01 c4             	add    %rax,%r12
    dab6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dabb:	0f 84 55 0d 00 00    	je     e816 <f0+0x2c36>
    dac1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dac6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dacd:	33 f3 bf 
    dad0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    dad7:	00 
    dad8:	bf 01 00 00 00       	mov    $0x1,%edi
    dadd:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    dae4:	00 
    dae5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    daec:	00 
    daed:	e8 ce 8d ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    daf2:	48 8b 15 1f 01 06 00 	mov    0x6011f(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    daf9:	49 89 c5             	mov    %rax,%r13
    dafc:	48 2b 05 ed 00 06 00 	sub    0x600ed(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    db03:	48 c1 e2 10          	shl    $0x10,%rdx
    db07:	48 39 d0             	cmp    %rdx,%rax
    db0a:	73 59                	jae    db65 <f0+0x1f85>
    db0c:	48 89 c2             	mov    %rax,%rdx
    db0f:	48 c1 ea 10          	shr    $0x10,%rdx
    db13:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db17:	48 8b 15 1a 01 06 00 	mov    0x6011a(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    db1e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db22:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db26:	4d 85 e4             	test   %r12,%r12
    db29:	74 3a                	je     db65 <f0+0x1f85>
    db2b:	0f b6 0a             	movzbl (%rdx),%ecx
    db2e:	80 f9 02             	cmp    $0x2,%cl
    db31:	0f 84 89 0b 00 00    	je     e6c0 <f0+0x2ae0>
    db37:	80 f9 01             	cmp    $0x1,%cl
    db3a:	75 29                	jne    db65 <f0+0x1f85>
    db3c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db3f:	0f b7 c0             	movzwl %ax,%eax
    db42:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db45:	48 0f af c1          	imul   %rcx,%rax
    db49:	48 c1 e8 20          	shr    $0x20,%rax
    db4d:	48 39 d0             	cmp    %rdx,%rax
    db50:	73 13                	jae    db65 <f0+0x1f85>
    db52:	49 01 c4             	add    %rax,%r12
    db55:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db5a:	0f 84 c3 0c 00 00    	je     e823 <f0+0x2c43>
    db60:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db65:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    db6c:	00 f0 3f 
    db6f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    db76:	00 
    db77:	bf 01 00 00 00       	mov    $0x1,%edi
    db7c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    db83:	00 
    db84:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    db8b:	00 
    db8c:	e8 2f 8d ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    db91:	48 8b 15 80 00 06 00 	mov    0x60080(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    db98:	49 89 c5             	mov    %rax,%r13
    db9b:	48 2b 05 4e 00 06 00 	sub    0x6004e(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dba2:	48 c1 e2 10          	shl    $0x10,%rdx
    dba6:	48 39 d0             	cmp    %rdx,%rax
    dba9:	73 59                	jae    dc04 <f0+0x2024>
    dbab:	48 89 c2             	mov    %rax,%rdx
    dbae:	48 c1 ea 10          	shr    $0x10,%rdx
    dbb2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbb6:	48 8b 15 7b 00 06 00 	mov    0x6007b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dbbd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbc1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbc5:	4d 85 e4             	test   %r12,%r12
    dbc8:	74 3a                	je     dc04 <f0+0x2024>
    dbca:	0f b6 0a             	movzbl (%rdx),%ecx
    dbcd:	80 f9 02             	cmp    $0x2,%cl
    dbd0:	0f 84 da 0a 00 00    	je     e6b0 <f0+0x2ad0>
    dbd6:	80 f9 01             	cmp    $0x1,%cl
    dbd9:	75 29                	jne    dc04 <f0+0x2024>
    dbdb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbde:	0f b7 c0             	movzwl %ax,%eax
    dbe1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dbe4:	48 0f af c1          	imul   %rcx,%rax
    dbe8:	48 c1 e8 20          	shr    $0x20,%rax
    dbec:	48 39 d0             	cmp    %rdx,%rax
    dbef:	73 13                	jae    dc04 <f0+0x2024>
    dbf1:	49 01 c4             	add    %rax,%r12
    dbf4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dbf9:	0f 84 31 0c 00 00    	je     e830 <f0+0x2c50>
    dbff:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc04:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dc0b:	33 f3 bf 
    dc0e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    dc15:	00 
    dc16:	bf 01 00 00 00       	mov    $0x1,%edi
    dc1b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    dc22:	00 
    dc23:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    dc2a:	00 
    dc2b:	e8 90 8c ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    dc30:	48 8b 15 e1 ff 05 00 	mov    0x5ffe1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dc37:	49 89 c5             	mov    %rax,%r13
    dc3a:	48 2b 05 af ff 05 00 	sub    0x5ffaf(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dc41:	48 c1 e2 10          	shl    $0x10,%rdx
    dc45:	48 39 d0             	cmp    %rdx,%rax
    dc48:	73 59                	jae    dca3 <f0+0x20c3>
    dc4a:	48 89 c2             	mov    %rax,%rdx
    dc4d:	48 c1 ea 10          	shr    $0x10,%rdx
    dc51:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc55:	48 8b 15 dc ff 05 00 	mov    0x5ffdc(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dc5c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc60:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc64:	4d 85 e4             	test   %r12,%r12
    dc67:	74 3a                	je     dca3 <f0+0x20c3>
    dc69:	0f b6 0a             	movzbl (%rdx),%ecx
    dc6c:	80 f9 02             	cmp    $0x2,%cl
    dc6f:	0f 84 2b 0a 00 00    	je     e6a0 <f0+0x2ac0>
    dc75:	80 f9 01             	cmp    $0x1,%cl
    dc78:	75 29                	jne    dca3 <f0+0x20c3>
    dc7a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc7d:	0f b7 c0             	movzwl %ax,%eax
    dc80:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc83:	48 0f af c1          	imul   %rcx,%rax
    dc87:	48 c1 e8 20          	shr    $0x20,%rax
    dc8b:	48 39 d0             	cmp    %rdx,%rax
    dc8e:	73 13                	jae    dca3 <f0+0x20c3>
    dc90:	49 01 c4             	add    %rax,%r12
    dc93:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc98:	0f 84 9f 0b 00 00    	je     e83d <f0+0x2c5d>
    dc9e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dca3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dcaa:	00 f0 3f 
    dcad:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    dcb4:	00 
    dcb5:	bf 01 00 00 00       	mov    $0x1,%edi
    dcba:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    dcc1:	00 
    dcc2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    dcc9:	00 
    dcca:	e8 f1 8b ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    dccf:	48 8b 15 42 ff 05 00 	mov    0x5ff42(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dcd6:	49 89 c5             	mov    %rax,%r13
    dcd9:	48 2b 05 10 ff 05 00 	sub    0x5ff10(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dce0:	48 c1 e2 10          	shl    $0x10,%rdx
    dce4:	48 39 d0             	cmp    %rdx,%rax
    dce7:	73 59                	jae    dd42 <f0+0x2162>
    dce9:	48 89 c2             	mov    %rax,%rdx
    dcec:	48 c1 ea 10          	shr    $0x10,%rdx
    dcf0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dcf4:	48 8b 15 3d ff 05 00 	mov    0x5ff3d(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dcfb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dcff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd03:	4d 85 e4             	test   %r12,%r12
    dd06:	74 3a                	je     dd42 <f0+0x2162>
    dd08:	0f b6 0a             	movzbl (%rdx),%ecx
    dd0b:	80 f9 02             	cmp    $0x2,%cl
    dd0e:	0f 84 7c 09 00 00    	je     e690 <f0+0x2ab0>
    dd14:	80 f9 01             	cmp    $0x1,%cl
    dd17:	75 29                	jne    dd42 <f0+0x2162>
    dd19:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd1c:	0f b7 c0             	movzwl %ax,%eax
    dd1f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd22:	48 0f af c1          	imul   %rcx,%rax
    dd26:	48 c1 e8 20          	shr    $0x20,%rax
    dd2a:	48 39 d0             	cmp    %rdx,%rax
    dd2d:	73 13                	jae    dd42 <f0+0x2162>
    dd2f:	49 01 c4             	add    %rax,%r12
    dd32:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd37:	0f 84 0d 0b 00 00    	je     e84a <f0+0x2c6a>
    dd3d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd42:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dd49:	33 f3 bf 
    dd4c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    dd53:	00 
    dd54:	bf 01 00 00 00       	mov    $0x1,%edi
    dd59:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    dd60:	00 
    dd61:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    dd68:	00 
    dd69:	e8 52 8b ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    dd6e:	48 8b 15 a3 fe 05 00 	mov    0x5fea3(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dd75:	49 89 c5             	mov    %rax,%r13
    dd78:	48 2b 05 71 fe 05 00 	sub    0x5fe71(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dd7f:	48 c1 e2 10          	shl    $0x10,%rdx
    dd83:	48 39 d0             	cmp    %rdx,%rax
    dd86:	73 59                	jae    dde1 <f0+0x2201>
    dd88:	48 89 c2             	mov    %rax,%rdx
    dd8b:	48 c1 ea 10          	shr    $0x10,%rdx
    dd8f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd93:	48 8b 15 9e fe 05 00 	mov    0x5fe9e(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dd9a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd9e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dda2:	4d 85 e4             	test   %r12,%r12
    dda5:	74 3a                	je     dde1 <f0+0x2201>
    dda7:	0f b6 0a             	movzbl (%rdx),%ecx
    ddaa:	80 f9 02             	cmp    $0x2,%cl
    ddad:	0f 84 cd 08 00 00    	je     e680 <f0+0x2aa0>
    ddb3:	80 f9 01             	cmp    $0x1,%cl
    ddb6:	75 29                	jne    dde1 <f0+0x2201>
    ddb8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ddbb:	0f b7 c0             	movzwl %ax,%eax
    ddbe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ddc1:	48 0f af c1          	imul   %rcx,%rax
    ddc5:	48 c1 e8 20          	shr    $0x20,%rax
    ddc9:	48 39 d0             	cmp    %rdx,%rax
    ddcc:	73 13                	jae    dde1 <f0+0x2201>
    ddce:	49 01 c4             	add    %rax,%r12
    ddd1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ddd6:	0f 84 7b 0a 00 00    	je     e857 <f0+0x2c77>
    dddc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dde1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dde8:	00 f0 3f 
    ddeb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    ddf2:	00 
    ddf3:	bf 01 00 00 00       	mov    $0x1,%edi
    ddf8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    ddff:	00 
    de00:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    de07:	00 
    de08:	e8 b3 8a ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    de0d:	48 8b 15 04 fe 05 00 	mov    0x5fe04(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    de14:	49 89 c5             	mov    %rax,%r13
    de17:	48 2b 05 d2 fd 05 00 	sub    0x5fdd2(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    de1e:	48 c1 e2 10          	shl    $0x10,%rdx
    de22:	48 39 d0             	cmp    %rdx,%rax
    de25:	73 59                	jae    de80 <f0+0x22a0>
    de27:	48 89 c2             	mov    %rax,%rdx
    de2a:	48 c1 ea 10          	shr    $0x10,%rdx
    de2e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    de32:	48 8b 15 ff fd 05 00 	mov    0x5fdff(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    de39:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    de3d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    de41:	4d 85 e4             	test   %r12,%r12
    de44:	74 3a                	je     de80 <f0+0x22a0>
    de46:	0f b6 0a             	movzbl (%rdx),%ecx
    de49:	80 f9 02             	cmp    $0x2,%cl
    de4c:	0f 84 1e 08 00 00    	je     e670 <f0+0x2a90>
    de52:	80 f9 01             	cmp    $0x1,%cl
    de55:	75 29                	jne    de80 <f0+0x22a0>
    de57:	8b 4a 18             	mov    0x18(%rdx),%ecx
    de5a:	0f b7 c0             	movzwl %ax,%eax
    de5d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    de60:	48 0f af c1          	imul   %rcx,%rax
    de64:	48 c1 e8 20          	shr    $0x20,%rax
    de68:	48 39 d0             	cmp    %rdx,%rax
    de6b:	73 13                	jae    de80 <f0+0x22a0>
    de6d:	49 01 c4             	add    %rax,%r12
    de70:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    de75:	0f 84 e9 09 00 00    	je     e864 <f0+0x2c84>
    de7b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de80:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    de87:	33 f3 bf 
    de8a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    de91:	00 
    de92:	bf 01 00 00 00       	mov    $0x1,%edi
    de97:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    de9e:	00 
    de9f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    dea6:	00 
    dea7:	e8 14 8a ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    deac:	48 8b 15 65 fd 05 00 	mov    0x5fd65(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    deb3:	49 89 c5             	mov    %rax,%r13
    deb6:	48 2b 05 33 fd 05 00 	sub    0x5fd33(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    debd:	48 c1 e2 10          	shl    $0x10,%rdx
    dec1:	48 39 d0             	cmp    %rdx,%rax
    dec4:	73 59                	jae    df1f <f0+0x233f>
    dec6:	48 89 c2             	mov    %rax,%rdx
    dec9:	48 c1 ea 10          	shr    $0x10,%rdx
    decd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ded1:	48 8b 15 60 fd 05 00 	mov    0x5fd60(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    ded8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dedc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dee0:	4d 85 e4             	test   %r12,%r12
    dee3:	74 3a                	je     df1f <f0+0x233f>
    dee5:	0f b6 0a             	movzbl (%rdx),%ecx
    dee8:	80 f9 02             	cmp    $0x2,%cl
    deeb:	0f 84 6f 07 00 00    	je     e660 <f0+0x2a80>
    def1:	80 f9 01             	cmp    $0x1,%cl
    def4:	75 29                	jne    df1f <f0+0x233f>
    def6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    def9:	0f b7 c0             	movzwl %ax,%eax
    defc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    deff:	48 0f af c1          	imul   %rcx,%rax
    df03:	48 c1 e8 20          	shr    $0x20,%rax
    df07:	48 39 d0             	cmp    %rdx,%rax
    df0a:	73 13                	jae    df1f <f0+0x233f>
    df0c:	49 01 c4             	add    %rax,%r12
    df0f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    df14:	0f 84 57 09 00 00    	je     e871 <f0+0x2c91>
    df1a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    df1f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    df26:	00 f0 3f 
    df29:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    df30:	00 
    df31:	bf 01 00 00 00       	mov    $0x1,%edi
    df36:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    df3d:	00 
    df3e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    df45:	00 
    df46:	e8 75 89 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    df4b:	48 8b 15 c6 fc 05 00 	mov    0x5fcc6(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    df52:	49 89 c5             	mov    %rax,%r13
    df55:	48 2b 05 94 fc 05 00 	sub    0x5fc94(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    df5c:	48 c1 e2 10          	shl    $0x10,%rdx
    df60:	48 39 d0             	cmp    %rdx,%rax
    df63:	73 59                	jae    dfbe <f0+0x23de>
    df65:	48 89 c2             	mov    %rax,%rdx
    df68:	48 c1 ea 10          	shr    $0x10,%rdx
    df6c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    df70:	48 8b 15 c1 fc 05 00 	mov    0x5fcc1(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    df77:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    df7b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    df7f:	4d 85 e4             	test   %r12,%r12
    df82:	74 3a                	je     dfbe <f0+0x23de>
    df84:	0f b6 0a             	movzbl (%rdx),%ecx
    df87:	80 f9 02             	cmp    $0x2,%cl
    df8a:	0f 84 c0 06 00 00    	je     e650 <f0+0x2a70>
    df90:	80 f9 01             	cmp    $0x1,%cl
    df93:	75 29                	jne    dfbe <f0+0x23de>
    df95:	8b 4a 18             	mov    0x18(%rdx),%ecx
    df98:	0f b7 c0             	movzwl %ax,%eax
    df9b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    df9e:	48 0f af c1          	imul   %rcx,%rax
    dfa2:	48 c1 e8 20          	shr    $0x20,%rax
    dfa6:	48 39 d0             	cmp    %rdx,%rax
    dfa9:	73 13                	jae    dfbe <f0+0x23de>
    dfab:	49 01 c4             	add    %rax,%r12
    dfae:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dfb3:	0f 84 c5 08 00 00    	je     e87e <f0+0x2c9e>
    dfb9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dfbe:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dfc5:	33 f3 bf 
    dfc8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    dfcf:	00 
    dfd0:	bf 01 00 00 00       	mov    $0x1,%edi
    dfd5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    dfdc:	00 
    dfdd:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    dfe4:	00 
    dfe5:	e8 d6 88 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    dfea:	48 8b 15 27 fc 05 00 	mov    0x5fc27(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dff1:	49 89 c5             	mov    %rax,%r13
    dff4:	48 2b 05 f5 fb 05 00 	sub    0x5fbf5(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dffb:	48 c1 e2 10          	shl    $0x10,%rdx
    dfff:	48 39 d0             	cmp    %rdx,%rax
    e002:	73 59                	jae    e05d <f0+0x247d>
    e004:	48 89 c2             	mov    %rax,%rdx
    e007:	48 c1 ea 10          	shr    $0x10,%rdx
    e00b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e00f:	48 8b 15 22 fc 05 00 	mov    0x5fc22(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e016:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e01a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e01e:	4d 85 e4             	test   %r12,%r12
    e021:	74 3a                	je     e05d <f0+0x247d>
    e023:	0f b6 0a             	movzbl (%rdx),%ecx
    e026:	80 f9 02             	cmp    $0x2,%cl
    e029:	0f 84 11 06 00 00    	je     e640 <f0+0x2a60>
    e02f:	80 f9 01             	cmp    $0x1,%cl
    e032:	75 29                	jne    e05d <f0+0x247d>
    e034:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e037:	0f b7 c0             	movzwl %ax,%eax
    e03a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e03d:	48 0f af c1          	imul   %rcx,%rax
    e041:	48 c1 e8 20          	shr    $0x20,%rax
    e045:	48 39 d0             	cmp    %rdx,%rax
    e048:	73 13                	jae    e05d <f0+0x247d>
    e04a:	49 01 c4             	add    %rax,%r12
    e04d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e052:	0f 84 33 08 00 00    	je     e88b <f0+0x2cab>
    e058:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e05d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e064:	00 f0 3f 
    e067:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    e06e:	00 
    e06f:	bf 01 00 00 00       	mov    $0x1,%edi
    e074:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    e07b:	00 
    e07c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    e083:	00 
    e084:	e8 37 88 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    e089:	48 8b 15 88 fb 05 00 	mov    0x5fb88(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e090:	49 89 c5             	mov    %rax,%r13
    e093:	48 2b 05 56 fb 05 00 	sub    0x5fb56(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e09a:	48 c1 e2 10          	shl    $0x10,%rdx
    e09e:	48 39 d0             	cmp    %rdx,%rax
    e0a1:	73 59                	jae    e0fc <f0+0x251c>
    e0a3:	48 89 c2             	mov    %rax,%rdx
    e0a6:	48 c1 ea 10          	shr    $0x10,%rdx
    e0aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e0ae:	48 8b 15 83 fb 05 00 	mov    0x5fb83(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e0b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e0b9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e0bd:	4d 85 e4             	test   %r12,%r12
    e0c0:	74 3a                	je     e0fc <f0+0x251c>
    e0c2:	0f b6 0a             	movzbl (%rdx),%ecx
    e0c5:	80 f9 02             	cmp    $0x2,%cl
    e0c8:	0f 84 62 05 00 00    	je     e630 <f0+0x2a50>
    e0ce:	80 f9 01             	cmp    $0x1,%cl
    e0d1:	75 29                	jne    e0fc <f0+0x251c>
    e0d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e0d6:	0f b7 c0             	movzwl %ax,%eax
    e0d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e0dc:	48 0f af c1          	imul   %rcx,%rax
    e0e0:	48 c1 e8 20          	shr    $0x20,%rax
    e0e4:	48 39 d0             	cmp    %rdx,%rax
    e0e7:	73 13                	jae    e0fc <f0+0x251c>
    e0e9:	49 01 c4             	add    %rax,%r12
    e0ec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e0f1:	0f 84 a1 07 00 00    	je     e898 <f0+0x2cb8>
    e0f7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e0fc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e103:	33 f3 bf 
    e106:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    e10d:	00 
    e10e:	bf 01 00 00 00       	mov    $0x1,%edi
    e113:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    e11a:	00 
    e11b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    e122:	00 
    e123:	e8 98 87 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    e128:	48 8b 15 e9 fa 05 00 	mov    0x5fae9(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e12f:	49 89 c5             	mov    %rax,%r13
    e132:	48 2b 05 b7 fa 05 00 	sub    0x5fab7(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e139:	48 c1 e2 10          	shl    $0x10,%rdx
    e13d:	48 39 d0             	cmp    %rdx,%rax
    e140:	73 59                	jae    e19b <f0+0x25bb>
    e142:	48 89 c2             	mov    %rax,%rdx
    e145:	48 c1 ea 10          	shr    $0x10,%rdx
    e149:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e14d:	48 8b 15 e4 fa 05 00 	mov    0x5fae4(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e154:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e158:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e15c:	4d 85 e4             	test   %r12,%r12
    e15f:	74 3a                	je     e19b <f0+0x25bb>
    e161:	0f b6 0a             	movzbl (%rdx),%ecx
    e164:	80 f9 02             	cmp    $0x2,%cl
    e167:	0f 84 b3 04 00 00    	je     e620 <f0+0x2a40>
    e16d:	80 f9 01             	cmp    $0x1,%cl
    e170:	75 29                	jne    e19b <f0+0x25bb>
    e172:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e175:	0f b7 c0             	movzwl %ax,%eax
    e178:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e17b:	48 0f af c1          	imul   %rcx,%rax
    e17f:	48 c1 e8 20          	shr    $0x20,%rax
    e183:	48 39 d0             	cmp    %rdx,%rax
    e186:	73 13                	jae    e19b <f0+0x25bb>
    e188:	49 01 c4             	add    %rax,%r12
    e18b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e190:	0f 84 0f 07 00 00    	je     e8a5 <f0+0x2cc5>
    e196:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e19b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e1a2:	00 f0 3f 
    e1a5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    e1ac:	00 
    e1ad:	bf 01 00 00 00       	mov    $0x1,%edi
    e1b2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    e1b9:	00 
    e1ba:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    e1c1:	00 
    e1c2:	e8 f9 86 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    e1c7:	48 8b 15 4a fa 05 00 	mov    0x5fa4a(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e1ce:	49 89 c5             	mov    %rax,%r13
    e1d1:	48 2b 05 18 fa 05 00 	sub    0x5fa18(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e1d8:	48 c1 e2 10          	shl    $0x10,%rdx
    e1dc:	48 39 d0             	cmp    %rdx,%rax
    e1df:	73 59                	jae    e23a <f0+0x265a>
    e1e1:	48 89 c2             	mov    %rax,%rdx
    e1e4:	48 c1 ea 10          	shr    $0x10,%rdx
    e1e8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e1ec:	48 8b 15 45 fa 05 00 	mov    0x5fa45(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e1f3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e1f7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e1fb:	4d 85 e4             	test   %r12,%r12
    e1fe:	74 3a                	je     e23a <f0+0x265a>
    e200:	0f b6 0a             	movzbl (%rdx),%ecx
    e203:	80 f9 02             	cmp    $0x2,%cl
    e206:	0f 84 04 04 00 00    	je     e610 <f0+0x2a30>
    e20c:	80 f9 01             	cmp    $0x1,%cl
    e20f:	75 29                	jne    e23a <f0+0x265a>
    e211:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e214:	0f b7 c0             	movzwl %ax,%eax
    e217:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e21a:	48 0f af c1          	imul   %rcx,%rax
    e21e:	48 c1 e8 20          	shr    $0x20,%rax
    e222:	48 39 d0             	cmp    %rdx,%rax
    e225:	73 13                	jae    e23a <f0+0x265a>
    e227:	49 01 c4             	add    %rax,%r12
    e22a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e22f:	0f 84 7d 06 00 00    	je     e8b2 <f0+0x2cd2>
    e235:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e23a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e241:	33 f3 bf 
    e244:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    e24b:	00 
    e24c:	bf 01 00 00 00       	mov    $0x1,%edi
    e251:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    e258:	00 
    e259:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    e260:	00 
    e261:	e8 5a 86 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    e266:	48 8b 15 ab f9 05 00 	mov    0x5f9ab(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e26d:	49 89 c5             	mov    %rax,%r13
    e270:	48 2b 05 79 f9 05 00 	sub    0x5f979(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e277:	48 c1 e2 10          	shl    $0x10,%rdx
    e27b:	48 39 d0             	cmp    %rdx,%rax
    e27e:	73 59                	jae    e2d9 <f0+0x26f9>
    e280:	48 89 c2             	mov    %rax,%rdx
    e283:	48 c1 ea 10          	shr    $0x10,%rdx
    e287:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e28b:	48 8b 15 a6 f9 05 00 	mov    0x5f9a6(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e292:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e296:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e29a:	4d 85 e4             	test   %r12,%r12
    e29d:	74 3a                	je     e2d9 <f0+0x26f9>
    e29f:	0f b6 0a             	movzbl (%rdx),%ecx
    e2a2:	80 f9 02             	cmp    $0x2,%cl
    e2a5:	0f 84 55 03 00 00    	je     e600 <f0+0x2a20>
    e2ab:	80 f9 01             	cmp    $0x1,%cl
    e2ae:	75 29                	jne    e2d9 <f0+0x26f9>
    e2b0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e2b3:	0f b7 c0             	movzwl %ax,%eax
    e2b6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e2b9:	48 0f af c1          	imul   %rcx,%rax
    e2bd:	48 c1 e8 20          	shr    $0x20,%rax
    e2c1:	48 39 d0             	cmp    %rdx,%rax
    e2c4:	73 13                	jae    e2d9 <f0+0x26f9>
    e2c6:	49 01 c4             	add    %rax,%r12
    e2c9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e2ce:	0f 84 eb 05 00 00    	je     e8bf <f0+0x2cdf>
    e2d4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e2d9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e2e0:	00 f0 3f 
    e2e3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    e2ea:	00 
    e2eb:	bf 01 00 00 00       	mov    $0x1,%edi
    e2f0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    e2f7:	00 
    e2f8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    e2ff:	00 
    e300:	e8 bb 85 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    e305:	48 8b 15 0c f9 05 00 	mov    0x5f90c(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e30c:	49 89 c5             	mov    %rax,%r13
    e30f:	48 2b 05 da f8 05 00 	sub    0x5f8da(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e316:	48 c1 e2 10          	shl    $0x10,%rdx
    e31a:	48 39 d0             	cmp    %rdx,%rax
    e31d:	73 59                	jae    e378 <f0+0x2798>
    e31f:	48 89 c2             	mov    %rax,%rdx
    e322:	48 c1 ea 10          	shr    $0x10,%rdx
    e326:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e32a:	48 8b 15 07 f9 05 00 	mov    0x5f907(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e331:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e335:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e339:	4d 85 e4             	test   %r12,%r12
    e33c:	74 3a                	je     e378 <f0+0x2798>
    e33e:	0f b6 0a             	movzbl (%rdx),%ecx
    e341:	80 f9 02             	cmp    $0x2,%cl
    e344:	0f 84 a6 02 00 00    	je     e5f0 <f0+0x2a10>
    e34a:	80 f9 01             	cmp    $0x1,%cl
    e34d:	75 29                	jne    e378 <f0+0x2798>
    e34f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e352:	0f b7 c0             	movzwl %ax,%eax
    e355:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e358:	48 0f af c1          	imul   %rcx,%rax
    e35c:	48 c1 e8 20          	shr    $0x20,%rax
    e360:	48 39 d0             	cmp    %rdx,%rax
    e363:	73 13                	jae    e378 <f0+0x2798>
    e365:	49 01 c4             	add    %rax,%r12
    e368:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e36d:	0f 84 59 05 00 00    	je     e8cc <f0+0x2cec>
    e373:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e378:	48 89 ee             	mov    %rbp,%rsi
    e37b:	bf 01 00 00 00       	mov    $0x1,%edi
    e380:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e387:	33 f3 bf 
    e38a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    e391:	00 
    e392:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    e399:	00 
    e39a:	e8 21 85 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    e39f:	48 8b 15 72 f8 05 00 	mov    0x5f872(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e3a6:	48 89 c5             	mov    %rax,%rbp
    e3a9:	48 2b 05 40 f8 05 00 	sub    0x5f840(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e3b0:	48 c1 e2 10          	shl    $0x10,%rdx
    e3b4:	48 39 d0             	cmp    %rdx,%rax
    e3b7:	73 59                	jae    e412 <f0+0x2832>
    e3b9:	48 89 c2             	mov    %rax,%rdx
    e3bc:	48 c1 ea 10          	shr    $0x10,%rdx
    e3c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e3c4:	48 8b 15 6d f8 05 00 	mov    0x5f86d(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e3cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e3cf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e3d3:	4d 85 e4             	test   %r12,%r12
    e3d6:	74 3a                	je     e412 <f0+0x2832>
    e3d8:	0f b6 0a             	movzbl (%rdx),%ecx
    e3db:	80 f9 02             	cmp    $0x2,%cl
    e3de:	0f 84 fc 01 00 00    	je     e5e0 <f0+0x2a00>
    e3e4:	80 f9 01             	cmp    $0x1,%cl
    e3e7:	75 29                	jne    e412 <f0+0x2832>
    e3e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e3ec:	0f b7 c0             	movzwl %ax,%eax
    e3ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e3f2:	48 0f af c1          	imul   %rcx,%rax
    e3f6:	48 c1 e8 20          	shr    $0x20,%rax
    e3fa:	48 39 d0             	cmp    %rdx,%rax
    e3fd:	73 13                	jae    e412 <f0+0x2832>
    e3ff:	49 01 c4             	add    %rax,%r12
    e402:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e407:	0f 84 d1 02 00 00    	je     e6de <f0+0x2afe>
    e40d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e412:	48 89 de             	mov    %rbx,%rsi
    e415:	48 89 ef             	mov    %rbp,%rdi
    e418:	e8 03 ca ff ff       	call   ae20 <fwp_hof0.constprop.0>
    e41d:	48 89 ef             	mov    %rbp,%rdi
    e420:	e8 eb 8a ff ff       	call   6f10 <fwp_drop0>
    e425:	48 89 df             	mov    %rbx,%rdi
    e428:	e8 e3 8a ff ff       	call   6f10 <fwp_drop0>
    e42d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    e434:	00 
    e435:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e43c:	00 00 
    e43e:	0f 85 95 04 00 00    	jne    e8d9 <f0+0x2cf9>
    e444:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    e44b:	31 c0                	xor    %eax,%eax
    e44d:	5b                   	pop    %rbx
    e44e:	5d                   	pop    %rbp
    e44f:	41 5c                	pop    %r12
    e451:	41 5d                	pop    %r13
    e453:	41 5e                	pop    %r14
    e455:	c3                   	ret
    e456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e45d:	00 00 00 
    e460:	4c 89 ef             	mov    %r13,%rdi
    e463:	e8 68 73 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e468:	e9 2c d8 ff ff       	jmp    bc99 <f0+0xb9>
    e46d:	0f 1f 00             	nopl   (%rax)
    e470:	66 85 c0             	test   %ax,%ax
    e473:	0f 85 ae f5 ff ff    	jne    da27 <f0+0x1e47>
    e479:	e9 99 f5 ff ff       	jmp    da17 <f0+0x1e37>
    e47e:	66 90                	xchg   %ax,%ax
    e480:	66 85 c0             	test   %ax,%ax
    e483:	0f 85 ff f4 ff ff    	jne    d988 <f0+0x1da8>
    e489:	e9 ea f4 ff ff       	jmp    d978 <f0+0x1d98>
    e48e:	66 90                	xchg   %ax,%ax
    e490:	66 85 c0             	test   %ax,%ax
    e493:	0f 85 50 f4 ff ff    	jne    d8e9 <f0+0x1d09>
    e499:	e9 3b f4 ff ff       	jmp    d8d9 <f0+0x1cf9>
    e49e:	66 90                	xchg   %ax,%ax
    e4a0:	66 85 c0             	test   %ax,%ax
    e4a3:	0f 85 a1 f3 ff ff    	jne    d84a <f0+0x1c6a>
    e4a9:	e9 8c f3 ff ff       	jmp    d83a <f0+0x1c5a>
    e4ae:	66 90                	xchg   %ax,%ax
    e4b0:	66 85 c0             	test   %ax,%ax
    e4b3:	0f 85 f2 f2 ff ff    	jne    d7ab <f0+0x1bcb>
    e4b9:	e9 dd f2 ff ff       	jmp    d79b <f0+0x1bbb>
    e4be:	66 90                	xchg   %ax,%ax
    e4c0:	66 85 c0             	test   %ax,%ax
    e4c3:	0f 85 43 f2 ff ff    	jne    d70c <f0+0x1b2c>
    e4c9:	e9 2e f2 ff ff       	jmp    d6fc <f0+0x1b1c>
    e4ce:	66 90                	xchg   %ax,%ax
    e4d0:	66 85 c0             	test   %ax,%ax
    e4d3:	0f 85 94 f1 ff ff    	jne    d66d <f0+0x1a8d>
    e4d9:	e9 7f f1 ff ff       	jmp    d65d <f0+0x1a7d>
    e4de:	66 90                	xchg   %ax,%ax
    e4e0:	66 85 c0             	test   %ax,%ax
    e4e3:	0f 85 e5 f0 ff ff    	jne    d5ce <f0+0x19ee>
    e4e9:	e9 d0 f0 ff ff       	jmp    d5be <f0+0x19de>
    e4ee:	66 90                	xchg   %ax,%ax
    e4f0:	66 85 c0             	test   %ax,%ax
    e4f3:	0f 85 fd d9 ff ff    	jne    bef6 <f0+0x316>
    e4f9:	e9 e8 d9 ff ff       	jmp    bee6 <f0+0x306>
    e4fe:	66 90                	xchg   %ax,%ax
    e500:	66 85 c0             	test   %ax,%ax
    e503:	0f 85 57 d9 ff ff    	jne    be60 <f0+0x280>
    e509:	e9 42 d9 ff ff       	jmp    be50 <f0+0x270>
    e50e:	66 90                	xchg   %ax,%ax
    e510:	66 85 c0             	test   %ax,%ax
    e513:	0f 85 b1 d8 ff ff    	jne    bdca <f0+0x1ea>
    e519:	e9 9c d8 ff ff       	jmp    bdba <f0+0x1da>
    e51e:	66 90                	xchg   %ax,%ax
    e520:	66 85 c0             	test   %ax,%ax
    e523:	0f 85 0e eb ff ff    	jne    d037 <f0+0x1457>
    e529:	e9 f9 ea ff ff       	jmp    d027 <f0+0x1447>
    e52e:	66 90                	xchg   %ax,%ax
    e530:	66 85 c0             	test   %ax,%ax
    e533:	0f 85 91 db ff ff    	jne    c0ca <f0+0x4ea>
    e539:	e9 7c db ff ff       	jmp    c0ba <f0+0x4da>
    e53e:	66 90                	xchg   %ax,%ax
    e540:	66 85 c0             	test   %ax,%ax
    e543:	0f 85 e2 da ff ff    	jne    c02b <f0+0x44b>
    e549:	e9 cd da ff ff       	jmp    c01b <f0+0x43b>
    e54e:	66 90                	xchg   %ax,%ax
    e550:	66 85 c0             	test   %ax,%ax
    e553:	0f 85 33 da ff ff    	jne    bf8c <f0+0x3ac>
    e559:	e9 1e da ff ff       	jmp    bf7c <f0+0x39c>
    e55e:	66 90                	xchg   %ax,%ax
    e560:	66 85 c0             	test   %ax,%ax
    e563:	0f 85 c6 ef ff ff    	jne    d52f <f0+0x194f>
    e569:	e9 b1 ef ff ff       	jmp    d51f <f0+0x193f>
    e56e:	66 90                	xchg   %ax,%ax
    e570:	66 85 c0             	test   %ax,%ax
    e573:	0f 85 17 ef ff ff    	jne    d490 <f0+0x18b0>
    e579:	e9 02 ef ff ff       	jmp    d480 <f0+0x18a0>
    e57e:	66 90                	xchg   %ax,%ax
    e580:	66 85 c0             	test   %ax,%ax
    e583:	0f 85 68 ee ff ff    	jne    d3f1 <f0+0x1811>
    e589:	e9 53 ee ff ff       	jmp    d3e1 <f0+0x1801>
    e58e:	66 90                	xchg   %ax,%ax
    e590:	66 85 c0             	test   %ax,%ax
    e593:	0f 85 b9 ed ff ff    	jne    d352 <f0+0x1772>
    e599:	e9 a4 ed ff ff       	jmp    d342 <f0+0x1762>
    e59e:	66 90                	xchg   %ax,%ax
    e5a0:	66 85 c0             	test   %ax,%ax
    e5a3:	0f 85 0a ed ff ff    	jne    d2b3 <f0+0x16d3>
    e5a9:	e9 f5 ec ff ff       	jmp    d2a3 <f0+0x16c3>
    e5ae:	66 90                	xchg   %ax,%ax
    e5b0:	66 85 c0             	test   %ax,%ax
    e5b3:	0f 85 5b ec ff ff    	jne    d214 <f0+0x1634>
    e5b9:	e9 46 ec ff ff       	jmp    d204 <f0+0x1624>
    e5be:	66 90                	xchg   %ax,%ax
    e5c0:	66 85 c0             	test   %ax,%ax
    e5c3:	0f 85 ac eb ff ff    	jne    d175 <f0+0x1595>
    e5c9:	e9 97 eb ff ff       	jmp    d165 <f0+0x1585>
    e5ce:	66 90                	xchg   %ax,%ax
    e5d0:	66 85 c0             	test   %ax,%ax
    e5d3:	0f 85 fd ea ff ff    	jne    d0d6 <f0+0x14f6>
    e5d9:	e9 e8 ea ff ff       	jmp    d0c6 <f0+0x14e6>
    e5de:	66 90                	xchg   %ax,%ax
    e5e0:	66 85 c0             	test   %ax,%ax
    e5e3:	0f 85 29 fe ff ff    	jne    e412 <f0+0x2832>
    e5e9:	e9 14 fe ff ff       	jmp    e402 <f0+0x2822>
    e5ee:	66 90                	xchg   %ax,%ax
    e5f0:	66 85 c0             	test   %ax,%ax
    e5f3:	0f 85 7f fd ff ff    	jne    e378 <f0+0x2798>
    e5f9:	e9 6a fd ff ff       	jmp    e368 <f0+0x2788>
    e5fe:	66 90                	xchg   %ax,%ax
    e600:	66 85 c0             	test   %ax,%ax
    e603:	0f 85 d0 fc ff ff    	jne    e2d9 <f0+0x26f9>
    e609:	e9 bb fc ff ff       	jmp    e2c9 <f0+0x26e9>
    e60e:	66 90                	xchg   %ax,%ax
    e610:	66 85 c0             	test   %ax,%ax
    e613:	0f 85 21 fc ff ff    	jne    e23a <f0+0x265a>
    e619:	e9 0c fc ff ff       	jmp    e22a <f0+0x264a>
    e61e:	66 90                	xchg   %ax,%ax
    e620:	66 85 c0             	test   %ax,%ax
    e623:	0f 85 72 fb ff ff    	jne    e19b <f0+0x25bb>
    e629:	e9 5d fb ff ff       	jmp    e18b <f0+0x25ab>
    e62e:	66 90                	xchg   %ax,%ax
    e630:	66 85 c0             	test   %ax,%ax
    e633:	0f 85 c3 fa ff ff    	jne    e0fc <f0+0x251c>
    e639:	e9 ae fa ff ff       	jmp    e0ec <f0+0x250c>
    e63e:	66 90                	xchg   %ax,%ax
    e640:	66 85 c0             	test   %ax,%ax
    e643:	0f 85 14 fa ff ff    	jne    e05d <f0+0x247d>
    e649:	e9 ff f9 ff ff       	jmp    e04d <f0+0x246d>
    e64e:	66 90                	xchg   %ax,%ax
    e650:	66 85 c0             	test   %ax,%ax
    e653:	0f 85 65 f9 ff ff    	jne    dfbe <f0+0x23de>
    e659:	e9 50 f9 ff ff       	jmp    dfae <f0+0x23ce>
    e65e:	66 90                	xchg   %ax,%ax
    e660:	66 85 c0             	test   %ax,%ax
    e663:	0f 85 b6 f8 ff ff    	jne    df1f <f0+0x233f>
    e669:	e9 a1 f8 ff ff       	jmp    df0f <f0+0x232f>
    e66e:	66 90                	xchg   %ax,%ax
    e670:	66 85 c0             	test   %ax,%ax
    e673:	0f 85 07 f8 ff ff    	jne    de80 <f0+0x22a0>
    e679:	e9 f2 f7 ff ff       	jmp    de70 <f0+0x2290>
    e67e:	66 90                	xchg   %ax,%ax
    e680:	66 85 c0             	test   %ax,%ax
    e683:	0f 85 58 f7 ff ff    	jne    dde1 <f0+0x2201>
    e689:	e9 43 f7 ff ff       	jmp    ddd1 <f0+0x21f1>
    e68e:	66 90                	xchg   %ax,%ax
    e690:	66 85 c0             	test   %ax,%ax
    e693:	0f 85 a9 f6 ff ff    	jne    dd42 <f0+0x2162>
    e699:	e9 94 f6 ff ff       	jmp    dd32 <f0+0x2152>
    e69e:	66 90                	xchg   %ax,%ax
    e6a0:	66 85 c0             	test   %ax,%ax
    e6a3:	0f 85 fa f5 ff ff    	jne    dca3 <f0+0x20c3>
    e6a9:	e9 e5 f5 ff ff       	jmp    dc93 <f0+0x20b3>
    e6ae:	66 90                	xchg   %ax,%ax
    e6b0:	66 85 c0             	test   %ax,%ax
    e6b3:	0f 85 4b f5 ff ff    	jne    dc04 <f0+0x2024>
    e6b9:	e9 36 f5 ff ff       	jmp    dbf4 <f0+0x2014>
    e6be:	66 90                	xchg   %ax,%ax
    e6c0:	66 85 c0             	test   %ax,%ax
    e6c3:	0f 85 9c f4 ff ff    	jne    db65 <f0+0x1f85>
    e6c9:	e9 87 f4 ff ff       	jmp    db55 <f0+0x1f75>
    e6ce:	66 90                	xchg   %ax,%ax
    e6d0:	66 85 c0             	test   %ax,%ax
    e6d3:	0f 85 ed f3 ff ff    	jne    dac6 <f0+0x1ee6>
    e6d9:	e9 d8 f3 ff ff       	jmp    dab6 <f0+0x1ed6>
    e6de:	4c 89 e7             	mov    %r12,%rdi
    e6e1:	e8 ea 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e6e6:	e9 22 fd ff ff       	jmp    e40d <f0+0x282d>
    e6eb:	4c 89 e7             	mov    %r12,%rdi
    e6ee:	e8 dd 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e6f3:	e9 cd d6 ff ff       	jmp    bdc5 <f0+0x1e5>
    e6f8:	4c 89 e7             	mov    %r12,%rdi
    e6fb:	e8 d0 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e700:	e9 56 d7 ff ff       	jmp    be5b <f0+0x27b>
    e705:	4c 89 e7             	mov    %r12,%rdi
    e708:	e8 c3 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e70d:	e9 df d7 ff ff       	jmp    bef1 <f0+0x311>
    e712:	4c 89 e7             	mov    %r12,%rdi
    e715:	e8 b6 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e71a:	e9 68 d8 ff ff       	jmp    bf87 <f0+0x3a7>
    e71f:	4c 89 e7             	mov    %r12,%rdi
    e722:	e8 a9 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e727:	e9 fa d8 ff ff       	jmp    c026 <f0+0x446>
    e72c:	4c 89 e7             	mov    %r12,%rdi
    e72f:	e8 9c 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e734:	e9 8c d9 ff ff       	jmp    c0c5 <f0+0x4e5>
    e739:	4c 89 e7             	mov    %r12,%rdi
    e73c:	e8 8f 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e741:	e9 ec e8 ff ff       	jmp    d032 <f0+0x1452>
    e746:	4c 89 e7             	mov    %r12,%rdi
    e749:	e8 82 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e74e:	e9 7e e9 ff ff       	jmp    d0d1 <f0+0x14f1>
    e753:	4c 89 e7             	mov    %r12,%rdi
    e756:	e8 75 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e75b:	e9 10 ea ff ff       	jmp    d170 <f0+0x1590>
    e760:	4c 89 e7             	mov    %r12,%rdi
    e763:	e8 68 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e768:	e9 a2 ea ff ff       	jmp    d20f <f0+0x162f>
    e76d:	4c 89 e7             	mov    %r12,%rdi
    e770:	e8 5b 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e775:	e9 34 eb ff ff       	jmp    d2ae <f0+0x16ce>
    e77a:	4c 89 e7             	mov    %r12,%rdi
    e77d:	e8 4e 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e782:	e9 c6 eb ff ff       	jmp    d34d <f0+0x176d>
    e787:	4c 89 e7             	mov    %r12,%rdi
    e78a:	e8 41 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e78f:	e9 58 ec ff ff       	jmp    d3ec <f0+0x180c>
    e794:	4c 89 e7             	mov    %r12,%rdi
    e797:	e8 34 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e79c:	e9 ea ec ff ff       	jmp    d48b <f0+0x18ab>
    e7a1:	4c 89 e7             	mov    %r12,%rdi
    e7a4:	e8 27 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7a9:	e9 7c ed ff ff       	jmp    d52a <f0+0x194a>
    e7ae:	4c 89 e7             	mov    %r12,%rdi
    e7b1:	e8 1a 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7b6:	e9 0e ee ff ff       	jmp    d5c9 <f0+0x19e9>
    e7bb:	4c 89 e7             	mov    %r12,%rdi
    e7be:	e8 0d 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7c3:	e9 a0 ee ff ff       	jmp    d668 <f0+0x1a88>
    e7c8:	4c 89 e7             	mov    %r12,%rdi
    e7cb:	e8 00 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7d0:	e9 32 ef ff ff       	jmp    d707 <f0+0x1b27>
    e7d5:	4c 89 e7             	mov    %r12,%rdi
    e7d8:	e8 f3 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7dd:	e9 c4 ef ff ff       	jmp    d7a6 <f0+0x1bc6>
    e7e2:	4c 89 e7             	mov    %r12,%rdi
    e7e5:	e8 e6 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7ea:	e9 56 f0 ff ff       	jmp    d845 <f0+0x1c65>
    e7ef:	4c 89 e7             	mov    %r12,%rdi
    e7f2:	e8 d9 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7f7:	e9 e8 f0 ff ff       	jmp    d8e4 <f0+0x1d04>
    e7fc:	4c 89 e7             	mov    %r12,%rdi
    e7ff:	e8 cc 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e804:	e9 7a f1 ff ff       	jmp    d983 <f0+0x1da3>
    e809:	4c 89 e7             	mov    %r12,%rdi
    e80c:	e8 bf 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e811:	e9 0c f2 ff ff       	jmp    da22 <f0+0x1e42>
    e816:	4c 89 e7             	mov    %r12,%rdi
    e819:	e8 b2 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e81e:	e9 9e f2 ff ff       	jmp    dac1 <f0+0x1ee1>
    e823:	4c 89 e7             	mov    %r12,%rdi
    e826:	e8 a5 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e82b:	e9 30 f3 ff ff       	jmp    db60 <f0+0x1f80>
    e830:	4c 89 e7             	mov    %r12,%rdi
    e833:	e8 98 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e838:	e9 c2 f3 ff ff       	jmp    dbff <f0+0x201f>
    e83d:	4c 89 e7             	mov    %r12,%rdi
    e840:	e8 8b 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e845:	e9 54 f4 ff ff       	jmp    dc9e <f0+0x20be>
    e84a:	4c 89 e7             	mov    %r12,%rdi
    e84d:	e8 7e 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e852:	e9 e6 f4 ff ff       	jmp    dd3d <f0+0x215d>
    e857:	4c 89 e7             	mov    %r12,%rdi
    e85a:	e8 71 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e85f:	e9 78 f5 ff ff       	jmp    dddc <f0+0x21fc>
    e864:	4c 89 e7             	mov    %r12,%rdi
    e867:	e8 64 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e86c:	e9 0a f6 ff ff       	jmp    de7b <f0+0x229b>
    e871:	4c 89 e7             	mov    %r12,%rdi
    e874:	e8 57 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e879:	e9 9c f6 ff ff       	jmp    df1a <f0+0x233a>
    e87e:	4c 89 e7             	mov    %r12,%rdi
    e881:	e8 4a 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e886:	e9 2e f7 ff ff       	jmp    dfb9 <f0+0x23d9>
    e88b:	4c 89 e7             	mov    %r12,%rdi
    e88e:	e8 3d 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e893:	e9 c0 f7 ff ff       	jmp    e058 <f0+0x2478>
    e898:	4c 89 e7             	mov    %r12,%rdi
    e89b:	e8 30 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e8a0:	e9 52 f8 ff ff       	jmp    e0f7 <f0+0x2517>
    e8a5:	4c 89 e7             	mov    %r12,%rdi
    e8a8:	e8 23 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e8ad:	e9 e4 f8 ff ff       	jmp    e196 <f0+0x25b6>
    e8b2:	4c 89 e7             	mov    %r12,%rdi
    e8b5:	e8 16 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e8ba:	e9 76 f9 ff ff       	jmp    e235 <f0+0x2655>
    e8bf:	4c 89 e7             	mov    %r12,%rdi
    e8c2:	e8 09 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e8c7:	e9 08 fa ff ff       	jmp    e2d4 <f0+0x26f4>
    e8cc:	4c 89 e7             	mov    %r12,%rdi
    e8cf:	e8 fc 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e8d4:	e9 9a fa ff ff       	jmp    e373 <f0+0x2793>
    e8d9:	e8 72 4b ff ff       	call   3450 <__stack_chk_fail@plt>
    e8de:	66 90                	xchg   %ax,%ax

000000000000e8e0 <fwp_main_thread>:
    e8e0:	f3 0f 1e fa          	endbr64
    e8e4:	41 54                	push   %r12
    e8e6:	55                   	push   %rbp
    e8e7:	53                   	push   %rbx
    e8e8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e8ef:	8b 0d ef f2 05 00    	mov    0x5f2ef(%rip),%ecx        # 6dbe4 <fwp_heap+0x13a4>
    e8f5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e8fc:	00 00 
    e8fe:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e905:	00 
    e906:	31 c0                	xor    %eax,%eax
    e908:	85 c9                	test   %ecx,%ecx
    e90a:	0f 84 58 07 00 00    	je     f068 <fwp_main_thread+0x788>
    e910:	8b 15 d2 f2 05 00    	mov    0x5f2d2(%rip),%edx        # 6dbe8 <fwp_heap+0x13a8>
    e916:	85 d2                	test   %edx,%edx
    e918:	0f 85 32 07 00 00    	jne    f050 <fwp_main_thread+0x770>
    e91e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e923:	31 f6                	xor    %esi,%esi
    e925:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e92a:	48 c7 05 ab d8 05 00 	movq   $0x40000000,0x5d8ab(%rip)        # 6c1e0 <fwp_main_stack_size>
    e931:	00 00 00 40 
    e935:	48 89 05 ac d8 05 00 	mov    %rax,0x5d8ac(%rip)        # 6c1e8 <fwp_main_stack_top>
    e93c:	48 8d 05 5d 57 00 00 	lea    0x575d(%rip),%rax        # 140a0 <alt.5>
    e943:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e948:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e94f:	01 00 
    e951:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e958:	00 
    e959:	e8 42 4d ff ff       	call   36a0 <sigaltstack@plt>
    e95e:	85 c0                	test   %eax,%eax
    e960:	0f 85 6a 07 00 00    	jne    f0d0 <fwp_main_thread+0x7f0>
    e966:	31 c0                	xor    %eax,%eax
    e968:	b9 12 00 00 00       	mov    $0x12,%ecx
    e96d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e972:	f3 48 ab             	rep stos %rax,(%rdi)
    e975:	48 8d 05 c4 53 ff ff 	lea    -0xac3c(%rip),%rax        # 3d40 <fwp_segv>
    e97c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e981:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e988:	04 00 00 08 
    e98c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e991:	e8 ca 4b ff ff       	call   3560 <sigemptyset@plt>
    e996:	85 c0                	test   %eax,%eax
    e998:	0f 85 32 07 00 00    	jne    f0d0 <fwp_main_thread+0x7f0>
    e99e:	31 d2                	xor    %edx,%edx
    e9a0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e9a5:	bf 0b 00 00 00       	mov    $0xb,%edi
    e9aa:	e8 41 4a ff ff       	call   33f0 <sigaction@plt>
    e9af:	85 c0                	test   %eax,%eax
    e9b1:	0f 85 19 07 00 00    	jne    f0d0 <fwp_main_thread+0x7f0>
    e9b7:	31 d2                	xor    %edx,%edx
    e9b9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e9be:	bf 07 00 00 00       	mov    $0x7,%edi
    e9c3:	e8 28 4a ff ff       	call   33f0 <sigaction@plt>
    e9c8:	85 c0                	test   %eax,%eax
    e9ca:	0f 85 00 07 00 00    	jne    f0d0 <fwp_main_thread+0x7f0>
    e9d0:	48 8b 05 89 f2 05 00 	mov    0x5f289(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    e9d7:	48 85 c0             	test   %rax,%rax
    e9da:	0f 88 50 06 00 00    	js     f030 <fwp_main_thread+0x750>
    e9e0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e9e4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    e9e9:	48 8d 3d 30 58 ff ff 	lea    -0xa7d0(%rip),%rdi        # 4220 <ad_raw_report>
    e9f0:	f2 0f 11 05 f0 fa 05 	movsd  %xmm0,0x5faf0(%rip)        # 6e4e8 <iteration_start_charge>
    e9f7:	00 
    e9f8:	c7 05 06 fb 05 00 01 	movl   $0x1,0x5fb06(%rip)        # 6e508 <iteration_active>
    e9ff:	00 00 00 
    ea02:	e8 09 09 00 00       	call   f310 <atexit>
    ea07:	85 c0                	test   %eax,%eax
    ea09:	0f 85 cd 06 00 00    	jne    f0dc <fwp_main_thread+0x7fc>
    ea0f:	8b 05 7b 56 00 00    	mov    0x567b(%rip),%eax        # 14090 <st.3>
    ea15:	85 c0                	test   %eax,%eax
    ea17:	0f 84 5b 06 00 00    	je     f078 <fwp_main_thread+0x798>
    ea1d:	48 8b 2d fc dd 05 00 	mov    0x5ddfc(%rip),%rbp        # 6c820 <fwp_cur>
    ea24:	48 85 ed             	test   %rbp,%rbp
    ea27:	0f 84 03 03 00 00    	je     ed30 <fwp_main_thread+0x450>
    ea2d:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    ea32:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    ea36:	48 89 eb             	mov    %rbp,%rbx
    ea39:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ea3e:	0f 84 41 01 00 00    	je     eb85 <fwp_main_thread+0x2a5>
    ea44:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    ea49:	0f 84 11 02 00 00    	je     ec60 <fwp_main_thread+0x380>
    ea4f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ea53:	0f 84 f7 01 00 00    	je     ec50 <fwp_main_thread+0x370>
    ea59:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ea5d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ea61:	0f 85 79 02 00 00    	jne    ece0 <fwp_main_thread+0x400>
    ea67:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ea6b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ea72:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ea76:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ea7d:	00 00 00 00 
    ea81:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ea88:	48 85 d2             	test   %rdx,%rdx
    ea8b:	74 07                	je     ea94 <fwp_main_thread+0x1b4>
    ea8d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ea94:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ea98:	48 85 c0             	test   %rax,%rax
    ea9b:	74 34                	je     ead1 <fwp_main_thread+0x1f1>
    ea9d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    eaa1:	48 8b 05 50 dd 05 00 	mov    0x5dd50(%rip),%rax        # 6c7f8 <fwp_timers>
    eaa8:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    eaac:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    eab3:	00 00 00 00 
    eab7:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    eabe:	48 85 c0             	test   %rax,%rax
    eac1:	74 07                	je     eaca <fwp_main_thread+0x1ea>
    eac3:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    eaca:	48 89 1d 27 dd 05 00 	mov    %rbx,0x5dd27(%rip)        # 6c7f8 <fwp_timers>
    ead1:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    ead5:	e8 96 8e ff ff       	call   7970 <fwp_block>
    eada:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    eae1:	48 85 c9             	test   %rcx,%rcx
    eae4:	74 47                	je     eb2d <fwp_main_thread+0x24d>
    eae6:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    eaed:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    eaf4:	48 85 d2             	test   %rdx,%rdx
    eaf7:	0f 84 23 02 00 00    	je     ed20 <fwp_main_thread+0x440>
    eafd:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    eb04:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    eb0b:	48 85 c0             	test   %rax,%rax
    eb0e:	74 07                	je     eb17 <fwp_main_thread+0x237>
    eb10:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    eb17:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    eb1e:	00 00 00 00 
    eb22:	66 0f ef d2          	pxor   %xmm2,%xmm2
    eb26:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    eb2d:	48 8b 0d ec dc 05 00 	mov    0x5dcec(%rip),%rcx        # 6c820 <fwp_cur>
    eb34:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    eb38:	0f 84 92 01 00 00    	je     ecd0 <fwp_main_thread+0x3f0>
    eb3e:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    eb45:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    eb4c:	48 85 d2             	test   %rdx,%rdx
    eb4f:	0f 84 1b 04 00 00    	je     ef70 <fwp_main_thread+0x690>
    eb55:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    eb5c:	48 85 c0             	test   %rax,%rax
    eb5f:	74 07                	je     eb68 <fwp_main_thread+0x288>
    eb61:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    eb68:	66 0f ef db          	pxor   %xmm3,%xmm3
    eb6c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    eb70:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    eb77:	48 89 cb             	mov    %rcx,%rbx
    eb7a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    eb7f:	0f 85 bf fe ff ff    	jne    ea44 <fwp_main_thread+0x164>
    eb85:	48 83 3d 2b f9 05 00 	cmpq   $0x0,0x5f92b(%rip)        # 6e4b8 <fwp_state_len>
    eb8c:	00 
    eb8d:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    eb91:	0f 84 0b 04 00 00    	je     efa2 <fwp_main_thread+0x6c2>
    eb97:	48 3b 1d 7a dc 05 00 	cmp    0x5dc7a(%rip),%rbx        # 6c818 <fwp_root>
    eb9e:	c7 05 f8 54 01 00 00 	movl   $0x0,0x154f8(%rip)        # 240a0 <fwp_exit_code>
    eba5:	00 00 00 
    eba8:	0f 85 4c 05 00 00    	jne    f0fa <fwp_main_thread+0x81a>
    ebae:	48 85 db             	test   %rbx,%rbx
    ebb1:	0f 84 9f 01 00 00    	je     ed56 <fwp_main_thread+0x476>
    ebb7:	48 8b 15 2a dc 05 00 	mov    0x5dc2a(%rip),%rdx        # 6c7e8 <fwp_tasks_active>
    ebbe:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    ebc2:	48 85 d2             	test   %rdx,%rdx
    ebc5:	0f 84 8b 01 00 00    	je     ed56 <fwp_main_thread+0x476>
    ebcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ebd0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    ebd4:	75 08                	jne    ebde <fwp_main_thread+0x2fe>
    ebd6:	48 89 d7             	mov    %rdx,%rdi
    ebd9:	e8 52 55 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    ebde:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    ebe5:	48 85 d2             	test   %rdx,%rdx
    ebe8:	75 e6                	jne    ebd0 <fwp_main_thread+0x2f0>
    ebea:	eb 31                	jmp    ec1d <fwp_main_thread+0x33d>
    ebec:	0f 1f 40 00          	nopl   0x0(%rax)
    ebf0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    ebf7:	48 89 1d 02 dc 05 00 	mov    %rbx,0x5dc02(%rip)        # 6c800 <fwp_ready_tail>
    ebfe:	e8 6d 8d ff ff       	call   7970 <fwp_block>
    ec03:	e8 68 8b ff ff       	call   7770 <fwp_free_zombie>
    ec08:	48 83 3d d8 db 05 00 	cmpq   $0x0,0x5dbd8(%rip)        # 6c7e8 <fwp_tasks_active>
    ec0f:	00 
    ec10:	0f 84 40 01 00 00    	je     ed56 <fwp_main_thread+0x476>
    ec16:	48 8b 1d fb db 05 00 	mov    0x5dbfb(%rip),%rbx        # 6c818 <fwp_root>
    ec1d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    ec21:	75 db                	jne    ebfe <fwp_main_thread+0x31e>
    ec23:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    ec27:	75 d5                	jne    ebfe <fwp_main_thread+0x31e>
    ec29:	48 8b 05 d0 db 05 00 	mov    0x5dbd0(%rip),%rax        # 6c800 <fwp_ready_tail>
    ec30:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    ec34:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    ec3b:	00 00 00 00 
    ec3f:	48 85 c0             	test   %rax,%rax
    ec42:	75 ac                	jne    ebf0 <fwp_main_thread+0x310>
    ec44:	48 89 1d bd db 05 00 	mov    %rbx,0x5dbbd(%rip)        # 6c808 <fwp_ready_head>
    ec4b:	eb aa                	jmp    ebf7 <fwp_main_thread+0x317>
    ec4d:	0f 1f 00             	nopl   (%rax)
    ec50:	e8 6b 59 ff ff       	call   45c0 <fwp_now_ns>
    ec55:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    ec59:	0f 8d 21 03 00 00    	jge    ef80 <fwp_main_thread+0x6a0>
    ec5f:	90                   	nop
    ec60:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ec64:	0f 85 ef fd ff ff    	jne    ea59 <fwp_main_thread+0x179>
    ec6a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    ec6e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ec72:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ec76:	0f 85 ef fd ff ff    	jne    ea6b <fwp_main_thread+0x18b>
    ec7c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    ec80:	48 85 c9             	test   %rcx,%rcx
    ec83:	0f 84 e2 fd ff ff    	je     ea6b <fwp_main_thread+0x18b>
    ec89:	48 85 c0             	test   %rax,%rax
    ec8c:	0f 84 5b 04 00 00    	je     f0ed <fwp_main_thread+0x80d>
    ec92:	48 39 c8             	cmp    %rcx,%rax
    ec95:	48 0f 4f c1          	cmovg  %rcx,%rax
    ec99:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    eca0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    eca4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ecab:	00 00 00 00 
    ecaf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ecb6:	48 85 d2             	test   %rdx,%rdx
    ecb9:	74 07                	je     ecc2 <fwp_main_thread+0x3e2>
    ecbb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ecc2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ecc6:	e9 d2 fd ff ff       	jmp    ea9d <fwp_main_thread+0x1bd>
    eccb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ecd0:	48 89 cb             	mov    %rcx,%rbx
    ecd3:	e9 61 fd ff ff       	jmp    ea39 <fwp_main_thread+0x159>
    ecd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ecdf:	00 
    ece0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    ece4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    eceb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ecf2:	00 00 00 00 
    ecf6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    ecfd:	48 85 c0             	test   %rax,%rax
    ed00:	0f 84 9a 03 00 00    	je     f0a0 <fwp_main_thread+0x7c0>
    ed06:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    ed0d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ed11:	e9 bb fd ff ff       	jmp    ead1 <fwp_main_thread+0x1f1>
    ed16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ed1d:	00 00 00 
    ed20:	48 89 01             	mov    %rax,(%rcx)
    ed23:	e9 e3 fd ff ff       	jmp    eb0b <fwp_main_thread+0x22b>
    ed28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ed2f:	00 
    ed30:	48 83 3d 80 f7 05 00 	cmpq   $0x0,0x5f780(%rip)        # 6e4b8 <fwp_state_len>
    ed37:	00 
    ed38:	0f 84 62 02 00 00    	je     efa0 <fwp_main_thread+0x6c0>
    ed3e:	48 83 3d d2 da 05 00 	cmpq   $0x0,0x5dad2(%rip)        # 6c818 <fwp_root>
    ed45:	00 
    ed46:	c7 05 50 53 01 00 00 	movl   $0x0,0x15350(%rip)        # 240a0 <fwp_exit_code>
    ed4d:	00 00 00 
    ed50:	0f 85 9f 03 00 00    	jne    f0f5 <fwp_main_thread+0x815>
    ed56:	e8 15 8a ff ff       	call   7770 <fwp_free_zombie>
    ed5b:	48 83 3d a5 da 05 00 	cmpq   $0x0,0x5daa5(%rip)        # 6c808 <fwp_ready_head>
    ed62:	00 
    ed63:	0f 85 e7 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    ed69:	48 83 3d 87 da 05 00 	cmpq   $0x0,0x5da87(%rip)        # 6c7f8 <fwp_timers>
    ed70:	00 
    ed71:	0f 85 d9 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    ed77:	8b 1d 77 d4 05 00    	mov    0x5d477(%rip),%ebx        # 6c1f4 <fwp_stack_pool_n>
    ed7d:	85 db                	test   %ebx,%ebx
    ed7f:	74 36                	je     edb7 <fwp_main_thread+0x4d7>
    ed81:	83 eb 01             	sub    $0x1,%ebx
    ed84:	48 8d 05 75 d4 05 00 	lea    0x5d475(%rip),%rax        # 6c200 <fwp_stack_pool>
    ed8b:	48 63 d3             	movslq %ebx,%rdx
    ed8e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    ed92:	eb 07                	jmp    ed9b <fwp_main_thread+0x4bb>
    ed94:	0f 1f 40 00          	nopl   0x0(%rax)
    ed98:	83 eb 01             	sub    $0x1,%ebx
    ed9b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    ed9f:	be 00 00 00 10       	mov    $0x10000000,%esi
    eda4:	89 1d 4a d4 05 00    	mov    %ebx,0x5d44a(%rip)        # 6c1f4 <fwp_stack_pool_n>
    edaa:	48 83 ed 08          	sub    $0x8,%rbp
    edae:	e8 0d 48 ff ff       	call   35c0 <munmap@plt>
    edb3:	85 db                	test   %ebx,%ebx
    edb5:	75 e1                	jne    ed98 <fwp_main_thread+0x4b8>
    edb7:	8b 3d 63 52 00 00    	mov    0x5263(%rip),%edi        # 14020 <fwp_epfd>
    edbd:	85 ff                	test   %edi,%edi
    edbf:	78 05                	js     edc6 <fwp_main_thread+0x4e6>
    edc1:	e8 fa 46 ff ff       	call   34c0 <close@plt>
    edc6:	4c 8b 25 33 d6 05 00 	mov    0x5d633(%rip),%r12        # 6c400 <fwp_nfdws>
    edcd:	48 8b 2d 34 d6 05 00 	mov    0x5d634(%rip),%rbp        # 6c408 <fwp_fdws>
    edd4:	31 db                	xor    %ebx,%ebx
    edd6:	c7 05 40 52 00 00 ff 	movl   $0xffffffff,0x5240(%rip)        # 14020 <fwp_epfd>
    eddd:	ff ff ff 
    ede0:	4d 85 e4             	test   %r12,%r12
    ede3:	74 38                	je     ee1d <fwp_main_thread+0x53d>
    ede5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    edec:	00 00 00 00 
    edf0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    edf5:	48 85 ff             	test   %rdi,%rdi
    edf8:	74 1a                	je     ee14 <fwp_main_thread+0x534>
    edfa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    edfe:	0f 85 4c 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    ee04:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    ee09:	0f 85 41 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    ee0f:	e8 fc 6b ff ff       	call   5a10 <fwp_mem_free>
    ee14:	48 83 c3 01          	add    $0x1,%rbx
    ee18:	49 39 dc             	cmp    %rbx,%r12
    ee1b:	75 d3                	jne    edf0 <fwp_main_thread+0x510>
    ee1d:	48 89 ef             	mov    %rbp,%rdi
    ee20:	e8 eb 6b ff ff       	call   5a10 <fwp_mem_free>
    ee25:	48 8b 15 ec d9 05 00 	mov    0x5d9ec(%rip),%rdx        # 6c818 <fwp_root>
    ee2c:	48 c7 05 d1 d5 05 00 	movq   $0x0,0x5d5d1(%rip)        # 6c408 <fwp_fdws>
    ee33:	00 00 00 00 
    ee37:	48 c7 05 be d5 05 00 	movq   $0x0,0x5d5be(%rip)        # 6c400 <fwp_nfdws>
    ee3e:	00 00 00 00 
    ee42:	48 85 d2             	test   %rdx,%rdx
    ee45:	74 4e                	je     ee95 <fwp_main_thread+0x5b5>
    ee47:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    ee4c:	0f 85 fe 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    ee52:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    ee59:	00 
    ee5a:	0f 85 f0 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    ee60:	48 83 3d 50 f6 05 00 	cmpq   $0x0,0x5f650(%rip)        # 6e4b8 <fwp_state_len>
    ee67:	00 
    ee68:	0f 85 e2 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    ee6e:	48 83 3d 32 f6 05 00 	cmpq   $0x0,0x5f632(%rip)        # 6e4a8 <fwp_state_owners>
    ee75:	00 
    ee76:	0f 85 d4 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    ee7c:	b9 79 00 00 00       	mov    $0x79,%ecx
    ee81:	31 c0                	xor    %eax,%eax
    ee83:	48 8d 3d 96 d5 05 00 	lea    0x5d596(%rip),%rdi        # 6c420 <fwp_root_context>
    ee8a:	f3 48 ab             	rep stos %rax,(%rdi)
    ee8d:	48 89 d7             	mov    %rdx,%rdi
    ee90:	e8 7b 6b ff ff       	call   5a10 <fwp_mem_free>
    ee95:	66 0f 6f 05 33 53 04 	movdqa 0x45333(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    ee9c:	00 
    ee9d:	66 0f d4 05 1b 53 04 	paddq  0x4531b(%rip),%xmm0        # 541c0 <ad_raw_live>
    eea4:	00 
    eea5:	48 c7 05 70 d9 05 00 	movq   $0x0,0x5d970(%rip)        # 6c820 <fwp_cur>
    eeac:	00 00 00 00 
    eeb0:	48 8b 05 a9 ed 05 00 	mov    0x5eda9(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    eeb7:	48 c7 05 56 d9 05 00 	movq   $0x0,0x5d956(%rip)        # 6c818 <fwp_root>
    eebe:	00 00 00 00 
    eec2:	c7 05 3c f6 05 00 00 	movl   $0x0,0x5f63c(%rip)        # 6e508 <iteration_active>
    eec9:	00 00 00 
    eecc:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    eed0:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    eed5:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    eed9:	66 0f d6 05 37 52 01 	movq   %xmm0,0x15237(%rip)        # 24118 <ad_raw_before_shutdown>
    eee0:	00 
    eee1:	48 85 c0             	test   %rax,%rax
    eee4:	0f 88 26 01 00 00    	js     f010 <fwp_main_thread+0x730>
    eeea:	66 0f ef c9          	pxor   %xmm1,%xmm1
    eeee:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    eef3:	f2 0f 5c 0d ed f5 05 	subsd  0x5f5ed(%rip),%xmm1        # 6e4e8 <iteration_start_charge>
    eefa:	00 
    eefb:	48 8b 3d 5e 51 00 00 	mov    0x515e(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    ef02:	48 8d 15 57 1c 00 00 	lea    0x1c57(%rip),%rdx        # 10b60 <_IO_stdin_used+0xb60>
    ef09:	be 02 00 00 00       	mov    $0x2,%esi
    ef0e:	f2 0f 10 05 ca f5 05 	movsd  0x5f5ca(%rip),%xmm0        # 6e4e0 <iteration_peak>
    ef15:	00 
    ef16:	4c 8b 0d d3 f5 05 00 	mov    0x5f5d3(%rip),%r9        # 6e4f0 <iteration_retains>
    ef1d:	b8 02 00 00 00       	mov    $0x2,%eax
    ef22:	4c 8b 05 cf f5 05 00 	mov    0x5f5cf(%rip),%r8        # 6e4f8 <iteration_bytes>
    ef29:	48 8b 0d d0 f5 05 00 	mov    0x5f5d0(%rip),%rcx        # 6e500 <iteration_requests>
    ef30:	e8 3b 47 ff ff       	call   3670 <__fprintf_chk@plt>
    ef35:	48 8b 3d 04 51 00 00 	mov    0x5104(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    ef3c:	e8 5f 46 ff ff       	call   35a0 <fflush@plt>
    ef41:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    ef48:	00 
    ef49:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ef50:	00 00 
    ef52:	0f 85 90 01 00 00    	jne    f0e8 <fwp_main_thread+0x808>
    ef58:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    ef5f:	31 c0                	xor    %eax,%eax
    ef61:	5b                   	pop    %rbx
    ef62:	5d                   	pop    %rbp
    ef63:	41 5c                	pop    %r12
    ef65:	c3                   	ret
    ef66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ef6d:	00 00 00 
    ef70:	48 89 05 81 d8 05 00 	mov    %rax,0x5d881(%rip)        # 6c7f8 <fwp_timers>
    ef77:	e9 e0 fb ff ff       	jmp    eb5c <fwp_main_thread+0x27c>
    ef7c:	0f 1f 40 00          	nopl   0x0(%rax)
    ef80:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    ef84:	0f 85 d6 fc ff ff    	jne    ec60 <fwp_main_thread+0x380>
    ef8a:	48 89 ef             	mov    %rbp,%rdi
    ef8d:	e8 9e 51 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    ef92:	e9 c9 fc ff ff       	jmp    ec60 <fwp_main_thread+0x380>
    ef97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ef9e:	00 00 
    efa0:	31 db                	xor    %ebx,%ebx
    efa2:	48 83 3d fe f4 05 00 	cmpq   $0x0,0x5f4fe(%rip)        # 6e4a8 <fwp_state_owners>
    efa9:	00 
    efaa:	0f 85 e7 fb ff ff    	jne    eb97 <fwp_main_thread+0x2b7>
    efb0:	48 8b 3d 09 f5 05 00 	mov    0x5f509(%rip),%rdi        # 6e4c0 <fwp_state>
    efb7:	e8 54 6a ff ff       	call   5a10 <fwp_mem_free>
    efbc:	48 c7 05 f9 f4 05 00 	movq   $0x0,0x5f4f9(%rip)        # 6e4c0 <fwp_state>
    efc3:	00 00 00 00 
    efc7:	48 c7 05 de f4 05 00 	movq   $0x0,0x5f4de(%rip)        # 6e4b0 <fwp_state_cap>
    efce:	00 00 00 00 
    efd2:	48 85 db             	test   %rbx,%rbx
    efd5:	0f 84 ce 00 00 00    	je     f0a9 <fwp_main_thread+0x7c9>
    efdb:	48 39 1d 36 d8 05 00 	cmp    %rbx,0x5d836(%rip)        # 6c818 <fwp_root>
    efe2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    efe9:	00 00 00 00 
    efed:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    eff4:	00 00 00 00 
    eff8:	c7 05 9e 50 01 00 00 	movl   $0x0,0x1509e(%rip)        # 240a0 <fwp_exit_code>
    efff:	00 00 00 
    f002:	0f 84 af fb ff ff    	je     ebb7 <fwp_main_thread+0x2d7>
    f008:	e9 43 47 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f00d:	0f 1f 00             	nopl   (%rax)
    f010:	48 89 c2             	mov    %rax,%rdx
    f013:	83 e0 01             	and    $0x1,%eax
    f016:	66 0f ef c9          	pxor   %xmm1,%xmm1
    f01a:	48 d1 ea             	shr    $1,%rdx
    f01d:	48 09 c2             	or     %rax,%rdx
    f020:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    f025:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    f029:	e9 c5 fe ff ff       	jmp    eef3 <fwp_main_thread+0x613>
    f02e:	66 90                	xchg   %ax,%ax
    f030:	48 89 c2             	mov    %rax,%rdx
    f033:	83 e0 01             	and    $0x1,%eax
    f036:	66 0f ef c0          	pxor   %xmm0,%xmm0
    f03a:	48 d1 ea             	shr    $1,%rdx
    f03d:	48 09 c2             	or     %rax,%rdx
    f040:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    f045:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    f049:	e9 9b f9 ff ff       	jmp    e9e9 <fwp_main_thread+0x109>
    f04e:	66 90                	xchg   %ax,%ax
    f050:	48 8d 3d 69 5c ff ff 	lea    -0xa397(%rip),%rdi        # 4cc0 <fwp_heap_report>
    f057:	e8 b4 02 00 00       	call   f310 <atexit>
    f05c:	e9 bd f8 ff ff       	jmp    e91e <fwp_main_thread+0x3e>
    f061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    f068:	e8 63 5d ff ff       	call   4dd0 <fwp_heap_init>
    f06d:	e9 9e f8 ff ff       	jmp    e910 <fwp_main_thread+0x30>
    f072:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    f078:	e8 63 cb ff ff       	call   bbe0 <f0>
    f07d:	48 c7 05 00 50 00 00 	movq   $0x0,0x5000(%rip)        # 14088 <v.2>
    f084:	00 00 00 00 
    f088:	c7 05 fe 4f 00 00 01 	movl   $0x1,0x4ffe(%rip)        # 14090 <st.3>
    f08f:	00 00 00 
    f092:	e9 86 f9 ff ff       	jmp    ea1d <fwp_main_thread+0x13d>
    f097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    f09e:	00 00 
    f0a0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    f0a4:	e9 28 fa ff ff       	jmp    ead1 <fwp_main_thread+0x1f1>
    f0a9:	48 83 3d 67 d7 05 00 	cmpq   $0x0,0x5d767(%rip)        # 6c818 <fwp_root>
    f0b0:	00 
    f0b1:	c7 05 e5 4f 01 00 00 	movl   $0x0,0x14fe5(%rip)        # 240a0 <fwp_exit_code>
    f0b8:	00 00 00 
    f0bb:	0f 84 95 fc ff ff    	je     ed56 <fwp_main_thread+0x476>
    f0c1:	e9 8a 46 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f0c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f0cd:	00 00 00 
    f0d0:	48 8d 3d 61 1a 00 00 	lea    0x1a61(%rip),%rdi        # 10b38 <_IO_stdin_used+0xb38>
    f0d7:	e8 74 53 ff ff       	call   4450 <fwp_trap>
    f0dc:	48 8d 3d f0 11 00 00 	lea    0x11f0(%rip),%rdi        # 102d3 <_IO_stdin_used+0x2d3>
    f0e3:	e8 18 4f ff ff       	call   4000 <ad_raw_fail>
    f0e8:	e8 63 43 ff ff       	call   3450 <__stack_chk_fail@plt>
    f0ed:	48 89 c8             	mov    %rcx,%rax
    f0f0:	e9 a4 fb ff ff       	jmp    ec99 <fwp_main_thread+0x3b9>
    f0f5:	e9 56 46 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f0fa:	e9 51 46 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f0ff:	90                   	nop

000000000000f100 <__divmodti4>:
    f100:	f3 0f 1e fa          	endbr64
    f104:	55                   	push   %rbp
    f105:	49 89 f1             	mov    %rsi,%r9
    f108:	49 89 d2             	mov    %rdx,%r10
    f10b:	48 89 fe             	mov    %rdi,%rsi
    f10e:	49 89 cb             	mov    %rcx,%r11
    f111:	48 89 e5             	mov    %rsp,%rbp
    f114:	41 57                	push   %r15
    f116:	41 56                	push   %r14
    f118:	41 55                	push   %r13
    f11a:	41 54                	push   %r12
    f11c:	53                   	push   %rbx
    f11d:	4c 89 c3             	mov    %r8,%rbx
    f120:	45 31 c0             	xor    %r8d,%r8d
    f123:	4d 85 c9             	test   %r9,%r9
    f126:	79 12                	jns    f13a <__divmodti4+0x3a>
    f128:	31 ff                	xor    %edi,%edi
    f12a:	48 f7 de             	neg    %rsi
    f12d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    f134:	4c 19 cf             	sbb    %r9,%rdi
    f137:	49 89 f9             	mov    %rdi,%r9
    f13a:	4c 89 d8             	mov    %r11,%rax
    f13d:	4d 85 db             	test   %r11,%r11
    f140:	0f 88 1a 01 00 00    	js     f260 <__divmodti4+0x160>
    f146:	4c 89 d9             	mov    %r11,%rcx
    f149:	49 89 f3             	mov    %rsi,%r11
    f14c:	75 62                	jne    f1b0 <__divmodti4+0xb0>
    f14e:	4d 89 c4             	mov    %r8,%r12
    f151:	4d 39 d1             	cmp    %r10,%r9
    f154:	0f 83 46 01 00 00    	jae    f2a0 <__divmodti4+0x1a0>
    f15a:	4c 89 d8             	mov    %r11,%rax
    f15d:	4c 89 ca             	mov    %r9,%rdx
    f160:	49 f7 f2             	div    %r10
    f163:	49 89 c3             	mov    %rax,%r11
    f166:	31 c0                	xor    %eax,%eax
    f168:	48 89 d6             	mov    %rdx,%rsi
    f16b:	31 ff                	xor    %edi,%edi
    f16d:	4c 89 d9             	mov    %r11,%rcx
    f170:	48 89 c2             	mov    %rax,%rdx
    f173:	48 89 c8             	mov    %rcx,%rax
    f176:	4d 85 e4             	test   %r12,%r12
    f179:	74 0a                	je     f185 <__divmodti4+0x85>
    f17b:	48 f7 d8             	neg    %rax
    f17e:	48 83 d2 00          	adc    $0x0,%rdx
    f182:	48 f7 da             	neg    %rdx
    f185:	4d 85 c0             	test   %r8,%r8
    f188:	74 0a                	je     f194 <__divmodti4+0x94>
    f18a:	48 f7 de             	neg    %rsi
    f18d:	48 83 d7 00          	adc    $0x0,%rdi
    f191:	48 f7 df             	neg    %rdi
    f194:	48 89 33             	mov    %rsi,(%rbx)
    f197:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    f19b:	5b                   	pop    %rbx
    f19c:	41 5c                	pop    %r12
    f19e:	41 5d                	pop    %r13
    f1a0:	41 5e                	pop    %r14
    f1a2:	41 5f                	pop    %r15
    f1a4:	5d                   	pop    %rbp
    f1a5:	c3                   	ret
    f1a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f1ad:	00 00 00 
    f1b0:	4d 89 c4             	mov    %r8,%r12
    f1b3:	49 39 c1             	cmp    %rax,%r9
    f1b6:	0f 82 ce 00 00 00    	jb     f28a <__divmodti4+0x18a>
    f1bc:	31 ff                	xor    %edi,%edi
    f1be:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    f1c3:	48 63 c7             	movslq %edi,%rax
    f1c6:	be 40 00 00 00       	mov    $0x40,%esi
    f1cb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    f1d0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    f1d5:	48 29 c6             	sub    %rax,%rsi
    f1d8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    f1dd:	48 09 c8             	or     %rcx,%rax
    f1e0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    f1e5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    f1ea:	49 89 c6             	mov    %rax,%r14
    f1ed:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    f1f1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    f1f6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    f1fb:	49 09 c1             	or     %rax,%r9
    f1fe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    f202:	4c 89 c8             	mov    %r9,%rax
    f205:	49 f7 f6             	div    %r14
    f208:	48 89 d1             	mov    %rdx,%rcx
    f20b:	49 89 c3             	mov    %rax,%r11
    f20e:	49 89 c1             	mov    %rax,%r9
    f211:	49 f7 e2             	mul    %r10
    f214:	49 89 c6             	mov    %rax,%r14
    f217:	49 89 d2             	mov    %rdx,%r10
    f21a:	48 39 d1             	cmp    %rdx,%rcx
    f21d:	72 07                	jb     f226 <__divmodti4+0x126>
    f21f:	75 17                	jne    f238 <__divmodti4+0x138>
    f221:	49 39 c7             	cmp    %rax,%r15
    f224:	73 12                	jae    f238 <__divmodti4+0x138>
    f226:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    f22a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    f22e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    f232:	49 89 d2             	mov    %rdx,%r10
    f235:	49 89 c6             	mov    %rax,%r14
    f238:	4c 89 f8             	mov    %r15,%rax
    f23b:	4c 29 f0             	sub    %r14,%rax
    f23e:	4c 19 d1             	sbb    %r10,%rcx
    f241:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    f246:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    f24b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    f250:	48 09 c6             	or     %rax,%rsi
    f253:	48 89 cf             	mov    %rcx,%rdi
    f256:	31 c0                	xor    %eax,%eax
    f258:	4c 89 c9             	mov    %r9,%rcx
    f25b:	e9 10 ff ff ff       	jmp    f170 <__divmodti4+0x70>
    f260:	4c 89 d0             	mov    %r10,%rax
    f263:	4c 89 da             	mov    %r11,%rdx
    f266:	4d 89 c4             	mov    %r8,%r12
    f269:	49 89 f3             	mov    %rsi,%r11
    f26c:	48 f7 d8             	neg    %rax
    f26f:	49 f7 d4             	not    %r12
    f272:	48 83 d2 00          	adc    $0x0,%rdx
    f276:	49 89 c2             	mov    %rax,%r10
    f279:	48 f7 da             	neg    %rdx
    f27c:	48 89 d1             	mov    %rdx,%rcx
    f27f:	0f 84 cc fe ff ff    	je     f151 <__divmodti4+0x51>
    f285:	49 39 d1             	cmp    %rdx,%r9
    f288:	73 46                	jae    f2d0 <__divmodti4+0x1d0>
    f28a:	4c 89 cf             	mov    %r9,%rdi
    f28d:	31 c0                	xor    %eax,%eax
    f28f:	31 c9                	xor    %ecx,%ecx
    f291:	e9 da fe ff ff       	jmp    f170 <__divmodti4+0x70>
    f296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f29d:	00 00 00 
    f2a0:	4d 85 d2             	test   %r10,%r10
    f2a3:	75 0d                	jne    f2b2 <__divmodti4+0x1b2>
    f2a5:	b8 01 00 00 00       	mov    $0x1,%eax
    f2aa:	31 d2                	xor    %edx,%edx
    f2ac:	49 f7 f2             	div    %r10
    f2af:	49 89 c2             	mov    %rax,%r10
    f2b2:	4c 89 c8             	mov    %r9,%rax
    f2b5:	31 d2                	xor    %edx,%edx
    f2b7:	49 f7 f2             	div    %r10
    f2ba:	49 89 c1             	mov    %rax,%r9
    f2bd:	4c 89 d8             	mov    %r11,%rax
    f2c0:	49 f7 f2             	div    %r10
    f2c3:	49 89 c3             	mov    %rax,%r11
    f2c6:	4c 89 c8             	mov    %r9,%rax
    f2c9:	e9 9a fe ff ff       	jmp    f168 <__divmodti4+0x68>
    f2ce:	66 90                	xchg   %ax,%ax
    f2d0:	45 31 f6             	xor    %r14d,%r14d
    f2d3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    f2d8:	44 89 f7             	mov    %r14d,%edi
    f2db:	45 85 f6             	test   %r14d,%r14d
    f2de:	0f 85 df fe ff ff    	jne    f1c3 <__divmodti4+0xc3>
    f2e4:	4c 39 ca             	cmp    %r9,%rdx
    f2e7:	72 17                	jb     f300 <__divmodti4+0x200>
    f2e9:	31 c9                	xor    %ecx,%ecx
    f2eb:	48 39 c6             	cmp    %rax,%rsi
    f2ee:	73 10                	jae    f300 <__divmodti4+0x200>
    f2f0:	4c 89 cf             	mov    %r9,%rdi
    f2f3:	31 c0                	xor    %eax,%eax
    f2f5:	e9 76 fe ff ff       	jmp    f170 <__divmodti4+0x70>
    f2fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    f300:	4c 89 de             	mov    %r11,%rsi
    f303:	b9 01 00 00 00       	mov    $0x1,%ecx
    f308:	48 29 c6             	sub    %rax,%rsi
    f30b:	49 19 d1             	sbb    %rdx,%r9
    f30e:	eb e0                	jmp    f2f0 <__divmodti4+0x1f0>

000000000000f310 <atexit>:
    f310:	f3 0f 1e fa          	endbr64
    f314:	48 8b 15 ed 4c 00 00 	mov    0x4ced(%rip),%rdx        # 14008 <__dso_handle>
    f31b:	31 f6                	xor    %esi,%esi
    f31d:	e9 1e 43 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000f324 <_fini>:
    f324:	f3 0f 1e fa          	endbr64
    f328:	48 83 ec 08          	sub    $0x8,%rsp
    f32c:	48 83 c4 08          	add    $0x8,%rsp
    f330:	c3                   	ret
