
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 dc 00 00 	lea    0xdce1(%rip),%rax        # 11460 <fwp_fn_table>
    377f:	48 89 05 b2 1c 02 00 	mov    %rax,0x21cb2(%rip)        # 25438 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ac 1c 02 00 	mov    %rax,0x21cac(%rip)        # 25440 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 7f a9 00 00 	lea    0xa97f(%rip),%rdx        # e1e0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e c1 00 00 	lea    0xc17e(%rip),%rdi        # fa88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 c1 00 00 	lea    0xc138(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc c0 00 00 	lea    0xc0fc(%rip),%rdi        # fa30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 c0 00 00 	lea    0xc0c8(%rip),%rdi        # fa08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee f4 01 00 	add    0x1f4ee(%rip),%rdx        # 23110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc f4 01 00 	add    0x1f4dc(%rip),%rax        # 23110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d c9 17 02 00 	mov    0x217c9(%rip),%rdi        # 25440 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 c1 fa 01 00 	mov    0x1fac1(%rip),%rax        # 237c0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 f9 f3 01 00 	mov    0x1f3f9(%rip),%rax        # 23178 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 e5 f3 01 00 	sub    0x1f3e5(%rip),%rax        # 23170 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f b8 00 00 	lea    0xb87f(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 62 f2 00 00 	mov    0xf262(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d ed f1 00 00 ff 	cmpl   $0xffffffff,0xf1ed(%rip)        # 13020 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d e1 f2 01 00 	mov    0x1f2e1(%rip),%r9        # 23128 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 bc f2 01 00 	mov    0x1f2bc(%rip),%r8        # 23120 <descent_inputs>
    3e64:	48 8b 0d c5 f2 01 00 	mov    0x1f2c5(%rip),%rcx        # 23130 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d e2 f1 00 00 	mov    0xf1e2(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 b8 00 00 	lea    0xb818(%rip),%rdx        # f6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 91 f2 01 00 	lea    0x1f291(%rip),%r12        # 23140 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 7b f1 00 00 	mov    0xf17b(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 40 f1 00 00 	mov    0xf140(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d 19 f1 00 00 	mov    0xf119(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 3b 0c 02 00 	mov    0x20c3b(%rip),%rax        # 24bd0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 34 0c 02 00 	lea    0x20c34(%rip),%r8        # 24bd0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 15 0c 02 00 	mov    0x20c15(%rip),%rbx        # 24bb8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 25 0c 02 00 	mov    0x20c25(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d c1 0b 02 00 	mov    0x20bc1(%rip),%rdi        # 24bc0 <fwp_heap+0x13e0>
    3fff:	48 29 35 0a 0c 02 00 	sub    %rsi,0x20c0a(%rip)        # 24c10 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 9a 0b 02 00 	mov    0x20b9a(%rip),%rax        # 24bb0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 50 0b 02 00 	add    0x20b50(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 5e 0b 02 00 	mov    0x20b5e(%rip),%rsi        # 24bc0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 6c 0b 02 00 	mov    0x20b6c(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 1b 0b 02 00 	mov    %r12,0x20b1b(%rip)        # 24bc0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 09 0b 02 00 	mov    %rbp,0x20b09(%rip)        # 24bb8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ee 0a 02 00 	cmp    %rdi,0x20aee(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d e5 0a 02 00 	mov    %rdi,0x20ae5(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 29 0b 02 00 	sub    %rdi,0x20b29(%rip)        # 24c10 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 d1 0a 02 00 	mov    0x20ad1(%rip),%rax        # 24bc8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ca 0a 02 00 	lea    0x20aca(%rip),%r8        # 24bc8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 7d ee 00 00 	mov    0xee7d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d b5 ed 00 00 	movslq 0xedb5(%rip),%rbp        # 13020 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 9a ee 01 00 	mov    0x1ee9a(%rip),%rsi        # 23138 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 96 ee 01 00 	lea    0x1ee96(%rip),%rcx        # 23140 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 6b ee 01 00 	addq   $0x1,0x1ee6b(%rip)        # 23130 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 50 ed 00 00    	mov    %ebx,0xed50(%rip)        # 13020 <descent_active_phase>
    42d0:	48 89 05 61 ee 01 00 	mov    %rax,0x1ee61(%rip)        # 23138 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d b9 f4 01 00 	cmp    0x1f4b9(%rip),%rdi        # 237c0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 7f f4 01 00 	mov    0x1f47f(%rip),%rax        # 237a0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 5d f4 01 00 	mov    %rdi,0x1f45d(%rip)        # 237a0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 39 f4 01 00 	mov    %rdi,0x1f439(%rip)        # 237a8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 ae 00 00 	lea    0xae18(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 48 ec 00 00 	mov    0xec48(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 30 ec 00 00 	mov    0xec30(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 41 eb 00 00 	mov    0xeb41(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 b1 00 00 	lea    0xb110(%rip),%rdi        # f700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 b5 00 	movdqa 0xb580(%rip),%xmm0        # fb90 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ca 0d 02 00 	add    0x20dca(%rip),%rax        # 25438 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 b0 00 00 	lea    0xb064(%rip),%rdi        # f728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 25 ea 01 00 	cmp    %rax,0x1ea25(%rip)        # 23108 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 20 ea 01 00 	add    0x1ea20(%rip),%rax        # 23110 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d b0 00 00 	lea    0xb04d(%rip),%rdi        # f758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e a5 00 00 	lea    0xa57e(%rip),%rsi        # f20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d a5 fe 01 00 	mov    0x1fea5(%rip),%r9        # 24ba8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 fe fe 01 00 	mov    0x1fefe(%rip),%r8        # 24c08 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 aa 00 00 	lea    0xaa97(%rip),%rdx        # f7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d e6 fe 01 00 	mov    0x1fee6(%rip),%rcx        # 24c00 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d f4 fe 01 	movsd  0x1fef4(%rip),%xmm1        # 24c20 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 e4 fe 01 	movsd  0x1fee4(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 25 e3 00 00 	mov    0xe325(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 ae 00 	movdqa 0xae28(%rip),%xmm0        # fba0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 9f f9 01 00 	lea    0x1f99f(%rip),%rax        # 24720 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 ae 00 	movdqa 0xae51(%rip),%xmm2        # fbe0 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 45 f9 01 00 	movaps %xmm0,0x1f945(%rip)        # 246e0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d ae 00 	movdqa 0xae0d(%rip),%xmm0        # fbb0 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 d3 fd 01 00 01 	movl   $0x1,0x1fdd3(%rip)        # 24b84 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 33 f9 01 00 	movaps %xmm0,0x1f933(%rip)        # 246f0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb ad 00 	movdqa 0xadfb(%rip),%xmm0        # fbc0 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 34 f9 01 00 	movaps %xmm0,0x1f934(%rip)        # 24700 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc ad 00 	movdqa 0xadfc(%rip),%xmm0        # fbd0 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 35 f9 01 00 	movaps %xmm0,0x1f935(%rip)        # 24710 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 b5 e9 01 00 	lea    0x1e9b5(%rip),%r8        # 237e0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 d0 fc 01 00 	mov    %rax,0x1fcd0(%rip)        # 24b98 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ae fc 01 00 	mov    %r12,0x1fcae(%rip)        # 24ba0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 97 fc 01 00 	mov    %rax,0x1fc97(%rip)        # 24b90 <fwp_heap+0x13b0>
    4ef9:	48 89 1d b0 fc 01 00 	mov    %rbx,0x1fcb0(%rip)        # 24bb0 <fwp_heap+0x13d0>
    4f00:	48 89 35 d9 fc 01 00 	mov    %rsi,0x1fcd9(%rip)        # 24be0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 b8 fc 01 00 	mov    %rax,0x1fcb8(%rip)        # 24bd8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 3c fc 01 00    	mov    %eax,0x1fc3c(%rip)        # 24b88 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 2c e8 01 00 	mov    0x1e82c(%rip),%r8        # 237a0 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 5c e7 01 00 	mov    %rbx,0x1e75c(%rip)        # 237a8 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 48 e7 01 00 	mov    %r8,0x1e748(%rip)        # 237a0 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c a0 00 00 	lea    0xa05c(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d bd df 01 00 	lea    0x1dfbd(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 a5 df 01 00 	movaps %xmm0,0x1dfa5(%rip)        # 230c0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 81 df 01 00 	mov    %rax,0x1df81(%rip)        # 230a8 <fwp_tape_cached_bytes>
    5127:	0f 29 05 a2 df 01 00 	movaps %xmm0,0x1dfa2(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 a6 df 01 00 	movaps %xmm0,0x1dfa6(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 a7 df 01 00 	mov    %rdx,0x1dfa7(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 9f 00 00 	lea    0x9fb3(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d d7 e5 01 00 	mov    0x1e5d7(%rip),%rbx        # 23798 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d aa dd 00 00 	mov    0xddaa(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 73 a5 00 00 	lea    0xa573(%rip),%rdi        # f830 <_IO_stdin_used+0x830>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 ad e4 01 00 	mov    0x1e4ad(%rip),%rax        # 237a0 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 87 e4 01 00 	mov    %rdx,0x1e487(%rip)        # 237a0 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d d4 e3 01 00 	mov    0x1e3d4(%rip),%rbx        # 23798 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 91 e3 01 00 	mov    %rbx,0x1e391(%rip)        # 23798 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 91 e3 01 00 	mov    %rdx,0x1e391(%rip)        # 237a8 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 a6 e3 01 00 	lea    0x1e3a6(%rip),%rsi        # 237e0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 25 ff 01 00 	addq   $0x1,0x1ff25(%rip)        # 25428 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 47 a3 00 00 	lea    0xa347(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 58 a3 00 00 	lea    0xa358(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 9b 00 00 	lea    0x9bf7(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 5e e2 01 00 	lea    0x1e25e(%rip),%rcx        # 237e0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 5f fe 01 00 	subq   $0x1,0x1fe5f(%rip)        # 25428 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d b3 a2 00 00 	lea    0xa2b3(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 40 fe 01 00 	cmpq   $0x0,0x1fe40(%rip)        # 25428 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 95 fd 01 00 	sub    %rax,0x1fd95(%rip)        # 25430 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 73 fd 01 00 	add    %r12,0x1fd73(%rip)        # 25430 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 cf f4 01 00 	mov    0x1f4cf(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 cc e0 01 00 	lea    0x1e0cc(%rip),%rax        # 237e0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 23 f4 01 00 	add    0x1f423(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 f0 f3 01 00 	mov    0x1f3f0(%rip),%rsi        # 24b90 <fwp_heap+0x13b0>
    57a0:	48 8b 05 11 f4 01 00 	mov    0x1f411(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 05 f4 01 00 	add    0x1f405(%rip),%r8        # 24bd8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 cd f3 01 	addsd  0x1f3cd(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 82 df 01 00 	lea    0x1df82(%rip),%rax        # 237e0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 8c f3 01 00 	sub    %rdi,0x1f38c(%rip)        # 24c00 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 a4 f3 01 	movsd  %xmm0,0x1f3a4(%rip)        # 24c20 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 5e f3 01 00 	sub    %rdx,0x1f35e(%rip)        # 24c00 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 64 f3 01 	addsd  0x1f364(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 58 f3 01 	movsd  %xmm0,0x1f358(%rip)        # 24c20 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 ef f2 01 00 	mov    0x1f2ef(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d e9 f2 01 00 	add    %rcx,0x1f2e9(%rip)        # 24c10 <fwp_heap+0x1430>
    5927:	4c 3b 0d a2 f2 01 00 	cmp    0x1f2a2(%rip),%r9        # 24bd0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 99 f2 01 00 	mov    %r9,0x1f299(%rip)        # 24bd0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 8a f2 01 00 	cmp    0x1f28a(%rip),%r9        # 24bc8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 7d f2 01 00 	mov    %r9,0x1f27d(%rip)        # 24bc8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 93 f1 01 00 	add    0x1f193(%rip),%rdi        # 24bd8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 70 dd 01 00 	lea    0x1dd70(%rip),%r15        # 237e0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 e0 f0 01 00 	add    0x1f0e0(%rip),%r12        # 24b90 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 39 f1 01 00 	add    0x1f139(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 38 f1 01 00 	cmp    %rax,0x1f138(%rip)        # 24c08 <fwp_heap+0x1428>
    5ad0:	48 89 05 29 f1 01 00 	mov    %rax,0x1f129(%rip)        # 24c00 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 28 f1 01 00 	mov    %rax,0x1f128(%rip)        # 24c08 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 24 f1 01 	addsd  0x1f124(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 1c f1 01 	movsd  %xmm0,0x1f11c(%rip)        # 24c18 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 63 f0 01 00    	mov    0x1f063(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 9f dc 01 00 	lea    0x1dc9f(%rip),%rdi        # 237e0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 58 f0 01 00 	add    0x1f058(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 53 f0 01 00 	cmp    %rax,0x1f053(%rip)        # 24c08 <fwp_heap+0x1428>
    5bb5:	48 89 05 44 f0 01 00 	mov    %rax,0x1f044(%rip)        # 24c00 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 43 f0 01 00 	mov    %rax,0x1f043(%rip)        # 24c08 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 3f f0 01 	addsd  0x1f03f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 37 f0 01 	movsd  %xmm0,0x1f037(%rip)        # 24c18 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ee ee 01 00    	mov    0x1eeee(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 25 db 01 00 	lea    0x1db25(%rip),%rax        # 237e0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 db ee 01 00 	add    0x1eedb(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 da ee 01 00 	cmp    %rax,0x1eeda(%rip)        # 24c08 <fwp_heap+0x1428>
    5d2e:	48 89 05 cb ee 01 00 	mov    %rax,0x1eecb(%rip)        # 24c00 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 ca ee 01 00 	mov    %rax,0x1eeca(%rip)        # 24c08 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 c6 ee 01 	addsd  0x1eec6(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 be ee 01 	movsd  %xmm0,0x1eebe(%rip)        # 24c18 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_apply>:
    5db0:	55                   	push   %rbp
    5db1:	48 89 f9             	mov    %rdi,%rcx
    5db4:	48 89 e5             	mov    %rsp,%rbp
    5db7:	41 57                	push   %r15
    5db9:	41 56                	push   %r14
    5dbb:	41 55                	push   %r13
    5dbd:	41 89 f5             	mov    %esi,%r13d
    5dc0:	41 54                	push   %r12
    5dc2:	53                   	push   %rbx
    5dc3:	48 83 ec 28          	sub    $0x28,%rsp
    5dc7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5dce:	00 00 
    5dd0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5dd4:	49 89 d6             	mov    %rdx,%r14
    5dd7:	44 8b 09             	mov    (%rcx),%r9d
    5dda:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5dde:	49 89 e0             	mov    %rsp,%r8
    5de1:	49 c1 e1 05          	shl    $0x5,%r9
    5de5:	4c 03 0d 4c f6 01 00 	add    0x1f64c(%rip),%r9        # 25438 <fwp_fns>
    5dec:	41 8b 19             	mov    (%r9),%ebx
    5def:	45 85 e4             	test   %r12d,%r12d
    5df2:	75 2c                	jne    5e20 <fwp_apply+0x70>
    5df4:	41 39 dd             	cmp    %ebx,%r13d
    5df7:	72 27                	jb     5e20 <fwp_apply+0x70>
    5df9:	85 db                	test   %ebx,%ebx
    5dfb:	0f 84 a7 01 00 00    	je     5fa8 <fwp_apply+0x1f8>
    5e01:	4c 89 f7             	mov    %r14,%rdi
    5e04:	41 ff 51 08          	call   *0x8(%r9)
    5e08:	48 89 c1             	mov    %rax,%rcx
    5e0b:	41 39 dd             	cmp    %ebx,%r13d
    5e0e:	0f 84 6c 01 00 00    	je     5f80 <fwp_apply+0x1d0>
    5e14:	89 d8                	mov    %ebx,%eax
    5e16:	41 29 dd             	sub    %ebx,%r13d
    5e19:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e1d:	eb b8                	jmp    5dd7 <fwp_apply+0x27>
    5e1f:	90                   	nop
    5e20:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e25:	41 39 df             	cmp    %ebx,%r15d
    5e28:	0f 82 cc 00 00 00    	jb     5efa <fwp_apply+0x14a>
    5e2e:	41 89 df             	mov    %ebx,%r15d
    5e31:	b8 01 00 00 00       	mov    $0x1,%eax
    5e36:	48 89 e2             	mov    %rsp,%rdx
    5e39:	45 29 e7             	sub    %r12d,%r15d
    5e3c:	85 db                	test   %ebx,%ebx
    5e3e:	0f 45 c3             	cmovne %ebx,%eax
    5e41:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5e48:	00 
    5e49:	48 c1 e8 04          	shr    $0x4,%rax
    5e4d:	48 c1 e0 04          	shl    $0x4,%rax
    5e51:	48 89 c6             	mov    %rax,%rsi
    5e54:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5e5b:	48 29 f2             	sub    %rsi,%rdx
    5e5e:	48 39 d4             	cmp    %rdx,%rsp
    5e61:	74 15                	je     5e78 <fwp_apply+0xc8>
    5e63:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5e6a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5e71:	00 00 
    5e73:	48 39 d4             	cmp    %rdx,%rsp
    5e76:	75 eb                	jne    5e63 <fwp_apply+0xb3>
    5e78:	25 ff 0f 00 00       	and    $0xfff,%eax
    5e7d:	48 29 c4             	sub    %rax,%rsp
    5e80:	48 85 c0             	test   %rax,%rax
    5e83:	0f 85 49 01 00 00    	jne    5fd2 <fwp_apply+0x222>
    5e89:	45 89 e2             	mov    %r12d,%r10d
    5e8c:	48 89 e6             	mov    %rsp,%rsi
    5e8f:	48 89 e7             	mov    %rsp,%rdi
    5e92:	31 c0                	xor    %eax,%eax
    5e94:	49 c1 e2 03          	shl    $0x3,%r10
    5e98:	45 85 e4             	test   %r12d,%r12d
    5e9b:	74 15                	je     5eb2 <fwp_apply+0x102>
    5e9d:	0f 1f 00             	nopl   (%rax)
    5ea0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5ea5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5ea9:	48 83 c0 08          	add    $0x8,%rax
    5ead:	4c 39 d0             	cmp    %r10,%rax
    5eb0:	75 ee                	jne    5ea0 <fwp_apply+0xf0>
    5eb2:	45 85 ff             	test   %r15d,%r15d
    5eb5:	0f 84 f4 00 00 00    	je     5faf <fwp_apply+0x1ff>
    5ebb:	44 89 fa             	mov    %r15d,%edx
    5ebe:	4c 89 f0             	mov    %r14,%rax
    5ec1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ec5:	44 89 e2             	mov    %r12d,%edx
    5ec8:	66 90                	xchg   %ax,%ax
    5eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ed1:	00 00 00 00 
    5ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5edc:	00 00 00 00 
    5ee0:	4c 8b 10             	mov    (%rax),%r10
    5ee3:	89 d1                	mov    %edx,%ecx
    5ee5:	48 83 c0 08          	add    $0x8,%rax
    5ee9:	83 c2 01             	add    $0x1,%edx
    5eec:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5ef0:	4c 39 d8             	cmp    %r11,%rax
    5ef3:	75 eb                	jne    5ee0 <fwp_apply+0x130>
    5ef5:	e9 b5 00 00 00       	jmp    5faf <fwp_apply+0x1ff>
    5efa:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5efe:	be 02 00 00 00       	mov    $0x2,%esi
    5f03:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f07:	48 c1 e7 03          	shl    $0x3,%rdi
    5f0b:	e8 80 fd ff ff       	call   5c90 <fwp_heap_alloc>
    5f10:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f14:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f19:	48 89 c3             	mov    %rax,%rbx
    5f1c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f20:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f24:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f28:	45 85 e4             	test   %r12d,%r12d
    5f2b:	74 14                	je     5f41 <fwp_apply+0x191>
    5f2d:	44 89 e2             	mov    %r12d,%edx
    5f30:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f34:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f38:	48 c1 e2 03          	shl    $0x3,%rdx
    5f3c:	e8 cf d6 ff ff       	call   3610 <memmove@plt>
    5f41:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5f45:	45 85 ed             	test   %r13d,%r13d
    5f48:	74 2e                	je     5f78 <fwp_apply+0x1c8>
    5f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f51:	00 00 00 00 
    5f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f5c:	00 00 00 00 
    5f60:	49 8b 16             	mov    (%r14),%rdx
    5f63:	44 89 e0             	mov    %r12d,%eax
    5f66:	49 83 c6 08          	add    $0x8,%r14
    5f6a:	41 83 c4 01          	add    $0x1,%r12d
    5f6e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5f73:	49 39 ce             	cmp    %rcx,%r14
    5f76:	75 e8                	jne    5f60 <fwp_apply+0x1b0>
    5f78:	48 89 d9             	mov    %rbx,%rcx
    5f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f80:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5f84:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f8b:	00 00 
    5f8d:	75 4e                	jne    5fdd <fwp_apply+0x22d>
    5f8f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5f93:	48 89 c8             	mov    %rcx,%rax
    5f96:	5b                   	pop    %rbx
    5f97:	41 5c                	pop    %r12
    5f99:	41 5d                	pop    %r13
    5f9b:	41 5e                	pop    %r14
    5f9d:	41 5f                	pop    %r15
    5f9f:	5d                   	pop    %rbp
    5fa0:	c3                   	ret
    5fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fa8:	45 31 ff             	xor    %r15d,%r15d
    5fab:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5faf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5fb3:	41 ff 51 08          	call   *0x8(%r9)
    5fb7:	48 89 c1             	mov    %rax,%rcx
    5fba:	45 39 fd             	cmp    %r15d,%r13d
    5fbd:	74 c1                	je     5f80 <fwp_apply+0x1d0>
    5fbf:	45 01 e5             	add    %r12d,%r13d
    5fc2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5fc6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5fca:	41 29 dd             	sub    %ebx,%r13d
    5fcd:	e9 05 fe ff ff       	jmp    5dd7 <fwp_apply+0x27>
    5fd2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5fd8:	e9 ac fe ff ff       	jmp    5e89 <fwp_apply+0xd9>
    5fdd:	e8 7e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    5fe2:	0f 1f 00             	nopl   (%rax)
    5fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fec:	00 00 00 00 

0000000000005ff0 <fwp_p_ad_push.constprop.0>:
    5ff0:	41 57                	push   %r15
    5ff2:	41 56                	push   %r14
    5ff4:	41 55                	push   %r13
    5ff6:	49 89 d5             	mov    %rdx,%r13
    5ff9:	41 54                	push   %r12
    5ffb:	49 89 fc             	mov    %rdi,%r12
    5ffe:	55                   	push   %rbp
    5fff:	53                   	push   %rbx
    6000:	48 83 ec 38          	sub    $0x38,%rsp
    6004:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6009:	48 85 ff             	test   %rdi,%rdi
    600c:	79 09                	jns    6017 <fwp_p_ad_push.constprop.0+0x27>
    600e:	48 85 d2             	test   %rdx,%rdx
    6011:	0f 88 a9 01 00 00    	js     61c0 <fwp_p_ad_push.constprop.0+0x1d0>
    6017:	48 89 f8             	mov    %rdi,%rax
    601a:	48 89 0c 24          	mov    %rcx,(%rsp)
    601e:	48 09 d0             	or     %rdx,%rax
    6021:	0f 89 79 01 00 00    	jns    61a0 <fwp_p_ad_push.constprop.0+0x1b0>
    6027:	48 89 f8             	mov    %rdi,%rax
    602a:	48 c1 f8 20          	sar    $0x20,%rax
    602e:	48 85 ff             	test   %rdi,%rdi
    6031:	79 24                	jns    6057 <fwp_p_ad_push.constprop.0+0x67>
    6033:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6038:	48 89 d0             	mov    %rdx,%rax
    603b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6042:	00 
    6043:	49 89 d4             	mov    %rdx,%r12
    6046:	48 c1 f8 20          	sar    $0x20,%rax
    604a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6051:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6057:	48 89 c7             	mov    %rax,%rdi
    605a:	e8 71 e6 ff ff       	call   46d0 <fwp_tape_of>
    605f:	48 89 c3             	mov    %rax,%rbx
    6062:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6067:	0f 85 f0 02 00 00    	jne    635d <fwp_p_ad_push.constprop.0+0x36d>
    606d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6071:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6078:	0f 8f 51 02 00 00    	jg     62cf <fwp_p_ad_push.constprop.0+0x2df>
    607e:	44 89 e0             	mov    %r12d,%eax
    6081:	49 39 c7             	cmp    %rax,%r15
    6084:	0f 8e 51 02 00 00    	jle    62db <fwp_p_ad_push.constprop.0+0x2eb>
    608a:	4d 85 ed             	test   %r13,%r13
    608d:	78 0c                	js     609b <fwp_p_ad_push.constprop.0+0xab>
    608f:	44 89 e8             	mov    %r13d,%eax
    6092:	49 39 c7             	cmp    %rax,%r15
    6095:	0f 8e 40 02 00 00    	jle    62db <fwp_p_ad_push.constprop.0+0x2eb>
    609b:	4d 89 fe             	mov    %r15,%r14
    609e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    60a2:	49 8d 46 01          	lea    0x1(%r14),%rax
    60a6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    60ac:	0f 87 1d 02 00 00    	ja     62cf <fwp_p_ad_push.constprop.0+0x2df>
    60b2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    60b6:	48 39 e8             	cmp    %rbp,%rax
    60b9:	0f 8e 31 01 00 00    	jle    61f0 <fwp_p_ad_push.constprop.0+0x200>
    60bf:	48 85 ed             	test   %rbp,%rbp
    60c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    60c7:	48 0f 44 e9          	cmove  %rcx,%rbp
    60cb:	48 39 e8             	cmp    %rbp,%rax
    60ce:	7e 20                	jle    60f0 <fwp_p_ad_push.constprop.0+0x100>
    60d0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    60d7:	0f 8f 03 01 00 00    	jg     61e0 <fwp_p_ad_push.constprop.0+0x1f0>
    60dd:	48 01 ed             	add    %rbp,%rbp
    60e0:	48 39 e8             	cmp    %rbp,%rax
    60e3:	7f eb                	jg     60d0 <fwp_p_ad_push.constprop.0+0xe0>
    60e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60ec:	00 00 00 00 
    60f0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    60f7:	00 
    60f8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    60fc:	48 89 c6             	mov    %rax,%rsi
    60ff:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6104:	e8 c7 d4 ff ff       	call   35d0 <realloc@plt>
    6109:	48 85 c0             	test   %rax,%rax
    610c:	0f 84 d5 01 00 00    	je     62e7 <fwp_p_ad_push.constprop.0+0x2f7>
    6112:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6116:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    611a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    611e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6122:	48 89 e9             	mov    %rbp,%rcx
    6125:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6129:	48 c1 e1 04          	shl    $0x4,%rcx
    612d:	48 89 ce             	mov    %rcx,%rsi
    6130:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6135:	e8 96 d4 ff ff       	call   35d0 <realloc@plt>
    613a:	48 85 c0             	test   %rax,%rax
    613d:	0f 84 a4 01 00 00    	je     62e7 <fwp_p_ad_push.constprop.0+0x2f7>
    6143:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6147:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    614c:	4d 85 f6             	test   %r14,%r14
    614f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6153:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6158:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    615f:	00 
    6160:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    6167:	00 
    6168:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    616c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    6173:	00 
    6174:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6178:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    617c:	0f 85 e6 00 00 00    	jne    6268 <fwp_p_ad_push.constprop.0+0x278>
    6182:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6186:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    618a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    618e:	49 01 c8             	add    %rcx,%r8
    6191:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    6195:	eb 79                	jmp    6210 <fwp_p_ad_push.constprop.0+0x220>
    6197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    619e:	00 00 
    61a0:	48 89 d0             	mov    %rdx,%rax
    61a3:	48 c1 ff 20          	sar    $0x20,%rdi
    61a7:	48 c1 f8 20          	sar    $0x20,%rax
    61ab:	48 39 c7             	cmp    %rax,%rdi
    61ae:	0f 84 a3 fe ff ff    	je     6057 <fwp_p_ad_push.constprop.0+0x67>
    61b4:	48 8d 3d f5 96 00 00 	lea    0x96f5(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    61bb:	e8 30 e2 ff ff       	call   43f0 <fwp_trap>
    61c0:	48 83 c4 38          	add    $0x38,%rsp
    61c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    61cb:	5b                   	pop    %rbx
    61cc:	5d                   	pop    %rbp
    61cd:	41 5c                	pop    %r12
    61cf:	41 5d                	pop    %r13
    61d1:	41 5e                	pop    %r14
    61d3:	41 5f                	pop    %r15
    61d5:	c3                   	ret
    61d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    61dd:	00 00 00 
    61e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    61e5:	e9 06 ff ff ff       	jmp    60f0 <fwp_p_ad_push.constprop.0+0x100>
    61ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61f0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    61f4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    61f8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    61ff:	00 
    6200:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6207:	00 
    6208:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    620c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6210:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6216:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    621a:	4d 85 ed             	test   %r13,%r13
    621d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6222:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6228:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    622f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6233:	49 8d 47 01          	lea    0x1(%r15),%rax
    6237:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    623b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6241:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6245:	48 83 c4 38          	add    $0x38,%rsp
    6249:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6250:	ff ff ff 
    6253:	4c 21 e0             	and    %r12,%rax
    6256:	5b                   	pop    %rbx
    6257:	5d                   	pop    %rbp
    6258:	4c 09 f8             	or     %r15,%rax
    625b:	41 5c                	pop    %r12
    625d:	41 5d                	pop    %r13
    625f:	41 5e                	pop    %r14
    6261:	41 5f                	pop    %r15
    6263:	c3                   	ret
    6264:	0f 1f 40 00          	nopl   0x0(%rax)
    6268:	48 39 ca             	cmp    %rcx,%rdx
    626b:	49 89 d6             	mov    %rdx,%r14
    626e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    6273:	48 0f 43 ca          	cmovae %rdx,%rcx
    6277:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    627c:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6281:	48 29 d1             	sub    %rdx,%rcx
    6284:	4c 89 ca             	mov    %r9,%rdx
    6287:	e8 d4 d2 ff ff       	call   3560 <__memmove_chk@plt>
    628c:	4c 03 73 30          	add    0x30(%rbx),%r14
    6290:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6295:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6299:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    629e:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    62a2:	48 03 7b 20          	add    0x20(%rbx),%rdi
    62a6:	4c 89 d2             	mov    %r10,%rdx
    62a9:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    62ae:	e8 5d d3 ff ff       	call   3610 <memmove@plt>
    62b3:	48 8b 43 30          	mov    0x30(%rbx),%rax
    62b7:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    62bb:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    62c0:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    62c5:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    62ca:	e9 b7 fe ff ff       	jmp    6186 <fwp_p_ad_push.constprop.0+0x196>
    62cf:	48 8d 3d 76 8e 00 00 	lea    0x8e76(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    62d6:	e8 15 e1 ff ff       	call   43f0 <fwp_trap>
    62db:	48 8d 3d 85 8e 00 00 	lea    0x8e85(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    62e2:	e8 09 e1 ff ff       	call   43f0 <fwp_trap>
    62e7:	48 89 df             	mov    %rbx,%rdi
    62ea:	e8 11 d9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    62ef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    62f3:	e8 c8 d0 ff ff       	call   33c0 <free@plt>
    62f8:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    62fc:	e8 bf d0 ff ff       	call   33c0 <free@plt>
    6301:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6305:	e8 b6 d0 ff ff       	call   33c0 <free@plt>
    630a:	31 c9                	xor    %ecx,%ecx
    630c:	31 c0                	xor    %eax,%eax
    630e:	31 d2                	xor    %edx,%edx
    6310:	89 53 04             	mov    %edx,0x4(%rbx)
    6313:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6317:	ba 13 00 00 00       	mov    $0x13,%edx
    631c:	be 01 00 00 00       	mov    $0x1,%esi
    6321:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6325:	48 8d 3d dc 8c 00 00 	lea    0x8cdc(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    632c:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6330:	48 8b 0d 29 cd 00 00 	mov    0xcd29(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    6337:	48 89 43 40          	mov    %rax,0x40(%rbx)
    633b:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    633f:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6343:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6347:	e8 34 d3 ff ff       	call   3680 <fwrite@plt>
    634c:	31 ff                	xor    %edi,%edi
    634e:	e8 6d d2 ff ff       	call   35c0 <fflush@plt>
    6353:	bf 66 00 00 00       	mov    $0x66,%edi
    6358:	e8 43 d3 ff ff       	call   36a0 <_Exit@plt>
    635d:	48 8d 3d 94 95 00 00 	lea    0x9594(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    6364:	e8 87 e0 ff ff       	call   43f0 <fwp_trap>
    6369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006370 <w107>:
    6370:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6374:	41 55                	push   %r13
    6376:	48 89 fa             	mov    %rdi,%rdx
    6379:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    637d:	41 54                	push   %r12
    637f:	49 89 fc             	mov    %rdi,%r12
    6382:	55                   	push   %rbp
    6383:	53                   	push   %rbx
    6384:	48 89 f3             	mov    %rsi,%rbx
    6387:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    638c:	48 89 f1             	mov    %rsi,%rcx
    638f:	48 83 ec 28          	sub    $0x28,%rsp
    6393:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6399:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    639f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    63a5:	e8 46 fc ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    63aa:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    63b0:	48 89 da             	mov    %rbx,%rdx
    63b3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    63b9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    63c0:	00 f0 3f 
    63c3:	48 89 c7             	mov    %rax,%rdi
    63c6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    63cd:	00 f0 bf 
    63d0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    63d5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63db:	e8 10 fc ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    63e0:	f2 0f 10 05 38 98 00 	movsd  0x9838(%rip),%xmm0        # fc20 <msg.4+0xb0>
    63e7:	00 
    63e8:	4c 89 e7             	mov    %r12,%rdi
    63eb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    63f1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    63f8:	00 f0 3f 
    63fb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6402:	49 89 c5             	mov    %rax,%r13
    6405:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    640c:	00 f0 bf 
    640f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6414:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    641a:	e8 d1 fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    641f:	48 89 e9             	mov    %rbp,%rcx
    6422:	4c 89 ea             	mov    %r13,%rdx
    6425:	48 89 ee             	mov    %rbp,%rsi
    6428:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    642e:	4c 89 ef             	mov    %r13,%rdi
    6431:	49 89 c4             	mov    %rax,%r12
    6434:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6438:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    643e:	e8 ad fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    6443:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6449:	f2 0f 59 1d d7 97 00 	mulsd  0x97d7(%rip),%xmm3        # fc28 <msg.4+0xb8>
    6450:	00 
    6451:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6458:	00 59 40 
    645b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6460:	48 89 c2             	mov    %rax,%rdx
    6463:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    646a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6470:	e8 7b fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    6475:	48 89 d9             	mov    %rbx,%rcx
    6478:	4c 89 e2             	mov    %r12,%rdx
    647b:	48 89 de             	mov    %rbx,%rsi
    647e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6484:	4c 89 e7             	mov    %r12,%rdi
    6487:	48 89 c5             	mov    %rax,%rbp
    648a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    648e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6494:	e8 57 fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    6499:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    649f:	48 89 ea             	mov    %rbp,%rdx
    64a2:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    64a8:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    64af:	00 f0 3f 
    64b2:	48 89 c7             	mov    %rax,%rdi
    64b5:	48 89 ce             	mov    %rcx,%rsi
    64b8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    64bd:	e8 2e fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    64c2:	48 83 c4 28          	add    $0x28,%rsp
    64c6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    64cb:	5b                   	pop    %rbx
    64cc:	5d                   	pop    %rbp
    64cd:	41 5c                	pop    %r12
    64cf:	41 5d                	pop    %r13
    64d1:	c3                   	ret
    64d2:	0f 1f 00             	nopl   (%rax)
    64d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    64dc:	00 00 00 00 

00000000000064e0 <w164.constprop.0>:
    64e0:	41 54                	push   %r12
    64e2:	55                   	push   %rbp
    64e3:	53                   	push   %rbx
    64e4:	48 83 ec 10          	sub    $0x10,%rsp
    64e8:	4c 8b 27             	mov    (%rdi),%r12
    64eb:	4d 85 e4             	test   %r12,%r12
    64ee:	74 58                	je     6548 <w164.constprop.0+0x68>
    64f0:	48 89 fd             	mov    %rdi,%rbp
    64f3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    64f7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    64fe:	31 db                	xor    %ebx,%ebx
    6500:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6506:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    650b:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6512:	00 f0 3f 
    6515:	48 83 c3 02          	add    $0x2,%rbx
    6519:	48 89 ce             	mov    %rcx,%rsi
    651c:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6522:	e8 c9 fa ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    6527:	4c 39 e3             	cmp    %r12,%rbx
    652a:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6530:	48 89 c7             	mov    %rax,%rdi
    6533:	72 cb                	jb     6500 <w164.constprop.0+0x20>
    6535:	48 83 c4 10          	add    $0x10,%rsp
    6539:	48 89 f8             	mov    %rdi,%rax
    653c:	5b                   	pop    %rbx
    653d:	5d                   	pop    %rbp
    653e:	41 5c                	pop    %r12
    6540:	c3                   	ret
    6541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6548:	48 83 c4 10          	add    $0x10,%rsp
    654c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6553:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6557:	5b                   	pop    %rbx
    6558:	48 89 f8             	mov    %rdi,%rax
    655b:	5d                   	pop    %rbp
    655c:	41 5c                	pop    %r12
    655e:	c3                   	ret
    655f:	90                   	nop

0000000000006560 <fwp_data.part.0.constprop.0>:
    6560:	41 56                	push   %r14
    6562:	41 89 fe             	mov    %edi,%r14d
    6565:	41 54                	push   %r12
    6567:	49 89 f4             	mov    %rsi,%r12
    656a:	55                   	push   %rbp
    656b:	53                   	push   %rbx
    656c:	48 83 ec 08          	sub    $0x8,%rsp
    6570:	8b 05 0e e6 01 00    	mov    0x1e60e(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    6576:	85 c0                	test   %eax,%eax
    6578:	0f 84 fa 00 00 00    	je     6678 <fwp_data.part.0.constprop.0+0x118>
    657e:	0f b6 05 fd e1 01 00 	movzbl 0x1e1fd(%rip),%eax        # 24782 <fwp_heap+0xfa2>
    6585:	48 8d 15 54 d2 01 00 	lea    0x1d254(%rip),%rdx        # 237e0 <fwp_heap>
    658c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6593:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6597:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    659b:	48 8b 18             	mov    (%rax),%rbx
    659e:	48 85 db             	test   %rbx,%rbx
    65a1:	0f 84 a9 00 00 00    	je     6650 <fwp_data.part.0.constprop.0+0xf0>
    65a7:	48 8b 13             	mov    (%rbx),%rdx
    65aa:	48 f7 d2             	not    %rdx
    65ad:	48 89 10             	mov    %rdx,(%rax)
    65b0:	48 83 fd 18          	cmp    $0x18,%rbp
    65b4:	76 1b                	jbe    65d1 <fwp_data.part.0.constprop.0+0x71>
    65b6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    65ba:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    65be:	31 f6                	xor    %esi,%esi
    65c0:	48 c1 e8 03          	shr    $0x3,%rax
    65c4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    65cb:	00 
    65cc:	e8 ef ce ff ff       	call   34c0 <memset@plt>
    65d1:	48 89 e8             	mov    %rbp,%rax
    65d4:	48 03 05 25 e6 01 00 	add    0x1e625(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    65db:	0f 82 a8 00 00 00    	jb     6689 <fwp_data.part.0.constprop.0+0x129>
    65e1:	48 39 05 20 e6 01 00 	cmp    %rax,0x1e620(%rip)        # 24c08 <fwp_heap+0x1428>
    65e8:	48 89 05 11 e6 01 00 	mov    %rax,0x1e611(%rip)        # 24c00 <fwp_heap+0x1420>
    65ef:	73 07                	jae    65f8 <fwp_data.part.0.constprop.0+0x98>
    65f1:	48 89 05 10 e6 01 00 	mov    %rax,0x1e610(%rip)        # 24c08 <fwp_heap+0x1428>
    65f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    65fc:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6601:	f2 0f 58 05 0f e6 01 	addsd  0x1e60f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    6608:	00 
    6609:	f2 0f 11 05 07 e6 01 	movsd  %xmm0,0x1e607(%rip)        # 24c18 <fwp_heap+0x1438>
    6610:	00 
    6611:	b8 02 00 00 00       	mov    $0x2,%eax
    6616:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    661b:	66 0f 6e c8          	movd   %eax,%xmm1
    661f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6623:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6627:	49 8b 04 24          	mov    (%r12),%rax
    662b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    662f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6634:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6638:	48 83 c4 08          	add    $0x8,%rsp
    663c:	48 89 d8             	mov    %rbx,%rax
    663f:	5b                   	pop    %rbx
    6640:	5d                   	pop    %rbp
    6641:	41 5c                	pop    %r12
    6643:	41 5e                	pop    %r14
    6645:	c3                   	ret
    6646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    664d:	00 00 00 
    6650:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6654:	48 85 db             	test   %rbx,%rbx
    6657:	74 1f                	je     6678 <fwp_data.part.0.constprop.0+0x118>
    6659:	48 8b 50 10          	mov    0x10(%rax),%rdx
    665d:	48 29 da             	sub    %rbx,%rdx
    6660:	48 39 ea             	cmp    %rbp,%rdx
    6663:	72 13                	jb     6678 <fwp_data.part.0.constprop.0+0x118>
    6665:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6669:	48 89 50 08          	mov    %rdx,0x8(%rax)
    666d:	e9 3e ff ff ff       	jmp    65b0 <fwp_data.part.0.constprop.0+0x50>
    6672:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6678:	31 f6                	xor    %esi,%esi
    667a:	bf 18 00 00 00       	mov    $0x18,%edi
    667f:	e8 0c f6 ff ff       	call   5c90 <fwp_heap_alloc>
    6684:	48 89 c3             	mov    %rax,%rbx
    6687:	eb 88                	jmp    6611 <fwp_data.part.0.constprop.0+0xb1>
    6689:	e8 22 d6 ff ff       	call   3cb0 <fwp_heap_oom>
    668e:	66 90                	xchg   %ax,%ax

0000000000006690 <fwp_rc_share>:
    6690:	48 8b 05 21 e5 01 00 	mov    0x1e521(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    6697:	48 2b 3d f2 e4 01 00 	sub    0x1e4f2(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    669e:	48 c1 e0 10          	shl    $0x10,%rax
    66a2:	48 39 c7             	cmp    %rax,%rdi
    66a5:	73 4a                	jae    66f1 <fwp_rc_share+0x61>
    66a7:	48 89 f8             	mov    %rdi,%rax
    66aa:	48 c1 e8 10          	shr    $0x10,%rax
    66ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    66b2:	48 8b 05 1f e5 01 00 	mov    0x1e51f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    66b9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    66bd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    66c1:	48 85 d2             	test   %rdx,%rdx
    66c4:	74 2b                	je     66f1 <fwp_rc_share+0x61>
    66c6:	0f b6 08             	movzbl (%rax),%ecx
    66c9:	80 f9 02             	cmp    $0x2,%cl
    66cc:	74 2a                	je     66f8 <fwp_rc_share+0x68>
    66ce:	80 f9 01             	cmp    $0x1,%cl
    66d1:	75 1e                	jne    66f1 <fwp_rc_share+0x61>
    66d3:	8b 48 18             	mov    0x18(%rax),%ecx
    66d6:	0f b7 ff             	movzwl %di,%edi
    66d9:	8b 40 1c             	mov    0x1c(%rax),%eax
    66dc:	48 0f af f9          	imul   %rcx,%rdi
    66e0:	48 c1 ef 20          	shr    $0x20,%rdi
    66e4:	48 39 c7             	cmp    %rax,%rdi
    66e7:	73 08                	jae    66f1 <fwp_rc_share+0x61>
    66e9:	48 01 fa             	add    %rdi,%rdx
    66ec:	80 3a 00             	cmpb   $0x0,(%rdx)
    66ef:	75 0d                	jne    66fe <fwp_rc_share+0x6e>
    66f1:	c3                   	ret
    66f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66f8:	66 85 ff             	test   %di,%di
    66fb:	74 ef                	je     66ec <fwp_rc_share+0x5c>
    66fd:	c3                   	ret
    66fe:	50                   	push   %rax
    66ff:	48 8d 3d 22 92 00 00 	lea    0x9222(%rip),%rdi        # f928 <_IO_stdin_used+0x928>
    6706:	e8 e5 dc ff ff       	call   43f0 <fwp_trap>
    670b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006710 <fwp_rc_fresh>:
    6710:	48 8b 15 a1 e4 01 00 	mov    0x1e4a1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6717:	48 89 f8             	mov    %rdi,%rax
    671a:	48 89 fe             	mov    %rdi,%rsi
    671d:	48 2b 05 6c e4 01 00 	sub    0x1e46c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6724:	48 c1 e2 10          	shl    $0x10,%rdx
    6728:	48 39 d0             	cmp    %rdx,%rax
    672b:	73 4f                	jae    677c <fwp_rc_fresh+0x6c>
    672d:	48 89 c2             	mov    %rax,%rdx
    6730:	48 c1 ea 10          	shr    $0x10,%rdx
    6734:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6738:	48 8b 15 99 e4 01 00 	mov    0x1e499(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    673f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6743:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6747:	48 85 d2             	test   %rdx,%rdx
    674a:	74 30                	je     677c <fwp_rc_fresh+0x6c>
    674c:	0f b6 39             	movzbl (%rcx),%edi
    674f:	40 80 ff 02          	cmp    $0x2,%dil
    6753:	74 2b                	je     6780 <fwp_rc_fresh+0x70>
    6755:	40 80 ff 01          	cmp    $0x1,%dil
    6759:	75 21                	jne    677c <fwp_rc_fresh+0x6c>
    675b:	8b 79 18             	mov    0x18(%rcx),%edi
    675e:	0f b7 c0             	movzwl %ax,%eax
    6761:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6764:	48 0f af c7          	imul   %rdi,%rax
    6768:	48 c1 e8 20          	shr    $0x20,%rax
    676c:	48 39 c8             	cmp    %rcx,%rax
    676f:	73 0b                	jae    677c <fwp_rc_fresh+0x6c>
    6771:	48 01 c2             	add    %rax,%rdx
    6774:	80 3a ff             	cmpb   $0xff,(%rdx)
    6777:	74 17                	je     6790 <fwp_rc_fresh+0x80>
    6779:	c6 02 01             	movb   $0x1,(%rdx)
    677c:	48 89 f0             	mov    %rsi,%rax
    677f:	c3                   	ret
    6780:	66 85 c0             	test   %ax,%ax
    6783:	74 ef                	je     6774 <fwp_rc_fresh+0x64>
    6785:	48 89 f0             	mov    %rsi,%rax
    6788:	c3                   	ret
    6789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6790:	48 83 ec 18          	sub    $0x18,%rsp
    6794:	48 89 d7             	mov    %rdx,%rdi
    6797:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    679c:	48 89 14 24          	mov    %rdx,(%rsp)
    67a0:	e8 ab ed ff ff       	call   5550 <fwp_rc_forget_slot>
    67a5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67aa:	48 8b 14 24          	mov    (%rsp),%rdx
    67ae:	48 89 f0             	mov    %rsi,%rax
    67b1:	c6 02 01             	movb   $0x1,(%rdx)
    67b4:	48 83 c4 18          	add    $0x18,%rsp
    67b8:	c3                   	ret
    67b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000067c0 <fwp_rc_free_arr>:
    67c0:	48 8b 15 f1 e3 01 00 	mov    0x1e3f1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    67c7:	48 89 f8             	mov    %rdi,%rax
    67ca:	48 2b 05 bf e3 01 00 	sub    0x1e3bf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    67d1:	48 c1 e2 10          	shl    $0x10,%rdx
    67d5:	48 39 d0             	cmp    %rdx,%rax
    67d8:	73 5b                	jae    6835 <fwp_rc_free_arr+0x75>
    67da:	48 89 c2             	mov    %rax,%rdx
    67dd:	48 c1 ea 10          	shr    $0x10,%rdx
    67e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67e5:	48 8b 15 ec e3 01 00 	mov    0x1e3ec(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    67ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    67f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    67f4:	48 85 c9             	test   %rcx,%rcx
    67f7:	74 3c                	je     6835 <fwp_rc_free_arr+0x75>
    67f9:	0f b6 32             	movzbl (%rdx),%esi
    67fc:	40 80 fe 02          	cmp    $0x2,%sil
    6800:	74 2e                	je     6830 <fwp_rc_free_arr+0x70>
    6802:	40 80 fe 01          	cmp    $0x1,%sil
    6806:	75 2d                	jne    6835 <fwp_rc_free_arr+0x75>
    6808:	8b 72 18             	mov    0x18(%rdx),%esi
    680b:	0f b7 c0             	movzwl %ax,%eax
    680e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6811:	48 0f af c6          	imul   %rsi,%rax
    6815:	48 c1 e8 20          	shr    $0x20,%rax
    6819:	48 39 d0             	cmp    %rdx,%rax
    681c:	73 17                	jae    6835 <fwp_rc_free_arr+0x75>
    681e:	48 01 c1             	add    %rax,%rcx
    6821:	80 39 01             	cmpb   $0x1,(%rcx)
    6824:	75 0f                	jne    6835 <fwp_rc_free_arr+0x75>
    6826:	e9 65 ef ff ff       	jmp    5790 <fwp_mem_free>
    682b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6830:	66 85 c0             	test   %ax,%ax
    6833:	74 ec                	je     6821 <fwp_rc_free_arr+0x61>
    6835:	c3                   	ret
    6836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    683d:	00 00 00 

0000000000006840 <fwp_rc_dup>:
    6840:	f3 0f 1e fa          	endbr64
    6844:	48 8b 05 6d e3 01 00 	mov    0x1e36d(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    684b:	48 2b 3d 3e e3 01 00 	sub    0x1e33e(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    6852:	48 c1 e0 10          	shl    $0x10,%rax
    6856:	48 39 c7             	cmp    %rax,%rdi
    6859:	73 56                	jae    68b1 <fwp_rc_dup+0x71>
    685b:	48 89 f8             	mov    %rdi,%rax
    685e:	48 c1 e8 10          	shr    $0x10,%rax
    6862:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6866:	48 8b 05 6b e3 01 00 	mov    0x1e36b(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    686d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6871:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6875:	48 85 c0             	test   %rax,%rax
    6878:	74 37                	je     68b1 <fwp_rc_dup+0x71>
    687a:	0f b6 0a             	movzbl (%rdx),%ecx
    687d:	80 f9 02             	cmp    $0x2,%cl
    6880:	74 36                	je     68b8 <fwp_rc_dup+0x78>
    6882:	80 f9 01             	cmp    $0x1,%cl
    6885:	75 2a                	jne    68b1 <fwp_rc_dup+0x71>
    6887:	8b 4a 18             	mov    0x18(%rdx),%ecx
    688a:	0f b7 ff             	movzwl %di,%edi
    688d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6890:	48 0f af f9          	imul   %rcx,%rdi
    6894:	48 c1 ef 20          	shr    $0x20,%rdi
    6898:	48 39 d7             	cmp    %rdx,%rdi
    689b:	73 14                	jae    68b1 <fwp_rc_dup+0x71>
    689d:	48 01 f8             	add    %rdi,%rax
    68a0:	0f b6 10             	movzbl (%rax),%edx
    68a3:	84 d2                	test   %dl,%dl
    68a5:	74 0a                	je     68b1 <fwp_rc_dup+0x71>
    68a7:	80 fa fd             	cmp    $0xfd,%dl
    68aa:	77 14                	ja     68c0 <fwp_rc_dup+0x80>
    68ac:	83 c2 01             	add    $0x1,%edx
    68af:	88 10                	mov    %dl,(%rax)
    68b1:	c3                   	ret
    68b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68b8:	66 85 ff             	test   %di,%di
    68bb:	74 e3                	je     68a0 <fwp_rc_dup+0x60>
    68bd:	c3                   	ret
    68be:	66 90                	xchg   %ax,%ax
    68c0:	48 89 c7             	mov    %rax,%rdi
    68c3:	e9 68 eb ff ff       	jmp    5430 <fwp_rc_wide_dup>
    68c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    68cf:	00 

00000000000068d0 <fwp_owned_entry161>:
    68d0:	f3 0f 1e fa          	endbr64
    68d4:	48 83 ec 38          	sub    $0x38,%rsp
    68d8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    68dd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    68e4:	00 00 
    68e6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    68eb:	31 c0                	xor    %eax,%eax
    68ed:	48 8b 07             	mov    (%rdi),%rax
    68f0:	48 03 47 10          	add    0x10(%rdi),%rax
    68f4:	0f 80 c2 00 00 00    	jo     69bc <fwp_owned_entry161+0xec>
    68fa:	66 48 0f 6e c8       	movq   %rax,%xmm1
    68ff:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6904:	31 ff                	xor    %edi,%edi
    6906:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    690a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    690f:	e8 4c fc ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    6914:	48 8b 15 9d e2 01 00 	mov    0x1e29d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    691b:	48 89 c6             	mov    %rax,%rsi
    691e:	48 2b 05 6b e2 01 00 	sub    0x1e26b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6925:	48 c1 e2 10          	shl    $0x10,%rdx
    6929:	48 39 d0             	cmp    %rdx,%rax
    692c:	73 4f                	jae    697d <fwp_owned_entry161+0xad>
    692e:	48 89 c2             	mov    %rax,%rdx
    6931:	48 c1 ea 10          	shr    $0x10,%rdx
    6935:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6939:	48 8b 15 98 e2 01 00 	mov    0x1e298(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6940:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6944:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6948:	48 85 d2             	test   %rdx,%rdx
    694b:	74 30                	je     697d <fwp_owned_entry161+0xad>
    694d:	0f b6 39             	movzbl (%rcx),%edi
    6950:	40 80 ff 02          	cmp    $0x2,%dil
    6954:	74 42                	je     6998 <fwp_owned_entry161+0xc8>
    6956:	40 80 ff 01          	cmp    $0x1,%dil
    695a:	75 21                	jne    697d <fwp_owned_entry161+0xad>
    695c:	8b 79 18             	mov    0x18(%rcx),%edi
    695f:	0f b7 c0             	movzwl %ax,%eax
    6962:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6965:	48 0f af c7          	imul   %rdi,%rax
    6969:	48 c1 e8 20          	shr    $0x20,%rax
    696d:	48 39 c8             	cmp    %rcx,%rax
    6970:	73 0b                	jae    697d <fwp_owned_entry161+0xad>
    6972:	48 01 c2             	add    %rax,%rdx
    6975:	80 3a ff             	cmpb   $0xff,(%rdx)
    6978:	74 26                	je     69a0 <fwp_owned_entry161+0xd0>
    697a:	c6 02 01             	movb   $0x1,(%rdx)
    697d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6982:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6989:	00 00 
    698b:	75 34                	jne    69c1 <fwp_owned_entry161+0xf1>
    698d:	48 89 f0             	mov    %rsi,%rax
    6990:	48 83 c4 38          	add    $0x38,%rsp
    6994:	c3                   	ret
    6995:	0f 1f 00             	nopl   (%rax)
    6998:	66 85 c0             	test   %ax,%ax
    699b:	75 e0                	jne    697d <fwp_owned_entry161+0xad>
    699d:	eb d6                	jmp    6975 <fwp_owned_entry161+0xa5>
    699f:	90                   	nop
    69a0:	48 89 d7             	mov    %rdx,%rdi
    69a3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    69a8:	48 89 14 24          	mov    %rdx,(%rsp)
    69ac:	e8 9f eb ff ff       	call   5550 <fwp_rc_forget_slot>
    69b1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    69b6:	48 8b 14 24          	mov    (%rsp),%rdx
    69ba:	eb be                	jmp    697a <fwp_owned_entry161+0xaa>
    69bc:	e8 3f cd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    69c1:	e8 9a ca ff ff       	call   3460 <__stack_chk_fail@plt>
    69c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69cd:	00 00 00 

00000000000069d0 <e161>:
    69d0:	f3 0f 1e fa          	endbr64
    69d4:	53                   	push   %rbx
    69d5:	48 83 ec 30          	sub    $0x30,%rsp
    69d9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    69de:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    69e5:	00 00 
    69e7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    69ec:	31 c0                	xor    %eax,%eax
    69ee:	48 8b 07             	mov    (%rdi),%rax
    69f1:	48 03 47 10          	add    0x10(%rdi),%rax
    69f5:	0f 80 c9 00 00 00    	jo     6ac4 <e161+0xf4>
    69fb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6a00:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6a05:	31 ff                	xor    %edi,%edi
    6a07:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6a0b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6a10:	e8 4b fb ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    6a15:	48 8b 15 9c e1 01 00 	mov    0x1e19c(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6a1c:	48 89 c3             	mov    %rax,%rbx
    6a1f:	48 2b 05 6a e1 01 00 	sub    0x1e16a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6a26:	48 c1 e2 10          	shl    $0x10,%rdx
    6a2a:	48 39 d0             	cmp    %rdx,%rax
    6a2d:	73 4f                	jae    6a7e <e161+0xae>
    6a2f:	48 89 c2             	mov    %rax,%rdx
    6a32:	48 c1 ea 10          	shr    $0x10,%rdx
    6a36:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a3a:	48 8b 15 97 e1 01 00 	mov    0x1e197(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6a41:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a45:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a49:	48 85 d2             	test   %rdx,%rdx
    6a4c:	74 30                	je     6a7e <e161+0xae>
    6a4e:	0f b6 31             	movzbl (%rcx),%esi
    6a51:	40 80 fe 02          	cmp    $0x2,%sil
    6a55:	74 49                	je     6aa0 <e161+0xd0>
    6a57:	40 80 fe 01          	cmp    $0x1,%sil
    6a5b:	75 21                	jne    6a7e <e161+0xae>
    6a5d:	8b 71 18             	mov    0x18(%rcx),%esi
    6a60:	0f b7 c0             	movzwl %ax,%eax
    6a63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a66:	48 0f af c6          	imul   %rsi,%rax
    6a6a:	48 c1 e8 20          	shr    $0x20,%rax
    6a6e:	48 39 c8             	cmp    %rcx,%rax
    6a71:	73 0b                	jae    6a7e <e161+0xae>
    6a73:	48 01 c2             	add    %rax,%rdx
    6a76:	80 3a ff             	cmpb   $0xff,(%rdx)
    6a79:	74 35                	je     6ab0 <e161+0xe0>
    6a7b:	c6 02 01             	movb   $0x1,(%rdx)
    6a7e:	48 89 df             	mov    %rbx,%rdi
    6a81:	e8 0a fc ff ff       	call   6690 <fwp_rc_share>
    6a86:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6a8b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a92:	00 00 
    6a94:	75 33                	jne    6ac9 <e161+0xf9>
    6a96:	48 83 c4 30          	add    $0x30,%rsp
    6a9a:	48 89 d8             	mov    %rbx,%rax
    6a9d:	5b                   	pop    %rbx
    6a9e:	c3                   	ret
    6a9f:	90                   	nop
    6aa0:	66 85 c0             	test   %ax,%ax
    6aa3:	75 d9                	jne    6a7e <e161+0xae>
    6aa5:	eb cf                	jmp    6a76 <e161+0xa6>
    6aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6aae:	00 00 
    6ab0:	48 89 d7             	mov    %rdx,%rdi
    6ab3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ab8:	e8 93 ea ff ff       	call   5550 <fwp_rc_forget_slot>
    6abd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6ac2:	eb b7                	jmp    6a7b <e161+0xab>
    6ac4:	e8 37 cc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6ac9:	e8 92 c9 ff ff       	call   3460 <__stack_chk_fail@plt>
    6ace:	66 90                	xchg   %ax,%ax

0000000000006ad0 <fwp_drop0>:
    6ad0:	f3 0f 1e fa          	endbr64
    6ad4:	48 8b 15 dd e0 01 00 	mov    0x1e0dd(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6adb:	48 89 f8             	mov    %rdi,%rax
    6ade:	48 2b 05 ab e0 01 00 	sub    0x1e0ab(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6ae5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ae9:	48 39 d0             	cmp    %rdx,%rax
    6aec:	0f 83 be 00 00 00    	jae    6bb0 <fwp_drop0+0xe0>
    6af2:	48 83 ec 18          	sub    $0x18,%rsp
    6af6:	4c 8d 05 e3 cc 01 00 	lea    0x1cce3(%rip),%r8        # 237e0 <fwp_heap>
    6afd:	48 89 c2             	mov    %rax,%rdx
    6b00:	48 c1 ea 10          	shr    $0x10,%rdx
    6b04:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b08:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6b0f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b13:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b17:	48 85 d2             	test   %rdx,%rdx
    6b1a:	74 3c                	je     6b58 <fwp_drop0+0x88>
    6b1c:	0f b6 31             	movzbl (%rcx),%esi
    6b1f:	40 80 fe 02          	cmp    $0x2,%sil
    6b23:	74 3b                	je     6b60 <fwp_drop0+0x90>
    6b25:	40 80 fe 01          	cmp    $0x1,%sil
    6b29:	75 2d                	jne    6b58 <fwp_drop0+0x88>
    6b2b:	8b 71 18             	mov    0x18(%rcx),%esi
    6b2e:	0f b7 c0             	movzwl %ax,%eax
    6b31:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b34:	48 0f af c6          	imul   %rsi,%rax
    6b38:	48 c1 e8 20          	shr    $0x20,%rax
    6b3c:	48 39 c8             	cmp    %rcx,%rax
    6b3f:	73 17                	jae    6b58 <fwp_drop0+0x88>
    6b41:	48 01 c2             	add    %rax,%rdx
    6b44:	0f b6 02             	movzbl (%rdx),%eax
    6b47:	84 c0                	test   %al,%al
    6b49:	74 0d                	je     6b58 <fwp_drop0+0x88>
    6b4b:	3c 01                	cmp    $0x1,%al
    6b4d:	74 21                	je     6b70 <fwp_drop0+0xa0>
    6b4f:	3c ff                	cmp    $0xff,%al
    6b51:	74 65                	je     6bb8 <fwp_drop0+0xe8>
    6b53:	83 e8 01             	sub    $0x1,%eax
    6b56:	88 02                	mov    %al,(%rdx)
    6b58:	48 83 c4 18          	add    $0x18,%rsp
    6b5c:	c3                   	ret
    6b5d:	0f 1f 00             	nopl   (%rax)
    6b60:	66 85 c0             	test   %ax,%ax
    6b63:	74 df                	je     6b44 <fwp_drop0+0x74>
    6b65:	48 83 c4 18          	add    $0x18,%rsp
    6b69:	c3                   	ret
    6b6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b70:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6b74:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6b79:	e8 42 fc ff ff       	call   67c0 <fwp_rc_free_arr>
    6b7e:	4c 8d 05 5b cc 01 00 	lea    0x1cc5b(%rip),%r8        # 237e0 <fwp_heap>
    6b85:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6b8a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6b91:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b98:	48 c1 e2 10          	shl    $0x10,%rdx
    6b9c:	48 39 d0             	cmp    %rdx,%rax
    6b9f:	73 b7                	jae    6b58 <fwp_drop0+0x88>
    6ba1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6ba6:	e9 52 ff ff ff       	jmp    6afd <fwp_drop0+0x2d>
    6bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6bb0:	c3                   	ret
    6bb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bb8:	48 89 d0             	mov    %rdx,%rax
    6bbb:	48 c1 e8 11          	shr    $0x11,%rax
    6bbf:	48 31 d0             	xor    %rdx,%rax
    6bc2:	48 89 c1             	mov    %rax,%rcx
    6bc5:	48 c1 e9 09          	shr    $0x9,%rcx
    6bc9:	48 31 c8             	xor    %rcx,%rax
    6bcc:	0f b6 c8             	movzbl %al,%ecx
    6bcf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6bd6:	00 
    6bd7:	48 85 c0             	test   %rax,%rax
    6bda:	75 0d                	jne    6be9 <fwp_drop0+0x119>
    6bdc:	eb 46                	jmp    6c24 <fwp_drop0+0x154>
    6bde:	66 90                	xchg   %ax,%ax
    6be0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6be4:	48 85 c0             	test   %rax,%rax
    6be7:	74 3b                	je     6c24 <fwp_drop0+0x154>
    6be9:	48 89 c1             	mov    %rax,%rcx
    6bec:	48 39 10             	cmp    %rdx,(%rax)
    6bef:	75 ef                	jne    6be0 <fwp_drop0+0x110>
    6bf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6bf5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6bf9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6bfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6c04:	0f 85 4e ff ff ff    	jne    6b58 <fwp_drop0+0x88>
    6c0a:	48 89 d7             	mov    %rdx,%rdi
    6c0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c12:	e8 39 e9 ff ff       	call   5550 <fwp_rc_forget_slot>
    6c17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6c1f:	e9 34 ff ff ff       	jmp    6b58 <fwp_drop0+0x88>
    6c24:	48 8d 3d 5d 8c 00 00 	lea    0x8c5d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6c2b:	e8 c0 d7 ff ff       	call   43f0 <fwp_trap>

0000000000006c30 <fwp_arg_drop12>:
    6c30:	f3 0f 1e fa          	endbr64
    6c34:	85 f6                	test   %esi,%esi
    6c36:	75 04                	jne    6c3c <fwp_arg_drop12+0xc>
    6c38:	85 d2                	test   %edx,%edx
    6c3a:	75 04                	jne    6c40 <fwp_arg_drop12+0x10>
    6c3c:	c3                   	ret
    6c3d:	0f 1f 00             	nopl   (%rax)
    6c40:	48 8b 3f             	mov    (%rdi),%rdi
    6c43:	e9 88 fe ff ff       	jmp    6ad0 <fwp_drop0>
    6c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c4f:	00 

0000000000006c50 <fwp_drop1>:
    6c50:	f3 0f 1e fa          	endbr64
    6c54:	48 8b 15 5d df 01 00 	mov    0x1df5d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6c5b:	48 89 f8             	mov    %rdi,%rax
    6c5e:	48 2b 05 2b df 01 00 	sub    0x1df2b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6c65:	48 c1 e2 10          	shl    $0x10,%rdx
    6c69:	48 39 d0             	cmp    %rdx,%rax
    6c6c:	0f 83 be 00 00 00    	jae    6d30 <fwp_drop1+0xe0>
    6c72:	48 83 ec 18          	sub    $0x18,%rsp
    6c76:	4c 8d 05 63 cb 01 00 	lea    0x1cb63(%rip),%r8        # 237e0 <fwp_heap>
    6c7d:	48 89 c2             	mov    %rax,%rdx
    6c80:	48 c1 ea 10          	shr    $0x10,%rdx
    6c84:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c88:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6c8f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c93:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c97:	48 85 d2             	test   %rdx,%rdx
    6c9a:	74 3c                	je     6cd8 <fwp_drop1+0x88>
    6c9c:	0f b6 31             	movzbl (%rcx),%esi
    6c9f:	40 80 fe 02          	cmp    $0x2,%sil
    6ca3:	74 3b                	je     6ce0 <fwp_drop1+0x90>
    6ca5:	40 80 fe 01          	cmp    $0x1,%sil
    6ca9:	75 2d                	jne    6cd8 <fwp_drop1+0x88>
    6cab:	8b 71 18             	mov    0x18(%rcx),%esi
    6cae:	0f b7 c0             	movzwl %ax,%eax
    6cb1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6cb4:	48 0f af c6          	imul   %rsi,%rax
    6cb8:	48 c1 e8 20          	shr    $0x20,%rax
    6cbc:	48 39 c8             	cmp    %rcx,%rax
    6cbf:	73 17                	jae    6cd8 <fwp_drop1+0x88>
    6cc1:	48 01 c2             	add    %rax,%rdx
    6cc4:	0f b6 02             	movzbl (%rdx),%eax
    6cc7:	84 c0                	test   %al,%al
    6cc9:	74 0d                	je     6cd8 <fwp_drop1+0x88>
    6ccb:	3c 01                	cmp    $0x1,%al
    6ccd:	74 21                	je     6cf0 <fwp_drop1+0xa0>
    6ccf:	3c ff                	cmp    $0xff,%al
    6cd1:	74 65                	je     6d38 <fwp_drop1+0xe8>
    6cd3:	83 e8 01             	sub    $0x1,%eax
    6cd6:	88 02                	mov    %al,(%rdx)
    6cd8:	48 83 c4 18          	add    $0x18,%rsp
    6cdc:	c3                   	ret
    6cdd:	0f 1f 00             	nopl   (%rax)
    6ce0:	66 85 c0             	test   %ax,%ax
    6ce3:	74 df                	je     6cc4 <fwp_drop1+0x74>
    6ce5:	48 83 c4 18          	add    $0x18,%rsp
    6ce9:	c3                   	ret
    6cea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6cf0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6cf4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6cf9:	e8 c2 fa ff ff       	call   67c0 <fwp_rc_free_arr>
    6cfe:	4c 8d 05 db ca 01 00 	lea    0x1cadb(%rip),%r8        # 237e0 <fwp_heap>
    6d05:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6d0a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6d11:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6d18:	48 c1 e2 10          	shl    $0x10,%rdx
    6d1c:	48 39 d0             	cmp    %rdx,%rax
    6d1f:	73 b7                	jae    6cd8 <fwp_drop1+0x88>
    6d21:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6d26:	e9 52 ff ff ff       	jmp    6c7d <fwp_drop1+0x2d>
    6d2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d30:	c3                   	ret
    6d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d38:	48 89 d0             	mov    %rdx,%rax
    6d3b:	48 c1 e8 11          	shr    $0x11,%rax
    6d3f:	48 31 d0             	xor    %rdx,%rax
    6d42:	48 89 c1             	mov    %rax,%rcx
    6d45:	48 c1 e9 09          	shr    $0x9,%rcx
    6d49:	48 31 c8             	xor    %rcx,%rax
    6d4c:	0f b6 c8             	movzbl %al,%ecx
    6d4f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6d56:	00 
    6d57:	48 85 c0             	test   %rax,%rax
    6d5a:	75 0d                	jne    6d69 <fwp_drop1+0x119>
    6d5c:	eb 46                	jmp    6da4 <fwp_drop1+0x154>
    6d5e:	66 90                	xchg   %ax,%ax
    6d60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6d64:	48 85 c0             	test   %rax,%rax
    6d67:	74 3b                	je     6da4 <fwp_drop1+0x154>
    6d69:	48 89 c1             	mov    %rax,%rcx
    6d6c:	48 39 10             	cmp    %rdx,(%rax)
    6d6f:	75 ef                	jne    6d60 <fwp_drop1+0x110>
    6d71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6d79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6d7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d84:	0f 85 4e ff ff ff    	jne    6cd8 <fwp_drop1+0x88>
    6d8a:	48 89 d7             	mov    %rdx,%rdi
    6d8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d92:	e8 b9 e7 ff ff       	call   5550 <fwp_rc_forget_slot>
    6d97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6d9f:	e9 34 ff ff ff       	jmp    6cd8 <fwp_drop1+0x88>
    6da4:	48 8d 3d dd 8a 00 00 	lea    0x8add(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6dab:	e8 40 d6 ff ff       	call   43f0 <fwp_trap>

0000000000006db0 <fwp_closure_drop>:
    6db0:	48 8b 15 01 de 01 00 	mov    0x1de01(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6db7:	48 89 f8             	mov    %rdi,%rax
    6dba:	48 2b 05 cf dd 01 00 	sub    0x1ddcf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6dc1:	48 c1 e2 10          	shl    $0x10,%rdx
    6dc5:	48 39 d0             	cmp    %rdx,%rax
    6dc8:	73 6b                	jae    6e35 <fwp_closure_drop+0x85>
    6dca:	48 89 c2             	mov    %rax,%rdx
    6dcd:	48 c1 ea 10          	shr    $0x10,%rdx
    6dd1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6dd5:	48 8b 15 fc dd 01 00 	mov    0x1ddfc(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6ddc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6de0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6de4:	48 85 d2             	test   %rdx,%rdx
    6de7:	74 4c                	je     6e35 <fwp_closure_drop+0x85>
    6de9:	0f b6 31             	movzbl (%rcx),%esi
    6dec:	40 80 fe 02          	cmp    $0x2,%sil
    6df0:	74 3e                	je     6e30 <fwp_closure_drop+0x80>
    6df2:	40 80 fe 01          	cmp    $0x1,%sil
    6df6:	75 3d                	jne    6e35 <fwp_closure_drop+0x85>
    6df8:	8b 71 18             	mov    0x18(%rcx),%esi
    6dfb:	0f b7 c0             	movzwl %ax,%eax
    6dfe:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e01:	48 0f af c6          	imul   %rsi,%rax
    6e05:	48 c1 e8 20          	shr    $0x20,%rax
    6e09:	48 39 c8             	cmp    %rcx,%rax
    6e0c:	73 27                	jae    6e35 <fwp_closure_drop+0x85>
    6e0e:	48 01 c2             	add    %rax,%rdx
    6e11:	0f b6 02             	movzbl (%rdx),%eax
    6e14:	84 c0                	test   %al,%al
    6e16:	74 1d                	je     6e35 <fwp_closure_drop+0x85>
    6e18:	3c 01                	cmp    $0x1,%al
    6e1a:	74 24                	je     6e40 <fwp_closure_drop+0x90>
    6e1c:	3c ff                	cmp    $0xff,%al
    6e1e:	74 48                	je     6e68 <fwp_closure_drop+0xb8>
    6e20:	83 e8 01             	sub    $0x1,%eax
    6e23:	88 02                	mov    %al,(%rdx)
    6e25:	c3                   	ret
    6e26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e2d:	00 00 00 
    6e30:	66 85 c0             	test   %ax,%ax
    6e33:	74 dc                	je     6e11 <fwp_closure_drop+0x61>
    6e35:	c3                   	ret
    6e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e3d:	00 00 00 
    6e40:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6e47:	ff ff 
    6e49:	48 85 c0             	test   %rax,%rax
    6e4c:	74 12                	je     6e60 <fwp_closure_drop+0xb0>
    6e4e:	48 89 fe             	mov    %rdi,%rsi
    6e51:	48 89 c7             	mov    %rax,%rdi
    6e54:	e9 f7 d5 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6e59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e60:	e9 9b d7 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6e65:	0f 1f 00             	nopl   (%rax)
    6e68:	48 89 d0             	mov    %rdx,%rax
    6e6b:	48 8d 35 6e c9 01 00 	lea    0x1c96e(%rip),%rsi        # 237e0 <fwp_heap>
    6e72:	48 83 ec 18          	sub    $0x18,%rsp
    6e76:	48 c1 e8 11          	shr    $0x11,%rax
    6e7a:	48 31 d0             	xor    %rdx,%rax
    6e7d:	48 89 c1             	mov    %rax,%rcx
    6e80:	48 c1 e9 09          	shr    $0x9,%rcx
    6e84:	48 31 c8             	xor    %rcx,%rax
    6e87:	0f b6 c8             	movzbl %al,%ecx
    6e8a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6e91:	00 
    6e92:	48 85 c0             	test   %rax,%rax
    6e95:	75 12                	jne    6ea9 <fwp_closure_drop+0xf9>
    6e97:	eb 49                	jmp    6ee2 <fwp_closure_drop+0x132>
    6e99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ea0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6ea4:	48 85 c0             	test   %rax,%rax
    6ea7:	74 39                	je     6ee2 <fwp_closure_drop+0x132>
    6ea9:	48 89 c1             	mov    %rax,%rcx
    6eac:	48 39 10             	cmp    %rdx,(%rax)
    6eaf:	75 ef                	jne    6ea0 <fwp_closure_drop+0xf0>
    6eb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6eb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6eb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6ebd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ec4:	74 05                	je     6ecb <fwp_closure_drop+0x11b>
    6ec6:	48 83 c4 18          	add    $0x18,%rsp
    6eca:	c3                   	ret
    6ecb:	48 89 d7             	mov    %rdx,%rdi
    6ece:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ed3:	e8 78 e6 ff ff       	call   5550 <fwp_rc_forget_slot>
    6ed8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6edd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6ee0:	eb e4                	jmp    6ec6 <fwp_closure_drop+0x116>
    6ee2:	48 8d 3d 9f 89 00 00 	lea    0x899f(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6ee9:	e8 02 d5 ff ff       	call   43f0 <fwp_trap>
    6eee:	66 90                	xchg   %ax,%ax

0000000000006ef0 <fwp_owned_tape_release>:
    6ef0:	48 85 ff             	test   %rdi,%rdi
    6ef3:	0f 84 f7 00 00 00    	je     6ff0 <fwp_owned_tape_release+0x100>
    6ef9:	41 54                	push   %r12
    6efb:	55                   	push   %rbp
    6efc:	53                   	push   %rbx
    6efd:	48 8b 07             	mov    (%rdi),%rax
    6f00:	48 85 c0             	test   %rax,%rax
    6f03:	74 08                	je     6f0d <fwp_owned_tape_release+0x1d>
    6f05:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6f09:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6f0d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6f11:	48 85 d2             	test   %rdx,%rdx
    6f14:	74 03                	je     6f19 <fwp_owned_tape_release+0x29>
    6f16:	48 89 02             	mov    %rax,(%rdx)
    6f19:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6f1d:	48 89 fb             	mov    %rdi,%rbx
    6f20:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6f24:	48 85 c0             	test   %rax,%rax
    6f27:	0f 84 89 00 00 00    	je     6fb6 <fwp_owned_tape_release+0xc6>
    6f2d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6f31:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6f35:	7e 47                	jle    6f7e <fwp_owned_tape_release+0x8e>
    6f37:	31 ed                	xor    %ebp,%ebp
    6f39:	eb 0d                	jmp    6f48 <fwp_owned_tape_release+0x58>
    6f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f40:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6f44:	48 8b 40 68          	mov    0x68(%rax),%rax
    6f48:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6f4c:	49 89 ec             	mov    %rbp,%r12
    6f4f:	48 83 c5 01          	add    $0x1,%rbp
    6f53:	49 c1 e4 04          	shl    $0x4,%r12
    6f57:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6f5b:	ff d0                	call   *%rax
    6f5d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6f61:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6f66:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6f6a:	ff 50 68             	call   *0x68(%rax)
    6f6d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6f71:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6f75:	48 39 e8             	cmp    %rbp,%rax
    6f78:	7f c6                	jg     6f40 <fwp_owned_tape_release+0x50>
    6f7a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f7e:	31 ed                	xor    %ebp,%ebp
    6f80:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6f85:	7e 28                	jle    6faf <fwp_owned_tape_release+0xbf>
    6f87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f8e:	00 00 
    6f90:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6f94:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6f98:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6f9c:	74 07                	je     6fa5 <fwp_owned_tape_release+0xb5>
    6f9e:	ff 52 68             	call   *0x68(%rdx)
    6fa1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6fa5:	48 83 c5 01          	add    $0x1,%rbp
    6fa9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6fad:	7f e1                	jg     6f90 <fwp_owned_tape_release+0xa0>
    6faf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6fb3:	ff 52 68             	call   *0x68(%rdx)
    6fb6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6fba:	e8 f1 fd ff ff       	call   6db0 <fwp_closure_drop>
    6fbf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6fc3:	e8 e8 fd ff ff       	call   6db0 <fwp_closure_drop>
    6fc8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6fcc:	e8 df fd ff ff       	call   6db0 <fwp_closure_drop>
    6fd1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6fd5:	e8 b6 e7 ff ff       	call   5790 <fwp_mem_free>
    6fda:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6fde:	e8 ad e7 ff ff       	call   5790 <fwp_mem_free>
    6fe3:	48 89 df             	mov    %rbx,%rdi
    6fe6:	5b                   	pop    %rbx
    6fe7:	5d                   	pop    %rbp
    6fe8:	41 5c                	pop    %r12
    6fea:	e9 a1 e7 ff ff       	jmp    5790 <fwp_mem_free>
    6fef:	90                   	nop
    6ff0:	c3                   	ret
    6ff1:	0f 1f 40 00          	nopl   0x0(%rax)
    6ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ffc:	00 00 00 00 

0000000000007000 <fwp_tape_finish>:
    7000:	f3 0f 1e fa          	endbr64
    7004:	41 56                	push   %r14
    7006:	48 8d 3d b3 c0 01 00 	lea    0x1c0b3(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    700d:	41 55                	push   %r13
    700f:	41 54                	push   %r12
    7011:	55                   	push   %rbp
    7012:	53                   	push   %rbx
    7013:	e8 f8 d0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    7018:	48 83 3d e8 c0 01 00 	cmpq   $0x0,0x1c0e8(%rip)        # 23108 <fwp_ntapes>
    701f:	00 
    7020:	48 c7 05 7d c0 01 00 	movq   $0x0,0x1c07d(%rip)        # 230a8 <fwp_tape_cached_bytes>
    7027:	00 00 00 00 
    702b:	7e 68                	jle    7095 <fwp_tape_finish+0x95>
    702d:	45 31 e4             	xor    %r12d,%r12d
    7030:	31 ed                	xor    %ebp,%ebp
    7032:	0f 1f 00             	nopl   (%rax)
    7035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    703c:	00 00 00 00 
    7040:	48 8b 1d c9 c0 01 00 	mov    0x1c0c9(%rip),%rbx        # 23110 <fwp_tapes>
    7047:	48 83 c5 01          	add    $0x1,%rbp
    704b:	4c 01 e3             	add    %r12,%rbx
    704e:	49 83 c4 68          	add    $0x68,%r12
    7052:	48 89 df             	mov    %rbx,%rdi
    7055:	e8 a6 cb ff ff       	call   3c00 <fwp_tape_unlink_scope>
    705a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    705e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7062:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    7066:	e8 55 c3 ff ff       	call   33c0 <free@plt>
    706b:	4c 89 f7             	mov    %r14,%rdi
    706e:	e8 4d c3 ff ff       	call   33c0 <free@plt>
    7073:	4c 89 ef             	mov    %r13,%rdi
    7076:	e8 45 c3 ff ff       	call   33c0 <free@plt>
    707b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    707f:	e8 6c fe ff ff       	call   6ef0 <fwp_owned_tape_release>
    7084:	48 39 2d 7d c0 01 00 	cmp    %rbp,0x1c07d(%rip)        # 23108 <fwp_ntapes>
    708b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7092:	00 
    7093:	7f ab                	jg     7040 <fwp_tape_finish+0x40>
    7095:	48 8b 3d 74 c0 01 00 	mov    0x1c074(%rip),%rdi        # 23110 <fwp_tapes>
    709c:	e8 1f c3 ff ff       	call   33c0 <free@plt>
    70a1:	5b                   	pop    %rbx
    70a2:	5d                   	pop    %rbp
    70a3:	48 c7 05 62 c0 01 00 	movq   $0x0,0x1c062(%rip)        # 23110 <fwp_tapes>
    70aa:	00 00 00 00 
    70ae:	48 c7 05 47 c0 01 00 	movq   $0x0,0x1c047(%rip)        # 23100 <fwp_tapes_cap>
    70b5:	00 00 00 00 
    70b9:	41 5c                	pop    %r12
    70bb:	48 c7 05 42 c0 01 00 	movq   $0x0,0x1c042(%rip)        # 23108 <fwp_ntapes>
    70c2:	00 00 00 00 
    70c6:	41 5d                	pop    %r13
    70c8:	48 c7 05 25 c0 01 00 	movq   $0x0,0x1c025(%rip)        # 230f8 <fwp_tape_next_slot>
    70cf:	00 00 00 00 
    70d3:	41 5e                	pop    %r14
    70d5:	c3                   	ret
    70d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    70dd:	00 00 00 

00000000000070e0 <fwp_tape_scope_release>:
    70e0:	f3 0f 1e fa          	endbr64
    70e4:	41 55                	push   %r13
    70e6:	41 54                	push   %r12
    70e8:	55                   	push   %rbp
    70e9:	53                   	push   %rbx
    70ea:	48 83 ec 58          	sub    $0x58,%rsp
    70ee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    70f5:	00 00 
    70f7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    70fc:	48 63 07             	movslq (%rdi),%rax
    70ff:	85 c0                	test   %eax,%eax
    7101:	0f 88 05 01 00 00    	js     720c <fwp_tape_scope_release+0x12c>
    7107:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    710e:	ec c4 4e 
    7111:	48 89 fb             	mov    %rdi,%rbx
    7114:	eb 3c                	jmp    7152 <fwp_tape_scope_release+0x72>
    7116:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    711d:	00 00 00 
    7120:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    7125:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7129:	e8 92 c2 ff ff       	call   33c0 <free@plt>
    712e:	48 8b 3c 24          	mov    (%rsp),%rdi
    7132:	e8 89 c2 ff ff       	call   33c0 <free@plt>
    7137:	4c 89 ef             	mov    %r13,%rdi
    713a:	e8 81 c2 ff ff       	call   33c0 <free@plt>
    713f:	4c 89 e7             	mov    %r12,%rdi
    7142:	e8 a9 fd ff ff       	call   6ef0 <fwp_owned_tape_release>
    7147:	48 63 03             	movslq (%rbx),%rax
    714a:	85 c0                	test   %eax,%eax
    714c:	0f 88 ba 00 00 00    	js     720c <fwp_tape_scope_release+0x12c>
    7152:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    7156:	48 8b 35 b3 bf 01 00 	mov    0x1bfb3(%rip),%rsi        # 23110 <fwp_tapes>
    715d:	4c 01 c6             	add    %r8,%rsi
    7160:	48 89 f7             	mov    %rsi,%rdi
    7163:	e8 98 ca ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7168:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    716d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7172:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7179:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    717d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    7181:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7188:	00 
    7189:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    718e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    7192:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    7197:	66 0f ef d2          	pxor   %xmm2,%xmm2
    719b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    71a0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    71a7:	00 
    71a8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    71af:	00 
    71b0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    71b7:	00 
    71b8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    71bd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    71c2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    71c6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    71ca:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    71ce:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    71d4:	77 18                	ja     71ee <fwp_tape_scope_release+0x10e>
    71d6:	49 c1 f8 03          	sar    $0x3,%r8
    71da:	4c 0f af c5          	imul   %rbp,%r8
    71de:	4c 3b 05 13 bf 01 00 	cmp    0x1bf13(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    71e5:	7d 07                	jge    71ee <fwp_tape_scope_release+0x10e>
    71e7:	4c 89 05 0a bf 01 00 	mov    %r8,0x1bf0a(%rip)        # 230f8 <fwp_tape_next_slot>
    71ee:	4d 85 e4             	test   %r12,%r12
    71f1:	0f 85 29 ff ff ff    	jne    7120 <fwp_tape_scope_release+0x40>
    71f7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    71fc:	e8 6f de ff ff       	call   5070 <fwp_tape_buffers_release>
    7201:	48 63 03             	movslq (%rbx),%rax
    7204:	85 c0                	test   %eax,%eax
    7206:	0f 89 46 ff ff ff    	jns    7152 <fwp_tape_scope_release+0x72>
    720c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7211:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7218:	00 00 
    721a:	75 0b                	jne    7227 <fwp_tape_scope_release+0x147>
    721c:	48 83 c4 58          	add    $0x58,%rsp
    7220:	5b                   	pop    %rbx
    7221:	5d                   	pop    %rbp
    7222:	41 5c                	pop    %r12
    7224:	41 5d                	pop    %r13
    7226:	c3                   	ret
    7227:	e8 34 c2 ff ff       	call   3460 <__stack_chk_fail@plt>
    722c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007230 <fwp_task_dispose>:
    7230:	53                   	push   %rbx
    7231:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7235:	0f 84 0b c5 ff ff    	je     3746 <fwp_task_dispose.cold>
    723b:	48 89 fb             	mov    %rdi,%rbx
    723e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7243:	0f 85 fd c4 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7249:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    724d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7254:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    725b:	00 
    725c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7260:	48 85 ff             	test   %rdi,%rdi
    7263:	74 07                	je     726c <fwp_task_dispose+0x3c>
    7265:	48 85 c0             	test   %rax,%rax
    7268:	74 02                	je     726c <fwp_task_dispose+0x3c>
    726a:	ff d0                	call   *%rax
    726c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7273:	e8 18 e5 ff ff       	call   5790 <fwp_mem_free>
    7278:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    727f:	00 00 00 00 
    7283:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7287:	74 6f                	je     72f8 <fwp_task_dispose+0xc8>
    7289:	48 8b 15 28 d9 01 00 	mov    0x1d928(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7290:	48 89 d8             	mov    %rbx,%rax
    7293:	48 2b 05 f6 d8 01 00 	sub    0x1d8f6(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    729a:	48 c1 e2 10          	shl    $0x10,%rdx
    729e:	48 39 d0             	cmp    %rdx,%rax
    72a1:	73 4c                	jae    72ef <fwp_task_dispose+0xbf>
    72a3:	48 89 c2             	mov    %rax,%rdx
    72a6:	48 c1 ea 10          	shr    $0x10,%rdx
    72aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    72ae:	48 8b 15 23 d9 01 00 	mov    0x1d923(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    72b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    72b9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    72bd:	48 85 c9             	test   %rcx,%rcx
    72c0:	74 2d                	je     72ef <fwp_task_dispose+0xbf>
    72c2:	0f b6 32             	movzbl (%rdx),%esi
    72c5:	40 80 fe 02          	cmp    $0x2,%sil
    72c9:	74 3d                	je     7308 <fwp_task_dispose+0xd8>
    72cb:	40 80 fe 01          	cmp    $0x1,%sil
    72cf:	75 1e                	jne    72ef <fwp_task_dispose+0xbf>
    72d1:	8b 72 18             	mov    0x18(%rdx),%esi
    72d4:	0f b7 c0             	movzwl %ax,%eax
    72d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    72da:	48 0f af c6          	imul   %rsi,%rax
    72de:	48 c1 e8 20          	shr    $0x20,%rax
    72e2:	48 39 d0             	cmp    %rdx,%rax
    72e5:	73 08                	jae    72ef <fwp_task_dispose+0xbf>
    72e7:	48 01 c1             	add    %rax,%rcx
    72ea:	80 39 01             	cmpb   $0x1,(%rcx)
    72ed:	74 09                	je     72f8 <fwp_task_dispose+0xc8>
    72ef:	5b                   	pop    %rbx
    72f0:	c3                   	ret
    72f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72f8:	48 89 df             	mov    %rbx,%rdi
    72fb:	5b                   	pop    %rbx
    72fc:	e9 8f e4 ff ff       	jmp    5790 <fwp_mem_free>
    7301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7308:	66 85 c0             	test   %ax,%ax
    730b:	74 dd                	je     72ea <fwp_task_dispose+0xba>
    730d:	5b                   	pop    %rbx
    730e:	c3                   	ret
    730f:	90                   	nop

0000000000007310 <fwp_free_zombie>:
    7310:	48 8b 15 99 c4 01 00 	mov    0x1c499(%rip),%rdx        # 237b0 <fwp_zombie>
    7317:	48 85 d2             	test   %rdx,%rdx
    731a:	0f 84 98 00 00 00    	je     73b8 <fwp_free_zombie+0xa8>
    7320:	48 3b 15 99 c4 01 00 	cmp    0x1c499(%rip),%rdx        # 237c0 <fwp_cur>
    7327:	0f 84 8b 00 00 00    	je     73b8 <fwp_free_zombie+0xa8>
    732d:	48 83 ec 18          	sub    $0x18,%rsp
    7331:	48 63 05 4c be 01 00 	movslq 0x1be4c(%rip),%rax        # 23184 <fwp_stack_pool_n>
    7338:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    733c:	83 f8 3f             	cmp    $0x3f,%eax
    733f:	7f 7f                	jg     73c0 <fwp_free_zombie+0xb0>
    7341:	8d 48 01             	lea    0x1(%rax),%ecx
    7344:	89 0d 3a be 01 00    	mov    %ecx,0x1be3a(%rip)        # 23184 <fwp_stack_pool_n>
    734a:	48 8d 0d 4f be 01 00 	lea    0x1be4f(%rip),%rcx        # 231a0 <fwp_stack_pool>
    7351:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7355:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    735c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7360:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7367:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    736b:	48 85 c9             	test   %rcx,%rcx
    736e:	0f 84 fc 00 00 00    	je     7470 <fwp_free_zombie+0x160>
    7374:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    737b:	48 85 c0             	test   %rax,%rax
    737e:	74 07                	je     7387 <fwp_free_zombie+0x77>
    7380:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7387:	8b 42 5c             	mov    0x5c(%rdx),%eax
    738a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    738e:	48 c7 05 17 c4 01 00 	movq   $0x0,0x1c417(%rip)        # 237b0 <fwp_zombie>
    7395:	00 00 00 00 
    7399:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    73a0:	85 c0                	test   %eax,%eax
    73a2:	74 34                	je     73d8 <fwp_free_zombie+0xc8>
    73a4:	83 f8 01             	cmp    $0x1,%eax
    73a7:	0f 84 b3 00 00 00    	je     7460 <fwp_free_zombie+0x150>
    73ad:	48 83 c4 18          	add    $0x18,%rsp
    73b1:	c3                   	ret
    73b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73b8:	c3                   	ret
    73b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73c0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    73c4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    73c9:	e8 12 c2 ff ff       	call   35e0 <munmap@plt>
    73ce:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    73d3:	eb 80                	jmp    7355 <fwp_free_zombie+0x45>
    73d5:	0f 1f 00             	nopl   (%rax)
    73d8:	48 8b 0d d9 d7 01 00 	mov    0x1d7d9(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    73df:	48 89 d0             	mov    %rdx,%rax
    73e2:	48 2b 05 a7 d7 01 00 	sub    0x1d7a7(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    73e9:	48 c1 e1 10          	shl    $0x10,%rcx
    73ed:	48 39 c8             	cmp    %rcx,%rax
    73f0:	73 bb                	jae    73ad <fwp_free_zombie+0x9d>
    73f2:	48 89 c1             	mov    %rax,%rcx
    73f5:	48 c1 e9 10          	shr    $0x10,%rcx
    73f9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    73fd:	48 8b 0d d4 d7 01 00 	mov    0x1d7d4(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7404:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7408:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    740c:	48 85 c9             	test   %rcx,%rcx
    740f:	74 9c                	je     73ad <fwp_free_zombie+0x9d>
    7411:	0f b6 3e             	movzbl (%rsi),%edi
    7414:	40 80 ff 02          	cmp    $0x2,%dil
    7418:	74 66                	je     7480 <fwp_free_zombie+0x170>
    741a:	40 80 ff 01          	cmp    $0x1,%dil
    741e:	75 8d                	jne    73ad <fwp_free_zombie+0x9d>
    7420:	8b 7e 18             	mov    0x18(%rsi),%edi
    7423:	0f b7 c0             	movzwl %ax,%eax
    7426:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7429:	48 0f af c7          	imul   %rdi,%rax
    742d:	48 c1 e8 20          	shr    $0x20,%rax
    7431:	48 39 f0             	cmp    %rsi,%rax
    7434:	0f 83 73 ff ff ff    	jae    73ad <fwp_free_zombie+0x9d>
    743a:	48 01 c1             	add    %rax,%rcx
    743d:	0f b6 01             	movzbl (%rcx),%eax
    7440:	84 c0                	test   %al,%al
    7442:	0f 84 65 ff ff ff    	je     73ad <fwp_free_zombie+0x9d>
    7448:	3c 01                	cmp    $0x1,%al
    744a:	74 14                	je     7460 <fwp_free_zombie+0x150>
    744c:	3c ff                	cmp    $0xff,%al
    744e:	74 3b                	je     748b <fwp_free_zombie+0x17b>
    7450:	83 e8 01             	sub    $0x1,%eax
    7453:	88 01                	mov    %al,(%rcx)
    7455:	e9 53 ff ff ff       	jmp    73ad <fwp_free_zombie+0x9d>
    745a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7460:	48 89 d7             	mov    %rdx,%rdi
    7463:	48 83 c4 18          	add    $0x18,%rsp
    7467:	e9 c4 fd ff ff       	jmp    7230 <fwp_task_dispose>
    746c:	0f 1f 40 00          	nopl   0x0(%rax)
    7470:	48 89 05 11 c3 01 00 	mov    %rax,0x1c311(%rip)        # 23788 <fwp_tasks_active>
    7477:	e9 ff fe ff ff       	jmp    737b <fwp_free_zombie+0x6b>
    747c:	0f 1f 40 00          	nopl   0x0(%rax)
    7480:	66 85 c0             	test   %ax,%ax
    7483:	0f 85 24 ff ff ff    	jne    73ad <fwp_free_zombie+0x9d>
    7489:	eb b2                	jmp    743d <fwp_free_zombie+0x12d>
    748b:	48 89 ca             	mov    %rcx,%rdx
    748e:	48 8d 35 4b c3 01 00 	lea    0x1c34b(%rip),%rsi        # 237e0 <fwp_heap>
    7495:	48 c1 ea 11          	shr    $0x11,%rdx
    7499:	48 31 ca             	xor    %rcx,%rdx
    749c:	48 89 d0             	mov    %rdx,%rax
    749f:	48 c1 e8 09          	shr    $0x9,%rax
    74a3:	48 31 c2             	xor    %rax,%rdx
    74a6:	0f b6 d2             	movzbl %dl,%edx
    74a9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    74b0:	00 
    74b1:	48 85 c0             	test   %rax,%rax
    74b4:	75 13                	jne    74c9 <fwp_free_zombie+0x1b9>
    74b6:	eb 4c                	jmp    7504 <fwp_free_zombie+0x1f4>
    74b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    74bf:	00 
    74c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    74c4:	48 85 c0             	test   %rax,%rax
    74c7:	74 3b                	je     7504 <fwp_free_zombie+0x1f4>
    74c9:	48 89 c2             	mov    %rax,%rdx
    74cc:	48 39 08             	cmp    %rcx,(%rax)
    74cf:	75 ef                	jne    74c0 <fwp_free_zombie+0x1b0>
    74d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    74d5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    74d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    74dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    74e4:	0f 85 c3 fe ff ff    	jne    73ad <fwp_free_zombie+0x9d>
    74ea:	48 89 cf             	mov    %rcx,%rdi
    74ed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    74f2:	e8 59 e0 ff ff       	call   5550 <fwp_rc_forget_slot>
    74f7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    74fc:	c6 01 fe             	movb   $0xfe,(%rcx)
    74ff:	e9 a9 fe ff ff       	jmp    73ad <fwp_free_zombie+0x9d>
    7504:	48 8d 3d 7d 83 00 00 	lea    0x837d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    750b:	e8 e0 ce ff ff       	call   43f0 <fwp_trap>

0000000000007510 <fwp_block>:
    7510:	48 83 ec 08          	sub    $0x8,%rsp
    7514:	48 8b 05 8d c2 01 00 	mov    0x1c28d(%rip),%rax        # 237a8 <fwp_ready_head>
    751b:	48 85 c0             	test   %rax,%rax
    751e:	0f 84 1c 01 00 00    	je     7640 <fwp_block+0x130>
    7524:	90                   	nop
    7525:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    752c:	00 00 00 00 
    7530:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7537:	48 89 15 6a c2 01 00 	mov    %rdx,0x1c26a(%rip)        # 237a8 <fwp_ready_head>
    753e:	48 85 d2             	test   %rdx,%rdx
    7541:	0f 84 19 01 00 00    	je     7660 <fwp_block+0x150>
    7547:	48 8b 15 72 c2 01 00 	mov    0x1c272(%rip),%rdx        # 237c0 <fwp_cur>
    754e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7552:	48 39 c2             	cmp    %rax,%rdx
    7555:	0f 84 d5 00 00 00    	je     7630 <fwp_block+0x120>
    755b:	48 8b 0d e6 de 01 00 	mov    0x1dee6(%rip),%rcx        # 25448 <fwp_state_owners>
    7562:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7566:	48 89 05 53 c2 01 00 	mov    %rax,0x1c253(%rip)        # 237c0 <fwp_cur>
    756d:	f3 0f 7e 05 fb de 01 	movq   0x1defb(%rip),%xmm0        # 25470 <fwp_foreign_callbacks>
    7574:	00 
    7575:	0f 16 05 e4 de 01 00 	movhps 0x1dee4(%rip),%xmm0        # 25460 <fwp_state>
    757c:	f3 0f 7e 0d e4 de 01 	movq   0x1dee4(%rip),%xmm1        # 25468 <fwp_handlers>
    7583:	00 
    7584:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    758b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7592:	0f 16 0d df de 01 00 	movhps 0x1dedf(%rip),%xmm1        # 25478 <fwp_cleanups>
    7599:	f3 0f 7e 05 b7 de 01 	movq   0x1deb7(%rip),%xmm0        # 25458 <fwp_state_len>
    75a0:	00 
    75a1:	0f 16 05 a8 de 01 00 	movhps 0x1dea8(%rip),%xmm0        # 25450 <fwp_state_cap>
    75a8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    75af:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    75b6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    75ba:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    75c1:	48 89 0d a0 de 01 00 	mov    %rcx,0x1dea0(%rip)        # 25468 <fwp_handlers>
    75c8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    75cf:	48 89 0d a2 de 01 00 	mov    %rcx,0x1dea2(%rip)        # 25478 <fwp_cleanups>
    75d6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    75dd:	48 89 0d 8c de 01 00 	mov    %rcx,0x1de8c(%rip)        # 25470 <fwp_foreign_callbacks>
    75e4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    75eb:	48 89 0d 6e de 01 00 	mov    %rcx,0x1de6e(%rip)        # 25460 <fwp_state>
    75f2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    75f9:	48 89 0d 58 de 01 00 	mov    %rcx,0x1de58(%rip)        # 25458 <fwp_state_len>
    7600:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7607:	48 89 0d 42 de 01 00 	mov    %rcx,0x1de42(%rip)        # 25450 <fwp_state_cap>
    760e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7615:	48 89 0d 2c de 01 00 	mov    %rcx,0x1de2c(%rip)        # 25448 <fwp_state_owners>
    761c:	e8 6f be ff ff       	call   3490 <swapcontext@plt>
    7621:	f3 0f 1e fa          	endbr64
    7625:	e8 e6 fc ff ff       	call   7310 <fwp_free_zombie>
    762a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7630:	8b 05 4a bb 01 00    	mov    0x1bb4a(%rip),%eax        # 23180 <fwp_slice>
    7636:	85 c0                	test   %eax,%eax
    7638:	74 36                	je     7670 <fwp_block+0x160>
    763a:	48 83 c4 08          	add    $0x8,%rsp
    763e:	c3                   	ret
    763f:	90                   	nop
    7640:	e8 5b db ff ff       	call   51a0 <fwp_poll_events>
    7645:	48 8b 05 5c c1 01 00 	mov    0x1c15c(%rip),%rax        # 237a8 <fwp_ready_head>
    764c:	48 85 c0             	test   %rax,%rax
    764f:	0f 85 db fe ff ff    	jne    7530 <fwp_block+0x20>
    7655:	eb e9                	jmp    7640 <fwp_block+0x130>
    7657:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    765e:	00 00 
    7660:	48 c7 05 35 c1 01 00 	movq   $0x0,0x1c135(%rip)        # 237a0 <fwp_ready_tail>
    7667:	00 00 00 00 
    766b:	e9 d7 fe ff ff       	jmp    7547 <fwp_block+0x37>
    7670:	48 8d 3d 0d 7b 00 00 	lea    0x7b0d(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    7677:	e8 24 bd ff ff       	call   33a0 <getenv@plt>
    767c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7681:	48 85 c0             	test   %rax,%rax
    7684:	74 05                	je     768b <fwp_block+0x17b>
    7686:	80 38 00             	cmpb   $0x0,(%rax)
    7689:	75 0b                	jne    7696 <fwp_block+0x186>
    768b:	89 15 ef ba 01 00    	mov    %edx,0x1baef(%rip)        # 23180 <fwp_slice>
    7691:	48 83 c4 08          	add    $0x8,%rsp
    7695:	c3                   	ret
    7696:	ba 0a 00 00 00       	mov    $0xa,%edx
    769b:	31 f6                	xor    %esi,%esi
    769d:	48 89 c7             	mov    %rax,%rdi
    76a0:	e8 ab be ff ff       	call   3550 <strtoll@plt>
    76a5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    76a9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    76b0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    76b5:	0f 46 d0             	cmovbe %eax,%edx
    76b8:	eb d1                	jmp    768b <fwp_block+0x17b>
    76ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000076c0 <fwp_drop4>:
    76c0:	48 8b 15 f1 d4 01 00 	mov    0x1d4f1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    76c7:	48 89 f8             	mov    %rdi,%rax
    76ca:	48 2b 05 bf d4 01 00 	sub    0x1d4bf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    76d1:	48 c1 e2 10          	shl    $0x10,%rdx
    76d5:	48 39 d0             	cmp    %rdx,%rax
    76d8:	0f 83 52 01 00 00    	jae    7830 <fwp_drop4+0x170>
    76de:	48 83 ec 18          	sub    $0x18,%rsp
    76e2:	4c 8d 05 f7 c0 01 00 	lea    0x1c0f7(%rip),%r8        # 237e0 <fwp_heap>
    76e9:	48 89 c2             	mov    %rax,%rdx
    76ec:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    76f3:	48 c1 ea 10          	shr    $0x10,%rdx
    76f7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    76fb:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    76ff:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7703:	48 85 d2             	test   %rdx,%rdx
    7706:	74 46                	je     774e <fwp_drop4+0x8e>
    7708:	44 0f b6 09          	movzbl (%rcx),%r9d
    770c:	41 80 f9 02          	cmp    $0x2,%r9b
    7710:	0f 84 ca 00 00 00    	je     77e0 <fwp_drop4+0x120>
    7716:	41 80 f9 01          	cmp    $0x1,%r9b
    771a:	75 32                	jne    774e <fwp_drop4+0x8e>
    771c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7720:	0f b7 c0             	movzwl %ax,%eax
    7723:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7726:	49 0f af c1          	imul   %r9,%rax
    772a:	48 c1 e8 20          	shr    $0x20,%rax
    772e:	48 39 c8             	cmp    %rcx,%rax
    7731:	73 1b                	jae    774e <fwp_drop4+0x8e>
    7733:	48 01 c2             	add    %rax,%rdx
    7736:	0f b6 02             	movzbl (%rdx),%eax
    7739:	84 c0                	test   %al,%al
    773b:	74 11                	je     774e <fwp_drop4+0x8e>
    773d:	3c 01                	cmp    $0x1,%al
    773f:	74 17                	je     7758 <fwp_drop4+0x98>
    7741:	3c ff                	cmp    $0xff,%al
    7743:	0f 84 ef 00 00 00    	je     7838 <fwp_drop4+0x178>
    7749:	83 e8 01             	sub    $0x1,%eax
    774c:	88 02                	mov    %al,(%rdx)
    774e:	48 83 c4 18          	add    $0x18,%rsp
    7752:	c3                   	ret
    7753:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7758:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    775c:	0f 88 8e 00 00 00    	js     77f0 <fwp_drop4+0x130>
    7762:	48 8b 15 4f d4 01 00 	mov    0x1d44f(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7769:	48 89 f8             	mov    %rdi,%rax
    776c:	48 2b 05 1d d4 01 00 	sub    0x1d41d(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7773:	48 c1 e2 10          	shl    $0x10,%rdx
    7777:	48 39 d0             	cmp    %rdx,%rax
    777a:	73 d2                	jae    774e <fwp_drop4+0x8e>
    777c:	48 89 c2             	mov    %rax,%rdx
    777f:	48 c1 ea 10          	shr    $0x10,%rdx
    7783:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7787:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    778b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    778f:	48 85 c9             	test   %rcx,%rcx
    7792:	74 ba                	je     774e <fwp_drop4+0x8e>
    7794:	0f b6 32             	movzbl (%rdx),%esi
    7797:	40 80 fe 02          	cmp    $0x2,%sil
    779b:	74 33                	je     77d0 <fwp_drop4+0x110>
    779d:	40 80 fe 01          	cmp    $0x1,%sil
    77a1:	75 ab                	jne    774e <fwp_drop4+0x8e>
    77a3:	8b 72 18             	mov    0x18(%rdx),%esi
    77a6:	0f b7 c0             	movzwl %ax,%eax
    77a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    77ac:	48 0f af c6          	imul   %rsi,%rax
    77b0:	48 c1 e8 20          	shr    $0x20,%rax
    77b4:	48 39 d0             	cmp    %rdx,%rax
    77b7:	73 95                	jae    774e <fwp_drop4+0x8e>
    77b9:	48 01 c1             	add    %rax,%rcx
    77bc:	80 39 01             	cmpb   $0x1,(%rcx)
    77bf:	75 8d                	jne    774e <fwp_drop4+0x8e>
    77c1:	48 83 c4 18          	add    $0x18,%rsp
    77c5:	e9 c6 df ff ff       	jmp    5790 <fwp_mem_free>
    77ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77d0:	66 85 c0             	test   %ax,%ax
    77d3:	74 e7                	je     77bc <fwp_drop4+0xfc>
    77d5:	48 83 c4 18          	add    $0x18,%rsp
    77d9:	c3                   	ret
    77da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77e0:	66 85 c0             	test   %ax,%ax
    77e3:	0f 84 4d ff ff ff    	je     7736 <fwp_drop4+0x76>
    77e9:	48 83 c4 18          	add    $0x18,%rsp
    77ed:	c3                   	ret
    77ee:	66 90                	xchg   %ax,%ax
    77f0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    77f4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    77f9:	e8 c2 ef ff ff       	call   67c0 <fwp_rc_free_arr>
    77fe:	4c 8d 05 db bf 01 00 	lea    0x1bfdb(%rip),%r8        # 237e0 <fwp_heap>
    7805:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    780a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7811:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7818:	48 c1 e2 10          	shl    $0x10,%rdx
    781c:	48 39 d0             	cmp    %rdx,%rax
    781f:	0f 83 29 ff ff ff    	jae    774e <fwp_drop4+0x8e>
    7825:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    782a:	e9 ba fe ff ff       	jmp    76e9 <fwp_drop4+0x29>
    782f:	90                   	nop
    7830:	c3                   	ret
    7831:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7838:	48 89 d0             	mov    %rdx,%rax
    783b:	48 c1 e8 11          	shr    $0x11,%rax
    783f:	48 31 d0             	xor    %rdx,%rax
    7842:	48 89 c1             	mov    %rax,%rcx
    7845:	48 c1 e9 09          	shr    $0x9,%rcx
    7849:	48 31 c8             	xor    %rcx,%rax
    784c:	0f b6 c8             	movzbl %al,%ecx
    784f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7856:	00 
    7857:	48 85 c0             	test   %rax,%rax
    785a:	75 0d                	jne    7869 <fwp_drop4+0x1a9>
    785c:	eb 46                	jmp    78a4 <fwp_drop4+0x1e4>
    785e:	66 90                	xchg   %ax,%ax
    7860:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7864:	48 85 c0             	test   %rax,%rax
    7867:	74 3b                	je     78a4 <fwp_drop4+0x1e4>
    7869:	48 89 c1             	mov    %rax,%rcx
    786c:	48 39 10             	cmp    %rdx,(%rax)
    786f:	75 ef                	jne    7860 <fwp_drop4+0x1a0>
    7871:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7875:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7879:	48 89 48 08          	mov    %rcx,0x8(%rax)
    787d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7884:	0f 85 c4 fe ff ff    	jne    774e <fwp_drop4+0x8e>
    788a:	48 89 d7             	mov    %rdx,%rdi
    788d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7892:	e8 b9 dc ff ff       	call   5550 <fwp_rc_forget_slot>
    7897:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    789c:	c6 02 fe             	movb   $0xfe,(%rdx)
    789f:	e9 aa fe ff ff       	jmp    774e <fwp_drop4+0x8e>
    78a4:	48 8d 3d dd 7f 00 00 	lea    0x7fdd(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    78ab:	e8 40 cb ff ff       	call   43f0 <fwp_trap>

00000000000078b0 <fwp_caps161>:
    78b0:	f3 0f 1e fa          	endbr64
    78b4:	85 f6                	test   %esi,%esi
    78b6:	74 08                	je     78c0 <fwp_caps161+0x10>
    78b8:	c3                   	ret
    78b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78c0:	48 8b 15 f1 d2 01 00 	mov    0x1d2f1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    78c7:	48 89 f8             	mov    %rdi,%rax
    78ca:	48 2b 05 bf d2 01 00 	sub    0x1d2bf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    78d1:	48 c1 e2 10          	shl    $0x10,%rdx
    78d5:	48 39 d0             	cmp    %rdx,%rax
    78d8:	73 de                	jae    78b8 <fwp_caps161+0x8>
    78da:	48 89 c2             	mov    %rax,%rdx
    78dd:	48 c1 ea 10          	shr    $0x10,%rdx
    78e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    78e5:	48 8b 15 ec d2 01 00 	mov    0x1d2ec(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    78ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    78f4:	48 85 c9             	test   %rcx,%rcx
    78f7:	74 bf                	je     78b8 <fwp_caps161+0x8>
    78f9:	0f b6 32             	movzbl (%rdx),%esi
    78fc:	40 80 fe 02          	cmp    $0x2,%sil
    7900:	74 2e                	je     7930 <fwp_caps161+0x80>
    7902:	40 80 fe 01          	cmp    $0x1,%sil
    7906:	75 b0                	jne    78b8 <fwp_caps161+0x8>
    7908:	8b 72 18             	mov    0x18(%rdx),%esi
    790b:	0f b7 c0             	movzwl %ax,%eax
    790e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7911:	48 0f af c6          	imul   %rsi,%rax
    7915:	48 c1 e8 20          	shr    $0x20,%rax
    7919:	48 39 d0             	cmp    %rdx,%rax
    791c:	73 9a                	jae    78b8 <fwp_caps161+0x8>
    791e:	48 01 c1             	add    %rax,%rcx
    7921:	80 39 01             	cmpb   $0x1,(%rcx)
    7924:	75 92                	jne    78b8 <fwp_caps161+0x8>
    7926:	e9 65 de ff ff       	jmp    5790 <fwp_mem_free>
    792b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7930:	66 85 c0             	test   %ax,%ax
    7933:	74 ec                	je     7921 <fwp_caps161+0x71>
    7935:	c3                   	ret
    7936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    793d:	00 00 00 

0000000000007940 <fwp_args12>:
    7940:	f3 0f 1e fa          	endbr64
    7944:	85 d2                	test   %edx,%edx
    7946:	74 04                	je     794c <fwp_args12+0xc>
    7948:	85 f6                	test   %esi,%esi
    794a:	74 04                	je     7950 <fwp_args12+0x10>
    794c:	c3                   	ret
    794d:	0f 1f 00             	nopl   (%rax)
    7950:	48 8b 15 61 d2 01 00 	mov    0x1d261(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7957:	48 8b 07             	mov    (%rdi),%rax
    795a:	48 2b 05 2f d2 01 00 	sub    0x1d22f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7961:	48 c1 e2 10          	shl    $0x10,%rdx
    7965:	48 39 d0             	cmp    %rdx,%rax
    7968:	73 e2                	jae    794c <fwp_args12+0xc>
    796a:	48 89 c2             	mov    %rax,%rdx
    796d:	48 c1 ea 10          	shr    $0x10,%rdx
    7971:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7975:	48 8b 15 5c d2 01 00 	mov    0x1d25c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    797c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7980:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7984:	48 85 ff             	test   %rdi,%rdi
    7987:	74 c3                	je     794c <fwp_args12+0xc>
    7989:	0f b6 0a             	movzbl (%rdx),%ecx
    798c:	80 f9 02             	cmp    $0x2,%cl
    798f:	74 2f                	je     79c0 <fwp_args12+0x80>
    7991:	80 f9 01             	cmp    $0x1,%cl
    7994:	75 b6                	jne    794c <fwp_args12+0xc>
    7996:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7999:	0f b7 c0             	movzwl %ax,%eax
    799c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    799f:	48 0f af c1          	imul   %rcx,%rax
    79a3:	48 c1 e8 20          	shr    $0x20,%rax
    79a7:	48 39 d0             	cmp    %rdx,%rax
    79aa:	73 a0                	jae    794c <fwp_args12+0xc>
    79ac:	48 01 c7             	add    %rax,%rdi
    79af:	0f b6 07             	movzbl (%rdi),%eax
    79b2:	84 c0                	test   %al,%al
    79b4:	74 96                	je     794c <fwp_args12+0xc>
    79b6:	3c fd                	cmp    $0xfd,%al
    79b8:	77 0c                	ja     79c6 <fwp_args12+0x86>
    79ba:	83 c0 01             	add    $0x1,%eax
    79bd:	88 07                	mov    %al,(%rdi)
    79bf:	c3                   	ret
    79c0:	66 85 c0             	test   %ax,%ax
    79c3:	74 ea                	je     79af <fwp_args12+0x6f>
    79c5:	c3                   	ret
    79c6:	e9 65 da ff ff       	jmp    5430 <fwp_rc_wide_dup>
    79cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000079d0 <fwp_args23>:
    79d0:	f3 0f 1e fa          	endbr64
    79d4:	85 d2                	test   %edx,%edx
    79d6:	74 04                	je     79dc <fwp_args23+0xc>
    79d8:	85 f6                	test   %esi,%esi
    79da:	74 04                	je     79e0 <fwp_args23+0x10>
    79dc:	c3                   	ret
    79dd:	0f 1f 00             	nopl   (%rax)
    79e0:	48 8b 15 d1 d1 01 00 	mov    0x1d1d1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    79e7:	48 8b 07             	mov    (%rdi),%rax
    79ea:	48 2b 05 9f d1 01 00 	sub    0x1d19f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    79f1:	48 c1 e2 10          	shl    $0x10,%rdx
    79f5:	48 39 d0             	cmp    %rdx,%rax
    79f8:	73 e2                	jae    79dc <fwp_args23+0xc>
    79fa:	48 89 c2             	mov    %rax,%rdx
    79fd:	48 c1 ea 10          	shr    $0x10,%rdx
    7a01:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a05:	48 8b 15 cc d1 01 00 	mov    0x1d1cc(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7a0c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a10:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7a14:	48 85 ff             	test   %rdi,%rdi
    7a17:	74 c3                	je     79dc <fwp_args23+0xc>
    7a19:	0f b6 0a             	movzbl (%rdx),%ecx
    7a1c:	80 f9 02             	cmp    $0x2,%cl
    7a1f:	74 2f                	je     7a50 <fwp_args23+0x80>
    7a21:	80 f9 01             	cmp    $0x1,%cl
    7a24:	75 b6                	jne    79dc <fwp_args23+0xc>
    7a26:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a29:	0f b7 c0             	movzwl %ax,%eax
    7a2c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a2f:	48 0f af c1          	imul   %rcx,%rax
    7a33:	48 c1 e8 20          	shr    $0x20,%rax
    7a37:	48 39 d0             	cmp    %rdx,%rax
    7a3a:	73 a0                	jae    79dc <fwp_args23+0xc>
    7a3c:	48 01 c7             	add    %rax,%rdi
    7a3f:	0f b6 07             	movzbl (%rdi),%eax
    7a42:	84 c0                	test   %al,%al
    7a44:	74 96                	je     79dc <fwp_args23+0xc>
    7a46:	3c fd                	cmp    $0xfd,%al
    7a48:	77 0c                	ja     7a56 <fwp_args23+0x86>
    7a4a:	83 c0 01             	add    $0x1,%eax
    7a4d:	88 07                	mov    %al,(%rdi)
    7a4f:	c3                   	ret
    7a50:	66 85 c0             	test   %ax,%ax
    7a53:	74 ea                	je     7a3f <fwp_args23+0x6f>
    7a55:	c3                   	ret
    7a56:	e9 d5 d9 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7a5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007a60 <fwp_caps12>:
    7a60:	f3 0f 1e fa          	endbr64
    7a64:	48 83 ec 18          	sub    $0x18,%rsp
    7a68:	8b 57 04             	mov    0x4(%rdi),%edx
    7a6b:	48 89 f8             	mov    %rdi,%rax
    7a6e:	85 d2                	test   %edx,%edx
    7a70:	0f 84 9a 00 00 00    	je     7b10 <fwp_caps12+0xb0>
    7a76:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7a7a:	85 f6                	test   %esi,%esi
    7a7c:	0f 85 9e 00 00 00    	jne    7b20 <fwp_caps12+0xc0>
    7a82:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7a87:	e8 44 f0 ff ff       	call   6ad0 <fwp_drop0>
    7a8c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7a91:	48 8b 0d 20 d1 01 00 	mov    0x1d120(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7a98:	48 89 c2             	mov    %rax,%rdx
    7a9b:	48 2b 15 ee d0 01 00 	sub    0x1d0ee(%rip),%rdx        # 24b90 <fwp_heap+0x13b0>
    7aa2:	48 c1 e1 10          	shl    $0x10,%rcx
    7aa6:	48 39 ca             	cmp    %rcx,%rdx
    7aa9:	73 6d                	jae    7b18 <fwp_caps12+0xb8>
    7aab:	48 89 d1             	mov    %rdx,%rcx
    7aae:	48 c1 e9 10          	shr    $0x10,%rcx
    7ab2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7ab6:	48 8b 0d 1b d1 01 00 	mov    0x1d11b(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7abd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7ac1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7ac5:	48 85 f6             	test   %rsi,%rsi
    7ac8:	74 4e                	je     7b18 <fwp_caps12+0xb8>
    7aca:	0f b6 39             	movzbl (%rcx),%edi
    7acd:	40 80 ff 02          	cmp    $0x2,%dil
    7ad1:	0f 84 b9 00 00 00    	je     7b90 <fwp_caps12+0x130>
    7ad7:	40 80 ff 01          	cmp    $0x1,%dil
    7adb:	75 3b                	jne    7b18 <fwp_caps12+0xb8>
    7add:	8b 79 18             	mov    0x18(%rcx),%edi
    7ae0:	0f b7 d2             	movzwl %dx,%edx
    7ae3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ae6:	48 0f af d7          	imul   %rdi,%rdx
    7aea:	48 c1 ea 20          	shr    $0x20,%rdx
    7aee:	48 39 ca             	cmp    %rcx,%rdx
    7af1:	73 25                	jae    7b18 <fwp_caps12+0xb8>
    7af3:	48 01 d6             	add    %rdx,%rsi
    7af6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7af9:	75 1d                	jne    7b18 <fwp_caps12+0xb8>
    7afb:	48 89 c7             	mov    %rax,%rdi
    7afe:	48 83 c4 18          	add    $0x18,%rsp
    7b02:	e9 89 dc ff ff       	jmp    5790 <fwp_mem_free>
    7b07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b0e:	00 00 
    7b10:	85 f6                	test   %esi,%esi
    7b12:	0f 84 79 ff ff ff    	je     7a91 <fwp_caps12+0x31>
    7b18:	48 83 c4 18          	add    $0x18,%rsp
    7b1c:	c3                   	ret
    7b1d:	0f 1f 00             	nopl   (%rax)
    7b20:	48 8b 05 91 d0 01 00 	mov    0x1d091(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    7b27:	48 2b 3d 62 d0 01 00 	sub    0x1d062(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    7b2e:	48 c1 e0 10          	shl    $0x10,%rax
    7b32:	48 39 c7             	cmp    %rax,%rdi
    7b35:	73 e1                	jae    7b18 <fwp_caps12+0xb8>
    7b37:	48 89 f8             	mov    %rdi,%rax
    7b3a:	48 c1 e8 10          	shr    $0x10,%rax
    7b3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7b42:	48 8b 05 8f d0 01 00 	mov    0x1d08f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    7b49:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7b4d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7b51:	48 85 c0             	test   %rax,%rax
    7b54:	74 c2                	je     7b18 <fwp_caps12+0xb8>
    7b56:	0f b6 0a             	movzbl (%rdx),%ecx
    7b59:	80 f9 02             	cmp    $0x2,%cl
    7b5c:	74 42                	je     7ba0 <fwp_caps12+0x140>
    7b5e:	80 f9 01             	cmp    $0x1,%cl
    7b61:	75 b5                	jne    7b18 <fwp_caps12+0xb8>
    7b63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b66:	0f b7 ff             	movzwl %di,%edi
    7b69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b6c:	48 0f af f9          	imul   %rcx,%rdi
    7b70:	48 c1 ef 20          	shr    $0x20,%rdi
    7b74:	48 39 d7             	cmp    %rdx,%rdi
    7b77:	73 9f                	jae    7b18 <fwp_caps12+0xb8>
    7b79:	48 01 f8             	add    %rdi,%rax
    7b7c:	0f b6 10             	movzbl (%rax),%edx
    7b7f:	84 d2                	test   %dl,%dl
    7b81:	74 95                	je     7b18 <fwp_caps12+0xb8>
    7b83:	80 fa fd             	cmp    $0xfd,%dl
    7b86:	77 23                	ja     7bab <fwp_caps12+0x14b>
    7b88:	83 c2 01             	add    $0x1,%edx
    7b8b:	88 10                	mov    %dl,(%rax)
    7b8d:	eb 89                	jmp    7b18 <fwp_caps12+0xb8>
    7b8f:	90                   	nop
    7b90:	66 85 d2             	test   %dx,%dx
    7b93:	0f 85 7f ff ff ff    	jne    7b18 <fwp_caps12+0xb8>
    7b99:	e9 58 ff ff ff       	jmp    7af6 <fwp_caps12+0x96>
    7b9e:	66 90                	xchg   %ax,%ax
    7ba0:	66 85 ff             	test   %di,%di
    7ba3:	0f 85 6f ff ff ff    	jne    7b18 <fwp_caps12+0xb8>
    7ba9:	eb d1                	jmp    7b7c <fwp_caps12+0x11c>
    7bab:	48 89 c7             	mov    %rax,%rdi
    7bae:	48 83 c4 18          	add    $0x18,%rsp
    7bb2:	e9 79 d8 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7bb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bbe:	00 00 

0000000000007bc0 <fwp_drop2>:
    7bc0:	48 8b 0d f1 cf 01 00 	mov    0x1cff1(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7bc7:	48 89 f8             	mov    %rdi,%rax
    7bca:	48 2b 05 bf cf 01 00 	sub    0x1cfbf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7bd1:	48 c1 e1 10          	shl    $0x10,%rcx
    7bd5:	48 39 c8             	cmp    %rcx,%rax
    7bd8:	0f 83 42 01 00 00    	jae    7d20 <fwp_drop2+0x160>
    7bde:	48 83 ec 18          	sub    $0x18,%rsp
    7be2:	48 89 fa             	mov    %rdi,%rdx
    7be5:	4c 8d 05 f4 bb 01 00 	lea    0x1bbf4(%rip),%r8        # 237e0 <fwp_heap>
    7bec:	48 89 c1             	mov    %rax,%rcx
    7bef:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7bf6:	48 c1 e9 10          	shr    $0x10,%rcx
    7bfa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7bfe:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7c02:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7c06:	48 85 c9             	test   %rcx,%rcx
    7c09:	74 40                	je     7c4b <fwp_drop2+0x8b>
    7c0b:	0f b6 3e             	movzbl (%rsi),%edi
    7c0e:	40 80 ff 02          	cmp    $0x2,%dil
    7c12:	74 3c                	je     7c50 <fwp_drop2+0x90>
    7c14:	40 80 ff 01          	cmp    $0x1,%dil
    7c18:	75 31                	jne    7c4b <fwp_drop2+0x8b>
    7c1a:	8b 7e 18             	mov    0x18(%rsi),%edi
    7c1d:	0f b7 c0             	movzwl %ax,%eax
    7c20:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7c23:	48 0f af c7          	imul   %rdi,%rax
    7c27:	48 c1 e8 20          	shr    $0x20,%rax
    7c2b:	48 39 f0             	cmp    %rsi,%rax
    7c2e:	73 1b                	jae    7c4b <fwp_drop2+0x8b>
    7c30:	48 01 c1             	add    %rax,%rcx
    7c33:	0f b6 01             	movzbl (%rcx),%eax
    7c36:	84 c0                	test   %al,%al
    7c38:	74 11                	je     7c4b <fwp_drop2+0x8b>
    7c3a:	3c 01                	cmp    $0x1,%al
    7c3c:	74 22                	je     7c60 <fwp_drop2+0xa0>
    7c3e:	3c ff                	cmp    $0xff,%al
    7c40:	0f 84 0a 01 00 00    	je     7d50 <fwp_drop2+0x190>
    7c46:	83 e8 01             	sub    $0x1,%eax
    7c49:	88 01                	mov    %al,(%rcx)
    7c4b:	48 83 c4 18          	add    $0x18,%rsp
    7c4f:	c3                   	ret
    7c50:	66 85 c0             	test   %ax,%ax
    7c53:	74 de                	je     7c33 <fwp_drop2+0x73>
    7c55:	48 83 c4 18          	add    $0x18,%rsp
    7c59:	c3                   	ret
    7c5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c60:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7c64:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7c6b:	48 89 f8             	mov    %rdi,%rax
    7c6e:	48 c1 e1 10          	shl    $0x10,%rcx
    7c72:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7c79:	48 39 c8             	cmp    %rcx,%rax
    7c7c:	73 62                	jae    7ce0 <fwp_drop2+0x120>
    7c7e:	48 89 c1             	mov    %rax,%rcx
    7c81:	48 c1 e9 10          	shr    $0x10,%rcx
    7c85:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7c89:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7c8d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7c91:	48 85 c9             	test   %rcx,%rcx
    7c94:	74 4a                	je     7ce0 <fwp_drop2+0x120>
    7c96:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7c9a:	41 80 f9 02          	cmp    $0x2,%r9b
    7c9e:	0f 84 9c 00 00 00    	je     7d40 <fwp_drop2+0x180>
    7ca4:	41 80 f9 01          	cmp    $0x1,%r9b
    7ca8:	75 36                	jne    7ce0 <fwp_drop2+0x120>
    7caa:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7cae:	0f b7 c0             	movzwl %ax,%eax
    7cb1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7cb4:	49 0f af c1          	imul   %r9,%rax
    7cb8:	48 c1 e8 20          	shr    $0x20,%rax
    7cbc:	48 39 f0             	cmp    %rsi,%rax
    7cbf:	73 1f                	jae    7ce0 <fwp_drop2+0x120>
    7cc1:	48 01 c1             	add    %rax,%rcx
    7cc4:	0f b6 01             	movzbl (%rcx),%eax
    7cc7:	84 c0                	test   %al,%al
    7cc9:	74 15                	je     7ce0 <fwp_drop2+0x120>
    7ccb:	3c 01                	cmp    $0x1,%al
    7ccd:	74 59                	je     7d28 <fwp_drop2+0x168>
    7ccf:	3c ff                	cmp    $0xff,%al
    7cd1:	0f 84 ef 00 00 00    	je     7dc6 <fwp_drop2+0x206>
    7cd7:	83 e8 01             	sub    $0x1,%eax
    7cda:	88 01                	mov    %al,(%rcx)
    7cdc:	0f 1f 40 00          	nopl   0x0(%rax)
    7ce0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7ce4:	48 89 d7             	mov    %rdx,%rdi
    7ce7:	48 89 0c 24          	mov    %rcx,(%rsp)
    7ceb:	e8 d0 ea ff ff       	call   67c0 <fwp_rc_free_arr>
    7cf0:	4c 8d 05 e9 ba 01 00 	lea    0x1bae9(%rip),%r8        # 237e0 <fwp_heap>
    7cf7:	48 8b 04 24          	mov    (%rsp),%rax
    7cfb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7d02:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7d09:	48 c1 e2 10          	shl    $0x10,%rdx
    7d0d:	48 39 d0             	cmp    %rdx,%rax
    7d10:	0f 83 35 ff ff ff    	jae    7c4b <fwp_drop2+0x8b>
    7d16:	48 8b 14 24          	mov    (%rsp),%rdx
    7d1a:	e9 cd fe ff ff       	jmp    7bec <fwp_drop2+0x2c>
    7d1f:	90                   	nop
    7d20:	c3                   	ret
    7d21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d28:	48 89 14 24          	mov    %rdx,(%rsp)
    7d2c:	e8 8f ea ff ff       	call   67c0 <fwp_rc_free_arr>
    7d31:	48 8b 14 24          	mov    (%rsp),%rdx
    7d35:	eb a9                	jmp    7ce0 <fwp_drop2+0x120>
    7d37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d3e:	00 00 
    7d40:	66 85 c0             	test   %ax,%ax
    7d43:	75 9b                	jne    7ce0 <fwp_drop2+0x120>
    7d45:	e9 7a ff ff ff       	jmp    7cc4 <fwp_drop2+0x104>
    7d4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d50:	48 89 c8             	mov    %rcx,%rax
    7d53:	48 c1 e8 11          	shr    $0x11,%rax
    7d57:	48 31 c8             	xor    %rcx,%rax
    7d5a:	48 89 c2             	mov    %rax,%rdx
    7d5d:	48 c1 ea 09          	shr    $0x9,%rdx
    7d61:	48 31 d0             	xor    %rdx,%rax
    7d64:	0f b6 d0             	movzbl %al,%edx
    7d67:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7d6e:	00 
    7d6f:	48 85 c0             	test   %rax,%rax
    7d72:	75 19                	jne    7d8d <fwp_drop2+0x1cd>
    7d74:	e9 d3 00 00 00       	jmp    7e4c <fwp_drop2+0x28c>
    7d79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7d84:	48 85 c0             	test   %rax,%rax
    7d87:	0f 84 bf 00 00 00    	je     7e4c <fwp_drop2+0x28c>
    7d8d:	48 89 c2             	mov    %rax,%rdx
    7d90:	48 39 08             	cmp    %rcx,(%rax)
    7d93:	75 eb                	jne    7d80 <fwp_drop2+0x1c0>
    7d95:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7d99:	48 83 ea 01          	sub    $0x1,%rdx
    7d9d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7da1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7da8:	0f 85 9d fe ff ff    	jne    7c4b <fwp_drop2+0x8b>
    7dae:	48 89 cf             	mov    %rcx,%rdi
    7db1:	48 89 0c 24          	mov    %rcx,(%rsp)
    7db5:	e8 96 d7 ff ff       	call   5550 <fwp_rc_forget_slot>
    7dba:	48 8b 0c 24          	mov    (%rsp),%rcx
    7dbe:	c6 01 fe             	movb   $0xfe,(%rcx)
    7dc1:	e9 85 fe ff ff       	jmp    7c4b <fwp_drop2+0x8b>
    7dc6:	48 89 ce             	mov    %rcx,%rsi
    7dc9:	48 c1 ee 11          	shr    $0x11,%rsi
    7dcd:	48 31 ce             	xor    %rcx,%rsi
    7dd0:	48 89 f0             	mov    %rsi,%rax
    7dd3:	48 c1 e8 09          	shr    $0x9,%rax
    7dd7:	48 31 c6             	xor    %rax,%rsi
    7dda:	40 0f b6 f6          	movzbl %sil,%esi
    7dde:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7de5:	00 
    7de6:	48 85 c0             	test   %rax,%rax
    7de9:	75 1e                	jne    7e09 <fwp_drop2+0x249>
    7deb:	eb 5f                	jmp    7e4c <fwp_drop2+0x28c>
    7ded:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7df4:	00 
    7df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7dfc:	00 00 00 00 
    7e00:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7e04:	48 85 c0             	test   %rax,%rax
    7e07:	74 43                	je     7e4c <fwp_drop2+0x28c>
    7e09:	48 89 c6             	mov    %rax,%rsi
    7e0c:	48 39 08             	cmp    %rcx,(%rax)
    7e0f:	75 ef                	jne    7e00 <fwp_drop2+0x240>
    7e11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e15:	48 83 ee 01          	sub    $0x1,%rsi
    7e19:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7e1d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7e24:	0f 85 b6 fe ff ff    	jne    7ce0 <fwp_drop2+0x120>
    7e2a:	48 89 cf             	mov    %rcx,%rdi
    7e2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e32:	48 89 0c 24          	mov    %rcx,(%rsp)
    7e36:	e8 15 d7 ff ff       	call   5550 <fwp_rc_forget_slot>
    7e3b:	48 8b 0c 24          	mov    (%rsp),%rcx
    7e3f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e44:	c6 01 fe             	movb   $0xfe,(%rcx)
    7e47:	e9 94 fe ff ff       	jmp    7ce0 <fwp_drop2+0x120>
    7e4c:	48 8d 3d 35 7a 00 00 	lea    0x7a35(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    7e53:	e8 98 c5 ff ff       	call   43f0 <fwp_trap>
    7e58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7e5f:	00 

0000000000007e60 <fwp_arg_drop23>:
    7e60:	f3 0f 1e fa          	endbr64
    7e64:	85 f6                	test   %esi,%esi
    7e66:	75 04                	jne    7e6c <fwp_arg_drop23+0xc>
    7e68:	85 d2                	test   %edx,%edx
    7e6a:	75 04                	jne    7e70 <fwp_arg_drop23+0x10>
    7e6c:	c3                   	ret
    7e6d:	0f 1f 00             	nopl   (%rax)
    7e70:	48 8b 3f             	mov    (%rdi),%rdi
    7e73:	e9 48 fd ff ff       	jmp    7bc0 <fwp_drop2>
    7e78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7e7f:	00 

0000000000007e80 <fwp_caps23>:
    7e80:	f3 0f 1e fa          	endbr64
    7e84:	48 83 ec 18          	sub    $0x18,%rsp
    7e88:	8b 57 04             	mov    0x4(%rdi),%edx
    7e8b:	48 89 f8             	mov    %rdi,%rax
    7e8e:	85 d2                	test   %edx,%edx
    7e90:	0f 84 9a 00 00 00    	je     7f30 <fwp_caps23+0xb0>
    7e96:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7e9a:	85 f6                	test   %esi,%esi
    7e9c:	0f 85 9e 00 00 00    	jne    7f40 <fwp_caps23+0xc0>
    7ea2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7ea7:	e8 14 fd ff ff       	call   7bc0 <fwp_drop2>
    7eac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7eb1:	48 8b 0d 00 cd 01 00 	mov    0x1cd00(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7eb8:	48 89 c2             	mov    %rax,%rdx
    7ebb:	48 2b 15 ce cc 01 00 	sub    0x1ccce(%rip),%rdx        # 24b90 <fwp_heap+0x13b0>
    7ec2:	48 c1 e1 10          	shl    $0x10,%rcx
    7ec6:	48 39 ca             	cmp    %rcx,%rdx
    7ec9:	73 6d                	jae    7f38 <fwp_caps23+0xb8>
    7ecb:	48 89 d1             	mov    %rdx,%rcx
    7ece:	48 c1 e9 10          	shr    $0x10,%rcx
    7ed2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7ed6:	48 8b 0d fb cc 01 00 	mov    0x1ccfb(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7edd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7ee1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7ee5:	48 85 f6             	test   %rsi,%rsi
    7ee8:	74 4e                	je     7f38 <fwp_caps23+0xb8>
    7eea:	0f b6 39             	movzbl (%rcx),%edi
    7eed:	40 80 ff 02          	cmp    $0x2,%dil
    7ef1:	0f 84 b9 00 00 00    	je     7fb0 <fwp_caps23+0x130>
    7ef7:	40 80 ff 01          	cmp    $0x1,%dil
    7efb:	75 3b                	jne    7f38 <fwp_caps23+0xb8>
    7efd:	8b 79 18             	mov    0x18(%rcx),%edi
    7f00:	0f b7 d2             	movzwl %dx,%edx
    7f03:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f06:	48 0f af d7          	imul   %rdi,%rdx
    7f0a:	48 c1 ea 20          	shr    $0x20,%rdx
    7f0e:	48 39 ca             	cmp    %rcx,%rdx
    7f11:	73 25                	jae    7f38 <fwp_caps23+0xb8>
    7f13:	48 01 d6             	add    %rdx,%rsi
    7f16:	80 3e 01             	cmpb   $0x1,(%rsi)
    7f19:	75 1d                	jne    7f38 <fwp_caps23+0xb8>
    7f1b:	48 89 c7             	mov    %rax,%rdi
    7f1e:	48 83 c4 18          	add    $0x18,%rsp
    7f22:	e9 69 d8 ff ff       	jmp    5790 <fwp_mem_free>
    7f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f2e:	00 00 
    7f30:	85 f6                	test   %esi,%esi
    7f32:	0f 84 79 ff ff ff    	je     7eb1 <fwp_caps23+0x31>
    7f38:	48 83 c4 18          	add    $0x18,%rsp
    7f3c:	c3                   	ret
    7f3d:	0f 1f 00             	nopl   (%rax)
    7f40:	48 8b 05 71 cc 01 00 	mov    0x1cc71(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    7f47:	48 2b 3d 42 cc 01 00 	sub    0x1cc42(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    7f4e:	48 c1 e0 10          	shl    $0x10,%rax
    7f52:	48 39 c7             	cmp    %rax,%rdi
    7f55:	73 e1                	jae    7f38 <fwp_caps23+0xb8>
    7f57:	48 89 f8             	mov    %rdi,%rax
    7f5a:	48 c1 e8 10          	shr    $0x10,%rax
    7f5e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7f62:	48 8b 05 6f cc 01 00 	mov    0x1cc6f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    7f69:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7f6d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7f71:	48 85 c0             	test   %rax,%rax
    7f74:	74 c2                	je     7f38 <fwp_caps23+0xb8>
    7f76:	0f b6 0a             	movzbl (%rdx),%ecx
    7f79:	80 f9 02             	cmp    $0x2,%cl
    7f7c:	74 42                	je     7fc0 <fwp_caps23+0x140>
    7f7e:	80 f9 01             	cmp    $0x1,%cl
    7f81:	75 b5                	jne    7f38 <fwp_caps23+0xb8>
    7f83:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f86:	0f b7 ff             	movzwl %di,%edi
    7f89:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f8c:	48 0f af f9          	imul   %rcx,%rdi
    7f90:	48 c1 ef 20          	shr    $0x20,%rdi
    7f94:	48 39 d7             	cmp    %rdx,%rdi
    7f97:	73 9f                	jae    7f38 <fwp_caps23+0xb8>
    7f99:	48 01 f8             	add    %rdi,%rax
    7f9c:	0f b6 10             	movzbl (%rax),%edx
    7f9f:	84 d2                	test   %dl,%dl
    7fa1:	74 95                	je     7f38 <fwp_caps23+0xb8>
    7fa3:	80 fa fd             	cmp    $0xfd,%dl
    7fa6:	77 23                	ja     7fcb <fwp_caps23+0x14b>
    7fa8:	83 c2 01             	add    $0x1,%edx
    7fab:	88 10                	mov    %dl,(%rax)
    7fad:	eb 89                	jmp    7f38 <fwp_caps23+0xb8>
    7faf:	90                   	nop
    7fb0:	66 85 d2             	test   %dx,%dx
    7fb3:	0f 85 7f ff ff ff    	jne    7f38 <fwp_caps23+0xb8>
    7fb9:	e9 58 ff ff ff       	jmp    7f16 <fwp_caps23+0x96>
    7fbe:	66 90                	xchg   %ax,%ax
    7fc0:	66 85 ff             	test   %di,%di
    7fc3:	0f 85 6f ff ff ff    	jne    7f38 <fwp_caps23+0xb8>
    7fc9:	eb d1                	jmp    7f9c <fwp_caps23+0x11c>
    7fcb:	48 89 c7             	mov    %rax,%rdi
    7fce:	48 83 c4 18          	add    $0x18,%rsp
    7fd2:	e9 59 d4 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fde:	00 00 

0000000000007fe0 <f23>:
    7fe0:	41 57                	push   %r15
    7fe2:	41 56                	push   %r14
    7fe4:	41 55                	push   %r13
    7fe6:	41 54                	push   %r12
    7fe8:	55                   	push   %rbp
    7fe9:	53                   	push   %rbx
    7fea:	48 83 ec 38          	sub    $0x38,%rsp
    7fee:	48 8b 15 c3 cb 01 00 	mov    0x1cbc3(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7ff5:	48 8b 0d 94 cb 01 00 	mov    0x1cb94(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    7ffc:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8003:	00 00 
    8005:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    800a:	49 89 fc             	mov    %rdi,%r12
    800d:	48 c1 e2 10          	shl    $0x10,%rdx
    8011:	48 85 ff             	test   %rdi,%rdi
    8014:	0f 84 bc 02 00 00    	je     82d6 <f23+0x2f6>
    801a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    801f:	48 89 d8             	mov    %rbx,%rax
    8022:	48 29 c8             	sub    %rcx,%rax
    8025:	48 39 d0             	cmp    %rdx,%rax
    8028:	0f 83 72 03 00 00    	jae    83a0 <f23+0x3c0>
    802e:	48 89 c2             	mov    %rax,%rdx
    8031:	48 c1 ea 10          	shr    $0x10,%rdx
    8035:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8039:	48 8b 15 98 cb 01 00 	mov    0x1cb98(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8040:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8044:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8048:	48 85 ff             	test   %rdi,%rdi
    804b:	0f 84 4f 03 00 00    	je     83a0 <f23+0x3c0>
    8051:	0f b6 0a             	movzbl (%rdx),%ecx
    8054:	80 f9 02             	cmp    $0x2,%cl
    8057:	0f 84 53 02 00 00    	je     82b0 <f23+0x2d0>
    805d:	80 f9 01             	cmp    $0x1,%cl
    8060:	75 24                	jne    8086 <f23+0xa6>
    8062:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8065:	0f b7 c0             	movzwl %ax,%eax
    8068:	8b 52 1c             	mov    0x1c(%rdx),%edx
    806b:	48 0f af c1          	imul   %rcx,%rax
    806f:	48 c1 e8 20          	shr    $0x20,%rax
    8073:	48 39 d0             	cmp    %rdx,%rax
    8076:	73 0e                	jae    8086 <f23+0xa6>
    8078:	48 01 c7             	add    %rax,%rdi
    807b:	0f b6 07             	movzbl (%rdi),%eax
    807e:	84 c0                	test   %al,%al
    8080:	0f 85 ca 02 00 00    	jne    8350 <f23+0x370>
    8086:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    808b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    8090:	ba 01 00 00 00       	mov    $0x1,%edx
    8095:	48 85 db             	test   %rbx,%rbx
    8098:	74 13                	je     80ad <f23+0xcd>
    809a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80a0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    80a4:	48 83 c2 01          	add    $0x1,%rdx
    80a8:	48 85 db             	test   %rbx,%rbx
    80ab:	75 f3                	jne    80a0 <f23+0xc0>
    80ad:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    80b2:	48 85 c0             	test   %rax,%rax
    80b5:	0f 84 15 03 00 00    	je     83d0 <f23+0x3f0>
    80bb:	31 db                	xor    %ebx,%ebx
    80bd:	0f 1f 00             	nopl   (%rax)
    80c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    80c4:	48 83 c3 01          	add    $0x1,%rbx
    80c8:	48 85 c0             	test   %rax,%rax
    80cb:	75 f3                	jne    80c0 <f23+0xe0>
    80cd:	48 39 d3             	cmp    %rdx,%rbx
    80d0:	48 0f 47 da          	cmova  %rdx,%rbx
    80d4:	48 89 d8             	mov    %rbx,%rax
    80d7:	48 c1 e8 3c          	shr    $0x3c,%rax
    80db:	0f 85 8f 03 00 00    	jne    8470 <f23+0x490>
    80e1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    80e5:	be 02 00 00 00       	mov    $0x2,%esi
    80ea:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    80f1:	00 
    80f2:	e8 99 db ff ff       	call   5c90 <fwp_heap_alloc>
    80f7:	48 89 28             	mov    %rbp,(%rax)
    80fa:	48 8b 15 b7 ca 01 00 	mov    0x1cab7(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8101:	49 89 c6             	mov    %rax,%r14
    8104:	48 2b 05 85 ca 01 00 	sub    0x1ca85(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    810b:	48 c1 e2 10          	shl    $0x10,%rdx
    810f:	48 39 d0             	cmp    %rdx,%rax
    8112:	73 57                	jae    816b <f23+0x18b>
    8114:	48 89 c2             	mov    %rax,%rdx
    8117:	48 c1 ea 10          	shr    $0x10,%rdx
    811b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    811f:	48 8b 15 b2 ca 01 00 	mov    0x1cab2(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8126:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    812a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    812e:	48 85 ed             	test   %rbp,%rbp
    8131:	74 38                	je     816b <f23+0x18b>
    8133:	0f b6 0a             	movzbl (%rdx),%ecx
    8136:	80 f9 02             	cmp    $0x2,%cl
    8139:	0f 84 51 02 00 00    	je     8390 <f23+0x3b0>
    813f:	80 f9 01             	cmp    $0x1,%cl
    8142:	75 27                	jne    816b <f23+0x18b>
    8144:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8147:	0f b7 c0             	movzwl %ax,%eax
    814a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    814d:	48 0f af c1          	imul   %rcx,%rax
    8151:	48 c1 e8 20          	shr    $0x20,%rax
    8155:	48 39 d0             	cmp    %rdx,%rax
    8158:	73 11                	jae    816b <f23+0x18b>
    815a:	48 01 c5             	add    %rax,%rbp
    815d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8161:	0f 84 d5 02 00 00    	je     843c <f23+0x45c>
    8167:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    816b:	48 85 db             	test   %rbx,%rbx
    816e:	74 5d                	je     81cd <f23+0x1ed>
    8170:	48 c1 e3 04          	shl    $0x4,%rbx
    8174:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    8179:	4c 89 f5             	mov    %r14,%rbp
    817c:	4d 89 e5             	mov    %r12,%r13
    817f:	4c 01 f3             	add    %r14,%rbx
    8182:	0f 1f 00             	nopl   (%rax)
    8185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    818c:	00 00 00 00 
    8190:	49 8b 45 08          	mov    0x8(%r13),%rax
    8194:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8198:	48 83 c5 10          	add    $0x10,%rbp
    819c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    81a1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    81a5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    81a9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    81ae:	e8 bd e1 ff ff       	call   6370 <w107>
    81b3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    81b8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    81bc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    81c0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    81c4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    81c8:	48 39 dd             	cmp    %rbx,%rbp
    81cb:	75 c3                	jne    8190 <f23+0x1b0>
    81cd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    81d2:	e8 e9 f9 ff ff       	call   7bc0 <fwp_drop2>
    81d7:	4c 89 e7             	mov    %r12,%rdi
    81da:	e8 e1 f9 ff ff       	call   7bc0 <fwp_drop2>
    81df:	4c 89 f7             	mov    %r14,%rdi
    81e2:	e8 f9 e2 ff ff       	call   64e0 <w164.constprop.0>
    81e7:	4c 89 f7             	mov    %r14,%rdi
    81ea:	48 89 c3             	mov    %rax,%rbx
    81ed:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    81f3:	e8 c8 f4 ff ff       	call   76c0 <fwp_drop4>
    81f8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    81fe:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8203:	31 ff                	xor    %edi,%edi
    8205:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    820a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    820e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8213:	e8 48 e3 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    8218:	48 8b 15 99 c9 01 00 	mov    0x1c999(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    821f:	48 89 c5             	mov    %rax,%rbp
    8222:	48 2b 05 67 c9 01 00 	sub    0x1c967(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8229:	48 c1 e2 10          	shl    $0x10,%rdx
    822d:	48 39 d0             	cmp    %rdx,%rax
    8230:	73 55                	jae    8287 <f23+0x2a7>
    8232:	48 89 c2             	mov    %rax,%rdx
    8235:	48 c1 ea 10          	shr    $0x10,%rdx
    8239:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    823d:	48 8b 15 94 c9 01 00 	mov    0x1c994(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8244:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8248:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    824c:	48 85 db             	test   %rbx,%rbx
    824f:	74 36                	je     8287 <f23+0x2a7>
    8251:	0f b6 0a             	movzbl (%rdx),%ecx
    8254:	80 f9 02             	cmp    $0x2,%cl
    8257:	0f 84 1b 01 00 00    	je     8378 <f23+0x398>
    825d:	80 f9 01             	cmp    $0x1,%cl
    8260:	75 25                	jne    8287 <f23+0x2a7>
    8262:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8265:	0f b7 c0             	movzwl %ax,%eax
    8268:	8b 52 1c             	mov    0x1c(%rdx),%edx
    826b:	48 0f af c1          	imul   %rcx,%rax
    826f:	48 c1 e8 20          	shr    $0x20,%rax
    8273:	48 39 d0             	cmp    %rdx,%rax
    8276:	73 0f                	jae    8287 <f23+0x2a7>
    8278:	48 01 c3             	add    %rax,%rbx
    827b:	80 3b ff             	cmpb   $0xff,(%rbx)
    827e:	0f 84 ab 01 00 00    	je     842f <f23+0x44f>
    8284:	c6 03 01             	movb   $0x1,(%rbx)
    8287:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    828c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8293:	00 00 
    8295:	0f 85 d0 01 00 00    	jne    846b <f23+0x48b>
    829b:	48 83 c4 38          	add    $0x38,%rsp
    829f:	48 89 e8             	mov    %rbp,%rax
    82a2:	5b                   	pop    %rbx
    82a3:	5d                   	pop    %rbp
    82a4:	41 5c                	pop    %r12
    82a6:	41 5d                	pop    %r13
    82a8:	41 5e                	pop    %r14
    82aa:	41 5f                	pop    %r15
    82ac:	c3                   	ret
    82ad:	0f 1f 00             	nopl   (%rax)
    82b0:	66 85 c0             	test   %ax,%ax
    82b3:	0f 85 cd fd ff ff    	jne    8086 <f23+0xa6>
    82b9:	0f b6 07             	movzbl (%rdi),%eax
    82bc:	84 c0                	test   %al,%al
    82be:	0f 84 c2 fd ff ff    	je     8086 <f23+0xa6>
    82c4:	3c fd                	cmp    $0xfd,%al
    82c6:	0f 87 95 01 00 00    	ja     8461 <f23+0x481>
    82cc:	83 c0 01             	add    $0x1,%eax
    82cf:	88 07                	mov    %al,(%rdi)
    82d1:	e9 b0 fd ff ff       	jmp    8086 <f23+0xa6>
    82d6:	48 f7 d9             	neg    %rcx
    82d9:	48 39 d1             	cmp    %rdx,%rcx
    82dc:	0f 83 ee 00 00 00    	jae    83d0 <f23+0x3f0>
    82e2:	48 89 c8             	mov    %rcx,%rax
    82e5:	48 c1 e8 10          	shr    $0x10,%rax
    82e9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    82ed:	48 8b 05 e4 c8 01 00 	mov    0x1c8e4(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    82f4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    82f8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    82fc:	48 85 ff             	test   %rdi,%rdi
    82ff:	0f 84 cb 00 00 00    	je     83d0 <f23+0x3f0>
    8305:	0f b6 02             	movzbl (%rdx),%eax
    8308:	3c 02                	cmp    $0x2,%al
    830a:	0f 84 9a 00 00 00    	je     83aa <f23+0x3ca>
    8310:	3c 01                	cmp    $0x1,%al
    8312:	0f 85 b8 00 00 00    	jne    83d0 <f23+0x3f0>
    8318:	0f b7 c1             	movzwl %cx,%eax
    831b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    831e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8321:	48 0f af c1          	imul   %rcx,%rax
    8325:	48 c1 e8 20          	shr    $0x20,%rax
    8329:	48 39 d0             	cmp    %rdx,%rax
    832c:	0f 83 9e 00 00 00    	jae    83d0 <f23+0x3f0>
    8332:	48 01 c7             	add    %rax,%rdi
    8335:	0f b6 07             	movzbl (%rdi),%eax
    8338:	84 c0                	test   %al,%al
    833a:	0f 84 90 00 00 00    	je     83d0 <f23+0x3f0>
    8340:	31 db                	xor    %ebx,%ebx
    8342:	0f 1f 00             	nopl   (%rax)
    8345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    834c:	00 00 00 00 
    8350:	3c fd                	cmp    $0xfd,%al
    8352:	0f 87 f1 00 00 00    	ja     8449 <f23+0x469>
    8358:	83 c0 01             	add    $0x1,%eax
    835b:	88 07                	mov    %al,(%rdi)
    835d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8362:	31 d2                	xor    %edx,%edx
    8364:	4d 85 e4             	test   %r12,%r12
    8367:	0f 85 1e fd ff ff    	jne    808b <f23+0xab>
    836d:	e9 3b fd ff ff       	jmp    80ad <f23+0xcd>
    8372:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8378:	66 85 c0             	test   %ax,%ax
    837b:	0f 85 06 ff ff ff    	jne    8287 <f23+0x2a7>
    8381:	e9 f5 fe ff ff       	jmp    827b <f23+0x29b>
    8386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    838d:	00 00 00 
    8390:	66 85 c0             	test   %ax,%ax
    8393:	0f 85 d2 fd ff ff    	jne    816b <f23+0x18b>
    8399:	e9 bf fd ff ff       	jmp    815d <f23+0x17d>
    839e:	66 90                	xchg   %ax,%ax
    83a0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    83a5:	e9 e6 fc ff ff       	jmp    8090 <f23+0xb0>
    83aa:	66 85 c9             	test   %cx,%cx
    83ad:	75 21                	jne    83d0 <f23+0x3f0>
    83af:	0f b6 07             	movzbl (%rdi),%eax
    83b2:	84 c0                	test   %al,%al
    83b4:	74 1a                	je     83d0 <f23+0x3f0>
    83b6:	3c fd                	cmp    $0xfd,%al
    83b8:	0f 87 be 00 00 00    	ja     847c <f23+0x49c>
    83be:	83 c0 01             	add    $0x1,%eax
    83c1:	88 07                	mov    %al,(%rdi)
    83c3:	66 90                	xchg   %ax,%ax
    83c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83cc:	00 00 00 00 
    83d0:	be 02 00 00 00       	mov    $0x2,%esi
    83d5:	bf 08 00 00 00       	mov    $0x8,%edi
    83da:	e8 b1 d8 ff ff       	call   5c90 <fwp_heap_alloc>
    83df:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    83e6:	48 8b 15 cb c7 01 00 	mov    0x1c7cb(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    83ed:	49 89 c6             	mov    %rax,%r14
    83f0:	48 2b 05 99 c7 01 00 	sub    0x1c799(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    83f7:	48 c1 e2 10          	shl    $0x10,%rdx
    83fb:	48 39 d0             	cmp    %rdx,%rax
    83fe:	73 53                	jae    8453 <f23+0x473>
    8400:	48 89 c2             	mov    %rax,%rdx
    8403:	48 c1 ea 10          	shr    $0x10,%rdx
    8407:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    840b:	48 8b 15 c6 c7 01 00 	mov    0x1c7c6(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8412:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8416:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    841a:	48 85 ed             	test   %rbp,%rbp
    841d:	74 34                	je     8453 <f23+0x473>
    841f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8426:	00 00 
    8428:	31 db                	xor    %ebx,%ebx
    842a:	e9 04 fd ff ff       	jmp    8133 <f23+0x153>
    842f:	48 89 df             	mov    %rbx,%rdi
    8432:	e8 19 d1 ff ff       	call   5550 <fwp_rc_forget_slot>
    8437:	e9 48 fe ff ff       	jmp    8284 <f23+0x2a4>
    843c:	48 89 ef             	mov    %rbp,%rdi
    843f:	e8 0c d1 ff ff       	call   5550 <fwp_rc_forget_slot>
    8444:	e9 1e fd ff ff       	jmp    8167 <f23+0x187>
    8449:	e8 e2 cf ff ff       	call   5430 <fwp_rc_wide_dup>
    844e:	e9 0a ff ff ff       	jmp    835d <f23+0x37d>
    8453:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    845a:	00 00 
    845c:	e9 6c fd ff ff       	jmp    81cd <f23+0x1ed>
    8461:	e8 ca cf ff ff       	call   5430 <fwp_rc_wide_dup>
    8466:	e9 1b fc ff ff       	jmp    8086 <f23+0xa6>
    846b:	e8 f0 af ff ff       	call   3460 <__stack_chk_fail@plt>
    8470:	48 8d 3d 19 6d 00 00 	lea    0x6d19(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    8477:	e8 74 bf ff ff       	call   43f0 <fwp_trap>
    847c:	e8 af cf ff ff       	call   5430 <fwp_rc_wide_dup>
    8481:	e9 4a ff ff ff       	jmp    83d0 <f23+0x3f0>
    8486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    848d:	00 00 00 

0000000000008490 <fwp_owned_entry23>:
    8490:	f3 0f 1e fa          	endbr64
    8494:	48 8b 3f             	mov    (%rdi),%rdi
    8497:	e9 44 fb ff ff       	jmp    7fe0 <f23>
    849c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000084a0 <e23>:
    84a0:	f3 0f 1e fa          	endbr64
    84a4:	53                   	push   %rbx
    84a5:	48 8b 1f             	mov    (%rdi),%rbx
    84a8:	48 89 df             	mov    %rbx,%rdi
    84ab:	e8 e0 e1 ff ff       	call   6690 <fwp_rc_share>
    84b0:	48 89 df             	mov    %rbx,%rdi
    84b3:	e8 28 fb ff ff       	call   7fe0 <f23>
    84b8:	48 89 c3             	mov    %rax,%rbx
    84bb:	48 89 c7             	mov    %rax,%rdi
    84be:	e8 cd e1 ff ff       	call   6690 <fwp_rc_share>
    84c3:	48 89 d8             	mov    %rbx,%rax
    84c6:	5b                   	pop    %rbx
    84c7:	c3                   	ret
    84c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    84cf:	00 

00000000000084d0 <f12>:
    84d0:	41 57                	push   %r15
    84d2:	41 56                	push   %r14
    84d4:	41 55                	push   %r13
    84d6:	4c 8d 2d 03 ec ff ff 	lea    -0x13fd(%rip),%r13        # 70e0 <fwp_tape_scope_release>
    84dd:	41 54                	push   %r12
    84df:	55                   	push   %rbp
    84e0:	53                   	push   %rbx
    84e1:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    84e8:	48 8b 05 89 cf 01 00 	mov    0x1cf89(%rip),%rax        # 25478 <fwp_cleanups>
    84ef:	48 8b 15 c2 c6 01 00 	mov    0x1c6c2(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    84f6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    84fd:	00 00 
    84ff:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    8506:	00 
    8507:	48 89 fd             	mov    %rdi,%rbp
    850a:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    8511:	ff 
    8512:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    8517:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    851c:	48 c1 e2 10          	shl    $0x10,%rdx
    8520:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    8525:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    852a:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    852f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    8534:	48 89 05 3d cf 01 00 	mov    %rax,0x1cf3d(%rip)        # 25478 <fwp_cleanups>
    853b:	48 8d 05 ce aa 00 00 	lea    0xaace(%rip),%rax        # 13010 <fc23>
    8542:	48 2b 05 47 c6 01 00 	sub    0x1c647(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8549:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    854e:	48 39 d0             	cmp    %rdx,%rax
    8551:	73 5d                	jae    85b0 <f12+0xe0>
    8553:	48 89 c2             	mov    %rax,%rdx
    8556:	48 c1 ea 10          	shr    $0x10,%rdx
    855a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    855e:	48 8b 15 73 c6 01 00 	mov    0x1c673(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8565:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8569:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    856d:	48 85 ff             	test   %rdi,%rdi
    8570:	74 3e                	je     85b0 <f12+0xe0>
    8572:	0f b6 0a             	movzbl (%rdx),%ecx
    8575:	80 f9 02             	cmp    $0x2,%cl
    8578:	0f 84 3a 0f 00 00    	je     94b8 <f12+0xfe8>
    857e:	80 f9 01             	cmp    $0x1,%cl
    8581:	75 2d                	jne    85b0 <f12+0xe0>
    8583:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8586:	0f b7 c0             	movzwl %ax,%eax
    8589:	8b 52 1c             	mov    0x1c(%rdx),%edx
    858c:	48 0f af c1          	imul   %rcx,%rax
    8590:	48 c1 e8 20          	shr    $0x20,%rax
    8594:	48 39 d0             	cmp    %rdx,%rax
    8597:	73 17                	jae    85b0 <f12+0xe0>
    8599:	48 01 c7             	add    %rax,%rdi
    859c:	0f b6 07             	movzbl (%rdi),%eax
    859f:	84 c0                	test   %al,%al
    85a1:	74 0d                	je     85b0 <f12+0xe0>
    85a3:	3c fd                	cmp    $0xfd,%al
    85a5:	0f 87 83 11 00 00    	ja     972e <f12+0x125e>
    85ab:	83 c0 01             	add    $0x1,%eax
    85ae:	88 07                	mov    %al,(%rdi)
    85b0:	48 8d 3d 59 aa 00 00 	lea    0xaa59(%rip),%rdi        # 13010 <fc23>
    85b7:	e8 f4 e7 ff ff       	call   6db0 <fwp_closure_drop>
    85bc:	48 85 ed             	test   %rbp,%rbp
    85bf:	0f 84 ca 10 00 00    	je     968f <f12+0x11bf>
    85c5:	48 89 e8             	mov    %rbp,%rax
    85c8:	31 db                	xor    %ebx,%ebx
    85ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    85d0:	48 8b 40 10          	mov    0x10(%rax),%rax
    85d4:	48 83 c3 01          	add    $0x1,%rbx
    85d8:	48 85 c0             	test   %rax,%rax
    85db:	75 f3                	jne    85d0 <f12+0x100>
    85dd:	31 ff                	xor    %edi,%edi
    85df:	e8 6c bc ff ff       	call   4250 <descent_phase_step>
    85e4:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    85eb:	0f 87 b5 11 00 00    	ja     97a6 <f12+0x12d6>
    85f1:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    85f6:	8b 35 84 aa 00 00    	mov    0xaa84(%rip),%esi        # 13080 <registered_finish.0>
    85fc:	85 f6                	test   %esi,%esi
    85fe:	0f 84 84 0e 00 00    	je     9488 <f12+0xfb8>
    8604:	48 8b 1d ed aa 01 00 	mov    0x1aaed(%rip),%rbx        # 230f8 <fwp_tape_next_slot>
    860b:	4c 8b 25 f6 aa 01 00 	mov    0x1aaf6(%rip),%r12        # 23108 <fwp_ntapes>
    8612:	4c 39 e3             	cmp    %r12,%rbx
    8615:	0f 8d d5 05 00 00    	jge    8bf0 <f12+0x720>
    861b:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    861f:	48 03 05 ea aa 01 00 	add    0x1aaea(%rip),%rax        # 23110 <fwp_tapes>
    8626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    862d:	00 00 00 
    8630:	8b 48 04             	mov    0x4(%rax),%ecx
    8633:	85 c9                	test   %ecx,%ecx
    8635:	75 0c                	jne    8643 <f12+0x173>
    8637:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    863d:	0f 86 ad 05 00 00    	jbe    8bf0 <f12+0x720>
    8643:	48 83 c3 01          	add    $0x1,%rbx
    8647:	48 83 c0 68          	add    $0x68,%rax
    864b:	4c 39 e3             	cmp    %r12,%rbx
    864e:	75 e0                	jne    8630 <f12+0x160>
    8650:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    8657:	0f 8f 6d 11 00 00    	jg     97ca <f12+0x12fa>
    865d:	4c 39 25 9c aa 01 00 	cmp    %r12,0x1aa9c(%rip)        # 23100 <fwp_tapes_cap>
    8664:	4c 8b 35 a5 aa 01 00 	mov    0x1aaa5(%rip),%r14        # 23110 <fwp_tapes>
    866b:	75 40                	jne    86ad <f12+0x1dd>
    866d:	4d 85 e4             	test   %r12,%r12
    8670:	0f 85 b2 0f 00 00    	jne    9628 <f12+0x1158>
    8676:	be 68 00 00 00       	mov    $0x68,%esi
    867b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    8681:	4c 89 f7             	mov    %r14,%rdi
    8684:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8689:	e8 42 af ff ff       	call   35d0 <realloc@plt>
    868e:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8693:	48 85 c0             	test   %rax,%rax
    8696:	49 89 c6             	mov    %rax,%r14
    8699:	0f 84 66 0e 00 00    	je     9505 <f12+0x1035>
    869f:	48 89 05 6a aa 01 00 	mov    %rax,0x1aa6a(%rip)        # 23110 <fwp_tapes>
    86a6:	4c 89 3d 53 aa 01 00 	mov    %r15,0x1aa53(%rip)        # 23100 <fwp_tapes_cap>
    86ad:	49 6b c4 68          	imul   $0x68,%r12,%rax
    86b1:	49 83 c4 01          	add    $0x1,%r12
    86b5:	4c 01 f0             	add    %r14,%rax
    86b8:	48 8d 78 08          	lea    0x8(%rax),%rdi
    86bc:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    86c3:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    86c7:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    86ce:	00 
    86cf:	48 29 f8             	sub    %rdi,%rax
    86d2:	8d 48 68             	lea    0x68(%rax),%ecx
    86d5:	31 c0                	xor    %eax,%eax
    86d7:	c1 e9 03             	shr    $0x3,%ecx
    86da:	f3 48 ab             	rep stos %rax,(%rdi)
    86dd:	4c 89 25 24 aa 01 00 	mov    %r12,0x1aa24(%rip)        # 23108 <fwp_ntapes>
    86e4:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    86e8:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    86ec:	48 8d 3d 2f 6a 00 00 	lea    0x6a2f(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    86f3:	0f 29 04 24          	movaps %xmm0,(%rsp)
    86f7:	4d 01 f4             	add    %r14,%r12
    86fa:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    8701:	00 00 
    8703:	e8 98 ac ff ff       	call   33a0 <getenv@plt>
    8708:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    870d:	48 85 c0             	test   %rax,%rax
    8710:	74 09                	je     871b <f12+0x24b>
    8712:	80 38 30             	cmpb   $0x30,(%rax)
    8715:	0f 84 25 04 00 00    	je     8b40 <f12+0x670>
    871b:	48 83 3d 85 a9 01 00 	cmpq   $0x0,0x1a985(%rip)        # 230a8 <fwp_tape_cached_bytes>
    8722:	00 
    8723:	0f 85 37 0e 00 00    	jne    9560 <f12+0x1090>
    8729:	41 8b 04 24          	mov    (%r12),%eax
    872d:	4c 8d 43 01          	lea    0x1(%rbx),%r8
    8731:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    8738:	00 00 
    873a:	4c 89 05 b7 a9 01 00 	mov    %r8,0x1a9b7(%rip)        # 230f8 <fwp_tape_next_slot>
    8741:	8d 70 01             	lea    0x1(%rax),%esi
    8744:	48 8b 05 2d cd 01 00 	mov    0x1cd2d(%rip),%rax        # 25478 <fwp_cleanups>
    874b:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    8752:	00 00 
    8754:	41 89 34 24          	mov    %esi,(%r12)
    8758:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    875f:	ff ff 
    8761:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    8767:	48 85 c0             	test   %rax,%rax
    876a:	75 20                	jne    878c <f12+0x2bc>
    876c:	e9 76 10 00 00       	jmp    97e7 <f12+0x1317>
    8771:	0f 1f 40 00          	nopl   0x0(%rax)
    8775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    877c:	00 00 00 00 
    8780:	48 8b 00             	mov    (%rax),%rax
    8783:	48 85 c0             	test   %rax,%rax
    8786:	0f 84 5b 10 00 00    	je     97e7 <f12+0x1317>
    878c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8790:	75 ee                	jne    8780 <f12+0x2b0>
    8792:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8796:	89 df                	mov    %ebx,%edi
    8798:	48 63 01             	movslq (%rcx),%rax
    879b:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    87a0:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    87a5:	85 c0                	test   %eax,%eax
    87a7:	78 09                	js     87b2 <f12+0x2e2>
    87a9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    87ad:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    87b2:	89 39                	mov    %edi,(%rcx)
    87b4:	bf 01 00 00 00       	mov    $0x1,%edi
    87b9:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    87be:	89 34 24             	mov    %esi,(%rsp)
    87c1:	e8 8a ba ff ff       	call   4250 <descent_phase_step>
    87c6:	31 c9                	xor    %ecx,%ecx
    87c8:	48 85 ed             	test   %rbp,%rbp
    87cb:	8b 34 24             	mov    (%rsp),%esi
    87ce:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    87d3:	48 89 e8             	mov    %rbp,%rax
    87d6:	0f 84 74 03 00 00    	je     8b50 <f12+0x680>
    87dc:	0f 1f 40 00          	nopl   0x0(%rax)
    87e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    87e4:	48 83 c1 01          	add    $0x1,%rcx
    87e8:	48 85 c0             	test   %rax,%rax
    87eb:	75 f3                	jne    87e0 <f12+0x310>
    87ed:	48 89 ea             	mov    %rbp,%rdx
    87f0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    87f4:	48 83 c0 01          	add    $0x1,%rax
    87f8:	48 85 d2             	test   %rdx,%rdx
    87fb:	75 f3                	jne    87f0 <f12+0x320>
    87fd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8804:	ff ff 1f 
    8807:	48 39 c2             	cmp    %rax,%rdx
    880a:	0f 82 a2 0f 00 00    	jb     97b2 <f12+0x12e2>
    8810:	48 85 c9             	test   %rcx,%rcx
    8813:	0f 8e 37 03 00 00    	jle    8b50 <f12+0x680>
    8819:	48 39 c1             	cmp    %rax,%rcx
    881c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8820:	49 89 c5             	mov    %rax,%r13
    8823:	48 c1 e8 3c          	shr    $0x3c,%rax
    8827:	0f 85 85 0f 00 00    	jne    97b2 <f12+0x12e2>
    882d:	48 c1 e6 10          	shl    $0x10,%rsi
    8831:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    8836:	4c 09 c6             	or     %r8,%rsi
    8839:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8840:	00 
    8841:	49 89 f4             	mov    %rsi,%r12
    8844:	be 02 00 00 00       	mov    $0x2,%esi
    8849:	e8 42 d4 ff ff       	call   5c90 <fwp_heap_alloc>
    884e:	4c 89 30             	mov    %r14,(%rax)
    8851:	48 8b 15 60 c3 01 00 	mov    0x1c360(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8858:	48 89 c3             	mov    %rax,%rbx
    885b:	48 2b 05 2e c3 01 00 	sub    0x1c32e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8862:	48 c1 e2 10          	shl    $0x10,%rdx
    8866:	48 39 d0             	cmp    %rdx,%rax
    8869:	0f 83 61 03 00 00    	jae    8bd0 <f12+0x700>
    886f:	48 89 c2             	mov    %rax,%rdx
    8872:	48 c1 ea 10          	shr    $0x10,%rdx
    8876:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    887a:	48 8b 15 57 c3 01 00 	mov    0x1c357(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8881:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8885:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8889:	48 85 d2             	test   %rdx,%rdx
    888c:	74 38                	je     88c6 <f12+0x3f6>
    888e:	0f b6 31             	movzbl (%rcx),%esi
    8891:	40 80 fe 02          	cmp    $0x2,%sil
    8895:	0f 84 22 03 00 00    	je     8bbd <f12+0x6ed>
    889b:	40 80 fe 01          	cmp    $0x1,%sil
    889f:	75 25                	jne    88c6 <f12+0x3f6>
    88a1:	8b 71 18             	mov    0x18(%rcx),%esi
    88a4:	0f b7 c0             	movzwl %ax,%eax
    88a7:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    88aa:	48 0f af c6          	imul   %rsi,%rax
    88ae:	48 c1 e8 20          	shr    $0x20,%rax
    88b2:	48 39 c8             	cmp    %rcx,%rax
    88b5:	73 0f                	jae    88c6 <f12+0x3f6>
    88b7:	48 01 c2             	add    %rax,%rdx
    88ba:	80 3a ff             	cmpb   $0xff,(%rdx)
    88bd:	0f 84 34 0e 00 00    	je     96f7 <f12+0x1227>
    88c3:	c6 02 01             	movb   $0x1,(%rdx)
    88c6:	4d 85 ed             	test   %r13,%r13
    88c9:	74 68                	je     8933 <f12+0x463>
    88cb:	4c 89 e1             	mov    %r12,%rcx
    88ce:	48 89 ea             	mov    %rbp,%rdx
    88d1:	31 c0                	xor    %eax,%eax
    88d3:	48 c1 e1 20          	shl    $0x20,%rcx
    88d7:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    88de:	00 
    88df:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88e6:	00 00 00 00 
    88ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88f1:	00 00 00 00 
    88f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88fc:	00 00 00 00 
    8900:	48 89 c6             	mov    %rax,%rsi
    8903:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8908:	48 01 ce             	add    %rcx,%rsi
    890b:	0f 80 88 0e 00 00    	jo     9799 <f12+0x12c9>
    8911:	66 48 0f 6e de       	movq   %rsi,%xmm3
    8916:	48 89 c6             	mov    %rax,%rsi
    8919:	48 83 c0 01          	add    $0x1,%rax
    891d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    8921:	48 c1 e6 04          	shl    $0x4,%rsi
    8925:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    892a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    892e:	4c 39 e8             	cmp    %r13,%rax
    8931:	72 cd                	jb     8900 <f12+0x430>
    8933:	48 8b 03             	mov    (%rbx),%rax
    8936:	48 d1 e8             	shr    $1,%rax
    8939:	0f 84 a1 02 00 00    	je     8be0 <f12+0x710>
    893f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8943:	48 89 d1             	mov    %rdx,%rcx
    8946:	48 c1 e9 3c          	shr    $0x3c,%rcx
    894a:	0f 85 62 0e 00 00    	jne    97b2 <f12+0x12e2>
    8950:	4c 8d 34 12          	lea    (%rdx,%rdx,1),%r14
    8954:	48 85 d2             	test   %rdx,%rdx
    8957:	74 45                	je     899e <f12+0x4ce>
    8959:	48 c1 e0 04          	shl    $0x4,%rax
    895d:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    8961:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    8966:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    896d:	00 00 00 
    8970:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    8975:	49 8b 77 18          	mov    0x18(%r15),%rsi
    8979:	49 83 c7 10          	add    $0x10,%r15
    897d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    8981:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    8986:	e8 e5 d9 ff ff       	call   6370 <w107>
    898b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    8990:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8994:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    8999:	4d 39 fd             	cmp    %r15,%r13
    899c:	75 d2                	jne    8970 <f12+0x4a0>
    899e:	4c 89 33             	mov    %r14,(%rbx)
    89a1:	48 89 df             	mov    %rbx,%rdi
    89a4:	e8 37 db ff ff       	call   64e0 <w164.constprop.0>
    89a9:	48 89 df             	mov    %rbx,%rdi
    89ac:	49 63 dc             	movslq %r12d,%rbx
    89af:	49 89 c5             	mov    %rax,%r13
    89b2:	e8 09 ed ff ff       	call   76c0 <fwp_drop4>
    89b7:	bf 02 00 00 00       	mov    $0x2,%edi
    89bc:	e8 8f b8 ff ff       	call   4250 <descent_phase_step>
    89c1:	48 89 df             	mov    %rbx,%rdi
    89c4:	e8 07 bd ff ff       	call   46d0 <fwp_tape_of>
    89c9:	48 89 c6             	mov    %rax,%rsi
    89cc:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    89d1:	0f 85 ff 0d 00 00    	jne    97d6 <f12+0x1306>
    89d7:	48 89 c7             	mov    %rax,%rdi
    89da:	e8 21 b2 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    89df:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    89e4:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    89e8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    89ef:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    89f4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    89f9:	0f 29 74 24 10       	movaps %xmm6,0x10(%rsp)
    89fe:	66 48 0f 6e f2       	movq   %rdx,%xmm6
    8a03:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    8a07:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    8a0b:	4c 8b 7e 40          	mov    0x40(%rsi),%r15
    8a0f:	0f 29 3c 24          	movaps %xmm7,(%rsp)
    8a13:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8a17:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8a1d:	77 19                	ja     8a38 <f12+0x568>
    8a1f:	41 0f b7 c4          	movzwl %r12w,%eax
    8a23:	83 e8 01             	sub    $0x1,%eax
    8a26:	48 98                	cltq
    8a28:	48 3b 05 c9 a6 01 00 	cmp    0x1a6c9(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    8a2f:	7d 07                	jge    8a38 <f12+0x568>
    8a31:	48 89 05 c0 a6 01 00 	mov    %rax,0x1a6c0(%rip)        # 230f8 <fwp_tape_next_slot>
    8a38:	48 8b 05 39 ca 01 00 	mov    0x1ca39(%rip),%rax        # 25478 <fwp_cleanups>
    8a3f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8a43:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    8a49:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    8a50:	00 
    8a51:	66 0f 6f 34 24       	movdqa (%rsp),%xmm6
    8a56:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8a5a:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8a61:	00 
    8a62:	48 8d 05 07 c6 ff ff 	lea    -0x39f9(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    8a69:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8a70:	00 
    8a71:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8a78:	00 
    8a79:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8a80:	00 
    8a81:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8a85:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8a89:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8a90:	00 
    8a91:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8a98:	00 
    8a99:	4c 89 bc 24 c0 00 00 	mov    %r15,0xc0(%rsp)
    8aa0:	00 
    8aa1:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    8aa8:	00 
    8aa9:	48 89 05 c8 c9 01 00 	mov    %rax,0x1c9c8(%rip)        # 25478 <fwp_cleanups>
    8ab0:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    8ab7:	00 
    8ab8:	0f 29 b4 24 b0 00 00 	movaps %xmm6,0xb0(%rsp)
    8abf:	00 
    8ac0:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8ac7:	00 
    8ac8:	4d 85 ed             	test   %r13,%r13
    8acb:	0f 88 ff 09 00 00    	js     94d0 <f12+0x1000>
    8ad1:	4c 89 e8             	mov    %r13,%rax
    8ad4:	48 c1 f8 20          	sar    $0x20,%rax
    8ad8:	48 39 c3             	cmp    %rax,%rbx
    8adb:	0f 85 a0 0c 00 00    	jne    9781 <f12+0x12b1>
    8ae1:	45 89 ea             	mov    %r13d,%r10d
    8ae4:	4c 39 d7             	cmp    %r10,%rdi
    8ae7:	0f 8e 88 0c 00 00    	jle    9775 <f12+0x12a5>
    8aed:	4d 39 d6             	cmp    %r10,%r14
    8af0:	0f 8e 12 01 00 00    	jle    8c08 <f12+0x738>
    8af6:	49 39 d6             	cmp    %rdx,%r14
    8af9:	0f 8f d9 0a 00 00    	jg     95d8 <f12+0x1108>
    8aff:	4d 85 ff             	test   %r15,%r15
    8b02:	0f 84 e6 09 00 00    	je     94ee <f12+0x101e>
    8b08:	4d 8d 4e ff          	lea    -0x1(%r14),%r9
    8b0c:	31 f6                	xor    %esi,%esi
    8b0e:	4c 89 ff             	mov    %r15,%rdi
    8b11:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    8b16:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    8b1d:	00 
    8b1e:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    8b23:	e8 98 a9 ff ff       	call   34c0 <memset@plt>
    8b28:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    8b2d:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    8b32:	45 31 db             	xor    %r11d,%r11d
    8b35:	e9 5d 01 00 00       	jmp    8c97 <f12+0x7c7>
    8b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b40:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8b44:	0f 84 df fb ff ff    	je     8729 <f12+0x259>
    8b4a:	e9 cc fb ff ff       	jmp    871b <f12+0x24b>
    8b4f:	90                   	nop
    8b50:	48 c1 e6 10          	shl    $0x10,%rsi
    8b54:	bf 08 00 00 00       	mov    $0x8,%edi
    8b59:	4c 09 c6             	or     %r8,%rsi
    8b5c:	49 89 f4             	mov    %rsi,%r12
    8b5f:	be 02 00 00 00       	mov    $0x2,%esi
    8b64:	e8 27 d1 ff ff       	call   5c90 <fwp_heap_alloc>
    8b69:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8b70:	48 8b 15 41 c0 01 00 	mov    0x1c041(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8b77:	48 89 c3             	mov    %rax,%rbx
    8b7a:	48 2b 05 0f c0 01 00 	sub    0x1c00f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8b81:	48 c1 e2 10          	shl    $0x10,%rdx
    8b85:	48 39 d0             	cmp    %rdx,%rax
    8b88:	73 56                	jae    8be0 <f12+0x710>
    8b8a:	48 89 c2             	mov    %rax,%rdx
    8b8d:	48 c1 ea 10          	shr    $0x10,%rdx
    8b91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b95:	48 8b 15 3c c0 01 00 	mov    0x1c03c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8b9c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8ba0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8ba4:	48 85 d2             	test   %rdx,%rdx
    8ba7:	0f 84 86 fd ff ff    	je     8933 <f12+0x463>
    8bad:	0f b6 31             	movzbl (%rcx),%esi
    8bb0:	45 31 ed             	xor    %r13d,%r13d
    8bb3:	40 80 fe 02          	cmp    $0x2,%sil
    8bb7:	0f 85 de fc ff ff    	jne    889b <f12+0x3cb>
    8bbd:	66 85 c0             	test   %ax,%ax
    8bc0:	0f 85 00 fd ff ff    	jne    88c6 <f12+0x3f6>
    8bc6:	e9 ef fc ff ff       	jmp    88ba <f12+0x3ea>
    8bcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8bd0:	4d 85 ed             	test   %r13,%r13
    8bd3:	0f 85 f2 fc ff ff    	jne    88cb <f12+0x3fb>
    8bd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8be0:	45 31 f6             	xor    %r14d,%r14d
    8be3:	e9 b6 fd ff ff       	jmp    899e <f12+0x4ce>
    8be8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bef:	00 
    8bf0:	4c 39 e3             	cmp    %r12,%rbx
    8bf3:	0f 84 57 fa ff ff    	je     8650 <f12+0x180>
    8bf9:	4c 8b 35 10 a5 01 00 	mov    0x1a510(%rip),%r14        # 23110 <fwp_tapes>
    8c00:	e9 df fa ff ff       	jmp    86e4 <f12+0x214>
    8c05:	0f 1f 00             	nopl   (%rax)
    8c08:	49 8d 5a 01          	lea    0x1(%r10),%rbx
    8c0c:	48 39 da             	cmp    %rbx,%rdx
    8c0f:	0f 8d cb 09 00 00    	jge    95e0 <f12+0x1110>
    8c15:	48 85 d2             	test   %rdx,%rdx
    8c18:	48 0f 44 d3          	cmove  %rbx,%rdx
    8c1c:	eb 17                	jmp    8c35 <f12+0x765>
    8c1e:	66 90                	xchg   %ax,%ax
    8c20:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    8c24:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    8c2b:	48 89 d8             	mov    %rbx,%rax
    8c2e:	48 0f 4c c6          	cmovl  %rsi,%rax
    8c32:	48 89 c2             	mov    %rax,%rdx
    8c35:	48 39 da             	cmp    %rbx,%rdx
    8c38:	7c e6                	jl     8c20 <f12+0x750>
    8c3a:	4d 85 ff             	test   %r15,%r15
    8c3d:	0f 84 2d 0a 00 00    	je     9670 <f12+0x11a0>
    8c43:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    8c4a:	00 
    8c4b:	4c 89 ff             	mov    %r15,%rdi
    8c4e:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    8c53:	e8 78 a9 ff ff       	call   35d0 <realloc@plt>
    8c58:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    8c5d:	49 89 c7             	mov    %rax,%r15
    8c60:	4d 85 ff             	test   %r15,%r15
    8c63:	0f 84 73 08 00 00    	je     94dc <f12+0x100c>
    8c69:	4c 89 bc 24 c0 00 00 	mov    %r15,0xc0(%rsp)
    8c70:	00 
    8c71:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
    8c78:	00 
    8c79:	48 85 db             	test   %rbx,%rbx
    8c7c:	0f 85 b6 0a 00 00    	jne    9738 <f12+0x1268>
    8c82:	4d 89 f3             	mov    %r14,%r11
    8c85:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
    8c8c:	49 f7 db             	neg    %r11
    8c8f:	4d 85 ed             	test   %r13,%r13
    8c92:	78 17                	js     8cab <f12+0x7db>
    8c94:	45 89 ea             	mov    %r13d,%r10d
    8c97:	f2 0f 10 05 81 6f 00 	movsd  0x6f81(%rip),%xmm0        # fc20 <msg.4+0xb0>
    8c9e:	00 
    8c9f:	f2 43 0f 58 04 d7    	addsd  (%r15,%r10,8),%xmm0
    8ca5:	f2 43 0f 11 04 d7    	movsd  %xmm0,(%r15,%r10,8)
    8cab:	bf 03 00 00 00       	mov    $0x3,%edi
    8cb0:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    8cb5:	4c 01 35 64 a4 01 00 	add    %r14,0x1a464(%rip)        # 23120 <descent_inputs>
    8cbc:	4c 01 1d 65 a4 01 00 	add    %r11,0x1a465(%rip)        # 23128 <descent_nodes>
    8cc3:	e8 88 b5 ff ff       	call   4250 <descent_phase_step>
    8cc8:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    8ccd:	4d 39 ce             	cmp    %r9,%r14
    8cd0:	0f 8f 8c 00 00 00    	jg     8d62 <f12+0x892>
    8cd6:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    8cdb:	4d 29 f1             	sub    %r14,%r9
    8cde:	4c 8b 14 24          	mov    (%rsp),%r10
    8ce2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8ce6:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8ceb:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    8cf0:	4b 8d 14 cb          	lea    (%r11,%r9,8),%rdx
    8cf4:	4d 29 da             	sub    %r11,%r10
    8cf7:	4a 8d 04 8f          	lea    (%rdi,%r9,4),%rax
    8cfb:	4f 8d 0c f7          	lea    (%r15,%r14,8),%r9
    8cff:	48 29 fe             	sub    %rdi,%rsi
    8d02:	4d 29 d9             	sub    %r11,%r9
    8d05:	eb 0d                	jmp    8d14 <f12+0x844>
    8d07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d0e:	00 00 
    8d10:	48 83 e8 04          	sub    $0x4,%rax
    8d14:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    8d1a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8d1e:	7a 02                	jp     8d22 <f12+0x852>
    8d20:	74 37                	je     8d59 <f12+0x889>
    8d22:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8d26:	45 85 db             	test   %r11d,%r11d
    8d29:	78 16                	js     8d41 <f12+0x871>
    8d2b:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8d31:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8d35:	f2 43 0f 58 0c df    	addsd  (%r15,%r11,8),%xmm1
    8d3b:	f2 43 0f 11 0c df    	movsd  %xmm1,(%r15,%r11,8)
    8d41:	4c 63 18             	movslq (%rax),%r11
    8d44:	45 85 db             	test   %r11d,%r11d
    8d47:	78 10                	js     8d59 <f12+0x889>
    8d49:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8d4d:	f2 43 0f 58 04 df    	addsd  (%r15,%r11,8),%xmm0
    8d53:	f2 43 0f 11 04 df    	movsd  %xmm0,(%r15,%r11,8)
    8d59:	48 83 ea 08          	sub    $0x8,%rdx
    8d5d:	48 39 c7             	cmp    %rax,%rdi
    8d60:	75 ae                	jne    8d10 <f12+0x840>
    8d62:	bf 04 00 00 00       	mov    $0x4,%edi
    8d67:	e8 e4 b4 ff ff       	call   4250 <descent_phase_step>
    8d6c:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8d73:	ff ff 1f 
    8d76:	4c 39 f0             	cmp    %r14,%rax
    8d79:	0f 82 3f 0a 00 00    	jb     97be <f12+0x12ee>
    8d7f:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8d86:	00 
    8d87:	be 02 00 00 00       	mov    $0x2,%esi
    8d8c:	e8 ff ce ff ff       	call   5c90 <fwp_heap_alloc>
    8d91:	4c 89 30             	mov    %r14,(%rax)
    8d94:	49 89 c5             	mov    %rax,%r13
    8d97:	31 c0                	xor    %eax,%eax
    8d99:	4d 85 f6             	test   %r14,%r14
    8d9c:	74 14                	je     8db2 <f12+0x8e2>
    8d9e:	66 90                	xchg   %ax,%ax
    8da0:	49 8b 14 c7          	mov    (%r15,%rax,8),%rdx
    8da4:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    8da9:	48 83 c0 01          	add    $0x1,%rax
    8dad:	49 39 c6             	cmp    %rax,%r14
    8db0:	75 ee                	jne    8da0 <f12+0x8d0>
    8db2:	bf 05 00 00 00       	mov    $0x5,%edi
    8db7:	e8 94 b4 ff ff       	call   4250 <descent_phase_step>
    8dbc:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    8dc3:	00 
    8dc4:	4c 89 e7             	mov    %r12,%rdi
    8dc7:	48 89 0d aa c6 01 00 	mov    %rcx,0x1c6aa(%rip)        # 25478 <fwp_cleanups>
    8dce:	48 89 0c 24          	mov    %rcx,(%rsp)
    8dd2:	e8 99 c2 ff ff       	call   5070 <fwp_tape_buffers_release>
    8dd7:	bf 06 00 00 00       	mov    $0x6,%edi
    8ddc:	e8 6f b4 ff ff       	call   4250 <descent_phase_step>
    8de1:	48 8b 15 d0 bd 01 00 	mov    0x1bdd0(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8de8:	4c 89 e8             	mov    %r13,%rax
    8deb:	48 8b 0c 24          	mov    (%rsp),%rcx
    8def:	48 2b 05 9a bd 01 00 	sub    0x1bd9a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8df6:	48 c1 e2 10          	shl    $0x10,%rdx
    8dfa:	48 39 d0             	cmp    %rdx,%rax
    8dfd:	73 57                	jae    8e56 <f12+0x986>
    8dff:	48 89 c2             	mov    %rax,%rdx
    8e02:	48 c1 ea 10          	shr    $0x10,%rdx
    8e06:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8e0a:	48 8b 15 c7 bd 01 00 	mov    0x1bdc7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8e11:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8e15:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8e19:	48 85 db             	test   %rbx,%rbx
    8e1c:	74 38                	je     8e56 <f12+0x986>
    8e1e:	0f b6 32             	movzbl (%rdx),%esi
    8e21:	40 80 fe 02          	cmp    $0x2,%sil
    8e25:	0f 84 0d 07 00 00    	je     9538 <f12+0x1068>
    8e2b:	40 80 fe 01          	cmp    $0x1,%sil
    8e2f:	75 25                	jne    8e56 <f12+0x986>
    8e31:	8b 72 18             	mov    0x18(%rdx),%esi
    8e34:	0f b7 c0             	movzwl %ax,%eax
    8e37:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e3a:	48 0f af c6          	imul   %rsi,%rax
    8e3e:	48 c1 e8 20          	shr    $0x20,%rax
    8e42:	48 39 d0             	cmp    %rdx,%rax
    8e45:	73 0f                	jae    8e56 <f12+0x986>
    8e47:	48 01 c3             	add    %rax,%rbx
    8e4a:	80 3b ff             	cmpb   $0xff,(%rbx)
    8e4d:	0f 84 b9 08 00 00    	je     970c <f12+0x123c>
    8e53:	c6 03 01             	movb   $0x1,(%rbx)
    8e56:	48 3b 4c 24 30       	cmp    0x30(%rsp),%rcx
    8e5b:	0f 85 ea a8 ff ff    	jne    374b <f12.cold>
    8e61:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8e66:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    8e6b:	48 89 05 06 c6 01 00 	mov    %rax,0x1c606(%rip)        # 25478 <fwp_cleanups>
    8e72:	e8 69 e2 ff ff       	call   70e0 <fwp_tape_scope_release>
    8e77:	49 8b 45 00          	mov    0x0(%r13),%rax
    8e7b:	49 89 c4             	mov    %rax,%r12
    8e7e:	49 0f ba f4 3f       	btr    $0x3f,%r12
    8e83:	48 85 c0             	test   %rax,%rax
    8e86:	0f 88 34 05 00 00    	js     93c0 <f12+0xef0>
    8e8c:	48 8b 15 25 bd 01 00 	mov    0x1bd25(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8e93:	4c 89 e8             	mov    %r13,%rax
    8e96:	48 2b 05 f3 bc 01 00 	sub    0x1bcf3(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8e9d:	48 c1 e2 10          	shl    $0x10,%rdx
    8ea1:	48 39 d0             	cmp    %rdx,%rax
    8ea4:	0f 83 16 05 00 00    	jae    93c0 <f12+0xef0>
    8eaa:	48 89 c2             	mov    %rax,%rdx
    8ead:	48 c1 ea 10          	shr    $0x10,%rdx
    8eb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8eb5:	48 8b 15 1c bd 01 00 	mov    0x1bd1c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8ebc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8ec0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8ec4:	48 85 c9             	test   %rcx,%rcx
    8ec7:	0f 84 f3 04 00 00    	je     93c0 <f12+0xef0>
    8ecd:	0f b6 32             	movzbl (%rdx),%esi
    8ed0:	40 80 fe 02          	cmp    $0x2,%sil
    8ed4:	0f 84 d6 04 00 00    	je     93b0 <f12+0xee0>
    8eda:	40 80 fe 01          	cmp    $0x1,%sil
    8ede:	0f 85 dc 04 00 00    	jne    93c0 <f12+0xef0>
    8ee4:	8b 72 18             	mov    0x18(%rdx),%esi
    8ee7:	0f b7 c0             	movzwl %ax,%eax
    8eea:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8eed:	48 0f af c6          	imul   %rsi,%rax
    8ef1:	48 c1 e8 20          	shr    $0x20,%rax
    8ef5:	48 39 d0             	cmp    %rdx,%rax
    8ef8:	0f 83 c2 04 00 00    	jae    93c0 <f12+0xef0>
    8efe:	48 01 c1             	add    %rax,%rcx
    8f01:	80 39 01             	cmpb   $0x1,(%rcx)
    8f04:	0f 85 b6 04 00 00    	jne    93c0 <f12+0xef0>
    8f0a:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    8f0f:	4d 89 ef             	mov    %r13,%r15
    8f12:	31 ff                	xor    %edi,%edi
    8f14:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8f19:	f2 0f 10 0d 0f 6d 00 	movsd  0x6d0f(%rip),%xmm1        # fc30 <msg.4+0xc0>
    8f20:	00 
    8f21:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8f25:	31 c0                	xor    %eax,%eax
    8f27:	4d 85 e4             	test   %r12,%r12
    8f2a:	75 29                	jne    8f55 <f12+0xa85>
    8f2c:	eb 42                	jmp    8f70 <f12+0xaa0>
    8f2e:	66 90                	xchg   %ax,%ax
    8f30:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8f34:	0f 88 53 08 00 00    	js     978d <f12+0x12bd>
    8f3a:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8f3f:	48 83 c0 01          	add    $0x1,%rax
    8f43:	48 83 c2 08          	add    $0x8,%rdx
    8f47:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8f4b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8f50:	49 39 c4             	cmp    %rax,%r12
    8f53:	74 1b                	je     8f70 <f12+0xaa0>
    8f55:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    8f59:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8f5e:	79 d0                	jns    8f30 <f12+0xa60>
    8f60:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    8f64:	eb ca                	jmp    8f30 <f12+0xa60>
    8f66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f6d:	00 00 00 
    8f70:	e8 4b e7 ff ff       	call   76c0 <fwp_drop4>
    8f75:	48 89 e8             	mov    %rbp,%rax
    8f78:	31 d2                	xor    %edx,%edx
    8f7a:	48 85 ed             	test   %rbp,%rbp
    8f7d:	0f 84 1c 07 00 00    	je     969f <f12+0x11cf>
    8f83:	66 90                	xchg   %ax,%ax
    8f85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8f8c:	00 00 00 00 
    8f90:	48 8b 40 10          	mov    0x10(%rax),%rax
    8f94:	48 83 c2 01          	add    $0x1,%rdx
    8f98:	48 85 c0             	test   %rax,%rax
    8f9b:	75 f3                	jne    8f90 <f12+0xac0>
    8f9d:	49 8b 07             	mov    (%r15),%rax
    8fa0:	49 89 c5             	mov    %rax,%r13
    8fa3:	49 0f ba f5 3f       	btr    $0x3f,%r13
    8fa8:	48 85 c0             	test   %rax,%rax
    8fab:	0f 88 61 03 00 00    	js     9312 <f12+0xe42>
    8fb1:	48 8b 05 00 bc 01 00 	mov    0x1bc00(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    8fb8:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    8fbd:	48 2b 0d cc bb 01 00 	sub    0x1bbcc(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    8fc4:	48 c1 e0 10          	shl    $0x10,%rax
    8fc8:	48 39 c1             	cmp    %rax,%rcx
    8fcb:	0f 83 41 03 00 00    	jae    9312 <f12+0xe42>
    8fd1:	48 89 c8             	mov    %rcx,%rax
    8fd4:	48 c1 e8 10          	shr    $0x10,%rax
    8fd8:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    8fdc:	48 8b 05 f5 bb 01 00 	mov    0x1bbf5(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    8fe3:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    8fe7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8feb:	48 85 ff             	test   %rdi,%rdi
    8fee:	0f 84 1e 03 00 00    	je     9312 <f12+0xe42>
    8ff4:	0f b6 06             	movzbl (%rsi),%eax
    8ff7:	3c 02                	cmp    $0x2,%al
    8ff9:	0f 84 01 03 00 00    	je     9300 <f12+0xe30>
    8fff:	3c 01                	cmp    $0x1,%al
    9001:	0f 85 02 03 00 00    	jne    9309 <f12+0xe39>
    9007:	8b 46 18             	mov    0x18(%rsi),%eax
    900a:	0f b7 c9             	movzwl %cx,%ecx
    900d:	48 0f af c8          	imul   %rax,%rcx
    9011:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9014:	48 c1 e9 20          	shr    $0x20,%rcx
    9018:	48 39 c1             	cmp    %rax,%rcx
    901b:	0f 83 e8 02 00 00    	jae    9309 <f12+0xe39>
    9021:	48 01 cf             	add    %rcx,%rdi
    9024:	80 3f 01             	cmpb   $0x1,(%rdi)
    9027:	0f 85 dc 02 00 00    	jne    9309 <f12+0xe39>
    902d:	49 39 d5             	cmp    %rdx,%r13
    9030:	48 89 d0             	mov    %rdx,%rax
    9033:	49 0f 46 c5          	cmovbe %r13,%rax
    9037:	48 85 c0             	test   %rax,%rax
    903a:	0f 84 5e 07 00 00    	je     979e <f12+0x12ce>
    9040:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
    9047:	00 
    9048:	4d 8d 77 08          	lea    0x8(%r15),%r14
    904c:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    9051:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    9058:	00 
    9059:	48 89 e9             	mov    %rbp,%rcx
    905c:	31 d2                	xor    %edx,%edx
    905e:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    9062:	eb 39                	jmp    909d <f12+0xbcd>
    9064:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    906a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9071:	00 00 00 00 
    9075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    907c:	00 00 00 00 
    9080:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9085:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    908a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9090:	48 83 c2 08          	add    $0x8,%rdx
    9094:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9098:	49 39 d0             	cmp    %rdx,%r8
    909b:	74 1b                	je     90b8 <f12+0xbe8>
    909d:	48 89 fe             	mov    %rdi,%rsi
    90a0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    90a4:	79 da                	jns    9080 <f12+0xbb0>
    90a6:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    90ab:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    90af:	eb cf                	jmp    9080 <f12+0xbb0>
    90b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90b8:	48 85 ed             	test   %rbp,%rbp
    90bb:	0f 84 ac 06 00 00    	je     976d <f12+0x129d>
    90c1:	4c 8b 05 f0 ba 01 00 	mov    0x1baf0(%rip),%r8        # 24bb8 <fwp_heap+0x13d8>
    90c8:	4c 8b 0d c1 ba 01 00 	mov    0x1bac1(%rip),%r9        # 24b90 <fwp_heap+0x13b0>
    90cf:	48 89 e9             	mov    %rbp,%rcx
    90d2:	45 31 ed             	xor    %r13d,%r13d
    90d5:	4c 8b 15 fc ba 01 00 	mov    0x1bafc(%rip),%r10        # 24bd8 <fwp_heap+0x13f8>
    90dc:	49 c1 e0 10          	shl    $0x10,%r8
    90e0:	eb 1c                	jmp    90fe <f12+0xc2e>
    90e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90e8:	49 83 c5 01          	add    $0x1,%r13
    90ec:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    90f0:	49 39 c5             	cmp    %rax,%r13
    90f3:	0f 83 67 01 00 00    	jae    9260 <f12+0xd90>
    90f9:	48 85 c9             	test   %rcx,%rcx
    90fc:	74 56                	je     9154 <f12+0xc84>
    90fe:	48 89 ca             	mov    %rcx,%rdx
    9101:	4c 29 ca             	sub    %r9,%rdx
    9104:	4c 39 c2             	cmp    %r8,%rdx
    9107:	73 4b                	jae    9154 <f12+0xc84>
    9109:	48 89 d6             	mov    %rdx,%rsi
    910c:	48 c1 ee 10          	shr    $0x10,%rsi
    9110:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9114:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    9118:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    911c:	48 85 ff             	test   %rdi,%rdi
    911f:	74 33                	je     9154 <f12+0xc84>
    9121:	44 0f b6 1e          	movzbl (%rsi),%r11d
    9125:	41 80 fb 02          	cmp    $0x2,%r11b
    9129:	0f 84 19 01 00 00    	je     9248 <f12+0xd78>
    912f:	41 80 fb 01          	cmp    $0x1,%r11b
    9133:	75 1f                	jne    9154 <f12+0xc84>
    9135:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    9139:	0f b7 d2             	movzwl %dx,%edx
    913c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    913f:	49 0f af d3          	imul   %r11,%rdx
    9143:	48 c1 ea 20          	shr    $0x20,%rdx
    9147:	48 39 f2             	cmp    %rsi,%rdx
    914a:	73 08                	jae    9154 <f12+0xc84>
    914c:	48 01 d7             	add    %rdx,%rdi
    914f:	80 3f 01             	cmpb   $0x1,(%rdi)
    9152:	74 94                	je     90e8 <f12+0xc18>
    9154:	49 39 c5             	cmp    %rax,%r13
    9157:	0f 83 03 01 00 00    	jae    9260 <f12+0xd90>
    915d:	49 89 c7             	mov    %rax,%r15
    9160:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    9167:	00 
    9168:	45 31 e4             	xor    %r12d,%r12d
    916b:	48 89 04 24          	mov    %rax,(%rsp)
    916f:	48 8d 1d 6a a6 01 00 	lea    0x1a66a(%rip),%rbx        # 237e0 <fwp_heap>
    9176:	eb 3a                	jmp    91b2 <f12+0xce2>
    9178:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    917f:	00 
    9180:	41 80 f9 01          	cmp    $0x1,%r9b
    9184:	75 27                	jne    91ad <f12+0xcdd>
    9186:	45 8b 48 18          	mov    0x18(%r8),%r9d
    918a:	0f b7 c0             	movzwl %ax,%eax
    918d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9191:	49 0f af c1          	imul   %r9,%rax
    9195:	48 c1 e8 20          	shr    $0x20,%rax
    9199:	4c 39 c0             	cmp    %r8,%rax
    919c:	73 0f                	jae    91ad <f12+0xcdd>
    919e:	48 01 c7             	add    %rax,%rdi
    91a1:	80 3f ff             	cmpb   $0xff,(%rdi)
    91a4:	0f 84 c6 02 00 00    	je     9470 <f12+0xfa0>
    91aa:	c6 07 01             	movb   $0x1,(%rdi)
    91ad:	4d 39 fd             	cmp    %r15,%r13
    91b0:	73 7e                	jae    9230 <f12+0xd60>
    91b2:	49 83 ef 01          	sub    $0x1,%r15
    91b6:	66 49 0f 6e ec       	movq   %r12,%xmm5
    91bb:	48 8b 34 24          	mov    (%rsp),%rsi
    91bf:	bf 01 00 00 00       	mov    $0x1,%edi
    91c4:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    91ca:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    91ce:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    91d5:	00 
    91d6:	e8 85 d3 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    91db:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    91e2:	49 89 c4             	mov    %rax,%r12
    91e5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    91ec:	48 c1 e7 10          	shl    $0x10,%rdi
    91f0:	48 39 f8             	cmp    %rdi,%rax
    91f3:	73 b8                	jae    91ad <f12+0xcdd>
    91f5:	48 89 c7             	mov    %rax,%rdi
    91f8:	48 c1 ef 10          	shr    $0x10,%rdi
    91fc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    9200:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    9207:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    920b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    920f:	48 85 ff             	test   %rdi,%rdi
    9212:	74 99                	je     91ad <f12+0xcdd>
    9214:	45 0f b6 08          	movzbl (%r8),%r9d
    9218:	41 80 f9 02          	cmp    $0x2,%r9b
    921c:	0f 85 5e ff ff ff    	jne    9180 <f12+0xcb0>
    9222:	66 85 c0             	test   %ax,%ax
    9225:	0f 84 76 ff ff ff    	je     91a1 <f12+0xcd1>
    922b:	4d 39 fd             	cmp    %r15,%r13
    922e:	72 82                	jb     91b2 <f12+0xce2>
    9230:	4d 85 ed             	test   %r13,%r13
    9233:	75 2e                	jne    9263 <f12+0xd93>
    9235:	8b 44 24 28          	mov    0x28(%rsp),%eax
    9239:	85 c0                	test   %eax,%eax
    923b:	4d 0f 45 f5          	cmovne %r13,%r14
    923f:	eb 6f                	jmp    92b0 <f12+0xde0>
    9241:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9248:	66 85 d2             	test   %dx,%dx
    924b:	0f 84 fe fe ff ff    	je     914f <f12+0xc7f>
    9251:	49 39 c5             	cmp    %rax,%r13
    9254:	0f 82 03 ff ff ff    	jb     915d <f12+0xc8d>
    925a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9260:	45 31 e4             	xor    %r12d,%r12d
    9263:	4c 89 f2             	mov    %r14,%rdx
    9266:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    926a:	48 89 e8             	mov    %rbp,%rax
    926d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9274:	00 
    9275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    927c:	00 00 00 00 
    9280:	48 8b 0a             	mov    (%rdx),%rcx
    9283:	48 83 c2 08          	add    $0x8,%rdx
    9287:	48 89 c7             	mov    %rax,%rdi
    928a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    928e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9292:	4c 39 c2             	cmp    %r8,%rdx
    9295:	75 e9                	jne    9280 <f12+0xdb0>
    9297:	8b 54 24 28          	mov    0x28(%rsp),%edx
    929b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    929f:	85 d2                	test   %edx,%edx
    92a1:	0f 84 a9 02 00 00    	je     9550 <f12+0x1080>
    92a7:	49 89 ec             	mov    %rbp,%r12
    92aa:	45 31 f6             	xor    %r14d,%r14d
    92ad:	48 89 c5             	mov    %rax,%rbp
    92b0:	4c 89 f7             	mov    %r14,%rdi
    92b3:	e8 d8 c4 ff ff       	call   5790 <fwp_mem_free>
    92b8:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    92bd:	e8 fe e3 ff ff       	call   76c0 <fwp_drop4>
    92c2:	48 89 ef             	mov    %rbp,%rdi
    92c5:	e8 06 d8 ff ff       	call   6ad0 <fwp_drop0>
    92ca:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    92d1:	00 
    92d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    92d9:	00 00 
    92db:	0f 85 01 05 00 00    	jne    97e2 <f12+0x1312>
    92e1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    92e8:	4c 89 e0             	mov    %r12,%rax
    92eb:	5b                   	pop    %rbx
    92ec:	5d                   	pop    %rbp
    92ed:	41 5c                	pop    %r12
    92ef:	41 5d                	pop    %r13
    92f1:	41 5e                	pop    %r14
    92f3:	41 5f                	pop    %r15
    92f5:	c3                   	ret
    92f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92fd:	00 00 00 
    9300:	66 85 c9             	test   %cx,%cx
    9303:	0f 84 1b fd ff ff    	je     9024 <f12+0xb54>
    9309:	48 85 ed             	test   %rbp,%rbp
    930c:	0f 84 2f 03 00 00    	je     9641 <f12+0x1171>
    9312:	48 89 e8             	mov    %rbp,%rax
    9315:	45 31 e4             	xor    %r12d,%r12d
    9318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    931f:	00 
    9320:	48 8b 40 10          	mov    0x10(%rax),%rax
    9324:	4c 89 e2             	mov    %r12,%rdx
    9327:	49 83 c4 01          	add    $0x1,%r12
    932b:	48 85 c0             	test   %rax,%rax
    932e:	75 f0                	jne    9320 <f12+0xe50>
    9330:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9337:	ff ff 1f 
    933a:	4c 39 e0             	cmp    %r12,%rax
    933d:	0f 82 6f 04 00 00    	jb     97b2 <f12+0x12e2>
    9343:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    934a:	00 
    934b:	be 02 00 00 00       	mov    $0x2,%esi
    9350:	e8 3b c9 ff ff       	call   5c90 <fwp_heap_alloc>
    9355:	4d 39 e5             	cmp    %r12,%r13
    9358:	48 89 ea             	mov    %rbp,%rdx
    935b:	49 89 c6             	mov    %rax,%r14
    935e:	4c 89 e0             	mov    %r12,%rax
    9361:	49 0f 46 c5          	cmovbe %r13,%rax
    9365:	4c 89 f1             	mov    %r14,%rcx
    9368:	66 90                	xchg   %ax,%ax
    936a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9371:	00 00 00 00 
    9375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    937c:	00 00 00 00 
    9380:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9384:	48 83 c1 08          	add    $0x8,%rcx
    9388:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    938c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9390:	48 85 d2             	test   %rdx,%rdx
    9393:	75 eb                	jne    9380 <f12+0xeb0>
    9395:	48 85 c0             	test   %rax,%rax
    9398:	0f 84 b5 02 00 00    	je     9653 <f12+0x1183>
    939e:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
    93a5:	00 
    93a6:	e9 a1 fc ff ff       	jmp    904c <f12+0xb7c>
    93ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    93b0:	66 85 c0             	test   %ax,%ax
    93b3:	0f 84 48 fb ff ff    	je     8f01 <f12+0xa31>
    93b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93c0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    93c7:	ff ff 1f 
    93ca:	4c 39 e0             	cmp    %r12,%rax
    93cd:	0f 82 eb 03 00 00    	jb     97be <f12+0x12ee>
    93d3:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    93da:	00 
    93db:	be 01 00 00 00       	mov    $0x1,%esi
    93e0:	e8 ab c8 ff ff       	call   5c90 <fwp_heap_alloc>
    93e5:	4c 89 20             	mov    %r12,(%rax)
    93e8:	48 8b 15 c9 b7 01 00 	mov    0x1b7c9(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    93ef:	49 89 c7             	mov    %rax,%r15
    93f2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    93f7:	48 2b 05 92 b7 01 00 	sub    0x1b792(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    93fe:	48 c1 e2 10          	shl    $0x10,%rdx
    9402:	48 39 d0             	cmp    %rdx,%rax
    9405:	73 57                	jae    945e <f12+0xf8e>
    9407:	48 89 c2             	mov    %rax,%rdx
    940a:	48 c1 ea 10          	shr    $0x10,%rdx
    940e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9412:	48 8b 15 bf b7 01 00 	mov    0x1b7bf(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    9419:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    941d:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9421:	4d 85 f6             	test   %r14,%r14
    9424:	74 38                	je     945e <f12+0xf8e>
    9426:	0f b6 0a             	movzbl (%rdx),%ecx
    9429:	80 f9 02             	cmp    $0x2,%cl
    942c:	0f 84 2e 02 00 00    	je     9660 <f12+0x1190>
    9432:	80 f9 01             	cmp    $0x1,%cl
    9435:	75 27                	jne    945e <f12+0xf8e>
    9437:	8b 4a 18             	mov    0x18(%rdx),%ecx
    943a:	0f b7 c0             	movzwl %ax,%eax
    943d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9440:	48 0f af c1          	imul   %rcx,%rax
    9444:	48 c1 e8 20          	shr    $0x20,%rax
    9448:	48 39 d0             	cmp    %rdx,%rax
    944b:	73 11                	jae    945e <f12+0xf8e>
    944d:	49 01 c6             	add    %rax,%r14
    9450:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9454:	0f 84 c7 02 00 00    	je     9721 <f12+0x1251>
    945a:	41 c6 06 01          	movb   $0x1,(%r14)
    945e:	4c 89 ef             	mov    %r13,%rdi
    9461:	e9 ae fa ff ff       	jmp    8f14 <f12+0xa44>
    9466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    946d:	00 00 00 
    9470:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    9475:	e8 d6 c0 ff ff       	call   5550 <fwp_rc_forget_slot>
    947a:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    947f:	e9 26 fd ff ff       	jmp    91aa <f12+0xcda>
    9484:	0f 1f 40 00          	nopl   0x0(%rax)
    9488:	48 8d 3d 71 db ff ff 	lea    -0x248f(%rip),%rdi        # 7000 <fwp_tape_finish>
    948f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9494:	e8 97 56 00 00       	call   eb30 <atexit>
    9499:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    949e:	85 c0                	test   %eax,%eax
    94a0:	75 63                	jne    9505 <f12+0x1035>
    94a2:	c7 05 d4 9b 00 00 01 	movl   $0x1,0x9bd4(%rip)        # 13080 <registered_finish.0>
    94a9:	00 00 00 
    94ac:	e9 53 f1 ff ff       	jmp    8604 <f12+0x134>
    94b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    94b8:	66 85 c0             	test   %ax,%ax
    94bb:	0f 85 ef f0 ff ff    	jne    85b0 <f12+0xe0>
    94c1:	e9 d6 f0 ff ff       	jmp    859c <f12+0xcc>
    94c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    94cd:	00 00 00 
    94d0:	4c 89 f3             	mov    %r14,%rbx
    94d3:	49 39 d6             	cmp    %rdx,%r14
    94d6:	0f 8f 39 f7 ff ff    	jg     8c15 <f12+0x745>
    94dc:	48 85 db             	test   %rbx,%rbx
    94df:	0f 84 9d f7 ff ff    	je     8c82 <f12+0x7b2>
    94e5:	4d 85 ff             	test   %r15,%r15
    94e8:	0f 85 8b f7 ff ff    	jne    8c79 <f12+0x7a9>
    94ee:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    94f5:	00 
    94f6:	4c 89 e7             	mov    %r12,%rdi
    94f9:	48 89 05 78 bf 01 00 	mov    %rax,0x1bf78(%rip)        # 25478 <fwp_cleanups>
    9500:	e8 6b bb ff ff       	call   5070 <fwp_tape_buffers_release>
    9505:	48 8b 0d 54 9b 00 00 	mov    0x9b54(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    950c:	ba 13 00 00 00       	mov    $0x13,%edx
    9511:	be 01 00 00 00       	mov    $0x1,%esi
    9516:	48 8d 3d eb 5a 00 00 	lea    0x5aeb(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    951d:	e8 5e a1 ff ff       	call   3680 <fwrite@plt>
    9522:	31 ff                	xor    %edi,%edi
    9524:	e8 97 a0 ff ff       	call   35c0 <fflush@plt>
    9529:	bf 66 00 00 00       	mov    $0x66,%edi
    952e:	e8 6d a1 ff ff       	call   36a0 <_Exit@plt>
    9533:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9538:	66 85 c0             	test   %ax,%ax
    953b:	0f 85 15 f9 ff ff    	jne    8e56 <f12+0x986>
    9541:	e9 04 f9 ff ff       	jmp    8e4a <f12+0x97a>
    9546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    954d:	00 00 00 
    9550:	49 89 ec             	mov    %rbp,%r12
    9553:	48 89 c5             	mov    %rax,%rbp
    9556:	e9 55 fd ff ff       	jmp    92b0 <f12+0xde0>
    955b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9560:	66 0f 6f 0d 58 9b 01 	movdqa 0x19b58(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    9567:	00 
    9568:	48 c7 05 35 9b 01 00 	movq   $0x0,0x19b35(%rip)        # 230a8 <fwp_tape_cached_bytes>
    956f:	00 00 00 00 
    9573:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    9579:	48 8b 05 60 9b 01 00 	mov    0x19b60(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    9580:	66 0f 6f 0d 48 9b 01 	movdqa 0x19b48(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    9587:	00 
    9588:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    958d:	48 8b 05 54 9b 01 00 	mov    0x19b54(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    9594:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    959a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    959e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    95a3:	48 8b 05 46 9b 01 00 	mov    0x19b46(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    95aa:	0f 29 0d 0f 9b 01 00 	movaps %xmm1,0x19b0f(%rip)        # 230c0 <fwp_tape_workspace>
    95b1:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    95b6:	0f 29 0d 13 9b 01 00 	movaps %xmm1,0x19b13(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    95bd:	48 c7 05 28 9b 01 00 	movq   $0x0,0x19b28(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    95c4:	00 00 00 00 
    95c8:	0f 29 0d 11 9b 01 00 	movaps %xmm1,0x19b11(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    95cf:	e9 55 f1 ff ff       	jmp    8729 <f12+0x259>
    95d4:	0f 1f 40 00          	nopl   0x0(%rax)
    95d8:	4c 89 f3             	mov    %r14,%rbx
    95db:	e9 35 f6 ff ff       	jmp    8c15 <f12+0x745>
    95e0:	4d 85 ff             	test   %r15,%r15
    95e3:	0f 84 05 ff ff ff    	je     94ee <f12+0x101e>
    95e9:	49 89 db             	mov    %rbx,%r11
    95ec:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    95f3:	00 
    95f4:	31 f6                	xor    %esi,%esi
    95f6:	4c 89 ff             	mov    %r15,%rdi
    95f9:	4d 29 f3             	sub    %r14,%r11
    95fc:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    9601:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
    9606:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    960b:	e8 b0 9e ff ff       	call   34c0 <memset@plt>
    9610:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    9615:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    961a:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
    961f:	e9 73 f6 ff ff       	jmp    8c97 <f12+0x7c7>
    9624:	0f 1f 40 00          	nopl   0x0(%rax)
    9628:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    962c:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9631:	49 39 c7             	cmp    %rax,%r15
    9634:	4c 0f 4f f8          	cmovg  %rax,%r15
    9638:	49 6b f7 68          	imul   $0x68,%r15,%rsi
    963c:	e9 40 f0 ff ff       	jmp    8681 <f12+0x1b1>
    9641:	be 02 00 00 00       	mov    $0x2,%esi
    9646:	bf 08 00 00 00       	mov    $0x8,%edi
    964b:	e8 40 c6 ff ff       	call   5c90 <fwp_heap_alloc>
    9650:	49 89 c6             	mov    %rax,%r14
    9653:	45 31 e4             	xor    %r12d,%r12d
    9656:	e9 55 fc ff ff       	jmp    92b0 <f12+0xde0>
    965b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9660:	66 85 c0             	test   %ax,%ax
    9663:	0f 85 f5 fd ff ff    	jne    945e <f12+0xf8e>
    9669:	e9 e2 fd ff ff       	jmp    9450 <f12+0xf80>
    966e:	66 90                	xchg   %ax,%ax
    9670:	48 89 d7             	mov    %rdx,%rdi
    9673:	be 08 00 00 00       	mov    $0x8,%esi
    9678:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    967d:	e8 9e 9e ff ff       	call   3520 <calloc@plt>
    9682:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    9687:	49 89 c7             	mov    %rax,%r15
    968a:	e9 d1 f5 ff ff       	jmp    8c60 <f12+0x790>
    968f:	31 ff                	xor    %edi,%edi
    9691:	e8 ba ab ff ff       	call   4250 <descent_phase_step>
    9696:	66 0f ef c0          	pxor   %xmm0,%xmm0
    969a:	e9 57 ef ff ff       	jmp    85f6 <f12+0x126>
    969f:	49 8b 07             	mov    (%r15),%rax
    96a2:	48 85 c0             	test   %rax,%rax
    96a5:	78 9a                	js     9641 <f12+0x1171>
    96a7:	48 8b 35 0a b5 01 00 	mov    0x1b50a(%rip),%rsi        # 24bb8 <fwp_heap+0x13d8>
    96ae:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    96b3:	48 2b 0d d6 b4 01 00 	sub    0x1b4d6(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    96ba:	48 c1 e6 10          	shl    $0x10,%rsi
    96be:	48 39 f1             	cmp    %rsi,%rcx
    96c1:	0f 83 7a ff ff ff    	jae    9641 <f12+0x1171>
    96c7:	48 89 ce             	mov    %rcx,%rsi
    96ca:	48 c1 ee 10          	shr    $0x10,%rsi
    96ce:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    96d2:	48 8b 35 ff b4 01 00 	mov    0x1b4ff(%rip),%rsi        # 24bd8 <fwp_heap+0x13f8>
    96d9:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    96dd:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    96e1:	48 85 ff             	test   %rdi,%rdi
    96e4:	0f 84 57 ff ff ff    	je     9641 <f12+0x1171>
    96ea:	48 0f ba f0 3f       	btr    $0x3f,%rax
    96ef:	49 89 c5             	mov    %rax,%r13
    96f2:	e9 fd f8 ff ff       	jmp    8ff4 <f12+0xb24>
    96f7:	48 89 d7             	mov    %rdx,%rdi
    96fa:	48 89 14 24          	mov    %rdx,(%rsp)
    96fe:	e8 4d be ff ff       	call   5550 <fwp_rc_forget_slot>
    9703:	48 8b 14 24          	mov    (%rsp),%rdx
    9707:	e9 b7 f1 ff ff       	jmp    88c3 <f12+0x3f3>
    970c:	48 89 df             	mov    %rbx,%rdi
    970f:	48 89 0c 24          	mov    %rcx,(%rsp)
    9713:	e8 38 be ff ff       	call   5550 <fwp_rc_forget_slot>
    9718:	48 8b 0c 24          	mov    (%rsp),%rcx
    971c:	e9 32 f7 ff ff       	jmp    8e53 <f12+0x983>
    9721:	4c 89 f7             	mov    %r14,%rdi
    9724:	e8 27 be ff ff       	call   5550 <fwp_rc_forget_slot>
    9729:	e9 2c fd ff ff       	jmp    945a <f12+0xf8a>
    972e:	e8 fd bc ff ff       	call   5430 <fwp_rc_wide_dup>
    9733:	e9 78 ee ff ff       	jmp    85b0 <f12+0xe0>
    9738:	49 89 db             	mov    %rbx,%r11
    973b:	4c 8d 4b ff          	lea    -0x1(%rbx),%r9
    973f:	31 f6                	xor    %esi,%esi
    9741:	4c 89 ff             	mov    %r15,%rdi
    9744:	4d 29 f3             	sub    %r14,%r11
    9747:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    974e:	00 
    974f:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    9754:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
    9759:	e8 62 9d ff ff       	call   34c0 <memset@plt>
    975e:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    9763:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    9768:	e9 22 f5 ff ff       	jmp    8c8f <f12+0x7bf>
    976d:	45 31 ed             	xor    %r13d,%r13d
    9770:	e9 e8 f9 ff ff       	jmp    915d <f12+0xc8d>
    9775:	48 8d 3d eb 59 00 00 	lea    0x59eb(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    977c:	e8 6f ac ff ff       	call   43f0 <fwp_trap>
    9781:	48 8d 3d 28 61 00 00 	lea    0x6128(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    9788:	e8 63 ac ff ff       	call   43f0 <fwp_trap>
    978d:	48 8d 3d 24 62 00 00 	lea    0x6224(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    9794:	e8 57 ac ff ff       	call   43f0 <fwp_trap>
    9799:	e8 62 9f ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    979e:	45 31 f6             	xor    %r14d,%r14d
    97a1:	e9 ad fe ff ff       	jmp    9653 <f12+0x1183>
    97a6:	48 8d 3d f1 59 00 00 	lea    0x59f1(%rip),%rdi        # f19e <_IO_stdin_used+0x19e>
    97ad:	e8 3e ac ff ff       	call   43f0 <fwp_trap>
    97b2:	48 8d 3d d7 59 00 00 	lea    0x59d7(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    97b9:	e8 32 ac ff ff       	call   43f0 <fwp_trap>
    97be:	48 8d 3d f3 59 00 00 	lea    0x59f3(%rip),%rdi        # f1b8 <_IO_stdin_used+0x1b8>
    97c5:	e8 26 ac ff ff       	call   43f0 <fwp_trap>
    97ca:	48 8d 3d 87 61 00 00 	lea    0x6187(%rip),%rdi        # f958 <_IO_stdin_used+0x958>
    97d1:	e8 1a ac ff ff       	call   43f0 <fwp_trap>
    97d6:	48 8d 3d 1b 61 00 00 	lea    0x611b(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    97dd:	e8 0e ac ff ff       	call   43f0 <fwp_trap>
    97e2:	e8 79 9c ff ff       	call   3460 <__stack_chk_fail@plt>
    97e7:	48 8d 3d 9a 61 00 00 	lea    0x619a(%rip),%rdi        # f988 <_IO_stdin_used+0x988>
    97ee:	e8 fd ab ff ff       	call   43f0 <fwp_trap>
    97f3:	66 90                	xchg   %ax,%ax
    97f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    97fc:	00 00 00 00 

0000000000009800 <fwp_owned_entry12>:
    9800:	f3 0f 1e fa          	endbr64
    9804:	48 8b 3f             	mov    (%rdi),%rdi
    9807:	e9 c4 ec ff ff       	jmp    84d0 <f12>
    980c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009810 <e12>:
    9810:	f3 0f 1e fa          	endbr64
    9814:	53                   	push   %rbx
    9815:	48 8b 1f             	mov    (%rdi),%rbx
    9818:	48 89 df             	mov    %rbx,%rdi
    981b:	e8 70 ce ff ff       	call   6690 <fwp_rc_share>
    9820:	48 89 df             	mov    %rbx,%rdi
    9823:	e8 a8 ec ff ff       	call   84d0 <f12>
    9828:	48 89 c3             	mov    %rax,%rbx
    982b:	48 89 c7             	mov    %rax,%rdi
    982e:	e8 5d ce ff ff       	call   6690 <fwp_rc_share>
    9833:	48 89 d8             	mov    %rbx,%rax
    9836:	5b                   	pop    %rbx
    9837:	c3                   	ret
    9838:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    983f:	00 

0000000000009840 <fwp_write>:
    9840:	41 57                	push   %r15
    9842:	41 56                	push   %r14
    9844:	41 55                	push   %r13
    9846:	41 54                	push   %r12
    9848:	55                   	push   %rbp
    9849:	53                   	push   %rbx
    984a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9851:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9858:	00 00 
    985a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9861:	00 
    9862:	49 89 d4             	mov    %rdx,%r12
    9865:	8b 12                	mov    (%rdx),%edx
    9867:	83 fa 19             	cmp    $0x19,%edx
    986a:	77 6a                	ja     98d6 <fwp_write+0x96>
    986c:	48 89 f5             	mov    %rsi,%rbp
    986f:	89 d0                	mov    %edx,%eax
    9871:	89 ce                	mov    %ecx,%esi
    9873:	48 89 fb             	mov    %rdi,%rbx
    9876:	48 8d 0d 83 62 00 00 	lea    0x6283(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    987d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9881:	48 01 c8             	add    %rcx,%rax
    9884:	3e ff e0             	notrack jmp *%rax
    9887:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    988e:	00 00 
    9890:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9894:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9898:	48 89 ca             	mov    %rcx,%rdx
    989b:	48 85 c9             	test   %rcx,%rcx
    989e:	0f 88 9c 0c 00 00    	js     a540 <fwp_write+0xd00>
    98a4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    98ab:	00 
    98ac:	48 89 c6             	mov    %rax,%rsi
    98af:	4c 89 e7             	mov    %r12,%rdi
    98b2:	e8 89 a1 ff ff       	call   3a40 <fwp_fmt_u128>
    98b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    98be:	00 00 
    98c0:	4c 89 e7             	mov    %r12,%rdi
    98c3:	e8 88 9b ff ff       	call   3450 <strlen@plt>
    98c8:	4c 89 e6             	mov    %r12,%rsi
    98cb:	48 89 df             	mov    %rbx,%rdi
    98ce:	48 89 c2             	mov    %rax,%rdx
    98d1:	e8 3a a9 ff ff       	call   4210 <buf_put>
    98d6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    98dd:	00 
    98de:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    98e5:	00 00 
    98e7:	0f 85 28 04 00 00    	jne    9d15 <fwp_write+0x4d5>
    98ed:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    98f4:	5b                   	pop    %rbx
    98f5:	5d                   	pop    %rbp
    98f6:	41 5c                	pop    %r12
    98f8:	41 5d                	pop    %r13
    98fa:	41 5e                	pop    %r14
    98fc:	41 5f                	pop    %r15
    98fe:	c3                   	ret
    98ff:	90                   	nop
    9900:	49 89 e9             	mov    %rbp,%r9
    9903:	4c 8d 05 6b 57 00 00 	lea    0x576b(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    990a:	b9 00 02 00 00       	mov    $0x200,%ecx
    990f:	ba 02 00 00 00       	mov    $0x2,%edx
    9914:	be 00 02 00 00       	mov    $0x200,%esi
    9919:	31 c0                	xor    %eax,%eax
    991b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9922:	00 
    9923:	e8 88 9a ff ff       	call   33b0 <__snprintf_chk@plt>
    9928:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    992f:	00 
    9930:	e8 1b 9b ff ff       	call   3450 <strlen@plt>
    9935:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    993c:	00 
    993d:	48 89 df             	mov    %rbx,%rdi
    9940:	48 89 c2             	mov    %rax,%rdx
    9943:	e8 c8 a8 ff ff       	call   4210 <buf_put>
    9948:	eb 8c                	jmp    98d6 <fwp_write+0x96>
    994a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9950:	49 89 e9             	mov    %rbp,%r9
    9953:	4c 8d 05 85 58 00 00 	lea    0x5885(%rip),%r8        # f1df <_IO_stdin_used+0x1df>
    995a:	eb ae                	jmp    990a <fwp_write+0xca>
    995c:	0f 1f 40 00          	nopl   0x0(%rax)
    9960:	83 fa 13             	cmp    $0x13,%edx
    9963:	48 8d 05 6b 58 00 00 	lea    0x586b(%rip),%rax        # f1d5 <_IO_stdin_used+0x1d5>
    996a:	48 8d 35 69 58 00 00 	lea    0x5869(%rip),%rsi        # f1da <_IO_stdin_used+0x1da>
    9971:	ba 04 00 00 00       	mov    $0x4,%edx
    9976:	48 0f 44 f0          	cmove  %rax,%rsi
    997a:	45 31 ed             	xor    %r13d,%r13d
    997d:	e8 8e a8 ff ff       	call   4210 <buf_put>
    9982:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9987:	0f 84 a3 08 00 00    	je     a230 <fwp_write+0x9f0>
    998d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9992:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9997:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    999c:	48 89 df             	mov    %rbx,%rdi
    999f:	49 0f 44 c5          	cmove  %r13,%rax
    99a3:	31 c9                	xor    %ecx,%ecx
    99a5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    99aa:	e8 91 fe ff ff       	call   9840 <fwp_write>
    99af:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    99b4:	0f 84 6e 09 00 00    	je     a328 <fwp_write+0xae8>
    99ba:	49 83 c5 01          	add    $0x1,%r13
    99be:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    99c2:	0f 83 68 08 00 00    	jae    a230 <fwp_write+0x9f0>
    99c8:	ba 02 00 00 00       	mov    $0x2,%edx
    99cd:	48 8d 35 4b 58 00 00 	lea    0x584b(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    99d4:	48 89 df             	mov    %rbx,%rdi
    99d7:	e8 34 a8 ff ff       	call   4210 <buf_put>
    99dc:	eb af                	jmp    998d <fwp_write+0x14d>
    99de:	66 90                	xchg   %ax,%ax
    99e0:	ba 06 00 00 00       	mov    $0x6,%edx
    99e5:	48 8d 35 0c 58 00 00 	lea    0x580c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    99ec:	48 83 c5 10          	add    $0x10,%rbp
    99f0:	e8 1b a8 ff ff       	call   4210 <buf_put>
    99f5:	48 89 ef             	mov    %rbp,%rdi
    99f8:	e8 53 9a ff ff       	call   3450 <strlen@plt>
    99fd:	48 89 ee             	mov    %rbp,%rsi
    9a00:	48 89 df             	mov    %rbx,%rdi
    9a03:	48 89 c2             	mov    %rax,%rdx
    9a06:	e8 05 a8 ff ff       	call   4210 <buf_put>
    9a0b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9a10:	ba 01 00 00 00       	mov    $0x1,%edx
    9a15:	48 89 df             	mov    %rbx,%rdi
    9a18:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9a1d:	e8 ee a7 ff ff       	call   4210 <buf_put>
    9a22:	e9 af fe ff ff       	jmp    98d6 <fwp_write+0x96>
    9a27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a2e:	00 00 
    9a30:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9a37:	00 
    9a38:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9a3f:	00 00 
    9a41:	0f 85 ce 02 00 00    	jne    9d15 <fwp_write+0x4d5>
    9a47:	ba 0a 00 00 00       	mov    $0xa,%edx
    9a4c:	48 8d 35 91 57 00 00 	lea    0x5791(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    9a53:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9a5a:	48 89 df             	mov    %rbx,%rdi
    9a5d:	5b                   	pop    %rbx
    9a5e:	5d                   	pop    %rbp
    9a5f:	41 5c                	pop    %r12
    9a61:	41 5d                	pop    %r13
    9a63:	41 5e                	pop    %r14
    9a65:	41 5f                	pop    %r15
    9a67:	e9 a4 a7 ff ff       	jmp    4210 <buf_put>
    9a6c:	0f 1f 40 00          	nopl   0x0(%rax)
    9a70:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9a75:	4d 85 ed             	test   %r13,%r13
    9a78:	0f 84 02 0c 00 00    	je     a680 <fwp_write+0xe40>
    9a7e:	48 8d 35 a7 57 00 00 	lea    0x57a7(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    9a85:	4c 89 ef             	mov    %r13,%rdi
    9a88:	e8 a3 9a ff ff       	call   3530 <strcmp@plt>
    9a8d:	41 89 c1             	mov    %eax,%r9d
    9a90:	85 c0                	test   %eax,%eax
    9a92:	0f 84 6c 0c 00 00    	je     a704 <fwp_write+0xec4>
    9a98:	4c 89 ef             	mov    %r13,%rdi
    9a9b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9aa0:	e8 ab 99 ff ff       	call   3450 <strlen@plt>
    9aa5:	4c 89 ee             	mov    %r13,%rsi
    9aa8:	48 89 df             	mov    %rbx,%rdi
    9aab:	48 89 c2             	mov    %rax,%rdx
    9aae:	e8 5d a7 ff ff       	call   4210 <buf_put>
    9ab3:	ba 01 00 00 00       	mov    $0x1,%edx
    9ab8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9abd:	48 89 df             	mov    %rbx,%rdi
    9ac0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9ac5:	e8 46 a7 ff ff       	call   4210 <buf_put>
    9aca:	ba 01 00 00 00       	mov    $0x1,%edx
    9acf:	4c 89 fe             	mov    %r15,%rsi
    9ad2:	48 89 df             	mov    %rbx,%rdi
    9ad5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9ada:	e8 31 a7 ff ff       	call   4210 <buf_put>
    9adf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9ae4:	45 31 f6             	xor    %r14d,%r14d
    9ae7:	85 d2                	test   %edx,%edx
    9ae9:	0f 8e 81 0a 00 00    	jle    a570 <fwp_write+0xd30>
    9aef:	45 31 ed             	xor    %r13d,%r13d
    9af2:	4d 85 ed             	test   %r13,%r13
    9af5:	0f 85 75 07 00 00    	jne    a270 <fwp_write+0xa30>
    9afb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9b02:	00 
    9b03:	45 85 f6             	test   %r14d,%r14d
    9b06:	0f 84 84 07 00 00    	je     a290 <fwp_write+0xa50>
    9b0c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9b11:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9b16:	48 89 df             	mov    %rbx,%rdi
    9b19:	49 83 c5 01          	add    $0x1,%r13
    9b1d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9b21:	31 c9                	xor    %ecx,%ecx
    9b23:	e8 18 fd ff ff       	call   9840 <fwp_write>
    9b28:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9b2d:	7f c3                	jg     9af2 <fwp_write+0x2b2>
    9b2f:	45 85 f6             	test   %r14d,%r14d
    9b32:	0f 84 38 0a 00 00    	je     a570 <fwp_write+0xd30>
    9b38:	b8 29 00 00 00       	mov    $0x29,%eax
    9b3d:	ba 01 00 00 00       	mov    $0x1,%edx
    9b42:	4c 89 fe             	mov    %r15,%rsi
    9b45:	48 89 df             	mov    %rbx,%rdi
    9b48:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9b4c:	e8 bf a6 ff ff       	call   4210 <buf_put>
    9b51:	e9 80 fd ff ff       	jmp    98d6 <fwp_write+0x96>
    9b56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b5d:	00 00 00 
    9b60:	ba 01 00 00 00       	mov    $0x1,%edx
    9b65:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9b6a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9b6f:	e8 9c a6 ff ff       	call   4210 <buf_put>
    9b74:	48 85 ed             	test   %rbp,%rbp
    9b77:	0f 84 93 06 00 00    	je     a210 <fwp_write+0x9d0>
    9b7d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9b81:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9b86:	31 c9                	xor    %ecx,%ecx
    9b88:	48 89 df             	mov    %rbx,%rdi
    9b8b:	e8 b0 fc ff ff       	call   9840 <fwp_write>
    9b90:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9b94:	48 85 ed             	test   %rbp,%rbp
    9b97:	0f 84 73 06 00 00    	je     a210 <fwp_write+0x9d0>
    9b9d:	ba 02 00 00 00       	mov    $0x2,%edx
    9ba2:	48 8d 35 76 56 00 00 	lea    0x5676(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9ba9:	48 89 df             	mov    %rbx,%rdi
    9bac:	e8 5f a6 ff ff       	call   4210 <buf_put>
    9bb1:	eb ca                	jmp    9b7d <fwp_write+0x33d>
    9bb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9bb8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9bbc:	85 f6                	test   %esi,%esi
    9bbe:	0f 84 fc 07 00 00    	je     a3c0 <fwp_write+0xb80>
    9bc4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9bcb:	00 
    9bcc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9bd3:	00 00 
    9bd5:	0f 85 3a 01 00 00    	jne    9d15 <fwp_write+0x4d5>
    9bdb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9bdf:	4c 89 ea             	mov    %r13,%rdx
    9be2:	e9 6c fe ff ff       	jmp    9a53 <fwp_write+0x213>
    9be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9bee:	00 00 
    9bf0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9bf5:	ba 01 00 00 00       	mov    $0x1,%edx
    9bfa:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9bff:	48 89 ee             	mov    %rbp,%rsi
    9c02:	e8 09 a6 ff ff       	call   4210 <buf_put>
    9c07:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9c0c:	4c 89 e7             	mov    %r12,%rdi
    9c0f:	e8 3c 98 ff ff       	call   3450 <strlen@plt>
    9c14:	4c 89 e6             	mov    %r12,%rsi
    9c17:	48 89 df             	mov    %rbx,%rdi
    9c1a:	48 89 c2             	mov    %rax,%rdx
    9c1d:	e8 ee a5 ff ff       	call   4210 <buf_put>
    9c22:	ba 01 00 00 00       	mov    $0x1,%edx
    9c27:	48 89 ee             	mov    %rbp,%rsi
    9c2a:	48 89 df             	mov    %rbx,%rdi
    9c2d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9c32:	e8 d9 a5 ff ff       	call   4210 <buf_put>
    9c37:	e9 9a fc ff ff       	jmp    98d6 <fwp_write+0x96>
    9c3c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c40:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9c45:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9c49:	0f 8a 8e 0b 00 00    	jp     a7dd <fwp_write+0xf9d>
    9c4f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9c53:	66 0f 54 05 a5 5f 00 	andpd  0x5fa5(%rip),%xmm0        # fc00 <msg.4+0x90>
    9c5a:	00 
    9c5b:	bd 01 00 00 00       	mov    $0x1,%ebp
    9c60:	66 0f 2e 05 d0 5f 00 	ucomisd 0x5fd0(%rip),%xmm0        # fc38 <msg.4+0xc8>
    9c67:	00 
    9c68:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9c6f:	00 
    9c70:	0f 87 b2 09 00 00    	ja     a628 <fwp_write+0xde8>
    9c76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9c7d:	00 00 00 
    9c80:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9c84:	89 ee                	mov    %ebp,%esi
    9c86:	4c 89 e7             	mov    %r12,%rdi
    9c89:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9c8e:	e8 7d aa ff ff       	call   4710 <fwp_format_g.constprop.0>
    9c93:	31 f6                	xor    %esi,%esi
    9c95:	4c 89 e7             	mov    %r12,%rdi
    9c98:	e8 73 97 ff ff       	call   3410 <strtod@plt>
    9c9d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9ca2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9ca6:	7a 06                	jp     9cae <fwp_write+0x46e>
    9ca8:	0f 84 e9 01 00 00    	je     9e97 <fwp_write+0x657>
    9cae:	83 c5 01             	add    $0x1,%ebp
    9cb1:	83 fd 12             	cmp    $0x12,%ebp
    9cb4:	75 ca                	jne    9c80 <fwp_write+0x440>
    9cb6:	be 11 00 00 00       	mov    $0x11,%esi
    9cbb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9cbf:	4c 89 e7             	mov    %r12,%rdi
    9cc2:	e8 49 aa ff ff       	call   4710 <fwp_format_g.constprop.0>
    9cc7:	e9 cb 01 00 00       	jmp    9e97 <fwp_write+0x657>
    9ccc:	0f 1f 40 00          	nopl   0x0(%rax)
    9cd0:	48 83 fd 01          	cmp    $0x1,%rbp
    9cd4:	0f 84 e6 08 00 00    	je     a5c0 <fwp_write+0xd80>
    9cda:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9cde:	b8 02 00 00 00       	mov    $0x2,%eax
    9ce3:	ba 01 00 00 00       	mov    $0x1,%edx
    9ce8:	48 0f 44 d0          	cmove  %rax,%rdx
    9cec:	48 8d 35 da 54 00 00 	lea    0x54da(%rip),%rsi        # f1cd <_IO_stdin_used+0x1cd>
    9cf3:	48 8d 05 d8 54 00 00 	lea    0x54d8(%rip),%rax        # f1d2 <_IO_stdin_used+0x1d2>
    9cfa:	48 0f 44 f0          	cmove  %rax,%rsi
    9cfe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d05:	00 
    9d06:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d0d:	00 00 
    9d0f:	0f 84 3e fd ff ff    	je     9a53 <fwp_write+0x213>
    9d15:	e8 46 97 ff ff       	call   3460 <__stack_chk_fail@plt>
    9d1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9d20:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9d25:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9d2a:	e8 21 a4 ff ff       	call   4150 <buf_grow>
    9d2f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9d33:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9d39:	4c 03 0b             	add    (%rbx),%r9
    9d3c:	66 45 89 11          	mov    %r10w,(%r9)
    9d40:	45 85 e4             	test   %r12d,%r12d
    9d43:	0f 8e 07 05 00 00    	jle    a250 <fwp_write+0xa10>
    9d49:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9d50:	55 55 55 
    9d53:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9d58:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9d5f:	aa aa aa 
    9d62:	49 83 c1 01          	add    $0x1,%r9
    9d66:	eb 45                	jmp    9dad <fwp_write+0x56d>
    9d68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d6f:	00 
    9d70:	be 01 00 00 00       	mov    $0x1,%esi
    9d75:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9d7a:	88 07                	mov    %al,(%rdi)
    9d7c:	48 89 e8             	mov    %rbp,%rax
    9d7f:	49 f7 e8             	imul   %r8
    9d82:	48 89 e8             	mov    %rbp,%rax
    9d85:	48 c1 f8 3f          	sar    $0x3f,%rax
    9d89:	48 29 c2             	sub    %rax,%rdx
    9d8c:	48 85 c9             	test   %rcx,%rcx
    9d8f:	0f 95 c0             	setne  %al
    9d92:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9d96:	48 83 ef 01          	sub    $0x1,%rdi
    9d9a:	48 21 c5             	and    %rax,%rbp
    9d9d:	48 29 ea             	sub    %rbp,%rdx
    9da0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9da4:	49 39 f9             	cmp    %rdi,%r9
    9da7:	0f 84 a3 04 00 00    	je     a250 <fwp_write+0xa10>
    9dad:	48 89 e8             	mov    %rbp,%rax
    9db0:	49 f7 e8             	imul   %r8
    9db3:	48 89 e8             	mov    %rbp,%rax
    9db6:	48 c1 f8 3f          	sar    $0x3f,%rax
    9dba:	48 89 d1             	mov    %rdx,%rcx
    9dbd:	48 29 c1             	sub    %rax,%rcx
    9dc0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9dc4:	48 89 e9             	mov    %rbp,%rcx
    9dc7:	48 29 c1             	sub    %rax,%rcx
    9dca:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9dce:	49 f7 e2             	mul    %r10
    9dd1:	b8 30 00 00 00       	mov    $0x30,%eax
    9dd6:	48 89 d6             	mov    %rdx,%rsi
    9dd9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9ddd:	48 d1 ee             	shr    $1,%rsi
    9de0:	48 01 f2             	add    %rsi,%rdx
    9de3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9de7:	48 29 d6             	sub    %rdx,%rsi
    9dea:	74 8e                	je     9d7a <fwp_write+0x53a>
    9dec:	48 83 fe 01          	cmp    $0x1,%rsi
    9df0:	0f 85 7a ff ff ff    	jne    9d70 <fwp_write+0x530>
    9df6:	31 f6                	xor    %esi,%esi
    9df8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9dfd:	e9 78 ff ff ff       	jmp    9d7a <fwp_write+0x53a>
    9e02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e08:	66 0f 6e cd          	movd   %ebp,%xmm1
    9e0c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9e0f:	0f 8a c8 09 00 00    	jp     a7dd <fwp_write+0xf9d>
    9e15:	0f 28 c1             	movaps %xmm1,%xmm0
    9e18:	0f 54 05 d1 5d 00 00 	andps  0x5dd1(%rip),%xmm0        # fbf0 <msg.4+0x80>
    9e1f:	0f 2e 05 de 51 00 00 	ucomiss 0x51de(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    9e26:	0f 87 24 08 00 00    	ja     a650 <fwp_write+0xe10>
    9e2c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9e30:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9e36:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9e3d:	00 
    9e3e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9e42:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e4e:	00 00 
    9e50:	44 89 ee             	mov    %r13d,%esi
    9e53:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9e58:	4c 89 e7             	mov    %r12,%rdi
    9e5b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9e60:	e8 ab a8 ff ff       	call   4710 <fwp_format_g.constprop.0>
    9e65:	31 f6                	xor    %esi,%esi
    9e67:	4c 89 e7             	mov    %r12,%rdi
    9e6a:	e8 41 96 ff ff       	call   34b0 <strtof@plt>
    9e6f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9e74:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9e77:	7a 02                	jp     9e7b <fwp_write+0x63b>
    9e79:	74 1c                	je     9e97 <fwp_write+0x657>
    9e7b:	41 83 c5 01          	add    $0x1,%r13d
    9e7f:	41 83 fd 0a          	cmp    $0xa,%r13d
    9e83:	75 cb                	jne    9e50 <fwp_write+0x610>
    9e85:	be 09 00 00 00       	mov    $0x9,%esi
    9e8a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9e8f:	4c 89 e7             	mov    %r12,%rdi
    9e92:	e8 79 a8 ff ff       	call   4710 <fwp_format_g.constprop.0>
    9e97:	4c 89 e7             	mov    %r12,%rdi
    9e9a:	e8 e1 a4 ff ff       	call   4380 <fwp_finish_float>
    9e9f:	e9 1c fa ff ff       	jmp    98c0 <fwp_write+0x80>
    9ea4:	0f 1f 40 00          	nopl   0x0(%rax)
    9ea8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    9eac:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9eb0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9eb7:	00 
    9eb8:	48 89 ef             	mov    %rbp,%rdi
    9ebb:	e8 80 9b ff ff       	call   3a40 <fwp_fmt_u128>
    9ec0:	48 89 ef             	mov    %rbp,%rdi
    9ec3:	e8 88 95 ff ff       	call   3450 <strlen@plt>
    9ec8:	48 89 ee             	mov    %rbp,%rsi
    9ecb:	48 89 df             	mov    %rbx,%rdi
    9ece:	48 89 c2             	mov    %rax,%rdx
    9ed1:	e8 3a a3 ff ff       	call   4210 <buf_put>
    9ed6:	e9 fb f9 ff ff       	jmp    98d6 <fwp_write+0x96>
    9edb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ee0:	ba 06 00 00 00       	mov    $0x6,%edx
    9ee5:	48 8d 35 36 53 00 00 	lea    0x5336(%rip),%rsi        # f222 <_IO_stdin_used+0x222>
    9eec:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9ef2:	e8 19 a3 ff ff       	call   4210 <buf_put>
    9ef7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9efe:	ff ff 7f 
    9f01:	48 23 55 00          	and    0x0(%rbp),%rdx
    9f05:	0f 84 86 02 00 00    	je     a191 <fwp_write+0x951>
    9f0b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9f10:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9f14:	48 85 d2             	test   %rdx,%rdx
    9f17:	0f 84 ae 00 00 00    	je     9fcb <fwp_write+0x78b>
    9f1d:	8b 0a                	mov    (%rdx),%ecx
    9f1f:	83 f9 1c             	cmp    $0x1c,%ecx
    9f22:	0f 84 58 06 00 00    	je     a580 <fwp_write+0xd40>
    9f28:	83 f9 1b             	cmp    $0x1b,%ecx
    9f2b:	0f 87 9a 00 00 00    	ja     9fcb <fwp_write+0x78b>
    9f31:	be 01 00 00 00       	mov    $0x1,%esi
    9f36:	48 d3 e6             	shl    %cl,%rsi
    9f39:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    9f3f:	0f 85 4b 04 00 00    	jne    a390 <fwp_write+0xb50>
    9f45:	f7 c6 84 04 00 00    	test   $0x484,%esi
    9f4b:	0f 85 0f 04 00 00    	jne    a360 <fwp_write+0xb20>
    9f51:	83 e6 21             	and    $0x21,%esi
    9f54:	74 75                	je     9fcb <fwp_write+0x78b>
    9f56:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    9f5b:	48 85 ff             	test   %rdi,%rdi
    9f5e:	79 07                	jns    9f67 <fwp_write+0x727>
    9f60:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    9f64:	4c 01 ee             	add    %r13,%rsi
    9f67:	48 0f be 3e          	movsbq (%rsi),%rdi
    9f6b:	85 c9                	test   %ecx,%ecx
    9f6d:	40 0f b6 f7          	movzbl %dil,%esi
    9f71:	48 0f 44 f7          	cmove  %rdi,%rsi
    9f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f7c:	00 00 00 00 
    9f80:	31 c9                	xor    %ecx,%ecx
    9f82:	48 89 df             	mov    %rbx,%rdi
    9f85:	49 83 c5 01          	add    $0x1,%r13
    9f89:	e8 b2 f8 ff ff       	call   9840 <fwp_write>
    9f8e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9f95:	ff ff 7f 
    9f98:	48 23 55 00          	and    0x0(%rbp),%rdx
    9f9c:	49 39 d5             	cmp    %rdx,%r13
    9f9f:	0f 83 ec 01 00 00    	jae    a191 <fwp_write+0x951>
    9fa5:	ba 02 00 00 00       	mov    $0x2,%edx
    9faa:	48 89 df             	mov    %rbx,%rdi
    9fad:	48 8d 35 6b 52 00 00 	lea    0x526b(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9fb4:	e8 57 a2 ff ff       	call   4210 <buf_put>
    9fb9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9fbe:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9fc2:	48 85 d2             	test   %rdx,%rdx
    9fc5:	0f 85 52 ff ff ff    	jne    9f1d <fwp_write+0x6dd>
    9fcb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9fd0:	48 85 ff             	test   %rdi,%rdi
    9fd3:	0f 88 cf 05 00 00    	js     a5a8 <fwp_write+0xd68>
    9fd9:	48 8b 31             	mov    (%rcx),%rsi
    9fdc:	eb a2                	jmp    9f80 <fwp_write+0x740>
    9fde:	66 90                	xchg   %ax,%ax
    9fe0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9fe7:	00 
    9fe8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9fef:	00 00 
    9ff1:	0f 85 1e fd ff ff    	jne    9d15 <fwp_write+0x4d5>
    9ff7:	ba 08 00 00 00       	mov    $0x8,%edx
    9ffc:	48 8d 35 ec 51 00 00 	lea    0x51ec(%rip),%rsi        # f1ef <_IO_stdin_used+0x1ef>
    a003:	e9 4b fa ff ff       	jmp    9a53 <fwp_write+0x213>
    a008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a00f:	00 
    a010:	89 e8                	mov    %ebp,%eax
    a012:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a019:	76 03                	jbe    a01e <fwp_write+0x7de>
    a01b:	8b 45 00             	mov    0x0(%rbp),%eax
    a01e:	41 89 c6             	mov    %eax,%r14d
    a021:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a026:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a02b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a02f:	4c 89 ef             	mov    %r13,%rdi
    a032:	e8 19 94 ff ff       	call   3450 <strlen@plt>
    a037:	4c 89 ee             	mov    %r13,%rsi
    a03a:	48 89 df             	mov    %rbx,%rdi
    a03d:	48 89 c2             	mov    %rax,%rdx
    a040:	e8 cb a1 ff ff       	call   4210 <buf_put>
    a045:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a04a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a04e:	85 f6                	test   %esi,%esi
    a050:	0f 8e 80 f8 ff ff    	jle    98d6 <fwp_write+0x96>
    a056:	45 31 ed             	xor    %r13d,%r13d
    a059:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a05e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a063:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a068:	ba 01 00 00 00       	mov    $0x1,%edx
    a06d:	4c 89 fe             	mov    %r15,%rsi
    a070:	48 89 04 24          	mov    %rax,(%rsp)
    a074:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a079:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a07d:	48 89 df             	mov    %rbx,%rdi
    a080:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a084:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a089:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a08e:	e8 7d a1 ff ff       	call   4210 <buf_put>
    a093:	41 8b 06             	mov    (%r14),%eax
    a096:	83 f8 0e             	cmp    $0xe,%eax
    a099:	0f 84 71 02 00 00    	je     a310 <fwp_write+0xad0>
    a09f:	83 f8 10             	cmp    $0x10,%eax
    a0a2:	0f 84 38 02 00 00    	je     a2e0 <fwp_write+0xaa0>
    a0a8:	83 f8 0a             	cmp    $0xa,%eax
    a0ab:	0f 84 7f 04 00 00    	je     a530 <fwp_write+0xcf0>
    a0b1:	0f 8f f9 00 00 00    	jg     a1b0 <fwp_write+0x970>
    a0b7:	83 f8 03             	cmp    $0x3,%eax
    a0ba:	0f 8f 50 04 00 00    	jg     a510 <fwp_write+0xcd0>
    a0c0:	85 c0                	test   %eax,%eax
    a0c2:	78 10                	js     a0d4 <fwp_write+0x894>
    a0c4:	48 8b 04 24          	mov    (%rsp),%rax
    a0c8:	48 c1 e8 3f          	shr    $0x3f,%rax
    a0cc:	85 c0                	test   %eax,%eax
    a0ce:	0f 85 f9 00 00 00    	jne    a1cd <fwp_write+0x98d>
    a0d4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a0d9:	48 8b 34 24          	mov    (%rsp),%rsi
    a0dd:	31 c9                	xor    %ecx,%ecx
    a0df:	48 89 df             	mov    %rbx,%rdi
    a0e2:	e8 59 f7 ff ff       	call   9840 <fwp_write>
    a0e7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a0ec:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a0f1:	49 83 c5 01          	add    $0x1,%r13
    a0f5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a0f9:	0f 8f 5f ff ff ff    	jg     a05e <fwp_write+0x81e>
    a0ff:	e9 d2 f7 ff ff       	jmp    98d6 <fwp_write+0x96>
    a104:	0f 1f 40 00          	nopl   0x0(%rax)
    a108:	ba 06 00 00 00       	mov    $0x6,%edx
    a10d:	48 8d 35 01 51 00 00 	lea    0x5101(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    a114:	45 31 ed             	xor    %r13d,%r13d
    a117:	e8 f4 a0 ff ff       	call   4210 <buf_put>
    a11c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a121:	75 19                	jne    a13c <fwp_write+0x8fc>
    a123:	eb 6c                	jmp    a191 <fwp_write+0x951>
    a125:	0f 1f 00             	nopl   (%rax)
    a128:	ba 02 00 00 00       	mov    $0x2,%edx
    a12d:	48 8d 35 eb 50 00 00 	lea    0x50eb(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a134:	48 89 df             	mov    %rbx,%rdi
    a137:	e8 d4 a0 ff ff       	call   4210 <buf_put>
    a13c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a142:	b9 00 02 00 00       	mov    $0x200,%ecx
    a147:	31 c0                	xor    %eax,%eax
    a149:	49 83 c5 01          	add    $0x1,%r13
    a14d:	4c 8d 05 c8 50 00 00 	lea    0x50c8(%rip),%r8        # f21c <_IO_stdin_used+0x21c>
    a154:	ba 02 00 00 00       	mov    $0x2,%edx
    a159:	be 00 02 00 00       	mov    $0x200,%esi
    a15e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a165:	00 
    a166:	e8 45 92 ff ff       	call   33b0 <__snprintf_chk@plt>
    a16b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a172:	00 
    a173:	e8 d8 92 ff ff       	call   3450 <strlen@plt>
    a178:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a17f:	00 
    a180:	48 89 df             	mov    %rbx,%rdi
    a183:	48 89 c2             	mov    %rax,%rdx
    a186:	e8 85 a0 ff ff       	call   4210 <buf_put>
    a18b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a18f:	72 97                	jb     a128 <fwp_write+0x8e8>
    a191:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a196:	ba 01 00 00 00       	mov    $0x1,%edx
    a19b:	48 89 df             	mov    %rbx,%rdi
    a19e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a1a3:	e8 68 a0 ff ff       	call   4210 <buf_put>
    a1a8:	e9 29 f7 ff ff       	jmp    98d6 <fwp_write+0x96>
    a1ad:	0f 1f 00             	nopl   (%rax)
    a1b0:	83 f8 0b             	cmp    $0xb,%eax
    a1b3:	0f 85 1b ff ff ff    	jne    a0d4 <fwp_write+0x894>
    a1b9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a1be:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a1c2:	83 e0 01             	and    $0x1,%eax
    a1c5:	85 c0                	test   %eax,%eax
    a1c7:	0f 84 07 ff ff ff    	je     a0d4 <fwp_write+0x894>
    a1cd:	4c 89 fe             	mov    %r15,%rsi
    a1d0:	48 89 df             	mov    %rbx,%rdi
    a1d3:	ba 01 00 00 00       	mov    $0x1,%edx
    a1d8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a1dd:	e8 2e a0 ff ff       	call   4210 <buf_put>
    a1e2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a1e7:	48 8b 34 24          	mov    (%rsp),%rsi
    a1eb:	31 c9                	xor    %ecx,%ecx
    a1ed:	48 89 df             	mov    %rbx,%rdi
    a1f0:	e8 4b f6 ff ff       	call   9840 <fwp_write>
    a1f5:	ba 01 00 00 00       	mov    $0x1,%edx
    a1fa:	4c 89 fe             	mov    %r15,%rsi
    a1fd:	48 89 df             	mov    %rbx,%rdi
    a200:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a205:	e8 06 a0 ff ff       	call   4210 <buf_put>
    a20a:	e9 d8 fe ff ff       	jmp    a0e7 <fwp_write+0x8a7>
    a20f:	90                   	nop
    a210:	ba 01 00 00 00       	mov    $0x1,%edx
    a215:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a21a:	48 89 df             	mov    %rbx,%rdi
    a21d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a222:	e8 e9 9f ff ff       	call   4210 <buf_put>
    a227:	e9 aa f6 ff ff       	jmp    98d6 <fwp_write+0x96>
    a22c:	0f 1f 40 00          	nopl   0x0(%rax)
    a230:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a235:	ba 01 00 00 00       	mov    $0x1,%edx
    a23a:	48 89 df             	mov    %rbx,%rdi
    a23d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a242:	e8 c9 9f ff ff       	call   4210 <buf_put>
    a247:	e9 8a f6 ff ff       	jmp    98d6 <fwp_write+0x96>
    a24c:	0f 1f 40 00          	nopl   0x0(%rax)
    a250:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a254:	48 8b 13             	mov    (%rbx),%rdx
    a257:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a25c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a260:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a264:	e9 6d f6 ff ff       	jmp    98d6 <fwp_write+0x96>
    a269:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a270:	ba 02 00 00 00       	mov    $0x2,%edx
    a275:	48 8d 35 a3 4f 00 00 	lea    0x4fa3(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a27c:	48 89 df             	mov    %rbx,%rdi
    a27f:	e8 8c 9f ff ff       	call   4210 <buf_put>
    a284:	e9 72 f8 ff ff       	jmp    9afb <fwp_write+0x2bb>
    a289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a290:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a295:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a29a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a29e:	48 89 f7             	mov    %rsi,%rdi
    a2a1:	48 89 34 24          	mov    %rsi,(%rsp)
    a2a5:	e8 a6 91 ff ff       	call   3450 <strlen@plt>
    a2aa:	48 8b 34 24          	mov    (%rsp),%rsi
    a2ae:	48 89 df             	mov    %rbx,%rdi
    a2b1:	48 89 c2             	mov    %rax,%rdx
    a2b4:	e8 57 9f ff ff       	call   4210 <buf_put>
    a2b9:	ba 03 00 00 00       	mov    $0x3,%edx
    a2be:	48 8d 35 7d 4f 00 00 	lea    0x4f7d(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    a2c5:	48 89 df             	mov    %rbx,%rdi
    a2c8:	e8 43 9f ff ff       	call   4210 <buf_put>
    a2cd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a2d2:	e9 35 f8 ff ff       	jmp    9b0c <fwp_write+0x2cc>
    a2d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2de:	00 00 
    a2e0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a2e5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a2e9:	48 85 ff             	test   %rdi,%rdi
    a2ec:	0f 84 e2 fd ff ff    	je     a0d4 <fwp_write+0x894>
    a2f2:	48 8d 35 33 4f 00 00 	lea    0x4f33(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    a2f9:	e8 32 92 ff ff       	call   3530 <strcmp@plt>
    a2fe:	85 c0                	test   %eax,%eax
    a300:	0f 95 c0             	setne  %al
    a303:	0f b6 c0             	movzbl %al,%eax
    a306:	e9 c1 fd ff ff       	jmp    a0cc <fwp_write+0x88c>
    a30b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a310:	31 c0                	xor    %eax,%eax
    a312:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a319:	00 
    a31a:	0f 97 c0             	seta   %al
    a31d:	e9 aa fd ff ff       	jmp    a0cc <fwp_write+0x88c>
    a322:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a328:	48 89 df             	mov    %rbx,%rdi
    a32b:	ba 02 00 00 00       	mov    $0x2,%edx
    a330:	48 8d 35 f2 4e 00 00 	lea    0x4ef2(%rip),%rsi        # f229 <_IO_stdin_used+0x229>
    a337:	e8 d4 9e ff ff       	call   4210 <buf_put>
    a33c:	4c 89 e8             	mov    %r13,%rax
    a33f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a344:	31 c9                	xor    %ecx,%ecx
    a346:	48 c1 e0 04          	shl    $0x4,%rax
    a34a:	48 89 df             	mov    %rbx,%rdi
    a34d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a352:	e8 e9 f4 ff ff       	call   9840 <fwp_write>
    a357:	e9 5e f6 ff ff       	jmp    99ba <fwp_write+0x17a>
    a35c:	0f 1f 40 00          	nopl   0x0(%rax)
    a360:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a365:	48 85 ff             	test   %rdi,%rdi
    a368:	79 0c                	jns    a376 <fwp_write+0xb36>
    a36a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a371:	00 
    a372:	48 03 75 10          	add    0x10(%rbp),%rsi
    a376:	48 63 3e             	movslq (%rsi),%rdi
    a379:	83 f9 02             	cmp    $0x2,%ecx
    a37c:	89 fe                	mov    %edi,%esi
    a37e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a382:	e9 f9 fb ff ff       	jmp    9f80 <fwp_write+0x740>
    a387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a38e:	00 00 
    a390:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a395:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a39a:	48 85 ff             	test   %rdi,%rdi
    a39d:	0f 88 0f 03 00 00    	js     a6b2 <fwp_write+0xe72>
    a3a3:	49 0f bf 38          	movswq (%r8),%rdi
    a3a7:	83 f9 01             	cmp    $0x1,%ecx
    a3aa:	0f b7 f7             	movzwl %di,%esi
    a3ad:	48 0f 44 f7          	cmove  %rdi,%rsi
    a3b1:	e9 ca fb ff ff       	jmp    9f80 <fwp_write+0x740>
    a3b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a3bd:	00 00 00 
    a3c0:	ba 01 00 00 00       	mov    $0x1,%edx
    a3c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a3ca:	48 83 c5 08          	add    $0x8,%rbp
    a3ce:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a3d3:	e8 38 9e ff ff       	call   4210 <buf_put>
    a3d8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a3dd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a3e2:	4d 85 ed             	test   %r13,%r13
    a3e5:	75 46                	jne    a42d <fwp_write+0xbed>
    a3e7:	e9 04 01 00 00       	jmp    a4f0 <fwp_write+0xcb0>
    a3ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a3f0:	41 80 f9 09          	cmp    $0x9,%r9b
    a3f4:	0f 84 d6 00 00 00    	je     a4d0 <fwp_write+0xc90>
    a3fa:	41 80 f9 0a          	cmp    $0xa,%r9b
    a3fe:	0f 85 9c 00 00 00    	jne    a4a0 <fwp_write+0xc60>
    a404:	ba 02 00 00 00       	mov    $0x2,%edx
    a409:	48 8d 35 f5 4d 00 00 	lea    0x4df5(%rip),%rsi        # f205 <_IO_stdin_used+0x205>
    a410:	48 89 df             	mov    %rbx,%rdi
    a413:	e8 f8 9d ff ff       	call   4210 <buf_put>
    a418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a41f:	00 
    a420:	48 83 c5 01          	add    $0x1,%rbp
    a424:	49 39 ec             	cmp    %rbp,%r12
    a427:	0f 84 c3 00 00 00    	je     a4f0 <fwp_write+0xcb0>
    a42d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a432:	41 80 f9 0d          	cmp    $0xd,%r9b
    a436:	74 28                	je     a460 <fwp_write+0xc20>
    a438:	7e b6                	jle    a3f0 <fwp_write+0xbb0>
    a43a:	41 80 f9 22          	cmp    $0x22,%r9b
    a43e:	74 40                	je     a480 <fwp_write+0xc40>
    a440:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a444:	75 5a                	jne    a4a0 <fwp_write+0xc60>
    a446:	ba 02 00 00 00       	mov    $0x2,%edx
    a44b:	48 8d 35 b0 4d 00 00 	lea    0x4db0(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    a452:	48 89 df             	mov    %rbx,%rdi
    a455:	e8 b6 9d ff ff       	call   4210 <buf_put>
    a45a:	eb c4                	jmp    a420 <fwp_write+0xbe0>
    a45c:	0f 1f 40 00          	nopl   0x0(%rax)
    a460:	ba 02 00 00 00       	mov    $0x2,%edx
    a465:	48 8d 35 9f 4d 00 00 	lea    0x4d9f(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    a46c:	48 89 df             	mov    %rbx,%rdi
    a46f:	e8 9c 9d ff ff       	call   4210 <buf_put>
    a474:	eb aa                	jmp    a420 <fwp_write+0xbe0>
    a476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a47d:	00 00 00 
    a480:	ba 02 00 00 00       	mov    $0x2,%edx
    a485:	48 8d 35 73 4d 00 00 	lea    0x4d73(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    a48c:	48 89 df             	mov    %rbx,%rdi
    a48f:	e8 7c 9d ff ff       	call   4210 <buf_put>
    a494:	eb 8a                	jmp    a420 <fwp_write+0xbe0>
    a496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a49d:	00 00 00 
    a4a0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a4a4:	0f 86 2e 01 00 00    	jbe    a5d8 <fwp_write+0xd98>
    a4aa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a4ae:	0f 84 24 01 00 00    	je     a5d8 <fwp_write+0xd98>
    a4b4:	ba 01 00 00 00       	mov    $0x1,%edx
    a4b9:	4c 89 fe             	mov    %r15,%rsi
    a4bc:	48 89 df             	mov    %rbx,%rdi
    a4bf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a4c4:	e8 47 9d ff ff       	call   4210 <buf_put>
    a4c9:	e9 52 ff ff ff       	jmp    a420 <fwp_write+0xbe0>
    a4ce:	66 90                	xchg   %ax,%ax
    a4d0:	ba 02 00 00 00       	mov    $0x2,%edx
    a4d5:	48 8d 35 2c 4d 00 00 	lea    0x4d2c(%rip),%rsi        # f208 <_IO_stdin_used+0x208>
    a4dc:	48 89 df             	mov    %rbx,%rdi
    a4df:	e8 2c 9d ff ff       	call   4210 <buf_put>
    a4e4:	e9 37 ff ff ff       	jmp    a420 <fwp_write+0xbe0>
    a4e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a4f0:	ba 01 00 00 00       	mov    $0x1,%edx
    a4f5:	4c 89 fe             	mov    %r15,%rsi
    a4f8:	48 89 df             	mov    %rbx,%rdi
    a4fb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a500:	e8 0b 9d ff ff       	call   4210 <buf_put>
    a505:	e9 cc f3 ff ff       	jmp    98d6 <fwp_write+0x96>
    a50a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a510:	83 f8 04             	cmp    $0x4,%eax
    a513:	0f 85 bb fb ff ff    	jne    a0d4 <fwp_write+0x894>
    a519:	48 8b 04 24          	mov    (%rsp),%rax
    a51d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a521:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a526:	48 c1 e8 3f          	shr    $0x3f,%rax
    a52a:	e9 96 fc ff ff       	jmp    a1c5 <fwp_write+0x985>
    a52f:	90                   	nop
    a530:	8b 0c 24             	mov    (%rsp),%ecx
    a533:	31 c0                	xor    %eax,%eax
    a535:	85 c9                	test   %ecx,%ecx
    a537:	0f 98 c0             	sets   %al
    a53a:	e9 86 fc ff ff       	jmp    a1c5 <fwp_write+0x985>
    a53f:	90                   	nop
    a540:	48 f7 d8             	neg    %rax
    a543:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a54a:	00 
    a54b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a552:	2d 
    a553:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a55a:	00 
    a55b:	48 83 d2 00          	adc    $0x0,%rdx
    a55f:	48 89 c6             	mov    %rax,%rsi
    a562:	48 f7 da             	neg    %rdx
    a565:	e8 d6 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a56a:	e9 51 f3 ff ff       	jmp    98c0 <fwp_write+0x80>
    a56f:	90                   	nop
    a570:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a575:	e9 c3 f5 ff ff       	jmp    9b3d <fwp_write+0x2fd>
    a57a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a580:	4c 89 e9             	mov    %r13,%rcx
    a583:	48 c1 e1 04          	shl    $0x4,%rcx
    a587:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a58c:	48 85 ff             	test   %rdi,%rdi
    a58f:	0f 89 eb f9 ff ff    	jns    9f80 <fwp_write+0x740>
    a595:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a599:	48 89 ce             	mov    %rcx,%rsi
    a59c:	e9 df f9 ff ff       	jmp    9f80 <fwp_write+0x740>
    a5a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a5a8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a5af:	00 
    a5b0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a5b4:	e9 20 fa ff ff       	jmp    9fd9 <fwp_write+0x799>
    a5b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a5c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a5c5:	48 8d 35 03 4c 00 00 	lea    0x4c03(%rip),%rsi        # f1cf <_IO_stdin_used+0x1cf>
    a5cc:	e9 2d f7 ff ff       	jmp    9cfe <fwp_write+0x4be>
    a5d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a5d8:	4c 8d 05 2f 4c 00 00 	lea    0x4c2f(%rip),%r8        # f20e <_IO_stdin_used+0x20e>
    a5df:	b9 10 00 00 00       	mov    $0x10,%ecx
    a5e4:	31 c0                	xor    %eax,%eax
    a5e6:	ba 02 00 00 00       	mov    $0x2,%edx
    a5eb:	be 10 00 00 00       	mov    $0x10,%esi
    a5f0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5f7:	00 
    a5f8:	e8 b3 8d ff ff       	call   33b0 <__snprintf_chk@plt>
    a5fd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a604:	00 
    a605:	e8 46 8e ff ff       	call   3450 <strlen@plt>
    a60a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a611:	00 
    a612:	48 89 df             	mov    %rbx,%rdi
    a615:	48 89 c2             	mov    %rax,%rdx
    a618:	e8 f3 9b ff ff       	call   4210 <buf_put>
    a61d:	e9 fe fd ff ff       	jmp    a420 <fwp_write+0xbe0>
    a622:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a628:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a62c:	48 8d 35 96 4b 00 00 	lea    0x4b96(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    a633:	48 8d 05 8e 4b 00 00 	lea    0x4b8e(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    a63a:	4c 89 e7             	mov    %r12,%rdi
    a63d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a641:	48 0f 46 f0          	cmovbe %rax,%rsi
    a645:	e8 a6 8d ff ff       	call   33f0 <strcpy@plt>
    a64a:	e9 71 f2 ff ff       	jmp    98c0 <fwp_write+0x80>
    a64f:	90                   	nop
    a650:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a654:	48 8d 35 6e 4b 00 00 	lea    0x4b6e(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    a65b:	48 8d 05 66 4b 00 00 	lea    0x4b66(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    a662:	0f 2f c8             	comiss %xmm0,%xmm1
    a665:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a66c:	00 
    a66d:	4c 89 e7             	mov    %r12,%rdi
    a670:	48 0f 46 f0          	cmovbe %rax,%rsi
    a674:	e8 77 8d ff ff       	call   33f0 <strcpy@plt>
    a679:	e9 42 f2 ff ff       	jmp    98c0 <fwp_write+0x80>
    a67e:	66 90                	xchg   %ax,%ax
    a680:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a685:	45 85 c0             	test   %r8d,%r8d
    a688:	75 34                	jne    a6be <fwp_write+0xe7e>
    a68a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a691:	00 
    a692:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a699:	00 00 
    a69b:	0f 85 74 f6 ff ff    	jne    9d15 <fwp_write+0x4d5>
    a6a1:	ba 02 00 00 00       	mov    $0x2,%edx
    a6a6:	48 8d 35 92 4b 00 00 	lea    0x4b92(%rip),%rsi        # f23f <_IO_stdin_used+0x23f>
    a6ad:	e9 a1 f3 ff ff       	jmp    9a53 <fwp_write+0x213>
    a6b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a6b6:	49 89 f0             	mov    %rsi,%r8
    a6b9:	e9 e5 fc ff ff       	jmp    a3a3 <fwp_write+0xb63>
    a6be:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a6c3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a6c8:	85 ff                	test   %edi,%edi
    a6ca:	0f 84 fa f3 ff ff    	je     9aca <fwp_write+0x28a>
    a6d0:	ba 01 00 00 00       	mov    $0x1,%edx
    a6d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a6da:	48 89 df             	mov    %rbx,%rdi
    a6dd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a6e2:	e8 29 9b ff ff       	call   4210 <buf_put>
    a6e7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a6ec:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a6f1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a6f7:	85 c0                	test   %eax,%eax
    a6f9:	0f 8f f0 f3 ff ff    	jg     9aef <fwp_write+0x2af>
    a6ff:	e9 34 f4 ff ff       	jmp    9b38 <fwp_write+0x2f8>
    a704:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a708:	49 89 c5             	mov    %rax,%r13
    a70b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a710:	49 89 c4             	mov    %rax,%r12
    a713:	49 c1 fd 3f          	sar    $0x3f,%r13
    a717:	4c 09 e8             	or     %r13,%rax
    a71a:	0f 84 a7 00 00 00    	je     a7c7 <fwp_write+0xf87>
    a720:	48 8d 2d d9 6c 00 00 	lea    0x6cd9(%rip),%rbp        # 11400 <units.1>
    a727:	4d 89 e7             	mov    %r12,%r15
    a72a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a72e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a733:	4c 89 ff             	mov    %r15,%rdi
    a736:	4c 89 ee             	mov    %r13,%rsi
    a739:	44 89 0c 24          	mov    %r9d,(%rsp)
    a73d:	48 99                	cqto
    a73f:	48 89 d1             	mov    %rdx,%rcx
    a742:	48 89 c2             	mov    %rax,%rdx
    a745:	e8 d6 41 00 00       	call   e920 <__divmodti4>
    a74a:	44 8b 0c 24          	mov    (%rsp),%r9d
    a74e:	48 89 c1             	mov    %rax,%rcx
    a751:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a756:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a75b:	0f 84 94 00 00 00    	je     a7f5 <fwp_write+0xfb5>
    a761:	41 83 c1 01          	add    $0x1,%r9d
    a765:	48 83 c5 10          	add    $0x10,%rbp
    a769:	41 83 f9 05          	cmp    $0x5,%r9d
    a76d:	75 bb                	jne    a72a <fwp_write+0xeea>
    a76f:	4d 85 ed             	test   %r13,%r13
    a772:	79 53                	jns    a7c7 <fwp_write+0xf87>
    a774:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a779:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a77e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a783:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a788:	48 99                	cqto
    a78a:	48 f7 d8             	neg    %rax
    a78d:	48 83 d2 00          	adc    $0x0,%rdx
    a791:	48 89 c6             	mov    %rax,%rsi
    a794:	48 f7 da             	neg    %rdx
    a797:	e8 a4 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a79c:	49 89 e8             	mov    %rbp,%r8
    a79f:	ba 00 02 00 00       	mov    $0x200,%edx
    a7a4:	be 02 00 00 00       	mov    $0x2,%esi
    a7a9:	31 c0                	xor    %eax,%eax
    a7ab:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a7b2:	00 
    a7b3:	48 8d 0d 80 4a 00 00 	lea    0x4a80(%rip),%rcx        # f23a <_IO_stdin_used+0x23a>
    a7ba:	4c 89 e7             	mov    %r12,%rdi
    a7bd:	e8 1e 8f ff ff       	call   36e0 <__sprintf_chk@plt>
    a7c2:	e9 f9 f0 ff ff       	jmp    98c0 <fwp_write+0x80>
    a7c7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a7cc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a7d1:	31 d2                	xor    %edx,%edx
    a7d3:	48 89 ef             	mov    %rbp,%rdi
    a7d6:	e8 65 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a7db:	eb bf                	jmp    a79c <fwp_write+0xf5c>
    a7dd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a7e4:	4e 61 4e 00 
    a7e8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a7ef:	00 
    a7f0:	e9 cb f0 ff ff       	jmp    98c0 <fwp_write+0x80>
    a7f5:	44 89 0c 24          	mov    %r9d,(%rsp)
    a7f9:	48 89 c8             	mov    %rcx,%rax
    a7fc:	48 85 d2             	test   %rdx,%rdx
    a7ff:	78 51                	js     a852 <fwp_write+0x1012>
    a801:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a806:	48 89 c6             	mov    %rax,%rsi
    a809:	48 89 ef             	mov    %rbp,%rdi
    a80c:	e8 2f 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a811:	44 8b 0c 24          	mov    (%rsp),%r9d
    a815:	49 63 c1             	movslq %r9d,%rax
    a818:	49 89 e8             	mov    %rbp,%r8
    a81b:	ba 00 02 00 00       	mov    $0x200,%edx
    a820:	be 02 00 00 00       	mov    $0x2,%esi
    a825:	48 c1 e0 04          	shl    $0x4,%rax
    a829:	48 8d 3d d0 6b 00 00 	lea    0x6bd0(%rip),%rdi        # 11400 <units.1>
    a830:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a837:	00 
    a838:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    a83c:	48 8d 0d f2 49 00 00 	lea    0x49f2(%rip),%rcx        # f235 <_IO_stdin_used+0x235>
    a843:	4c 89 e7             	mov    %r12,%rdi
    a846:	31 c0                	xor    %eax,%eax
    a848:	e8 93 8e ff ff       	call   36e0 <__sprintf_chk@plt>
    a84d:	e9 6e f0 ff ff       	jmp    98c0 <fwp_write+0x80>
    a852:	48 f7 d8             	neg    %rax
    a855:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a85a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a85f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a864:	48 83 d2 00          	adc    $0x0,%rdx
    a868:	48 89 c6             	mov    %rax,%rsi
    a86b:	48 f7 da             	neg    %rdx
    a86e:	e8 cd 91 ff ff       	call   3a40 <fwp_fmt_u128>
    a873:	44 8b 0c 24          	mov    (%rsp),%r9d
    a877:	eb 9c                	jmp    a815 <fwp_write+0xfd5>
    a879:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000a880 <fwp_hof0.constprop.0>:
    a880:	55                   	push   %rbp
    a881:	48 89 e5             	mov    %rsp,%rbp
    a884:	41 57                	push   %r15
    a886:	41 56                	push   %r14
    a888:	41 55                	push   %r13
    a88a:	41 54                	push   %r12
    a88c:	53                   	push   %rbx
    a88d:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    a894:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    a89b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a8a2:	00 00 
    a8a4:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a8a8:	31 c0                	xor    %eax,%eax
    a8aa:	48 85 f6             	test   %rsi,%rsi
    a8ad:	0f 84 86 06 00 00    	je     af39 <fwp_hof0.constprop.0+0x6b9>
    a8b3:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    a8b7:	49 89 f7             	mov    %rsi,%r15
    a8ba:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    a8c1:	48 8d 35 18 8f 01 00 	lea    0x18f18(%rip),%rsi        # 237e0 <fwp_heap>
    a8c8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a8cf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    a8d6:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    a8dd:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    a8e1:	48 c1 e2 10          	shl    $0x10,%rdx
    a8e5:	48 39 d0             	cmp    %rdx,%rax
    a8e8:	73 5d                	jae    a947 <fwp_hof0.constprop.0+0xc7>
    a8ea:	48 89 c2             	mov    %rax,%rdx
    a8ed:	48 c1 ea 10          	shr    $0x10,%rdx
    a8f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a8f5:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    a8fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a900:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a904:	48 85 ff             	test   %rdi,%rdi
    a907:	74 3e                	je     a947 <fwp_hof0.constprop.0+0xc7>
    a909:	0f b6 0a             	movzbl (%rdx),%ecx
    a90c:	80 f9 02             	cmp    $0x2,%cl
    a90f:	0f 84 cd 0a 00 00    	je     b3e2 <fwp_hof0.constprop.0+0xb62>
    a915:	80 f9 01             	cmp    $0x1,%cl
    a918:	75 2d                	jne    a947 <fwp_hof0.constprop.0+0xc7>
    a91a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a91d:	0f b7 c0             	movzwl %ax,%eax
    a920:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a923:	48 0f af c1          	imul   %rcx,%rax
    a927:	48 c1 e8 20          	shr    $0x20,%rax
    a92b:	48 39 d0             	cmp    %rdx,%rax
    a92e:	73 17                	jae    a947 <fwp_hof0.constprop.0+0xc7>
    a930:	48 01 c7             	add    %rax,%rdi
    a933:	0f b6 07             	movzbl (%rdi),%eax
    a936:	84 c0                	test   %al,%al
    a938:	74 0d                	je     a947 <fwp_hof0.constprop.0+0xc7>
    a93a:	3c fd                	cmp    $0xfd,%al
    a93c:	0f 87 7e 0b 00 00    	ja     b4c0 <fwp_hof0.constprop.0+0xc40>
    a942:	83 c0 01             	add    $0x1,%eax
    a945:	88 07                	mov    %al,(%rdi)
    a947:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a94e:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    a955:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    a95c:	c7 00 00 00 
    a960:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a964:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a968:	48 8b 15 c9 aa 01 00 	mov    0x1aac9(%rip),%rdx        # 25438 <fwp_fns>
    a96f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    a973:	48 8d 05 9e 86 00 00 	lea    0x869e(%rip),%rax        # 13018 <fc12>
    a97a:	44 8b 20             	mov    (%rax),%r12d
    a97d:	49 c1 e4 05          	shl    $0x5,%r12
    a981:	49 01 d4             	add    %rdx,%r12
    a984:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    a989:	48 85 c9             	test   %rcx,%rcx
    a98c:	0f 84 1d 0a 00 00    	je     b3af <fwp_hof0.constprop.0+0xb2f>
    a992:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    a997:	0f 84 7b 08 00 00    	je     b218 <fwp_hof0.constprop.0+0x998>
    a99d:	48 8d 3d 3c 8e 01 00 	lea    0x18e3c(%rip),%rdi        # 237e0 <fwp_heap>
    a9a4:	48 8d 05 6d 86 00 00 	lea    0x866d(%rip),%rax        # 13018 <fc12>
    a9ab:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    a9b2:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    a9b9:	48 89 f1             	mov    %rsi,%rcx
    a9bc:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    a9c0:	48 c1 e1 10          	shl    $0x10,%rcx
    a9c4:	48 39 c8             	cmp    %rcx,%rax
    a9c7:	73 5f                	jae    aa28 <fwp_hof0.constprop.0+0x1a8>
    a9c9:	48 89 c1             	mov    %rax,%rcx
    a9cc:	48 c1 e9 10          	shr    $0x10,%rcx
    a9d0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a9d4:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    a9db:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a9df:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    a9e3:	48 85 ff             	test   %rdi,%rdi
    a9e6:	74 40                	je     aa28 <fwp_hof0.constprop.0+0x1a8>
    a9e8:	0f b6 31             	movzbl (%rcx),%esi
    a9eb:	40 80 fe 02          	cmp    $0x2,%sil
    a9ef:	0f 84 08 09 00 00    	je     b2fd <fwp_hof0.constprop.0+0xa7d>
    a9f5:	40 80 fe 01          	cmp    $0x1,%sil
    a9f9:	75 2d                	jne    aa28 <fwp_hof0.constprop.0+0x1a8>
    a9fb:	8b 71 18             	mov    0x18(%rcx),%esi
    a9fe:	0f b7 c0             	movzwl %ax,%eax
    aa01:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aa04:	48 0f af c6          	imul   %rsi,%rax
    aa08:	48 c1 e8 20          	shr    $0x20,%rax
    aa0c:	48 39 c8             	cmp    %rcx,%rax
    aa0f:	73 17                	jae    aa28 <fwp_hof0.constprop.0+0x1a8>
    aa11:	48 01 c7             	add    %rax,%rdi
    aa14:	0f b6 07             	movzbl (%rdi),%eax
    aa17:	84 c0                	test   %al,%al
    aa19:	74 0d                	je     aa28 <fwp_hof0.constprop.0+0x1a8>
    aa1b:	3c fd                	cmp    $0xfd,%al
    aa1d:	0f 87 66 09 00 00    	ja     b389 <fwp_hof0.constprop.0+0xb09>
    aa23:	83 c0 01             	add    $0x1,%eax
    aa26:	88 07                	mov    %al,(%rdi)
    aa28:	48 8d 05 e9 85 00 00 	lea    0x85e9(%rip),%rax        # 13018 <fc12>
    aa2f:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    aa36:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aa3a:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    aa41:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    aa45:	48 8d 05 cc 85 00 00 	lea    0x85cc(%rip),%rax        # 13018 <fc12>
    aa4c:	41 8b 0c 24          	mov    (%r12),%ecx
    aa50:	2b 48 04             	sub    0x4(%rax),%ecx
    aa53:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    aa57:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    aa5b:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    aa5e:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    aa62:	49 89 c1             	mov    %rax,%r9
    aa65:	8b 00                	mov    (%rax),%eax
    aa67:	44 39 e9             	cmp    %r13d,%ecx
    aa6a:	44 0f 46 e9          	cmovbe %ecx,%r13d
    aa6e:	4d 89 cf             	mov    %r9,%r15
    aa71:	48 c1 e0 05          	shl    $0x5,%rax
    aa75:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    aa79:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    aa80:	4d 8b 50 18          	mov    0x18(%r8),%r10
    aa84:	4d 85 d2             	test   %r10,%r10
    aa87:	75 58                	jne    aae1 <fwp_hof0.constprop.0+0x261>
    aa89:	e9 f5 01 00 00       	jmp    ac83 <fwp_hof0.constprop.0+0x403>
    aa8e:	66 90                	xchg   %ax,%ax
    aa90:	45 85 ff             	test   %r15d,%r15d
    aa93:	74 69                	je     aafe <fwp_hof0.constprop.0+0x27e>
    aa95:	4c 89 e7             	mov    %r12,%rdi
    aa98:	41 ff 12             	call   *(%r10)
    aa9b:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aa9f:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    aaa3:	e8 08 c3 ff ff       	call   6db0 <fwp_closure_drop>
    aaa8:	44 39 eb             	cmp    %r13d,%ebx
    aaab:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    aaaf:	0f 84 53 07 00 00    	je     b208 <fwp_hof0.constprop.0+0x988>
    aab5:	44 8b 00             	mov    (%rax),%r8d
    aab8:	45 29 fe             	sub    %r15d,%r14d
    aabb:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    aabf:	49 89 c1             	mov    %rax,%r9
    aac2:	45 89 f5             	mov    %r14d,%r13d
    aac5:	49 c1 e0 05          	shl    $0x5,%r8
    aac9:	4c 03 05 68 a9 01 00 	add    0x1a968(%rip),%r8        # 25438 <fwp_fns>
    aad0:	4d 8b 50 18          	mov    0x18(%r8),%r10
    aad4:	4d 85 d2             	test   %r10,%r10
    aad7:	0f 84 a3 01 00 00    	je     ac80 <fwp_hof0.constprop.0+0x400>
    aadd:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aae1:	41 8b 49 04          	mov    0x4(%r9),%ecx
    aae5:	45 8b 38             	mov    (%r8),%r15d
    aae8:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    aaec:	45 39 fe             	cmp    %r15d,%r14d
    aaef:	0f 82 6b 04 00 00    	jb     af60 <fwp_hof0.constprop.0+0x6e0>
    aaf5:	44 89 fb             	mov    %r15d,%ebx
    aaf8:	29 cb                	sub    %ecx,%ebx
    aafa:	85 c9                	test   %ecx,%ecx
    aafc:	74 92                	je     aa90 <fwp_hof0.constprop.0+0x210>
    aafe:	45 85 ff             	test   %r15d,%r15d
    ab01:	b8 01 00 00 00       	mov    $0x1,%eax
    ab06:	48 89 e6             	mov    %rsp,%rsi
    ab09:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    ab0d:	41 0f 45 c7          	cmovne %r15d,%eax
    ab11:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    ab18:	00 
    ab19:	48 c1 e8 04          	shr    $0x4,%rax
    ab1d:	48 c1 e0 04          	shl    $0x4,%rax
    ab21:	48 89 c7             	mov    %rax,%rdi
    ab24:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    ab2b:	48 29 fe             	sub    %rdi,%rsi
    ab2e:	48 39 f4             	cmp    %rsi,%rsp
    ab31:	74 15                	je     ab48 <fwp_hof0.constprop.0+0x2c8>
    ab33:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    ab3a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    ab41:	00 00 
    ab43:	48 39 f4             	cmp    %rsi,%rsp
    ab46:	75 eb                	jne    ab33 <fwp_hof0.constprop.0+0x2b3>
    ab48:	25 ff 0f 00 00       	and    $0xfff,%eax
    ab4d:	48 29 c4             	sub    %rax,%rsp
    ab50:	48 85 c0             	test   %rax,%rax
    ab53:	74 06                	je     ab5b <fwp_hof0.constprop.0+0x2db>
    ab55:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    ab5b:	89 cf                	mov    %ecx,%edi
    ab5d:	49 89 e3             	mov    %rsp,%r11
    ab60:	31 c0                	xor    %eax,%eax
    ab62:	48 c1 e7 03          	shl    $0x3,%rdi
    ab66:	85 c9                	test   %ecx,%ecx
    ab68:	74 28                	je     ab92 <fwp_hof0.constprop.0+0x312>
    ab6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab71:	00 00 00 00 
    ab75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab7c:	00 00 00 00 
    ab80:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    ab85:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    ab89:	48 83 c0 08          	add    $0x8,%rax
    ab8d:	48 39 c7             	cmp    %rax,%rdi
    ab90:	75 ee                	jne    ab80 <fwp_hof0.constprop.0+0x300>
    ab92:	85 db                	test   %ebx,%ebx
    ab94:	74 1f                	je     abb5 <fwp_hof0.constprop.0+0x335>
    ab96:	89 de                	mov    %ebx,%esi
    ab98:	4c 89 e0             	mov    %r12,%rax
    ab9b:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    ab9f:	90                   	nop
    aba0:	48 8b 30             	mov    (%rax),%rsi
    aba3:	89 ca                	mov    %ecx,%edx
    aba5:	48 83 c0 08          	add    $0x8,%rax
    aba9:	83 c1 01             	add    $0x1,%ecx
    abac:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    abb0:	48 39 c7             	cmp    %rax,%rdi
    abb3:	75 eb                	jne    aba0 <fwp_hof0.constprop.0+0x320>
    abb5:	48 8d 15 24 8c 01 00 	lea    0x18c24(%rip),%rdx        # 237e0 <fwp_heap>
    abbc:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    abc0:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    abc7:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    abce:	48 89 f1             	mov    %rsi,%rcx
    abd1:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    abd5:	48 c1 e1 10          	shl    $0x10,%rcx
    abd9:	48 39 c8             	cmp    %rcx,%rax
    abdc:	73 4c                	jae    ac2a <fwp_hof0.constprop.0+0x3aa>
    abde:	48 89 c1             	mov    %rax,%rcx
    abe1:	48 c1 e9 10          	shr    $0x10,%rcx
    abe5:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    abe9:	48 8b 0d e8 9f 01 00 	mov    0x19fe8(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    abf0:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    abf4:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    abf8:	48 85 f6             	test   %rsi,%rsi
    abfb:	74 2d                	je     ac2a <fwp_hof0.constprop.0+0x3aa>
    abfd:	0f b6 39             	movzbl (%rcx),%edi
    ac00:	40 80 ff 02          	cmp    $0x2,%dil
    ac04:	74 6a                	je     ac70 <fwp_hof0.constprop.0+0x3f0>
    ac06:	40 80 ff 01          	cmp    $0x1,%dil
    ac0a:	75 1e                	jne    ac2a <fwp_hof0.constprop.0+0x3aa>
    ac0c:	8b 79 18             	mov    0x18(%rcx),%edi
    ac0f:	0f b7 c0             	movzwl %ax,%eax
    ac12:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ac15:	48 0f af c7          	imul   %rdi,%rax
    ac19:	48 c1 e8 20          	shr    $0x20,%rax
    ac1d:	48 39 c8             	cmp    %rcx,%rax
    ac20:	73 08                	jae    ac2a <fwp_hof0.constprop.0+0x3aa>
    ac22:	48 01 c6             	add    %rax,%rsi
    ac25:	80 3e 01             	cmpb   $0x1,(%rsi)
    ac28:	74 36                	je     ac60 <fwp_hof0.constprop.0+0x3e0>
    ac2a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    ac2e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ac32:	be 01 00 00 00       	mov    $0x1,%esi
    ac37:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    ac3b:	41 ff 52 08          	call   *0x8(%r10)
    ac3f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    ac43:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    ac47:	49 8b 40 18          	mov    0x18(%r8),%rax
    ac4b:	4c 89 df             	mov    %r11,%rdi
    ac4e:	ff 10                	call   *(%rax)
    ac50:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    ac54:	e9 42 fe ff ff       	jmp    aa9b <fwp_hof0.constprop.0+0x21b>
    ac59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac60:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    ac67:	00 
    ac68:	eb dd                	jmp    ac47 <fwp_hof0.constprop.0+0x3c7>
    ac6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac70:	66 85 c0             	test   %ax,%ax
    ac73:	75 b5                	jne    ac2a <fwp_hof0.constprop.0+0x3aa>
    ac75:	eb ae                	jmp    ac25 <fwp_hof0.constprop.0+0x3a5>
    ac77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac7e:	00 00 
    ac80:	49 89 c7             	mov    %rax,%r15
    ac83:	4c 89 ff             	mov    %r15,%rdi
    ac86:	e8 05 ba ff ff       	call   6690 <fwp_rc_share>
    ac8b:	45 85 ed             	test   %r13d,%r13d
    ac8e:	74 21                	je     acb1 <fwp_hof0.constprop.0+0x431>
    ac90:	44 89 ea             	mov    %r13d,%edx
    ac93:	4c 89 e3             	mov    %r12,%rbx
    ac96:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    ac9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aca0:	48 8b 3b             	mov    (%rbx),%rdi
    aca3:	48 83 c3 08          	add    $0x8,%rbx
    aca7:	e8 e4 b9 ff ff       	call   6690 <fwp_rc_share>
    acac:	4c 39 f3             	cmp    %r14,%rbx
    acaf:	75 ef                	jne    aca0 <fwp_hof0.constprop.0+0x420>
    acb1:	4c 89 e2             	mov    %r12,%rdx
    acb4:	44 89 ee             	mov    %r13d,%esi
    acb7:	4c 89 ff             	mov    %r15,%rdi
    acba:	e8 f1 b0 ff ff       	call   5db0 <fwp_apply>
    acbf:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    acc3:	8b 75 94             	mov    -0x6c(%rbp),%esi
    acc6:	39 75 90             	cmp    %esi,-0x70(%rbp)
    acc9:	0f 83 87 00 00 00    	jae    ad56 <fwp_hof0.constprop.0+0x4d6>
    accf:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    acd5:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    acd9:	48 89 c2             	mov    %rax,%rdx
    acdc:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    ace0:	29 d6                	sub    %edx,%esi
    ace2:	48 8b 15 4f a7 01 00 	mov    0x1a74f(%rip),%rdx        # 25438 <fwp_fns>
    ace9:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    aced:	89 75 94             	mov    %esi,-0x6c(%rbp)
    acf0:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    acf4:	44 8b 26             	mov    (%rsi),%r12d
    acf7:	48 89 f0             	mov    %rsi,%rax
    acfa:	49 c1 e4 05          	shl    $0x5,%r12
    acfe:	49 01 d4             	add    %rdx,%r12
    ad01:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    ad07:	0f 85 3f fd ff ff    	jne    aa4c <fwp_hof0.constprop.0+0x1cc>
    ad0d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ad11:	e8 7a b9 ff ff       	call   6690 <fwp_rc_share>
    ad16:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    ad1a:	45 85 f6             	test   %r14d,%r14d
    ad1d:	74 23                	je     ad42 <fwp_hof0.constprop.0+0x4c2>
    ad1f:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    ad23:	31 db                	xor    %ebx,%ebx
    ad25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad2c:	00 00 00 00 
    ad30:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    ad34:	48 83 c3 01          	add    $0x1,%rbx
    ad38:	e8 53 b9 ff ff       	call   6690 <fwp_rc_share>
    ad3d:	44 39 f3             	cmp    %r14d,%ebx
    ad40:	72 ee                	jb     ad30 <fwp_hof0.constprop.0+0x4b0>
    ad42:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    ad46:	8b 75 94             	mov    -0x6c(%rbp),%esi
    ad49:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ad4d:	e8 5e b0 ff ff       	call   5db0 <fwp_apply>
    ad52:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ad56:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    ad5d:	01 
    ad5e:	0f 85 00 fc ff ff    	jne    a964 <fwp_hof0.constprop.0+0xe4>
    ad64:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    ad68:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    ad6f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ad73:	b9 01 00 00 00       	mov    $0x1,%ecx
    ad78:	48 8d 15 01 7e 00 00 	lea    0x7e01(%rip),%rdx        # 12b80 <d0>
    ad7f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    ad86:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    ad8d:	00 
    ad8e:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    ad92:	e8 a9 ea ff ff       	call   9840 <fwp_write>
    ad97:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    ad9b:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    ad9f:	48 8d 05 eb 42 00 00 	lea    0x42eb(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    ada6:	48 85 c9             	test   %rcx,%rcx
    ada9:	48 0f 44 c8          	cmove  %rax,%rcx
    adad:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    adb1:	0f 87 f5 06 00 00    	ja     b4ac <fwp_hof0.constprop.0+0xc2c>
    adb7:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    adbb:	be 01 00 00 00       	mov    $0x1,%esi
    adc0:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    adc4:	e8 c7 ae ff ff       	call   5c90 <fwp_heap_alloc>
    adc9:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    adcd:	4c 89 f2             	mov    %r14,%rdx
    add0:	4c 89 30             	mov    %r14,(%rax)
    add3:	4c 8d 60 08          	lea    0x8(%rax),%r12
    add7:	48 89 c3             	mov    %rax,%rbx
    adda:	4c 89 e7             	mov    %r12,%rdi
    addd:	e8 be 87 ff ff       	call   35a0 <memcpy@plt>
    ade2:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    ade8:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    adec:	e8 cf 85 ff ff       	call   33c0 <free@plt>
    adf1:	48 8d 35 e8 89 01 00 	lea    0x189e8(%rip),%rsi        # 237e0 <fwp_heap>
    adf8:	48 89 d8             	mov    %rbx,%rax
    adfb:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ae02:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ae09:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    ae0d:	48 c1 e2 10          	shl    $0x10,%rdx
    ae11:	48 39 d0             	cmp    %rdx,%rax
    ae14:	73 57                	jae    ae6d <fwp_hof0.constprop.0+0x5ed>
    ae16:	48 89 c2             	mov    %rax,%rdx
    ae19:	48 c1 ea 10          	shr    $0x10,%rdx
    ae1d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae21:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ae28:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae2c:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ae30:	4d 85 f6             	test   %r14,%r14
    ae33:	74 38                	je     ae6d <fwp_hof0.constprop.0+0x5ed>
    ae35:	0f b6 0a             	movzbl (%rdx),%ecx
    ae38:	80 f9 02             	cmp    $0x2,%cl
    ae3b:	0f 84 c9 05 00 00    	je     b40a <fwp_hof0.constprop.0+0xb8a>
    ae41:	80 f9 01             	cmp    $0x1,%cl
    ae44:	75 27                	jne    ae6d <fwp_hof0.constprop.0+0x5ed>
    ae46:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae49:	0f b7 c0             	movzwl %ax,%eax
    ae4c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae4f:	48 0f af c1          	imul   %rcx,%rax
    ae53:	48 c1 e8 20          	shr    $0x20,%rax
    ae57:	48 39 d0             	cmp    %rdx,%rax
    ae5a:	73 11                	jae    ae6d <fwp_hof0.constprop.0+0x5ed>
    ae5c:	49 01 c6             	add    %rax,%r14
    ae5f:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ae63:	0f 84 67 06 00 00    	je     b4d0 <fwp_hof0.constprop.0+0xc50>
    ae69:	41 c6 06 01          	movb   $0x1,(%r14)
    ae6d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ae71:	e8 5a bc ff ff       	call   6ad0 <fwp_drop0>
    ae76:	48 8b 13             	mov    (%rbx),%rdx
    ae79:	be 01 00 00 00       	mov    $0x1,%esi
    ae7e:	4c 89 e7             	mov    %r12,%rdi
    ae81:	48 8b 0d b8 a5 01 00 	mov    0x1a5b8(%rip),%rcx        # 25440 <fwp_prog_out>
    ae88:	e8 f3 87 ff ff       	call   3680 <fwrite@plt>
    ae8d:	48 8b 35 ac a5 01 00 	mov    0x1a5ac(%rip),%rsi        # 25440 <fwp_prog_out>
    ae94:	bf 0a 00 00 00       	mov    $0xa,%edi
    ae99:	e8 42 86 ff ff       	call   34e0 <fputc@plt>
    ae9e:	48 8d 35 3b 89 01 00 	lea    0x1893b(%rip),%rsi        # 237e0 <fwp_heap>
    aea5:	48 89 d8             	mov    %rbx,%rax
    aea8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    aeaf:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    aeb6:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    aeba:	48 c1 e2 10          	shl    $0x10,%rdx
    aebe:	48 39 d0             	cmp    %rdx,%rax
    aec1:	73 69                	jae    af2c <fwp_hof0.constprop.0+0x6ac>
    aec3:	48 89 c2             	mov    %rax,%rdx
    aec6:	48 c1 ea 10          	shr    $0x10,%rdx
    aeca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aece:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    aed5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aed9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aedd:	4d 85 e4             	test   %r12,%r12
    aee0:	74 4a                	je     af2c <fwp_hof0.constprop.0+0x6ac>
    aee2:	0f b6 0a             	movzbl (%rdx),%ecx
    aee5:	80 f9 02             	cmp    $0x2,%cl
    aee8:	0f 84 2a 05 00 00    	je     b418 <fwp_hof0.constprop.0+0xb98>
    aeee:	80 f9 01             	cmp    $0x1,%cl
    aef1:	75 39                	jne    af2c <fwp_hof0.constprop.0+0x6ac>
    aef3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aef6:	0f b7 c0             	movzwl %ax,%eax
    aef9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aefc:	48 0f af c1          	imul   %rcx,%rax
    af00:	48 c1 e8 20          	shr    $0x20,%rax
    af04:	48 39 d0             	cmp    %rdx,%rax
    af07:	73 23                	jae    af2c <fwp_hof0.constprop.0+0x6ac>
    af09:	49 01 c4             	add    %rax,%r12
    af0c:	41 0f b6 04 24       	movzbl (%r12),%eax
    af11:	84 c0                	test   %al,%al
    af13:	74 17                	je     af2c <fwp_hof0.constprop.0+0x6ac>
    af15:	3c 01                	cmp    $0x1,%al
    af17:	0f 84 d3 04 00 00    	je     b3f0 <fwp_hof0.constprop.0+0xb70>
    af1d:	3c ff                	cmp    $0xff,%al
    af1f:	0f 84 01 05 00 00    	je     b426 <fwp_hof0.constprop.0+0xba6>
    af25:	83 e8 01             	sub    $0x1,%eax
    af28:	41 88 04 24          	mov    %al,(%r12)
    af2c:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    af30:	4d 85 ff             	test   %r15,%r15
    af33:	0f 85 88 f9 ff ff    	jne    a8c1 <fwp_hof0.constprop.0+0x41>
    af39:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    af3d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    af44:	00 00 
    af46:	0f 85 7e 05 00 00    	jne    b4ca <fwp_hof0.constprop.0+0xc4a>
    af4c:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    af50:	31 c0                	xor    %eax,%eax
    af52:	5b                   	pop    %rbx
    af53:	41 5c                	pop    %r12
    af55:	41 5d                	pop    %r13
    af57:	41 5e                	pop    %r14
    af59:	41 5f                	pop    %r15
    af5b:	5d                   	pop    %rbp
    af5c:	c3                   	ret
    af5d:	0f 1f 00             	nopl   (%rax)
    af60:	48 8d 1d 79 88 01 00 	lea    0x18879(%rip),%rbx        # 237e0 <fwp_heap>
    af67:	41 8d 76 01          	lea    0x1(%r14),%esi
    af6b:	45 89 f7             	mov    %r14d,%r15d
    af6e:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    af74:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    af7b:	00 
    af7c:	85 c0                	test   %eax,%eax
    af7e:	0f 84 a9 03 00 00    	je     b32d <fwp_hof0.constprop.0+0xaad>
    af84:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    af8b:	0f 87 9c 03 00 00    	ja     b32d <fwp_hof0.constprop.0+0xaad>
    af91:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    af95:	48 c1 e8 04          	shr    $0x4,%rax
    af99:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    afa0:	00 
    afa1:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    afa8:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    afac:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    afb0:	4c 8b 12             	mov    (%rdx),%r10
    afb3:	4d 85 d2             	test   %r10,%r10
    afb6:	0f 84 4f 03 00 00    	je     b30b <fwp_hof0.constprop.0+0xa8b>
    afbc:	4d 8b 1a             	mov    (%r10),%r11
    afbf:	49 f7 d3             	not    %r11
    afc2:	4c 89 1a             	mov    %r11,(%rdx)
    afc5:	48 39 c7             	cmp    %rax,%rdi
    afc8:	73 50                	jae    b01a <fwp_hof0.constprop.0+0x79a>
    afca:	48 89 fa             	mov    %rdi,%rdx
    afcd:	48 83 c7 08          	add    $0x8,%rdi
    afd1:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    afd8:	00 
    afd9:	48 f7 d2             	not    %rdx
    afdc:	48 01 c2             	add    %rax,%rdx
    afdf:	48 c1 ea 03          	shr    $0x3,%rdx
    afe3:	48 39 c7             	cmp    %rax,%rdi
    afe6:	73 32                	jae    b01a <fwp_hof0.constprop.0+0x79a>
    afe8:	83 e2 01             	and    $0x1,%edx
    afeb:	74 13                	je     b000 <fwp_hof0.constprop.0+0x780>
    afed:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    aff4:	00 
    aff5:	48 83 c7 08          	add    $0x8,%rdi
    aff9:	48 39 c7             	cmp    %rax,%rdi
    affc:	73 1c                	jae    b01a <fwp_hof0.constprop.0+0x79a>
    affe:	66 90                	xchg   %ax,%ax
    b000:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b007:	00 
    b008:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    b00f:	00 00 
    b011:	48 83 c7 10          	add    $0x10,%rdi
    b015:	48 39 c7             	cmp    %rax,%rdi
    b018:	72 e6                	jb     b000 <fwp_hof0.constprop.0+0x780>
    b01a:	48 8d 35 bf 87 01 00 	lea    0x187bf(%rip),%rsi        # 237e0 <fwp_heap>
    b021:	48 89 c2             	mov    %rax,%rdx
    b024:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    b02b:	0f 82 6a 04 00 00    	jb     b49b <fwp_hof0.constprop.0+0xc1b>
    b031:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    b038:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    b03f:	73 07                	jae    b048 <fwp_hof0.constprop.0+0x7c8>
    b041:	48 89 15 c0 9b 01 00 	mov    %rdx,0x19bc0(%rip)        # 24c08 <fwp_heap+0x1428>
    b048:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b04c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b051:	f2 0f 58 05 bf 9b 01 	addsd  0x19bbf(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    b058:	00 
    b059:	f2 0f 11 05 b7 9b 01 	movsd  %xmm0,0x19bb7(%rip)        # 24c18 <fwp_heap+0x1438>
    b060:	00 
    b061:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b066:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b06b:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b06f:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b074:	85 c9                	test   %ecx,%ecx
    b076:	74 37                	je     b0af <fwp_hof0.constprop.0+0x82f>
    b078:	89 ca                	mov    %ecx,%edx
    b07a:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b07e:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b082:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b085:	48 c1 e2 03          	shl    $0x3,%rdx
    b089:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b090:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b094:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b098:	e8 73 85 ff ff       	call   3610 <memmove@plt>
    b09d:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b0a1:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b0a5:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b0a8:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b0af:	45 85 ed             	test   %r13d,%r13d
    b0b2:	74 23                	je     b0d7 <fwp_hof0.constprop.0+0x857>
    b0b4:	45 89 ed             	mov    %r13d,%r13d
    b0b7:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b0bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b0c0:	49 8b 14 24          	mov    (%r12),%rdx
    b0c4:	89 c8                	mov    %ecx,%eax
    b0c6:	49 83 c4 08          	add    $0x8,%r12
    b0ca:	83 c1 01             	add    $0x1,%ecx
    b0cd:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b0d2:	4c 39 e6             	cmp    %r12,%rsi
    b0d5:	75 e9                	jne    b0c0 <fwp_hof0.constprop.0+0x840>
    b0d7:	48 8d 35 02 87 01 00 	lea    0x18702(%rip),%rsi        # 237e0 <fwp_heap>
    b0de:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b0e2:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b0e9:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b0f0:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b0f4:	48 c1 e2 10          	shl    $0x10,%rdx
    b0f8:	48 39 d0             	cmp    %rdx,%rax
    b0fb:	73 54                	jae    b151 <fwp_hof0.constprop.0+0x8d1>
    b0fd:	48 89 c2             	mov    %rax,%rdx
    b100:	48 c1 ea 10          	shr    $0x10,%rdx
    b104:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b108:	48 8b 15 c9 9a 01 00 	mov    0x19ac9(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b10f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b113:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b117:	48 85 c9             	test   %rcx,%rcx
    b11a:	74 35                	je     b151 <fwp_hof0.constprop.0+0x8d1>
    b11c:	0f b6 32             	movzbl (%rdx),%esi
    b11f:	40 80 fe 02          	cmp    $0x2,%sil
    b123:	0f 84 52 02 00 00    	je     b37b <fwp_hof0.constprop.0+0xafb>
    b129:	40 80 fe 01          	cmp    $0x1,%sil
    b12d:	75 22                	jne    b151 <fwp_hof0.constprop.0+0x8d1>
    b12f:	8b 72 18             	mov    0x18(%rdx),%esi
    b132:	0f b7 c0             	movzwl %ax,%eax
    b135:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b138:	48 0f af c6          	imul   %rsi,%rax
    b13c:	48 c1 e8 20          	shr    $0x20,%rax
    b140:	48 39 d0             	cmp    %rdx,%rax
    b143:	73 0c                	jae    b151 <fwp_hof0.constprop.0+0x8d1>
    b145:	48 01 c1             	add    %rax,%rcx
    b148:	80 39 01             	cmpb   $0x1,(%rcx)
    b14b:	0f 84 9f 01 00 00    	je     b2f0 <fwp_hof0.constprop.0+0xa70>
    b151:	49 8b 40 18          	mov    0x18(%r8),%rax
    b155:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b159:	be 01 00 00 00       	mov    $0x1,%esi
    b15e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b162:	ff 50 08             	call   *0x8(%rax)
    b165:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b169:	48 8d 35 70 86 01 00 	lea    0x18670(%rip),%rsi        # 237e0 <fwp_heap>
    b170:	4c 89 d0             	mov    %r10,%rax
    b173:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b17a:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b181:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b185:	48 c1 e2 10          	shl    $0x10,%rdx
    b189:	48 39 d0             	cmp    %rdx,%rax
    b18c:	73 59                	jae    b1e7 <fwp_hof0.constprop.0+0x967>
    b18e:	48 89 c2             	mov    %rax,%rdx
    b191:	48 c1 ea 10          	shr    $0x10,%rdx
    b195:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b199:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b1a0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b1a4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b1a8:	4d 85 e4             	test   %r12,%r12
    b1ab:	74 3a                	je     b1e7 <fwp_hof0.constprop.0+0x967>
    b1ad:	0f b6 0a             	movzbl (%rdx),%ecx
    b1b0:	80 f9 02             	cmp    $0x2,%cl
    b1b3:	0f 84 99 01 00 00    	je     b352 <fwp_hof0.constprop.0+0xad2>
    b1b9:	80 f9 01             	cmp    $0x1,%cl
    b1bc:	75 29                	jne    b1e7 <fwp_hof0.constprop.0+0x967>
    b1be:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b1c1:	0f b7 c0             	movzwl %ax,%eax
    b1c4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b1c7:	48 0f af c1          	imul   %rcx,%rax
    b1cb:	48 c1 e8 20          	shr    $0x20,%rax
    b1cf:	48 39 d0             	cmp    %rdx,%rax
    b1d2:	73 13                	jae    b1e7 <fwp_hof0.constprop.0+0x967>
    b1d4:	49 01 c4             	add    %rax,%r12
    b1d7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b1dc:	0f 84 84 01 00 00    	je     b366 <fwp_hof0.constprop.0+0xae6>
    b1e2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b1e7:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b1eb:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b1ef:	e8 bc bb ff ff       	call   6db0 <fwp_closure_drop>
    b1f4:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b1f8:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b1fc:	e9 c2 fa ff ff       	jmp    acc3 <fwp_hof0.constprop.0+0x443>
    b201:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b208:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b20c:	e9 b2 fa ff ff       	jmp    acc3 <fwp_hof0.constprop.0+0x443>
    b211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b218:	41 8b 34 24          	mov    (%r12),%esi
    b21c:	8b 05 fa 7d 00 00    	mov    0x7dfa(%rip),%eax        # 1301c <fc12+0x4>
    b222:	89 f7                	mov    %esi,%edi
    b224:	29 c7                	sub    %eax,%edi
    b226:	83 ff 01             	cmp    $0x1,%edi
    b229:	0f 85 6e f7 ff ff    	jne    a99d <fwp_hof0.constprop.0+0x11d>
    b22f:	48 89 e3             	mov    %rsp,%rbx
    b232:	85 c0                	test   %eax,%eax
    b234:	0f 84 60 01 00 00    	je     b39a <fwp_hof0.constprop.0+0xb1a>
    b23a:	89 f1                	mov    %esi,%ecx
    b23c:	ba 08 00 00 00       	mov    $0x8,%edx
    b241:	48 c1 e1 03          	shl    $0x3,%rcx
    b245:	85 f6                	test   %esi,%esi
    b247:	48 89 e6             	mov    %rsp,%rsi
    b24a:	48 0f 45 d1          	cmovne %rcx,%rdx
    b24e:	49 89 d7             	mov    %rdx,%r15
    b251:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b255:	48 c1 ea 04          	shr    $0x4,%rdx
    b259:	48 c1 e2 04          	shl    $0x4,%rdx
    b25d:	48 89 d7             	mov    %rdx,%rdi
    b260:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b267:	48 29 fe             	sub    %rdi,%rsi
    b26a:	48 39 f4             	cmp    %rsi,%rsp
    b26d:	74 15                	je     b284 <fwp_hof0.constprop.0+0xa04>
    b26f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b276:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b27d:	00 00 
    b27f:	48 39 f4             	cmp    %rsi,%rsp
    b282:	75 eb                	jne    b26f <fwp_hof0.constprop.0+0x9ef>
    b284:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b28a:	48 29 d4             	sub    %rdx,%rsp
    b28d:	48 85 d2             	test   %rdx,%rdx
    b290:	74 06                	je     b298 <fwp_hof0.constprop.0+0xa18>
    b292:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b298:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b29f:	00 
    b2a0:	4c 89 f9             	mov    %r15,%rcx
    b2a3:	48 8d 35 76 7d 00 00 	lea    0x7d76(%rip),%rsi        # 13020 <descent_active_phase>
    b2aa:	48 89 e7             	mov    %rsp,%rdi
    b2ad:	4c 89 f2             	mov    %r14,%rdx
    b2b0:	e8 bb 82 ff ff       	call   3570 <__memcpy_chk@plt>
    b2b5:	4d 39 f7             	cmp    %r14,%r15
    b2b8:	4c 89 f9             	mov    %r15,%rcx
    b2bb:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b2bf:	49 0f 42 ce          	cmovb  %r14,%rcx
    b2c3:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b2ca:	ba 08 00 00 00       	mov    $0x8,%edx
    b2cf:	4c 29 f1             	sub    %r14,%rcx
    b2d2:	e8 99 82 ff ff       	call   3570 <__memcpy_chk@plt>
    b2d7:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b2dc:	48 89 e7             	mov    %rsp,%rdi
    b2df:	ff 10                	call   *(%rax)
    b2e1:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b2e5:	e9 bd 00 00 00       	jmp    b3a7 <fwp_hof0.constprop.0+0xb27>
    b2ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b2f0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b2f7:	00 
    b2f8:	e9 6c fe ff ff       	jmp    b169 <fwp_hof0.constprop.0+0x8e9>
    b2fd:	66 85 c0             	test   %ax,%ax
    b300:	0f 85 22 f7 ff ff    	jne    aa28 <fwp_hof0.constprop.0+0x1a8>
    b306:	e9 09 f7 ff ff       	jmp    aa14 <fwp_hof0.constprop.0+0x194>
    b30b:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b30f:	4d 85 d2             	test   %r10,%r10
    b312:	74 19                	je     b32d <fwp_hof0.constprop.0+0xaad>
    b314:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b318:	4d 29 d3             	sub    %r10,%r11
    b31b:	49 39 c3             	cmp    %rax,%r11
    b31e:	72 0d                	jb     b32d <fwp_hof0.constprop.0+0xaad>
    b320:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b324:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b328:	e9 98 fc ff ff       	jmp    afc5 <fwp_hof0.constprop.0+0x745>
    b32d:	31 f6                	xor    %esi,%esi
    b32f:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b332:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b336:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b33a:	e8 51 a9 ff ff       	call   5c90 <fwp_heap_alloc>
    b33f:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b342:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b346:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b34a:	49 89 c2             	mov    %rax,%r10
    b34d:	e9 0f fd ff ff       	jmp    b061 <fwp_hof0.constprop.0+0x7e1>
    b352:	66 85 c0             	test   %ax,%ax
    b355:	0f 85 8c fe ff ff    	jne    b1e7 <fwp_hof0.constprop.0+0x967>
    b35b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b360:	0f 85 7c fe ff ff    	jne    b1e2 <fwp_hof0.constprop.0+0x962>
    b366:	4c 89 e7             	mov    %r12,%rdi
    b369:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b36d:	e8 de a1 ff ff       	call   5550 <fwp_rc_forget_slot>
    b372:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b376:	e9 67 fe ff ff       	jmp    b1e2 <fwp_hof0.constprop.0+0x962>
    b37b:	66 85 c0             	test   %ax,%ax
    b37e:	0f 85 cd fd ff ff    	jne    b151 <fwp_hof0.constprop.0+0x8d1>
    b384:	e9 bf fd ff ff       	jmp    b148 <fwp_hof0.constprop.0+0x8c8>
    b389:	e8 a2 a0 ff ff       	call   5430 <fwp_rc_wide_dup>
    b38e:	48 8b 15 a3 a0 01 00 	mov    0x1a0a3(%rip),%rdx        # 25438 <fwp_fns>
    b395:	e9 8e f6 ff ff       	jmp    aa28 <fwp_hof0.constprop.0+0x1a8>
    b39a:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b3a1:	ff 11                	call   *(%rcx)
    b3a3:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b3a7:	48 89 dc             	mov    %rbx,%rsp
    b3aa:	e9 a7 f9 ff ff       	jmp    ad56 <fwp_hof0.constprop.0+0x4d6>
    b3af:	48 89 c7             	mov    %rax,%rdi
    b3b2:	e8 d9 b2 ff ff       	call   6690 <fwp_rc_share>
    b3b7:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b3bb:	e8 d0 b2 ff ff       	call   6690 <fwp_rc_share>
    b3c0:	48 8d 05 51 7c 00 00 	lea    0x7c51(%rip),%rax        # 13018 <fc12>
    b3c7:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b3ce:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b3d2:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b3d9:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b3dd:	e9 60 f9 ff ff       	jmp    ad42 <fwp_hof0.constprop.0+0x4c2>
    b3e2:	66 85 c0             	test   %ax,%ax
    b3e5:	0f 85 5c f5 ff ff    	jne    a947 <fwp_hof0.constprop.0+0xc7>
    b3eb:	e9 43 f5 ff ff       	jmp    a933 <fwp_hof0.constprop.0+0xb3>
    b3f0:	48 89 df             	mov    %rbx,%rdi
    b3f3:	e8 c8 b3 ff ff       	call   67c0 <fwp_rc_free_arr>
    b3f8:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b3fc:	4d 85 ff             	test   %r15,%r15
    b3ff:	0f 85 bc f4 ff ff    	jne    a8c1 <fwp_hof0.constprop.0+0x41>
    b405:	e9 2f fb ff ff       	jmp    af39 <fwp_hof0.constprop.0+0x6b9>
    b40a:	66 85 c0             	test   %ax,%ax
    b40d:	0f 85 5a fa ff ff    	jne    ae6d <fwp_hof0.constprop.0+0x5ed>
    b413:	e9 47 fa ff ff       	jmp    ae5f <fwp_hof0.constprop.0+0x5df>
    b418:	66 85 c0             	test   %ax,%ax
    b41b:	0f 85 0b fb ff ff    	jne    af2c <fwp_hof0.constprop.0+0x6ac>
    b421:	e9 e6 fa ff ff       	jmp    af0c <fwp_hof0.constprop.0+0x68c>
    b426:	4c 89 e0             	mov    %r12,%rax
    b429:	48 8d 35 b0 83 01 00 	lea    0x183b0(%rip),%rsi        # 237e0 <fwp_heap>
    b430:	48 c1 e8 11          	shr    $0x11,%rax
    b434:	4c 31 e0             	xor    %r12,%rax
    b437:	48 89 c2             	mov    %rax,%rdx
    b43a:	48 c1 ea 09          	shr    $0x9,%rdx
    b43e:	48 31 d0             	xor    %rdx,%rax
    b441:	0f b6 c0             	movzbl %al,%eax
    b444:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b44b:	00 
    b44c:	48 85 d2             	test   %rdx,%rdx
    b44f:	75 18                	jne    b469 <fwp_hof0.constprop.0+0xbe9>
    b451:	eb 4d                	jmp    b4a0 <fwp_hof0.constprop.0+0xc20>
    b453:	66 90                	xchg   %ax,%ax
    b455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b45c:	00 00 00 00 
    b460:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b464:	48 85 d2             	test   %rdx,%rdx
    b467:	74 37                	je     b4a0 <fwp_hof0.constprop.0+0xc20>
    b469:	48 89 d0             	mov    %rdx,%rax
    b46c:	4c 39 22             	cmp    %r12,(%rdx)
    b46f:	75 ef                	jne    b460 <fwp_hof0.constprop.0+0xbe0>
    b471:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b475:	48 83 e8 01          	sub    $0x1,%rax
    b479:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b47d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b483:	0f 85 a3 fa ff ff    	jne    af2c <fwp_hof0.constprop.0+0x6ac>
    b489:	4c 89 e7             	mov    %r12,%rdi
    b48c:	e8 bf a0 ff ff       	call   5550 <fwp_rc_forget_slot>
    b491:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b496:	e9 91 fa ff ff       	jmp    af2c <fwp_hof0.constprop.0+0x6ac>
    b49b:	e8 10 88 ff ff       	call   3cb0 <fwp_heap_oom>
    b4a0:	48 8d 3d e1 43 00 00 	lea    0x43e1(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    b4a7:	e8 44 8f ff ff       	call   43f0 <fwp_trap>
    b4ac:	48 8d 3d 93 3d 00 00 	lea    0x3d93(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    b4b3:	e8 38 8f ff ff       	call   43f0 <fwp_trap>
    b4b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b4bf:	00 
    b4c0:	e8 6b 9f ff ff       	call   5430 <fwp_rc_wide_dup>
    b4c5:	e9 7d f4 ff ff       	jmp    a947 <fwp_hof0.constprop.0+0xc7>
    b4ca:	e8 91 7f ff ff       	call   3460 <__stack_chk_fail@plt>
    b4cf:	90                   	nop
    b4d0:	4c 89 f7             	mov    %r14,%rdi
    b4d3:	e8 78 a0 ff ff       	call   5550 <fwp_rc_forget_slot>
    b4d8:	e9 8c f9 ff ff       	jmp    ae69 <fwp_hof0.constprop.0+0x5e9>
    b4dd:	0f 1f 00             	nopl   (%rax)

000000000000b4e0 <f0>:
    b4e0:	41 56                	push   %r14
    b4e2:	4c 8d 35 f7 82 01 00 	lea    0x182f7(%rip),%r14        # 237e0 <fwp_heap>
    b4e9:	41 55                	push   %r13
    b4eb:	41 54                	push   %r12
    b4ed:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b4f3:	55                   	push   %rbp
    b4f4:	53                   	push   %rbx
    b4f5:	31 db                	xor    %ebx,%ebx
    b4f7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b4fe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b505:	00 00 
    b507:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b50e:	00 
    b50f:	31 c0                	xor    %eax,%eax
    b511:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b518:	00 
    b519:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b520:	00 00 
    b522:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b527:	48 8d 05 22 b7 ff ff 	lea    -0x48de(%rip),%rax        # 6c50 <fwp_drop1>
    b52e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b533:	48 8b 05 3e 9f 01 00 	mov    0x19f3e(%rip),%rax        # 25478 <fwp_cleanups>
    b53a:	48 89 25 37 9f 01 00 	mov    %rsp,0x19f37(%rip)        # 25478 <fwp_cleanups>
    b541:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b545:	48 89 04 24          	mov    %rax,(%rsp)
    b549:	48 8d 05 80 86 ff ff 	lea    -0x7980(%rip),%rax        # 3bd0 <fwp_range_release>
    b550:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b555:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b55a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b55f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b564:	eb 47                	jmp    b5ad <f0+0xcd>
    b566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b56d:	00 00 00 
    b570:	80 f9 01             	cmp    $0x1,%cl
    b573:	75 29                	jne    b59e <f0+0xbe>
    b575:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b578:	0f b7 c0             	movzwl %ax,%eax
    b57b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b57e:	48 0f af c1          	imul   %rcx,%rax
    b582:	48 c1 e8 20          	shr    $0x20,%rax
    b586:	48 39 d0             	cmp    %rdx,%rax
    b589:	73 13                	jae    b59e <f0+0xbe>
    b58b:	49 01 c5             	add    %rax,%r13
    b58e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b593:	0f 84 c7 27 00 00    	je     dd60 <f0+0x2880>
    b599:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b59e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b5a3:	49 83 ec 01          	sub    $0x1,%r12
    b5a7:	0f 82 83 00 00 00    	jb     b630 <f0+0x150>
    b5ad:	48 89 ee             	mov    %rbp,%rsi
    b5b0:	bf 01 00 00 00       	mov    $0x1,%edi
    b5b5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b5bc:	00 
    b5bd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b5c2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b5c9:	00 
    b5ca:	e8 91 af ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b5cf:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b5d6:	48 89 c3             	mov    %rax,%rbx
    b5d9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b5e0:	48 c1 e2 10          	shl    $0x10,%rdx
    b5e4:	48 39 d0             	cmp    %rdx,%rax
    b5e7:	73 b5                	jae    b59e <f0+0xbe>
    b5e9:	48 89 c2             	mov    %rax,%rdx
    b5ec:	48 c1 ea 10          	shr    $0x10,%rdx
    b5f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b5f4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b5fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5ff:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b603:	4d 85 ed             	test   %r13,%r13
    b606:	74 96                	je     b59e <f0+0xbe>
    b608:	0f b6 0a             	movzbl (%rdx),%ecx
    b60b:	80 f9 02             	cmp    $0x2,%cl
    b60e:	0f 85 5c ff ff ff    	jne    b570 <f0+0x90>
    b614:	66 85 c0             	test   %ax,%ax
    b617:	0f 84 71 ff ff ff    	je     b58e <f0+0xae>
    b61d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b622:	49 83 ec 01          	sub    $0x1,%r12
    b626:	73 85                	jae    b5ad <f0+0xcd>
    b628:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b62f:	00 
    b630:	48 8b 04 24          	mov    (%rsp),%rax
    b634:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b639:	bf 01 00 00 00       	mov    $0x1,%edi
    b63e:	66 0f 6f 05 ca 45 00 	movdqa 0x45ca(%rip),%xmm0        # fc10 <msg.4+0xa0>
    b645:	00 
    b646:	48 89 05 2b 9e 01 00 	mov    %rax,0x19e2b(%rip)        # 25478 <fwp_cleanups>
    b64d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b652:	e8 09 af ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b657:	48 8b 15 5a 95 01 00 	mov    0x1955a(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b65e:	49 89 c5             	mov    %rax,%r13
    b661:	48 2b 05 28 95 01 00 	sub    0x19528(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b668:	48 c1 e2 10          	shl    $0x10,%rdx
    b66c:	48 39 d0             	cmp    %rdx,%rax
    b66f:	73 59                	jae    b6ca <f0+0x1ea>
    b671:	48 89 c2             	mov    %rax,%rdx
    b674:	48 c1 ea 10          	shr    $0x10,%rdx
    b678:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b67c:	48 8b 15 55 95 01 00 	mov    0x19555(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b683:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b687:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b68b:	4d 85 e4             	test   %r12,%r12
    b68e:	74 3a                	je     b6ca <f0+0x1ea>
    b690:	0f b6 0a             	movzbl (%rdx),%ecx
    b693:	80 f9 02             	cmp    $0x2,%cl
    b696:	0f 84 74 27 00 00    	je     de10 <f0+0x2930>
    b69c:	80 f9 01             	cmp    $0x1,%cl
    b69f:	75 29                	jne    b6ca <f0+0x1ea>
    b6a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b6a4:	0f b7 c0             	movzwl %ax,%eax
    b6a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b6aa:	48 0f af c1          	imul   %rcx,%rax
    b6ae:	48 c1 e8 20          	shr    $0x20,%rax
    b6b2:	48 39 d0             	cmp    %rdx,%rax
    b6b5:	73 13                	jae    b6ca <f0+0x1ea>
    b6b7:	49 01 c4             	add    %rax,%r12
    b6ba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b6bf:	0f 84 26 29 00 00    	je     dfeb <f0+0x2b0b>
    b6c5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b6ca:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b6cf:	bf 01 00 00 00       	mov    $0x1,%edi
    b6d4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b6d9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b6e0:	00 f0 3f 
    b6e3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b6e8:	e8 73 ae ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b6ed:	48 8b 15 c4 94 01 00 	mov    0x194c4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b6f4:	49 89 c5             	mov    %rax,%r13
    b6f7:	48 2b 05 92 94 01 00 	sub    0x19492(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b6fe:	48 c1 e2 10          	shl    $0x10,%rdx
    b702:	48 39 d0             	cmp    %rdx,%rax
    b705:	73 59                	jae    b760 <f0+0x280>
    b707:	48 89 c2             	mov    %rax,%rdx
    b70a:	48 c1 ea 10          	shr    $0x10,%rdx
    b70e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b712:	48 8b 15 bf 94 01 00 	mov    0x194bf(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b719:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b71d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b721:	4d 85 e4             	test   %r12,%r12
    b724:	74 3a                	je     b760 <f0+0x280>
    b726:	0f b6 0a             	movzbl (%rdx),%ecx
    b729:	80 f9 02             	cmp    $0x2,%cl
    b72c:	0f 84 ce 26 00 00    	je     de00 <f0+0x2920>
    b732:	80 f9 01             	cmp    $0x1,%cl
    b735:	75 29                	jne    b760 <f0+0x280>
    b737:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b73a:	0f b7 c0             	movzwl %ax,%eax
    b73d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b740:	48 0f af c1          	imul   %rcx,%rax
    b744:	48 c1 e8 20          	shr    $0x20,%rax
    b748:	48 39 d0             	cmp    %rdx,%rax
    b74b:	73 13                	jae    b760 <f0+0x280>
    b74d:	49 01 c4             	add    %rax,%r12
    b750:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b755:	0f 84 9d 28 00 00    	je     dff8 <f0+0x2b18>
    b75b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b760:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b765:	bf 01 00 00 00       	mov    $0x1,%edi
    b76a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b76f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b776:	33 f3 bf 
    b779:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b77e:	e8 dd ad ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b783:	48 8b 15 2e 94 01 00 	mov    0x1942e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b78a:	49 89 c5             	mov    %rax,%r13
    b78d:	48 2b 05 fc 93 01 00 	sub    0x193fc(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b794:	48 c1 e2 10          	shl    $0x10,%rdx
    b798:	48 39 d0             	cmp    %rdx,%rax
    b79b:	73 59                	jae    b7f6 <f0+0x316>
    b79d:	48 89 c2             	mov    %rax,%rdx
    b7a0:	48 c1 ea 10          	shr    $0x10,%rdx
    b7a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7a8:	48 8b 15 29 94 01 00 	mov    0x19429(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b7af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7b3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b7b7:	4d 85 e4             	test   %r12,%r12
    b7ba:	74 3a                	je     b7f6 <f0+0x316>
    b7bc:	0f b6 0a             	movzbl (%rdx),%ecx
    b7bf:	80 f9 02             	cmp    $0x2,%cl
    b7c2:	0f 84 28 26 00 00    	je     ddf0 <f0+0x2910>
    b7c8:	80 f9 01             	cmp    $0x1,%cl
    b7cb:	75 29                	jne    b7f6 <f0+0x316>
    b7cd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b7d0:	0f b7 c0             	movzwl %ax,%eax
    b7d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b7d6:	48 0f af c1          	imul   %rcx,%rax
    b7da:	48 c1 e8 20          	shr    $0x20,%rax
    b7de:	48 39 d0             	cmp    %rdx,%rax
    b7e1:	73 13                	jae    b7f6 <f0+0x316>
    b7e3:	49 01 c4             	add    %rax,%r12
    b7e6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b7eb:	0f 84 14 28 00 00    	je     e005 <f0+0x2b25>
    b7f1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b7f6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b7fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b800:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b805:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b80c:	00 f0 3f 
    b80f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b814:	e8 47 ad ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b819:	48 8b 15 98 93 01 00 	mov    0x19398(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b820:	49 89 c5             	mov    %rax,%r13
    b823:	48 2b 05 66 93 01 00 	sub    0x19366(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b82a:	48 c1 e2 10          	shl    $0x10,%rdx
    b82e:	48 39 d0             	cmp    %rdx,%rax
    b831:	73 59                	jae    b88c <f0+0x3ac>
    b833:	48 89 c2             	mov    %rax,%rdx
    b836:	48 c1 ea 10          	shr    $0x10,%rdx
    b83a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b83e:	48 8b 15 93 93 01 00 	mov    0x19393(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b845:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b849:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b84d:	4d 85 e4             	test   %r12,%r12
    b850:	74 3a                	je     b88c <f0+0x3ac>
    b852:	0f b6 0a             	movzbl (%rdx),%ecx
    b855:	80 f9 02             	cmp    $0x2,%cl
    b858:	0f 84 f2 25 00 00    	je     de50 <f0+0x2970>
    b85e:	80 f9 01             	cmp    $0x1,%cl
    b861:	75 29                	jne    b88c <f0+0x3ac>
    b863:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b866:	0f b7 c0             	movzwl %ax,%eax
    b869:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b86c:	48 0f af c1          	imul   %rcx,%rax
    b870:	48 c1 e8 20          	shr    $0x20,%rax
    b874:	48 39 d0             	cmp    %rdx,%rax
    b877:	73 13                	jae    b88c <f0+0x3ac>
    b879:	49 01 c4             	add    %rax,%r12
    b87c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b881:	0f 84 8b 27 00 00    	je     e012 <f0+0x2b32>
    b887:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b88c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b893:	33 f3 bf 
    b896:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b89d:	00 
    b89e:	bf 01 00 00 00       	mov    $0x1,%edi
    b8a3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b8aa:	00 
    b8ab:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b8b2:	00 
    b8b3:	e8 a8 ac ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b8b8:	48 8b 15 f9 92 01 00 	mov    0x192f9(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    b8bf:	49 89 c5             	mov    %rax,%r13
    b8c2:	48 2b 05 c7 92 01 00 	sub    0x192c7(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    b8c9:	48 c1 e2 10          	shl    $0x10,%rdx
    b8cd:	48 39 d0             	cmp    %rdx,%rax
    b8d0:	73 59                	jae    b92b <f0+0x44b>
    b8d2:	48 89 c2             	mov    %rax,%rdx
    b8d5:	48 c1 ea 10          	shr    $0x10,%rdx
    b8d9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b8dd:	48 8b 15 f4 92 01 00 	mov    0x192f4(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b8e4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b8e8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b8ec:	4d 85 e4             	test   %r12,%r12
    b8ef:	74 3a                	je     b92b <f0+0x44b>
    b8f1:	0f b6 0a             	movzbl (%rdx),%ecx
    b8f4:	80 f9 02             	cmp    $0x2,%cl
    b8f7:	0f 84 43 25 00 00    	je     de40 <f0+0x2960>
    b8fd:	80 f9 01             	cmp    $0x1,%cl
    b900:	75 29                	jne    b92b <f0+0x44b>
    b902:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b905:	0f b7 c0             	movzwl %ax,%eax
    b908:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b90b:	48 0f af c1          	imul   %rcx,%rax
    b90f:	48 c1 e8 20          	shr    $0x20,%rax
    b913:	48 39 d0             	cmp    %rdx,%rax
    b916:	73 13                	jae    b92b <f0+0x44b>
    b918:	49 01 c4             	add    %rax,%r12
    b91b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b920:	0f 84 f9 26 00 00    	je     e01f <f0+0x2b3f>
    b926:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b92b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b932:	00 f0 3f 
    b935:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b93c:	00 
    b93d:	bf 01 00 00 00       	mov    $0x1,%edi
    b942:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b949:	00 
    b94a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b951:	00 
    b952:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b959:	33 f3 bf 
    b95c:	e8 ff ab ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b961:	48 89 c7             	mov    %rax,%rdi
    b964:	e8 a7 ad ff ff       	call   6710 <fwp_rc_fresh>
    b969:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b970:	00 
    b971:	bf 01 00 00 00       	mov    $0x1,%edi
    b976:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b97d:	00 
    b97e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b985:	00 
    b986:	e8 d5 ab ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b98b:	48 89 c7             	mov    %rax,%rdi
    b98e:	e8 7d ad ff ff       	call   6710 <fwp_rc_fresh>
    b993:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b99a:	00 
    b99b:	bf 01 00 00 00       	mov    $0x1,%edi
    b9a0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b9a7:	00 
    b9a8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b9af:	00 
    b9b0:	e8 ab ab ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b9b5:	48 89 c7             	mov    %rax,%rdi
    b9b8:	e8 53 ad ff ff       	call   6710 <fwp_rc_fresh>
    b9bd:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b9c4:	00 
    b9c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b9ca:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b9d1:	00 
    b9d2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b9d9:	00 
    b9da:	e8 81 ab ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b9df:	48 89 c7             	mov    %rax,%rdi
    b9e2:	e8 29 ad ff ff       	call   6710 <fwp_rc_fresh>
    b9e7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b9ee:	00 
    b9ef:	bf 01 00 00 00       	mov    $0x1,%edi
    b9f4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b9fb:	00 
    b9fc:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    ba03:	00 
    ba04:	e8 57 ab ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    ba09:	48 89 c7             	mov    %rax,%rdi
    ba0c:	e8 ff ac ff ff       	call   6710 <fwp_rc_fresh>
    ba11:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    ba18:	00 
    ba19:	bf 01 00 00 00       	mov    $0x1,%edi
    ba1e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    ba25:	00 
    ba26:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    ba2d:	00 
    ba2e:	e8 2d ab ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    ba33:	48 89 c7             	mov    %rax,%rdi
    ba36:	e8 d5 ac ff ff       	call   6710 <fwp_rc_fresh>
    ba3b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    ba42:	00 
    ba43:	bf 01 00 00 00       	mov    $0x1,%edi
    ba48:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    ba4f:	00 
    ba50:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    ba57:	00 
    ba58:	e8 03 ab ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    ba5d:	48 89 c7             	mov    %rax,%rdi
    ba60:	e8 ab ac ff ff       	call   6710 <fwp_rc_fresh>
    ba65:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    ba6c:	00 
    ba6d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba72:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    ba79:	00 
    ba7a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    ba81:	00 
    ba82:	e8 d9 aa ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    ba87:	48 89 c7             	mov    %rax,%rdi
    ba8a:	e8 81 ac ff ff       	call   6710 <fwp_rc_fresh>
    ba8f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    ba96:	00 
    ba97:	bf 01 00 00 00       	mov    $0x1,%edi
    ba9c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    baa3:	00 
    baa4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    baab:	00 
    baac:	e8 af aa ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bab1:	48 89 c7             	mov    %rax,%rdi
    bab4:	e8 57 ac ff ff       	call   6710 <fwp_rc_fresh>
    bab9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    bac0:	00 
    bac1:	bf 01 00 00 00       	mov    $0x1,%edi
    bac6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    bacd:	00 
    bace:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    bad5:	00 
    bad6:	e8 85 aa ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    badb:	48 89 c7             	mov    %rax,%rdi
    bade:	e8 2d ac ff ff       	call   6710 <fwp_rc_fresh>
    bae3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    baea:	00 
    baeb:	bf 01 00 00 00       	mov    $0x1,%edi
    baf0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    baf7:	00 
    baf8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    baff:	00 
    bb00:	e8 5b aa ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bb05:	48 89 c7             	mov    %rax,%rdi
    bb08:	e8 03 ac ff ff       	call   6710 <fwp_rc_fresh>
    bb0d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    bb14:	00 
    bb15:	bf 01 00 00 00       	mov    $0x1,%edi
    bb1a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    bb21:	00 
    bb22:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    bb29:	00 
    bb2a:	e8 31 aa ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bb2f:	48 89 c7             	mov    %rax,%rdi
    bb32:	e8 d9 ab ff ff       	call   6710 <fwp_rc_fresh>
    bb37:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    bb3e:	00 
    bb3f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb44:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    bb4b:	00 
    bb4c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    bb53:	00 
    bb54:	e8 07 aa ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bb59:	48 89 c7             	mov    %rax,%rdi
    bb5c:	e8 af ab ff ff       	call   6710 <fwp_rc_fresh>
    bb61:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    bb68:	00 
    bb69:	bf 01 00 00 00       	mov    $0x1,%edi
    bb6e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    bb75:	00 
    bb76:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    bb7d:	00 
    bb7e:	e8 dd a9 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bb83:	48 89 c7             	mov    %rax,%rdi
    bb86:	e8 85 ab ff ff       	call   6710 <fwp_rc_fresh>
    bb8b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    bb92:	00 
    bb93:	bf 01 00 00 00       	mov    $0x1,%edi
    bb98:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    bb9f:	00 
    bba0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    bba7:	00 
    bba8:	e8 b3 a9 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bbad:	48 89 c7             	mov    %rax,%rdi
    bbb0:	e8 5b ab ff ff       	call   6710 <fwp_rc_fresh>
    bbb5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    bbbc:	00 
    bbbd:	bf 01 00 00 00       	mov    $0x1,%edi
    bbc2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    bbc9:	00 
    bbca:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    bbd1:	00 
    bbd2:	e8 89 a9 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bbd7:	48 89 c7             	mov    %rax,%rdi
    bbda:	e8 31 ab ff ff       	call   6710 <fwp_rc_fresh>
    bbdf:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    bbe6:	00 
    bbe7:	bf 01 00 00 00       	mov    $0x1,%edi
    bbec:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    bbf3:	00 
    bbf4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    bbfb:	00 
    bbfc:	e8 5f a9 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bc01:	48 89 c7             	mov    %rax,%rdi
    bc04:	e8 07 ab ff ff       	call   6710 <fwp_rc_fresh>
    bc09:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    bc10:	00 
    bc11:	bf 01 00 00 00       	mov    $0x1,%edi
    bc16:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    bc1d:	00 
    bc1e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    bc25:	00 
    bc26:	e8 35 a9 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bc2b:	48 89 c7             	mov    %rax,%rdi
    bc2e:	e8 dd aa ff ff       	call   6710 <fwp_rc_fresh>
    bc33:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    bc3a:	00 
    bc3b:	bf 01 00 00 00       	mov    $0x1,%edi
    bc40:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    bc47:	00 
    bc48:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    bc4f:	00 
    bc50:	e8 0b a9 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bc55:	48 89 c7             	mov    %rax,%rdi
    bc58:	e8 b3 aa ff ff       	call   6710 <fwp_rc_fresh>
    bc5d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    bc64:	00 
    bc65:	bf 01 00 00 00       	mov    $0x1,%edi
    bc6a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    bc71:	00 
    bc72:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    bc79:	00 
    bc7a:	e8 e1 a8 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bc7f:	48 89 c7             	mov    %rax,%rdi
    bc82:	e8 89 aa ff ff       	call   6710 <fwp_rc_fresh>
    bc87:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    bc8e:	00 
    bc8f:	bf 01 00 00 00       	mov    $0x1,%edi
    bc94:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    bc9b:	00 
    bc9c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    bca3:	00 
    bca4:	e8 b7 a8 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bca9:	48 89 c7             	mov    %rax,%rdi
    bcac:	e8 5f aa ff ff       	call   6710 <fwp_rc_fresh>
    bcb1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    bcb8:	00 
    bcb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bcbe:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    bcc5:	00 
    bcc6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    bccd:	00 
    bcce:	e8 8d a8 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bcd3:	48 89 c7             	mov    %rax,%rdi
    bcd6:	e8 35 aa ff ff       	call   6710 <fwp_rc_fresh>
    bcdb:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    bce2:	00 
    bce3:	bf 01 00 00 00       	mov    $0x1,%edi
    bce8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    bcef:	00 
    bcf0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    bcf7:	00 
    bcf8:	e8 63 a8 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bcfd:	48 89 c7             	mov    %rax,%rdi
    bd00:	e8 0b aa ff ff       	call   6710 <fwp_rc_fresh>
    bd05:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    bd0c:	00 
    bd0d:	bf 01 00 00 00       	mov    $0x1,%edi
    bd12:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    bd19:	00 
    bd1a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    bd21:	00 
    bd22:	e8 39 a8 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bd27:	48 89 c7             	mov    %rax,%rdi
    bd2a:	e8 e1 a9 ff ff       	call   6710 <fwp_rc_fresh>
    bd2f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bd36:	00 
    bd37:	bf 01 00 00 00       	mov    $0x1,%edi
    bd3c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    bd43:	00 
    bd44:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    bd4b:	00 
    bd4c:	e8 0f a8 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bd51:	48 89 c7             	mov    %rax,%rdi
    bd54:	e8 b7 a9 ff ff       	call   6710 <fwp_rc_fresh>
    bd59:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bd60:	00 
    bd61:	bf 01 00 00 00       	mov    $0x1,%edi
    bd66:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    bd6d:	00 
    bd6e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bd75:	00 
    bd76:	e8 e5 a7 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bd7b:	48 89 c7             	mov    %rax,%rdi
    bd7e:	e8 8d a9 ff ff       	call   6710 <fwp_rc_fresh>
    bd83:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    bd8a:	00 
    bd8b:	bf 01 00 00 00       	mov    $0x1,%edi
    bd90:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bd97:	00 
    bd98:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    bd9f:	00 
    bda0:	e8 bb a7 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bda5:	48 89 c7             	mov    %rax,%rdi
    bda8:	e8 63 a9 ff ff       	call   6710 <fwp_rc_fresh>
    bdad:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    bdb4:	00 
    bdb5:	bf 01 00 00 00       	mov    $0x1,%edi
    bdba:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bdc1:	00 
    bdc2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bdc9:	00 
    bdca:	e8 91 a7 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bdcf:	48 89 c7             	mov    %rax,%rdi
    bdd2:	e8 39 a9 ff ff       	call   6710 <fwp_rc_fresh>
    bdd7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bdde:	00 
    bddf:	bf 01 00 00 00       	mov    $0x1,%edi
    bde4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bdeb:	00 
    bdec:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bdf3:	00 
    bdf4:	e8 67 a7 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bdf9:	48 89 c7             	mov    %rax,%rdi
    bdfc:	e8 0f a9 ff ff       	call   6710 <fwp_rc_fresh>
    be01:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    be08:	00 
    be09:	bf 01 00 00 00       	mov    $0x1,%edi
    be0e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    be15:	00 
    be16:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    be1d:	00 
    be1e:	e8 3d a7 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    be23:	48 89 c7             	mov    %rax,%rdi
    be26:	e8 e5 a8 ff ff       	call   6710 <fwp_rc_fresh>
    be2b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    be32:	00 
    be33:	bf 01 00 00 00       	mov    $0x1,%edi
    be38:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    be3f:	00 
    be40:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    be47:	00 
    be48:	e8 13 a7 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    be4d:	48 89 c7             	mov    %rax,%rdi
    be50:	e8 bb a8 ff ff       	call   6710 <fwp_rc_fresh>
    be55:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    be5c:	00 
    be5d:	bf 01 00 00 00       	mov    $0x1,%edi
    be62:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    be69:	00 
    be6a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    be71:	00 
    be72:	e8 e9 a6 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    be77:	48 89 c7             	mov    %rax,%rdi
    be7a:	e8 91 a8 ff ff       	call   6710 <fwp_rc_fresh>
    be7f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    be86:	00 
    be87:	bf 01 00 00 00       	mov    $0x1,%edi
    be8c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    be93:	00 
    be94:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    be9b:	00 
    be9c:	e8 bf a6 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bea1:	48 89 c7             	mov    %rax,%rdi
    bea4:	e8 67 a8 ff ff       	call   6710 <fwp_rc_fresh>
    bea9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    beb0:	00 
    beb1:	bf 01 00 00 00       	mov    $0x1,%edi
    beb6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bebd:	00 
    bebe:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bec5:	00 
    bec6:	e8 95 a6 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    becb:	48 89 c7             	mov    %rax,%rdi
    bece:	e8 3d a8 ff ff       	call   6710 <fwp_rc_fresh>
    bed3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    beda:	00 
    bedb:	bf 01 00 00 00       	mov    $0x1,%edi
    bee0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    bee7:	00 
    bee8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    beef:	00 
    bef0:	e8 6b a6 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bef5:	48 89 c7             	mov    %rax,%rdi
    bef8:	e8 13 a8 ff ff       	call   6710 <fwp_rc_fresh>
    befd:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bf04:	00 
    bf05:	bf 01 00 00 00       	mov    $0x1,%edi
    bf0a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bf11:	00 
    bf12:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bf19:	00 
    bf1a:	e8 41 a6 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bf1f:	48 89 c7             	mov    %rax,%rdi
    bf22:	e8 e9 a7 ff ff       	call   6710 <fwp_rc_fresh>
    bf27:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bf2e:	00 
    bf2f:	bf 01 00 00 00       	mov    $0x1,%edi
    bf34:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bf3b:	00 
    bf3c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bf43:	00 
    bf44:	e8 17 a6 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bf49:	48 89 c7             	mov    %rax,%rdi
    bf4c:	e8 bf a7 ff ff       	call   6710 <fwp_rc_fresh>
    bf51:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bf58:	00 
    bf59:	bf 01 00 00 00       	mov    $0x1,%edi
    bf5e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bf65:	00 
    bf66:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bf6d:	00 
    bf6e:	e8 ed a5 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bf73:	48 89 c7             	mov    %rax,%rdi
    bf76:	e8 95 a7 ff ff       	call   6710 <fwp_rc_fresh>
    bf7b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bf82:	00 
    bf83:	bf 01 00 00 00       	mov    $0x1,%edi
    bf88:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bf8f:	00 
    bf90:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bf97:	00 
    bf98:	e8 c3 a5 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bf9d:	48 89 c7             	mov    %rax,%rdi
    bfa0:	e8 6b a7 ff ff       	call   6710 <fwp_rc_fresh>
    bfa5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bfac:	00 
    bfad:	bf 01 00 00 00       	mov    $0x1,%edi
    bfb2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bfb9:	00 
    bfba:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bfc1:	00 
    bfc2:	e8 99 a5 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bfc7:	48 89 c7             	mov    %rax,%rdi
    bfca:	e8 41 a7 ff ff       	call   6710 <fwp_rc_fresh>
    bfcf:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bfd6:	00 
    bfd7:	bf 01 00 00 00       	mov    $0x1,%edi
    bfdc:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bfe3:	00 
    bfe4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bfeb:	00 
    bfec:	e8 6f a5 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    bff1:	48 89 c7             	mov    %rax,%rdi
    bff4:	e8 17 a7 ff ff       	call   6710 <fwp_rc_fresh>
    bff9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c000:	00 
    c001:	bf 01 00 00 00       	mov    $0x1,%edi
    c006:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    c00d:	00 
    c00e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c015:	00 
    c016:	e8 45 a5 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c01b:	48 89 c7             	mov    %rax,%rdi
    c01e:	e8 ed a6 ff ff       	call   6710 <fwp_rc_fresh>
    c023:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c02a:	00 
    c02b:	bf 01 00 00 00       	mov    $0x1,%edi
    c030:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    c037:	00 
    c038:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c03f:	00 
    c040:	e8 1b a5 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c045:	48 89 c7             	mov    %rax,%rdi
    c048:	e8 c3 a6 ff ff       	call   6710 <fwp_rc_fresh>
    c04d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c054:	00 
    c055:	bf 01 00 00 00       	mov    $0x1,%edi
    c05a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    c061:	00 
    c062:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c069:	00 
    c06a:	e8 f1 a4 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c06f:	48 89 c7             	mov    %rax,%rdi
    c072:	e8 99 a6 ff ff       	call   6710 <fwp_rc_fresh>
    c077:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c07e:	00 
    c07f:	bf 01 00 00 00       	mov    $0x1,%edi
    c084:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    c08b:	00 
    c08c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c093:	00 
    c094:	e8 c7 a4 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c099:	48 89 c7             	mov    %rax,%rdi
    c09c:	e8 6f a6 ff ff       	call   6710 <fwp_rc_fresh>
    c0a1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c0a8:	00 
    c0a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c0ae:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    c0b5:	00 
    c0b6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c0bd:	00 
    c0be:	e8 9d a4 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c0c3:	48 89 c7             	mov    %rax,%rdi
    c0c6:	e8 45 a6 ff ff       	call   6710 <fwp_rc_fresh>
    c0cb:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c0d2:	00 
    c0d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c0d8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    c0df:	00 
    c0e0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c0e7:	00 
    c0e8:	e8 73 a4 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c0ed:	48 89 c7             	mov    %rax,%rdi
    c0f0:	e8 1b a6 ff ff       	call   6710 <fwp_rc_fresh>
    c0f5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c0fc:	00 
    c0fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c102:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    c109:	00 
    c10a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c111:	00 
    c112:	e8 49 a4 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c117:	48 89 c7             	mov    %rax,%rdi
    c11a:	e8 f1 a5 ff ff       	call   6710 <fwp_rc_fresh>
    c11f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c126:	00 
    c127:	bf 01 00 00 00       	mov    $0x1,%edi
    c12c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    c133:	00 
    c134:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c13b:	00 
    c13c:	e8 1f a4 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c141:	48 89 c7             	mov    %rax,%rdi
    c144:	e8 c7 a5 ff ff       	call   6710 <fwp_rc_fresh>
    c149:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c150:	00 
    c151:	bf 01 00 00 00       	mov    $0x1,%edi
    c156:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    c15d:	00 
    c15e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c165:	00 
    c166:	e8 f5 a3 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c16b:	48 89 c7             	mov    %rax,%rdi
    c16e:	e8 9d a5 ff ff       	call   6710 <fwp_rc_fresh>
    c173:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c17a:	00 
    c17b:	bf 01 00 00 00       	mov    $0x1,%edi
    c180:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    c187:	00 
    c188:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c18f:	00 
    c190:	e8 cb a3 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c195:	48 89 c7             	mov    %rax,%rdi
    c198:	e8 73 a5 ff ff       	call   6710 <fwp_rc_fresh>
    c19d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c1a4:	00 
    c1a5:	bf 01 00 00 00       	mov    $0x1,%edi
    c1aa:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    c1b1:	00 
    c1b2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c1b9:	00 
    c1ba:	e8 a1 a3 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c1bf:	48 89 c7             	mov    %rax,%rdi
    c1c2:	e8 49 a5 ff ff       	call   6710 <fwp_rc_fresh>
    c1c7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c1ce:	00 
    c1cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c1d4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    c1db:	00 
    c1dc:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c1e3:	00 
    c1e4:	e8 77 a3 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c1e9:	48 89 c7             	mov    %rax,%rdi
    c1ec:	e8 1f a5 ff ff       	call   6710 <fwp_rc_fresh>
    c1f1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c1f8:	00 
    c1f9:	bf 01 00 00 00       	mov    $0x1,%edi
    c1fe:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c205:	00 
    c206:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c20d:	00 
    c20e:	e8 4d a3 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c213:	48 89 c7             	mov    %rax,%rdi
    c216:	e8 f5 a4 ff ff       	call   6710 <fwp_rc_fresh>
    c21b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c222:	00 
    c223:	bf 01 00 00 00       	mov    $0x1,%edi
    c228:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c22f:	00 
    c230:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c237:	00 
    c238:	e8 23 a3 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c23d:	48 89 c7             	mov    %rax,%rdi
    c240:	e8 cb a4 ff ff       	call   6710 <fwp_rc_fresh>
    c245:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c24c:	00 
    c24d:	bf 01 00 00 00       	mov    $0x1,%edi
    c252:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c259:	00 
    c25a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c261:	00 
    c262:	e8 f9 a2 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c267:	48 89 c7             	mov    %rax,%rdi
    c26a:	e8 a1 a4 ff ff       	call   6710 <fwp_rc_fresh>
    c26f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c276:	00 
    c277:	bf 01 00 00 00       	mov    $0x1,%edi
    c27c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c283:	00 
    c284:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c28b:	00 
    c28c:	e8 cf a2 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c291:	48 89 c7             	mov    %rax,%rdi
    c294:	e8 77 a4 ff ff       	call   6710 <fwp_rc_fresh>
    c299:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c2a0:	00 
    c2a1:	bf 01 00 00 00       	mov    $0x1,%edi
    c2a6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c2ad:	00 
    c2ae:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c2b5:	00 
    c2b6:	e8 a5 a2 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c2bb:	48 89 c7             	mov    %rax,%rdi
    c2be:	e8 4d a4 ff ff       	call   6710 <fwp_rc_fresh>
    c2c3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c2ca:	00 
    c2cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c2d7:	00 
    c2d8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c2df:	00 
    c2e0:	e8 7b a2 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c2e5:	48 89 c7             	mov    %rax,%rdi
    c2e8:	e8 23 a4 ff ff       	call   6710 <fwp_rc_fresh>
    c2ed:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c2f4:	00 
    c2f5:	bf 01 00 00 00       	mov    $0x1,%edi
    c2fa:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c301:	00 
    c302:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c309:	00 
    c30a:	e8 51 a2 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c30f:	48 89 c7             	mov    %rax,%rdi
    c312:	e8 f9 a3 ff ff       	call   6710 <fwp_rc_fresh>
    c317:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c31e:	00 
    c31f:	bf 01 00 00 00       	mov    $0x1,%edi
    c324:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c32b:	00 
    c32c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c333:	00 
    c334:	e8 27 a2 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c339:	48 89 c7             	mov    %rax,%rdi
    c33c:	e8 cf a3 ff ff       	call   6710 <fwp_rc_fresh>
    c341:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c348:	00 
    c349:	bf 01 00 00 00       	mov    $0x1,%edi
    c34e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c355:	00 
    c356:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c35d:	00 
    c35e:	e8 fd a1 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c363:	48 89 c7             	mov    %rax,%rdi
    c366:	e8 a5 a3 ff ff       	call   6710 <fwp_rc_fresh>
    c36b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c372:	00 
    c373:	bf 01 00 00 00       	mov    $0x1,%edi
    c378:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c37f:	00 
    c380:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c387:	00 
    c388:	e8 d3 a1 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c38d:	48 89 c7             	mov    %rax,%rdi
    c390:	e8 7b a3 ff ff       	call   6710 <fwp_rc_fresh>
    c395:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c39c:	00 
    c39d:	bf 01 00 00 00       	mov    $0x1,%edi
    c3a2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c3a9:	00 
    c3aa:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c3b1:	00 
    c3b2:	e8 a9 a1 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c3b7:	48 89 c7             	mov    %rax,%rdi
    c3ba:	e8 51 a3 ff ff       	call   6710 <fwp_rc_fresh>
    c3bf:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c3c6:	00 
    c3c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c3cc:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c3d3:	00 
    c3d4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c3db:	00 
    c3dc:	e8 7f a1 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c3e1:	48 89 c7             	mov    %rax,%rdi
    c3e4:	e8 27 a3 ff ff       	call   6710 <fwp_rc_fresh>
    c3e9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c3f0:	00 
    c3f1:	bf 01 00 00 00       	mov    $0x1,%edi
    c3f6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c3fd:	00 
    c3fe:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c405:	00 
    c406:	e8 55 a1 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c40b:	48 89 c7             	mov    %rax,%rdi
    c40e:	e8 fd a2 ff ff       	call   6710 <fwp_rc_fresh>
    c413:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c41a:	00 
    c41b:	bf 01 00 00 00       	mov    $0x1,%edi
    c420:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c427:	00 
    c428:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c42f:	00 
    c430:	e8 2b a1 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c435:	48 89 c7             	mov    %rax,%rdi
    c438:	e8 d3 a2 ff ff       	call   6710 <fwp_rc_fresh>
    c43d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c444:	00 
    c445:	bf 01 00 00 00       	mov    $0x1,%edi
    c44a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c451:	00 
    c452:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c459:	00 
    c45a:	e8 01 a1 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c45f:	48 89 c7             	mov    %rax,%rdi
    c462:	e8 a9 a2 ff ff       	call   6710 <fwp_rc_fresh>
    c467:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c46e:	00 
    c46f:	bf 01 00 00 00       	mov    $0x1,%edi
    c474:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c47b:	00 
    c47c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c483:	00 
    c484:	e8 d7 a0 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c489:	48 89 c7             	mov    %rax,%rdi
    c48c:	e8 7f a2 ff ff       	call   6710 <fwp_rc_fresh>
    c491:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c498:	00 
    c499:	bf 01 00 00 00       	mov    $0x1,%edi
    c49e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c4a5:	00 
    c4a6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c4ad:	00 
    c4ae:	e8 ad a0 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c4b3:	48 89 c7             	mov    %rax,%rdi
    c4b6:	e8 55 a2 ff ff       	call   6710 <fwp_rc_fresh>
    c4bb:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c4c2:	00 
    c4c3:	bf 01 00 00 00       	mov    $0x1,%edi
    c4c8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c4cf:	00 
    c4d0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c4d7:	00 
    c4d8:	e8 83 a0 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c4dd:	48 89 c7             	mov    %rax,%rdi
    c4e0:	e8 2b a2 ff ff       	call   6710 <fwp_rc_fresh>
    c4e5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c4ec:	00 
    c4ed:	bf 01 00 00 00       	mov    $0x1,%edi
    c4f2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c4f9:	00 
    c4fa:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c501:	00 
    c502:	e8 59 a0 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c507:	48 89 c7             	mov    %rax,%rdi
    c50a:	e8 01 a2 ff ff       	call   6710 <fwp_rc_fresh>
    c50f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c516:	00 
    c517:	bf 01 00 00 00       	mov    $0x1,%edi
    c51c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c523:	00 
    c524:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c52b:	00 
    c52c:	e8 2f a0 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c531:	48 89 c7             	mov    %rax,%rdi
    c534:	e8 d7 a1 ff ff       	call   6710 <fwp_rc_fresh>
    c539:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c540:	00 
    c541:	bf 01 00 00 00       	mov    $0x1,%edi
    c546:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c54d:	00 
    c54e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c555:	00 
    c556:	e8 05 a0 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c55b:	48 89 c7             	mov    %rax,%rdi
    c55e:	e8 ad a1 ff ff       	call   6710 <fwp_rc_fresh>
    c563:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c56a:	00 
    c56b:	bf 01 00 00 00       	mov    $0x1,%edi
    c570:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c577:	00 
    c578:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c57f:	00 
    c580:	e8 db 9f ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c585:	48 89 c7             	mov    %rax,%rdi
    c588:	e8 83 a1 ff ff       	call   6710 <fwp_rc_fresh>
    c58d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c594:	00 
    c595:	bf 01 00 00 00       	mov    $0x1,%edi
    c59a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c5a1:	00 
    c5a2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c5a9:	00 
    c5aa:	e8 b1 9f ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c5af:	48 89 c7             	mov    %rax,%rdi
    c5b2:	e8 59 a1 ff ff       	call   6710 <fwp_rc_fresh>
    c5b7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c5be:	00 
    c5bf:	bf 01 00 00 00       	mov    $0x1,%edi
    c5c4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c5cb:	00 
    c5cc:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c5d3:	00 
    c5d4:	e8 87 9f ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c5d9:	48 89 c7             	mov    %rax,%rdi
    c5dc:	e8 2f a1 ff ff       	call   6710 <fwp_rc_fresh>
    c5e1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c5e8:	00 
    c5e9:	bf 01 00 00 00       	mov    $0x1,%edi
    c5ee:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c5f5:	00 
    c5f6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c5fd:	00 
    c5fe:	e8 5d 9f ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c603:	48 89 c7             	mov    %rax,%rdi
    c606:	e8 05 a1 ff ff       	call   6710 <fwp_rc_fresh>
    c60b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c612:	00 
    c613:	bf 01 00 00 00       	mov    $0x1,%edi
    c618:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c61f:	00 
    c620:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c627:	00 
    c628:	e8 33 9f ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c62d:	48 89 c7             	mov    %rax,%rdi
    c630:	e8 db a0 ff ff       	call   6710 <fwp_rc_fresh>
    c635:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c63c:	00 
    c63d:	bf 01 00 00 00       	mov    $0x1,%edi
    c642:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c649:	00 
    c64a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c651:	00 
    c652:	e8 09 9f ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c657:	48 89 c7             	mov    %rax,%rdi
    c65a:	e8 b1 a0 ff ff       	call   6710 <fwp_rc_fresh>
    c65f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c666:	00 
    c667:	bf 01 00 00 00       	mov    $0x1,%edi
    c66c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c673:	00 
    c674:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c67b:	00 
    c67c:	e8 df 9e ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c681:	48 89 c7             	mov    %rax,%rdi
    c684:	e8 87 a0 ff ff       	call   6710 <fwp_rc_fresh>
    c689:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c690:	00 
    c691:	bf 01 00 00 00       	mov    $0x1,%edi
    c696:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c69d:	00 
    c69e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c6a5:	00 
    c6a6:	e8 b5 9e ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c6ab:	48 89 c7             	mov    %rax,%rdi
    c6ae:	e8 5d a0 ff ff       	call   6710 <fwp_rc_fresh>
    c6b3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c6ba:	00 
    c6bb:	bf 01 00 00 00       	mov    $0x1,%edi
    c6c0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c6c7:	00 
    c6c8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c6cf:	00 
    c6d0:	e8 8b 9e ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c6d5:	48 89 c7             	mov    %rax,%rdi
    c6d8:	e8 33 a0 ff ff       	call   6710 <fwp_rc_fresh>
    c6dd:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c6e4:	00 
    c6e5:	bf 01 00 00 00       	mov    $0x1,%edi
    c6ea:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c6f1:	00 
    c6f2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c6f9:	00 
    c6fa:	e8 61 9e ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c6ff:	48 89 c7             	mov    %rax,%rdi
    c702:	e8 09 a0 ff ff       	call   6710 <fwp_rc_fresh>
    c707:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c70e:	00 
    c70f:	bf 01 00 00 00       	mov    $0x1,%edi
    c714:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c71b:	00 
    c71c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c723:	00 
    c724:	e8 37 9e ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c729:	48 89 c7             	mov    %rax,%rdi
    c72c:	e8 df 9f ff ff       	call   6710 <fwp_rc_fresh>
    c731:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c738:	00 
    c739:	bf 01 00 00 00       	mov    $0x1,%edi
    c73e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c745:	00 
    c746:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c74d:	00 
    c74e:	e8 0d 9e ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c753:	48 89 c7             	mov    %rax,%rdi
    c756:	e8 b5 9f ff ff       	call   6710 <fwp_rc_fresh>
    c75b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c762:	00 
    c763:	bf 01 00 00 00       	mov    $0x1,%edi
    c768:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c76f:	00 
    c770:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c777:	00 
    c778:	e8 e3 9d ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c77d:	48 89 c7             	mov    %rax,%rdi
    c780:	e8 8b 9f ff ff       	call   6710 <fwp_rc_fresh>
    c785:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c78c:	00 
    c78d:	bf 01 00 00 00       	mov    $0x1,%edi
    c792:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c799:	00 
    c79a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c7a1:	00 
    c7a2:	e8 b9 9d ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c7a7:	48 89 c7             	mov    %rax,%rdi
    c7aa:	e8 61 9f ff ff       	call   6710 <fwp_rc_fresh>
    c7af:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c7b6:	00 
    c7b7:	bf 01 00 00 00       	mov    $0x1,%edi
    c7bc:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c7c3:	00 
    c7c4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c7cb:	00 
    c7cc:	e8 8f 9d ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c7d1:	48 89 c7             	mov    %rax,%rdi
    c7d4:	e8 37 9f ff ff       	call   6710 <fwp_rc_fresh>
    c7d9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c7e0:	00 
    c7e1:	bf 01 00 00 00       	mov    $0x1,%edi
    c7e6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c7ed:	00 
    c7ee:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c7f5:	00 
    c7f6:	e8 65 9d ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c7fb:	48 89 c7             	mov    %rax,%rdi
    c7fe:	e8 0d 9f ff ff       	call   6710 <fwp_rc_fresh>
    c803:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c80a:	00 
    c80b:	bf 01 00 00 00       	mov    $0x1,%edi
    c810:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c817:	00 
    c818:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c81f:	00 
    c820:	e8 3b 9d ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c825:	48 8b 15 8c 83 01 00 	mov    0x1838c(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c82c:	49 89 c5             	mov    %rax,%r13
    c82f:	48 2b 05 5a 83 01 00 	sub    0x1835a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c836:	48 c1 e2 10          	shl    $0x10,%rdx
    c83a:	48 39 d0             	cmp    %rdx,%rax
    c83d:	73 59                	jae    c898 <f0+0x13b8>
    c83f:	48 89 c2             	mov    %rax,%rdx
    c842:	48 c1 ea 10          	shr    $0x10,%rdx
    c846:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c84a:	48 8b 15 87 83 01 00 	mov    0x18387(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c851:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c855:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c859:	4d 85 e4             	test   %r12,%r12
    c85c:	74 3a                	je     c898 <f0+0x13b8>
    c85e:	0f b6 0a             	movzbl (%rdx),%ecx
    c861:	80 f9 02             	cmp    $0x2,%cl
    c864:	0f 84 c6 15 00 00    	je     de30 <f0+0x2950>
    c86a:	80 f9 01             	cmp    $0x1,%cl
    c86d:	75 29                	jne    c898 <f0+0x13b8>
    c86f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c872:	0f b7 c0             	movzwl %ax,%eax
    c875:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c878:	48 0f af c1          	imul   %rcx,%rax
    c87c:	48 c1 e8 20          	shr    $0x20,%rax
    c880:	48 39 d0             	cmp    %rdx,%rax
    c883:	73 13                	jae    c898 <f0+0x13b8>
    c885:	49 01 c4             	add    %rax,%r12
    c888:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c88d:	0f 84 99 17 00 00    	je     e02c <f0+0x2b4c>
    c893:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c898:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c89f:	33 f3 bf 
    c8a2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c8a9:	00 
    c8aa:	bf 01 00 00 00       	mov    $0x1,%edi
    c8af:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c8b6:	00 
    c8b7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c8be:	00 
    c8bf:	e8 9c 9c ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c8c4:	48 8b 15 ed 82 01 00 	mov    0x182ed(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c8cb:	49 89 c5             	mov    %rax,%r13
    c8ce:	48 2b 05 bb 82 01 00 	sub    0x182bb(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c8d5:	48 c1 e2 10          	shl    $0x10,%rdx
    c8d9:	48 39 d0             	cmp    %rdx,%rax
    c8dc:	73 59                	jae    c937 <f0+0x1457>
    c8de:	48 89 c2             	mov    %rax,%rdx
    c8e1:	48 c1 ea 10          	shr    $0x10,%rdx
    c8e5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8e9:	48 8b 15 e8 82 01 00 	mov    0x182e8(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c8f0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8f4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8f8:	4d 85 e4             	test   %r12,%r12
    c8fb:	74 3a                	je     c937 <f0+0x1457>
    c8fd:	0f b6 0a             	movzbl (%rdx),%ecx
    c900:	80 f9 02             	cmp    $0x2,%cl
    c903:	0f 84 17 15 00 00    	je     de20 <f0+0x2940>
    c909:	80 f9 01             	cmp    $0x1,%cl
    c90c:	75 29                	jne    c937 <f0+0x1457>
    c90e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c911:	0f b7 c0             	movzwl %ax,%eax
    c914:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c917:	48 0f af c1          	imul   %rcx,%rax
    c91b:	48 c1 e8 20          	shr    $0x20,%rax
    c91f:	48 39 d0             	cmp    %rdx,%rax
    c922:	73 13                	jae    c937 <f0+0x1457>
    c924:	49 01 c4             	add    %rax,%r12
    c927:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c92c:	0f 84 07 17 00 00    	je     e039 <f0+0x2b59>
    c932:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c937:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c93e:	00 f0 3f 
    c941:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c948:	00 
    c949:	bf 01 00 00 00       	mov    $0x1,%edi
    c94e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c955:	00 
    c956:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c95d:	00 
    c95e:	e8 fd 9b ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    c963:	48 8b 15 4e 82 01 00 	mov    0x1824e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c96a:	49 89 c5             	mov    %rax,%r13
    c96d:	48 2b 05 1c 82 01 00 	sub    0x1821c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c974:	48 c1 e2 10          	shl    $0x10,%rdx
    c978:	48 39 d0             	cmp    %rdx,%rax
    c97b:	73 59                	jae    c9d6 <f0+0x14f6>
    c97d:	48 89 c2             	mov    %rax,%rdx
    c980:	48 c1 ea 10          	shr    $0x10,%rdx
    c984:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c988:	48 8b 15 49 82 01 00 	mov    0x18249(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c98f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c993:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c997:	4d 85 e4             	test   %r12,%r12
    c99a:	74 3a                	je     c9d6 <f0+0x14f6>
    c99c:	0f b6 0a             	movzbl (%rdx),%ecx
    c99f:	80 f9 02             	cmp    $0x2,%cl
    c9a2:	0f 84 28 15 00 00    	je     ded0 <f0+0x29f0>
    c9a8:	80 f9 01             	cmp    $0x1,%cl
    c9ab:	75 29                	jne    c9d6 <f0+0x14f6>
    c9ad:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9b0:	0f b7 c0             	movzwl %ax,%eax
    c9b3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9b6:	48 0f af c1          	imul   %rcx,%rax
    c9ba:	48 c1 e8 20          	shr    $0x20,%rax
    c9be:	48 39 d0             	cmp    %rdx,%rax
    c9c1:	73 13                	jae    c9d6 <f0+0x14f6>
    c9c3:	49 01 c4             	add    %rax,%r12
    c9c6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9cb:	0f 84 75 16 00 00    	je     e046 <f0+0x2b66>
    c9d1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9d6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c9dd:	33 f3 bf 
    c9e0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c9e7:	00 
    c9e8:	bf 01 00 00 00       	mov    $0x1,%edi
    c9ed:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c9f4:	00 
    c9f5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c9fc:	00 
    c9fd:	e8 5e 9b ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    ca02:	48 8b 15 af 81 01 00 	mov    0x181af(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ca09:	49 89 c5             	mov    %rax,%r13
    ca0c:	48 2b 05 7d 81 01 00 	sub    0x1817d(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ca13:	48 c1 e2 10          	shl    $0x10,%rdx
    ca17:	48 39 d0             	cmp    %rdx,%rax
    ca1a:	73 59                	jae    ca75 <f0+0x1595>
    ca1c:	48 89 c2             	mov    %rax,%rdx
    ca1f:	48 c1 ea 10          	shr    $0x10,%rdx
    ca23:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca27:	48 8b 15 aa 81 01 00 	mov    0x181aa(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ca2e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca32:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca36:	4d 85 e4             	test   %r12,%r12
    ca39:	74 3a                	je     ca75 <f0+0x1595>
    ca3b:	0f b6 0a             	movzbl (%rdx),%ecx
    ca3e:	80 f9 02             	cmp    $0x2,%cl
    ca41:	0f 84 79 14 00 00    	je     dec0 <f0+0x29e0>
    ca47:	80 f9 01             	cmp    $0x1,%cl
    ca4a:	75 29                	jne    ca75 <f0+0x1595>
    ca4c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca4f:	0f b7 c0             	movzwl %ax,%eax
    ca52:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca55:	48 0f af c1          	imul   %rcx,%rax
    ca59:	48 c1 e8 20          	shr    $0x20,%rax
    ca5d:	48 39 d0             	cmp    %rdx,%rax
    ca60:	73 13                	jae    ca75 <f0+0x1595>
    ca62:	49 01 c4             	add    %rax,%r12
    ca65:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca6a:	0f 84 e3 15 00 00    	je     e053 <f0+0x2b73>
    ca70:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca75:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca7c:	00 f0 3f 
    ca7f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    ca86:	00 
    ca87:	bf 01 00 00 00       	mov    $0x1,%edi
    ca8c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    ca93:	00 
    ca94:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    ca9b:	00 
    ca9c:	e8 bf 9a ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    caa1:	48 8b 15 10 81 01 00 	mov    0x18110(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    caa8:	49 89 c5             	mov    %rax,%r13
    caab:	48 2b 05 de 80 01 00 	sub    0x180de(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cab2:	48 c1 e2 10          	shl    $0x10,%rdx
    cab6:	48 39 d0             	cmp    %rdx,%rax
    cab9:	73 59                	jae    cb14 <f0+0x1634>
    cabb:	48 89 c2             	mov    %rax,%rdx
    cabe:	48 c1 ea 10          	shr    $0x10,%rdx
    cac2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cac6:	48 8b 15 0b 81 01 00 	mov    0x1810b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cacd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cad1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cad5:	4d 85 e4             	test   %r12,%r12
    cad8:	74 3a                	je     cb14 <f0+0x1634>
    cada:	0f b6 0a             	movzbl (%rdx),%ecx
    cadd:	80 f9 02             	cmp    $0x2,%cl
    cae0:	0f 84 ca 13 00 00    	je     deb0 <f0+0x29d0>
    cae6:	80 f9 01             	cmp    $0x1,%cl
    cae9:	75 29                	jne    cb14 <f0+0x1634>
    caeb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caee:	0f b7 c0             	movzwl %ax,%eax
    caf1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    caf4:	48 0f af c1          	imul   %rcx,%rax
    caf8:	48 c1 e8 20          	shr    $0x20,%rax
    cafc:	48 39 d0             	cmp    %rdx,%rax
    caff:	73 13                	jae    cb14 <f0+0x1634>
    cb01:	49 01 c4             	add    %rax,%r12
    cb04:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb09:	0f 84 51 15 00 00    	je     e060 <f0+0x2b80>
    cb0f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb14:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb1b:	33 f3 bf 
    cb1e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    cb25:	00 
    cb26:	bf 01 00 00 00       	mov    $0x1,%edi
    cb2b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    cb32:	00 
    cb33:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    cb3a:	00 
    cb3b:	e8 20 9a ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    cb40:	48 8b 15 71 80 01 00 	mov    0x18071(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cb47:	49 89 c5             	mov    %rax,%r13
    cb4a:	48 2b 05 3f 80 01 00 	sub    0x1803f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cb51:	48 c1 e2 10          	shl    $0x10,%rdx
    cb55:	48 39 d0             	cmp    %rdx,%rax
    cb58:	73 59                	jae    cbb3 <f0+0x16d3>
    cb5a:	48 89 c2             	mov    %rax,%rdx
    cb5d:	48 c1 ea 10          	shr    $0x10,%rdx
    cb61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb65:	48 8b 15 6c 80 01 00 	mov    0x1806c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cb6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb70:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb74:	4d 85 e4             	test   %r12,%r12
    cb77:	74 3a                	je     cbb3 <f0+0x16d3>
    cb79:	0f b6 0a             	movzbl (%rdx),%ecx
    cb7c:	80 f9 02             	cmp    $0x2,%cl
    cb7f:	0f 84 1b 13 00 00    	je     dea0 <f0+0x29c0>
    cb85:	80 f9 01             	cmp    $0x1,%cl
    cb88:	75 29                	jne    cbb3 <f0+0x16d3>
    cb8a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb8d:	0f b7 c0             	movzwl %ax,%eax
    cb90:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb93:	48 0f af c1          	imul   %rcx,%rax
    cb97:	48 c1 e8 20          	shr    $0x20,%rax
    cb9b:	48 39 d0             	cmp    %rdx,%rax
    cb9e:	73 13                	jae    cbb3 <f0+0x16d3>
    cba0:	49 01 c4             	add    %rax,%r12
    cba3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cba8:	0f 84 bf 14 00 00    	je     e06d <f0+0x2b8d>
    cbae:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbb3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cbba:	00 f0 3f 
    cbbd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    cbc4:	00 
    cbc5:	bf 01 00 00 00       	mov    $0x1,%edi
    cbca:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    cbd1:	00 
    cbd2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    cbd9:	00 
    cbda:	e8 81 99 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    cbdf:	48 8b 15 d2 7f 01 00 	mov    0x17fd2(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cbe6:	49 89 c5             	mov    %rax,%r13
    cbe9:	48 2b 05 a0 7f 01 00 	sub    0x17fa0(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cbf0:	48 c1 e2 10          	shl    $0x10,%rdx
    cbf4:	48 39 d0             	cmp    %rdx,%rax
    cbf7:	73 59                	jae    cc52 <f0+0x1772>
    cbf9:	48 89 c2             	mov    %rax,%rdx
    cbfc:	48 c1 ea 10          	shr    $0x10,%rdx
    cc00:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc04:	48 8b 15 cd 7f 01 00 	mov    0x17fcd(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cc0b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc0f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc13:	4d 85 e4             	test   %r12,%r12
    cc16:	74 3a                	je     cc52 <f0+0x1772>
    cc18:	0f b6 0a             	movzbl (%rdx),%ecx
    cc1b:	80 f9 02             	cmp    $0x2,%cl
    cc1e:	0f 84 6c 12 00 00    	je     de90 <f0+0x29b0>
    cc24:	80 f9 01             	cmp    $0x1,%cl
    cc27:	75 29                	jne    cc52 <f0+0x1772>
    cc29:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc2c:	0f b7 c0             	movzwl %ax,%eax
    cc2f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc32:	48 0f af c1          	imul   %rcx,%rax
    cc36:	48 c1 e8 20          	shr    $0x20,%rax
    cc3a:	48 39 d0             	cmp    %rdx,%rax
    cc3d:	73 13                	jae    cc52 <f0+0x1772>
    cc3f:	49 01 c4             	add    %rax,%r12
    cc42:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc47:	0f 84 2d 14 00 00    	je     e07a <f0+0x2b9a>
    cc4d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc52:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cc59:	33 f3 bf 
    cc5c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    cc63:	00 
    cc64:	bf 01 00 00 00       	mov    $0x1,%edi
    cc69:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    cc70:	00 
    cc71:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    cc78:	00 
    cc79:	e8 e2 98 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    cc7e:	48 8b 15 33 7f 01 00 	mov    0x17f33(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cc85:	49 89 c5             	mov    %rax,%r13
    cc88:	48 2b 05 01 7f 01 00 	sub    0x17f01(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cc8f:	48 c1 e2 10          	shl    $0x10,%rdx
    cc93:	48 39 d0             	cmp    %rdx,%rax
    cc96:	73 59                	jae    ccf1 <f0+0x1811>
    cc98:	48 89 c2             	mov    %rax,%rdx
    cc9b:	48 c1 ea 10          	shr    $0x10,%rdx
    cc9f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cca3:	48 8b 15 2e 7f 01 00 	mov    0x17f2e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ccaa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccae:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccb2:	4d 85 e4             	test   %r12,%r12
    ccb5:	74 3a                	je     ccf1 <f0+0x1811>
    ccb7:	0f b6 0a             	movzbl (%rdx),%ecx
    ccba:	80 f9 02             	cmp    $0x2,%cl
    ccbd:	0f 84 bd 11 00 00    	je     de80 <f0+0x29a0>
    ccc3:	80 f9 01             	cmp    $0x1,%cl
    ccc6:	75 29                	jne    ccf1 <f0+0x1811>
    ccc8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cccb:	0f b7 c0             	movzwl %ax,%eax
    ccce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccd1:	48 0f af c1          	imul   %rcx,%rax
    ccd5:	48 c1 e8 20          	shr    $0x20,%rax
    ccd9:	48 39 d0             	cmp    %rdx,%rax
    ccdc:	73 13                	jae    ccf1 <f0+0x1811>
    ccde:	49 01 c4             	add    %rax,%r12
    cce1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cce6:	0f 84 9b 13 00 00    	je     e087 <f0+0x2ba7>
    ccec:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccf1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ccf8:	00 f0 3f 
    ccfb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    cd02:	00 
    cd03:	bf 01 00 00 00       	mov    $0x1,%edi
    cd08:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    cd0f:	00 
    cd10:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    cd17:	00 
    cd18:	e8 43 98 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    cd1d:	48 8b 15 94 7e 01 00 	mov    0x17e94(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cd24:	49 89 c5             	mov    %rax,%r13
    cd27:	48 2b 05 62 7e 01 00 	sub    0x17e62(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cd2e:	48 c1 e2 10          	shl    $0x10,%rdx
    cd32:	48 39 d0             	cmp    %rdx,%rax
    cd35:	73 59                	jae    cd90 <f0+0x18b0>
    cd37:	48 89 c2             	mov    %rax,%rdx
    cd3a:	48 c1 ea 10          	shr    $0x10,%rdx
    cd3e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd42:	48 8b 15 8f 7e 01 00 	mov    0x17e8f(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cd49:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd4d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd51:	4d 85 e4             	test   %r12,%r12
    cd54:	74 3a                	je     cd90 <f0+0x18b0>
    cd56:	0f b6 0a             	movzbl (%rdx),%ecx
    cd59:	80 f9 02             	cmp    $0x2,%cl
    cd5c:	0f 84 0e 11 00 00    	je     de70 <f0+0x2990>
    cd62:	80 f9 01             	cmp    $0x1,%cl
    cd65:	75 29                	jne    cd90 <f0+0x18b0>
    cd67:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd6a:	0f b7 c0             	movzwl %ax,%eax
    cd6d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd70:	48 0f af c1          	imul   %rcx,%rax
    cd74:	48 c1 e8 20          	shr    $0x20,%rax
    cd78:	48 39 d0             	cmp    %rdx,%rax
    cd7b:	73 13                	jae    cd90 <f0+0x18b0>
    cd7d:	49 01 c4             	add    %rax,%r12
    cd80:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd85:	0f 84 09 13 00 00    	je     e094 <f0+0x2bb4>
    cd8b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd90:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd97:	33 f3 bf 
    cd9a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    cda1:	00 
    cda2:	bf 01 00 00 00       	mov    $0x1,%edi
    cda7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    cdae:	00 
    cdaf:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    cdb6:	00 
    cdb7:	e8 a4 97 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    cdbc:	48 8b 15 f5 7d 01 00 	mov    0x17df5(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cdc3:	49 89 c5             	mov    %rax,%r13
    cdc6:	48 2b 05 c3 7d 01 00 	sub    0x17dc3(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cdcd:	48 c1 e2 10          	shl    $0x10,%rdx
    cdd1:	48 39 d0             	cmp    %rdx,%rax
    cdd4:	73 59                	jae    ce2f <f0+0x194f>
    cdd6:	48 89 c2             	mov    %rax,%rdx
    cdd9:	48 c1 ea 10          	shr    $0x10,%rdx
    cddd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cde1:	48 8b 15 f0 7d 01 00 	mov    0x17df0(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cde8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdec:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdf0:	4d 85 e4             	test   %r12,%r12
    cdf3:	74 3a                	je     ce2f <f0+0x194f>
    cdf5:	0f b6 0a             	movzbl (%rdx),%ecx
    cdf8:	80 f9 02             	cmp    $0x2,%cl
    cdfb:	0f 84 5f 10 00 00    	je     de60 <f0+0x2980>
    ce01:	80 f9 01             	cmp    $0x1,%cl
    ce04:	75 29                	jne    ce2f <f0+0x194f>
    ce06:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce09:	0f b7 c0             	movzwl %ax,%eax
    ce0c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce0f:	48 0f af c1          	imul   %rcx,%rax
    ce13:	48 c1 e8 20          	shr    $0x20,%rax
    ce17:	48 39 d0             	cmp    %rdx,%rax
    ce1a:	73 13                	jae    ce2f <f0+0x194f>
    ce1c:	49 01 c4             	add    %rax,%r12
    ce1f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce24:	0f 84 77 12 00 00    	je     e0a1 <f0+0x2bc1>
    ce2a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce2f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce36:	00 f0 3f 
    ce39:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    ce40:	00 
    ce41:	bf 01 00 00 00       	mov    $0x1,%edi
    ce46:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    ce4d:	00 
    ce4e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    ce55:	00 
    ce56:	e8 05 97 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    ce5b:	48 8b 15 56 7d 01 00 	mov    0x17d56(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ce62:	49 89 c5             	mov    %rax,%r13
    ce65:	48 2b 05 24 7d 01 00 	sub    0x17d24(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ce6c:	48 c1 e2 10          	shl    $0x10,%rdx
    ce70:	48 39 d0             	cmp    %rdx,%rax
    ce73:	73 59                	jae    cece <f0+0x19ee>
    ce75:	48 89 c2             	mov    %rax,%rdx
    ce78:	48 c1 ea 10          	shr    $0x10,%rdx
    ce7c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce80:	48 8b 15 51 7d 01 00 	mov    0x17d51(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ce87:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce8b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce8f:	4d 85 e4             	test   %r12,%r12
    ce92:	74 3a                	je     cece <f0+0x19ee>
    ce94:	0f b6 0a             	movzbl (%rdx),%ecx
    ce97:	80 f9 02             	cmp    $0x2,%cl
    ce9a:	0f 84 40 0f 00 00    	je     dde0 <f0+0x2900>
    cea0:	80 f9 01             	cmp    $0x1,%cl
    cea3:	75 29                	jne    cece <f0+0x19ee>
    cea5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cea8:	0f b7 c0             	movzwl %ax,%eax
    ceab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ceae:	48 0f af c1          	imul   %rcx,%rax
    ceb2:	48 c1 e8 20          	shr    $0x20,%rax
    ceb6:	48 39 d0             	cmp    %rdx,%rax
    ceb9:	73 13                	jae    cece <f0+0x19ee>
    cebb:	49 01 c4             	add    %rax,%r12
    cebe:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cec3:	0f 84 e5 11 00 00    	je     e0ae <f0+0x2bce>
    cec9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cece:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ced5:	33 f3 bf 
    ced8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    cedf:	00 
    cee0:	bf 01 00 00 00       	mov    $0x1,%edi
    cee5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    ceec:	00 
    ceed:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cef4:	00 
    cef5:	e8 66 96 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    cefa:	48 8b 15 b7 7c 01 00 	mov    0x17cb7(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cf01:	49 89 c5             	mov    %rax,%r13
    cf04:	48 2b 05 85 7c 01 00 	sub    0x17c85(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cf0b:	48 c1 e2 10          	shl    $0x10,%rdx
    cf0f:	48 39 d0             	cmp    %rdx,%rax
    cf12:	73 59                	jae    cf6d <f0+0x1a8d>
    cf14:	48 89 c2             	mov    %rax,%rdx
    cf17:	48 c1 ea 10          	shr    $0x10,%rdx
    cf1b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf1f:	48 8b 15 b2 7c 01 00 	mov    0x17cb2(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cf26:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf2a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf2e:	4d 85 e4             	test   %r12,%r12
    cf31:	74 3a                	je     cf6d <f0+0x1a8d>
    cf33:	0f b6 0a             	movzbl (%rdx),%ecx
    cf36:	80 f9 02             	cmp    $0x2,%cl
    cf39:	0f 84 91 0e 00 00    	je     ddd0 <f0+0x28f0>
    cf3f:	80 f9 01             	cmp    $0x1,%cl
    cf42:	75 29                	jne    cf6d <f0+0x1a8d>
    cf44:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf47:	0f b7 c0             	movzwl %ax,%eax
    cf4a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf4d:	48 0f af c1          	imul   %rcx,%rax
    cf51:	48 c1 e8 20          	shr    $0x20,%rax
    cf55:	48 39 d0             	cmp    %rdx,%rax
    cf58:	73 13                	jae    cf6d <f0+0x1a8d>
    cf5a:	49 01 c4             	add    %rax,%r12
    cf5d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf62:	0f 84 53 11 00 00    	je     e0bb <f0+0x2bdb>
    cf68:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf6d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf74:	00 f0 3f 
    cf77:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    cf7e:	00 
    cf7f:	bf 01 00 00 00       	mov    $0x1,%edi
    cf84:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cf8b:	00 
    cf8c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cf93:	00 
    cf94:	e8 c7 95 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    cf99:	48 8b 15 18 7c 01 00 	mov    0x17c18(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cfa0:	49 89 c5             	mov    %rax,%r13
    cfa3:	48 2b 05 e6 7b 01 00 	sub    0x17be6(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cfaa:	48 c1 e2 10          	shl    $0x10,%rdx
    cfae:	48 39 d0             	cmp    %rdx,%rax
    cfb1:	73 59                	jae    d00c <f0+0x1b2c>
    cfb3:	48 89 c2             	mov    %rax,%rdx
    cfb6:	48 c1 ea 10          	shr    $0x10,%rdx
    cfba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfbe:	48 8b 15 13 7c 01 00 	mov    0x17c13(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cfc5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfc9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfcd:	4d 85 e4             	test   %r12,%r12
    cfd0:	74 3a                	je     d00c <f0+0x1b2c>
    cfd2:	0f b6 0a             	movzbl (%rdx),%ecx
    cfd5:	80 f9 02             	cmp    $0x2,%cl
    cfd8:	0f 84 e2 0d 00 00    	je     ddc0 <f0+0x28e0>
    cfde:	80 f9 01             	cmp    $0x1,%cl
    cfe1:	75 29                	jne    d00c <f0+0x1b2c>
    cfe3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfe6:	0f b7 c0             	movzwl %ax,%eax
    cfe9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfec:	48 0f af c1          	imul   %rcx,%rax
    cff0:	48 c1 e8 20          	shr    $0x20,%rax
    cff4:	48 39 d0             	cmp    %rdx,%rax
    cff7:	73 13                	jae    d00c <f0+0x1b2c>
    cff9:	49 01 c4             	add    %rax,%r12
    cffc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d001:	0f 84 c1 10 00 00    	je     e0c8 <f0+0x2be8>
    d007:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d00c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d013:	33 f3 bf 
    d016:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d01d:	00 
    d01e:	bf 01 00 00 00       	mov    $0x1,%edi
    d023:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d02a:	00 
    d02b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d032:	00 
    d033:	e8 28 95 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d038:	48 8b 15 79 7b 01 00 	mov    0x17b79(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d03f:	49 89 c5             	mov    %rax,%r13
    d042:	48 2b 05 47 7b 01 00 	sub    0x17b47(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d049:	48 c1 e2 10          	shl    $0x10,%rdx
    d04d:	48 39 d0             	cmp    %rdx,%rax
    d050:	73 59                	jae    d0ab <f0+0x1bcb>
    d052:	48 89 c2             	mov    %rax,%rdx
    d055:	48 c1 ea 10          	shr    $0x10,%rdx
    d059:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d05d:	48 8b 15 74 7b 01 00 	mov    0x17b74(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d064:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d068:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d06c:	4d 85 e4             	test   %r12,%r12
    d06f:	74 3a                	je     d0ab <f0+0x1bcb>
    d071:	0f b6 0a             	movzbl (%rdx),%ecx
    d074:	80 f9 02             	cmp    $0x2,%cl
    d077:	0f 84 33 0d 00 00    	je     ddb0 <f0+0x28d0>
    d07d:	80 f9 01             	cmp    $0x1,%cl
    d080:	75 29                	jne    d0ab <f0+0x1bcb>
    d082:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d085:	0f b7 c0             	movzwl %ax,%eax
    d088:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d08b:	48 0f af c1          	imul   %rcx,%rax
    d08f:	48 c1 e8 20          	shr    $0x20,%rax
    d093:	48 39 d0             	cmp    %rdx,%rax
    d096:	73 13                	jae    d0ab <f0+0x1bcb>
    d098:	49 01 c4             	add    %rax,%r12
    d09b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0a0:	0f 84 2f 10 00 00    	je     e0d5 <f0+0x2bf5>
    d0a6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0ab:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d0b2:	00 f0 3f 
    d0b5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d0bc:	00 
    d0bd:	bf 01 00 00 00       	mov    $0x1,%edi
    d0c2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d0c9:	00 
    d0ca:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d0d1:	00 
    d0d2:	e8 89 94 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d0d7:	48 8b 15 da 7a 01 00 	mov    0x17ada(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d0de:	49 89 c5             	mov    %rax,%r13
    d0e1:	48 2b 05 a8 7a 01 00 	sub    0x17aa8(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d0e8:	48 c1 e2 10          	shl    $0x10,%rdx
    d0ec:	48 39 d0             	cmp    %rdx,%rax
    d0ef:	73 59                	jae    d14a <f0+0x1c6a>
    d0f1:	48 89 c2             	mov    %rax,%rdx
    d0f4:	48 c1 ea 10          	shr    $0x10,%rdx
    d0f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0fc:	48 8b 15 d5 7a 01 00 	mov    0x17ad5(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d103:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d107:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d10b:	4d 85 e4             	test   %r12,%r12
    d10e:	74 3a                	je     d14a <f0+0x1c6a>
    d110:	0f b6 0a             	movzbl (%rdx),%ecx
    d113:	80 f9 02             	cmp    $0x2,%cl
    d116:	0f 84 84 0c 00 00    	je     dda0 <f0+0x28c0>
    d11c:	80 f9 01             	cmp    $0x1,%cl
    d11f:	75 29                	jne    d14a <f0+0x1c6a>
    d121:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d124:	0f b7 c0             	movzwl %ax,%eax
    d127:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d12a:	48 0f af c1          	imul   %rcx,%rax
    d12e:	48 c1 e8 20          	shr    $0x20,%rax
    d132:	48 39 d0             	cmp    %rdx,%rax
    d135:	73 13                	jae    d14a <f0+0x1c6a>
    d137:	49 01 c4             	add    %rax,%r12
    d13a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d13f:	0f 84 9d 0f 00 00    	je     e0e2 <f0+0x2c02>
    d145:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d14a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d151:	33 f3 bf 
    d154:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d15b:	00 
    d15c:	bf 01 00 00 00       	mov    $0x1,%edi
    d161:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d168:	00 
    d169:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d170:	00 
    d171:	e8 ea 93 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d176:	48 8b 15 3b 7a 01 00 	mov    0x17a3b(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d17d:	49 89 c5             	mov    %rax,%r13
    d180:	48 2b 05 09 7a 01 00 	sub    0x17a09(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d187:	48 c1 e2 10          	shl    $0x10,%rdx
    d18b:	48 39 d0             	cmp    %rdx,%rax
    d18e:	73 59                	jae    d1e9 <f0+0x1d09>
    d190:	48 89 c2             	mov    %rax,%rdx
    d193:	48 c1 ea 10          	shr    $0x10,%rdx
    d197:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d19b:	48 8b 15 36 7a 01 00 	mov    0x17a36(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d1a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1a6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1aa:	4d 85 e4             	test   %r12,%r12
    d1ad:	74 3a                	je     d1e9 <f0+0x1d09>
    d1af:	0f b6 0a             	movzbl (%rdx),%ecx
    d1b2:	80 f9 02             	cmp    $0x2,%cl
    d1b5:	0f 84 d5 0b 00 00    	je     dd90 <f0+0x28b0>
    d1bb:	80 f9 01             	cmp    $0x1,%cl
    d1be:	75 29                	jne    d1e9 <f0+0x1d09>
    d1c0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1c3:	0f b7 c0             	movzwl %ax,%eax
    d1c6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1c9:	48 0f af c1          	imul   %rcx,%rax
    d1cd:	48 c1 e8 20          	shr    $0x20,%rax
    d1d1:	48 39 d0             	cmp    %rdx,%rax
    d1d4:	73 13                	jae    d1e9 <f0+0x1d09>
    d1d6:	49 01 c4             	add    %rax,%r12
    d1d9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1de:	0f 84 0b 0f 00 00    	je     e0ef <f0+0x2c0f>
    d1e4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1e9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d1f0:	00 f0 3f 
    d1f3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d1fa:	00 
    d1fb:	bf 01 00 00 00       	mov    $0x1,%edi
    d200:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d207:	00 
    d208:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d20f:	00 
    d210:	e8 4b 93 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d215:	48 8b 15 9c 79 01 00 	mov    0x1799c(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d21c:	49 89 c5             	mov    %rax,%r13
    d21f:	48 2b 05 6a 79 01 00 	sub    0x1796a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d226:	48 c1 e2 10          	shl    $0x10,%rdx
    d22a:	48 39 d0             	cmp    %rdx,%rax
    d22d:	73 59                	jae    d288 <f0+0x1da8>
    d22f:	48 89 c2             	mov    %rax,%rdx
    d232:	48 c1 ea 10          	shr    $0x10,%rdx
    d236:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d23a:	48 8b 15 97 79 01 00 	mov    0x17997(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d241:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d245:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d249:	4d 85 e4             	test   %r12,%r12
    d24c:	74 3a                	je     d288 <f0+0x1da8>
    d24e:	0f b6 0a             	movzbl (%rdx),%ecx
    d251:	80 f9 02             	cmp    $0x2,%cl
    d254:	0f 84 26 0b 00 00    	je     dd80 <f0+0x28a0>
    d25a:	80 f9 01             	cmp    $0x1,%cl
    d25d:	75 29                	jne    d288 <f0+0x1da8>
    d25f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d262:	0f b7 c0             	movzwl %ax,%eax
    d265:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d268:	48 0f af c1          	imul   %rcx,%rax
    d26c:	48 c1 e8 20          	shr    $0x20,%rax
    d270:	48 39 d0             	cmp    %rdx,%rax
    d273:	73 13                	jae    d288 <f0+0x1da8>
    d275:	49 01 c4             	add    %rax,%r12
    d278:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d27d:	0f 84 79 0e 00 00    	je     e0fc <f0+0x2c1c>
    d283:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d288:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d28f:	33 f3 bf 
    d292:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d299:	00 
    d29a:	bf 01 00 00 00       	mov    $0x1,%edi
    d29f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d2a6:	00 
    d2a7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d2ae:	00 
    d2af:	e8 ac 92 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d2b4:	48 8b 15 fd 78 01 00 	mov    0x178fd(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d2bb:	49 89 c5             	mov    %rax,%r13
    d2be:	48 2b 05 cb 78 01 00 	sub    0x178cb(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d2c5:	48 c1 e2 10          	shl    $0x10,%rdx
    d2c9:	48 39 d0             	cmp    %rdx,%rax
    d2cc:	73 59                	jae    d327 <f0+0x1e47>
    d2ce:	48 89 c2             	mov    %rax,%rdx
    d2d1:	48 c1 ea 10          	shr    $0x10,%rdx
    d2d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2d9:	48 8b 15 f8 78 01 00 	mov    0x178f8(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d2e0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2e4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2e8:	4d 85 e4             	test   %r12,%r12
    d2eb:	74 3a                	je     d327 <f0+0x1e47>
    d2ed:	0f b6 0a             	movzbl (%rdx),%ecx
    d2f0:	80 f9 02             	cmp    $0x2,%cl
    d2f3:	0f 84 77 0a 00 00    	je     dd70 <f0+0x2890>
    d2f9:	80 f9 01             	cmp    $0x1,%cl
    d2fc:	75 29                	jne    d327 <f0+0x1e47>
    d2fe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d301:	0f b7 c0             	movzwl %ax,%eax
    d304:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d307:	48 0f af c1          	imul   %rcx,%rax
    d30b:	48 c1 e8 20          	shr    $0x20,%rax
    d30f:	48 39 d0             	cmp    %rdx,%rax
    d312:	73 13                	jae    d327 <f0+0x1e47>
    d314:	49 01 c4             	add    %rax,%r12
    d317:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d31c:	0f 84 e7 0d 00 00    	je     e109 <f0+0x2c29>
    d322:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d327:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d32e:	00 f0 3f 
    d331:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d338:	00 
    d339:	bf 01 00 00 00       	mov    $0x1,%edi
    d33e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d345:	00 
    d346:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d34d:	00 
    d34e:	e8 0d 92 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d353:	48 8b 15 5e 78 01 00 	mov    0x1785e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d35a:	49 89 c5             	mov    %rax,%r13
    d35d:	48 2b 05 2c 78 01 00 	sub    0x1782c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d364:	48 c1 e2 10          	shl    $0x10,%rdx
    d368:	48 39 d0             	cmp    %rdx,%rax
    d36b:	73 59                	jae    d3c6 <f0+0x1ee6>
    d36d:	48 89 c2             	mov    %rax,%rdx
    d370:	48 c1 ea 10          	shr    $0x10,%rdx
    d374:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d378:	48 8b 15 59 78 01 00 	mov    0x17859(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d37f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d383:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d387:	4d 85 e4             	test   %r12,%r12
    d38a:	74 3a                	je     d3c6 <f0+0x1ee6>
    d38c:	0f b6 0a             	movzbl (%rdx),%ecx
    d38f:	80 f9 02             	cmp    $0x2,%cl
    d392:	0f 84 38 0c 00 00    	je     dfd0 <f0+0x2af0>
    d398:	80 f9 01             	cmp    $0x1,%cl
    d39b:	75 29                	jne    d3c6 <f0+0x1ee6>
    d39d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3a0:	0f b7 c0             	movzwl %ax,%eax
    d3a3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3a6:	48 0f af c1          	imul   %rcx,%rax
    d3aa:	48 c1 e8 20          	shr    $0x20,%rax
    d3ae:	48 39 d0             	cmp    %rdx,%rax
    d3b1:	73 13                	jae    d3c6 <f0+0x1ee6>
    d3b3:	49 01 c4             	add    %rax,%r12
    d3b6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3bb:	0f 84 55 0d 00 00    	je     e116 <f0+0x2c36>
    d3c1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3c6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d3cd:	33 f3 bf 
    d3d0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d3d7:	00 
    d3d8:	bf 01 00 00 00       	mov    $0x1,%edi
    d3dd:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d3e4:	00 
    d3e5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d3ec:	00 
    d3ed:	e8 6e 91 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d3f2:	48 8b 15 bf 77 01 00 	mov    0x177bf(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d3f9:	49 89 c5             	mov    %rax,%r13
    d3fc:	48 2b 05 8d 77 01 00 	sub    0x1778d(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d403:	48 c1 e2 10          	shl    $0x10,%rdx
    d407:	48 39 d0             	cmp    %rdx,%rax
    d40a:	73 59                	jae    d465 <f0+0x1f85>
    d40c:	48 89 c2             	mov    %rax,%rdx
    d40f:	48 c1 ea 10          	shr    $0x10,%rdx
    d413:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d417:	48 8b 15 ba 77 01 00 	mov    0x177ba(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d41e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d422:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d426:	4d 85 e4             	test   %r12,%r12
    d429:	74 3a                	je     d465 <f0+0x1f85>
    d42b:	0f b6 0a             	movzbl (%rdx),%ecx
    d42e:	80 f9 02             	cmp    $0x2,%cl
    d431:	0f 84 89 0b 00 00    	je     dfc0 <f0+0x2ae0>
    d437:	80 f9 01             	cmp    $0x1,%cl
    d43a:	75 29                	jne    d465 <f0+0x1f85>
    d43c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d43f:	0f b7 c0             	movzwl %ax,%eax
    d442:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d445:	48 0f af c1          	imul   %rcx,%rax
    d449:	48 c1 e8 20          	shr    $0x20,%rax
    d44d:	48 39 d0             	cmp    %rdx,%rax
    d450:	73 13                	jae    d465 <f0+0x1f85>
    d452:	49 01 c4             	add    %rax,%r12
    d455:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d45a:	0f 84 c3 0c 00 00    	je     e123 <f0+0x2c43>
    d460:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d465:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d46c:	00 f0 3f 
    d46f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d476:	00 
    d477:	bf 01 00 00 00       	mov    $0x1,%edi
    d47c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d483:	00 
    d484:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d48b:	00 
    d48c:	e8 cf 90 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d491:	48 8b 15 20 77 01 00 	mov    0x17720(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d498:	49 89 c5             	mov    %rax,%r13
    d49b:	48 2b 05 ee 76 01 00 	sub    0x176ee(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d4a2:	48 c1 e2 10          	shl    $0x10,%rdx
    d4a6:	48 39 d0             	cmp    %rdx,%rax
    d4a9:	73 59                	jae    d504 <f0+0x2024>
    d4ab:	48 89 c2             	mov    %rax,%rdx
    d4ae:	48 c1 ea 10          	shr    $0x10,%rdx
    d4b2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4b6:	48 8b 15 1b 77 01 00 	mov    0x1771b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d4bd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4c1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4c5:	4d 85 e4             	test   %r12,%r12
    d4c8:	74 3a                	je     d504 <f0+0x2024>
    d4ca:	0f b6 0a             	movzbl (%rdx),%ecx
    d4cd:	80 f9 02             	cmp    $0x2,%cl
    d4d0:	0f 84 da 0a 00 00    	je     dfb0 <f0+0x2ad0>
    d4d6:	80 f9 01             	cmp    $0x1,%cl
    d4d9:	75 29                	jne    d504 <f0+0x2024>
    d4db:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4de:	0f b7 c0             	movzwl %ax,%eax
    d4e1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4e4:	48 0f af c1          	imul   %rcx,%rax
    d4e8:	48 c1 e8 20          	shr    $0x20,%rax
    d4ec:	48 39 d0             	cmp    %rdx,%rax
    d4ef:	73 13                	jae    d504 <f0+0x2024>
    d4f1:	49 01 c4             	add    %rax,%r12
    d4f4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4f9:	0f 84 31 0c 00 00    	je     e130 <f0+0x2c50>
    d4ff:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d504:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d50b:	33 f3 bf 
    d50e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d515:	00 
    d516:	bf 01 00 00 00       	mov    $0x1,%edi
    d51b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d522:	00 
    d523:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d52a:	00 
    d52b:	e8 30 90 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d530:	48 8b 15 81 76 01 00 	mov    0x17681(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d537:	49 89 c5             	mov    %rax,%r13
    d53a:	48 2b 05 4f 76 01 00 	sub    0x1764f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d541:	48 c1 e2 10          	shl    $0x10,%rdx
    d545:	48 39 d0             	cmp    %rdx,%rax
    d548:	73 59                	jae    d5a3 <f0+0x20c3>
    d54a:	48 89 c2             	mov    %rax,%rdx
    d54d:	48 c1 ea 10          	shr    $0x10,%rdx
    d551:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d555:	48 8b 15 7c 76 01 00 	mov    0x1767c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d55c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d560:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d564:	4d 85 e4             	test   %r12,%r12
    d567:	74 3a                	je     d5a3 <f0+0x20c3>
    d569:	0f b6 0a             	movzbl (%rdx),%ecx
    d56c:	80 f9 02             	cmp    $0x2,%cl
    d56f:	0f 84 2b 0a 00 00    	je     dfa0 <f0+0x2ac0>
    d575:	80 f9 01             	cmp    $0x1,%cl
    d578:	75 29                	jne    d5a3 <f0+0x20c3>
    d57a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d57d:	0f b7 c0             	movzwl %ax,%eax
    d580:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d583:	48 0f af c1          	imul   %rcx,%rax
    d587:	48 c1 e8 20          	shr    $0x20,%rax
    d58b:	48 39 d0             	cmp    %rdx,%rax
    d58e:	73 13                	jae    d5a3 <f0+0x20c3>
    d590:	49 01 c4             	add    %rax,%r12
    d593:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d598:	0f 84 9f 0b 00 00    	je     e13d <f0+0x2c5d>
    d59e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5a3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d5aa:	00 f0 3f 
    d5ad:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d5b4:	00 
    d5b5:	bf 01 00 00 00       	mov    $0x1,%edi
    d5ba:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d5c1:	00 
    d5c2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d5c9:	00 
    d5ca:	e8 91 8f ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d5cf:	48 8b 15 e2 75 01 00 	mov    0x175e2(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d5d6:	49 89 c5             	mov    %rax,%r13
    d5d9:	48 2b 05 b0 75 01 00 	sub    0x175b0(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d5e0:	48 c1 e2 10          	shl    $0x10,%rdx
    d5e4:	48 39 d0             	cmp    %rdx,%rax
    d5e7:	73 59                	jae    d642 <f0+0x2162>
    d5e9:	48 89 c2             	mov    %rax,%rdx
    d5ec:	48 c1 ea 10          	shr    $0x10,%rdx
    d5f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5f4:	48 8b 15 dd 75 01 00 	mov    0x175dd(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d5fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5ff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d603:	4d 85 e4             	test   %r12,%r12
    d606:	74 3a                	je     d642 <f0+0x2162>
    d608:	0f b6 0a             	movzbl (%rdx),%ecx
    d60b:	80 f9 02             	cmp    $0x2,%cl
    d60e:	0f 84 7c 09 00 00    	je     df90 <f0+0x2ab0>
    d614:	80 f9 01             	cmp    $0x1,%cl
    d617:	75 29                	jne    d642 <f0+0x2162>
    d619:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d61c:	0f b7 c0             	movzwl %ax,%eax
    d61f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d622:	48 0f af c1          	imul   %rcx,%rax
    d626:	48 c1 e8 20          	shr    $0x20,%rax
    d62a:	48 39 d0             	cmp    %rdx,%rax
    d62d:	73 13                	jae    d642 <f0+0x2162>
    d62f:	49 01 c4             	add    %rax,%r12
    d632:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d637:	0f 84 0d 0b 00 00    	je     e14a <f0+0x2c6a>
    d63d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d642:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d649:	33 f3 bf 
    d64c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d653:	00 
    d654:	bf 01 00 00 00       	mov    $0x1,%edi
    d659:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d660:	00 
    d661:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d668:	00 
    d669:	e8 f2 8e ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d66e:	48 8b 15 43 75 01 00 	mov    0x17543(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d675:	49 89 c5             	mov    %rax,%r13
    d678:	48 2b 05 11 75 01 00 	sub    0x17511(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d67f:	48 c1 e2 10          	shl    $0x10,%rdx
    d683:	48 39 d0             	cmp    %rdx,%rax
    d686:	73 59                	jae    d6e1 <f0+0x2201>
    d688:	48 89 c2             	mov    %rax,%rdx
    d68b:	48 c1 ea 10          	shr    $0x10,%rdx
    d68f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d693:	48 8b 15 3e 75 01 00 	mov    0x1753e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d69a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d69e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6a2:	4d 85 e4             	test   %r12,%r12
    d6a5:	74 3a                	je     d6e1 <f0+0x2201>
    d6a7:	0f b6 0a             	movzbl (%rdx),%ecx
    d6aa:	80 f9 02             	cmp    $0x2,%cl
    d6ad:	0f 84 cd 08 00 00    	je     df80 <f0+0x2aa0>
    d6b3:	80 f9 01             	cmp    $0x1,%cl
    d6b6:	75 29                	jne    d6e1 <f0+0x2201>
    d6b8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6bb:	0f b7 c0             	movzwl %ax,%eax
    d6be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6c1:	48 0f af c1          	imul   %rcx,%rax
    d6c5:	48 c1 e8 20          	shr    $0x20,%rax
    d6c9:	48 39 d0             	cmp    %rdx,%rax
    d6cc:	73 13                	jae    d6e1 <f0+0x2201>
    d6ce:	49 01 c4             	add    %rax,%r12
    d6d1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6d6:	0f 84 7b 0a 00 00    	je     e157 <f0+0x2c77>
    d6dc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6e1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d6e8:	00 f0 3f 
    d6eb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d6f2:	00 
    d6f3:	bf 01 00 00 00       	mov    $0x1,%edi
    d6f8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d6ff:	00 
    d700:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d707:	00 
    d708:	e8 53 8e ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d70d:	48 8b 15 a4 74 01 00 	mov    0x174a4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d714:	49 89 c5             	mov    %rax,%r13
    d717:	48 2b 05 72 74 01 00 	sub    0x17472(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d71e:	48 c1 e2 10          	shl    $0x10,%rdx
    d722:	48 39 d0             	cmp    %rdx,%rax
    d725:	73 59                	jae    d780 <f0+0x22a0>
    d727:	48 89 c2             	mov    %rax,%rdx
    d72a:	48 c1 ea 10          	shr    $0x10,%rdx
    d72e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d732:	48 8b 15 9f 74 01 00 	mov    0x1749f(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d739:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d73d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d741:	4d 85 e4             	test   %r12,%r12
    d744:	74 3a                	je     d780 <f0+0x22a0>
    d746:	0f b6 0a             	movzbl (%rdx),%ecx
    d749:	80 f9 02             	cmp    $0x2,%cl
    d74c:	0f 84 1e 08 00 00    	je     df70 <f0+0x2a90>
    d752:	80 f9 01             	cmp    $0x1,%cl
    d755:	75 29                	jne    d780 <f0+0x22a0>
    d757:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d75a:	0f b7 c0             	movzwl %ax,%eax
    d75d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d760:	48 0f af c1          	imul   %rcx,%rax
    d764:	48 c1 e8 20          	shr    $0x20,%rax
    d768:	48 39 d0             	cmp    %rdx,%rax
    d76b:	73 13                	jae    d780 <f0+0x22a0>
    d76d:	49 01 c4             	add    %rax,%r12
    d770:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d775:	0f 84 e9 09 00 00    	je     e164 <f0+0x2c84>
    d77b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d780:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d787:	33 f3 bf 
    d78a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d791:	00 
    d792:	bf 01 00 00 00       	mov    $0x1,%edi
    d797:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d79e:	00 
    d79f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d7a6:	00 
    d7a7:	e8 b4 8d ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d7ac:	48 8b 15 05 74 01 00 	mov    0x17405(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d7b3:	49 89 c5             	mov    %rax,%r13
    d7b6:	48 2b 05 d3 73 01 00 	sub    0x173d3(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d7bd:	48 c1 e2 10          	shl    $0x10,%rdx
    d7c1:	48 39 d0             	cmp    %rdx,%rax
    d7c4:	73 59                	jae    d81f <f0+0x233f>
    d7c6:	48 89 c2             	mov    %rax,%rdx
    d7c9:	48 c1 ea 10          	shr    $0x10,%rdx
    d7cd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7d1:	48 8b 15 00 74 01 00 	mov    0x17400(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d7d8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7dc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7e0:	4d 85 e4             	test   %r12,%r12
    d7e3:	74 3a                	je     d81f <f0+0x233f>
    d7e5:	0f b6 0a             	movzbl (%rdx),%ecx
    d7e8:	80 f9 02             	cmp    $0x2,%cl
    d7eb:	0f 84 6f 07 00 00    	je     df60 <f0+0x2a80>
    d7f1:	80 f9 01             	cmp    $0x1,%cl
    d7f4:	75 29                	jne    d81f <f0+0x233f>
    d7f6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7f9:	0f b7 c0             	movzwl %ax,%eax
    d7fc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7ff:	48 0f af c1          	imul   %rcx,%rax
    d803:	48 c1 e8 20          	shr    $0x20,%rax
    d807:	48 39 d0             	cmp    %rdx,%rax
    d80a:	73 13                	jae    d81f <f0+0x233f>
    d80c:	49 01 c4             	add    %rax,%r12
    d80f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d814:	0f 84 57 09 00 00    	je     e171 <f0+0x2c91>
    d81a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d81f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d826:	00 f0 3f 
    d829:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d830:	00 
    d831:	bf 01 00 00 00       	mov    $0x1,%edi
    d836:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d83d:	00 
    d83e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d845:	00 
    d846:	e8 15 8d ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d84b:	48 8b 15 66 73 01 00 	mov    0x17366(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d852:	49 89 c5             	mov    %rax,%r13
    d855:	48 2b 05 34 73 01 00 	sub    0x17334(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d85c:	48 c1 e2 10          	shl    $0x10,%rdx
    d860:	48 39 d0             	cmp    %rdx,%rax
    d863:	73 59                	jae    d8be <f0+0x23de>
    d865:	48 89 c2             	mov    %rax,%rdx
    d868:	48 c1 ea 10          	shr    $0x10,%rdx
    d86c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d870:	48 8b 15 61 73 01 00 	mov    0x17361(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d877:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d87b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d87f:	4d 85 e4             	test   %r12,%r12
    d882:	74 3a                	je     d8be <f0+0x23de>
    d884:	0f b6 0a             	movzbl (%rdx),%ecx
    d887:	80 f9 02             	cmp    $0x2,%cl
    d88a:	0f 84 c0 06 00 00    	je     df50 <f0+0x2a70>
    d890:	80 f9 01             	cmp    $0x1,%cl
    d893:	75 29                	jne    d8be <f0+0x23de>
    d895:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d898:	0f b7 c0             	movzwl %ax,%eax
    d89b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d89e:	48 0f af c1          	imul   %rcx,%rax
    d8a2:	48 c1 e8 20          	shr    $0x20,%rax
    d8a6:	48 39 d0             	cmp    %rdx,%rax
    d8a9:	73 13                	jae    d8be <f0+0x23de>
    d8ab:	49 01 c4             	add    %rax,%r12
    d8ae:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8b3:	0f 84 c5 08 00 00    	je     e17e <f0+0x2c9e>
    d8b9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8be:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d8c5:	33 f3 bf 
    d8c8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d8cf:	00 
    d8d0:	bf 01 00 00 00       	mov    $0x1,%edi
    d8d5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d8dc:	00 
    d8dd:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d8e4:	00 
    d8e5:	e8 76 8c ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d8ea:	48 8b 15 c7 72 01 00 	mov    0x172c7(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d8f1:	49 89 c5             	mov    %rax,%r13
    d8f4:	48 2b 05 95 72 01 00 	sub    0x17295(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d8fb:	48 c1 e2 10          	shl    $0x10,%rdx
    d8ff:	48 39 d0             	cmp    %rdx,%rax
    d902:	73 59                	jae    d95d <f0+0x247d>
    d904:	48 89 c2             	mov    %rax,%rdx
    d907:	48 c1 ea 10          	shr    $0x10,%rdx
    d90b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d90f:	48 8b 15 c2 72 01 00 	mov    0x172c2(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d916:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d91a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d91e:	4d 85 e4             	test   %r12,%r12
    d921:	74 3a                	je     d95d <f0+0x247d>
    d923:	0f b6 0a             	movzbl (%rdx),%ecx
    d926:	80 f9 02             	cmp    $0x2,%cl
    d929:	0f 84 11 06 00 00    	je     df40 <f0+0x2a60>
    d92f:	80 f9 01             	cmp    $0x1,%cl
    d932:	75 29                	jne    d95d <f0+0x247d>
    d934:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d937:	0f b7 c0             	movzwl %ax,%eax
    d93a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d93d:	48 0f af c1          	imul   %rcx,%rax
    d941:	48 c1 e8 20          	shr    $0x20,%rax
    d945:	48 39 d0             	cmp    %rdx,%rax
    d948:	73 13                	jae    d95d <f0+0x247d>
    d94a:	49 01 c4             	add    %rax,%r12
    d94d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d952:	0f 84 33 08 00 00    	je     e18b <f0+0x2cab>
    d958:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d95d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d964:	00 f0 3f 
    d967:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d96e:	00 
    d96f:	bf 01 00 00 00       	mov    $0x1,%edi
    d974:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d97b:	00 
    d97c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d983:	00 
    d984:	e8 d7 8b ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    d989:	48 8b 15 28 72 01 00 	mov    0x17228(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d990:	49 89 c5             	mov    %rax,%r13
    d993:	48 2b 05 f6 71 01 00 	sub    0x171f6(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d99a:	48 c1 e2 10          	shl    $0x10,%rdx
    d99e:	48 39 d0             	cmp    %rdx,%rax
    d9a1:	73 59                	jae    d9fc <f0+0x251c>
    d9a3:	48 89 c2             	mov    %rax,%rdx
    d9a6:	48 c1 ea 10          	shr    $0x10,%rdx
    d9aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9ae:	48 8b 15 23 72 01 00 	mov    0x17223(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d9b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d9b9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9bd:	4d 85 e4             	test   %r12,%r12
    d9c0:	74 3a                	je     d9fc <f0+0x251c>
    d9c2:	0f b6 0a             	movzbl (%rdx),%ecx
    d9c5:	80 f9 02             	cmp    $0x2,%cl
    d9c8:	0f 84 62 05 00 00    	je     df30 <f0+0x2a50>
    d9ce:	80 f9 01             	cmp    $0x1,%cl
    d9d1:	75 29                	jne    d9fc <f0+0x251c>
    d9d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d9d6:	0f b7 c0             	movzwl %ax,%eax
    d9d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d9dc:	48 0f af c1          	imul   %rcx,%rax
    d9e0:	48 c1 e8 20          	shr    $0x20,%rax
    d9e4:	48 39 d0             	cmp    %rdx,%rax
    d9e7:	73 13                	jae    d9fc <f0+0x251c>
    d9e9:	49 01 c4             	add    %rax,%r12
    d9ec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9f1:	0f 84 a1 07 00 00    	je     e198 <f0+0x2cb8>
    d9f7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9fc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    da03:	33 f3 bf 
    da06:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    da0d:	00 
    da0e:	bf 01 00 00 00       	mov    $0x1,%edi
    da13:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    da1a:	00 
    da1b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    da22:	00 
    da23:	e8 38 8b ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    da28:	48 8b 15 89 71 01 00 	mov    0x17189(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    da2f:	49 89 c5             	mov    %rax,%r13
    da32:	48 2b 05 57 71 01 00 	sub    0x17157(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    da39:	48 c1 e2 10          	shl    $0x10,%rdx
    da3d:	48 39 d0             	cmp    %rdx,%rax
    da40:	73 59                	jae    da9b <f0+0x25bb>
    da42:	48 89 c2             	mov    %rax,%rdx
    da45:	48 c1 ea 10          	shr    $0x10,%rdx
    da49:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da4d:	48 8b 15 84 71 01 00 	mov    0x17184(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    da54:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da58:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da5c:	4d 85 e4             	test   %r12,%r12
    da5f:	74 3a                	je     da9b <f0+0x25bb>
    da61:	0f b6 0a             	movzbl (%rdx),%ecx
    da64:	80 f9 02             	cmp    $0x2,%cl
    da67:	0f 84 b3 04 00 00    	je     df20 <f0+0x2a40>
    da6d:	80 f9 01             	cmp    $0x1,%cl
    da70:	75 29                	jne    da9b <f0+0x25bb>
    da72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da75:	0f b7 c0             	movzwl %ax,%eax
    da78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da7b:	48 0f af c1          	imul   %rcx,%rax
    da7f:	48 c1 e8 20          	shr    $0x20,%rax
    da83:	48 39 d0             	cmp    %rdx,%rax
    da86:	73 13                	jae    da9b <f0+0x25bb>
    da88:	49 01 c4             	add    %rax,%r12
    da8b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da90:	0f 84 0f 07 00 00    	je     e1a5 <f0+0x2cc5>
    da96:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da9b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    daa2:	00 f0 3f 
    daa5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    daac:	00 
    daad:	bf 01 00 00 00       	mov    $0x1,%edi
    dab2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    dab9:	00 
    daba:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    dac1:	00 
    dac2:	e8 99 8a ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    dac7:	48 8b 15 ea 70 01 00 	mov    0x170ea(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dace:	49 89 c5             	mov    %rax,%r13
    dad1:	48 2b 05 b8 70 01 00 	sub    0x170b8(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dad8:	48 c1 e2 10          	shl    $0x10,%rdx
    dadc:	48 39 d0             	cmp    %rdx,%rax
    dadf:	73 59                	jae    db3a <f0+0x265a>
    dae1:	48 89 c2             	mov    %rax,%rdx
    dae4:	48 c1 ea 10          	shr    $0x10,%rdx
    dae8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    daec:	48 8b 15 e5 70 01 00 	mov    0x170e5(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    daf3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    daf7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dafb:	4d 85 e4             	test   %r12,%r12
    dafe:	74 3a                	je     db3a <f0+0x265a>
    db00:	0f b6 0a             	movzbl (%rdx),%ecx
    db03:	80 f9 02             	cmp    $0x2,%cl
    db06:	0f 84 04 04 00 00    	je     df10 <f0+0x2a30>
    db0c:	80 f9 01             	cmp    $0x1,%cl
    db0f:	75 29                	jne    db3a <f0+0x265a>
    db11:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db14:	0f b7 c0             	movzwl %ax,%eax
    db17:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db1a:	48 0f af c1          	imul   %rcx,%rax
    db1e:	48 c1 e8 20          	shr    $0x20,%rax
    db22:	48 39 d0             	cmp    %rdx,%rax
    db25:	73 13                	jae    db3a <f0+0x265a>
    db27:	49 01 c4             	add    %rax,%r12
    db2a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db2f:	0f 84 7d 06 00 00    	je     e1b2 <f0+0x2cd2>
    db35:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db3a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    db41:	33 f3 bf 
    db44:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    db4b:	00 
    db4c:	bf 01 00 00 00       	mov    $0x1,%edi
    db51:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    db58:	00 
    db59:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    db60:	00 
    db61:	e8 fa 89 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    db66:	48 8b 15 4b 70 01 00 	mov    0x1704b(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    db6d:	49 89 c5             	mov    %rax,%r13
    db70:	48 2b 05 19 70 01 00 	sub    0x17019(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    db77:	48 c1 e2 10          	shl    $0x10,%rdx
    db7b:	48 39 d0             	cmp    %rdx,%rax
    db7e:	73 59                	jae    dbd9 <f0+0x26f9>
    db80:	48 89 c2             	mov    %rax,%rdx
    db83:	48 c1 ea 10          	shr    $0x10,%rdx
    db87:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db8b:	48 8b 15 46 70 01 00 	mov    0x17046(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    db92:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db96:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db9a:	4d 85 e4             	test   %r12,%r12
    db9d:	74 3a                	je     dbd9 <f0+0x26f9>
    db9f:	0f b6 0a             	movzbl (%rdx),%ecx
    dba2:	80 f9 02             	cmp    $0x2,%cl
    dba5:	0f 84 55 03 00 00    	je     df00 <f0+0x2a20>
    dbab:	80 f9 01             	cmp    $0x1,%cl
    dbae:	75 29                	jne    dbd9 <f0+0x26f9>
    dbb0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbb3:	0f b7 c0             	movzwl %ax,%eax
    dbb6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dbb9:	48 0f af c1          	imul   %rcx,%rax
    dbbd:	48 c1 e8 20          	shr    $0x20,%rax
    dbc1:	48 39 d0             	cmp    %rdx,%rax
    dbc4:	73 13                	jae    dbd9 <f0+0x26f9>
    dbc6:	49 01 c4             	add    %rax,%r12
    dbc9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dbce:	0f 84 eb 05 00 00    	je     e1bf <f0+0x2cdf>
    dbd4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dbd9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dbe0:	00 f0 3f 
    dbe3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    dbea:	00 
    dbeb:	bf 01 00 00 00       	mov    $0x1,%edi
    dbf0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    dbf7:	00 
    dbf8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    dbff:	00 
    dc00:	e8 5b 89 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    dc05:	48 8b 15 ac 6f 01 00 	mov    0x16fac(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dc0c:	49 89 c5             	mov    %rax,%r13
    dc0f:	48 2b 05 7a 6f 01 00 	sub    0x16f7a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dc16:	48 c1 e2 10          	shl    $0x10,%rdx
    dc1a:	48 39 d0             	cmp    %rdx,%rax
    dc1d:	73 59                	jae    dc78 <f0+0x2798>
    dc1f:	48 89 c2             	mov    %rax,%rdx
    dc22:	48 c1 ea 10          	shr    $0x10,%rdx
    dc26:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc2a:	48 8b 15 a7 6f 01 00 	mov    0x16fa7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dc31:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc35:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc39:	4d 85 e4             	test   %r12,%r12
    dc3c:	74 3a                	je     dc78 <f0+0x2798>
    dc3e:	0f b6 0a             	movzbl (%rdx),%ecx
    dc41:	80 f9 02             	cmp    $0x2,%cl
    dc44:	0f 84 a6 02 00 00    	je     def0 <f0+0x2a10>
    dc4a:	80 f9 01             	cmp    $0x1,%cl
    dc4d:	75 29                	jne    dc78 <f0+0x2798>
    dc4f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc52:	0f b7 c0             	movzwl %ax,%eax
    dc55:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc58:	48 0f af c1          	imul   %rcx,%rax
    dc5c:	48 c1 e8 20          	shr    $0x20,%rax
    dc60:	48 39 d0             	cmp    %rdx,%rax
    dc63:	73 13                	jae    dc78 <f0+0x2798>
    dc65:	49 01 c4             	add    %rax,%r12
    dc68:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc6d:	0f 84 59 05 00 00    	je     e1cc <f0+0x2cec>
    dc73:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc78:	48 89 ee             	mov    %rbp,%rsi
    dc7b:	bf 01 00 00 00       	mov    $0x1,%edi
    dc80:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dc87:	33 f3 bf 
    dc8a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    dc91:	00 
    dc92:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    dc99:	00 
    dc9a:	e8 c1 88 ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    dc9f:	48 8b 15 12 6f 01 00 	mov    0x16f12(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dca6:	48 89 c5             	mov    %rax,%rbp
    dca9:	48 2b 05 e0 6e 01 00 	sub    0x16ee0(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dcb0:	48 c1 e2 10          	shl    $0x10,%rdx
    dcb4:	48 39 d0             	cmp    %rdx,%rax
    dcb7:	73 59                	jae    dd12 <f0+0x2832>
    dcb9:	48 89 c2             	mov    %rax,%rdx
    dcbc:	48 c1 ea 10          	shr    $0x10,%rdx
    dcc0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dcc4:	48 8b 15 0d 6f 01 00 	mov    0x16f0d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dccb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dccf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dcd3:	4d 85 e4             	test   %r12,%r12
    dcd6:	74 3a                	je     dd12 <f0+0x2832>
    dcd8:	0f b6 0a             	movzbl (%rdx),%ecx
    dcdb:	80 f9 02             	cmp    $0x2,%cl
    dcde:	0f 84 fc 01 00 00    	je     dee0 <f0+0x2a00>
    dce4:	80 f9 01             	cmp    $0x1,%cl
    dce7:	75 29                	jne    dd12 <f0+0x2832>
    dce9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dcec:	0f b7 c0             	movzwl %ax,%eax
    dcef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dcf2:	48 0f af c1          	imul   %rcx,%rax
    dcf6:	48 c1 e8 20          	shr    $0x20,%rax
    dcfa:	48 39 d0             	cmp    %rdx,%rax
    dcfd:	73 13                	jae    dd12 <f0+0x2832>
    dcff:	49 01 c4             	add    %rax,%r12
    dd02:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd07:	0f 84 d1 02 00 00    	je     dfde <f0+0x2afe>
    dd0d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd12:	48 89 de             	mov    %rbx,%rsi
    dd15:	48 89 ef             	mov    %rbp,%rdi
    dd18:	e8 63 cb ff ff       	call   a880 <fwp_hof0.constprop.0>
    dd1d:	48 89 ef             	mov    %rbp,%rdi
    dd20:	e8 ab 8d ff ff       	call   6ad0 <fwp_drop0>
    dd25:	48 89 df             	mov    %rbx,%rdi
    dd28:	e8 a3 8d ff ff       	call   6ad0 <fwp_drop0>
    dd2d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    dd34:	00 
    dd35:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    dd3c:	00 00 
    dd3e:	0f 85 95 04 00 00    	jne    e1d9 <f0+0x2cf9>
    dd44:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    dd4b:	31 c0                	xor    %eax,%eax
    dd4d:	5b                   	pop    %rbx
    dd4e:	5d                   	pop    %rbp
    dd4f:	41 5c                	pop    %r12
    dd51:	41 5d                	pop    %r13
    dd53:	41 5e                	pop    %r14
    dd55:	c3                   	ret
    dd56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dd5d:	00 00 00 
    dd60:	4c 89 ef             	mov    %r13,%rdi
    dd63:	e8 e8 77 ff ff       	call   5550 <fwp_rc_forget_slot>
    dd68:	e9 2c d8 ff ff       	jmp    b599 <f0+0xb9>
    dd6d:	0f 1f 00             	nopl   (%rax)
    dd70:	66 85 c0             	test   %ax,%ax
    dd73:	0f 85 ae f5 ff ff    	jne    d327 <f0+0x1e47>
    dd79:	e9 99 f5 ff ff       	jmp    d317 <f0+0x1e37>
    dd7e:	66 90                	xchg   %ax,%ax
    dd80:	66 85 c0             	test   %ax,%ax
    dd83:	0f 85 ff f4 ff ff    	jne    d288 <f0+0x1da8>
    dd89:	e9 ea f4 ff ff       	jmp    d278 <f0+0x1d98>
    dd8e:	66 90                	xchg   %ax,%ax
    dd90:	66 85 c0             	test   %ax,%ax
    dd93:	0f 85 50 f4 ff ff    	jne    d1e9 <f0+0x1d09>
    dd99:	e9 3b f4 ff ff       	jmp    d1d9 <f0+0x1cf9>
    dd9e:	66 90                	xchg   %ax,%ax
    dda0:	66 85 c0             	test   %ax,%ax
    dda3:	0f 85 a1 f3 ff ff    	jne    d14a <f0+0x1c6a>
    dda9:	e9 8c f3 ff ff       	jmp    d13a <f0+0x1c5a>
    ddae:	66 90                	xchg   %ax,%ax
    ddb0:	66 85 c0             	test   %ax,%ax
    ddb3:	0f 85 f2 f2 ff ff    	jne    d0ab <f0+0x1bcb>
    ddb9:	e9 dd f2 ff ff       	jmp    d09b <f0+0x1bbb>
    ddbe:	66 90                	xchg   %ax,%ax
    ddc0:	66 85 c0             	test   %ax,%ax
    ddc3:	0f 85 43 f2 ff ff    	jne    d00c <f0+0x1b2c>
    ddc9:	e9 2e f2 ff ff       	jmp    cffc <f0+0x1b1c>
    ddce:	66 90                	xchg   %ax,%ax
    ddd0:	66 85 c0             	test   %ax,%ax
    ddd3:	0f 85 94 f1 ff ff    	jne    cf6d <f0+0x1a8d>
    ddd9:	e9 7f f1 ff ff       	jmp    cf5d <f0+0x1a7d>
    ddde:	66 90                	xchg   %ax,%ax
    dde0:	66 85 c0             	test   %ax,%ax
    dde3:	0f 85 e5 f0 ff ff    	jne    cece <f0+0x19ee>
    dde9:	e9 d0 f0 ff ff       	jmp    cebe <f0+0x19de>
    ddee:	66 90                	xchg   %ax,%ax
    ddf0:	66 85 c0             	test   %ax,%ax
    ddf3:	0f 85 fd d9 ff ff    	jne    b7f6 <f0+0x316>
    ddf9:	e9 e8 d9 ff ff       	jmp    b7e6 <f0+0x306>
    ddfe:	66 90                	xchg   %ax,%ax
    de00:	66 85 c0             	test   %ax,%ax
    de03:	0f 85 57 d9 ff ff    	jne    b760 <f0+0x280>
    de09:	e9 42 d9 ff ff       	jmp    b750 <f0+0x270>
    de0e:	66 90                	xchg   %ax,%ax
    de10:	66 85 c0             	test   %ax,%ax
    de13:	0f 85 b1 d8 ff ff    	jne    b6ca <f0+0x1ea>
    de19:	e9 9c d8 ff ff       	jmp    b6ba <f0+0x1da>
    de1e:	66 90                	xchg   %ax,%ax
    de20:	66 85 c0             	test   %ax,%ax
    de23:	0f 85 0e eb ff ff    	jne    c937 <f0+0x1457>
    de29:	e9 f9 ea ff ff       	jmp    c927 <f0+0x1447>
    de2e:	66 90                	xchg   %ax,%ax
    de30:	66 85 c0             	test   %ax,%ax
    de33:	0f 85 5f ea ff ff    	jne    c898 <f0+0x13b8>
    de39:	e9 4a ea ff ff       	jmp    c888 <f0+0x13a8>
    de3e:	66 90                	xchg   %ax,%ax
    de40:	66 85 c0             	test   %ax,%ax
    de43:	0f 85 e2 da ff ff    	jne    b92b <f0+0x44b>
    de49:	e9 cd da ff ff       	jmp    b91b <f0+0x43b>
    de4e:	66 90                	xchg   %ax,%ax
    de50:	66 85 c0             	test   %ax,%ax
    de53:	0f 85 33 da ff ff    	jne    b88c <f0+0x3ac>
    de59:	e9 1e da ff ff       	jmp    b87c <f0+0x39c>
    de5e:	66 90                	xchg   %ax,%ax
    de60:	66 85 c0             	test   %ax,%ax
    de63:	0f 85 c6 ef ff ff    	jne    ce2f <f0+0x194f>
    de69:	e9 b1 ef ff ff       	jmp    ce1f <f0+0x193f>
    de6e:	66 90                	xchg   %ax,%ax
    de70:	66 85 c0             	test   %ax,%ax
    de73:	0f 85 17 ef ff ff    	jne    cd90 <f0+0x18b0>
    de79:	e9 02 ef ff ff       	jmp    cd80 <f0+0x18a0>
    de7e:	66 90                	xchg   %ax,%ax
    de80:	66 85 c0             	test   %ax,%ax
    de83:	0f 85 68 ee ff ff    	jne    ccf1 <f0+0x1811>
    de89:	e9 53 ee ff ff       	jmp    cce1 <f0+0x1801>
    de8e:	66 90                	xchg   %ax,%ax
    de90:	66 85 c0             	test   %ax,%ax
    de93:	0f 85 b9 ed ff ff    	jne    cc52 <f0+0x1772>
    de99:	e9 a4 ed ff ff       	jmp    cc42 <f0+0x1762>
    de9e:	66 90                	xchg   %ax,%ax
    dea0:	66 85 c0             	test   %ax,%ax
    dea3:	0f 85 0a ed ff ff    	jne    cbb3 <f0+0x16d3>
    dea9:	e9 f5 ec ff ff       	jmp    cba3 <f0+0x16c3>
    deae:	66 90                	xchg   %ax,%ax
    deb0:	66 85 c0             	test   %ax,%ax
    deb3:	0f 85 5b ec ff ff    	jne    cb14 <f0+0x1634>
    deb9:	e9 46 ec ff ff       	jmp    cb04 <f0+0x1624>
    debe:	66 90                	xchg   %ax,%ax
    dec0:	66 85 c0             	test   %ax,%ax
    dec3:	0f 85 ac eb ff ff    	jne    ca75 <f0+0x1595>
    dec9:	e9 97 eb ff ff       	jmp    ca65 <f0+0x1585>
    dece:	66 90                	xchg   %ax,%ax
    ded0:	66 85 c0             	test   %ax,%ax
    ded3:	0f 85 fd ea ff ff    	jne    c9d6 <f0+0x14f6>
    ded9:	e9 e8 ea ff ff       	jmp    c9c6 <f0+0x14e6>
    dede:	66 90                	xchg   %ax,%ax
    dee0:	66 85 c0             	test   %ax,%ax
    dee3:	0f 85 29 fe ff ff    	jne    dd12 <f0+0x2832>
    dee9:	e9 14 fe ff ff       	jmp    dd02 <f0+0x2822>
    deee:	66 90                	xchg   %ax,%ax
    def0:	66 85 c0             	test   %ax,%ax
    def3:	0f 85 7f fd ff ff    	jne    dc78 <f0+0x2798>
    def9:	e9 6a fd ff ff       	jmp    dc68 <f0+0x2788>
    defe:	66 90                	xchg   %ax,%ax
    df00:	66 85 c0             	test   %ax,%ax
    df03:	0f 85 d0 fc ff ff    	jne    dbd9 <f0+0x26f9>
    df09:	e9 bb fc ff ff       	jmp    dbc9 <f0+0x26e9>
    df0e:	66 90                	xchg   %ax,%ax
    df10:	66 85 c0             	test   %ax,%ax
    df13:	0f 85 21 fc ff ff    	jne    db3a <f0+0x265a>
    df19:	e9 0c fc ff ff       	jmp    db2a <f0+0x264a>
    df1e:	66 90                	xchg   %ax,%ax
    df20:	66 85 c0             	test   %ax,%ax
    df23:	0f 85 72 fb ff ff    	jne    da9b <f0+0x25bb>
    df29:	e9 5d fb ff ff       	jmp    da8b <f0+0x25ab>
    df2e:	66 90                	xchg   %ax,%ax
    df30:	66 85 c0             	test   %ax,%ax
    df33:	0f 85 c3 fa ff ff    	jne    d9fc <f0+0x251c>
    df39:	e9 ae fa ff ff       	jmp    d9ec <f0+0x250c>
    df3e:	66 90                	xchg   %ax,%ax
    df40:	66 85 c0             	test   %ax,%ax
    df43:	0f 85 14 fa ff ff    	jne    d95d <f0+0x247d>
    df49:	e9 ff f9 ff ff       	jmp    d94d <f0+0x246d>
    df4e:	66 90                	xchg   %ax,%ax
    df50:	66 85 c0             	test   %ax,%ax
    df53:	0f 85 65 f9 ff ff    	jne    d8be <f0+0x23de>
    df59:	e9 50 f9 ff ff       	jmp    d8ae <f0+0x23ce>
    df5e:	66 90                	xchg   %ax,%ax
    df60:	66 85 c0             	test   %ax,%ax
    df63:	0f 85 b6 f8 ff ff    	jne    d81f <f0+0x233f>
    df69:	e9 a1 f8 ff ff       	jmp    d80f <f0+0x232f>
    df6e:	66 90                	xchg   %ax,%ax
    df70:	66 85 c0             	test   %ax,%ax
    df73:	0f 85 07 f8 ff ff    	jne    d780 <f0+0x22a0>
    df79:	e9 f2 f7 ff ff       	jmp    d770 <f0+0x2290>
    df7e:	66 90                	xchg   %ax,%ax
    df80:	66 85 c0             	test   %ax,%ax
    df83:	0f 85 58 f7 ff ff    	jne    d6e1 <f0+0x2201>
    df89:	e9 43 f7 ff ff       	jmp    d6d1 <f0+0x21f1>
    df8e:	66 90                	xchg   %ax,%ax
    df90:	66 85 c0             	test   %ax,%ax
    df93:	0f 85 a9 f6 ff ff    	jne    d642 <f0+0x2162>
    df99:	e9 94 f6 ff ff       	jmp    d632 <f0+0x2152>
    df9e:	66 90                	xchg   %ax,%ax
    dfa0:	66 85 c0             	test   %ax,%ax
    dfa3:	0f 85 fa f5 ff ff    	jne    d5a3 <f0+0x20c3>
    dfa9:	e9 e5 f5 ff ff       	jmp    d593 <f0+0x20b3>
    dfae:	66 90                	xchg   %ax,%ax
    dfb0:	66 85 c0             	test   %ax,%ax
    dfb3:	0f 85 4b f5 ff ff    	jne    d504 <f0+0x2024>
    dfb9:	e9 36 f5 ff ff       	jmp    d4f4 <f0+0x2014>
    dfbe:	66 90                	xchg   %ax,%ax
    dfc0:	66 85 c0             	test   %ax,%ax
    dfc3:	0f 85 9c f4 ff ff    	jne    d465 <f0+0x1f85>
    dfc9:	e9 87 f4 ff ff       	jmp    d455 <f0+0x1f75>
    dfce:	66 90                	xchg   %ax,%ax
    dfd0:	66 85 c0             	test   %ax,%ax
    dfd3:	0f 85 ed f3 ff ff    	jne    d3c6 <f0+0x1ee6>
    dfd9:	e9 d8 f3 ff ff       	jmp    d3b6 <f0+0x1ed6>
    dfde:	4c 89 e7             	mov    %r12,%rdi
    dfe1:	e8 6a 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dfe6:	e9 22 fd ff ff       	jmp    dd0d <f0+0x282d>
    dfeb:	4c 89 e7             	mov    %r12,%rdi
    dfee:	e8 5d 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    dff3:	e9 cd d6 ff ff       	jmp    b6c5 <f0+0x1e5>
    dff8:	4c 89 e7             	mov    %r12,%rdi
    dffb:	e8 50 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e000:	e9 56 d7 ff ff       	jmp    b75b <f0+0x27b>
    e005:	4c 89 e7             	mov    %r12,%rdi
    e008:	e8 43 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e00d:	e9 df d7 ff ff       	jmp    b7f1 <f0+0x311>
    e012:	4c 89 e7             	mov    %r12,%rdi
    e015:	e8 36 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e01a:	e9 68 d8 ff ff       	jmp    b887 <f0+0x3a7>
    e01f:	4c 89 e7             	mov    %r12,%rdi
    e022:	e8 29 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e027:	e9 fa d8 ff ff       	jmp    b926 <f0+0x446>
    e02c:	4c 89 e7             	mov    %r12,%rdi
    e02f:	e8 1c 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e034:	e9 5a e8 ff ff       	jmp    c893 <f0+0x13b3>
    e039:	4c 89 e7             	mov    %r12,%rdi
    e03c:	e8 0f 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e041:	e9 ec e8 ff ff       	jmp    c932 <f0+0x1452>
    e046:	4c 89 e7             	mov    %r12,%rdi
    e049:	e8 02 75 ff ff       	call   5550 <fwp_rc_forget_slot>
    e04e:	e9 7e e9 ff ff       	jmp    c9d1 <f0+0x14f1>
    e053:	4c 89 e7             	mov    %r12,%rdi
    e056:	e8 f5 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e05b:	e9 10 ea ff ff       	jmp    ca70 <f0+0x1590>
    e060:	4c 89 e7             	mov    %r12,%rdi
    e063:	e8 e8 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e068:	e9 a2 ea ff ff       	jmp    cb0f <f0+0x162f>
    e06d:	4c 89 e7             	mov    %r12,%rdi
    e070:	e8 db 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e075:	e9 34 eb ff ff       	jmp    cbae <f0+0x16ce>
    e07a:	4c 89 e7             	mov    %r12,%rdi
    e07d:	e8 ce 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e082:	e9 c6 eb ff ff       	jmp    cc4d <f0+0x176d>
    e087:	4c 89 e7             	mov    %r12,%rdi
    e08a:	e8 c1 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e08f:	e9 58 ec ff ff       	jmp    ccec <f0+0x180c>
    e094:	4c 89 e7             	mov    %r12,%rdi
    e097:	e8 b4 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e09c:	e9 ea ec ff ff       	jmp    cd8b <f0+0x18ab>
    e0a1:	4c 89 e7             	mov    %r12,%rdi
    e0a4:	e8 a7 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0a9:	e9 7c ed ff ff       	jmp    ce2a <f0+0x194a>
    e0ae:	4c 89 e7             	mov    %r12,%rdi
    e0b1:	e8 9a 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0b6:	e9 0e ee ff ff       	jmp    cec9 <f0+0x19e9>
    e0bb:	4c 89 e7             	mov    %r12,%rdi
    e0be:	e8 8d 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0c3:	e9 a0 ee ff ff       	jmp    cf68 <f0+0x1a88>
    e0c8:	4c 89 e7             	mov    %r12,%rdi
    e0cb:	e8 80 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0d0:	e9 32 ef ff ff       	jmp    d007 <f0+0x1b27>
    e0d5:	4c 89 e7             	mov    %r12,%rdi
    e0d8:	e8 73 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0dd:	e9 c4 ef ff ff       	jmp    d0a6 <f0+0x1bc6>
    e0e2:	4c 89 e7             	mov    %r12,%rdi
    e0e5:	e8 66 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0ea:	e9 56 f0 ff ff       	jmp    d145 <f0+0x1c65>
    e0ef:	4c 89 e7             	mov    %r12,%rdi
    e0f2:	e8 59 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e0f7:	e9 e8 f0 ff ff       	jmp    d1e4 <f0+0x1d04>
    e0fc:	4c 89 e7             	mov    %r12,%rdi
    e0ff:	e8 4c 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e104:	e9 7a f1 ff ff       	jmp    d283 <f0+0x1da3>
    e109:	4c 89 e7             	mov    %r12,%rdi
    e10c:	e8 3f 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e111:	e9 0c f2 ff ff       	jmp    d322 <f0+0x1e42>
    e116:	4c 89 e7             	mov    %r12,%rdi
    e119:	e8 32 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e11e:	e9 9e f2 ff ff       	jmp    d3c1 <f0+0x1ee1>
    e123:	4c 89 e7             	mov    %r12,%rdi
    e126:	e8 25 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e12b:	e9 30 f3 ff ff       	jmp    d460 <f0+0x1f80>
    e130:	4c 89 e7             	mov    %r12,%rdi
    e133:	e8 18 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e138:	e9 c2 f3 ff ff       	jmp    d4ff <f0+0x201f>
    e13d:	4c 89 e7             	mov    %r12,%rdi
    e140:	e8 0b 74 ff ff       	call   5550 <fwp_rc_forget_slot>
    e145:	e9 54 f4 ff ff       	jmp    d59e <f0+0x20be>
    e14a:	4c 89 e7             	mov    %r12,%rdi
    e14d:	e8 fe 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e152:	e9 e6 f4 ff ff       	jmp    d63d <f0+0x215d>
    e157:	4c 89 e7             	mov    %r12,%rdi
    e15a:	e8 f1 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e15f:	e9 78 f5 ff ff       	jmp    d6dc <f0+0x21fc>
    e164:	4c 89 e7             	mov    %r12,%rdi
    e167:	e8 e4 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e16c:	e9 0a f6 ff ff       	jmp    d77b <f0+0x229b>
    e171:	4c 89 e7             	mov    %r12,%rdi
    e174:	e8 d7 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e179:	e9 9c f6 ff ff       	jmp    d81a <f0+0x233a>
    e17e:	4c 89 e7             	mov    %r12,%rdi
    e181:	e8 ca 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e186:	e9 2e f7 ff ff       	jmp    d8b9 <f0+0x23d9>
    e18b:	4c 89 e7             	mov    %r12,%rdi
    e18e:	e8 bd 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e193:	e9 c0 f7 ff ff       	jmp    d958 <f0+0x2478>
    e198:	4c 89 e7             	mov    %r12,%rdi
    e19b:	e8 b0 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1a0:	e9 52 f8 ff ff       	jmp    d9f7 <f0+0x2517>
    e1a5:	4c 89 e7             	mov    %r12,%rdi
    e1a8:	e8 a3 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1ad:	e9 e4 f8 ff ff       	jmp    da96 <f0+0x25b6>
    e1b2:	4c 89 e7             	mov    %r12,%rdi
    e1b5:	e8 96 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1ba:	e9 76 f9 ff ff       	jmp    db35 <f0+0x2655>
    e1bf:	4c 89 e7             	mov    %r12,%rdi
    e1c2:	e8 89 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1c7:	e9 08 fa ff ff       	jmp    dbd4 <f0+0x26f4>
    e1cc:	4c 89 e7             	mov    %r12,%rdi
    e1cf:	e8 7c 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e1d4:	e9 9a fa ff ff       	jmp    dc73 <f0+0x2793>
    e1d9:	e8 82 52 ff ff       	call   3460 <__stack_chk_fail@plt>
    e1de:	66 90                	xchg   %ax,%ax

000000000000e1e0 <fwp_main_thread>:
    e1e0:	f3 0f 1e fa          	endbr64
    e1e4:	41 54                	push   %r12
    e1e6:	55                   	push   %rbp
    e1e7:	53                   	push   %rbx
    e1e8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e1ef:	8b 35 8f 69 01 00    	mov    0x1698f(%rip),%esi        # 24b84 <fwp_heap+0x13a4>
    e1f5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e1fc:	00 00 
    e1fe:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e205:	00 
    e206:	31 c0                	xor    %eax,%eax
    e208:	85 f6                	test   %esi,%esi
    e20a:	0f 84 a8 06 00 00    	je     e8b8 <fwp_main_thread+0x6d8>
    e210:	8b 0d 72 69 01 00    	mov    0x16972(%rip),%ecx        # 24b88 <fwp_heap+0x13a8>
    e216:	85 c9                	test   %ecx,%ecx
    e218:	0f 85 82 06 00 00    	jne    e8a0 <fwp_main_thread+0x6c0>
    e21e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e223:	31 f6                	xor    %esi,%esi
    e225:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e22a:	48 c7 05 3b 4f 01 00 	movq   $0x40000000,0x14f3b(%rip)        # 23170 <fwp_main_stack_size>
    e231:	00 00 00 40 
    e235:	48 89 05 3c 4f 01 00 	mov    %rax,0x14f3c(%rip)        # 23178 <fwp_main_stack_top>
    e23c:	48 8d 05 5d 4e 00 00 	lea    0x4e5d(%rip),%rax        # 130a0 <alt.5>
    e243:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e248:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e24f:	01 00 
    e251:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e258:	00 
    e259:	e8 62 54 ff ff       	call   36c0 <sigaltstack@plt>
    e25e:	85 c0                	test   %eax,%eax
    e260:	0f 85 8a 06 00 00    	jne    e8f0 <fwp_main_thread+0x710>
    e266:	31 c0                	xor    %eax,%eax
    e268:	b9 12 00 00 00       	mov    $0x12,%ecx
    e26d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e272:	f3 48 ab             	rep stos %rax,(%rdi)
    e275:	48 8d 05 74 5a ff ff 	lea    -0xa58c(%rip),%rax        # 3cf0 <fwp_segv>
    e27c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e281:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e288:	04 00 00 08 
    e28c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e291:	e8 ea 52 ff ff       	call   3580 <sigemptyset@plt>
    e296:	85 c0                	test   %eax,%eax
    e298:	0f 85 52 06 00 00    	jne    e8f0 <fwp_main_thread+0x710>
    e29e:	31 d2                	xor    %edx,%edx
    e2a0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e2a5:	bf 0b 00 00 00       	mov    $0xb,%edi
    e2aa:	e8 51 51 ff ff       	call   3400 <sigaction@plt>
    e2af:	85 c0                	test   %eax,%eax
    e2b1:	0f 85 39 06 00 00    	jne    e8f0 <fwp_main_thread+0x710>
    e2b7:	31 d2                	xor    %edx,%edx
    e2b9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e2be:	bf 07 00 00 00       	mov    $0x7,%edi
    e2c3:	e8 38 51 ff ff       	call   3400 <sigaction@plt>
    e2c8:	85 c0                	test   %eax,%eax
    e2ca:	0f 85 20 06 00 00    	jne    e8f0 <fwp_main_thread+0x710>
    e2d0:	8b 15 42 4e 01 00    	mov    0x14e42(%rip),%edx        # 23118 <descent_registered>
    e2d6:	85 d2                	test   %edx,%edx
    e2d8:	0f 84 72 05 00 00    	je     e850 <fwp_main_thread+0x670>
    e2de:	8b 05 ac 4d 00 00    	mov    0x4dac(%rip),%eax        # 13090 <st.3>
    e2e4:	85 c0                	test   %eax,%eax
    e2e6:	0f 84 90 05 00 00    	je     e87c <fwp_main_thread+0x69c>
    e2ec:	48 8b 2d cd 54 01 00 	mov    0x154cd(%rip),%rbp        # 237c0 <fwp_cur>
    e2f3:	48 85 ed             	test   %rbp,%rbp
    e2f6:	0f 84 74 03 00 00    	je     e670 <fwp_main_thread+0x490>
    e2fc:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e301:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e305:	48 89 eb             	mov    %rbp,%rbx
    e308:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e30d:	0f 84 41 01 00 00    	je     e454 <fwp_main_thread+0x274>
    e313:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e318:	0f 84 82 02 00 00    	je     e5a0 <fwp_main_thread+0x3c0>
    e31e:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e322:	0f 84 68 02 00 00    	je     e590 <fwp_main_thread+0x3b0>
    e328:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e32c:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e330:	0f 85 ea 02 00 00    	jne    e620 <fwp_main_thread+0x440>
    e336:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e33a:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e341:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e345:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e34c:	00 00 00 00 
    e350:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e357:	48 85 d2             	test   %rdx,%rdx
    e35a:	74 07                	je     e363 <fwp_main_thread+0x183>
    e35c:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e363:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e367:	48 85 c0             	test   %rax,%rax
    e36a:	74 34                	je     e3a0 <fwp_main_thread+0x1c0>
    e36c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e370:	48 8b 05 21 54 01 00 	mov    0x15421(%rip),%rax        # 23798 <fwp_timers>
    e377:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e37b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e382:	00 00 00 00 
    e386:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e38d:	48 85 c0             	test   %rax,%rax
    e390:	74 07                	je     e399 <fwp_main_thread+0x1b9>
    e392:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e399:	48 89 1d f8 53 01 00 	mov    %rbx,0x153f8(%rip)        # 23798 <fwp_timers>
    e3a0:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e3a4:	e8 67 91 ff ff       	call   7510 <fwp_block>
    e3a9:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e3b0:	48 85 c9             	test   %rcx,%rcx
    e3b3:	74 47                	je     e3fc <fwp_main_thread+0x21c>
    e3b5:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e3bc:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e3c3:	48 85 d2             	test   %rdx,%rdx
    e3c6:	0f 84 94 02 00 00    	je     e660 <fwp_main_thread+0x480>
    e3cc:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e3d3:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e3da:	48 85 c0             	test   %rax,%rax
    e3dd:	74 07                	je     e3e6 <fwp_main_thread+0x206>
    e3df:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e3e6:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e3ed:	00 00 00 00 
    e3f1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e3f5:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e3fc:	48 8b 0d bd 53 01 00 	mov    0x153bd(%rip),%rcx        # 237c0 <fwp_cur>
    e403:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e407:	0f 84 03 02 00 00    	je     e610 <fwp_main_thread+0x430>
    e40d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e414:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e41b:	48 85 d2             	test   %rdx,%rdx
    e41e:	0f 84 fc 03 00 00    	je     e820 <fwp_main_thread+0x640>
    e424:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e42b:	48 85 c0             	test   %rax,%rax
    e42e:	74 07                	je     e437 <fwp_main_thread+0x257>
    e430:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e437:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e43b:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e43f:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e446:	48 89 cb             	mov    %rcx,%rbx
    e449:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e44e:	0f 85 bf fe ff ff    	jne    e313 <fwp_main_thread+0x133>
    e454:	48 83 3d fc 6f 01 00 	cmpq   $0x0,0x16ffc(%rip)        # 25458 <fwp_state_len>
    e45b:	00 
    e45c:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e460:	0f 84 bc 00 00 00    	je     e522 <fwp_main_thread+0x342>
    e466:	48 39 1d 4b 53 01 00 	cmp    %rbx,0x1534b(%rip)        # 237b8 <fwp_root>
    e46d:	c7 05 29 4c 01 00 00 	movl   $0x0,0x14c29(%rip)        # 230a0 <fwp_exit_code>
    e474:	00 00 00 
    e477:	0f 85 91 04 00 00    	jne    e90e <fwp_main_thread+0x72e>
    e47d:	48 85 db             	test   %rbx,%rbx
    e480:	0f 84 10 02 00 00    	je     e696 <fwp_main_thread+0x4b6>
    e486:	48 8b 15 fb 52 01 00 	mov    0x152fb(%rip),%rdx        # 23788 <fwp_tasks_active>
    e48d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e491:	48 85 d2             	test   %rdx,%rdx
    e494:	0f 84 fc 01 00 00    	je     e696 <fwp_main_thread+0x4b6>
    e49a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e4a0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e4a4:	75 08                	jne    e4ae <fwp_main_thread+0x2ce>
    e4a6:	48 89 d7             	mov    %rdx,%rdi
    e4a9:	e8 52 5e ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e4ae:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e4b5:	48 85 d2             	test   %rdx,%rdx
    e4b8:	75 e6                	jne    e4a0 <fwp_main_thread+0x2c0>
    e4ba:	eb 31                	jmp    e4ed <fwp_main_thread+0x30d>
    e4bc:	0f 1f 40 00          	nopl   0x0(%rax)
    e4c0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e4c7:	48 89 1d d2 52 01 00 	mov    %rbx,0x152d2(%rip)        # 237a0 <fwp_ready_tail>
    e4ce:	e8 3d 90 ff ff       	call   7510 <fwp_block>
    e4d3:	e8 38 8e ff ff       	call   7310 <fwp_free_zombie>
    e4d8:	48 83 3d a8 52 01 00 	cmpq   $0x0,0x152a8(%rip)        # 23788 <fwp_tasks_active>
    e4df:	00 
    e4e0:	0f 84 b0 01 00 00    	je     e696 <fwp_main_thread+0x4b6>
    e4e6:	48 8b 1d cb 52 01 00 	mov    0x152cb(%rip),%rbx        # 237b8 <fwp_root>
    e4ed:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e4f1:	75 db                	jne    e4ce <fwp_main_thread+0x2ee>
    e4f3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e4f7:	75 d5                	jne    e4ce <fwp_main_thread+0x2ee>
    e4f9:	48 8b 05 a0 52 01 00 	mov    0x152a0(%rip),%rax        # 237a0 <fwp_ready_tail>
    e500:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e504:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e50b:	00 00 00 00 
    e50f:	48 85 c0             	test   %rax,%rax
    e512:	75 ac                	jne    e4c0 <fwp_main_thread+0x2e0>
    e514:	48 89 1d 8d 52 01 00 	mov    %rbx,0x1528d(%rip)        # 237a8 <fwp_ready_head>
    e51b:	eb aa                	jmp    e4c7 <fwp_main_thread+0x2e7>
    e51d:	0f 1f 00             	nopl   (%rax)
    e520:	31 db                	xor    %ebx,%ebx
    e522:	48 83 3d 1e 6f 01 00 	cmpq   $0x0,0x16f1e(%rip)        # 25448 <fwp_state_owners>
    e529:	00 
    e52a:	0f 85 36 ff ff ff    	jne    e466 <fwp_main_thread+0x286>
    e530:	48 8b 3d 29 6f 01 00 	mov    0x16f29(%rip),%rdi        # 25460 <fwp_state>
    e537:	e8 54 72 ff ff       	call   5790 <fwp_mem_free>
    e53c:	48 c7 05 19 6f 01 00 	movq   $0x0,0x16f19(%rip)        # 25460 <fwp_state>
    e543:	00 00 00 00 
    e547:	48 c7 05 fe 6e 01 00 	movq   $0x0,0x16efe(%rip)        # 25450 <fwp_state_cap>
    e54e:	00 00 00 00 
    e552:	48 85 db             	test   %rbx,%rbx
    e555:	0f 84 76 03 00 00    	je     e8d1 <fwp_main_thread+0x6f1>
    e55b:	48 39 1d 56 52 01 00 	cmp    %rbx,0x15256(%rip)        # 237b8 <fwp_root>
    e562:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e569:	00 00 00 00 
    e56d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e574:	00 00 00 00 
    e578:	c7 05 1e 4b 01 00 00 	movl   $0x0,0x14b1e(%rip)        # 230a0 <fwp_exit_code>
    e57f:	00 00 00 
    e582:	0f 84 fe fe ff ff    	je     e486 <fwp_main_thread+0x2a6>
    e588:	e9 c3 51 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e58d:	0f 1f 00             	nopl   (%rax)
    e590:	e8 cb 5f ff ff       	call   4560 <fwp_now_ns>
    e595:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e599:	0f 8d 91 02 00 00    	jge    e830 <fwp_main_thread+0x650>
    e59f:	90                   	nop
    e5a0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e5a4:	0f 85 7e fd ff ff    	jne    e328 <fwp_main_thread+0x148>
    e5aa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e5ae:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e5b2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e5b6:	0f 85 7e fd ff ff    	jne    e33a <fwp_main_thread+0x15a>
    e5bc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e5c0:	48 85 c9             	test   %rcx,%rcx
    e5c3:	0f 84 71 fd ff ff    	je     e33a <fwp_main_thread+0x15a>
    e5c9:	48 85 c0             	test   %rax,%rax
    e5cc:	0f 84 2f 03 00 00    	je     e901 <fwp_main_thread+0x721>
    e5d2:	48 39 c8             	cmp    %rcx,%rax
    e5d5:	48 0f 4f c1          	cmovg  %rcx,%rax
    e5d9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e5e0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e5e4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e5eb:	00 00 00 00 
    e5ef:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e5f6:	48 85 d2             	test   %rdx,%rdx
    e5f9:	74 07                	je     e602 <fwp_main_thread+0x422>
    e5fb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e602:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e606:	e9 61 fd ff ff       	jmp    e36c <fwp_main_thread+0x18c>
    e60b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e610:	48 89 cb             	mov    %rcx,%rbx
    e613:	e9 f0 fc ff ff       	jmp    e308 <fwp_main_thread+0x128>
    e618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e61f:	00 
    e620:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e624:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e62b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e632:	00 00 00 00 
    e636:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e63d:	48 85 c0             	test   %rax,%rax
    e640:	0f 84 82 02 00 00    	je     e8c8 <fwp_main_thread+0x6e8>
    e646:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e64d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e651:	e9 4a fd ff ff       	jmp    e3a0 <fwp_main_thread+0x1c0>
    e656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e65d:	00 00 00 
    e660:	48 89 01             	mov    %rax,(%rcx)
    e663:	e9 72 fd ff ff       	jmp    e3da <fwp_main_thread+0x1fa>
    e668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e66f:	00 
    e670:	48 83 3d e0 6d 01 00 	cmpq   $0x0,0x16de0(%rip)        # 25458 <fwp_state_len>
    e677:	00 
    e678:	0f 84 a2 fe ff ff    	je     e520 <fwp_main_thread+0x340>
    e67e:	48 83 3d 32 51 01 00 	cmpq   $0x0,0x15132(%rip)        # 237b8 <fwp_root>
    e685:	00 
    e686:	c7 05 10 4a 01 00 00 	movl   $0x0,0x14a10(%rip)        # 230a0 <fwp_exit_code>
    e68d:	00 00 00 
    e690:	0f 85 7d 02 00 00    	jne    e913 <fwp_main_thread+0x733>
    e696:	e8 75 8c ff ff       	call   7310 <fwp_free_zombie>
    e69b:	48 83 3d 05 51 01 00 	cmpq   $0x0,0x15105(%rip)        # 237a8 <fwp_ready_head>
    e6a2:	00 
    e6a3:	0f 85 a7 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e6a9:	48 83 3d e7 50 01 00 	cmpq   $0x0,0x150e7(%rip)        # 23798 <fwp_timers>
    e6b0:	00 
    e6b1:	0f 85 99 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e6b7:	8b 1d c7 4a 01 00    	mov    0x14ac7(%rip),%ebx        # 23184 <fwp_stack_pool_n>
    e6bd:	85 db                	test   %ebx,%ebx
    e6bf:	74 36                	je     e6f7 <fwp_main_thread+0x517>
    e6c1:	83 eb 01             	sub    $0x1,%ebx
    e6c4:	48 8d 05 d5 4a 01 00 	lea    0x14ad5(%rip),%rax        # 231a0 <fwp_stack_pool>
    e6cb:	48 63 d3             	movslq %ebx,%rdx
    e6ce:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e6d2:	eb 07                	jmp    e6db <fwp_main_thread+0x4fb>
    e6d4:	0f 1f 40 00          	nopl   0x0(%rax)
    e6d8:	83 eb 01             	sub    $0x1,%ebx
    e6db:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e6df:	be 00 00 00 10       	mov    $0x10000000,%esi
    e6e4:	89 1d 9a 4a 01 00    	mov    %ebx,0x14a9a(%rip)        # 23184 <fwp_stack_pool_n>
    e6ea:	48 83 ed 08          	sub    $0x8,%rbp
    e6ee:	e8 ed 4e ff ff       	call   35e0 <munmap@plt>
    e6f3:	85 db                	test   %ebx,%ebx
    e6f5:	75 e1                	jne    e6d8 <fwp_main_thread+0x4f8>
    e6f7:	8b 3d 27 49 00 00    	mov    0x4927(%rip),%edi        # 13024 <fwp_epfd>
    e6fd:	85 ff                	test   %edi,%edi
    e6ff:	78 05                	js     e706 <fwp_main_thread+0x526>
    e701:	e8 ca 4d ff ff       	call   34d0 <close@plt>
    e706:	4c 8b 25 93 4c 01 00 	mov    0x14c93(%rip),%r12        # 233a0 <fwp_nfdws>
    e70d:	48 8b 2d 94 4c 01 00 	mov    0x14c94(%rip),%rbp        # 233a8 <fwp_fdws>
    e714:	31 db                	xor    %ebx,%ebx
    e716:	c7 05 04 49 00 00 ff 	movl   $0xffffffff,0x4904(%rip)        # 13024 <fwp_epfd>
    e71d:	ff ff ff 
    e720:	4d 85 e4             	test   %r12,%r12
    e723:	74 38                	je     e75d <fwp_main_thread+0x57d>
    e725:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e72c:	00 00 00 00 
    e730:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e735:	48 85 ff             	test   %rdi,%rdi
    e738:	74 1a                	je     e754 <fwp_main_thread+0x574>
    e73a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e73e:	0f 85 0c 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e744:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e749:	0f 85 01 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e74f:	e8 3c 70 ff ff       	call   5790 <fwp_mem_free>
    e754:	48 83 c3 01          	add    $0x1,%rbx
    e758:	4c 39 e3             	cmp    %r12,%rbx
    e75b:	75 d3                	jne    e730 <fwp_main_thread+0x550>
    e75d:	48 89 ef             	mov    %rbp,%rdi
    e760:	e8 2b 70 ff ff       	call   5790 <fwp_mem_free>
    e765:	48 8b 15 4c 50 01 00 	mov    0x1504c(%rip),%rdx        # 237b8 <fwp_root>
    e76c:	48 c7 05 31 4c 01 00 	movq   $0x0,0x14c31(%rip)        # 233a8 <fwp_fdws>
    e773:	00 00 00 00 
    e777:	48 c7 05 1e 4c 01 00 	movq   $0x0,0x14c1e(%rip)        # 233a0 <fwp_nfdws>
    e77e:	00 00 00 00 
    e782:	48 85 d2             	test   %rdx,%rdx
    e785:	74 4e                	je     e7d5 <fwp_main_thread+0x5f5>
    e787:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e78c:	0f 85 be 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e792:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e799:	00 
    e79a:	0f 85 b0 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e7a0:	48 83 3d b0 6c 01 00 	cmpq   $0x0,0x16cb0(%rip)        # 25458 <fwp_state_len>
    e7a7:	00 
    e7a8:	0f 85 a2 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e7ae:	48 83 3d 92 6c 01 00 	cmpq   $0x0,0x16c92(%rip)        # 25448 <fwp_state_owners>
    e7b5:	00 
    e7b6:	0f 85 94 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e7bc:	b9 79 00 00 00       	mov    $0x79,%ecx
    e7c1:	31 c0                	xor    %eax,%eax
    e7c3:	48 8d 3d f6 4b 01 00 	lea    0x14bf6(%rip),%rdi        # 233c0 <fwp_root_context>
    e7ca:	f3 48 ab             	rep stos %rax,(%rdi)
    e7cd:	48 89 d7             	mov    %rdx,%rdi
    e7d0:	e8 bb 6f ff ff       	call   5790 <fwp_mem_free>
    e7d5:	48 8b 3d 64 48 00 00 	mov    0x4864(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    e7dc:	48 c7 05 d9 4f 01 00 	movq   $0x0,0x14fd9(%rip)        # 237c0 <fwp_cur>
    e7e3:	00 00 00 00 
    e7e7:	48 c7 05 c6 4f 01 00 	movq   $0x0,0x14fc6(%rip)        # 237b8 <fwp_root>
    e7ee:	00 00 00 00 
    e7f2:	e8 c9 4d ff ff       	call   35c0 <fflush@plt>
    e7f7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e7fe:	00 
    e7ff:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e806:	00 00 
    e808:	0f 85 fb 00 00 00    	jne    e909 <fwp_main_thread+0x729>
    e80e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e815:	31 c0                	xor    %eax,%eax
    e817:	5b                   	pop    %rbx
    e818:	5d                   	pop    %rbp
    e819:	41 5c                	pop    %r12
    e81b:	c3                   	ret
    e81c:	0f 1f 40 00          	nopl   0x0(%rax)
    e820:	48 89 05 71 4f 01 00 	mov    %rax,0x14f71(%rip)        # 23798 <fwp_timers>
    e827:	e9 ff fb ff ff       	jmp    e42b <fwp_main_thread+0x24b>
    e82c:	0f 1f 40 00          	nopl   0x0(%rax)
    e830:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e834:	0f 85 66 fd ff ff    	jne    e5a0 <fwp_main_thread+0x3c0>
    e83a:	48 89 ef             	mov    %rbp,%rdi
    e83d:	e8 be 5a ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e842:	e9 59 fd ff ff       	jmp    e5a0 <fwp_main_thread+0x3c0>
    e847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e84e:	00 00 
    e850:	48 8d 3d b9 55 ff ff 	lea    -0xaa47(%rip),%rdi        # 3e10 <descent_phase_report>
    e857:	e8 d4 02 00 00       	call   eb30 <atexit>
    e85c:	85 c0                	test   %eax,%eax
    e85e:	0f 85 98 00 00 00    	jne    e8fc <fwp_main_thread+0x71c>
    e864:	c7 05 aa 48 01 00 01 	movl   $0x1,0x148aa(%rip)        # 23118 <descent_registered>
    e86b:	00 00 00 
    e86e:	8b 05 1c 48 00 00    	mov    0x481c(%rip),%eax        # 13090 <st.3>
    e874:	85 c0                	test   %eax,%eax
    e876:	0f 85 70 fa ff ff    	jne    e2ec <fwp_main_thread+0x10c>
    e87c:	e8 5f cc ff ff       	call   b4e0 <f0>
    e881:	48 c7 05 fc 47 00 00 	movq   $0x0,0x47fc(%rip)        # 13088 <v.2>
    e888:	00 00 00 00 
    e88c:	c7 05 fa 47 00 00 01 	movl   $0x1,0x47fa(%rip)        # 13090 <st.3>
    e893:	00 00 00 
    e896:	e9 51 fa ff ff       	jmp    e2ec <fwp_main_thread+0x10c>
    e89b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e8a0:	48 8d 3d b9 63 ff ff 	lea    -0x9c47(%rip),%rdi        # 4c60 <fwp_heap_report>
    e8a7:	e8 84 02 00 00       	call   eb30 <atexit>
    e8ac:	e9 6d f9 ff ff       	jmp    e21e <fwp_main_thread+0x3e>
    e8b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e8b8:	e8 b3 64 ff ff       	call   4d70 <fwp_heap_init>
    e8bd:	e9 4e f9 ff ff       	jmp    e210 <fwp_main_thread+0x30>
    e8c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e8c8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e8cc:	e9 cf fa ff ff       	jmp    e3a0 <fwp_main_thread+0x1c0>
    e8d1:	48 83 3d df 4e 01 00 	cmpq   $0x0,0x14edf(%rip)        # 237b8 <fwp_root>
    e8d8:	00 
    e8d9:	c7 05 bd 47 01 00 00 	movl   $0x0,0x147bd(%rip)        # 230a0 <fwp_exit_code>
    e8e0:	00 00 00 
    e8e3:	0f 84 ad fd ff ff    	je     e696 <fwp_main_thread+0x4b6>
    e8e9:	e9 62 4e ff ff       	jmp    3750 <fwp_main_thread.cold>
    e8ee:	66 90                	xchg   %ax,%ax
    e8f0:	48 8d 3d e9 10 00 00 	lea    0x10e9(%rip),%rdi        # f9e0 <_IO_stdin_used+0x9e0>
    e8f7:	e8 f4 5a ff ff       	call   43f0 <fwp_trap>
    e8fc:	e8 df 54 ff ff       	call   3de0 <descent_phase_fail>
    e901:	48 89 c8             	mov    %rcx,%rax
    e904:	e9 d0 fc ff ff       	jmp    e5d9 <fwp_main_thread+0x3f9>
    e909:	e8 52 4b ff ff       	call   3460 <__stack_chk_fail@plt>
    e90e:	e9 3d 4e ff ff       	jmp    3750 <fwp_main_thread.cold>
    e913:	e9 38 4e ff ff       	jmp    3750 <fwp_main_thread.cold>
    e918:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e91f:	00 

000000000000e920 <__divmodti4>:
    e920:	f3 0f 1e fa          	endbr64
    e924:	55                   	push   %rbp
    e925:	49 89 f1             	mov    %rsi,%r9
    e928:	49 89 d2             	mov    %rdx,%r10
    e92b:	48 89 fe             	mov    %rdi,%rsi
    e92e:	49 89 cb             	mov    %rcx,%r11
    e931:	48 89 e5             	mov    %rsp,%rbp
    e934:	41 57                	push   %r15
    e936:	41 56                	push   %r14
    e938:	41 55                	push   %r13
    e93a:	41 54                	push   %r12
    e93c:	53                   	push   %rbx
    e93d:	4c 89 c3             	mov    %r8,%rbx
    e940:	45 31 c0             	xor    %r8d,%r8d
    e943:	4d 85 c9             	test   %r9,%r9
    e946:	79 12                	jns    e95a <__divmodti4+0x3a>
    e948:	31 ff                	xor    %edi,%edi
    e94a:	48 f7 de             	neg    %rsi
    e94d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e954:	4c 19 cf             	sbb    %r9,%rdi
    e957:	49 89 f9             	mov    %rdi,%r9
    e95a:	4c 89 d8             	mov    %r11,%rax
    e95d:	4d 85 db             	test   %r11,%r11
    e960:	0f 88 1a 01 00 00    	js     ea80 <__divmodti4+0x160>
    e966:	4c 89 d9             	mov    %r11,%rcx
    e969:	49 89 f3             	mov    %rsi,%r11
    e96c:	75 62                	jne    e9d0 <__divmodti4+0xb0>
    e96e:	4d 89 c4             	mov    %r8,%r12
    e971:	4d 39 d1             	cmp    %r10,%r9
    e974:	0f 83 46 01 00 00    	jae    eac0 <__divmodti4+0x1a0>
    e97a:	4c 89 d8             	mov    %r11,%rax
    e97d:	4c 89 ca             	mov    %r9,%rdx
    e980:	49 f7 f2             	div    %r10
    e983:	49 89 c3             	mov    %rax,%r11
    e986:	31 c0                	xor    %eax,%eax
    e988:	48 89 d6             	mov    %rdx,%rsi
    e98b:	31 ff                	xor    %edi,%edi
    e98d:	4c 89 d9             	mov    %r11,%rcx
    e990:	48 89 c2             	mov    %rax,%rdx
    e993:	48 89 c8             	mov    %rcx,%rax
    e996:	4d 85 e4             	test   %r12,%r12
    e999:	74 0a                	je     e9a5 <__divmodti4+0x85>
    e99b:	48 f7 d8             	neg    %rax
    e99e:	48 83 d2 00          	adc    $0x0,%rdx
    e9a2:	48 f7 da             	neg    %rdx
    e9a5:	4d 85 c0             	test   %r8,%r8
    e9a8:	74 0a                	je     e9b4 <__divmodti4+0x94>
    e9aa:	48 f7 de             	neg    %rsi
    e9ad:	48 83 d7 00          	adc    $0x0,%rdi
    e9b1:	48 f7 df             	neg    %rdi
    e9b4:	48 89 33             	mov    %rsi,(%rbx)
    e9b7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e9bb:	5b                   	pop    %rbx
    e9bc:	41 5c                	pop    %r12
    e9be:	41 5d                	pop    %r13
    e9c0:	41 5e                	pop    %r14
    e9c2:	41 5f                	pop    %r15
    e9c4:	5d                   	pop    %rbp
    e9c5:	c3                   	ret
    e9c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e9cd:	00 00 00 
    e9d0:	4d 89 c4             	mov    %r8,%r12
    e9d3:	49 39 c1             	cmp    %rax,%r9
    e9d6:	0f 82 ce 00 00 00    	jb     eaaa <__divmodti4+0x18a>
    e9dc:	31 ff                	xor    %edi,%edi
    e9de:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e9e3:	48 63 c7             	movslq %edi,%rax
    e9e6:	be 40 00 00 00       	mov    $0x40,%esi
    e9eb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e9f0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e9f5:	48 29 c6             	sub    %rax,%rsi
    e9f8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e9fd:	48 09 c8             	or     %rcx,%rax
    ea00:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    ea05:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ea0a:	49 89 c6             	mov    %rax,%r14
    ea0d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ea11:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    ea16:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    ea1b:	49 09 c1             	or     %rax,%r9
    ea1e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    ea22:	4c 89 c8             	mov    %r9,%rax
    ea25:	49 f7 f6             	div    %r14
    ea28:	48 89 d1             	mov    %rdx,%rcx
    ea2b:	49 89 c3             	mov    %rax,%r11
    ea2e:	49 89 c1             	mov    %rax,%r9
    ea31:	49 f7 e2             	mul    %r10
    ea34:	49 89 c6             	mov    %rax,%r14
    ea37:	49 89 d2             	mov    %rdx,%r10
    ea3a:	48 39 d1             	cmp    %rdx,%rcx
    ea3d:	72 07                	jb     ea46 <__divmodti4+0x126>
    ea3f:	75 17                	jne    ea58 <__divmodti4+0x138>
    ea41:	49 39 c7             	cmp    %rax,%r15
    ea44:	73 12                	jae    ea58 <__divmodti4+0x138>
    ea46:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    ea4a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    ea4e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    ea52:	49 89 d2             	mov    %rdx,%r10
    ea55:	49 89 c6             	mov    %rax,%r14
    ea58:	4c 89 f8             	mov    %r15,%rax
    ea5b:	4c 29 f0             	sub    %r14,%rax
    ea5e:	4c 19 d1             	sbb    %r10,%rcx
    ea61:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ea66:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ea6b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ea70:	48 09 c6             	or     %rax,%rsi
    ea73:	48 89 cf             	mov    %rcx,%rdi
    ea76:	31 c0                	xor    %eax,%eax
    ea78:	4c 89 c9             	mov    %r9,%rcx
    ea7b:	e9 10 ff ff ff       	jmp    e990 <__divmodti4+0x70>
    ea80:	4c 89 d0             	mov    %r10,%rax
    ea83:	4c 89 da             	mov    %r11,%rdx
    ea86:	4d 89 c4             	mov    %r8,%r12
    ea89:	49 89 f3             	mov    %rsi,%r11
    ea8c:	48 f7 d8             	neg    %rax
    ea8f:	49 f7 d4             	not    %r12
    ea92:	48 83 d2 00          	adc    $0x0,%rdx
    ea96:	49 89 c2             	mov    %rax,%r10
    ea99:	48 f7 da             	neg    %rdx
    ea9c:	48 89 d1             	mov    %rdx,%rcx
    ea9f:	0f 84 cc fe ff ff    	je     e971 <__divmodti4+0x51>
    eaa5:	49 39 d1             	cmp    %rdx,%r9
    eaa8:	73 46                	jae    eaf0 <__divmodti4+0x1d0>
    eaaa:	4c 89 cf             	mov    %r9,%rdi
    eaad:	31 c0                	xor    %eax,%eax
    eaaf:	31 c9                	xor    %ecx,%ecx
    eab1:	e9 da fe ff ff       	jmp    e990 <__divmodti4+0x70>
    eab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    eabd:	00 00 00 
    eac0:	4d 85 d2             	test   %r10,%r10
    eac3:	75 0d                	jne    ead2 <__divmodti4+0x1b2>
    eac5:	b8 01 00 00 00       	mov    $0x1,%eax
    eaca:	31 d2                	xor    %edx,%edx
    eacc:	49 f7 f2             	div    %r10
    eacf:	49 89 c2             	mov    %rax,%r10
    ead2:	4c 89 c8             	mov    %r9,%rax
    ead5:	31 d2                	xor    %edx,%edx
    ead7:	49 f7 f2             	div    %r10
    eada:	49 89 c1             	mov    %rax,%r9
    eadd:	4c 89 d8             	mov    %r11,%rax
    eae0:	49 f7 f2             	div    %r10
    eae3:	49 89 c3             	mov    %rax,%r11
    eae6:	4c 89 c8             	mov    %r9,%rax
    eae9:	e9 9a fe ff ff       	jmp    e988 <__divmodti4+0x68>
    eaee:	66 90                	xchg   %ax,%ax
    eaf0:	45 31 f6             	xor    %r14d,%r14d
    eaf3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    eaf8:	44 89 f7             	mov    %r14d,%edi
    eafb:	45 85 f6             	test   %r14d,%r14d
    eafe:	0f 85 df fe ff ff    	jne    e9e3 <__divmodti4+0xc3>
    eb04:	4c 39 ca             	cmp    %r9,%rdx
    eb07:	72 17                	jb     eb20 <__divmodti4+0x200>
    eb09:	31 c9                	xor    %ecx,%ecx
    eb0b:	48 39 c6             	cmp    %rax,%rsi
    eb0e:	73 10                	jae    eb20 <__divmodti4+0x200>
    eb10:	4c 89 cf             	mov    %r9,%rdi
    eb13:	31 c0                	xor    %eax,%eax
    eb15:	e9 76 fe ff ff       	jmp    e990 <__divmodti4+0x70>
    eb1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    eb20:	4c 89 de             	mov    %r11,%rsi
    eb23:	b9 01 00 00 00       	mov    $0x1,%ecx
    eb28:	48 29 c6             	sub    %rax,%rsi
    eb2b:	49 19 d1             	sbb    %rdx,%r9
    eb2e:	eb e0                	jmp    eb10 <__divmodti4+0x1f0>

000000000000eb30 <atexit>:
    eb30:	f3 0f 1e fa          	endbr64
    eb34:	48 8b 15 cd 44 00 00 	mov    0x44cd(%rip),%rdx        # 13008 <__dso_handle>
    eb3b:	31 f6                	xor    %esi,%esi
    eb3d:	e9 1e 4b ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000eb44 <_fini>:
    eb44:	f3 0f 1e fa          	endbr64
    eb48:	48 83 ec 08          	sub    $0x8,%rsp
    eb4c:	48 83 c4 08          	add    $0x8,%rsp
    eb50:	c3                   	ret
