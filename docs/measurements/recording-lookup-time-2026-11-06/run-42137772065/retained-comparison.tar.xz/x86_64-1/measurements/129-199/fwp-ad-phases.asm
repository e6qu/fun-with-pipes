
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 db 00 00 	lea    0xdb81(%rip),%rax        # 11300 <fwp_fn_table>
    377f:	48 89 05 92 1c 02 00 	mov    %rax,0x21c92(%rip)        # 25418 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c 1c 02 00 	mov    %rax,0x21c8c(%rip)        # 25420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 af a1 00 00 	lea    0xa1af(%rip),%rdx        # da10 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 86 c1 00 00 	lea    0xc186(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 40 c1 00 00 	lea    0xc140(%rip),%rdi        # fa68 <_IO_stdin_used+0xa68>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 04 c1 00 00 	lea    0xc104(%rip),%rdi        # fa38 <_IO_stdin_used+0xa38>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d d0 c0 00 00 	lea    0xc0d0(%rip),%rdi        # fa10 <_IO_stdin_used+0xa10>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce f4 01 00 	add    0x1f4ce(%rip),%rdx        # 230f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc f4 01 00 	add    0x1f4bc(%rip),%rax        # 230f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 17 02 00 	mov    0x217a9(%rip),%rdi        # 25420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 f3 00 00 	mov    0xf394(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 f3 00 00 	mov    0xf381(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 f3 00 00 	mov    0xf372(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 fa 01 00 	mov    0x1faa1(%rip),%rax        # 237a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 f3 01 00 	mov    0x1f3d9(%rip),%rax        # 23158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 f3 01 00 	sub    0x1f3c5(%rip),%rax        # 23150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 87 b8 00 00 	lea    0xb887(%rip),%rdi        # f670 <_IO_stdin_used+0x670>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 f2 00 00 	mov    0xf242(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 f1 00 00 ff 	cmpl   $0xffffffff,0xf1e5(%rip)        # 13018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 f2 01 00 	mov    0x1f2c1(%rip),%r9        # 23108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c f2 01 00 	mov    0x1f29c(%rip),%r8        # 23100 <descent_inputs>
    3e64:	48 8b 0d a5 f2 01 00 	mov    0x1f2a5(%rip),%rcx        # 23110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 f1 00 00 	mov    0xf1c2(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 20 b8 00 00 	lea    0xb820(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 f2 01 00 	lea    0x1f271(%rip),%r12        # 23120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b f1 00 00 	mov    0xf15b(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 f1 00 00 	mov    0xf120(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 f0 00 00 	mov    0xf0f9(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b 0c 02 00 	mov    0x20c1b(%rip),%rax        # 24bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 0c 02 00 	lea    0x20c14(%rip),%r8        # 24bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 0b 02 00 	mov    0x20bf5(%rip),%rbx        # 24b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 0c 02 00 	mov    0x20c05(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 0b 02 00 	mov    0x20ba1(%rip),%rdi        # 24ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea 0b 02 00 	sub    %rsi,0x20bea(%rip)        # 24bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a 0b 02 00 	mov    0x20b7a(%rip),%rax        # 24b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 0b 02 00 	add    0x20b30(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e 0b 02 00 	mov    0x20b3e(%rip),%rsi        # 24ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c 0b 02 00 	mov    0x20b4c(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb 0a 02 00 	mov    %r12,0x20afb(%rip)        # 24ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 0a 02 00 	mov    %rbp,0x20ae9(%rip)        # 24b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce 0a 02 00 	cmp    %rdi,0x20ace(%rip)        # 24b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 0a 02 00 	mov    %rdi,0x20ac5(%rip)        # 24b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 0b 02 00 	sub    %rdi,0x20b09(%rip)        # 24bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 0a 02 00 	mov    0x20ab1(%rip),%rax        # 24ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa 0a 02 00 	lea    0x20aaa(%rip),%r8        # 24ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d ee 00 00 	mov    0xee5d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad ed 00 00 	movslq 0xedad(%rip),%rbp        # 13018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a ee 01 00 	mov    0x1ee7a(%rip),%rsi        # 23118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 ee 01 00 	lea    0x1ee76(%rip),%rcx        # 23120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b ee 01 00 	addq   $0x1,0x1ee4b(%rip)        # 23110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 ed 00 00    	mov    %ebx,0xed48(%rip)        # 13018 <descent_active_phase>
    42d0:	48 89 05 41 ee 01 00 	mov    %rax,0x1ee41(%rip)        # 23118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 f4 01 00 	cmp    0x1f499(%rip),%rdi        # 237a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f f4 01 00 	mov    0x1f45f(%rip),%rax        # 23780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d f4 01 00 	mov    %rdi,0x1f43d(%rip)        # 23780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 f4 01 00 	mov    %rdi,0x1f419(%rip)        # 23788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee ad 00 00 	lea    0xadee(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 ec 00 00 	mov    0xec28(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 ec 00 00 	mov    0xec10(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 eb 00 00 	mov    0xeb21(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 18 b1 00 00 	lea    0xb118(%rip),%rdi        # f708 <_IO_stdin_used+0x708>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 b0 b5 00 	movdqa 0xb5b0(%rip),%xmm0        # fbc0 <msg.4+0x50>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa 0d 02 00 	add    0x20daa(%rip),%rax        # 25418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 6c b0 00 00 	lea    0xb06c(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 ea 01 00 	cmp    %rax,0x1ea05(%rip)        # 230e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 ea 01 00 	add    0x1ea00(%rip),%rax        # 230f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 55 b0 00 00 	lea    0xb055(%rip),%rdi        # f760 <_IO_stdin_used+0x760>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 fe 01 00 	mov    0x1fe85(%rip),%r9        # 24b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de fe 01 00 	mov    0x1fede(%rip),%r8        # 24be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 9f aa 00 00 	lea    0xaa9f(%rip),%rdx        # f7b0 <_IO_stdin_used+0x7b0>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 fe 01 00 	mov    0x1fec6(%rip),%rcx        # 24be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 fe 01 	movsd  0x1fed4(%rip),%xmm1        # 24c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 fe 01 	movsd  0x1fec4(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 e3 00 00 	mov    0xe305(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 58 ae 00 	movdqa 0xae58(%rip),%xmm0        # fbd0 <msg.4+0x60>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f f9 01 00 	lea    0x1f97f(%rip),%rax        # 24700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 81 ae 00 	movdqa 0xae81(%rip),%xmm2        # fc10 <msg.4+0xa0>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 f9 01 00 	movaps %xmm0,0x1f925(%rip)        # 246c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 3d ae 00 	movdqa 0xae3d(%rip),%xmm0        # fbe0 <msg.4+0x70>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 fd 01 00 01 	movl   $0x1,0x1fdb3(%rip)        # 24b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 f9 01 00 	movaps %xmm0,0x1f913(%rip)        # 246d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 2b ae 00 	movdqa 0xae2b(%rip),%xmm0        # fbf0 <msg.4+0x80>
    4dc4:	00 
    4dc5:	0f 29 05 14 f9 01 00 	movaps %xmm0,0x1f914(%rip)        # 246e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 2c ae 00 	movdqa 0xae2c(%rip),%xmm0        # fc00 <msg.4+0x90>
    4dd3:	00 
    4dd4:	0f 29 05 15 f9 01 00 	movaps %xmm0,0x1f915(%rip)        # 246f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 e9 01 00 	lea    0x1e995(%rip),%r8        # 237c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 fc 01 00 	mov    %rax,0x1fcb0(%rip)        # 24b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e fc 01 00 	mov    %r12,0x1fc8e(%rip)        # 24b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 fc 01 00 	mov    %rax,0x1fc77(%rip)        # 24b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 fc 01 00 	mov    %rbx,0x1fc90(%rip)        # 24b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 fc 01 00 	mov    %rsi,0x1fcb9(%rip)        # 24bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 fc 01 00 	mov    %rax,0x1fc98(%rip)        # 24bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c fc 01 00    	mov    %eax,0x1fc1c(%rip)        # 24b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c e8 01 00 	mov    0x1e80c(%rip),%r8        # 23780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c e7 01 00 	mov    %rbx,0x1e73c(%rip)        # 23788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 e7 01 00 	mov    %r8,0x1e728(%rip)        # 23780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c a0 00 00 	lea    0xa05c(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d df 01 00 	lea    0x1df9d(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 df 01 00 	movaps %xmm0,0x1df85(%rip)        # 230a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 df 01 00 	mov    %rax,0x1df61(%rip)        # 23088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 df 01 00 	movaps %xmm0,0x1df82(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 df 01 00 	movaps %xmm0,0x1df86(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 df 01 00 	mov    %rdx,0x1df87(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 9f 00 00 	lea    0x9fb3(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 e5 01 00 	mov    0x1e5b7(%rip),%rbx        # 23778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a dd 00 00 	mov    0xdd8a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 7b a5 00 00 	lea    0xa57b(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d e4 01 00 	mov    0x1e48d(%rip),%rax        # 23780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 e4 01 00 	mov    %rdx,0x1e467(%rip)        # 23780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 e3 01 00 	mov    0x1e3b4(%rip),%rbx        # 23778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 e3 01 00 	mov    %rbx,0x1e371(%rip)        # 23778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 e3 01 00 	mov    %rdx,0x1e371(%rip)        # 23788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 e3 01 00 	lea    0x1e386(%rip),%rsi        # 237c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 ff 01 00 	addq   $0x1,0x1ff05(%rip)        # 25408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 4f a3 00 00 	lea    0xa34f(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 60 a3 00 00 	lea    0xa360(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 9b 00 00 	lea    0x9bf7(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e e2 01 00 	lea    0x1e23e(%rip),%rcx        # 237c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f fe 01 00 	subq   $0x1,0x1fe3f(%rip)        # 25408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d bb a2 00 00 	lea    0xa2bb(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 fe 01 00 	cmpq   $0x0,0x1fe20(%rip)        # 25408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 fd 01 00 	sub    %rax,0x1fd75(%rip)        # 25410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 fd 01 00 	add    %r12,0x1fd53(%rip)        # 25410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af f4 01 00 	mov    0x1f4af(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac e0 01 00 	lea    0x1e0ac(%rip),%rax        # 237c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 f4 01 00 	add    0x1f403(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 f3 01 00 	mov    0x1f3d0(%rip),%rsi        # 24b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 f3 01 00 	mov    0x1f3f1(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 f3 01 00 	add    0x1f3e5(%rip),%r8        # 24bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad f3 01 	addsd  0x1f3ad(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 df 01 00 	lea    0x1df62(%rip),%rax        # 237c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c f3 01 00 	sub    %rdi,0x1f36c(%rip)        # 24be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 f3 01 	movsd  %xmm0,0x1f384(%rip)        # 24c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e f3 01 00 	sub    %rdx,0x1f33e(%rip)        # 24be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 f3 01 	addsd  0x1f344(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 f3 01 	movsd  %xmm0,0x1f338(%rip)        # 24c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf f2 01 00 	mov    0x1f2cf(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 f2 01 00 	add    %rcx,0x1f2c9(%rip)        # 24bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 f2 01 00 	cmp    0x1f282(%rip),%r9        # 24bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 f2 01 00 	mov    %r9,0x1f279(%rip)        # 24bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a f2 01 00 	cmp    0x1f26a(%rip),%r9        # 24ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d f2 01 00 	mov    %r9,0x1f25d(%rip)        # 24ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 f1 01 00 	add    0x1f173(%rip),%rdi        # 24bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 dd 01 00 	lea    0x1dd50(%rip),%r15        # 237c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 f0 01 00 	add    0x1f0c0(%rip),%r12        # 24b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 f1 01 00 	add    0x1f119(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 f1 01 00 	cmp    %rax,0x1f118(%rip)        # 24be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 f1 01 00 	mov    %rax,0x1f109(%rip)        # 24be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 f1 01 00 	mov    %rax,0x1f108(%rip)        # 24be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 f1 01 	addsd  0x1f104(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc f0 01 	movsd  %xmm0,0x1f0fc(%rip)        # 24bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 f0 01 00    	mov    0x1f043(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f dc 01 00 	lea    0x1dc7f(%rip),%rdi        # 237c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 f0 01 00 	add    0x1f038(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 f0 01 00 	cmp    %rax,0x1f033(%rip)        # 24be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 f0 01 00 	mov    %rax,0x1f024(%rip)        # 24be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 f0 01 00 	mov    %rax,0x1f023(%rip)        # 24be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f f0 01 	addsd  0x1f01f(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 f0 01 	movsd  %xmm0,0x1f017(%rip)        # 24bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce ee 01 00    	mov    0x1eece(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 db 01 00 	lea    0x1db05(%rip),%rax        # 237c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb ee 01 00 	add    0x1eebb(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba ee 01 00 	cmp    %rax,0x1eeba(%rip)        # 24be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab ee 01 00 	mov    %rax,0x1eeab(%rip)        # 24be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa ee 01 00 	mov    %rax,0x1eeaa(%rip)        # 24be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 ee 01 	addsd  0x1eea6(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e ee 01 	movsd  %xmm0,0x1ee9e(%rip)        # 24bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_data.part.0.constprop.0>:
    5db0:	41 56                	push   %r14
    5db2:	41 89 fe             	mov    %edi,%r14d
    5db5:	41 54                	push   %r12
    5db7:	49 89 f4             	mov    %rsi,%r12
    5dba:	55                   	push   %rbp
    5dbb:	53                   	push   %rbx
    5dbc:	48 83 ec 08          	sub    $0x8,%rsp
    5dc0:	8b 05 9e ed 01 00    	mov    0x1ed9e(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5dc6:	85 c0                	test   %eax,%eax
    5dc8:	0f 84 fa 00 00 00    	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5dce:	0f b6 05 8d e9 01 00 	movzbl 0x1e98d(%rip),%eax        # 24762 <fwp_heap+0xfa2>
    5dd5:	48 8d 15 e4 d9 01 00 	lea    0x1d9e4(%rip),%rdx        # 237c0 <fwp_heap>
    5ddc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5de3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5de7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5deb:	48 8b 18             	mov    (%rax),%rbx
    5dee:	48 85 db             	test   %rbx,%rbx
    5df1:	0f 84 a9 00 00 00    	je     5ea0 <fwp_data.part.0.constprop.0+0xf0>
    5df7:	48 8b 13             	mov    (%rbx),%rdx
    5dfa:	48 f7 d2             	not    %rdx
    5dfd:	48 89 10             	mov    %rdx,(%rax)
    5e00:	48 83 fd 18          	cmp    $0x18,%rbp
    5e04:	76 1b                	jbe    5e21 <fwp_data.part.0.constprop.0+0x71>
    5e06:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e0a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e0e:	31 f6                	xor    %esi,%esi
    5e10:	48 c1 e8 03          	shr    $0x3,%rax
    5e14:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e1b:	00 
    5e1c:	e8 9f d6 ff ff       	call   34c0 <memset@plt>
    5e21:	48 89 e8             	mov    %rbp,%rax
    5e24:	48 03 05 b5 ed 01 00 	add    0x1edb5(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5e2b:	0f 82 a8 00 00 00    	jb     5ed9 <fwp_data.part.0.constprop.0+0x129>
    5e31:	48 39 05 b0 ed 01 00 	cmp    %rax,0x1edb0(%rip)        # 24be8 <fwp_heap+0x1428>
    5e38:	48 89 05 a1 ed 01 00 	mov    %rax,0x1eda1(%rip)        # 24be0 <fwp_heap+0x1420>
    5e3f:	73 07                	jae    5e48 <fwp_data.part.0.constprop.0+0x98>
    5e41:	48 89 05 a0 ed 01 00 	mov    %rax,0x1eda0(%rip)        # 24be8 <fwp_heap+0x1428>
    5e48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e4c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e51:	f2 0f 58 05 9f ed 01 	addsd  0x1ed9f(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 97 ed 01 	movsd  %xmm0,0x1ed97(%rip)        # 24bf8 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	b8 02 00 00 00       	mov    $0x2,%eax
    5e66:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e6b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e6f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e73:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e77:	49 8b 04 24          	mov    (%r12),%rax
    5e7b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e7f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e84:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e88:	48 83 c4 08          	add    $0x8,%rsp
    5e8c:	48 89 d8             	mov    %rbx,%rax
    5e8f:	5b                   	pop    %rbx
    5e90:	5d                   	pop    %rbp
    5e91:	41 5c                	pop    %r12
    5e93:	41 5e                	pop    %r14
    5e95:	c3                   	ret
    5e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e9d:	00 00 00 
    5ea0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5ea4:	48 85 db             	test   %rbx,%rbx
    5ea7:	74 1f                	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5ea9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ead:	48 29 da             	sub    %rbx,%rdx
    5eb0:	48 39 ea             	cmp    %rbp,%rdx
    5eb3:	72 13                	jb     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5eb5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5eb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ebd:	e9 3e ff ff ff       	jmp    5e00 <fwp_data.part.0.constprop.0+0x50>
    5ec2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ec8:	31 f6                	xor    %esi,%esi
    5eca:	bf 18 00 00 00       	mov    $0x18,%edi
    5ecf:	e8 bc fd ff ff       	call   5c90 <fwp_heap_alloc>
    5ed4:	48 89 c3             	mov    %rax,%rbx
    5ed7:	eb 88                	jmp    5e61 <fwp_data.part.0.constprop.0+0xb1>
    5ed9:	e8 d2 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5ede:	66 90                	xchg   %ax,%ax

0000000000005ee0 <fwp_p_ad_push>:
    5ee0:	41 57                	push   %r15
    5ee2:	41 56                	push   %r14
    5ee4:	41 55                	push   %r13
    5ee6:	49 89 d5             	mov    %rdx,%r13
    5ee9:	41 54                	push   %r12
    5eeb:	49 89 fc             	mov    %rdi,%r12
    5eee:	55                   	push   %rbp
    5eef:	53                   	push   %rbx
    5ef0:	48 83 ec 48          	sub    $0x48,%rsp
    5ef4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5ef9:	48 85 ff             	test   %rdi,%rdi
    5efc:	79 09                	jns    5f07 <fwp_p_ad_push+0x27>
    5efe:	48 85 d2             	test   %rdx,%rdx
    5f01:	0f 88 b9 02 00 00    	js     61c0 <fwp_p_ad_push+0x2e0>
    5f07:	48 89 f8             	mov    %rdi,%rax
    5f0a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f0e:	4c 89 c5             	mov    %r8,%rbp
    5f11:	48 09 d0             	or     %rdx,%rax
    5f14:	0f 89 7e 02 00 00    	jns    6198 <fwp_p_ad_push+0x2b8>
    5f1a:	48 85 ff             	test   %rdi,%rdi
    5f1d:	0f 89 e6 03 00 00    	jns    6309 <fwp_p_ad_push+0x429>
    5f23:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5f28:	49 89 d6             	mov    %rdx,%r14
    5f2b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5f32:	00 
    5f33:	49 89 d4             	mov    %rdx,%r12
    5f36:	49 c1 fe 20          	sar    $0x20,%r14
    5f3a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5f41:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5f47:	48 85 ed             	test   %rbp,%rbp
    5f4a:	0f 84 48 03 00 00    	je     6298 <fwp_p_ad_push+0x3b8>
    5f50:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    5f54:	0f 84 be 02 00 00    	je     6218 <fwp_p_ad_push+0x338>
    5f5a:	4c 89 f7             	mov    %r14,%rdi
    5f5d:	e8 6e e7 ff ff       	call   46d0 <fwp_tape_of>
    5f62:	48 89 c3             	mov    %rax,%rbx
    5f65:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5f6a:	0f 85 3e 03 00 00    	jne    62ae <fwp_p_ad_push+0x3ce>
    5f70:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    5f74:	48 89 45 08          	mov    %rax,0x8(%rbp)
    5f78:	4c 8b 43 10          	mov    0x10(%rbx),%r8
    5f7c:	49 81 f8 fe ff ff 7f 	cmp    $0x7ffffffe,%r8
    5f83:	0f 8f cd 03 00 00    	jg     6356 <fwp_p_ad_push+0x476>
    5f89:	44 89 e0             	mov    %r12d,%eax
    5f8c:	4c 39 c0             	cmp    %r8,%rax
    5f8f:	0f 8d b5 03 00 00    	jge    634a <fwp_p_ad_push+0x46a>
    5f95:	4d 85 ed             	test   %r13,%r13
    5f98:	78 0c                	js     5fa6 <fwp_p_ad_push+0xc6>
    5f9a:	44 89 e8             	mov    %r13d,%eax
    5f9d:	4c 39 c0             	cmp    %r8,%rax
    5fa0:	0f 8d a4 03 00 00    	jge    634a <fwp_p_ad_push+0x46a>
    5fa6:	4d 89 c7             	mov    %r8,%r15
    5fa9:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    5fad:	49 8d 47 01          	lea    0x1(%r15),%rax
    5fb1:	4c 89 f9             	mov    %r15,%rcx
    5fb4:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5fba:	0f 87 96 03 00 00    	ja     6356 <fwp_p_ad_push+0x476>
    5fc0:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5fc4:	48 39 e8             	cmp    %rbp,%rax
    5fc7:	0f 8e 23 02 00 00    	jle    61f0 <fwp_p_ad_push+0x310>
    5fcd:	48 85 ed             	test   %rbp,%rbp
    5fd0:	ba 40 00 00 00       	mov    $0x40,%edx
    5fd5:	48 0f 44 ea          	cmove  %rdx,%rbp
    5fd9:	48 39 e8             	cmp    %rbp,%rax
    5fdc:	7e 22                	jle    6000 <fwp_p_ad_push+0x120>
    5fde:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5fe5:	0f 8f f5 01 00 00    	jg     61e0 <fwp_p_ad_push+0x300>
    5feb:	48 01 ed             	add    %rbp,%rbp
    5fee:	48 39 e8             	cmp    %rbp,%rax
    5ff1:	7f eb                	jg     5fde <fwp_p_ad_push+0xfe>
    5ff3:	66 90                	xchg   %ax,%ax
    5ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ffc:	00 00 00 00 
    6000:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6007:	00 
    6008:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    600c:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6011:	48 89 c6             	mov    %rax,%rsi
    6014:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6019:	4c 8b 73 60          	mov    0x60(%rbx),%r14
    601d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6022:	e8 a9 d5 ff ff       	call   35d0 <realloc@plt>
    6027:	48 85 c0             	test   %rax,%rax
    602a:	0f 84 32 03 00 00    	je     6362 <fwp_p_ad_push+0x482>
    6030:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6034:	4d 85 f6             	test   %r14,%r14
    6037:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    603c:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6040:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6045:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    6049:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    604d:	0f 84 d5 01 00 00    	je     6228 <fwp_p_ad_push+0x348>
    6053:	49 8b 56 60          	mov    0x60(%r14),%rdx
    6057:	48 39 ea             	cmp    %rbp,%rdx
    605a:	0f 8d bb 00 00 00    	jge    611b <fwp_p_ad_push+0x23b>
    6060:	49 8b 76 40          	mov    0x40(%r14),%rsi
    6064:	48 89 ef             	mov    %rbp,%rdi
    6067:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    606c:	48 c1 e7 04          	shl    $0x4,%rdi
    6070:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    6075:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    607a:	be 02 00 00 00       	mov    $0x2,%esi
    607f:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    6084:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    6089:	e8 02 fc ff ff       	call   5c90 <fwp_heap_alloc>
    608e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6093:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    6098:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    609d:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    60a2:	48 85 f6             	test   %rsi,%rsi
    60a5:	74 31                	je     60d8 <fwp_p_ad_push+0x1f8>
    60a7:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    60ac:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    60b1:	48 c1 e2 04          	shl    $0x4,%rdx
    60b5:	48 39 fa             	cmp    %rdi,%rdx
    60b8:	48 0f 47 d7          	cmova  %rdi,%rdx
    60bc:	48 89 c7             	mov    %rax,%rdi
    60bf:	e8 dc d4 ff ff       	call   35a0 <memcpy@plt>
    60c4:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    60c9:	e8 c2 f6 ff ff       	call   5790 <fwp_mem_free>
    60ce:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    60d3:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    60d8:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    60dc:	48 89 ea             	mov    %rbp,%rdx
    60df:	31 f6                	xor    %esi,%esi
    60e1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    60e6:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    60eb:	48 29 fa             	sub    %rdi,%rdx
    60ee:	48 c1 e7 04          	shl    $0x4,%rdi
    60f2:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    60f7:	48 c1 e2 04          	shl    $0x4,%rdx
    60fb:	e8 c0 d3 ff ff       	call   34c0 <memset@plt>
    6100:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6105:	49 89 6e 60          	mov    %rbp,0x60(%r14)
    6109:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    610e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6113:	49 89 46 40          	mov    %rax,0x40(%r14)
    6117:	48 8b 43 20          	mov    0x20(%rbx),%rax
    611b:	4d 85 ff             	test   %r15,%r15
    611e:	0f 85 9c 01 00 00    	jne    62c0 <fwp_p_ad_push+0x3e0>
    6124:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6128:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    612c:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6133:	00 
    6134:	49 01 c6             	add    %rax,%r14
    6137:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    613b:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    613f:	46 89 24 38          	mov    %r12d,(%rax,%r15,1)
    6143:	4d 85 ed             	test   %r13,%r13
    6146:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    614c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6153:	4c 0f 48 e8          	cmovs  %rax,%r13
    6157:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    615c:	49 8d 40 01          	lea    0x1(%r8),%rax
    6160:	f2 0f 11 0c 0a       	movsd  %xmm1,(%rdx,%rcx,1)
    6165:	47 89 2c 3e          	mov    %r13d,(%r14,%r15,1)
    6169:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    616e:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6172:	48 83 c4 48          	add    $0x48,%rsp
    6176:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    617d:	ff ff ff 
    6180:	4c 21 e0             	and    %r12,%rax
    6183:	5b                   	pop    %rbx
    6184:	5d                   	pop    %rbp
    6185:	4c 09 c0             	or     %r8,%rax
    6188:	41 5c                	pop    %r12
    618a:	41 5d                	pop    %r13
    618c:	41 5e                	pop    %r14
    618e:	41 5f                	pop    %r15
    6190:	c3                   	ret
    6191:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6198:	48 c1 fa 20          	sar    $0x20,%rdx
    619c:	48 c1 ff 20          	sar    $0x20,%rdi
    61a0:	49 89 d6             	mov    %rdx,%r14
    61a3:	48 39 d7             	cmp    %rdx,%rdi
    61a6:	0f 84 9b fd ff ff    	je     5f47 <fwp_p_ad_push+0x67>
    61ac:	48 8d 3d 05 97 00 00 	lea    0x9705(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    61b3:	e8 38 e2 ff ff       	call   43f0 <fwp_trap>
    61b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61bf:	00 
    61c0:	48 83 c4 48          	add    $0x48,%rsp
    61c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    61cb:	5b                   	pop    %rbx
    61cc:	5d                   	pop    %rbp
    61cd:	41 5c                	pop    %r12
    61cf:	41 5d                	pop    %r13
    61d1:	41 5e                	pop    %r14
    61d3:	41 5f                	pop    %r15
    61d5:	c3                   	ret
    61d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    61dd:	00 00 00 
    61e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    61e5:	e9 16 fe ff ff       	jmp    6000 <fwp_p_ad_push+0x120>
    61ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61f0:	48 8b 43 20          	mov    0x20(%rbx),%rax
    61f4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    61f8:	48 c1 e1 03          	shl    $0x3,%rcx
    61fc:	4e 8d 3c bd 00 00 00 	lea    0x0(,%r15,4),%r15
    6203:	00 
    6204:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6208:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    620c:	e9 2e ff ff ff       	jmp    613f <fwp_p_ad_push+0x25f>
    6211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6218:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    621c:	e9 57 fd ff ff       	jmp    5f78 <fwp_p_ad_push+0x98>
    6221:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6228:	49 89 ee             	mov    %rbp,%r14
    622b:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    622f:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6234:	49 c1 e6 04          	shl    $0x4,%r14
    6238:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    623d:	4c 89 f6             	mov    %r14,%rsi
    6240:	e8 8b d3 ff ff       	call   35d0 <realloc@plt>
    6245:	48 89 c2             	mov    %rax,%rdx
    6248:	48 85 c0             	test   %rax,%rax
    624b:	0f 84 11 01 00 00    	je     6362 <fwp_p_ad_push+0x482>
    6251:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6255:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6259:	4d 85 ff             	test   %r15,%r15
    625c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6261:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6266:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    626a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    626f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6273:	48 8d 3c 02          	lea    (%rdx,%rax,1),%rdi
    6277:	0f 85 98 00 00 00    	jne    6315 <fwp_p_ad_push+0x435>
    627d:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6281:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6285:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    628c:	00 
    628d:	45 31 ff             	xor    %r15d,%r15d
    6290:	e9 9f fe ff ff       	jmp    6134 <fwp_p_ad_push+0x254>
    6295:	0f 1f 00             	nopl   (%rax)
    6298:	4c 89 f7             	mov    %r14,%rdi
    629b:	e8 30 e4 ff ff       	call   46d0 <fwp_tape_of>
    62a0:	48 89 c3             	mov    %rax,%rbx
    62a3:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    62a8:	0f 84 ca fc ff ff    	je     5f78 <fwp_p_ad_push+0x98>
    62ae:	48 8d 3d 4b 96 00 00 	lea    0x964b(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    62b5:	e8 36 e1 ff ff       	call   43f0 <fwp_trap>
    62ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    62c0:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
    62c7:	00 
    62c8:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    62cd:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    62d1:	49 c1 e7 02          	shl    $0x2,%r15
    62d5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    62da:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    62e1:	00 
    62e2:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    62e6:	4c 89 fa             	mov    %r15,%rdx
    62e9:	e8 22 d3 ff ff       	call   3610 <memmove@plt>
    62ee:	48 8b 43 20          	mov    0x20(%rbx),%rax
    62f2:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    62f6:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    62fa:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    62ff:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6304:	e9 2b fe ff ff       	jmp    6134 <fwp_p_ad_push+0x254>
    6309:	48 c1 ff 20          	sar    $0x20,%rdi
    630d:	49 89 fe             	mov    %rdi,%r14
    6310:	e9 32 fc ff ff       	jmp    5f47 <fwp_p_ad_push+0x67>
    6315:	4c 39 f0             	cmp    %r14,%rax
    6318:	4c 89 f1             	mov    %r14,%rcx
    631b:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
    6322:	00 
    6323:	49 89 c6             	mov    %rax,%r14
    6326:	48 0f 43 c8          	cmovae %rax,%rcx
    632a:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    632f:	48 29 c1             	sub    %rax,%rcx
    6332:	e8 29 d2 ff ff       	call   3560 <__memmove_chk@plt>
    6337:	4c 03 73 30          	add    0x30(%rbx),%r14
    633b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    633f:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6343:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6348:	eb 83                	jmp    62cd <fwp_p_ad_push+0x3ed>
    634a:	48 8d 3d 16 8e 00 00 	lea    0x8e16(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    6351:	e8 9a e0 ff ff       	call   43f0 <fwp_trap>
    6356:	48 8d 3d ef 8d 00 00 	lea    0x8def(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    635d:	e8 8e e0 ff ff       	call   43f0 <fwp_trap>
    6362:	48 89 df             	mov    %rbx,%rdi
    6365:	e8 96 d8 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    636a:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    636e:	e8 4d d0 ff ff       	call   33c0 <free@plt>
    6373:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6377:	e8 44 d0 ff ff       	call   33c0 <free@plt>
    637c:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6380:	e8 3b d0 ff ff       	call   33c0 <free@plt>
    6385:	31 c9                	xor    %ecx,%ecx
    6387:	31 c0                	xor    %eax,%eax
    6389:	31 d2                	xor    %edx,%edx
    638b:	89 53 04             	mov    %edx,0x4(%rbx)
    638e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6392:	ba 13 00 00 00       	mov    $0x13,%edx
    6397:	be 01 00 00 00       	mov    $0x1,%esi
    639c:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    63a0:	48 8d 3d 61 8c 00 00 	lea    0x8c61(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    63a7:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    63ab:	48 8b 0d 8e cc 00 00 	mov    0xcc8e(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    63b2:	48 89 43 40          	mov    %rax,0x40(%rbx)
    63b6:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    63ba:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    63be:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    63c2:	e8 b9 d2 ff ff       	call   3680 <fwrite@plt>
    63c7:	31 ff                	xor    %edi,%edi
    63c9:	e8 f2 d1 ff ff       	call   35c0 <fflush@plt>
    63ce:	bf 66 00 00 00       	mov    $0x66,%edi
    63d3:	e8 c8 d2 ff ff       	call   36a0 <_Exit@plt>
    63d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    63df:	00 

00000000000063e0 <w120>:
    63e0:	41 56                	push   %r14
    63e2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    63e6:	48 89 fa             	mov    %rdi,%rdx
    63e9:	41 55                	push   %r13
    63eb:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    63ef:	49 89 fd             	mov    %rdi,%r13
    63f2:	41 54                	push   %r12
    63f4:	55                   	push   %rbp
    63f5:	53                   	push   %rbx
    63f6:	48 83 ec 40          	sub    $0x40,%rsp
    63fa:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6400:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6405:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    640c:	00 00 
    640e:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    6413:	48 89 f5             	mov    %rsi,%rbp
    6416:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    641b:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6421:	48 89 f1             	mov    %rsi,%rcx
    6424:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    642a:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    6431:	ff ff 
    6433:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    643a:	00 00 
    643c:	e8 9f fa ff ff       	call   5ee0 <fwp_p_ad_push>
    6441:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6447:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    644c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6452:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6459:	00 f0 3f 
    645c:	48 89 c7             	mov    %rax,%rdi
    645f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6466:	00 f0 bf 
    6469:	48 89 ea             	mov    %rbp,%rdx
    646c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6471:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6477:	e8 64 fa ff ff       	call   5ee0 <fwp_p_ad_push>
    647c:	f2 0f 10 05 14 97 00 	movsd  0x9714(%rip),%xmm0        # fb98 <msg.4+0x28>
    6483:	00 
    6484:	4c 89 ef             	mov    %r13,%rdi
    6487:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    648d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6492:	49 89 c6             	mov    %rax,%r14
    6495:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    649c:	00 f0 3f 
    649f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    64a6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    64ad:	00 f0 bf 
    64b0:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    64b5:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    64bb:	e8 20 fa ff ff       	call   5ee0 <fwp_p_ad_push>
    64c0:	4c 89 e1             	mov    %r12,%rcx
    64c3:	4c 89 e6             	mov    %r12,%rsi
    64c6:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    64cb:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    64d1:	4c 89 f2             	mov    %r14,%rdx
    64d4:	4c 89 f7             	mov    %r14,%rdi
    64d7:	49 89 c5             	mov    %rax,%r13
    64da:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    64de:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    64e4:	e8 f7 f9 ff ff       	call   5ee0 <fwp_p_ad_push>
    64e9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    64ef:	f2 0f 59 1d a9 96 00 	mulsd  0x96a9(%rip),%xmm3        # fba0 <msg.4+0x30>
    64f6:	00 
    64f7:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    64fc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6501:	48 89 c2             	mov    %rax,%rdx
    6504:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    650b:	00 59 40 
    650e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6515:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    651b:	e8 c0 f9 ff ff       	call   5ee0 <fwp_p_ad_push>
    6520:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6525:	48 89 e9             	mov    %rbp,%rcx
    6528:	4c 89 ea             	mov    %r13,%rdx
    652b:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6531:	48 89 ee             	mov    %rbp,%rsi
    6534:	4c 89 ef             	mov    %r13,%rdi
    6537:	49 89 c4             	mov    %rax,%r12
    653a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    653e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6544:	e8 97 f9 ff ff       	call   5ee0 <fwp_p_ad_push>
    6549:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    654f:	45 31 c0             	xor    %r8d,%r8d
    6552:	4c 89 e2             	mov    %r12,%rdx
    6555:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    655b:	48 89 c7             	mov    %rax,%rdi
    655e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6565:	00 f0 3f 
    6568:	48 89 ce             	mov    %rcx,%rsi
    656b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6570:	e8 6b f9 ff ff       	call   5ee0 <fwp_p_ad_push>
    6575:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    657a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6581:	00 00 
    6583:	75 12                	jne    6597 <w120+0x1b7>
    6585:	48 83 c4 40          	add    $0x40,%rsp
    6589:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    658e:	5b                   	pop    %rbx
    658f:	5d                   	pop    %rbp
    6590:	41 5c                	pop    %r12
    6592:	41 5d                	pop    %r13
    6594:	41 5e                	pop    %r14
    6596:	c3                   	ret
    6597:	e8 c4 ce ff ff       	call   3460 <__stack_chk_fail@plt>
    659c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000065a0 <w176.constprop.0>:
    65a0:	41 54                	push   %r12
    65a2:	55                   	push   %rbp
    65a3:	53                   	push   %rbx
    65a4:	48 83 ec 10          	sub    $0x10,%rsp
    65a8:	4c 8b 27             	mov    (%rdi),%r12
    65ab:	4d 85 e4             	test   %r12,%r12
    65ae:	74 58                	je     6608 <w176.constprop.0+0x68>
    65b0:	48 89 fd             	mov    %rdi,%rbp
    65b3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    65b7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    65be:	31 db                	xor    %ebx,%ebx
    65c0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    65c6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    65cb:	45 31 c0             	xor    %r8d,%r8d
    65ce:	48 83 c3 02          	add    $0x2,%rbx
    65d2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    65d9:	00 f0 3f 
    65dc:	48 89 ce             	mov    %rcx,%rsi
    65df:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    65e5:	e8 f6 f8 ff ff       	call   5ee0 <fwp_p_ad_push>
    65ea:	4c 39 e3             	cmp    %r12,%rbx
    65ed:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    65f3:	48 89 c7             	mov    %rax,%rdi
    65f6:	72 c8                	jb     65c0 <w176.constprop.0+0x20>
    65f8:	48 83 c4 10          	add    $0x10,%rsp
    65fc:	48 89 f8             	mov    %rdi,%rax
    65ff:	5b                   	pop    %rbx
    6600:	5d                   	pop    %rbp
    6601:	41 5c                	pop    %r12
    6603:	c3                   	ret
    6604:	0f 1f 40 00          	nopl   0x0(%rax)
    6608:	48 83 c4 10          	add    $0x10,%rsp
    660c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6613:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6617:	5b                   	pop    %rbx
    6618:	48 89 f8             	mov    %rdi,%rax
    661b:	5d                   	pop    %rbp
    661c:	41 5c                	pop    %r12
    661e:	c3                   	ret
    661f:	90                   	nop

0000000000006620 <fwp_rc_share>:
    6620:	48 8b 05 71 e5 01 00 	mov    0x1e571(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    6627:	48 2b 3d 42 e5 01 00 	sub    0x1e542(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    662e:	48 c1 e0 10          	shl    $0x10,%rax
    6632:	48 39 c7             	cmp    %rax,%rdi
    6635:	73 4a                	jae    6681 <fwp_rc_share+0x61>
    6637:	48 89 f8             	mov    %rdi,%rax
    663a:	48 c1 e8 10          	shr    $0x10,%rax
    663e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6642:	48 8b 05 6f e5 01 00 	mov    0x1e56f(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    6649:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    664d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6651:	48 85 d2             	test   %rdx,%rdx
    6654:	74 2b                	je     6681 <fwp_rc_share+0x61>
    6656:	0f b6 08             	movzbl (%rax),%ecx
    6659:	80 f9 02             	cmp    $0x2,%cl
    665c:	74 2a                	je     6688 <fwp_rc_share+0x68>
    665e:	80 f9 01             	cmp    $0x1,%cl
    6661:	75 1e                	jne    6681 <fwp_rc_share+0x61>
    6663:	8b 48 18             	mov    0x18(%rax),%ecx
    6666:	0f b7 ff             	movzwl %di,%edi
    6669:	8b 40 1c             	mov    0x1c(%rax),%eax
    666c:	48 0f af f9          	imul   %rcx,%rdi
    6670:	48 c1 ef 20          	shr    $0x20,%rdi
    6674:	48 39 c7             	cmp    %rax,%rdi
    6677:	73 08                	jae    6681 <fwp_rc_share+0x61>
    6679:	48 01 fa             	add    %rdi,%rdx
    667c:	80 3a 00             	cmpb   $0x0,(%rdx)
    667f:	75 0d                	jne    668e <fwp_rc_share+0x6e>
    6681:	c3                   	ret
    6682:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6688:	66 85 ff             	test   %di,%di
    668b:	74 ef                	je     667c <fwp_rc_share+0x5c>
    668d:	c3                   	ret
    668e:	50                   	push   %rax
    668f:	48 8d 3d 9a 92 00 00 	lea    0x929a(%rip),%rdi        # f930 <_IO_stdin_used+0x930>
    6696:	e8 55 dd ff ff       	call   43f0 <fwp_trap>
    669b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000066a0 <fwp_rc_fresh>:
    66a0:	48 8b 15 f1 e4 01 00 	mov    0x1e4f1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    66a7:	48 89 f8             	mov    %rdi,%rax
    66aa:	48 89 fe             	mov    %rdi,%rsi
    66ad:	48 2b 05 bc e4 01 00 	sub    0x1e4bc(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    66b4:	48 c1 e2 10          	shl    $0x10,%rdx
    66b8:	48 39 d0             	cmp    %rdx,%rax
    66bb:	73 4f                	jae    670c <fwp_rc_fresh+0x6c>
    66bd:	48 89 c2             	mov    %rax,%rdx
    66c0:	48 c1 ea 10          	shr    $0x10,%rdx
    66c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66c8:	48 8b 15 e9 e4 01 00 	mov    0x1e4e9(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    66cf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    66d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    66d7:	48 85 d2             	test   %rdx,%rdx
    66da:	74 30                	je     670c <fwp_rc_fresh+0x6c>
    66dc:	0f b6 39             	movzbl (%rcx),%edi
    66df:	40 80 ff 02          	cmp    $0x2,%dil
    66e3:	74 2b                	je     6710 <fwp_rc_fresh+0x70>
    66e5:	40 80 ff 01          	cmp    $0x1,%dil
    66e9:	75 21                	jne    670c <fwp_rc_fresh+0x6c>
    66eb:	8b 79 18             	mov    0x18(%rcx),%edi
    66ee:	0f b7 c0             	movzwl %ax,%eax
    66f1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    66f4:	48 0f af c7          	imul   %rdi,%rax
    66f8:	48 c1 e8 20          	shr    $0x20,%rax
    66fc:	48 39 c8             	cmp    %rcx,%rax
    66ff:	73 0b                	jae    670c <fwp_rc_fresh+0x6c>
    6701:	48 01 c2             	add    %rax,%rdx
    6704:	80 3a ff             	cmpb   $0xff,(%rdx)
    6707:	74 17                	je     6720 <fwp_rc_fresh+0x80>
    6709:	c6 02 01             	movb   $0x1,(%rdx)
    670c:	48 89 f0             	mov    %rsi,%rax
    670f:	c3                   	ret
    6710:	66 85 c0             	test   %ax,%ax
    6713:	74 ef                	je     6704 <fwp_rc_fresh+0x64>
    6715:	48 89 f0             	mov    %rsi,%rax
    6718:	c3                   	ret
    6719:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6720:	48 83 ec 18          	sub    $0x18,%rsp
    6724:	48 89 d7             	mov    %rdx,%rdi
    6727:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    672c:	48 89 14 24          	mov    %rdx,(%rsp)
    6730:	e8 1b ee ff ff       	call   5550 <fwp_rc_forget_slot>
    6735:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    673a:	48 8b 14 24          	mov    (%rsp),%rdx
    673e:	48 89 f0             	mov    %rsi,%rax
    6741:	c6 02 01             	movb   $0x1,(%rdx)
    6744:	48 83 c4 18          	add    $0x18,%rsp
    6748:	c3                   	ret
    6749:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006750 <fwp_rc_free_obj>:
    6750:	48 8b 15 41 e4 01 00 	mov    0x1e441(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6757:	48 89 f8             	mov    %rdi,%rax
    675a:	48 2b 05 0f e4 01 00 	sub    0x1e40f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6761:	48 c1 e2 10          	shl    $0x10,%rdx
    6765:	48 39 d0             	cmp    %rdx,%rax
    6768:	73 5b                	jae    67c5 <fwp_rc_free_obj+0x75>
    676a:	48 89 c2             	mov    %rax,%rdx
    676d:	48 c1 ea 10          	shr    $0x10,%rdx
    6771:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6775:	48 8b 15 3c e4 01 00 	mov    0x1e43c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    677c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6780:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6784:	48 85 c9             	test   %rcx,%rcx
    6787:	74 3c                	je     67c5 <fwp_rc_free_obj+0x75>
    6789:	0f b6 32             	movzbl (%rdx),%esi
    678c:	40 80 fe 02          	cmp    $0x2,%sil
    6790:	74 2e                	je     67c0 <fwp_rc_free_obj+0x70>
    6792:	40 80 fe 01          	cmp    $0x1,%sil
    6796:	75 2d                	jne    67c5 <fwp_rc_free_obj+0x75>
    6798:	8b 72 18             	mov    0x18(%rdx),%esi
    679b:	0f b7 c0             	movzwl %ax,%eax
    679e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    67a1:	48 0f af c6          	imul   %rsi,%rax
    67a5:	48 c1 e8 20          	shr    $0x20,%rax
    67a9:	48 39 d0             	cmp    %rdx,%rax
    67ac:	73 17                	jae    67c5 <fwp_rc_free_obj+0x75>
    67ae:	48 01 c1             	add    %rax,%rcx
    67b1:	80 39 01             	cmpb   $0x1,(%rcx)
    67b4:	75 0f                	jne    67c5 <fwp_rc_free_obj+0x75>
    67b6:	e9 d5 ef ff ff       	jmp    5790 <fwp_mem_free>
    67bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    67c0:	66 85 c0             	test   %ax,%ax
    67c3:	74 ec                	je     67b1 <fwp_rc_free_obj+0x61>
    67c5:	c3                   	ret
    67c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67cd:	00 00 00 

00000000000067d0 <fwp_rc_dup>:
    67d0:	f3 0f 1e fa          	endbr64
    67d4:	48 8b 05 bd e3 01 00 	mov    0x1e3bd(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    67db:	48 2b 3d 8e e3 01 00 	sub    0x1e38e(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    67e2:	48 c1 e0 10          	shl    $0x10,%rax
    67e6:	48 39 c7             	cmp    %rax,%rdi
    67e9:	73 56                	jae    6841 <fwp_rc_dup+0x71>
    67eb:	48 89 f8             	mov    %rdi,%rax
    67ee:	48 c1 e8 10          	shr    $0x10,%rax
    67f2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    67f6:	48 8b 05 bb e3 01 00 	mov    0x1e3bb(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    67fd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6801:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6805:	48 85 c0             	test   %rax,%rax
    6808:	74 37                	je     6841 <fwp_rc_dup+0x71>
    680a:	0f b6 0a             	movzbl (%rdx),%ecx
    680d:	80 f9 02             	cmp    $0x2,%cl
    6810:	74 36                	je     6848 <fwp_rc_dup+0x78>
    6812:	80 f9 01             	cmp    $0x1,%cl
    6815:	75 2a                	jne    6841 <fwp_rc_dup+0x71>
    6817:	8b 4a 18             	mov    0x18(%rdx),%ecx
    681a:	0f b7 ff             	movzwl %di,%edi
    681d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6820:	48 0f af f9          	imul   %rcx,%rdi
    6824:	48 c1 ef 20          	shr    $0x20,%rdi
    6828:	48 39 d7             	cmp    %rdx,%rdi
    682b:	73 14                	jae    6841 <fwp_rc_dup+0x71>
    682d:	48 01 f8             	add    %rdi,%rax
    6830:	0f b6 10             	movzbl (%rax),%edx
    6833:	84 d2                	test   %dl,%dl
    6835:	74 0a                	je     6841 <fwp_rc_dup+0x71>
    6837:	80 fa fd             	cmp    $0xfd,%dl
    683a:	77 14                	ja     6850 <fwp_rc_dup+0x80>
    683c:	83 c2 01             	add    $0x1,%edx
    683f:	88 10                	mov    %dl,(%rax)
    6841:	c3                   	ret
    6842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6848:	66 85 ff             	test   %di,%di
    684b:	74 e3                	je     6830 <fwp_rc_dup+0x60>
    684d:	c3                   	ret
    684e:	66 90                	xchg   %ax,%ax
    6850:	48 89 c7             	mov    %rax,%rdi
    6853:	e9 d8 eb ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    685f:	00 

0000000000006860 <fwp_owned_entry173>:
    6860:	f3 0f 1e fa          	endbr64
    6864:	48 83 ec 38          	sub    $0x38,%rsp
    6868:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    686d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6874:	00 00 
    6876:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    687b:	31 c0                	xor    %eax,%eax
    687d:	48 8b 07             	mov    (%rdi),%rax
    6880:	48 03 47 10          	add    0x10(%rdi),%rax
    6884:	0f 80 c2 00 00 00    	jo     694c <fwp_owned_entry173+0xec>
    688a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    688f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6894:	31 ff                	xor    %edi,%edi
    6896:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    689a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    689f:	e8 0c f5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    68a4:	48 8b 15 ed e2 01 00 	mov    0x1e2ed(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    68ab:	48 89 c6             	mov    %rax,%rsi
    68ae:	48 2b 05 bb e2 01 00 	sub    0x1e2bb(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    68b5:	48 c1 e2 10          	shl    $0x10,%rdx
    68b9:	48 39 d0             	cmp    %rdx,%rax
    68bc:	73 4f                	jae    690d <fwp_owned_entry173+0xad>
    68be:	48 89 c2             	mov    %rax,%rdx
    68c1:	48 c1 ea 10          	shr    $0x10,%rdx
    68c5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68c9:	48 8b 15 e8 e2 01 00 	mov    0x1e2e8(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    68d0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    68d4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    68d8:	48 85 d2             	test   %rdx,%rdx
    68db:	74 30                	je     690d <fwp_owned_entry173+0xad>
    68dd:	0f b6 39             	movzbl (%rcx),%edi
    68e0:	40 80 ff 02          	cmp    $0x2,%dil
    68e4:	74 42                	je     6928 <fwp_owned_entry173+0xc8>
    68e6:	40 80 ff 01          	cmp    $0x1,%dil
    68ea:	75 21                	jne    690d <fwp_owned_entry173+0xad>
    68ec:	8b 79 18             	mov    0x18(%rcx),%edi
    68ef:	0f b7 c0             	movzwl %ax,%eax
    68f2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68f5:	48 0f af c7          	imul   %rdi,%rax
    68f9:	48 c1 e8 20          	shr    $0x20,%rax
    68fd:	48 39 c8             	cmp    %rcx,%rax
    6900:	73 0b                	jae    690d <fwp_owned_entry173+0xad>
    6902:	48 01 c2             	add    %rax,%rdx
    6905:	80 3a ff             	cmpb   $0xff,(%rdx)
    6908:	74 26                	je     6930 <fwp_owned_entry173+0xd0>
    690a:	c6 02 01             	movb   $0x1,(%rdx)
    690d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6912:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6919:	00 00 
    691b:	75 34                	jne    6951 <fwp_owned_entry173+0xf1>
    691d:	48 89 f0             	mov    %rsi,%rax
    6920:	48 83 c4 38          	add    $0x38,%rsp
    6924:	c3                   	ret
    6925:	0f 1f 00             	nopl   (%rax)
    6928:	66 85 c0             	test   %ax,%ax
    692b:	75 e0                	jne    690d <fwp_owned_entry173+0xad>
    692d:	eb d6                	jmp    6905 <fwp_owned_entry173+0xa5>
    692f:	90                   	nop
    6930:	48 89 d7             	mov    %rdx,%rdi
    6933:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6938:	48 89 14 24          	mov    %rdx,(%rsp)
    693c:	e8 0f ec ff ff       	call   5550 <fwp_rc_forget_slot>
    6941:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6946:	48 8b 14 24          	mov    (%rsp),%rdx
    694a:	eb be                	jmp    690a <fwp_owned_entry173+0xaa>
    694c:	e8 af cd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6951:	e8 0a cb ff ff       	call   3460 <__stack_chk_fail@plt>
    6956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    695d:	00 00 00 

0000000000006960 <e173>:
    6960:	f3 0f 1e fa          	endbr64
    6964:	53                   	push   %rbx
    6965:	48 83 ec 30          	sub    $0x30,%rsp
    6969:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    696e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6975:	00 00 
    6977:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    697c:	31 c0                	xor    %eax,%eax
    697e:	48 8b 07             	mov    (%rdi),%rax
    6981:	48 03 47 10          	add    0x10(%rdi),%rax
    6985:	0f 80 c9 00 00 00    	jo     6a54 <e173+0xf4>
    698b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6990:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6995:	31 ff                	xor    %edi,%edi
    6997:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    699b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    69a0:	e8 0b f4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    69a5:	48 8b 15 ec e1 01 00 	mov    0x1e1ec(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    69ac:	48 89 c3             	mov    %rax,%rbx
    69af:	48 2b 05 ba e1 01 00 	sub    0x1e1ba(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    69b6:	48 c1 e2 10          	shl    $0x10,%rdx
    69ba:	48 39 d0             	cmp    %rdx,%rax
    69bd:	73 4f                	jae    6a0e <e173+0xae>
    69bf:	48 89 c2             	mov    %rax,%rdx
    69c2:	48 c1 ea 10          	shr    $0x10,%rdx
    69c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69ca:	48 8b 15 e7 e1 01 00 	mov    0x1e1e7(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    69d1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    69d5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    69d9:	48 85 d2             	test   %rdx,%rdx
    69dc:	74 30                	je     6a0e <e173+0xae>
    69de:	0f b6 31             	movzbl (%rcx),%esi
    69e1:	40 80 fe 02          	cmp    $0x2,%sil
    69e5:	74 49                	je     6a30 <e173+0xd0>
    69e7:	40 80 fe 01          	cmp    $0x1,%sil
    69eb:	75 21                	jne    6a0e <e173+0xae>
    69ed:	8b 71 18             	mov    0x18(%rcx),%esi
    69f0:	0f b7 c0             	movzwl %ax,%eax
    69f3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69f6:	48 0f af c6          	imul   %rsi,%rax
    69fa:	48 c1 e8 20          	shr    $0x20,%rax
    69fe:	48 39 c8             	cmp    %rcx,%rax
    6a01:	73 0b                	jae    6a0e <e173+0xae>
    6a03:	48 01 c2             	add    %rax,%rdx
    6a06:	80 3a ff             	cmpb   $0xff,(%rdx)
    6a09:	74 35                	je     6a40 <e173+0xe0>
    6a0b:	c6 02 01             	movb   $0x1,(%rdx)
    6a0e:	48 89 df             	mov    %rbx,%rdi
    6a11:	e8 0a fc ff ff       	call   6620 <fwp_rc_share>
    6a16:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6a1b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a22:	00 00 
    6a24:	75 33                	jne    6a59 <e173+0xf9>
    6a26:	48 83 c4 30          	add    $0x30,%rsp
    6a2a:	48 89 d8             	mov    %rbx,%rax
    6a2d:	5b                   	pop    %rbx
    6a2e:	c3                   	ret
    6a2f:	90                   	nop
    6a30:	66 85 c0             	test   %ax,%ax
    6a33:	75 d9                	jne    6a0e <e173+0xae>
    6a35:	eb cf                	jmp    6a06 <e173+0xa6>
    6a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a3e:	00 00 
    6a40:	48 89 d7             	mov    %rdx,%rdi
    6a43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6a48:	e8 03 eb ff ff       	call   5550 <fwp_rc_forget_slot>
    6a4d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6a52:	eb b7                	jmp    6a0b <e173+0xab>
    6a54:	e8 a7 cc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6a59:	e8 02 ca ff ff       	call   3460 <__stack_chk_fail@plt>
    6a5e:	66 90                	xchg   %ax,%ax

0000000000006a60 <fwp_closure_drop>:
    6a60:	48 8b 15 31 e1 01 00 	mov    0x1e131(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6a67:	48 89 f8             	mov    %rdi,%rax
    6a6a:	48 2b 05 ff e0 01 00 	sub    0x1e0ff(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6a71:	48 c1 e2 10          	shl    $0x10,%rdx
    6a75:	48 39 d0             	cmp    %rdx,%rax
    6a78:	73 6b                	jae    6ae5 <fwp_closure_drop+0x85>
    6a7a:	48 89 c2             	mov    %rax,%rdx
    6a7d:	48 c1 ea 10          	shr    $0x10,%rdx
    6a81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a85:	48 8b 15 2c e1 01 00 	mov    0x1e12c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6a8c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a90:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a94:	48 85 d2             	test   %rdx,%rdx
    6a97:	74 4c                	je     6ae5 <fwp_closure_drop+0x85>
    6a99:	0f b6 31             	movzbl (%rcx),%esi
    6a9c:	40 80 fe 02          	cmp    $0x2,%sil
    6aa0:	74 3e                	je     6ae0 <fwp_closure_drop+0x80>
    6aa2:	40 80 fe 01          	cmp    $0x1,%sil
    6aa6:	75 3d                	jne    6ae5 <fwp_closure_drop+0x85>
    6aa8:	8b 71 18             	mov    0x18(%rcx),%esi
    6aab:	0f b7 c0             	movzwl %ax,%eax
    6aae:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ab1:	48 0f af c6          	imul   %rsi,%rax
    6ab5:	48 c1 e8 20          	shr    $0x20,%rax
    6ab9:	48 39 c8             	cmp    %rcx,%rax
    6abc:	73 27                	jae    6ae5 <fwp_closure_drop+0x85>
    6abe:	48 01 c2             	add    %rax,%rdx
    6ac1:	0f b6 02             	movzbl (%rdx),%eax
    6ac4:	84 c0                	test   %al,%al
    6ac6:	74 1d                	je     6ae5 <fwp_closure_drop+0x85>
    6ac8:	3c 01                	cmp    $0x1,%al
    6aca:	74 24                	je     6af0 <fwp_closure_drop+0x90>
    6acc:	3c ff                	cmp    $0xff,%al
    6ace:	74 48                	je     6b18 <fwp_closure_drop+0xb8>
    6ad0:	83 e8 01             	sub    $0x1,%eax
    6ad3:	88 02                	mov    %al,(%rdx)
    6ad5:	c3                   	ret
    6ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6add:	00 00 00 
    6ae0:	66 85 c0             	test   %ax,%ax
    6ae3:	74 dc                	je     6ac1 <fwp_closure_drop+0x61>
    6ae5:	c3                   	ret
    6ae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6aed:	00 00 00 
    6af0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6af7:	ff ff 
    6af9:	48 85 c0             	test   %rax,%rax
    6afc:	74 12                	je     6b10 <fwp_closure_drop+0xb0>
    6afe:	48 89 fe             	mov    %rdi,%rsi
    6b01:	48 89 c7             	mov    %rax,%rdi
    6b04:	e9 47 d9 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6b09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b10:	e9 eb da ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6b15:	0f 1f 00             	nopl   (%rax)
    6b18:	48 89 d0             	mov    %rdx,%rax
    6b1b:	48 8d 35 9e cc 01 00 	lea    0x1cc9e(%rip),%rsi        # 237c0 <fwp_heap>
    6b22:	48 83 ec 18          	sub    $0x18,%rsp
    6b26:	48 c1 e8 11          	shr    $0x11,%rax
    6b2a:	48 31 d0             	xor    %rdx,%rax
    6b2d:	48 89 c1             	mov    %rax,%rcx
    6b30:	48 c1 e9 09          	shr    $0x9,%rcx
    6b34:	48 31 c8             	xor    %rcx,%rax
    6b37:	0f b6 c8             	movzbl %al,%ecx
    6b3a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6b41:	00 
    6b42:	48 85 c0             	test   %rax,%rax
    6b45:	75 22                	jne    6b69 <fwp_closure_drop+0x109>
    6b47:	eb 59                	jmp    6ba2 <fwp_closure_drop+0x142>
    6b49:	90                   	nop
    6b4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b51:	00 00 00 00 
    6b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b5c:	00 00 00 00 
    6b60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b64:	48 85 c0             	test   %rax,%rax
    6b67:	74 39                	je     6ba2 <fwp_closure_drop+0x142>
    6b69:	48 89 c1             	mov    %rax,%rcx
    6b6c:	48 39 10             	cmp    %rdx,(%rax)
    6b6f:	75 ef                	jne    6b60 <fwp_closure_drop+0x100>
    6b71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6b84:	74 05                	je     6b8b <fwp_closure_drop+0x12b>
    6b86:	48 83 c4 18          	add    $0x18,%rsp
    6b8a:	c3                   	ret
    6b8b:	48 89 d7             	mov    %rdx,%rdi
    6b8e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6b93:	e8 b8 e9 ff ff       	call   5550 <fwp_rc_forget_slot>
    6b98:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6b9d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6ba0:	eb e4                	jmp    6b86 <fwp_closure_drop+0x126>
    6ba2:	48 8d 3d e7 8c 00 00 	lea    0x8ce7(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    6ba9:	e8 42 d8 ff ff       	call   43f0 <fwp_trap>
    6bae:	66 90                	xchg   %ax,%ax

0000000000006bb0 <fwp_owned_tape_release>:
    6bb0:	48 85 ff             	test   %rdi,%rdi
    6bb3:	0f 84 f7 00 00 00    	je     6cb0 <fwp_owned_tape_release+0x100>
    6bb9:	41 54                	push   %r12
    6bbb:	55                   	push   %rbp
    6bbc:	53                   	push   %rbx
    6bbd:	48 8b 07             	mov    (%rdi),%rax
    6bc0:	48 85 c0             	test   %rax,%rax
    6bc3:	74 08                	je     6bcd <fwp_owned_tape_release+0x1d>
    6bc5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6bc9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6bcd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6bd1:	48 85 d2             	test   %rdx,%rdx
    6bd4:	74 03                	je     6bd9 <fwp_owned_tape_release+0x29>
    6bd6:	48 89 02             	mov    %rax,(%rdx)
    6bd9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6bdd:	48 89 fb             	mov    %rdi,%rbx
    6be0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6be4:	48 85 c0             	test   %rax,%rax
    6be7:	0f 84 89 00 00 00    	je     6c76 <fwp_owned_tape_release+0xc6>
    6bed:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6bf1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6bf5:	7e 47                	jle    6c3e <fwp_owned_tape_release+0x8e>
    6bf7:	31 ed                	xor    %ebp,%ebp
    6bf9:	eb 0d                	jmp    6c08 <fwp_owned_tape_release+0x58>
    6bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c00:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6c04:	48 8b 40 68          	mov    0x68(%rax),%rax
    6c08:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6c0c:	49 89 ec             	mov    %rbp,%r12
    6c0f:	48 83 c5 01          	add    $0x1,%rbp
    6c13:	49 c1 e4 04          	shl    $0x4,%r12
    6c17:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6c1b:	ff d0                	call   *%rax
    6c1d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6c21:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6c26:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6c2a:	ff 50 68             	call   *0x68(%rax)
    6c2d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6c31:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6c35:	48 39 e8             	cmp    %rbp,%rax
    6c38:	7f c6                	jg     6c00 <fwp_owned_tape_release+0x50>
    6c3a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6c3e:	31 ed                	xor    %ebp,%ebp
    6c40:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6c45:	7e 28                	jle    6c6f <fwp_owned_tape_release+0xbf>
    6c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c4e:	00 00 
    6c50:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6c54:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6c58:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6c5c:	74 07                	je     6c65 <fwp_owned_tape_release+0xb5>
    6c5e:	ff 52 68             	call   *0x68(%rdx)
    6c61:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6c65:	48 83 c5 01          	add    $0x1,%rbp
    6c69:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6c6d:	7f e1                	jg     6c50 <fwp_owned_tape_release+0xa0>
    6c6f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6c73:	ff 52 68             	call   *0x68(%rdx)
    6c76:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6c7a:	e8 e1 fd ff ff       	call   6a60 <fwp_closure_drop>
    6c7f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6c83:	e8 d8 fd ff ff       	call   6a60 <fwp_closure_drop>
    6c88:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6c8c:	e8 cf fd ff ff       	call   6a60 <fwp_closure_drop>
    6c91:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6c95:	e8 f6 ea ff ff       	call   5790 <fwp_mem_free>
    6c9a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6c9e:	e8 ed ea ff ff       	call   5790 <fwp_mem_free>
    6ca3:	48 89 df             	mov    %rbx,%rdi
    6ca6:	5b                   	pop    %rbx
    6ca7:	5d                   	pop    %rbp
    6ca8:	41 5c                	pop    %r12
    6caa:	e9 e1 ea ff ff       	jmp    5790 <fwp_mem_free>
    6caf:	90                   	nop
    6cb0:	c3                   	ret
    6cb1:	0f 1f 40 00          	nopl   0x0(%rax)
    6cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cbc:	00 00 00 00 

0000000000006cc0 <fwp_tape_finish>:
    6cc0:	f3 0f 1e fa          	endbr64
    6cc4:	41 56                	push   %r14
    6cc6:	48 8d 3d d3 c3 01 00 	lea    0x1c3d3(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    6ccd:	41 55                	push   %r13
    6ccf:	41 54                	push   %r12
    6cd1:	55                   	push   %rbp
    6cd2:	53                   	push   %rbx
    6cd3:	e8 38 d4 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6cd8:	48 83 3d 08 c4 01 00 	cmpq   $0x0,0x1c408(%rip)        # 230e8 <fwp_ntapes>
    6cdf:	00 
    6ce0:	48 c7 05 9d c3 01 00 	movq   $0x0,0x1c39d(%rip)        # 23088 <fwp_tape_cached_bytes>
    6ce7:	00 00 00 00 
    6ceb:	7e 68                	jle    6d55 <fwp_tape_finish+0x95>
    6ced:	45 31 e4             	xor    %r12d,%r12d
    6cf0:	31 ed                	xor    %ebp,%ebp
    6cf2:	0f 1f 00             	nopl   (%rax)
    6cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6cfc:	00 00 00 00 
    6d00:	48 8b 1d e9 c3 01 00 	mov    0x1c3e9(%rip),%rbx        # 230f0 <fwp_tapes>
    6d07:	48 83 c5 01          	add    $0x1,%rbp
    6d0b:	4c 01 e3             	add    %r12,%rbx
    6d0e:	49 83 c4 68          	add    $0x68,%r12
    6d12:	48 89 df             	mov    %rbx,%rdi
    6d15:	e8 e6 ce ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6d1a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6d1e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6d22:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6d26:	e8 95 c6 ff ff       	call   33c0 <free@plt>
    6d2b:	4c 89 f7             	mov    %r14,%rdi
    6d2e:	e8 8d c6 ff ff       	call   33c0 <free@plt>
    6d33:	4c 89 ef             	mov    %r13,%rdi
    6d36:	e8 85 c6 ff ff       	call   33c0 <free@plt>
    6d3b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6d3f:	e8 6c fe ff ff       	call   6bb0 <fwp_owned_tape_release>
    6d44:	48 39 2d 9d c3 01 00 	cmp    %rbp,0x1c39d(%rip)        # 230e8 <fwp_ntapes>
    6d4b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6d52:	00 
    6d53:	7f ab                	jg     6d00 <fwp_tape_finish+0x40>
    6d55:	48 8b 3d 94 c3 01 00 	mov    0x1c394(%rip),%rdi        # 230f0 <fwp_tapes>
    6d5c:	e8 5f c6 ff ff       	call   33c0 <free@plt>
    6d61:	5b                   	pop    %rbx
    6d62:	5d                   	pop    %rbp
    6d63:	48 c7 05 82 c3 01 00 	movq   $0x0,0x1c382(%rip)        # 230f0 <fwp_tapes>
    6d6a:	00 00 00 00 
    6d6e:	48 c7 05 67 c3 01 00 	movq   $0x0,0x1c367(%rip)        # 230e0 <fwp_tapes_cap>
    6d75:	00 00 00 00 
    6d79:	41 5c                	pop    %r12
    6d7b:	48 c7 05 62 c3 01 00 	movq   $0x0,0x1c362(%rip)        # 230e8 <fwp_ntapes>
    6d82:	00 00 00 00 
    6d86:	41 5d                	pop    %r13
    6d88:	48 c7 05 45 c3 01 00 	movq   $0x0,0x1c345(%rip)        # 230d8 <fwp_tape_next_slot>
    6d8f:	00 00 00 00 
    6d93:	41 5e                	pop    %r14
    6d95:	c3                   	ret
    6d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d9d:	00 00 00 

0000000000006da0 <fwp_tape_scope_release>:
    6da0:	f3 0f 1e fa          	endbr64
    6da4:	41 55                	push   %r13
    6da6:	41 54                	push   %r12
    6da8:	55                   	push   %rbp
    6da9:	53                   	push   %rbx
    6daa:	48 83 ec 58          	sub    $0x58,%rsp
    6dae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6db5:	00 00 
    6db7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6dbc:	48 63 07             	movslq (%rdi),%rax
    6dbf:	85 c0                	test   %eax,%eax
    6dc1:	0f 88 05 01 00 00    	js     6ecc <fwp_tape_scope_release+0x12c>
    6dc7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6dce:	ec c4 4e 
    6dd1:	48 89 fb             	mov    %rdi,%rbx
    6dd4:	eb 3c                	jmp    6e12 <fwp_tape_scope_release+0x72>
    6dd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ddd:	00 00 00 
    6de0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6de5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6de9:	e8 d2 c5 ff ff       	call   33c0 <free@plt>
    6dee:	48 8b 3c 24          	mov    (%rsp),%rdi
    6df2:	e8 c9 c5 ff ff       	call   33c0 <free@plt>
    6df7:	4c 89 ef             	mov    %r13,%rdi
    6dfa:	e8 c1 c5 ff ff       	call   33c0 <free@plt>
    6dff:	4c 89 e7             	mov    %r12,%rdi
    6e02:	e8 a9 fd ff ff       	call   6bb0 <fwp_owned_tape_release>
    6e07:	48 63 03             	movslq (%rbx),%rax
    6e0a:	85 c0                	test   %eax,%eax
    6e0c:	0f 88 ba 00 00 00    	js     6ecc <fwp_tape_scope_release+0x12c>
    6e12:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6e16:	48 8b 35 d3 c2 01 00 	mov    0x1c2d3(%rip),%rsi        # 230f0 <fwp_tapes>
    6e1d:	4c 01 c6             	add    %r8,%rsi
    6e20:	48 89 f7             	mov    %rsi,%rdi
    6e23:	e8 d8 cd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6e28:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6e2d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6e32:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6e39:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6e3d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6e41:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6e48:	00 
    6e49:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6e4e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6e52:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6e57:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6e5b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6e60:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6e67:	00 
    6e68:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6e6f:	00 
    6e70:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6e77:	00 
    6e78:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6e7d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6e82:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6e86:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6e8a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6e8e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6e94:	77 18                	ja     6eae <fwp_tape_scope_release+0x10e>
    6e96:	49 c1 f8 03          	sar    $0x3,%r8
    6e9a:	4c 0f af c5          	imul   %rbp,%r8
    6e9e:	4c 3b 05 33 c2 01 00 	cmp    0x1c233(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    6ea5:	7d 07                	jge    6eae <fwp_tape_scope_release+0x10e>
    6ea7:	4c 89 05 2a c2 01 00 	mov    %r8,0x1c22a(%rip)        # 230d8 <fwp_tape_next_slot>
    6eae:	4d 85 e4             	test   %r12,%r12
    6eb1:	0f 85 29 ff ff ff    	jne    6de0 <fwp_tape_scope_release+0x40>
    6eb7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6ebc:	e8 af e1 ff ff       	call   5070 <fwp_tape_buffers_release>
    6ec1:	48 63 03             	movslq (%rbx),%rax
    6ec4:	85 c0                	test   %eax,%eax
    6ec6:	0f 89 46 ff ff ff    	jns    6e12 <fwp_tape_scope_release+0x72>
    6ecc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6ed1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ed8:	00 00 
    6eda:	75 0b                	jne    6ee7 <fwp_tape_scope_release+0x147>
    6edc:	48 83 c4 58          	add    $0x58,%rsp
    6ee0:	5b                   	pop    %rbx
    6ee1:	5d                   	pop    %rbp
    6ee2:	41 5c                	pop    %r12
    6ee4:	41 5d                	pop    %r13
    6ee6:	c3                   	ret
    6ee7:	e8 74 c5 ff ff       	call   3460 <__stack_chk_fail@plt>
    6eec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006ef0 <fwp_drop4>:
    6ef0:	48 8b 0d a1 dc 01 00 	mov    0x1dca1(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    6ef7:	48 89 f8             	mov    %rdi,%rax
    6efa:	48 2b 05 6f dc 01 00 	sub    0x1dc6f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6f01:	48 c1 e1 10          	shl    $0x10,%rcx
    6f05:	48 39 c8             	cmp    %rcx,%rax
    6f08:	0f 83 42 01 00 00    	jae    7050 <fwp_drop4+0x160>
    6f0e:	48 83 ec 18          	sub    $0x18,%rsp
    6f12:	48 89 fa             	mov    %rdi,%rdx
    6f15:	4c 8d 05 a4 c8 01 00 	lea    0x1c8a4(%rip),%r8        # 237c0 <fwp_heap>
    6f1c:	48 89 c1             	mov    %rax,%rcx
    6f1f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6f26:	48 c1 e9 10          	shr    $0x10,%rcx
    6f2a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6f2e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6f32:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6f36:	48 85 c9             	test   %rcx,%rcx
    6f39:	74 40                	je     6f7b <fwp_drop4+0x8b>
    6f3b:	0f b6 3e             	movzbl (%rsi),%edi
    6f3e:	40 80 ff 02          	cmp    $0x2,%dil
    6f42:	74 3c                	je     6f80 <fwp_drop4+0x90>
    6f44:	40 80 ff 01          	cmp    $0x1,%dil
    6f48:	75 31                	jne    6f7b <fwp_drop4+0x8b>
    6f4a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6f4d:	0f b7 c0             	movzwl %ax,%eax
    6f50:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6f53:	48 0f af c7          	imul   %rdi,%rax
    6f57:	48 c1 e8 20          	shr    $0x20,%rax
    6f5b:	48 39 f0             	cmp    %rsi,%rax
    6f5e:	73 1b                	jae    6f7b <fwp_drop4+0x8b>
    6f60:	48 01 c1             	add    %rax,%rcx
    6f63:	0f b6 01             	movzbl (%rcx),%eax
    6f66:	84 c0                	test   %al,%al
    6f68:	74 11                	je     6f7b <fwp_drop4+0x8b>
    6f6a:	3c 01                	cmp    $0x1,%al
    6f6c:	74 22                	je     6f90 <fwp_drop4+0xa0>
    6f6e:	3c ff                	cmp    $0xff,%al
    6f70:	0f 84 0a 01 00 00    	je     7080 <fwp_drop4+0x190>
    6f76:	83 e8 01             	sub    $0x1,%eax
    6f79:	88 01                	mov    %al,(%rcx)
    6f7b:	48 83 c4 18          	add    $0x18,%rsp
    6f7f:	c3                   	ret
    6f80:	66 85 c0             	test   %ax,%ax
    6f83:	74 de                	je     6f63 <fwp_drop4+0x73>
    6f85:	48 83 c4 18          	add    $0x18,%rsp
    6f89:	c3                   	ret
    6f8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f90:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6f94:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6f9b:	48 89 f8             	mov    %rdi,%rax
    6f9e:	48 c1 e1 10          	shl    $0x10,%rcx
    6fa2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6fa9:	48 39 c8             	cmp    %rcx,%rax
    6fac:	73 62                	jae    7010 <fwp_drop4+0x120>
    6fae:	48 89 c1             	mov    %rax,%rcx
    6fb1:	48 c1 e9 10          	shr    $0x10,%rcx
    6fb5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6fb9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6fbd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6fc1:	48 85 c9             	test   %rcx,%rcx
    6fc4:	74 4a                	je     7010 <fwp_drop4+0x120>
    6fc6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6fca:	41 80 f9 02          	cmp    $0x2,%r9b
    6fce:	0f 84 9c 00 00 00    	je     7070 <fwp_drop4+0x180>
    6fd4:	41 80 f9 01          	cmp    $0x1,%r9b
    6fd8:	75 36                	jne    7010 <fwp_drop4+0x120>
    6fda:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6fde:	0f b7 c0             	movzwl %ax,%eax
    6fe1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6fe4:	49 0f af c1          	imul   %r9,%rax
    6fe8:	48 c1 e8 20          	shr    $0x20,%rax
    6fec:	48 39 f0             	cmp    %rsi,%rax
    6fef:	73 1f                	jae    7010 <fwp_drop4+0x120>
    6ff1:	48 01 c1             	add    %rax,%rcx
    6ff4:	0f b6 01             	movzbl (%rcx),%eax
    6ff7:	84 c0                	test   %al,%al
    6ff9:	74 15                	je     7010 <fwp_drop4+0x120>
    6ffb:	3c 01                	cmp    $0x1,%al
    6ffd:	74 59                	je     7058 <fwp_drop4+0x168>
    6fff:	3c ff                	cmp    $0xff,%al
    7001:	0f 84 ff 00 00 00    	je     7106 <fwp_drop4+0x216>
    7007:	83 e8 01             	sub    $0x1,%eax
    700a:	88 01                	mov    %al,(%rcx)
    700c:	0f 1f 40 00          	nopl   0x0(%rax)
    7010:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7014:	48 89 d7             	mov    %rdx,%rdi
    7017:	48 89 0c 24          	mov    %rcx,(%rsp)
    701b:	e8 30 f7 ff ff       	call   6750 <fwp_rc_free_obj>
    7020:	4c 8d 05 99 c7 01 00 	lea    0x1c799(%rip),%r8        # 237c0 <fwp_heap>
    7027:	48 8b 04 24          	mov    (%rsp),%rax
    702b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7032:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7039:	48 c1 e2 10          	shl    $0x10,%rdx
    703d:	48 39 d0             	cmp    %rdx,%rax
    7040:	0f 83 35 ff ff ff    	jae    6f7b <fwp_drop4+0x8b>
    7046:	48 8b 14 24          	mov    (%rsp),%rdx
    704a:	e9 cd fe ff ff       	jmp    6f1c <fwp_drop4+0x2c>
    704f:	90                   	nop
    7050:	c3                   	ret
    7051:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7058:	48 89 14 24          	mov    %rdx,(%rsp)
    705c:	e8 ef f6 ff ff       	call   6750 <fwp_rc_free_obj>
    7061:	48 8b 14 24          	mov    (%rsp),%rdx
    7065:	eb a9                	jmp    7010 <fwp_drop4+0x120>
    7067:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    706e:	00 00 
    7070:	66 85 c0             	test   %ax,%ax
    7073:	75 9b                	jne    7010 <fwp_drop4+0x120>
    7075:	e9 7a ff ff ff       	jmp    6ff4 <fwp_drop4+0x104>
    707a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7080:	48 89 c8             	mov    %rcx,%rax
    7083:	48 c1 e8 11          	shr    $0x11,%rax
    7087:	48 31 c8             	xor    %rcx,%rax
    708a:	48 89 c2             	mov    %rax,%rdx
    708d:	48 c1 ea 09          	shr    $0x9,%rdx
    7091:	48 31 d0             	xor    %rdx,%rax
    7094:	0f b6 d0             	movzbl %al,%edx
    7097:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    709e:	00 
    709f:	48 85 c0             	test   %rax,%rax
    70a2:	75 29                	jne    70cd <fwp_drop4+0x1dd>
    70a4:	e9 e3 00 00 00       	jmp    718c <fwp_drop4+0x29c>
    70a9:	90                   	nop
    70aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70b1:	00 00 00 00 
    70b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70bc:	00 00 00 00 
    70c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    70c4:	48 85 c0             	test   %rax,%rax
    70c7:	0f 84 bf 00 00 00    	je     718c <fwp_drop4+0x29c>
    70cd:	48 89 c2             	mov    %rax,%rdx
    70d0:	48 39 08             	cmp    %rcx,(%rax)
    70d3:	75 eb                	jne    70c0 <fwp_drop4+0x1d0>
    70d5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    70d9:	48 83 ea 01          	sub    $0x1,%rdx
    70dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    70e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    70e8:	0f 85 8d fe ff ff    	jne    6f7b <fwp_drop4+0x8b>
    70ee:	48 89 cf             	mov    %rcx,%rdi
    70f1:	48 89 0c 24          	mov    %rcx,(%rsp)
    70f5:	e8 56 e4 ff ff       	call   5550 <fwp_rc_forget_slot>
    70fa:	48 8b 0c 24          	mov    (%rsp),%rcx
    70fe:	c6 01 fe             	movb   $0xfe,(%rcx)
    7101:	e9 75 fe ff ff       	jmp    6f7b <fwp_drop4+0x8b>
    7106:	48 89 ce             	mov    %rcx,%rsi
    7109:	48 c1 ee 11          	shr    $0x11,%rsi
    710d:	48 31 ce             	xor    %rcx,%rsi
    7110:	48 89 f0             	mov    %rsi,%rax
    7113:	48 c1 e8 09          	shr    $0x9,%rax
    7117:	48 31 c6             	xor    %rax,%rsi
    711a:	40 0f b6 f6          	movzbl %sil,%esi
    711e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7125:	00 
    7126:	48 85 c0             	test   %rax,%rax
    7129:	75 1e                	jne    7149 <fwp_drop4+0x259>
    712b:	eb 5f                	jmp    718c <fwp_drop4+0x29c>
    712d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7134:	00 
    7135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    713c:	00 00 00 00 
    7140:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7144:	48 85 c0             	test   %rax,%rax
    7147:	74 43                	je     718c <fwp_drop4+0x29c>
    7149:	48 89 c6             	mov    %rax,%rsi
    714c:	48 39 08             	cmp    %rcx,(%rax)
    714f:	75 ef                	jne    7140 <fwp_drop4+0x250>
    7151:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7155:	48 83 ee 01          	sub    $0x1,%rsi
    7159:	48 89 70 08          	mov    %rsi,0x8(%rax)
    715d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7164:	0f 85 a6 fe ff ff    	jne    7010 <fwp_drop4+0x120>
    716a:	48 89 cf             	mov    %rcx,%rdi
    716d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7172:	48 89 0c 24          	mov    %rcx,(%rsp)
    7176:	e8 d5 e3 ff ff       	call   5550 <fwp_rc_forget_slot>
    717b:	48 8b 0c 24          	mov    (%rsp),%rcx
    717f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7184:	c6 01 fe             	movb   $0xfe,(%rcx)
    7187:	e9 84 fe ff ff       	jmp    7010 <fwp_drop4+0x120>
    718c:	48 8d 3d fd 86 00 00 	lea    0x86fd(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7193:	e8 58 d2 ff ff       	call   43f0 <fwp_trap>
    7198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    719f:	00 

00000000000071a0 <fwp_arg_drop37>:
    71a0:	f3 0f 1e fa          	endbr64
    71a4:	85 f6                	test   %esi,%esi
    71a6:	75 04                	jne    71ac <fwp_arg_drop37+0xc>
    71a8:	85 d2                	test   %edx,%edx
    71aa:	75 04                	jne    71b0 <fwp_arg_drop37+0x10>
    71ac:	c3                   	ret
    71ad:	0f 1f 00             	nopl   (%rax)
    71b0:	48 8b 3f             	mov    (%rdi),%rdi
    71b3:	e9 38 fd ff ff       	jmp    6ef0 <fwp_drop4>
    71b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    71bf:	00 

00000000000071c0 <fwp_task_dispose>:
    71c0:	53                   	push   %rbx
    71c1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    71c5:	0f 84 7b c5 ff ff    	je     3746 <fwp_task_dispose.cold>
    71cb:	48 89 fb             	mov    %rdi,%rbx
    71ce:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    71d3:	0f 85 6d c5 ff ff    	jne    3746 <fwp_task_dispose.cold>
    71d9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    71dd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    71e4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    71eb:	00 
    71ec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    71f0:	48 85 ff             	test   %rdi,%rdi
    71f3:	74 07                	je     71fc <fwp_task_dispose+0x3c>
    71f5:	48 85 c0             	test   %rax,%rax
    71f8:	74 02                	je     71fc <fwp_task_dispose+0x3c>
    71fa:	ff d0                	call   *%rax
    71fc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7203:	e8 88 e5 ff ff       	call   5790 <fwp_mem_free>
    7208:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    720f:	00 00 00 00 
    7213:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7217:	74 6f                	je     7288 <fwp_task_dispose+0xc8>
    7219:	48 8b 15 78 d9 01 00 	mov    0x1d978(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7220:	48 89 d8             	mov    %rbx,%rax
    7223:	48 2b 05 46 d9 01 00 	sub    0x1d946(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    722a:	48 c1 e2 10          	shl    $0x10,%rdx
    722e:	48 39 d0             	cmp    %rdx,%rax
    7231:	73 4c                	jae    727f <fwp_task_dispose+0xbf>
    7233:	48 89 c2             	mov    %rax,%rdx
    7236:	48 c1 ea 10          	shr    $0x10,%rdx
    723a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    723e:	48 8b 15 73 d9 01 00 	mov    0x1d973(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7245:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7249:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    724d:	48 85 c9             	test   %rcx,%rcx
    7250:	74 2d                	je     727f <fwp_task_dispose+0xbf>
    7252:	0f b6 32             	movzbl (%rdx),%esi
    7255:	40 80 fe 02          	cmp    $0x2,%sil
    7259:	74 3d                	je     7298 <fwp_task_dispose+0xd8>
    725b:	40 80 fe 01          	cmp    $0x1,%sil
    725f:	75 1e                	jne    727f <fwp_task_dispose+0xbf>
    7261:	8b 72 18             	mov    0x18(%rdx),%esi
    7264:	0f b7 c0             	movzwl %ax,%eax
    7267:	8b 52 1c             	mov    0x1c(%rdx),%edx
    726a:	48 0f af c6          	imul   %rsi,%rax
    726e:	48 c1 e8 20          	shr    $0x20,%rax
    7272:	48 39 d0             	cmp    %rdx,%rax
    7275:	73 08                	jae    727f <fwp_task_dispose+0xbf>
    7277:	48 01 c1             	add    %rax,%rcx
    727a:	80 39 01             	cmpb   $0x1,(%rcx)
    727d:	74 09                	je     7288 <fwp_task_dispose+0xc8>
    727f:	5b                   	pop    %rbx
    7280:	c3                   	ret
    7281:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7288:	48 89 df             	mov    %rbx,%rdi
    728b:	5b                   	pop    %rbx
    728c:	e9 ff e4 ff ff       	jmp    5790 <fwp_mem_free>
    7291:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7298:	66 85 c0             	test   %ax,%ax
    729b:	74 dd                	je     727a <fwp_task_dispose+0xba>
    729d:	5b                   	pop    %rbx
    729e:	c3                   	ret
    729f:	90                   	nop

00000000000072a0 <fwp_free_zombie>:
    72a0:	48 8b 15 e9 c4 01 00 	mov    0x1c4e9(%rip),%rdx        # 23790 <fwp_zombie>
    72a7:	48 85 d2             	test   %rdx,%rdx
    72aa:	0f 84 98 00 00 00    	je     7348 <fwp_free_zombie+0xa8>
    72b0:	48 3b 15 e9 c4 01 00 	cmp    0x1c4e9(%rip),%rdx        # 237a0 <fwp_cur>
    72b7:	0f 84 8b 00 00 00    	je     7348 <fwp_free_zombie+0xa8>
    72bd:	48 83 ec 18          	sub    $0x18,%rsp
    72c1:	48 63 05 9c be 01 00 	movslq 0x1be9c(%rip),%rax        # 23164 <fwp_stack_pool_n>
    72c8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    72cc:	83 f8 3f             	cmp    $0x3f,%eax
    72cf:	7f 7f                	jg     7350 <fwp_free_zombie+0xb0>
    72d1:	8d 48 01             	lea    0x1(%rax),%ecx
    72d4:	89 0d 8a be 01 00    	mov    %ecx,0x1be8a(%rip)        # 23164 <fwp_stack_pool_n>
    72da:	48 8d 0d 9f be 01 00 	lea    0x1be9f(%rip),%rcx        # 23180 <fwp_stack_pool>
    72e1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    72e5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    72ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    72f0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    72f7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    72fb:	48 85 c9             	test   %rcx,%rcx
    72fe:	0f 84 fc 00 00 00    	je     7400 <fwp_free_zombie+0x160>
    7304:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    730b:	48 85 c0             	test   %rax,%rax
    730e:	74 07                	je     7317 <fwp_free_zombie+0x77>
    7310:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7317:	8b 42 5c             	mov    0x5c(%rdx),%eax
    731a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    731e:	48 c7 05 67 c4 01 00 	movq   $0x0,0x1c467(%rip)        # 23790 <fwp_zombie>
    7325:	00 00 00 00 
    7329:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7330:	85 c0                	test   %eax,%eax
    7332:	74 34                	je     7368 <fwp_free_zombie+0xc8>
    7334:	83 f8 01             	cmp    $0x1,%eax
    7337:	0f 84 b3 00 00 00    	je     73f0 <fwp_free_zombie+0x150>
    733d:	48 83 c4 18          	add    $0x18,%rsp
    7341:	c3                   	ret
    7342:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7348:	c3                   	ret
    7349:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7350:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7354:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7359:	e8 82 c2 ff ff       	call   35e0 <munmap@plt>
    735e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7363:	eb 80                	jmp    72e5 <fwp_free_zombie+0x45>
    7365:	0f 1f 00             	nopl   (%rax)
    7368:	48 8b 0d 29 d8 01 00 	mov    0x1d829(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    736f:	48 89 d0             	mov    %rdx,%rax
    7372:	48 2b 05 f7 d7 01 00 	sub    0x1d7f7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7379:	48 c1 e1 10          	shl    $0x10,%rcx
    737d:	48 39 c8             	cmp    %rcx,%rax
    7380:	73 bb                	jae    733d <fwp_free_zombie+0x9d>
    7382:	48 89 c1             	mov    %rax,%rcx
    7385:	48 c1 e9 10          	shr    $0x10,%rcx
    7389:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    738d:	48 8b 0d 24 d8 01 00 	mov    0x1d824(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    7394:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7398:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    739c:	48 85 c9             	test   %rcx,%rcx
    739f:	74 9c                	je     733d <fwp_free_zombie+0x9d>
    73a1:	0f b6 3e             	movzbl (%rsi),%edi
    73a4:	40 80 ff 02          	cmp    $0x2,%dil
    73a8:	74 66                	je     7410 <fwp_free_zombie+0x170>
    73aa:	40 80 ff 01          	cmp    $0x1,%dil
    73ae:	75 8d                	jne    733d <fwp_free_zombie+0x9d>
    73b0:	8b 7e 18             	mov    0x18(%rsi),%edi
    73b3:	0f b7 c0             	movzwl %ax,%eax
    73b6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    73b9:	48 0f af c7          	imul   %rdi,%rax
    73bd:	48 c1 e8 20          	shr    $0x20,%rax
    73c1:	48 39 f0             	cmp    %rsi,%rax
    73c4:	0f 83 73 ff ff ff    	jae    733d <fwp_free_zombie+0x9d>
    73ca:	48 01 c1             	add    %rax,%rcx
    73cd:	0f b6 01             	movzbl (%rcx),%eax
    73d0:	84 c0                	test   %al,%al
    73d2:	0f 84 65 ff ff ff    	je     733d <fwp_free_zombie+0x9d>
    73d8:	3c 01                	cmp    $0x1,%al
    73da:	74 14                	je     73f0 <fwp_free_zombie+0x150>
    73dc:	3c ff                	cmp    $0xff,%al
    73de:	74 3b                	je     741b <fwp_free_zombie+0x17b>
    73e0:	83 e8 01             	sub    $0x1,%eax
    73e3:	88 01                	mov    %al,(%rcx)
    73e5:	e9 53 ff ff ff       	jmp    733d <fwp_free_zombie+0x9d>
    73ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73f0:	48 89 d7             	mov    %rdx,%rdi
    73f3:	48 83 c4 18          	add    $0x18,%rsp
    73f7:	e9 c4 fd ff ff       	jmp    71c0 <fwp_task_dispose>
    73fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7400:	48 89 05 61 c3 01 00 	mov    %rax,0x1c361(%rip)        # 23768 <fwp_tasks_active>
    7407:	e9 ff fe ff ff       	jmp    730b <fwp_free_zombie+0x6b>
    740c:	0f 1f 40 00          	nopl   0x0(%rax)
    7410:	66 85 c0             	test   %ax,%ax
    7413:	0f 85 24 ff ff ff    	jne    733d <fwp_free_zombie+0x9d>
    7419:	eb b2                	jmp    73cd <fwp_free_zombie+0x12d>
    741b:	48 89 ca             	mov    %rcx,%rdx
    741e:	48 8d 35 9b c3 01 00 	lea    0x1c39b(%rip),%rsi        # 237c0 <fwp_heap>
    7425:	48 c1 ea 11          	shr    $0x11,%rdx
    7429:	48 31 ca             	xor    %rcx,%rdx
    742c:	48 89 d0             	mov    %rdx,%rax
    742f:	48 c1 e8 09          	shr    $0x9,%rax
    7433:	48 31 c2             	xor    %rax,%rdx
    7436:	0f b6 d2             	movzbl %dl,%edx
    7439:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7440:	00 
    7441:	48 85 c0             	test   %rax,%rax
    7444:	75 23                	jne    7469 <fwp_free_zombie+0x1c9>
    7446:	eb 5c                	jmp    74a4 <fwp_free_zombie+0x204>
    7448:	66 90                	xchg   %ax,%ax
    744a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7451:	00 00 00 00 
    7455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    745c:	00 00 00 00 
    7460:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7464:	48 85 c0             	test   %rax,%rax
    7467:	74 3b                	je     74a4 <fwp_free_zombie+0x204>
    7469:	48 89 c2             	mov    %rax,%rdx
    746c:	48 39 08             	cmp    %rcx,(%rax)
    746f:	75 ef                	jne    7460 <fwp_free_zombie+0x1c0>
    7471:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7475:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7479:	48 89 50 08          	mov    %rdx,0x8(%rax)
    747d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7484:	0f 85 b3 fe ff ff    	jne    733d <fwp_free_zombie+0x9d>
    748a:	48 89 cf             	mov    %rcx,%rdi
    748d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7492:	e8 b9 e0 ff ff       	call   5550 <fwp_rc_forget_slot>
    7497:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    749c:	c6 01 fe             	movb   $0xfe,(%rcx)
    749f:	e9 99 fe ff ff       	jmp    733d <fwp_free_zombie+0x9d>
    74a4:	48 8d 3d e5 83 00 00 	lea    0x83e5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    74ab:	e8 40 cf ff ff       	call   43f0 <fwp_trap>

00000000000074b0 <fwp_block>:
    74b0:	48 83 ec 08          	sub    $0x8,%rsp
    74b4:	48 8b 05 cd c2 01 00 	mov    0x1c2cd(%rip),%rax        # 23788 <fwp_ready_head>
    74bb:	48 85 c0             	test   %rax,%rax
    74be:	0f 84 1c 01 00 00    	je     75e0 <fwp_block+0x130>
    74c4:	90                   	nop
    74c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74cc:	00 00 00 00 
    74d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    74d7:	48 89 15 aa c2 01 00 	mov    %rdx,0x1c2aa(%rip)        # 23788 <fwp_ready_head>
    74de:	48 85 d2             	test   %rdx,%rdx
    74e1:	0f 84 19 01 00 00    	je     7600 <fwp_block+0x150>
    74e7:	48 8b 15 b2 c2 01 00 	mov    0x1c2b2(%rip),%rdx        # 237a0 <fwp_cur>
    74ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    74f2:	48 39 c2             	cmp    %rax,%rdx
    74f5:	0f 84 d5 00 00 00    	je     75d0 <fwp_block+0x120>
    74fb:	48 8b 0d 26 df 01 00 	mov    0x1df26(%rip),%rcx        # 25428 <fwp_state_owners>
    7502:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7506:	48 89 05 93 c2 01 00 	mov    %rax,0x1c293(%rip)        # 237a0 <fwp_cur>
    750d:	f3 0f 7e 05 3b df 01 	movq   0x1df3b(%rip),%xmm0        # 25450 <fwp_foreign_callbacks>
    7514:	00 
    7515:	0f 16 05 24 df 01 00 	movhps 0x1df24(%rip),%xmm0        # 25440 <fwp_state>
    751c:	f3 0f 7e 0d 24 df 01 	movq   0x1df24(%rip),%xmm1        # 25448 <fwp_handlers>
    7523:	00 
    7524:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    752b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7532:	0f 16 0d 1f df 01 00 	movhps 0x1df1f(%rip),%xmm1        # 25458 <fwp_cleanups>
    7539:	f3 0f 7e 05 f7 de 01 	movq   0x1def7(%rip),%xmm0        # 25438 <fwp_state_len>
    7540:	00 
    7541:	0f 16 05 e8 de 01 00 	movhps 0x1dee8(%rip),%xmm0        # 25430 <fwp_state_cap>
    7548:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    754f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7556:	48 8b 70 08          	mov    0x8(%rax),%rsi
    755a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7561:	48 89 0d e0 de 01 00 	mov    %rcx,0x1dee0(%rip)        # 25448 <fwp_handlers>
    7568:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    756f:	48 89 0d e2 de 01 00 	mov    %rcx,0x1dee2(%rip)        # 25458 <fwp_cleanups>
    7576:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    757d:	48 89 0d cc de 01 00 	mov    %rcx,0x1decc(%rip)        # 25450 <fwp_foreign_callbacks>
    7584:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    758b:	48 89 0d ae de 01 00 	mov    %rcx,0x1deae(%rip)        # 25440 <fwp_state>
    7592:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7599:	48 89 0d 98 de 01 00 	mov    %rcx,0x1de98(%rip)        # 25438 <fwp_state_len>
    75a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    75a7:	48 89 0d 82 de 01 00 	mov    %rcx,0x1de82(%rip)        # 25430 <fwp_state_cap>
    75ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    75b5:	48 89 0d 6c de 01 00 	mov    %rcx,0x1de6c(%rip)        # 25428 <fwp_state_owners>
    75bc:	e8 cf be ff ff       	call   3490 <swapcontext@plt>
    75c1:	f3 0f 1e fa          	endbr64
    75c5:	e8 d6 fc ff ff       	call   72a0 <fwp_free_zombie>
    75ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75d0:	8b 05 8a bb 01 00    	mov    0x1bb8a(%rip),%eax        # 23160 <fwp_slice>
    75d6:	85 c0                	test   %eax,%eax
    75d8:	74 36                	je     7610 <fwp_block+0x160>
    75da:	48 83 c4 08          	add    $0x8,%rsp
    75de:	c3                   	ret
    75df:	90                   	nop
    75e0:	e8 bb db ff ff       	call   51a0 <fwp_poll_events>
    75e5:	48 8b 05 9c c1 01 00 	mov    0x1c19c(%rip),%rax        # 23788 <fwp_ready_head>
    75ec:	48 85 c0             	test   %rax,%rax
    75ef:	0f 85 db fe ff ff    	jne    74d0 <fwp_block+0x20>
    75f5:	eb e9                	jmp    75e0 <fwp_block+0x130>
    75f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75fe:	00 00 
    7600:	48 c7 05 75 c1 01 00 	movq   $0x0,0x1c175(%rip)        # 23780 <fwp_ready_tail>
    7607:	00 00 00 00 
    760b:	e9 d7 fe ff ff       	jmp    74e7 <fwp_block+0x37>
    7610:	48 8d 3d 6d 7b 00 00 	lea    0x7b6d(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    7617:	e8 84 bd ff ff       	call   33a0 <getenv@plt>
    761c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7621:	48 85 c0             	test   %rax,%rax
    7624:	74 05                	je     762b <fwp_block+0x17b>
    7626:	80 38 00             	cmpb   $0x0,(%rax)
    7629:	75 0b                	jne    7636 <fwp_block+0x186>
    762b:	89 15 2f bb 01 00    	mov    %edx,0x1bb2f(%rip)        # 23160 <fwp_slice>
    7631:	48 83 c4 08          	add    $0x8,%rsp
    7635:	c3                   	ret
    7636:	ba 0a 00 00 00       	mov    $0xa,%edx
    763b:	31 f6                	xor    %esi,%esi
    763d:	48 89 c7             	mov    %rax,%rdi
    7640:	e8 0b bf ff ff       	call   3550 <strtoll@plt>
    7645:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7649:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7650:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7655:	0f 46 d0             	cmovbe %eax,%edx
    7658:	eb d1                	jmp    762b <fwp_block+0x17b>
    765a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007660 <fwp_caps173>:
    7660:	f3 0f 1e fa          	endbr64
    7664:	85 f6                	test   %esi,%esi
    7666:	74 08                	je     7670 <fwp_caps173+0x10>
    7668:	c3                   	ret
    7669:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7670:	48 8b 15 21 d5 01 00 	mov    0x1d521(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7677:	48 89 f8             	mov    %rdi,%rax
    767a:	48 2b 05 ef d4 01 00 	sub    0x1d4ef(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7681:	48 c1 e2 10          	shl    $0x10,%rdx
    7685:	48 39 d0             	cmp    %rdx,%rax
    7688:	73 de                	jae    7668 <fwp_caps173+0x8>
    768a:	48 89 c2             	mov    %rax,%rdx
    768d:	48 c1 ea 10          	shr    $0x10,%rdx
    7691:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7695:	48 8b 15 1c d5 01 00 	mov    0x1d51c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    769c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    76a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    76a4:	48 85 c9             	test   %rcx,%rcx
    76a7:	74 bf                	je     7668 <fwp_caps173+0x8>
    76a9:	0f b6 32             	movzbl (%rdx),%esi
    76ac:	40 80 fe 02          	cmp    $0x2,%sil
    76b0:	74 2e                	je     76e0 <fwp_caps173+0x80>
    76b2:	40 80 fe 01          	cmp    $0x1,%sil
    76b6:	75 b0                	jne    7668 <fwp_caps173+0x8>
    76b8:	8b 72 18             	mov    0x18(%rdx),%esi
    76bb:	0f b7 c0             	movzwl %ax,%eax
    76be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    76c1:	48 0f af c6          	imul   %rsi,%rax
    76c5:	48 c1 e8 20          	shr    $0x20,%rax
    76c9:	48 39 d0             	cmp    %rdx,%rax
    76cc:	73 9a                	jae    7668 <fwp_caps173+0x8>
    76ce:	48 01 c1             	add    %rax,%rcx
    76d1:	80 39 01             	cmpb   $0x1,(%rcx)
    76d4:	75 92                	jne    7668 <fwp_caps173+0x8>
    76d6:	e9 b5 e0 ff ff       	jmp    5790 <fwp_mem_free>
    76db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    76e0:	66 85 c0             	test   %ax,%ax
    76e3:	74 ec                	je     76d1 <fwp_caps173+0x71>
    76e5:	c3                   	ret
    76e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    76ed:	00 00 00 

00000000000076f0 <fwp_args37>:
    76f0:	f3 0f 1e fa          	endbr64
    76f4:	85 d2                	test   %edx,%edx
    76f6:	74 04                	je     76fc <fwp_args37+0xc>
    76f8:	85 f6                	test   %esi,%esi
    76fa:	74 04                	je     7700 <fwp_args37+0x10>
    76fc:	c3                   	ret
    76fd:	0f 1f 00             	nopl   (%rax)
    7700:	48 8b 15 91 d4 01 00 	mov    0x1d491(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7707:	48 8b 07             	mov    (%rdi),%rax
    770a:	48 2b 05 5f d4 01 00 	sub    0x1d45f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7711:	48 c1 e2 10          	shl    $0x10,%rdx
    7715:	48 39 d0             	cmp    %rdx,%rax
    7718:	73 e2                	jae    76fc <fwp_args37+0xc>
    771a:	48 89 c2             	mov    %rax,%rdx
    771d:	48 c1 ea 10          	shr    $0x10,%rdx
    7721:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7725:	48 8b 15 8c d4 01 00 	mov    0x1d48c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    772c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7730:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7734:	48 85 ff             	test   %rdi,%rdi
    7737:	74 c3                	je     76fc <fwp_args37+0xc>
    7739:	0f b6 0a             	movzbl (%rdx),%ecx
    773c:	80 f9 02             	cmp    $0x2,%cl
    773f:	74 2f                	je     7770 <fwp_args37+0x80>
    7741:	80 f9 01             	cmp    $0x1,%cl
    7744:	75 b6                	jne    76fc <fwp_args37+0xc>
    7746:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7749:	0f b7 c0             	movzwl %ax,%eax
    774c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    774f:	48 0f af c1          	imul   %rcx,%rax
    7753:	48 c1 e8 20          	shr    $0x20,%rax
    7757:	48 39 d0             	cmp    %rdx,%rax
    775a:	73 a0                	jae    76fc <fwp_args37+0xc>
    775c:	48 01 c7             	add    %rax,%rdi
    775f:	0f b6 07             	movzbl (%rdi),%eax
    7762:	84 c0                	test   %al,%al
    7764:	74 96                	je     76fc <fwp_args37+0xc>
    7766:	3c fd                	cmp    $0xfd,%al
    7768:	77 0c                	ja     7776 <fwp_args37+0x86>
    776a:	83 c0 01             	add    $0x1,%eax
    776d:	88 07                	mov    %al,(%rdi)
    776f:	c3                   	ret
    7770:	66 85 c0             	test   %ax,%ax
    7773:	74 ea                	je     775f <fwp_args37+0x6f>
    7775:	c3                   	ret
    7776:	e9 b5 dc ff ff       	jmp    5430 <fwp_rc_wide_dup>
    777b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007780 <fwp_caps37>:
    7780:	f3 0f 1e fa          	endbr64
    7784:	48 83 ec 18          	sub    $0x18,%rsp
    7788:	8b 57 04             	mov    0x4(%rdi),%edx
    778b:	48 89 f8             	mov    %rdi,%rax
    778e:	85 d2                	test   %edx,%edx
    7790:	0f 84 9a 00 00 00    	je     7830 <fwp_caps37+0xb0>
    7796:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    779a:	85 f6                	test   %esi,%esi
    779c:	0f 85 9e 00 00 00    	jne    7840 <fwp_caps37+0xc0>
    77a2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    77a7:	e8 44 f7 ff ff       	call   6ef0 <fwp_drop4>
    77ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    77b1:	48 8b 0d e0 d3 01 00 	mov    0x1d3e0(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    77b8:	48 89 c2             	mov    %rax,%rdx
    77bb:	48 2b 15 ae d3 01 00 	sub    0x1d3ae(%rip),%rdx        # 24b70 <fwp_heap+0x13b0>
    77c2:	48 c1 e1 10          	shl    $0x10,%rcx
    77c6:	48 39 ca             	cmp    %rcx,%rdx
    77c9:	73 6d                	jae    7838 <fwp_caps37+0xb8>
    77cb:	48 89 d1             	mov    %rdx,%rcx
    77ce:	48 c1 e9 10          	shr    $0x10,%rcx
    77d2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    77d6:	48 8b 0d db d3 01 00 	mov    0x1d3db(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    77dd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    77e1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    77e5:	48 85 f6             	test   %rsi,%rsi
    77e8:	74 4e                	je     7838 <fwp_caps37+0xb8>
    77ea:	0f b6 39             	movzbl (%rcx),%edi
    77ed:	40 80 ff 02          	cmp    $0x2,%dil
    77f1:	0f 84 b9 00 00 00    	je     78b0 <fwp_caps37+0x130>
    77f7:	40 80 ff 01          	cmp    $0x1,%dil
    77fb:	75 3b                	jne    7838 <fwp_caps37+0xb8>
    77fd:	8b 79 18             	mov    0x18(%rcx),%edi
    7800:	0f b7 d2             	movzwl %dx,%edx
    7803:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7806:	48 0f af d7          	imul   %rdi,%rdx
    780a:	48 c1 ea 20          	shr    $0x20,%rdx
    780e:	48 39 ca             	cmp    %rcx,%rdx
    7811:	73 25                	jae    7838 <fwp_caps37+0xb8>
    7813:	48 01 d6             	add    %rdx,%rsi
    7816:	80 3e 01             	cmpb   $0x1,(%rsi)
    7819:	75 1d                	jne    7838 <fwp_caps37+0xb8>
    781b:	48 89 c7             	mov    %rax,%rdi
    781e:	48 83 c4 18          	add    $0x18,%rsp
    7822:	e9 69 df ff ff       	jmp    5790 <fwp_mem_free>
    7827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    782e:	00 00 
    7830:	85 f6                	test   %esi,%esi
    7832:	0f 84 79 ff ff ff    	je     77b1 <fwp_caps37+0x31>
    7838:	48 83 c4 18          	add    $0x18,%rsp
    783c:	c3                   	ret
    783d:	0f 1f 00             	nopl   (%rax)
    7840:	48 8b 05 51 d3 01 00 	mov    0x1d351(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    7847:	48 2b 3d 22 d3 01 00 	sub    0x1d322(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    784e:	48 c1 e0 10          	shl    $0x10,%rax
    7852:	48 39 c7             	cmp    %rax,%rdi
    7855:	73 e1                	jae    7838 <fwp_caps37+0xb8>
    7857:	48 89 f8             	mov    %rdi,%rax
    785a:	48 c1 e8 10          	shr    $0x10,%rax
    785e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7862:	48 8b 05 4f d3 01 00 	mov    0x1d34f(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    7869:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    786d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7871:	48 85 c0             	test   %rax,%rax
    7874:	74 c2                	je     7838 <fwp_caps37+0xb8>
    7876:	0f b6 0a             	movzbl (%rdx),%ecx
    7879:	80 f9 02             	cmp    $0x2,%cl
    787c:	74 42                	je     78c0 <fwp_caps37+0x140>
    787e:	80 f9 01             	cmp    $0x1,%cl
    7881:	75 b5                	jne    7838 <fwp_caps37+0xb8>
    7883:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7886:	0f b7 ff             	movzwl %di,%edi
    7889:	8b 52 1c             	mov    0x1c(%rdx),%edx
    788c:	48 0f af f9          	imul   %rcx,%rdi
    7890:	48 c1 ef 20          	shr    $0x20,%rdi
    7894:	48 39 d7             	cmp    %rdx,%rdi
    7897:	73 9f                	jae    7838 <fwp_caps37+0xb8>
    7899:	48 01 f8             	add    %rdi,%rax
    789c:	0f b6 10             	movzbl (%rax),%edx
    789f:	84 d2                	test   %dl,%dl
    78a1:	74 95                	je     7838 <fwp_caps37+0xb8>
    78a3:	80 fa fd             	cmp    $0xfd,%dl
    78a6:	77 23                	ja     78cb <fwp_caps37+0x14b>
    78a8:	83 c2 01             	add    $0x1,%edx
    78ab:	88 10                	mov    %dl,(%rax)
    78ad:	eb 89                	jmp    7838 <fwp_caps37+0xb8>
    78af:	90                   	nop
    78b0:	66 85 d2             	test   %dx,%dx
    78b3:	0f 85 7f ff ff ff    	jne    7838 <fwp_caps37+0xb8>
    78b9:	e9 58 ff ff ff       	jmp    7816 <fwp_caps37+0x96>
    78be:	66 90                	xchg   %ax,%ax
    78c0:	66 85 ff             	test   %di,%di
    78c3:	0f 85 6f ff ff ff    	jne    7838 <fwp_caps37+0xb8>
    78c9:	eb d1                	jmp    789c <fwp_caps37+0x11c>
    78cb:	48 89 c7             	mov    %rax,%rdi
    78ce:	48 83 c4 18          	add    $0x18,%rsp
    78d2:	e9 59 db ff ff       	jmp    5430 <fwp_rc_wide_dup>
    78d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    78de:	00 00 

00000000000078e0 <fwp_drop0>:
    78e0:	f3 0f 1e fa          	endbr64
    78e4:	48 8b 15 ad d2 01 00 	mov    0x1d2ad(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    78eb:	48 89 f8             	mov    %rdi,%rax
    78ee:	48 2b 05 7b d2 01 00 	sub    0x1d27b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    78f5:	48 c1 e2 10          	shl    $0x10,%rdx
    78f9:	48 39 d0             	cmp    %rdx,%rax
    78fc:	0f 83 36 01 00 00    	jae    7a38 <fwp_drop0+0x158>
    7902:	48 83 ec 18          	sub    $0x18,%rsp
    7906:	48 8d 35 b3 be 01 00 	lea    0x1beb3(%rip),%rsi        # 237c0 <fwp_heap>
    790d:	48 89 c2             	mov    %rax,%rdx
    7910:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7917:	48 c1 ea 10          	shr    $0x10,%rdx
    791b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    791f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7923:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7927:	48 85 d2             	test   %rdx,%rdx
    792a:	74 42                	je     796e <fwp_drop0+0x8e>
    792c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7930:	41 80 f8 02          	cmp    $0x2,%r8b
    7934:	74 42                	je     7978 <fwp_drop0+0x98>
    7936:	41 80 f8 01          	cmp    $0x1,%r8b
    793a:	75 32                	jne    796e <fwp_drop0+0x8e>
    793c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7940:	0f b7 c0             	movzwl %ax,%eax
    7943:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7946:	49 0f af c0          	imul   %r8,%rax
    794a:	48 c1 e8 20          	shr    $0x20,%rax
    794e:	48 39 c8             	cmp    %rcx,%rax
    7951:	73 1b                	jae    796e <fwp_drop0+0x8e>
    7953:	48 01 c2             	add    %rax,%rdx
    7956:	0f b6 02             	movzbl (%rdx),%eax
    7959:	84 c0                	test   %al,%al
    795b:	74 11                	je     796e <fwp_drop0+0x8e>
    795d:	3c 01                	cmp    $0x1,%al
    795f:	74 27                	je     7988 <fwp_drop0+0xa8>
    7961:	3c ff                	cmp    $0xff,%al
    7963:	0f 84 e7 00 00 00    	je     7a50 <fwp_drop0+0x170>
    7969:	83 e8 01             	sub    $0x1,%eax
    796c:	88 02                	mov    %al,(%rdx)
    796e:	48 83 c4 18          	add    $0x18,%rsp
    7972:	c3                   	ret
    7973:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7978:	66 85 c0             	test   %ax,%ax
    797b:	74 d9                	je     7956 <fwp_drop0+0x76>
    797d:	48 83 c4 18          	add    $0x18,%rsp
    7981:	c3                   	ret
    7982:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7988:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    798f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7996:	48 89 f8             	mov    %rdi,%rax
    7999:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    799d:	48 29 c8             	sub    %rcx,%rax
    79a0:	48 c1 e2 10          	shl    $0x10,%rdx
    79a4:	48 39 d0             	cmp    %rdx,%rax
    79a7:	73 71                	jae    7a1a <fwp_drop0+0x13a>
    79a9:	49 89 c2             	mov    %rax,%r10
    79ac:	49 c1 ea 10          	shr    $0x10,%r10
    79b0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    79b4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    79b8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    79bc:	4d 85 d2             	test   %r10,%r10
    79bf:	74 59                	je     7a1a <fwp_drop0+0x13a>
    79c1:	45 0f b6 19          	movzbl (%r9),%r11d
    79c5:	41 80 fb 02          	cmp    $0x2,%r11b
    79c9:	74 75                	je     7a40 <fwp_drop0+0x160>
    79cb:	41 80 fb 01          	cmp    $0x1,%r11b
    79cf:	75 49                	jne    7a1a <fwp_drop0+0x13a>
    79d1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    79d5:	0f b7 c0             	movzwl %ax,%eax
    79d8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    79dc:	49 0f af c3          	imul   %r11,%rax
    79e0:	48 c1 e8 20          	shr    $0x20,%rax
    79e4:	4c 39 c8             	cmp    %r9,%rax
    79e7:	73 31                	jae    7a1a <fwp_drop0+0x13a>
    79e9:	49 01 c2             	add    %rax,%r10
    79ec:	41 80 3a 01          	cmpb   $0x1,(%r10)
    79f0:	75 28                	jne    7a1a <fwp_drop0+0x13a>
    79f2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    79f7:	e8 94 dd ff ff       	call   5790 <fwp_mem_free>
    79fc:	48 8d 35 bd bd 01 00 	lea    0x1bdbd(%rip),%rsi        # 237c0 <fwp_heap>
    7a03:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7a08:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7a0f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7a16:	48 c1 e2 10          	shl    $0x10,%rdx
    7a1a:	4c 89 c0             	mov    %r8,%rax
    7a1d:	48 29 c8             	sub    %rcx,%rax
    7a20:	48 39 d0             	cmp    %rdx,%rax
    7a23:	0f 83 45 ff ff ff    	jae    796e <fwp_drop0+0x8e>
    7a29:	4c 89 c7             	mov    %r8,%rdi
    7a2c:	e9 dc fe ff ff       	jmp    790d <fwp_drop0+0x2d>
    7a31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a38:	c3                   	ret
    7a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a40:	66 85 c0             	test   %ax,%ax
    7a43:	75 d5                	jne    7a1a <fwp_drop0+0x13a>
    7a45:	eb a5                	jmp    79ec <fwp_drop0+0x10c>
    7a47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a4e:	00 00 
    7a50:	48 89 d0             	mov    %rdx,%rax
    7a53:	48 c1 e8 11          	shr    $0x11,%rax
    7a57:	48 31 d0             	xor    %rdx,%rax
    7a5a:	48 89 c1             	mov    %rax,%rcx
    7a5d:	48 c1 e9 09          	shr    $0x9,%rcx
    7a61:	48 31 c8             	xor    %rcx,%rax
    7a64:	0f b6 c8             	movzbl %al,%ecx
    7a67:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7a6e:	00 
    7a6f:	48 85 c0             	test   %rax,%rax
    7a72:	75 15                	jne    7a89 <fwp_drop0+0x1a9>
    7a74:	eb 4e                	jmp    7ac4 <fwp_drop0+0x1e4>
    7a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a7d:	00 00 00 
    7a80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7a84:	48 85 c0             	test   %rax,%rax
    7a87:	74 3b                	je     7ac4 <fwp_drop0+0x1e4>
    7a89:	48 89 c1             	mov    %rax,%rcx
    7a8c:	48 39 10             	cmp    %rdx,(%rax)
    7a8f:	75 ef                	jne    7a80 <fwp_drop0+0x1a0>
    7a91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7a99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7a9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7aa4:	0f 85 c4 fe ff ff    	jne    796e <fwp_drop0+0x8e>
    7aaa:	48 89 d7             	mov    %rdx,%rdi
    7aad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ab2:	e8 99 da ff ff       	call   5550 <fwp_rc_forget_slot>
    7ab7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7abc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7abf:	e9 aa fe ff ff       	jmp    796e <fwp_drop0+0x8e>
    7ac4:	48 8d 3d c5 7d 00 00 	lea    0x7dc5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7acb:	e8 20 c9 ff ff       	call   43f0 <fwp_trap>

0000000000007ad0 <fwp_drop1>:
    7ad0:	f3 0f 1e fa          	endbr64
    7ad4:	48 8b 15 bd d0 01 00 	mov    0x1d0bd(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7adb:	48 89 f8             	mov    %rdi,%rax
    7ade:	48 2b 05 8b d0 01 00 	sub    0x1d08b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7ae5:	48 c1 e2 10          	shl    $0x10,%rdx
    7ae9:	48 39 d0             	cmp    %rdx,%rax
    7aec:	0f 83 36 01 00 00    	jae    7c28 <fwp_drop1+0x158>
    7af2:	48 83 ec 18          	sub    $0x18,%rsp
    7af6:	48 8d 35 c3 bc 01 00 	lea    0x1bcc3(%rip),%rsi        # 237c0 <fwp_heap>
    7afd:	48 89 c2             	mov    %rax,%rdx
    7b00:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7b07:	48 c1 ea 10          	shr    $0x10,%rdx
    7b0b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b0f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7b13:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b17:	48 85 d2             	test   %rdx,%rdx
    7b1a:	74 42                	je     7b5e <fwp_drop1+0x8e>
    7b1c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7b20:	41 80 f8 02          	cmp    $0x2,%r8b
    7b24:	74 42                	je     7b68 <fwp_drop1+0x98>
    7b26:	41 80 f8 01          	cmp    $0x1,%r8b
    7b2a:	75 32                	jne    7b5e <fwp_drop1+0x8e>
    7b2c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7b30:	0f b7 c0             	movzwl %ax,%eax
    7b33:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b36:	49 0f af c0          	imul   %r8,%rax
    7b3a:	48 c1 e8 20          	shr    $0x20,%rax
    7b3e:	48 39 c8             	cmp    %rcx,%rax
    7b41:	73 1b                	jae    7b5e <fwp_drop1+0x8e>
    7b43:	48 01 c2             	add    %rax,%rdx
    7b46:	0f b6 02             	movzbl (%rdx),%eax
    7b49:	84 c0                	test   %al,%al
    7b4b:	74 11                	je     7b5e <fwp_drop1+0x8e>
    7b4d:	3c 01                	cmp    $0x1,%al
    7b4f:	74 27                	je     7b78 <fwp_drop1+0xa8>
    7b51:	3c ff                	cmp    $0xff,%al
    7b53:	0f 84 e7 00 00 00    	je     7c40 <fwp_drop1+0x170>
    7b59:	83 e8 01             	sub    $0x1,%eax
    7b5c:	88 02                	mov    %al,(%rdx)
    7b5e:	48 83 c4 18          	add    $0x18,%rsp
    7b62:	c3                   	ret
    7b63:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b68:	66 85 c0             	test   %ax,%ax
    7b6b:	74 d9                	je     7b46 <fwp_drop1+0x76>
    7b6d:	48 83 c4 18          	add    $0x18,%rsp
    7b71:	c3                   	ret
    7b72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b78:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b7f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b86:	48 89 f8             	mov    %rdi,%rax
    7b89:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7b8d:	48 29 c8             	sub    %rcx,%rax
    7b90:	48 c1 e2 10          	shl    $0x10,%rdx
    7b94:	48 39 d0             	cmp    %rdx,%rax
    7b97:	73 71                	jae    7c0a <fwp_drop1+0x13a>
    7b99:	49 89 c2             	mov    %rax,%r10
    7b9c:	49 c1 ea 10          	shr    $0x10,%r10
    7ba0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7ba4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7ba8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7bac:	4d 85 d2             	test   %r10,%r10
    7baf:	74 59                	je     7c0a <fwp_drop1+0x13a>
    7bb1:	45 0f b6 19          	movzbl (%r9),%r11d
    7bb5:	41 80 fb 02          	cmp    $0x2,%r11b
    7bb9:	74 75                	je     7c30 <fwp_drop1+0x160>
    7bbb:	41 80 fb 01          	cmp    $0x1,%r11b
    7bbf:	75 49                	jne    7c0a <fwp_drop1+0x13a>
    7bc1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7bc5:	0f b7 c0             	movzwl %ax,%eax
    7bc8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7bcc:	49 0f af c3          	imul   %r11,%rax
    7bd0:	48 c1 e8 20          	shr    $0x20,%rax
    7bd4:	4c 39 c8             	cmp    %r9,%rax
    7bd7:	73 31                	jae    7c0a <fwp_drop1+0x13a>
    7bd9:	49 01 c2             	add    %rax,%r10
    7bdc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7be0:	75 28                	jne    7c0a <fwp_drop1+0x13a>
    7be2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7be7:	e8 a4 db ff ff       	call   5790 <fwp_mem_free>
    7bec:	48 8d 35 cd bb 01 00 	lea    0x1bbcd(%rip),%rsi        # 237c0 <fwp_heap>
    7bf3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7bf8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7bff:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c06:	48 c1 e2 10          	shl    $0x10,%rdx
    7c0a:	4c 89 c0             	mov    %r8,%rax
    7c0d:	48 29 c8             	sub    %rcx,%rax
    7c10:	48 39 d0             	cmp    %rdx,%rax
    7c13:	0f 83 45 ff ff ff    	jae    7b5e <fwp_drop1+0x8e>
    7c19:	4c 89 c7             	mov    %r8,%rdi
    7c1c:	e9 dc fe ff ff       	jmp    7afd <fwp_drop1+0x2d>
    7c21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c28:	c3                   	ret
    7c29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c30:	66 85 c0             	test   %ax,%ax
    7c33:	75 d5                	jne    7c0a <fwp_drop1+0x13a>
    7c35:	eb a5                	jmp    7bdc <fwp_drop1+0x10c>
    7c37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c3e:	00 00 
    7c40:	48 89 d0             	mov    %rdx,%rax
    7c43:	48 c1 e8 11          	shr    $0x11,%rax
    7c47:	48 31 d0             	xor    %rdx,%rax
    7c4a:	48 89 c1             	mov    %rax,%rcx
    7c4d:	48 c1 e9 09          	shr    $0x9,%rcx
    7c51:	48 31 c8             	xor    %rcx,%rax
    7c54:	0f b6 c8             	movzbl %al,%ecx
    7c57:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7c5e:	00 
    7c5f:	48 85 c0             	test   %rax,%rax
    7c62:	75 25                	jne    7c89 <fwp_drop1+0x1b9>
    7c64:	eb 5e                	jmp    7cc4 <fwp_drop1+0x1f4>
    7c66:	0f 1f 40 00          	nopl   0x0(%rax)
    7c6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c71:	00 00 00 00 
    7c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c7c:	00 00 00 00 
    7c80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7c84:	48 85 c0             	test   %rax,%rax
    7c87:	74 3b                	je     7cc4 <fwp_drop1+0x1f4>
    7c89:	48 89 c1             	mov    %rax,%rcx
    7c8c:	48 39 10             	cmp    %rdx,(%rax)
    7c8f:	75 ef                	jne    7c80 <fwp_drop1+0x1b0>
    7c91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7c99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7c9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ca4:	0f 85 b4 fe ff ff    	jne    7b5e <fwp_drop1+0x8e>
    7caa:	48 89 d7             	mov    %rdx,%rdi
    7cad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7cb2:	e8 99 d8 ff ff       	call   5550 <fwp_rc_forget_slot>
    7cb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7cbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7cbf:	e9 9a fe ff ff       	jmp    7b5e <fwp_drop1+0x8e>
    7cc4:	48 8d 3d c5 7b 00 00 	lea    0x7bc5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7ccb:	e8 20 c7 ff ff       	call   43f0 <fwp_trap>

0000000000007cd0 <fwp_drop10>:
    7cd0:	48 8b 0d c1 ce 01 00 	mov    0x1cec1(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    7cd7:	48 89 f8             	mov    %rdi,%rax
    7cda:	48 2b 05 8f ce 01 00 	sub    0x1ce8f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7ce1:	48 c1 e1 10          	shl    $0x10,%rcx
    7ce5:	48 39 c8             	cmp    %rcx,%rax
    7ce8:	0f 83 c2 01 00 00    	jae    7eb0 <fwp_drop10+0x1e0>
    7cee:	48 83 ec 18          	sub    $0x18,%rsp
    7cf2:	48 89 fa             	mov    %rdi,%rdx
    7cf5:	48 8d 35 c4 ba 01 00 	lea    0x1bac4(%rip),%rsi        # 237c0 <fwp_heap>
    7cfc:	48 89 c1             	mov    %rax,%rcx
    7cff:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7d06:	48 c1 e9 10          	shr    $0x10,%rcx
    7d0a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7d0e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7d12:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7d16:	48 85 c9             	test   %rcx,%rcx
    7d19:	74 46                	je     7d61 <fwp_drop10+0x91>
    7d1b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7d1f:	41 80 f9 02          	cmp    $0x2,%r9b
    7d23:	0f 84 d7 00 00 00    	je     7e00 <fwp_drop10+0x130>
    7d29:	41 80 f9 01          	cmp    $0x1,%r9b
    7d2d:	75 32                	jne    7d61 <fwp_drop10+0x91>
    7d2f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7d33:	0f b7 c0             	movzwl %ax,%eax
    7d36:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7d39:	49 0f af c1          	imul   %r9,%rax
    7d3d:	48 c1 e8 20          	shr    $0x20,%rax
    7d41:	48 39 f8             	cmp    %rdi,%rax
    7d44:	73 1b                	jae    7d61 <fwp_drop10+0x91>
    7d46:	48 01 c1             	add    %rax,%rcx
    7d49:	0f b6 01             	movzbl (%rcx),%eax
    7d4c:	84 c0                	test   %al,%al
    7d4e:	74 11                	je     7d61 <fwp_drop10+0x91>
    7d50:	3c 01                	cmp    $0x1,%al
    7d52:	74 1c                	je     7d70 <fwp_drop10+0xa0>
    7d54:	3c ff                	cmp    $0xff,%al
    7d56:	0f 84 5c 01 00 00    	je     7eb8 <fwp_drop10+0x1e8>
    7d5c:	83 e8 01             	sub    $0x1,%eax
    7d5f:	88 01                	mov    %al,(%rcx)
    7d61:	48 83 c4 18          	add    $0x18,%rsp
    7d65:	c3                   	ret
    7d66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d6d:	00 00 00 
    7d70:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7d77:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7d7e:	48 89 d0             	mov    %rdx,%rax
    7d81:	49 89 d1             	mov    %rdx,%r9
    7d84:	48 c1 e1 10          	shl    $0x10,%rcx
    7d88:	48 29 f8             	sub    %rdi,%rax
    7d8b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7d8f:	78 7f                	js     7e10 <fwp_drop10+0x140>
    7d91:	48 39 c8             	cmp    %rcx,%rax
    7d94:	73 cb                	jae    7d61 <fwp_drop10+0x91>
    7d96:	48 89 c1             	mov    %rax,%rcx
    7d99:	48 c1 e9 10          	shr    $0x10,%rcx
    7d9d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7da1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7da5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7da9:	48 85 f6             	test   %rsi,%rsi
    7dac:	74 b3                	je     7d61 <fwp_drop10+0x91>
    7dae:	0f b6 39             	movzbl (%rcx),%edi
    7db1:	40 80 ff 02          	cmp    $0x2,%dil
    7db5:	74 39                	je     7df0 <fwp_drop10+0x120>
    7db7:	40 80 ff 01          	cmp    $0x1,%dil
    7dbb:	75 a4                	jne    7d61 <fwp_drop10+0x91>
    7dbd:	8b 79 18             	mov    0x18(%rcx),%edi
    7dc0:	0f b7 c0             	movzwl %ax,%eax
    7dc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7dc6:	48 0f af c7          	imul   %rdi,%rax
    7dca:	48 c1 e8 20          	shr    $0x20,%rax
    7dce:	48 39 c8             	cmp    %rcx,%rax
    7dd1:	73 8e                	jae    7d61 <fwp_drop10+0x91>
    7dd3:	48 01 c6             	add    %rax,%rsi
    7dd6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7dd9:	75 86                	jne    7d61 <fwp_drop10+0x91>
    7ddb:	48 89 d7             	mov    %rdx,%rdi
    7dde:	48 83 c4 18          	add    $0x18,%rsp
    7de2:	e9 a9 d9 ff ff       	jmp    5790 <fwp_mem_free>
    7de7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7dee:	00 00 
    7df0:	66 85 c0             	test   %ax,%ax
    7df3:	74 e1                	je     7dd6 <fwp_drop10+0x106>
    7df5:	48 83 c4 18          	add    $0x18,%rsp
    7df9:	c3                   	ret
    7dfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e00:	66 85 c0             	test   %ax,%ax
    7e03:	0f 84 40 ff ff ff    	je     7d49 <fwp_drop10+0x79>
    7e09:	48 83 c4 18          	add    $0x18,%rsp
    7e0d:	c3                   	ret
    7e0e:	66 90                	xchg   %ax,%ax
    7e10:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7e14:	48 39 c8             	cmp    %rcx,%rax
    7e17:	73 74                	jae    7e8d <fwp_drop10+0x1bd>
    7e19:	49 89 c2             	mov    %rax,%r10
    7e1c:	49 c1 ea 10          	shr    $0x10,%r10
    7e20:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7e24:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7e28:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7e2c:	4d 85 d2             	test   %r10,%r10
    7e2f:	74 5c                	je     7e8d <fwp_drop10+0x1bd>
    7e31:	45 0f b6 18          	movzbl (%r8),%r11d
    7e35:	41 80 fb 02          	cmp    $0x2,%r11b
    7e39:	74 6d                	je     7ea8 <fwp_drop10+0x1d8>
    7e3b:	41 80 fb 01          	cmp    $0x1,%r11b
    7e3f:	75 4c                	jne    7e8d <fwp_drop10+0x1bd>
    7e41:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7e45:	0f b7 c0             	movzwl %ax,%eax
    7e48:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7e4c:	49 0f af c3          	imul   %r11,%rax
    7e50:	48 c1 e8 20          	shr    $0x20,%rax
    7e54:	4c 39 c0             	cmp    %r8,%rax
    7e57:	73 34                	jae    7e8d <fwp_drop10+0x1bd>
    7e59:	49 01 c2             	add    %rax,%r10
    7e5c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7e60:	75 2b                	jne    7e8d <fwp_drop10+0x1bd>
    7e62:	4c 89 cf             	mov    %r9,%rdi
    7e65:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e6a:	e8 21 d9 ff ff       	call   5790 <fwp_mem_free>
    7e6f:	48 8d 35 4a b9 01 00 	lea    0x1b94a(%rip),%rsi        # 237c0 <fwp_heap>
    7e76:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e7b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7e82:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7e89:	48 c1 e1 10          	shl    $0x10,%rcx
    7e8d:	48 89 d0             	mov    %rdx,%rax
    7e90:	48 29 f8             	sub    %rdi,%rax
    7e93:	48 39 c8             	cmp    %rcx,%rax
    7e96:	0f 82 60 fe ff ff    	jb     7cfc <fwp_drop10+0x2c>
    7e9c:	e9 c0 fe ff ff       	jmp    7d61 <fwp_drop10+0x91>
    7ea1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ea8:	66 85 c0             	test   %ax,%ax
    7eab:	75 e0                	jne    7e8d <fwp_drop10+0x1bd>
    7ead:	eb ad                	jmp    7e5c <fwp_drop10+0x18c>
    7eaf:	90                   	nop
    7eb0:	c3                   	ret
    7eb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7eb8:	48 89 c8             	mov    %rcx,%rax
    7ebb:	48 c1 e8 11          	shr    $0x11,%rax
    7ebf:	48 31 c8             	xor    %rcx,%rax
    7ec2:	48 89 c2             	mov    %rax,%rdx
    7ec5:	48 c1 ea 09          	shr    $0x9,%rdx
    7ec9:	48 31 d0             	xor    %rdx,%rax
    7ecc:	0f b6 d0             	movzbl %al,%edx
    7ecf:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7ed6:	00 
    7ed7:	48 85 c0             	test   %rax,%rax
    7eda:	75 0d                	jne    7ee9 <fwp_drop10+0x219>
    7edc:	eb 46                	jmp    7f24 <fwp_drop10+0x254>
    7ede:	66 90                	xchg   %ax,%ax
    7ee0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7ee4:	48 85 c0             	test   %rax,%rax
    7ee7:	74 3b                	je     7f24 <fwp_drop10+0x254>
    7ee9:	48 89 c2             	mov    %rax,%rdx
    7eec:	48 39 08             	cmp    %rcx,(%rax)
    7eef:	75 ef                	jne    7ee0 <fwp_drop10+0x210>
    7ef1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ef5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7ef9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7efd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7f04:	0f 85 57 fe ff ff    	jne    7d61 <fwp_drop10+0x91>
    7f0a:	48 89 cf             	mov    %rcx,%rdi
    7f0d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7f12:	e8 39 d6 ff ff       	call   5550 <fwp_rc_forget_slot>
    7f17:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7f1c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7f1f:	e9 3d fe ff ff       	jmp    7d61 <fwp_drop10+0x91>
    7f24:	48 8d 3d 65 79 00 00 	lea    0x7965(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7f2b:	e8 c0 c4 ff ff       	call   43f0 <fwp_trap>

0000000000007f30 <f37>:
    7f30:	41 57                	push   %r15
    7f32:	41 56                	push   %r14
    7f34:	41 55                	push   %r13
    7f36:	41 54                	push   %r12
    7f38:	55                   	push   %rbp
    7f39:	53                   	push   %rbx
    7f3a:	48 83 ec 38          	sub    $0x38,%rsp
    7f3e:	48 8b 15 53 cc 01 00 	mov    0x1cc53(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7f45:	48 8b 0d 24 cc 01 00 	mov    0x1cc24(%rip),%rcx        # 24b70 <fwp_heap+0x13b0>
    7f4c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7f53:	00 00 
    7f55:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7f5a:	49 89 fc             	mov    %rdi,%r12
    7f5d:	48 c1 e2 10          	shl    $0x10,%rdx
    7f61:	48 85 ff             	test   %rdi,%rdi
    7f64:	0f 84 bc 02 00 00    	je     8226 <f37+0x2f6>
    7f6a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7f6f:	48 89 d8             	mov    %rbx,%rax
    7f72:	48 29 c8             	sub    %rcx,%rax
    7f75:	48 39 d0             	cmp    %rdx,%rax
    7f78:	0f 83 72 03 00 00    	jae    82f0 <f37+0x3c0>
    7f7e:	48 89 c2             	mov    %rax,%rdx
    7f81:	48 c1 ea 10          	shr    $0x10,%rdx
    7f85:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f89:	48 8b 15 28 cc 01 00 	mov    0x1cc28(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7f90:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f94:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7f98:	48 85 ff             	test   %rdi,%rdi
    7f9b:	0f 84 4f 03 00 00    	je     82f0 <f37+0x3c0>
    7fa1:	0f b6 0a             	movzbl (%rdx),%ecx
    7fa4:	80 f9 02             	cmp    $0x2,%cl
    7fa7:	0f 84 53 02 00 00    	je     8200 <f37+0x2d0>
    7fad:	80 f9 01             	cmp    $0x1,%cl
    7fb0:	75 24                	jne    7fd6 <f37+0xa6>
    7fb2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fb5:	0f b7 c0             	movzwl %ax,%eax
    7fb8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fbb:	48 0f af c1          	imul   %rcx,%rax
    7fbf:	48 c1 e8 20          	shr    $0x20,%rax
    7fc3:	48 39 d0             	cmp    %rdx,%rax
    7fc6:	73 0e                	jae    7fd6 <f37+0xa6>
    7fc8:	48 01 c7             	add    %rax,%rdi
    7fcb:	0f b6 07             	movzbl (%rdi),%eax
    7fce:	84 c0                	test   %al,%al
    7fd0:	0f 85 ca 02 00 00    	jne    82a0 <f37+0x370>
    7fd6:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7fdb:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7fe0:	ba 01 00 00 00       	mov    $0x1,%edx
    7fe5:	48 85 db             	test   %rbx,%rbx
    7fe8:	74 13                	je     7ffd <f37+0xcd>
    7fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ff0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7ff4:	48 83 c2 01          	add    $0x1,%rdx
    7ff8:	48 85 db             	test   %rbx,%rbx
    7ffb:	75 f3                	jne    7ff0 <f37+0xc0>
    7ffd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8002:	48 85 c0             	test   %rax,%rax
    8005:	0f 84 15 03 00 00    	je     8320 <f37+0x3f0>
    800b:	31 db                	xor    %ebx,%ebx
    800d:	0f 1f 00             	nopl   (%rax)
    8010:	48 8b 40 10          	mov    0x10(%rax),%rax
    8014:	48 83 c3 01          	add    $0x1,%rbx
    8018:	48 85 c0             	test   %rax,%rax
    801b:	75 f3                	jne    8010 <f37+0xe0>
    801d:	48 39 d3             	cmp    %rdx,%rbx
    8020:	48 0f 47 da          	cmova  %rdx,%rbx
    8024:	48 89 d8             	mov    %rbx,%rax
    8027:	48 c1 e8 3c          	shr    $0x3c,%rax
    802b:	0f 85 8f 03 00 00    	jne    83c0 <f37+0x490>
    8031:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8035:	be 02 00 00 00       	mov    $0x2,%esi
    803a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8041:	00 
    8042:	e8 49 dc ff ff       	call   5c90 <fwp_heap_alloc>
    8047:	48 89 28             	mov    %rbp,(%rax)
    804a:	48 8b 15 47 cb 01 00 	mov    0x1cb47(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    8051:	49 89 c6             	mov    %rax,%r14
    8054:	48 2b 05 15 cb 01 00 	sub    0x1cb15(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    805b:	48 c1 e2 10          	shl    $0x10,%rdx
    805f:	48 39 d0             	cmp    %rdx,%rax
    8062:	73 57                	jae    80bb <f37+0x18b>
    8064:	48 89 c2             	mov    %rax,%rdx
    8067:	48 c1 ea 10          	shr    $0x10,%rdx
    806b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    806f:	48 8b 15 42 cb 01 00 	mov    0x1cb42(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    8076:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    807a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    807e:	48 85 ed             	test   %rbp,%rbp
    8081:	74 38                	je     80bb <f37+0x18b>
    8083:	0f b6 0a             	movzbl (%rdx),%ecx
    8086:	80 f9 02             	cmp    $0x2,%cl
    8089:	0f 84 51 02 00 00    	je     82e0 <f37+0x3b0>
    808f:	80 f9 01             	cmp    $0x1,%cl
    8092:	75 27                	jne    80bb <f37+0x18b>
    8094:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8097:	0f b7 c0             	movzwl %ax,%eax
    809a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    809d:	48 0f af c1          	imul   %rcx,%rax
    80a1:	48 c1 e8 20          	shr    $0x20,%rax
    80a5:	48 39 d0             	cmp    %rdx,%rax
    80a8:	73 11                	jae    80bb <f37+0x18b>
    80aa:	48 01 c5             	add    %rax,%rbp
    80ad:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    80b1:	0f 84 d5 02 00 00    	je     838c <f37+0x45c>
    80b7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    80bb:	48 85 db             	test   %rbx,%rbx
    80be:	74 5d                	je     811d <f37+0x1ed>
    80c0:	48 c1 e3 04          	shl    $0x4,%rbx
    80c4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    80c9:	4c 89 f5             	mov    %r14,%rbp
    80cc:	4d 89 e5             	mov    %r12,%r13
    80cf:	4c 01 f3             	add    %r14,%rbx
    80d2:	0f 1f 00             	nopl   (%rax)
    80d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80dc:	00 00 00 00 
    80e0:	49 8b 45 08          	mov    0x8(%r13),%rax
    80e4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    80e8:	48 83 c5 10          	add    $0x10,%rbp
    80ec:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    80f1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    80f5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    80f9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    80fe:	e8 dd e2 ff ff       	call   63e0 <w120>
    8103:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8108:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    810c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8110:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8114:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    8118:	48 39 dd             	cmp    %rbx,%rbp
    811b:	75 c3                	jne    80e0 <f37+0x1b0>
    811d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8122:	e8 c9 ed ff ff       	call   6ef0 <fwp_drop4>
    8127:	4c 89 e7             	mov    %r12,%rdi
    812a:	e8 c1 ed ff ff       	call   6ef0 <fwp_drop4>
    812f:	4c 89 f7             	mov    %r14,%rdi
    8132:	e8 69 e4 ff ff       	call   65a0 <w176.constprop.0>
    8137:	4c 89 f7             	mov    %r14,%rdi
    813a:	48 89 c3             	mov    %rax,%rbx
    813d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8143:	e8 88 fb ff ff       	call   7cd0 <fwp_drop10>
    8148:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    814e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8153:	31 ff                	xor    %edi,%edi
    8155:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    815a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    815e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8163:	e8 48 dc ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    8168:	48 8b 15 29 ca 01 00 	mov    0x1ca29(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    816f:	48 89 c5             	mov    %rax,%rbp
    8172:	48 2b 05 f7 c9 01 00 	sub    0x1c9f7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    8179:	48 c1 e2 10          	shl    $0x10,%rdx
    817d:	48 39 d0             	cmp    %rdx,%rax
    8180:	73 55                	jae    81d7 <f37+0x2a7>
    8182:	48 89 c2             	mov    %rax,%rdx
    8185:	48 c1 ea 10          	shr    $0x10,%rdx
    8189:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    818d:	48 8b 15 24 ca 01 00 	mov    0x1ca24(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    8194:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8198:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    819c:	48 85 db             	test   %rbx,%rbx
    819f:	74 36                	je     81d7 <f37+0x2a7>
    81a1:	0f b6 0a             	movzbl (%rdx),%ecx
    81a4:	80 f9 02             	cmp    $0x2,%cl
    81a7:	0f 84 1b 01 00 00    	je     82c8 <f37+0x398>
    81ad:	80 f9 01             	cmp    $0x1,%cl
    81b0:	75 25                	jne    81d7 <f37+0x2a7>
    81b2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81b5:	0f b7 c0             	movzwl %ax,%eax
    81b8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81bb:	48 0f af c1          	imul   %rcx,%rax
    81bf:	48 c1 e8 20          	shr    $0x20,%rax
    81c3:	48 39 d0             	cmp    %rdx,%rax
    81c6:	73 0f                	jae    81d7 <f37+0x2a7>
    81c8:	48 01 c3             	add    %rax,%rbx
    81cb:	80 3b ff             	cmpb   $0xff,(%rbx)
    81ce:	0f 84 ab 01 00 00    	je     837f <f37+0x44f>
    81d4:	c6 03 01             	movb   $0x1,(%rbx)
    81d7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    81dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    81e3:	00 00 
    81e5:	0f 85 d0 01 00 00    	jne    83bb <f37+0x48b>
    81eb:	48 83 c4 38          	add    $0x38,%rsp
    81ef:	48 89 e8             	mov    %rbp,%rax
    81f2:	5b                   	pop    %rbx
    81f3:	5d                   	pop    %rbp
    81f4:	41 5c                	pop    %r12
    81f6:	41 5d                	pop    %r13
    81f8:	41 5e                	pop    %r14
    81fa:	41 5f                	pop    %r15
    81fc:	c3                   	ret
    81fd:	0f 1f 00             	nopl   (%rax)
    8200:	66 85 c0             	test   %ax,%ax
    8203:	0f 85 cd fd ff ff    	jne    7fd6 <f37+0xa6>
    8209:	0f b6 07             	movzbl (%rdi),%eax
    820c:	84 c0                	test   %al,%al
    820e:	0f 84 c2 fd ff ff    	je     7fd6 <f37+0xa6>
    8214:	3c fd                	cmp    $0xfd,%al
    8216:	0f 87 95 01 00 00    	ja     83b1 <f37+0x481>
    821c:	83 c0 01             	add    $0x1,%eax
    821f:	88 07                	mov    %al,(%rdi)
    8221:	e9 b0 fd ff ff       	jmp    7fd6 <f37+0xa6>
    8226:	48 f7 d9             	neg    %rcx
    8229:	48 39 d1             	cmp    %rdx,%rcx
    822c:	0f 83 ee 00 00 00    	jae    8320 <f37+0x3f0>
    8232:	48 89 c8             	mov    %rcx,%rax
    8235:	48 c1 e8 10          	shr    $0x10,%rax
    8239:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    823d:	48 8b 05 74 c9 01 00 	mov    0x1c974(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    8244:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8248:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    824c:	48 85 ff             	test   %rdi,%rdi
    824f:	0f 84 cb 00 00 00    	je     8320 <f37+0x3f0>
    8255:	0f b6 02             	movzbl (%rdx),%eax
    8258:	3c 02                	cmp    $0x2,%al
    825a:	0f 84 9a 00 00 00    	je     82fa <f37+0x3ca>
    8260:	3c 01                	cmp    $0x1,%al
    8262:	0f 85 b8 00 00 00    	jne    8320 <f37+0x3f0>
    8268:	0f b7 c1             	movzwl %cx,%eax
    826b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    826e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8271:	48 0f af c1          	imul   %rcx,%rax
    8275:	48 c1 e8 20          	shr    $0x20,%rax
    8279:	48 39 d0             	cmp    %rdx,%rax
    827c:	0f 83 9e 00 00 00    	jae    8320 <f37+0x3f0>
    8282:	48 01 c7             	add    %rax,%rdi
    8285:	0f b6 07             	movzbl (%rdi),%eax
    8288:	84 c0                	test   %al,%al
    828a:	0f 84 90 00 00 00    	je     8320 <f37+0x3f0>
    8290:	31 db                	xor    %ebx,%ebx
    8292:	0f 1f 00             	nopl   (%rax)
    8295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    829c:	00 00 00 00 
    82a0:	3c fd                	cmp    $0xfd,%al
    82a2:	0f 87 f1 00 00 00    	ja     8399 <f37+0x469>
    82a8:	83 c0 01             	add    $0x1,%eax
    82ab:	88 07                	mov    %al,(%rdi)
    82ad:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    82b2:	31 d2                	xor    %edx,%edx
    82b4:	4d 85 e4             	test   %r12,%r12
    82b7:	0f 85 1e fd ff ff    	jne    7fdb <f37+0xab>
    82bd:	e9 3b fd ff ff       	jmp    7ffd <f37+0xcd>
    82c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    82c8:	66 85 c0             	test   %ax,%ax
    82cb:	0f 85 06 ff ff ff    	jne    81d7 <f37+0x2a7>
    82d1:	e9 f5 fe ff ff       	jmp    81cb <f37+0x29b>
    82d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    82dd:	00 00 00 
    82e0:	66 85 c0             	test   %ax,%ax
    82e3:	0f 85 d2 fd ff ff    	jne    80bb <f37+0x18b>
    82e9:	e9 bf fd ff ff       	jmp    80ad <f37+0x17d>
    82ee:	66 90                	xchg   %ax,%ax
    82f0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    82f5:	e9 e6 fc ff ff       	jmp    7fe0 <f37+0xb0>
    82fa:	66 85 c9             	test   %cx,%cx
    82fd:	75 21                	jne    8320 <f37+0x3f0>
    82ff:	0f b6 07             	movzbl (%rdi),%eax
    8302:	84 c0                	test   %al,%al
    8304:	74 1a                	je     8320 <f37+0x3f0>
    8306:	3c fd                	cmp    $0xfd,%al
    8308:	0f 87 be 00 00 00    	ja     83cc <f37+0x49c>
    830e:	83 c0 01             	add    $0x1,%eax
    8311:	88 07                	mov    %al,(%rdi)
    8313:	66 90                	xchg   %ax,%ax
    8315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    831c:	00 00 00 00 
    8320:	be 02 00 00 00       	mov    $0x2,%esi
    8325:	bf 08 00 00 00       	mov    $0x8,%edi
    832a:	e8 61 d9 ff ff       	call   5c90 <fwp_heap_alloc>
    832f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8336:	48 8b 15 5b c8 01 00 	mov    0x1c85b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    833d:	49 89 c6             	mov    %rax,%r14
    8340:	48 2b 05 29 c8 01 00 	sub    0x1c829(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    8347:	48 c1 e2 10          	shl    $0x10,%rdx
    834b:	48 39 d0             	cmp    %rdx,%rax
    834e:	73 53                	jae    83a3 <f37+0x473>
    8350:	48 89 c2             	mov    %rax,%rdx
    8353:	48 c1 ea 10          	shr    $0x10,%rdx
    8357:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    835b:	48 8b 15 56 c8 01 00 	mov    0x1c856(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    8362:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8366:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    836a:	48 85 ed             	test   %rbp,%rbp
    836d:	74 34                	je     83a3 <f37+0x473>
    836f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8376:	00 00 
    8378:	31 db                	xor    %ebx,%ebx
    837a:	e9 04 fd ff ff       	jmp    8083 <f37+0x153>
    837f:	48 89 df             	mov    %rbx,%rdi
    8382:	e8 c9 d1 ff ff       	call   5550 <fwp_rc_forget_slot>
    8387:	e9 48 fe ff ff       	jmp    81d4 <f37+0x2a4>
    838c:	48 89 ef             	mov    %rbp,%rdi
    838f:	e8 bc d1 ff ff       	call   5550 <fwp_rc_forget_slot>
    8394:	e9 1e fd ff ff       	jmp    80b7 <f37+0x187>
    8399:	e8 92 d0 ff ff       	call   5430 <fwp_rc_wide_dup>
    839e:	e9 0a ff ff ff       	jmp    82ad <f37+0x37d>
    83a3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    83aa:	00 00 
    83ac:	e9 6c fd ff ff       	jmp    811d <f37+0x1ed>
    83b1:	e8 7a d0 ff ff       	call   5430 <fwp_rc_wide_dup>
    83b6:	e9 1b fc ff ff       	jmp    7fd6 <f37+0xa6>
    83bb:	e8 a0 b0 ff ff       	call   3460 <__stack_chk_fail@plt>
    83c0:	48 8d 3d c9 6d 00 00 	lea    0x6dc9(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    83c7:	e8 24 c0 ff ff       	call   43f0 <fwp_trap>
    83cc:	e8 5f d0 ff ff       	call   5430 <fwp_rc_wide_dup>
    83d1:	e9 4a ff ff ff       	jmp    8320 <f37+0x3f0>
    83d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    83dd:	00 00 00 

00000000000083e0 <fwp_owned_entry37>:
    83e0:	f3 0f 1e fa          	endbr64
    83e4:	48 8b 3f             	mov    (%rdi),%rdi
    83e7:	e9 44 fb ff ff       	jmp    7f30 <f37>
    83ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000083f0 <e37>:
    83f0:	f3 0f 1e fa          	endbr64
    83f4:	53                   	push   %rbx
    83f5:	48 8b 1f             	mov    (%rdi),%rbx
    83f8:	48 89 df             	mov    %rbx,%rdi
    83fb:	e8 20 e2 ff ff       	call   6620 <fwp_rc_share>
    8400:	48 89 df             	mov    %rbx,%rdi
    8403:	e8 28 fb ff ff       	call   7f30 <f37>
    8408:	48 89 c3             	mov    %rax,%rbx
    840b:	48 89 c7             	mov    %rax,%rdi
    840e:	e8 0d e2 ff ff       	call   6620 <fwp_rc_share>
    8413:	48 89 d8             	mov    %rbx,%rax
    8416:	5b                   	pop    %rbx
    8417:	c3                   	ret
    8418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    841f:	00 

0000000000008420 <fwp_write>:
    8420:	41 57                	push   %r15
    8422:	41 56                	push   %r14
    8424:	41 55                	push   %r13
    8426:	41 54                	push   %r12
    8428:	55                   	push   %rbp
    8429:	53                   	push   %rbx
    842a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8431:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8438:	00 00 
    843a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8441:	00 
    8442:	49 89 d4             	mov    %rdx,%r12
    8445:	8b 12                	mov    (%rdx),%edx
    8447:	83 fa 19             	cmp    $0x19,%edx
    844a:	77 6a                	ja     84b6 <fwp_write+0x96>
    844c:	48 89 f5             	mov    %rsi,%rbp
    844f:	89 d0                	mov    %edx,%eax
    8451:	89 ce                	mov    %ecx,%esi
    8453:	48 89 fb             	mov    %rdi,%rbx
    8456:	48 8d 0d a3 76 00 00 	lea    0x76a3(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    845d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8461:	48 01 c8             	add    %rcx,%rax
    8464:	3e ff e0             	notrack jmp *%rax
    8467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    846e:	00 00 
    8470:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8474:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8478:	48 89 ca             	mov    %rcx,%rdx
    847b:	48 85 c9             	test   %rcx,%rcx
    847e:	0f 88 9c 0c 00 00    	js     9120 <fwp_write+0xd00>
    8484:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    848b:	00 
    848c:	48 89 c6             	mov    %rax,%rsi
    848f:	4c 89 e7             	mov    %r12,%rdi
    8492:	e8 a9 b5 ff ff       	call   3a40 <fwp_fmt_u128>
    8497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    849e:	00 00 
    84a0:	4c 89 e7             	mov    %r12,%rdi
    84a3:	e8 a8 af ff ff       	call   3450 <strlen@plt>
    84a8:	4c 89 e6             	mov    %r12,%rsi
    84ab:	48 89 df             	mov    %rbx,%rdi
    84ae:	48 89 c2             	mov    %rax,%rdx
    84b1:	e8 5a bd ff ff       	call   4210 <buf_put>
    84b6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    84bd:	00 
    84be:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    84c5:	00 00 
    84c7:	0f 85 28 04 00 00    	jne    88f5 <fwp_write+0x4d5>
    84cd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    84d4:	5b                   	pop    %rbx
    84d5:	5d                   	pop    %rbp
    84d6:	41 5c                	pop    %r12
    84d8:	41 5d                	pop    %r13
    84da:	41 5e                	pop    %r14
    84dc:	41 5f                	pop    %r15
    84de:	c3                   	ret
    84df:	90                   	nop
    84e0:	49 89 e9             	mov    %rbp,%r9
    84e3:	4c 8d 05 8b 6b 00 00 	lea    0x6b8b(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    84ea:	b9 00 02 00 00       	mov    $0x200,%ecx
    84ef:	ba 02 00 00 00       	mov    $0x2,%edx
    84f4:	be 00 02 00 00       	mov    $0x200,%esi
    84f9:	31 c0                	xor    %eax,%eax
    84fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8502:	00 
    8503:	e8 a8 ae ff ff       	call   33b0 <__snprintf_chk@plt>
    8508:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    850f:	00 
    8510:	e8 3b af ff ff       	call   3450 <strlen@plt>
    8515:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    851c:	00 
    851d:	48 89 df             	mov    %rbx,%rdi
    8520:	48 89 c2             	mov    %rax,%rdx
    8523:	e8 e8 bc ff ff       	call   4210 <buf_put>
    8528:	eb 8c                	jmp    84b6 <fwp_write+0x96>
    852a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8530:	49 89 e9             	mov    %rbp,%r9
    8533:	4c 8d 05 7b 6c 00 00 	lea    0x6c7b(%rip),%r8        # f1b5 <_IO_stdin_used+0x1b5>
    853a:	eb ae                	jmp    84ea <fwp_write+0xca>
    853c:	0f 1f 40 00          	nopl   0x0(%rax)
    8540:	83 fa 13             	cmp    $0x13,%edx
    8543:	48 8d 05 61 6c 00 00 	lea    0x6c61(%rip),%rax        # f1ab <_IO_stdin_used+0x1ab>
    854a:	48 8d 35 5f 6c 00 00 	lea    0x6c5f(%rip),%rsi        # f1b0 <_IO_stdin_used+0x1b0>
    8551:	ba 04 00 00 00       	mov    $0x4,%edx
    8556:	48 0f 44 f0          	cmove  %rax,%rsi
    855a:	45 31 ed             	xor    %r13d,%r13d
    855d:	e8 ae bc ff ff       	call   4210 <buf_put>
    8562:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8567:	0f 84 a3 08 00 00    	je     8e10 <fwp_write+0x9f0>
    856d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8572:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8577:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    857c:	48 89 df             	mov    %rbx,%rdi
    857f:	49 0f 44 c5          	cmove  %r13,%rax
    8583:	31 c9                	xor    %ecx,%ecx
    8585:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    858a:	e8 91 fe ff ff       	call   8420 <fwp_write>
    858f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8594:	0f 84 6e 09 00 00    	je     8f08 <fwp_write+0xae8>
    859a:	49 83 c5 01          	add    $0x1,%r13
    859e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    85a2:	0f 83 68 08 00 00    	jae    8e10 <fwp_write+0x9f0>
    85a8:	ba 02 00 00 00       	mov    $0x2,%edx
    85ad:	48 8d 35 41 6c 00 00 	lea    0x6c41(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    85b4:	48 89 df             	mov    %rbx,%rdi
    85b7:	e8 54 bc ff ff       	call   4210 <buf_put>
    85bc:	eb af                	jmp    856d <fwp_write+0x14d>
    85be:	66 90                	xchg   %ax,%ax
    85c0:	ba 06 00 00 00       	mov    $0x6,%edx
    85c5:	48 8d 35 02 6c 00 00 	lea    0x6c02(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    85cc:	48 83 c5 10          	add    $0x10,%rbp
    85d0:	e8 3b bc ff ff       	call   4210 <buf_put>
    85d5:	48 89 ef             	mov    %rbp,%rdi
    85d8:	e8 73 ae ff ff       	call   3450 <strlen@plt>
    85dd:	48 89 ee             	mov    %rbp,%rsi
    85e0:	48 89 df             	mov    %rbx,%rdi
    85e3:	48 89 c2             	mov    %rax,%rdx
    85e6:	e8 25 bc ff ff       	call   4210 <buf_put>
    85eb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    85f0:	ba 01 00 00 00       	mov    $0x1,%edx
    85f5:	48 89 df             	mov    %rbx,%rdi
    85f8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    85fd:	e8 0e bc ff ff       	call   4210 <buf_put>
    8602:	e9 af fe ff ff       	jmp    84b6 <fwp_write+0x96>
    8607:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    860e:	00 00 
    8610:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8617:	00 
    8618:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    861f:	00 00 
    8621:	0f 85 ce 02 00 00    	jne    88f5 <fwp_write+0x4d5>
    8627:	ba 0a 00 00 00       	mov    $0xa,%edx
    862c:	48 8d 35 87 6b 00 00 	lea    0x6b87(%rip),%rsi        # f1ba <_IO_stdin_used+0x1ba>
    8633:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    863a:	48 89 df             	mov    %rbx,%rdi
    863d:	5b                   	pop    %rbx
    863e:	5d                   	pop    %rbp
    863f:	41 5c                	pop    %r12
    8641:	41 5d                	pop    %r13
    8643:	41 5e                	pop    %r14
    8645:	41 5f                	pop    %r15
    8647:	e9 c4 bb ff ff       	jmp    4210 <buf_put>
    864c:	0f 1f 40 00          	nopl   0x0(%rax)
    8650:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8655:	4d 85 ed             	test   %r13,%r13
    8658:	0f 84 02 0c 00 00    	je     9260 <fwp_write+0xe40>
    865e:	48 8d 35 9d 6b 00 00 	lea    0x6b9d(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8665:	4c 89 ef             	mov    %r13,%rdi
    8668:	e8 c3 ae ff ff       	call   3530 <strcmp@plt>
    866d:	41 89 c1             	mov    %eax,%r9d
    8670:	85 c0                	test   %eax,%eax
    8672:	0f 84 6c 0c 00 00    	je     92e4 <fwp_write+0xec4>
    8678:	4c 89 ef             	mov    %r13,%rdi
    867b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8680:	e8 cb ad ff ff       	call   3450 <strlen@plt>
    8685:	4c 89 ee             	mov    %r13,%rsi
    8688:	48 89 df             	mov    %rbx,%rdi
    868b:	48 89 c2             	mov    %rax,%rdx
    868e:	e8 7d bb ff ff       	call   4210 <buf_put>
    8693:	ba 01 00 00 00       	mov    $0x1,%edx
    8698:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    869d:	48 89 df             	mov    %rbx,%rdi
    86a0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    86a5:	e8 66 bb ff ff       	call   4210 <buf_put>
    86aa:	ba 01 00 00 00       	mov    $0x1,%edx
    86af:	4c 89 fe             	mov    %r15,%rsi
    86b2:	48 89 df             	mov    %rbx,%rdi
    86b5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    86ba:	e8 51 bb ff ff       	call   4210 <buf_put>
    86bf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    86c4:	45 31 f6             	xor    %r14d,%r14d
    86c7:	85 d2                	test   %edx,%edx
    86c9:	0f 8e 81 0a 00 00    	jle    9150 <fwp_write+0xd30>
    86cf:	45 31 ed             	xor    %r13d,%r13d
    86d2:	4d 85 ed             	test   %r13,%r13
    86d5:	0f 85 75 07 00 00    	jne    8e50 <fwp_write+0xa30>
    86db:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    86e2:	00 
    86e3:	45 85 f6             	test   %r14d,%r14d
    86e6:	0f 84 84 07 00 00    	je     8e70 <fwp_write+0xa50>
    86ec:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    86f1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    86f6:	48 89 df             	mov    %rbx,%rdi
    86f9:	49 83 c5 01          	add    $0x1,%r13
    86fd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8701:	31 c9                	xor    %ecx,%ecx
    8703:	e8 18 fd ff ff       	call   8420 <fwp_write>
    8708:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    870d:	7f c3                	jg     86d2 <fwp_write+0x2b2>
    870f:	45 85 f6             	test   %r14d,%r14d
    8712:	0f 84 38 0a 00 00    	je     9150 <fwp_write+0xd30>
    8718:	b8 29 00 00 00       	mov    $0x29,%eax
    871d:	ba 01 00 00 00       	mov    $0x1,%edx
    8722:	4c 89 fe             	mov    %r15,%rsi
    8725:	48 89 df             	mov    %rbx,%rdi
    8728:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    872c:	e8 df ba ff ff       	call   4210 <buf_put>
    8731:	e9 80 fd ff ff       	jmp    84b6 <fwp_write+0x96>
    8736:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    873d:	00 00 00 
    8740:	ba 01 00 00 00       	mov    $0x1,%edx
    8745:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    874a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    874f:	e8 bc ba ff ff       	call   4210 <buf_put>
    8754:	48 85 ed             	test   %rbp,%rbp
    8757:	0f 84 93 06 00 00    	je     8df0 <fwp_write+0x9d0>
    875d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8761:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8766:	31 c9                	xor    %ecx,%ecx
    8768:	48 89 df             	mov    %rbx,%rdi
    876b:	e8 b0 fc ff ff       	call   8420 <fwp_write>
    8770:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8774:	48 85 ed             	test   %rbp,%rbp
    8777:	0f 84 73 06 00 00    	je     8df0 <fwp_write+0x9d0>
    877d:	ba 02 00 00 00       	mov    $0x2,%edx
    8782:	48 8d 35 6c 6a 00 00 	lea    0x6a6c(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8789:	48 89 df             	mov    %rbx,%rdi
    878c:	e8 7f ba ff ff       	call   4210 <buf_put>
    8791:	eb ca                	jmp    875d <fwp_write+0x33d>
    8793:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8798:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    879c:	85 f6                	test   %esi,%esi
    879e:	0f 84 fc 07 00 00    	je     8fa0 <fwp_write+0xb80>
    87a4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    87ab:	00 
    87ac:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87b3:	00 00 
    87b5:	0f 85 3a 01 00 00    	jne    88f5 <fwp_write+0x4d5>
    87bb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    87bf:	4c 89 ea             	mov    %r13,%rdx
    87c2:	e9 6c fe ff ff       	jmp    8633 <fwp_write+0x213>
    87c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    87ce:	00 00 
    87d0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    87d5:	ba 01 00 00 00       	mov    $0x1,%edx
    87da:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    87df:	48 89 ee             	mov    %rbp,%rsi
    87e2:	e8 29 ba ff ff       	call   4210 <buf_put>
    87e7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    87ec:	4c 89 e7             	mov    %r12,%rdi
    87ef:	e8 5c ac ff ff       	call   3450 <strlen@plt>
    87f4:	4c 89 e6             	mov    %r12,%rsi
    87f7:	48 89 df             	mov    %rbx,%rdi
    87fa:	48 89 c2             	mov    %rax,%rdx
    87fd:	e8 0e ba ff ff       	call   4210 <buf_put>
    8802:	ba 01 00 00 00       	mov    $0x1,%edx
    8807:	48 89 ee             	mov    %rbp,%rsi
    880a:	48 89 df             	mov    %rbx,%rdi
    880d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8812:	e8 f9 b9 ff ff       	call   4210 <buf_put>
    8817:	e9 9a fc ff ff       	jmp    84b6 <fwp_write+0x96>
    881c:	0f 1f 40 00          	nopl   0x0(%rax)
    8820:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8825:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8829:	0f 8a 8e 0b 00 00    	jp     93bd <fwp_write+0xf9d>
    882f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8833:	66 0f 54 05 f5 73 00 	andpd  0x73f5(%rip),%xmm0        # fc30 <msg.4+0xc0>
    883a:	00 
    883b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8840:	66 0f 2e 05 60 73 00 	ucomisd 0x7360(%rip),%xmm0        # fba8 <msg.4+0x38>
    8847:	00 
    8848:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    884f:	00 
    8850:	0f 87 b2 09 00 00    	ja     9208 <fwp_write+0xde8>
    8856:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    885d:	00 00 00 
    8860:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8864:	89 ee                	mov    %ebp,%esi
    8866:	4c 89 e7             	mov    %r12,%rdi
    8869:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    886e:	e8 9d be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8873:	31 f6                	xor    %esi,%esi
    8875:	4c 89 e7             	mov    %r12,%rdi
    8878:	e8 93 ab ff ff       	call   3410 <strtod@plt>
    887d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8882:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8886:	7a 06                	jp     888e <fwp_write+0x46e>
    8888:	0f 84 e9 01 00 00    	je     8a77 <fwp_write+0x657>
    888e:	83 c5 01             	add    $0x1,%ebp
    8891:	83 fd 12             	cmp    $0x12,%ebp
    8894:	75 ca                	jne    8860 <fwp_write+0x440>
    8896:	be 11 00 00 00       	mov    $0x11,%esi
    889b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    889f:	4c 89 e7             	mov    %r12,%rdi
    88a2:	e8 69 be ff ff       	call   4710 <fwp_format_g.constprop.0>
    88a7:	e9 cb 01 00 00       	jmp    8a77 <fwp_write+0x657>
    88ac:	0f 1f 40 00          	nopl   0x0(%rax)
    88b0:	48 83 fd 01          	cmp    $0x1,%rbp
    88b4:	0f 84 e6 08 00 00    	je     91a0 <fwp_write+0xd80>
    88ba:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    88be:	b8 02 00 00 00       	mov    $0x2,%eax
    88c3:	ba 01 00 00 00       	mov    $0x1,%edx
    88c8:	48 0f 44 d0          	cmove  %rax,%rdx
    88cc:	48 8d 35 d0 68 00 00 	lea    0x68d0(%rip),%rsi        # f1a3 <_IO_stdin_used+0x1a3>
    88d3:	48 8d 05 ce 68 00 00 	lea    0x68ce(%rip),%rax        # f1a8 <_IO_stdin_used+0x1a8>
    88da:	48 0f 44 f0          	cmove  %rax,%rsi
    88de:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    88e5:	00 
    88e6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88ed:	00 00 
    88ef:	0f 84 3e fd ff ff    	je     8633 <fwp_write+0x213>
    88f5:	e8 66 ab ff ff       	call   3460 <__stack_chk_fail@plt>
    88fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8900:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8905:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    890a:	e8 41 b8 ff ff       	call   4150 <buf_grow>
    890f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8913:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8919:	4c 03 0b             	add    (%rbx),%r9
    891c:	66 45 89 11          	mov    %r10w,(%r9)
    8920:	45 85 e4             	test   %r12d,%r12d
    8923:	0f 8e 07 05 00 00    	jle    8e30 <fwp_write+0xa10>
    8929:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8930:	55 55 55 
    8933:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8938:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    893f:	aa aa aa 
    8942:	49 83 c1 01          	add    $0x1,%r9
    8946:	eb 45                	jmp    898d <fwp_write+0x56d>
    8948:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    894f:	00 
    8950:	be 01 00 00 00       	mov    $0x1,%esi
    8955:	b8 2d 00 00 00       	mov    $0x2d,%eax
    895a:	88 07                	mov    %al,(%rdi)
    895c:	48 89 e8             	mov    %rbp,%rax
    895f:	49 f7 e8             	imul   %r8
    8962:	48 89 e8             	mov    %rbp,%rax
    8965:	48 c1 f8 3f          	sar    $0x3f,%rax
    8969:	48 29 c2             	sub    %rax,%rdx
    896c:	48 85 c9             	test   %rcx,%rcx
    896f:	0f 95 c0             	setne  %al
    8972:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8976:	48 83 ef 01          	sub    $0x1,%rdi
    897a:	48 21 c5             	and    %rax,%rbp
    897d:	48 29 ea             	sub    %rbp,%rdx
    8980:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8984:	49 39 f9             	cmp    %rdi,%r9
    8987:	0f 84 a3 04 00 00    	je     8e30 <fwp_write+0xa10>
    898d:	48 89 e8             	mov    %rbp,%rax
    8990:	49 f7 e8             	imul   %r8
    8993:	48 89 e8             	mov    %rbp,%rax
    8996:	48 c1 f8 3f          	sar    $0x3f,%rax
    899a:	48 89 d1             	mov    %rdx,%rcx
    899d:	48 29 c1             	sub    %rax,%rcx
    89a0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    89a4:	48 89 e9             	mov    %rbp,%rcx
    89a7:	48 29 c1             	sub    %rax,%rcx
    89aa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    89ae:	49 f7 e2             	mul    %r10
    89b1:	b8 30 00 00 00       	mov    $0x30,%eax
    89b6:	48 89 d6             	mov    %rdx,%rsi
    89b9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    89bd:	48 d1 ee             	shr    $1,%rsi
    89c0:	48 01 f2             	add    %rsi,%rdx
    89c3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    89c7:	48 29 d6             	sub    %rdx,%rsi
    89ca:	74 8e                	je     895a <fwp_write+0x53a>
    89cc:	48 83 fe 01          	cmp    $0x1,%rsi
    89d0:	0f 85 7a ff ff ff    	jne    8950 <fwp_write+0x530>
    89d6:	31 f6                	xor    %esi,%esi
    89d8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    89dd:	e9 78 ff ff ff       	jmp    895a <fwp_write+0x53a>
    89e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    89e8:	66 0f 6e cd          	movd   %ebp,%xmm1
    89ec:	0f 2e c9             	ucomiss %xmm1,%xmm1
    89ef:	0f 8a c8 09 00 00    	jp     93bd <fwp_write+0xf9d>
    89f5:	0f 28 c1             	movaps %xmm1,%xmm0
    89f8:	0f 54 05 21 72 00 00 	andps  0x7221(%rip),%xmm0        # fc20 <msg.4+0xb0>
    89ff:	0f 2e 05 fe 65 00 00 	ucomiss 0x65fe(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8a06:	0f 87 24 08 00 00    	ja     9230 <fwp_write+0xe10>
    8a0c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8a10:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8a16:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8a1d:	00 
    8a1e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8a22:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8a27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a2e:	00 00 
    8a30:	44 89 ee             	mov    %r13d,%esi
    8a33:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8a38:	4c 89 e7             	mov    %r12,%rdi
    8a3b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8a40:	e8 cb bc ff ff       	call   4710 <fwp_format_g.constprop.0>
    8a45:	31 f6                	xor    %esi,%esi
    8a47:	4c 89 e7             	mov    %r12,%rdi
    8a4a:	e8 61 aa ff ff       	call   34b0 <strtof@plt>
    8a4f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8a54:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8a57:	7a 02                	jp     8a5b <fwp_write+0x63b>
    8a59:	74 1c                	je     8a77 <fwp_write+0x657>
    8a5b:	41 83 c5 01          	add    $0x1,%r13d
    8a5f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8a63:	75 cb                	jne    8a30 <fwp_write+0x610>
    8a65:	be 09 00 00 00       	mov    $0x9,%esi
    8a6a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8a6f:	4c 89 e7             	mov    %r12,%rdi
    8a72:	e8 99 bc ff ff       	call   4710 <fwp_format_g.constprop.0>
    8a77:	4c 89 e7             	mov    %r12,%rdi
    8a7a:	e8 01 b9 ff ff       	call   4380 <fwp_finish_float>
    8a7f:	e9 1c fa ff ff       	jmp    84a0 <fwp_write+0x80>
    8a84:	0f 1f 40 00          	nopl   0x0(%rax)
    8a88:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8a8c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8a90:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8a97:	00 
    8a98:	48 89 ef             	mov    %rbp,%rdi
    8a9b:	e8 a0 af ff ff       	call   3a40 <fwp_fmt_u128>
    8aa0:	48 89 ef             	mov    %rbp,%rdi
    8aa3:	e8 a8 a9 ff ff       	call   3450 <strlen@plt>
    8aa8:	48 89 ee             	mov    %rbp,%rsi
    8aab:	48 89 df             	mov    %rbx,%rdi
    8aae:	48 89 c2             	mov    %rax,%rdx
    8ab1:	e8 5a b7 ff ff       	call   4210 <buf_put>
    8ab6:	e9 fb f9 ff ff       	jmp    84b6 <fwp_write+0x96>
    8abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ac0:	ba 06 00 00 00       	mov    $0x6,%edx
    8ac5:	48 8d 35 2c 67 00 00 	lea    0x672c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    8acc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8ad2:	e8 39 b7 ff ff       	call   4210 <buf_put>
    8ad7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8ade:	ff ff 7f 
    8ae1:	48 23 55 00          	and    0x0(%rbp),%rdx
    8ae5:	0f 84 86 02 00 00    	je     8d71 <fwp_write+0x951>
    8aeb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8af0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8af4:	48 85 d2             	test   %rdx,%rdx
    8af7:	0f 84 ae 00 00 00    	je     8bab <fwp_write+0x78b>
    8afd:	8b 0a                	mov    (%rdx),%ecx
    8aff:	83 f9 1c             	cmp    $0x1c,%ecx
    8b02:	0f 84 58 06 00 00    	je     9160 <fwp_write+0xd40>
    8b08:	83 f9 1b             	cmp    $0x1b,%ecx
    8b0b:	0f 87 9a 00 00 00    	ja     8bab <fwp_write+0x78b>
    8b11:	be 01 00 00 00       	mov    $0x1,%esi
    8b16:	48 d3 e6             	shl    %cl,%rsi
    8b19:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8b1f:	0f 85 4b 04 00 00    	jne    8f70 <fwp_write+0xb50>
    8b25:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8b2b:	0f 85 0f 04 00 00    	jne    8f40 <fwp_write+0xb20>
    8b31:	83 e6 21             	and    $0x21,%esi
    8b34:	74 75                	je     8bab <fwp_write+0x78b>
    8b36:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8b3b:	48 85 ff             	test   %rdi,%rdi
    8b3e:	79 07                	jns    8b47 <fwp_write+0x727>
    8b40:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8b44:	4c 01 ee             	add    %r13,%rsi
    8b47:	48 0f be 3e          	movsbq (%rsi),%rdi
    8b4b:	85 c9                	test   %ecx,%ecx
    8b4d:	40 0f b6 f7          	movzbl %dil,%esi
    8b51:	48 0f 44 f7          	cmove  %rdi,%rsi
    8b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b5c:	00 00 00 00 
    8b60:	31 c9                	xor    %ecx,%ecx
    8b62:	48 89 df             	mov    %rbx,%rdi
    8b65:	49 83 c5 01          	add    $0x1,%r13
    8b69:	e8 b2 f8 ff ff       	call   8420 <fwp_write>
    8b6e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8b75:	ff ff 7f 
    8b78:	48 23 55 00          	and    0x0(%rbp),%rdx
    8b7c:	49 39 d5             	cmp    %rdx,%r13
    8b7f:	0f 83 ec 01 00 00    	jae    8d71 <fwp_write+0x951>
    8b85:	ba 02 00 00 00       	mov    $0x2,%edx
    8b8a:	48 89 df             	mov    %rbx,%rdi
    8b8d:	48 8d 35 61 66 00 00 	lea    0x6661(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8b94:	e8 77 b6 ff ff       	call   4210 <buf_put>
    8b99:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8b9e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8ba2:	48 85 d2             	test   %rdx,%rdx
    8ba5:	0f 85 52 ff ff ff    	jne    8afd <fwp_write+0x6dd>
    8bab:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8bb0:	48 85 ff             	test   %rdi,%rdi
    8bb3:	0f 88 cf 05 00 00    	js     9188 <fwp_write+0xd68>
    8bb9:	48 8b 31             	mov    (%rcx),%rsi
    8bbc:	eb a2                	jmp    8b60 <fwp_write+0x740>
    8bbe:	66 90                	xchg   %ax,%ax
    8bc0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8bc7:	00 
    8bc8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8bcf:	00 00 
    8bd1:	0f 85 1e fd ff ff    	jne    88f5 <fwp_write+0x4d5>
    8bd7:	ba 08 00 00 00       	mov    $0x8,%edx
    8bdc:	48 8d 35 e2 65 00 00 	lea    0x65e2(%rip),%rsi        # f1c5 <_IO_stdin_used+0x1c5>
    8be3:	e9 4b fa ff ff       	jmp    8633 <fwp_write+0x213>
    8be8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bef:	00 
    8bf0:	89 e8                	mov    %ebp,%eax
    8bf2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8bf9:	76 03                	jbe    8bfe <fwp_write+0x7de>
    8bfb:	8b 45 00             	mov    0x0(%rbp),%eax
    8bfe:	41 89 c6             	mov    %eax,%r14d
    8c01:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8c06:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8c0b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8c0f:	4c 89 ef             	mov    %r13,%rdi
    8c12:	e8 39 a8 ff ff       	call   3450 <strlen@plt>
    8c17:	4c 89 ee             	mov    %r13,%rsi
    8c1a:	48 89 df             	mov    %rbx,%rdi
    8c1d:	48 89 c2             	mov    %rax,%rdx
    8c20:	e8 eb b5 ff ff       	call   4210 <buf_put>
    8c25:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8c2a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8c2e:	85 f6                	test   %esi,%esi
    8c30:	0f 8e 80 f8 ff ff    	jle    84b6 <fwp_write+0x96>
    8c36:	45 31 ed             	xor    %r13d,%r13d
    8c39:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8c3e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8c43:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8c48:	ba 01 00 00 00       	mov    $0x1,%edx
    8c4d:	4c 89 fe             	mov    %r15,%rsi
    8c50:	48 89 04 24          	mov    %rax,(%rsp)
    8c54:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8c59:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8c5d:	48 89 df             	mov    %rbx,%rdi
    8c60:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8c64:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8c69:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8c6e:	e8 9d b5 ff ff       	call   4210 <buf_put>
    8c73:	41 8b 06             	mov    (%r14),%eax
    8c76:	83 f8 0e             	cmp    $0xe,%eax
    8c79:	0f 84 71 02 00 00    	je     8ef0 <fwp_write+0xad0>
    8c7f:	83 f8 10             	cmp    $0x10,%eax
    8c82:	0f 84 38 02 00 00    	je     8ec0 <fwp_write+0xaa0>
    8c88:	83 f8 0a             	cmp    $0xa,%eax
    8c8b:	0f 84 7f 04 00 00    	je     9110 <fwp_write+0xcf0>
    8c91:	0f 8f f9 00 00 00    	jg     8d90 <fwp_write+0x970>
    8c97:	83 f8 03             	cmp    $0x3,%eax
    8c9a:	0f 8f 50 04 00 00    	jg     90f0 <fwp_write+0xcd0>
    8ca0:	85 c0                	test   %eax,%eax
    8ca2:	78 10                	js     8cb4 <fwp_write+0x894>
    8ca4:	48 8b 04 24          	mov    (%rsp),%rax
    8ca8:	48 c1 e8 3f          	shr    $0x3f,%rax
    8cac:	85 c0                	test   %eax,%eax
    8cae:	0f 85 f9 00 00 00    	jne    8dad <fwp_write+0x98d>
    8cb4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8cb9:	48 8b 34 24          	mov    (%rsp),%rsi
    8cbd:	31 c9                	xor    %ecx,%ecx
    8cbf:	48 89 df             	mov    %rbx,%rdi
    8cc2:	e8 59 f7 ff ff       	call   8420 <fwp_write>
    8cc7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8ccc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8cd1:	49 83 c5 01          	add    $0x1,%r13
    8cd5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8cd9:	0f 8f 5f ff ff ff    	jg     8c3e <fwp_write+0x81e>
    8cdf:	e9 d2 f7 ff ff       	jmp    84b6 <fwp_write+0x96>
    8ce4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ce8:	ba 06 00 00 00       	mov    $0x6,%edx
    8ced:	48 8d 35 f7 64 00 00 	lea    0x64f7(%rip),%rsi        # f1eb <_IO_stdin_used+0x1eb>
    8cf4:	45 31 ed             	xor    %r13d,%r13d
    8cf7:	e8 14 b5 ff ff       	call   4210 <buf_put>
    8cfc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8d01:	75 19                	jne    8d1c <fwp_write+0x8fc>
    8d03:	eb 6c                	jmp    8d71 <fwp_write+0x951>
    8d05:	0f 1f 00             	nopl   (%rax)
    8d08:	ba 02 00 00 00       	mov    $0x2,%edx
    8d0d:	48 8d 35 e1 64 00 00 	lea    0x64e1(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8d14:	48 89 df             	mov    %rbx,%rdi
    8d17:	e8 f4 b4 ff ff       	call   4210 <buf_put>
    8d1c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8d22:	b9 00 02 00 00       	mov    $0x200,%ecx
    8d27:	31 c0                	xor    %eax,%eax
    8d29:	49 83 c5 01          	add    $0x1,%r13
    8d2d:	4c 8d 05 be 64 00 00 	lea    0x64be(%rip),%r8        # f1f2 <_IO_stdin_used+0x1f2>
    8d34:	ba 02 00 00 00       	mov    $0x2,%edx
    8d39:	be 00 02 00 00       	mov    $0x200,%esi
    8d3e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d45:	00 
    8d46:	e8 65 a6 ff ff       	call   33b0 <__snprintf_chk@plt>
    8d4b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d52:	00 
    8d53:	e8 f8 a6 ff ff       	call   3450 <strlen@plt>
    8d58:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8d5f:	00 
    8d60:	48 89 df             	mov    %rbx,%rdi
    8d63:	48 89 c2             	mov    %rax,%rdx
    8d66:	e8 a5 b4 ff ff       	call   4210 <buf_put>
    8d6b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8d6f:	72 97                	jb     8d08 <fwp_write+0x8e8>
    8d71:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d76:	ba 01 00 00 00       	mov    $0x1,%edx
    8d7b:	48 89 df             	mov    %rbx,%rdi
    8d7e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8d83:	e8 88 b4 ff ff       	call   4210 <buf_put>
    8d88:	e9 29 f7 ff ff       	jmp    84b6 <fwp_write+0x96>
    8d8d:	0f 1f 00             	nopl   (%rax)
    8d90:	83 f8 0b             	cmp    $0xb,%eax
    8d93:	0f 85 1b ff ff ff    	jne    8cb4 <fwp_write+0x894>
    8d99:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8d9e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8da2:	83 e0 01             	and    $0x1,%eax
    8da5:	85 c0                	test   %eax,%eax
    8da7:	0f 84 07 ff ff ff    	je     8cb4 <fwp_write+0x894>
    8dad:	4c 89 fe             	mov    %r15,%rsi
    8db0:	48 89 df             	mov    %rbx,%rdi
    8db3:	ba 01 00 00 00       	mov    $0x1,%edx
    8db8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8dbd:	e8 4e b4 ff ff       	call   4210 <buf_put>
    8dc2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8dc7:	48 8b 34 24          	mov    (%rsp),%rsi
    8dcb:	31 c9                	xor    %ecx,%ecx
    8dcd:	48 89 df             	mov    %rbx,%rdi
    8dd0:	e8 4b f6 ff ff       	call   8420 <fwp_write>
    8dd5:	ba 01 00 00 00       	mov    $0x1,%edx
    8dda:	4c 89 fe             	mov    %r15,%rsi
    8ddd:	48 89 df             	mov    %rbx,%rdi
    8de0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8de5:	e8 26 b4 ff ff       	call   4210 <buf_put>
    8dea:	e9 d8 fe ff ff       	jmp    8cc7 <fwp_write+0x8a7>
    8def:	90                   	nop
    8df0:	ba 01 00 00 00       	mov    $0x1,%edx
    8df5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8dfa:	48 89 df             	mov    %rbx,%rdi
    8dfd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8e02:	e8 09 b4 ff ff       	call   4210 <buf_put>
    8e07:	e9 aa f6 ff ff       	jmp    84b6 <fwp_write+0x96>
    8e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e10:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e15:	ba 01 00 00 00       	mov    $0x1,%edx
    8e1a:	48 89 df             	mov    %rbx,%rdi
    8e1d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8e22:	e8 e9 b3 ff ff       	call   4210 <buf_put>
    8e27:	e9 8a f6 ff ff       	jmp    84b6 <fwp_write+0x96>
    8e2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e30:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8e34:	48 8b 13             	mov    (%rbx),%rdx
    8e37:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8e3c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8e40:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8e44:	e9 6d f6 ff ff       	jmp    84b6 <fwp_write+0x96>
    8e49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e50:	ba 02 00 00 00       	mov    $0x2,%edx
    8e55:	48 8d 35 99 63 00 00 	lea    0x6399(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8e5c:	48 89 df             	mov    %rbx,%rdi
    8e5f:	e8 ac b3 ff ff       	call   4210 <buf_put>
    8e64:	e9 72 f8 ff ff       	jmp    86db <fwp_write+0x2bb>
    8e69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e70:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8e75:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8e7a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8e7e:	48 89 f7             	mov    %rsi,%rdi
    8e81:	48 89 34 24          	mov    %rsi,(%rsp)
    8e85:	e8 c6 a5 ff ff       	call   3450 <strlen@plt>
    8e8a:	48 8b 34 24          	mov    (%rsp),%rsi
    8e8e:	48 89 df             	mov    %rbx,%rdi
    8e91:	48 89 c2             	mov    %rax,%rdx
    8e94:	e8 77 b3 ff ff       	call   4210 <buf_put>
    8e99:	ba 03 00 00 00       	mov    $0x3,%edx
    8e9e:	48 8d 35 73 63 00 00 	lea    0x6373(%rip),%rsi        # f218 <_IO_stdin_used+0x218>
    8ea5:	48 89 df             	mov    %rbx,%rdi
    8ea8:	e8 63 b3 ff ff       	call   4210 <buf_put>
    8ead:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8eb2:	e9 35 f8 ff ff       	jmp    86ec <fwp_write+0x2cc>
    8eb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8ebe:	00 00 
    8ec0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8ec5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8ec9:	48 85 ff             	test   %rdi,%rdi
    8ecc:	0f 84 e2 fd ff ff    	je     8cb4 <fwp_write+0x894>
    8ed2:	48 8d 35 29 63 00 00 	lea    0x6329(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8ed9:	e8 52 a6 ff ff       	call   3530 <strcmp@plt>
    8ede:	85 c0                	test   %eax,%eax
    8ee0:	0f 95 c0             	setne  %al
    8ee3:	0f b6 c0             	movzbl %al,%eax
    8ee6:	e9 c1 fd ff ff       	jmp    8cac <fwp_write+0x88c>
    8eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ef0:	31 c0                	xor    %eax,%eax
    8ef2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8ef9:	00 
    8efa:	0f 97 c0             	seta   %al
    8efd:	e9 aa fd ff ff       	jmp    8cac <fwp_write+0x88c>
    8f02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f08:	48 89 df             	mov    %rbx,%rdi
    8f0b:	ba 02 00 00 00       	mov    $0x2,%edx
    8f10:	48 8d 35 e8 62 00 00 	lea    0x62e8(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    8f17:	e8 f4 b2 ff ff       	call   4210 <buf_put>
    8f1c:	4c 89 e8             	mov    %r13,%rax
    8f1f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8f24:	31 c9                	xor    %ecx,%ecx
    8f26:	48 c1 e0 04          	shl    $0x4,%rax
    8f2a:	48 89 df             	mov    %rbx,%rdi
    8f2d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8f32:	e8 e9 f4 ff ff       	call   8420 <fwp_write>
    8f37:	e9 5e f6 ff ff       	jmp    859a <fwp_write+0x17a>
    8f3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8f40:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8f45:	48 85 ff             	test   %rdi,%rdi
    8f48:	79 0c                	jns    8f56 <fwp_write+0xb36>
    8f4a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8f51:	00 
    8f52:	48 03 75 10          	add    0x10(%rbp),%rsi
    8f56:	48 63 3e             	movslq (%rsi),%rdi
    8f59:	83 f9 02             	cmp    $0x2,%ecx
    8f5c:	89 fe                	mov    %edi,%esi
    8f5e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8f62:	e9 f9 fb ff ff       	jmp    8b60 <fwp_write+0x740>
    8f67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8f6e:	00 00 
    8f70:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8f75:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8f7a:	48 85 ff             	test   %rdi,%rdi
    8f7d:	0f 88 0f 03 00 00    	js     9292 <fwp_write+0xe72>
    8f83:	49 0f bf 38          	movswq (%r8),%rdi
    8f87:	83 f9 01             	cmp    $0x1,%ecx
    8f8a:	0f b7 f7             	movzwl %di,%esi
    8f8d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8f91:	e9 ca fb ff ff       	jmp    8b60 <fwp_write+0x740>
    8f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f9d:	00 00 00 
    8fa0:	ba 01 00 00 00       	mov    $0x1,%edx
    8fa5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8faa:	48 83 c5 08          	add    $0x8,%rbp
    8fae:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8fb3:	e8 58 b2 ff ff       	call   4210 <buf_put>
    8fb8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8fbd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8fc2:	4d 85 ed             	test   %r13,%r13
    8fc5:	75 46                	jne    900d <fwp_write+0xbed>
    8fc7:	e9 04 01 00 00       	jmp    90d0 <fwp_write+0xcb0>
    8fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    8fd0:	41 80 f9 09          	cmp    $0x9,%r9b
    8fd4:	0f 84 d6 00 00 00    	je     90b0 <fwp_write+0xc90>
    8fda:	41 80 f9 0a          	cmp    $0xa,%r9b
    8fde:	0f 85 9c 00 00 00    	jne    9080 <fwp_write+0xc60>
    8fe4:	ba 02 00 00 00       	mov    $0x2,%edx
    8fe9:	48 8d 35 eb 61 00 00 	lea    0x61eb(%rip),%rsi        # f1db <_IO_stdin_used+0x1db>
    8ff0:	48 89 df             	mov    %rbx,%rdi
    8ff3:	e8 18 b2 ff ff       	call   4210 <buf_put>
    8ff8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8fff:	00 
    9000:	48 83 c5 01          	add    $0x1,%rbp
    9004:	49 39 ec             	cmp    %rbp,%r12
    9007:	0f 84 c3 00 00 00    	je     90d0 <fwp_write+0xcb0>
    900d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9012:	41 80 f9 0d          	cmp    $0xd,%r9b
    9016:	74 28                	je     9040 <fwp_write+0xc20>
    9018:	7e b6                	jle    8fd0 <fwp_write+0xbb0>
    901a:	41 80 f9 22          	cmp    $0x22,%r9b
    901e:	74 40                	je     9060 <fwp_write+0xc40>
    9020:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9024:	75 5a                	jne    9080 <fwp_write+0xc60>
    9026:	ba 02 00 00 00       	mov    $0x2,%edx
    902b:	48 8d 35 a6 61 00 00 	lea    0x61a6(%rip),%rsi        # f1d8 <_IO_stdin_used+0x1d8>
    9032:	48 89 df             	mov    %rbx,%rdi
    9035:	e8 d6 b1 ff ff       	call   4210 <buf_put>
    903a:	eb c4                	jmp    9000 <fwp_write+0xbe0>
    903c:	0f 1f 40 00          	nopl   0x0(%rax)
    9040:	ba 02 00 00 00       	mov    $0x2,%edx
    9045:	48 8d 35 95 61 00 00 	lea    0x6195(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    904c:	48 89 df             	mov    %rbx,%rdi
    904f:	e8 bc b1 ff ff       	call   4210 <buf_put>
    9054:	eb aa                	jmp    9000 <fwp_write+0xbe0>
    9056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    905d:	00 00 00 
    9060:	ba 02 00 00 00       	mov    $0x2,%edx
    9065:	48 8d 35 69 61 00 00 	lea    0x6169(%rip),%rsi        # f1d5 <_IO_stdin_used+0x1d5>
    906c:	48 89 df             	mov    %rbx,%rdi
    906f:	e8 9c b1 ff ff       	call   4210 <buf_put>
    9074:	eb 8a                	jmp    9000 <fwp_write+0xbe0>
    9076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    907d:	00 00 00 
    9080:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9084:	0f 86 2e 01 00 00    	jbe    91b8 <fwp_write+0xd98>
    908a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    908e:	0f 84 24 01 00 00    	je     91b8 <fwp_write+0xd98>
    9094:	ba 01 00 00 00       	mov    $0x1,%edx
    9099:	4c 89 fe             	mov    %r15,%rsi
    909c:	48 89 df             	mov    %rbx,%rdi
    909f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    90a4:	e8 67 b1 ff ff       	call   4210 <buf_put>
    90a9:	e9 52 ff ff ff       	jmp    9000 <fwp_write+0xbe0>
    90ae:	66 90                	xchg   %ax,%ax
    90b0:	ba 02 00 00 00       	mov    $0x2,%edx
    90b5:	48 8d 35 22 61 00 00 	lea    0x6122(%rip),%rsi        # f1de <_IO_stdin_used+0x1de>
    90bc:	48 89 df             	mov    %rbx,%rdi
    90bf:	e8 4c b1 ff ff       	call   4210 <buf_put>
    90c4:	e9 37 ff ff ff       	jmp    9000 <fwp_write+0xbe0>
    90c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90d0:	ba 01 00 00 00       	mov    $0x1,%edx
    90d5:	4c 89 fe             	mov    %r15,%rsi
    90d8:	48 89 df             	mov    %rbx,%rdi
    90db:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    90e0:	e8 2b b1 ff ff       	call   4210 <buf_put>
    90e5:	e9 cc f3 ff ff       	jmp    84b6 <fwp_write+0x96>
    90ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90f0:	83 f8 04             	cmp    $0x4,%eax
    90f3:	0f 85 bb fb ff ff    	jne    8cb4 <fwp_write+0x894>
    90f9:	48 8b 04 24          	mov    (%rsp),%rax
    90fd:	48 8b 40 08          	mov    0x8(%rax),%rax
    9101:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9106:	48 c1 e8 3f          	shr    $0x3f,%rax
    910a:	e9 96 fc ff ff       	jmp    8da5 <fwp_write+0x985>
    910f:	90                   	nop
    9110:	8b 0c 24             	mov    (%rsp),%ecx
    9113:	31 c0                	xor    %eax,%eax
    9115:	85 c9                	test   %ecx,%ecx
    9117:	0f 98 c0             	sets   %al
    911a:	e9 86 fc ff ff       	jmp    8da5 <fwp_write+0x985>
    911f:	90                   	nop
    9120:	48 f7 d8             	neg    %rax
    9123:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    912a:	00 
    912b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9132:	2d 
    9133:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    913a:	00 
    913b:	48 83 d2 00          	adc    $0x0,%rdx
    913f:	48 89 c6             	mov    %rax,%rsi
    9142:	48 f7 da             	neg    %rdx
    9145:	e8 f6 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    914a:	e9 51 f3 ff ff       	jmp    84a0 <fwp_write+0x80>
    914f:	90                   	nop
    9150:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9155:	e9 c3 f5 ff ff       	jmp    871d <fwp_write+0x2fd>
    915a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9160:	4c 89 e9             	mov    %r13,%rcx
    9163:	48 c1 e1 04          	shl    $0x4,%rcx
    9167:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    916c:	48 85 ff             	test   %rdi,%rdi
    916f:	0f 89 eb f9 ff ff    	jns    8b60 <fwp_write+0x740>
    9175:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9179:	48 89 ce             	mov    %rcx,%rsi
    917c:	e9 df f9 ff ff       	jmp    8b60 <fwp_write+0x740>
    9181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9188:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    918f:	00 
    9190:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9194:	e9 20 fa ff ff       	jmp    8bb9 <fwp_write+0x799>
    9199:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    91a0:	ba 02 00 00 00       	mov    $0x2,%edx
    91a5:	48 8d 35 f9 5f 00 00 	lea    0x5ff9(%rip),%rsi        # f1a5 <_IO_stdin_used+0x1a5>
    91ac:	e9 2d f7 ff ff       	jmp    88de <fwp_write+0x4be>
    91b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    91b8:	4c 8d 05 25 60 00 00 	lea    0x6025(%rip),%r8        # f1e4 <_IO_stdin_used+0x1e4>
    91bf:	b9 10 00 00 00       	mov    $0x10,%ecx
    91c4:	31 c0                	xor    %eax,%eax
    91c6:	ba 02 00 00 00       	mov    $0x2,%edx
    91cb:	be 10 00 00 00       	mov    $0x10,%esi
    91d0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    91d7:	00 
    91d8:	e8 d3 a1 ff ff       	call   33b0 <__snprintf_chk@plt>
    91dd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    91e4:	00 
    91e5:	e8 66 a2 ff ff       	call   3450 <strlen@plt>
    91ea:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    91f1:	00 
    91f2:	48 89 df             	mov    %rbx,%rdi
    91f5:	48 89 c2             	mov    %rax,%rdx
    91f8:	e8 13 b0 ff ff       	call   4210 <buf_put>
    91fd:	e9 fe fd ff ff       	jmp    9000 <fwp_write+0xbe0>
    9202:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9208:	66 0f ef c0          	pxor   %xmm0,%xmm0
    920c:	48 8d 35 8c 5f 00 00 	lea    0x5f8c(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    9213:	48 8d 05 84 5f 00 00 	lea    0x5f84(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    921a:	4c 89 e7             	mov    %r12,%rdi
    921d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9221:	48 0f 46 f0          	cmovbe %rax,%rsi
    9225:	e8 c6 a1 ff ff       	call   33f0 <strcpy@plt>
    922a:	e9 71 f2 ff ff       	jmp    84a0 <fwp_write+0x80>
    922f:	90                   	nop
    9230:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9234:	48 8d 35 64 5f 00 00 	lea    0x5f64(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    923b:	48 8d 05 5c 5f 00 00 	lea    0x5f5c(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    9242:	0f 2f c8             	comiss %xmm0,%xmm1
    9245:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    924c:	00 
    924d:	4c 89 e7             	mov    %r12,%rdi
    9250:	48 0f 46 f0          	cmovbe %rax,%rsi
    9254:	e8 97 a1 ff ff       	call   33f0 <strcpy@plt>
    9259:	e9 42 f2 ff ff       	jmp    84a0 <fwp_write+0x80>
    925e:	66 90                	xchg   %ax,%ax
    9260:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9265:	45 85 c0             	test   %r8d,%r8d
    9268:	75 34                	jne    929e <fwp_write+0xe7e>
    926a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9271:	00 
    9272:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9279:	00 00 
    927b:	0f 85 74 f6 ff ff    	jne    88f5 <fwp_write+0x4d5>
    9281:	ba 02 00 00 00       	mov    $0x2,%edx
    9286:	48 8d 35 88 5f 00 00 	lea    0x5f88(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    928d:	e9 a1 f3 ff ff       	jmp    8633 <fwp_write+0x213>
    9292:	48 03 75 10          	add    0x10(%rbp),%rsi
    9296:	49 89 f0             	mov    %rsi,%r8
    9299:	e9 e5 fc ff ff       	jmp    8f83 <fwp_write+0xb63>
    929e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    92a3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    92a8:	85 ff                	test   %edi,%edi
    92aa:	0f 84 fa f3 ff ff    	je     86aa <fwp_write+0x28a>
    92b0:	ba 01 00 00 00       	mov    $0x1,%edx
    92b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    92ba:	48 89 df             	mov    %rbx,%rdi
    92bd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    92c2:	e8 49 af ff ff       	call   4210 <buf_put>
    92c7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    92cc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    92d1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    92d7:	85 c0                	test   %eax,%eax
    92d9:	0f 8f f0 f3 ff ff    	jg     86cf <fwp_write+0x2af>
    92df:	e9 34 f4 ff ff       	jmp    8718 <fwp_write+0x2f8>
    92e4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    92e8:	49 89 c5             	mov    %rax,%r13
    92eb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    92f0:	49 89 c4             	mov    %rax,%r12
    92f3:	49 c1 fd 3f          	sar    $0x3f,%r13
    92f7:	4c 09 e8             	or     %r13,%rax
    92fa:	0f 84 a7 00 00 00    	je     93a7 <fwp_write+0xf87>
    9300:	48 8d 2d 99 7f 00 00 	lea    0x7f99(%rip),%rbp        # 112a0 <units.0>
    9307:	4d 89 e7             	mov    %r12,%r15
    930a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    930e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9313:	4c 89 ff             	mov    %r15,%rdi
    9316:	4c 89 ee             	mov    %r13,%rsi
    9319:	44 89 0c 24          	mov    %r9d,(%rsp)
    931d:	48 99                	cqto
    931f:	48 89 d1             	mov    %rdx,%rcx
    9322:	48 89 c2             	mov    %rax,%rdx
    9325:	e8 26 4e 00 00       	call   e150 <__divmodti4>
    932a:	44 8b 0c 24          	mov    (%rsp),%r9d
    932e:	48 89 c1             	mov    %rax,%rcx
    9331:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9336:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    933b:	0f 84 94 00 00 00    	je     93d5 <fwp_write+0xfb5>
    9341:	41 83 c1 01          	add    $0x1,%r9d
    9345:	48 83 c5 10          	add    $0x10,%rbp
    9349:	41 83 f9 05          	cmp    $0x5,%r9d
    934d:	75 bb                	jne    930a <fwp_write+0xeea>
    934f:	4d 85 ed             	test   %r13,%r13
    9352:	79 53                	jns    93a7 <fwp_write+0xf87>
    9354:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9359:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    935e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9363:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9368:	48 99                	cqto
    936a:	48 f7 d8             	neg    %rax
    936d:	48 83 d2 00          	adc    $0x0,%rdx
    9371:	48 89 c6             	mov    %rax,%rsi
    9374:	48 f7 da             	neg    %rdx
    9377:	e8 c4 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    937c:	49 89 e8             	mov    %rbp,%r8
    937f:	ba 00 02 00 00       	mov    $0x200,%edx
    9384:	be 02 00 00 00       	mov    $0x2,%esi
    9389:	31 c0                	xor    %eax,%eax
    938b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9392:	00 
    9393:	48 8d 0d 76 5e 00 00 	lea    0x5e76(%rip),%rcx        # f210 <_IO_stdin_used+0x210>
    939a:	4c 89 e7             	mov    %r12,%rdi
    939d:	e8 3e a3 ff ff       	call   36e0 <__sprintf_chk@plt>
    93a2:	e9 f9 f0 ff ff       	jmp    84a0 <fwp_write+0x80>
    93a7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    93ac:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    93b1:	31 d2                	xor    %edx,%edx
    93b3:	48 89 ef             	mov    %rbp,%rdi
    93b6:	e8 85 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    93bb:	eb bf                	jmp    937c <fwp_write+0xf5c>
    93bd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    93c4:	4e 61 4e 00 
    93c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    93cf:	00 
    93d0:	e9 cb f0 ff ff       	jmp    84a0 <fwp_write+0x80>
    93d5:	44 89 0c 24          	mov    %r9d,(%rsp)
    93d9:	48 89 c8             	mov    %rcx,%rax
    93dc:	48 85 d2             	test   %rdx,%rdx
    93df:	78 51                	js     9432 <fwp_write+0x1012>
    93e1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    93e6:	48 89 c6             	mov    %rax,%rsi
    93e9:	48 89 ef             	mov    %rbp,%rdi
    93ec:	e8 4f a6 ff ff       	call   3a40 <fwp_fmt_u128>
    93f1:	44 8b 0c 24          	mov    (%rsp),%r9d
    93f5:	49 63 c1             	movslq %r9d,%rax
    93f8:	49 89 e8             	mov    %rbp,%r8
    93fb:	ba 00 02 00 00       	mov    $0x200,%edx
    9400:	be 02 00 00 00       	mov    $0x2,%esi
    9405:	48 c1 e0 04          	shl    $0x4,%rax
    9409:	48 8d 3d 90 7e 00 00 	lea    0x7e90(%rip),%rdi        # 112a0 <units.0>
    9410:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9417:	00 
    9418:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    941c:	48 8d 0d e8 5d 00 00 	lea    0x5de8(%rip),%rcx        # f20b <_IO_stdin_used+0x20b>
    9423:	4c 89 e7             	mov    %r12,%rdi
    9426:	31 c0                	xor    %eax,%eax
    9428:	e8 b3 a2 ff ff       	call   36e0 <__sprintf_chk@plt>
    942d:	e9 6e f0 ff ff       	jmp    84a0 <fwp_write+0x80>
    9432:	48 f7 d8             	neg    %rax
    9435:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    943a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    943f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9444:	48 83 d2 00          	adc    $0x0,%rdx
    9448:	48 89 c6             	mov    %rax,%rsi
    944b:	48 f7 da             	neg    %rdx
    944e:	e8 ed a5 ff ff       	call   3a40 <fwp_fmt_u128>
    9453:	44 8b 0c 24          	mov    (%rsp),%r9d
    9457:	eb 9c                	jmp    93f5 <fwp_write+0xfd5>
    9459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009460 <fwp_hof0.constprop.0>:
    9460:	41 57                	push   %r15
    9462:	41 56                	push   %r14
    9464:	41 55                	push   %r13
    9466:	41 54                	push   %r12
    9468:	55                   	push   %rbp
    9469:	53                   	push   %rbx
    946a:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9471:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9478:	00 00 
    947a:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    9481:	00 
    9482:	31 c0                	xor    %eax,%eax
    9484:	48 85 f6             	test   %rsi,%rsi
    9487:	0f 84 4a 0f 00 00    	je     a3d7 <fwp_hof0.constprop.0+0xf77>
    948d:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
    9492:	4c 8d 2d 27 a3 01 00 	lea    0x1a327(%rip),%r13        # 237c0 <fwp_heap>
    9499:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
    949e:	66 90                	xchg   %ax,%ax
    94a0:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    94a7:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    94ac:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    94b3:	48 c1 e2 10          	shl    $0x10,%rdx
    94b7:	48 39 d0             	cmp    %rdx,%rax
    94ba:	73 5d                	jae    9519 <fwp_hof0.constprop.0+0xb9>
    94bc:	48 89 c2             	mov    %rax,%rdx
    94bf:	48 c1 ea 10          	shr    $0x10,%rdx
    94c3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    94c7:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    94ce:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    94d2:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    94d6:	48 85 ff             	test   %rdi,%rdi
    94d9:	74 3e                	je     9519 <fwp_hof0.constprop.0+0xb9>
    94db:	0f b6 0a             	movzbl (%rdx),%ecx
    94de:	80 f9 02             	cmp    $0x2,%cl
    94e1:	0f 84 c9 14 00 00    	je     a9b0 <fwp_hof0.constprop.0+0x1550>
    94e7:	80 f9 01             	cmp    $0x1,%cl
    94ea:	75 2d                	jne    9519 <fwp_hof0.constprop.0+0xb9>
    94ec:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94ef:	0f b7 c0             	movzwl %ax,%eax
    94f2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94f5:	48 0f af c1          	imul   %rcx,%rax
    94f9:	48 c1 e8 20          	shr    $0x20,%rax
    94fd:	48 39 d0             	cmp    %rdx,%rax
    9500:	73 17                	jae    9519 <fwp_hof0.constprop.0+0xb9>
    9502:	48 01 c7             	add    %rax,%rdi
    9505:	0f b6 07             	movzbl (%rdi),%eax
    9508:	84 c0                	test   %al,%al
    950a:	74 0d                	je     9519 <fwp_hof0.constprop.0+0xb9>
    950c:	3c fd                	cmp    $0xfd,%al
    950e:	0f 87 a7 16 00 00    	ja     abbb <fwp_hof0.constprop.0+0x175b>
    9514:	83 c0 01             	add    $0x1,%eax
    9517:	88 07                	mov    %al,(%rdi)
    9519:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    951e:	45 31 c0             	xor    %r8d,%r8d
    9521:	48 c7 44 24 40 c6 00 	movq   $0xc6,0x40(%rsp)
    9528:	00 00 
    952a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    952f:	4c 89 c3             	mov    %r8,%rbx
    9532:	4d 85 c0             	test   %r8,%r8
    9535:	0f 85 15 a2 ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    953b:	48 8b 05 16 bf 01 00 	mov    0x1bf16(%rip),%rax        # 25458 <fwp_cleanups>
    9542:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9549:	4c 8d 3d 50 d8 ff ff 	lea    -0x27b0(%rip),%r15        # 6da0 <fwp_tape_scope_release>
    9550:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    9557:	ff 
    9558:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
    955f:	00 
    9560:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9567:	00 
    9568:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    956d:	48 c1 e2 10          	shl    $0x10,%rdx
    9571:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    9576:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    957d:	00 
    957e:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9585:	00 
    9586:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    958b:	48 89 05 c6 be 01 00 	mov    %rax,0x1bec6(%rip)        # 25458 <fwp_cleanups>
    9592:	48 8d 05 77 9a 00 00 	lea    0x9a77(%rip),%rax        # 13010 <fc37>
    9599:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    95a0:	48 39 d0             	cmp    %rdx,%rax
    95a3:	73 5d                	jae    9602 <fwp_hof0.constprop.0+0x1a2>
    95a5:	48 89 c2             	mov    %rax,%rdx
    95a8:	48 c1 ea 10          	shr    $0x10,%rdx
    95ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95b0:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    95b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95bb:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    95bf:	48 85 ff             	test   %rdi,%rdi
    95c2:	74 3e                	je     9602 <fwp_hof0.constprop.0+0x1a2>
    95c4:	0f b6 0a             	movzbl (%rdx),%ecx
    95c7:	80 f9 02             	cmp    $0x2,%cl
    95ca:	0f 84 80 12 00 00    	je     a850 <fwp_hof0.constprop.0+0x13f0>
    95d0:	80 f9 01             	cmp    $0x1,%cl
    95d3:	75 2d                	jne    9602 <fwp_hof0.constprop.0+0x1a2>
    95d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    95d8:	0f b7 c0             	movzwl %ax,%eax
    95db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    95de:	48 0f af c1          	imul   %rcx,%rax
    95e2:	48 c1 e8 20          	shr    $0x20,%rax
    95e6:	48 39 d0             	cmp    %rdx,%rax
    95e9:	73 17                	jae    9602 <fwp_hof0.constprop.0+0x1a2>
    95eb:	48 01 c7             	add    %rax,%rdi
    95ee:	0f b6 07             	movzbl (%rdi),%eax
    95f1:	84 c0                	test   %al,%al
    95f3:	74 0d                	je     9602 <fwp_hof0.constprop.0+0x1a2>
    95f5:	3c fd                	cmp    $0xfd,%al
    95f7:	0f 87 fe 14 00 00    	ja     aafb <fwp_hof0.constprop.0+0x169b>
    95fd:	83 c0 01             	add    $0x1,%eax
    9600:	88 07                	mov    %al,(%rdi)
    9602:	48 8d 3d 07 9a 00 00 	lea    0x9a07(%rip),%rdi        # 13010 <fc37>
    9609:	e8 52 d4 ff ff       	call   6a60 <fwp_closure_drop>
    960e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    9613:	48 85 c0             	test   %rax,%rax
    9616:	0f 84 03 14 00 00    	je     aa1f <fwp_hof0.constprop.0+0x15bf>
    961c:	31 ed                	xor    %ebp,%ebp
    961e:	66 90                	xchg   %ax,%ax
    9620:	48 8b 40 10          	mov    0x10(%rax),%rax
    9624:	48 83 c5 01          	add    $0x1,%rbp
    9628:	48 85 c0             	test   %rax,%rax
    962b:	75 f3                	jne    9620 <fwp_hof0.constprop.0+0x1c0>
    962d:	31 ff                	xor    %edi,%edi
    962f:	e8 1c ac ff ff       	call   4250 <descent_phase_step>
    9634:	48 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%rbp
    963b:	0f 87 b7 15 00 00    	ja     abf8 <fwp_hof0.constprop.0+0x1798>
    9641:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    9646:	8b 35 14 9a 00 00    	mov    0x9a14(%rip),%esi        # 13060 <registered_finish.1>
    964c:	85 f6                	test   %esi,%esi
    964e:	0f 84 b4 11 00 00    	je     a808 <fwp_hof0.constprop.0+0x13a8>
    9654:	48 8b 15 7d 9a 01 00 	mov    0x19a7d(%rip),%rdx        # 230d8 <fwp_tape_next_slot>
    965b:	4c 8b 25 86 9a 01 00 	mov    0x19a86(%rip),%r12        # 230e8 <fwp_ntapes>
    9662:	49 39 d4             	cmp    %rdx,%r12
    9665:	0f 8e 65 10 00 00    	jle    a6d0 <fwp_hof0.constprop.0+0x1270>
    966b:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    966f:	48 03 05 7a 9a 01 00 	add    0x19a7a(%rip),%rax        # 230f0 <fwp_tapes>
    9676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    967d:	00 00 00 
    9680:	8b 48 04             	mov    0x4(%rax),%ecx
    9683:	85 c9                	test   %ecx,%ecx
    9685:	75 0c                	jne    9693 <fwp_hof0.constprop.0+0x233>
    9687:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    968d:	0f 86 3d 10 00 00    	jbe    a6d0 <fwp_hof0.constprop.0+0x1270>
    9693:	48 83 c2 01          	add    $0x1,%rdx
    9697:	48 83 c0 68          	add    $0x68,%rax
    969b:	49 39 d4             	cmp    %rdx,%r12
    969e:	75 e0                	jne    9680 <fwp_hof0.constprop.0+0x220>
    96a0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    96a7:	0f 8f cf 15 00 00    	jg     ac7c <fwp_hof0.constprop.0+0x181c>
    96ad:	4c 3b 25 2c 9a 01 00 	cmp    0x19a2c(%rip),%r12        # 230e0 <fwp_tapes_cap>
    96b4:	4c 8b 0d 35 9a 01 00 	mov    0x19a35(%rip),%r9        # 230f0 <fwp_tapes>
    96bb:	75 49                	jne    9706 <fwp_hof0.constprop.0+0x2a6>
    96bd:	4d 85 e4             	test   %r12,%r12
    96c0:	0f 84 4a 13 00 00    	je     aa10 <fwp_hof0.constprop.0+0x15b0>
    96c6:	4b 8d 2c 24          	lea    (%r12,%r12,1),%rbp
    96ca:	b8 ff ff 00 00       	mov    $0xffff,%eax
    96cf:	48 39 c5             	cmp    %rax,%rbp
    96d2:	48 0f 4f e8          	cmovg  %rax,%rbp
    96d6:	48 6b f5 68          	imul   $0x68,%rbp,%rsi
    96da:	4c 89 cf             	mov    %r9,%rdi
    96dd:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    96e2:	e8 e9 9e ff ff       	call   35d0 <realloc@plt>
    96e7:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    96ec:	48 85 c0             	test   %rax,%rax
    96ef:	49 89 c1             	mov    %rax,%r9
    96f2:	0f 84 90 15 00 00    	je     ac88 <fwp_hof0.constprop.0+0x1828>
    96f8:	48 89 05 f1 99 01 00 	mov    %rax,0x199f1(%rip)        # 230f0 <fwp_tapes>
    96ff:	48 89 2d da 99 01 00 	mov    %rbp,0x199da(%rip)        # 230e0 <fwp_tapes_cap>
    9706:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    970a:	31 c0                	xor    %eax,%eax
    970c:	49 8d 6c 24 01       	lea    0x1(%r12),%rbp
    9711:	4c 01 c9             	add    %r9,%rcx
    9714:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    9718:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    971f:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9723:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    972a:	00 
    972b:	48 29 f9             	sub    %rdi,%rcx
    972e:	83 c1 68             	add    $0x68,%ecx
    9731:	c1 e9 03             	shr    $0x3,%ecx
    9734:	f3 48 ab             	rep stos %rax,(%rdi)
    9737:	48 89 2d aa 99 01 00 	mov    %rbp,0x199aa(%rip)        # 230e8 <fwp_ntapes>
    973e:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    9742:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9746:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    974b:	48 8d 3d d0 59 00 00 	lea    0x59d0(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    9752:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    9757:	4c 01 c9             	add    %r9,%rcx
    975a:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    9761:	00 
    9762:	48 89 0c 24          	mov    %rcx,(%rsp)
    9766:	e8 35 9c ff ff       	call   33a0 <getenv@plt>
    976b:	48 8b 0c 24          	mov    (%rsp),%rcx
    976f:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    9774:	48 85 c0             	test   %rax,%rax
    9777:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
    977d:	0f 84 2d 0d 00 00    	je     a4b0 <fwp_hof0.constprop.0+0x1050>
    9783:	80 38 30             	cmpb   $0x30,(%rax)
    9786:	0f 85 24 0d 00 00    	jne    a4b0 <fwp_hof0.constprop.0+0x1050>
    978c:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9790:	0f 85 1a 0d 00 00    	jne    a4b0 <fwp_hof0.constprop.0+0x1050>
    9796:	8b 01                	mov    (%rcx),%eax
    9798:	c7 41 04 01 00 00 00 	movl   $0x1,0x4(%rcx)
    979f:	48 89 2d 32 99 01 00 	mov    %rbp,0x19932(%rip)        # 230d8 <fwp_tape_next_slot>
    97a6:	44 8d 70 01          	lea    0x1(%rax),%r14d
    97aa:	48 8b 05 df 63 00 00 	mov    0x63df(%rip),%rax        # fb90 <msg.4+0x20>
    97b1:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    97b8:	00 
    97b9:	44 89 31             	mov    %r14d,(%rcx)
    97bc:	48 89 41 58          	mov    %rax,0x58(%rcx)
    97c0:	48 8b 05 91 bc 01 00 	mov    0x1bc91(%rip),%rax        # 25458 <fwp_cleanups>
    97c7:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
    97cb:	48 85 c0             	test   %rax,%rax
    97ce:	75 1c                	jne    97ec <fwp_hof0.constprop.0+0x38c>
    97d0:	e9 4b 14 00 00       	jmp    ac20 <fwp_hof0.constprop.0+0x17c0>
    97d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    97dc:	00 00 00 00 
    97e0:	48 8b 00             	mov    (%rax),%rax
    97e3:	48 85 c0             	test   %rax,%rax
    97e6:	0f 84 34 14 00 00    	je     ac20 <fwp_hof0.constprop.0+0x17c0>
    97ec:	4c 39 78 08          	cmp    %r15,0x8(%rax)
    97f0:	75 ee                	jne    97e0 <fwp_hof0.constprop.0+0x380>
    97f2:	48 8b 78 10          	mov    0x10(%rax),%rdi
    97f6:	44 89 e6             	mov    %r12d,%esi
    97f9:	48 63 07             	movslq (%rdi),%rax
    97fc:	48 89 79 50          	mov    %rdi,0x50(%rcx)
    9800:	89 41 5c             	mov    %eax,0x5c(%rcx)
    9803:	85 c0                	test   %eax,%eax
    9805:	78 09                	js     9810 <fwp_hof0.constprop.0+0x3b0>
    9807:	48 6b c0 68          	imul   $0x68,%rax,%rax
    980b:	45 89 64 01 58       	mov    %r12d,0x58(%r9,%rax,1)
    9810:	89 37                	mov    %esi,(%rdi)
    9812:	bf 01 00 00 00       	mov    $0x1,%edi
    9817:	45 31 e4             	xor    %r12d,%r12d
    981a:	e8 31 aa ff ff       	call   4250 <descent_phase_step>
    981f:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9824:	48 89 f8             	mov    %rdi,%rax
    9827:	48 85 ff             	test   %rdi,%rdi
    982a:	0f 84 d0 0d 00 00    	je     a600 <fwp_hof0.constprop.0+0x11a0>
    9830:	48 8b 40 10          	mov    0x10(%rax),%rax
    9834:	49 83 c4 01          	add    $0x1,%r12
    9838:	48 85 c0             	test   %rax,%rax
    983b:	75 f3                	jne    9830 <fwp_hof0.constprop.0+0x3d0>
    983d:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    9842:	0f 1f 00             	nopl   (%rax)
    9845:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    984c:	00 00 00 00 
    9850:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9854:	48 83 c0 01          	add    $0x1,%rax
    9858:	48 85 c9             	test   %rcx,%rcx
    985b:	75 f3                	jne    9850 <fwp_hof0.constprop.0+0x3f0>
    985d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    9864:	ff ff 1f 
    9867:	48 39 c1             	cmp    %rax,%rcx
    986a:	0f 82 a0 13 00 00    	jb     ac10 <fwp_hof0.constprop.0+0x17b0>
    9870:	4d 85 e4             	test   %r12,%r12
    9873:	0f 8e 87 0d 00 00    	jle    a600 <fwp_hof0.constprop.0+0x11a0>
    9879:	49 39 c4             	cmp    %rax,%r12
    987c:	4c 0f 47 e0          	cmova  %rax,%r12
    9880:	4c 89 e0             	mov    %r12,%rax
    9883:	48 c1 e8 3c          	shr    $0x3c,%rax
    9887:	0f 85 83 13 00 00    	jne    ac10 <fwp_hof0.constprop.0+0x17b0>
    988d:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    9891:	44 89 f2             	mov    %r14d,%edx
    9894:	be 02 00 00 00       	mov    $0x2,%esi
    9899:	48 c1 e2 10          	shl    $0x10,%rdx
    989d:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    98a4:	00 
    98a5:	48 09 d5             	or     %rdx,%rbp
    98a8:	e8 e3 c3 ff ff       	call   5c90 <fwp_heap_alloc>
    98ad:	4c 89 38             	mov    %r15,(%rax)
    98b0:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    98b7:	49 89 c6             	mov    %rax,%r14
    98ba:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    98c1:	48 c1 e2 10          	shl    $0x10,%rdx
    98c5:	48 39 d0             	cmp    %rdx,%rax
    98c8:	0f 83 e2 0d 00 00    	jae    a6b0 <fwp_hof0.constprop.0+0x1250>
    98ce:	48 89 c2             	mov    %rax,%rdx
    98d1:	48 c1 ea 10          	shr    $0x10,%rdx
    98d5:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    98d9:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    98e0:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    98e4:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    98e8:	4d 85 ff             	test   %r15,%r15
    98eb:	74 3a                	je     9927 <fwp_hof0.constprop.0+0x4c7>
    98ed:	0f b6 32             	movzbl (%rdx),%esi
    98f0:	40 80 fe 02          	cmp    $0x2,%sil
    98f4:	0f 84 77 0d 00 00    	je     a671 <fwp_hof0.constprop.0+0x1211>
    98fa:	40 80 fe 01          	cmp    $0x1,%sil
    98fe:	75 27                	jne    9927 <fwp_hof0.constprop.0+0x4c7>
    9900:	8b 72 18             	mov    0x18(%rdx),%esi
    9903:	0f b7 c0             	movzwl %ax,%eax
    9906:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9909:	48 0f af c6          	imul   %rsi,%rax
    990d:	48 c1 e8 20          	shr    $0x20,%rax
    9911:	48 39 d0             	cmp    %rdx,%rax
    9914:	73 11                	jae    9927 <fwp_hof0.constprop.0+0x4c7>
    9916:	49 01 c7             	add    %rax,%r15
    9919:	41 80 3f ff          	cmpb   $0xff,(%r15)
    991d:	0f 84 61 0d 00 00    	je     a684 <fwp_hof0.constprop.0+0x1224>
    9923:	41 c6 07 01          	movb   $0x1,(%r15)
    9927:	4d 85 e4             	test   %r12,%r12
    992a:	74 48                	je     9974 <fwp_hof0.constprop.0+0x514>
    992c:	48 89 ee             	mov    %rbp,%rsi
    992f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    9934:	31 c0                	xor    %eax,%eax
    9936:	48 c1 e6 20          	shl    $0x20,%rsi
    993a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9940:	48 89 c1             	mov    %rax,%rcx
    9943:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9948:	48 01 f1             	add    %rsi,%rcx
    994b:	0f 80 ff 9d ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9951:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    9956:	48 89 c1             	mov    %rax,%rcx
    9959:	48 83 c0 01          	add    $0x1,%rax
    995d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9961:	48 c1 e1 04          	shl    $0x4,%rcx
    9965:	41 0f 11 44 0e 08    	movups %xmm0,0x8(%r14,%rcx,1)
    996b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    996f:	4c 39 e0             	cmp    %r12,%rax
    9972:	72 cc                	jb     9940 <fwp_hof0.constprop.0+0x4e0>
    9974:	49 8b 06             	mov    (%r14),%rax
    9977:	48 d1 e8             	shr    $1,%rax
    997a:	0f 84 40 0d 00 00    	je     a6c0 <fwp_hof0.constprop.0+0x1260>
    9980:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9984:	48 89 f7             	mov    %rsi,%rdi
    9987:	48 c1 ef 3c          	shr    $0x3c,%rdi
    998b:	0f 85 7f 12 00 00    	jne    ac10 <fwp_hof0.constprop.0+0x17b0>
    9991:	48 8d 14 36          	lea    (%rsi,%rsi,1),%rdx
    9995:	48 85 f6             	test   %rsi,%rsi
    9998:	74 48                	je     99e2 <fwp_hof0.constprop.0+0x582>
    999a:	48 c1 e0 04          	shl    $0x4,%rax
    999e:	48 89 1c 24          	mov    %rbx,(%rsp)
    99a2:	49 89 d7             	mov    %rdx,%r15
    99a5:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    99a9:	4d 8d 64 06 f8       	lea    -0x8(%r14,%rax,1),%r12
    99ae:	66 90                	xchg   %ax,%ax
    99b0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    99b4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    99b8:	48 83 c3 10          	add    $0x10,%rbx
    99bc:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    99c0:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    99c4:	e8 17 ca ff ff       	call   63e0 <w120>
    99c9:	66 48 0f 6e e0       	movq   %rax,%xmm4
    99ce:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    99d2:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    99d6:	49 39 dc             	cmp    %rbx,%r12
    99d9:	75 d5                	jne    99b0 <fwp_hof0.constprop.0+0x550>
    99db:	48 8b 1c 24          	mov    (%rsp),%rbx
    99df:	4c 89 fa             	mov    %r15,%rdx
    99e2:	49 89 16             	mov    %rdx,(%r14)
    99e5:	4c 89 f7             	mov    %r14,%rdi
    99e8:	4c 63 fd             	movslq %ebp,%r15
    99eb:	e8 b0 cb ff ff       	call   65a0 <w176.constprop.0>
    99f0:	4c 89 f7             	mov    %r14,%rdi
    99f3:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    99f8:	e8 d3 e2 ff ff       	call   7cd0 <fwp_drop10>
    99fd:	bf 02 00 00 00       	mov    $0x2,%edi
    9a02:	e8 49 a8 ff ff       	call   4250 <descent_phase_step>
    9a07:	4c 89 ff             	mov    %r15,%rdi
    9a0a:	e8 c1 ac ff ff       	call   46d0 <fwp_tape_of>
    9a0f:	48 89 c6             	mov    %rax,%rsi
    9a12:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9a17:	0f 85 99 12 00 00    	jne    acb6 <fwp_hof0.constprop.0+0x1856>
    9a1d:	48 89 c7             	mov    %rax,%rdi
    9a20:	e8 db a1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    9a25:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    9a2a:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    9a2e:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9a35:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    9a3a:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9a3f:	0f 29 74 24 10       	movaps %xmm6,0x10(%rsp)
    9a44:	66 48 0f 6e f2       	movq   %rdx,%xmm6
    9a49:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    9a4d:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    9a51:	4c 8b 66 40          	mov    0x40(%rsi),%r12
    9a55:	0f 29 3c 24          	movaps %xmm7,(%rsp)
    9a59:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9a5d:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    9a63:	77 18                	ja     9a7d <fwp_hof0.constprop.0+0x61d>
    9a65:	0f b7 c5             	movzwl %bp,%eax
    9a68:	83 e8 01             	sub    $0x1,%eax
    9a6b:	48 98                	cltq
    9a6d:	48 3b 05 64 96 01 00 	cmp    0x19664(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    9a74:	7d 07                	jge    9a7d <fwp_hof0.constprop.0+0x61d>
    9a76:	48 89 05 5b 96 01 00 	mov    %rax,0x1965b(%rip)        # 230d8 <fwp_tape_next_slot>
    9a7d:	48 8b 05 d4 b9 01 00 	mov    0x1b9d4(%rip),%rax        # 25458 <fwp_cleanups>
    9a84:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9a88:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9a8f:	00 
    9a90:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9a94:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    9a9a:	66 0f 6f 34 24       	movdqa (%rsp),%xmm6
    9a9f:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9aa6:	00 
    9aa7:	48 8d 05 c2 b5 ff ff 	lea    -0x4a3e(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    9aae:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9ab5:	00 
    9ab6:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9abd:	00 
    9abe:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9ac2:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9ac6:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    9acb:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9ad2:	00 
    9ad3:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    9ada:	00 
    9adb:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9ae0:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9ae7:	00 
    9ae8:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    9aef:	00 
    9af0:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    9af7:	00 
    9af8:	48 89 05 59 b9 01 00 	mov    %rax,0x1b959(%rip)        # 25458 <fwp_cleanups>
    9aff:	0f 29 bc 24 c0 00 00 	movaps %xmm7,0xc0(%rsp)
    9b06:	00 
    9b07:	0f 29 b4 24 d0 00 00 	movaps %xmm6,0xd0(%rsp)
    9b0e:	00 
    9b0f:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    9b16:	00 
    9b17:	48 85 f6             	test   %rsi,%rsi
    9b1a:	0f 88 40 0d 00 00    	js     a860 <fwp_hof0.constprop.0+0x1400>
    9b20:	48 89 f0             	mov    %rsi,%rax
    9b23:	48 c1 f8 20          	sar    $0x20,%rax
    9b27:	49 39 c7             	cmp    %rax,%r15
    9b2a:	0f 85 9d 10 00 00    	jne    abcd <fwp_hof0.constprop.0+0x176d>
    9b30:	41 89 f2             	mov    %esi,%r10d
    9b33:	4d 89 d7             	mov    %r10,%r15
    9b36:	4c 39 d7             	cmp    %r10,%rdi
    9b39:	0f 8e 9a 10 00 00    	jle    abd9 <fwp_hof0.constprop.0+0x1779>
    9b3f:	4d 39 d6             	cmp    %r10,%r14
    9b42:	0f 8e c8 0b 00 00    	jle    a710 <fwp_hof0.constprop.0+0x12b0>
    9b48:	49 39 d6             	cmp    %rdx,%r14
    9b4b:	0f 8f 07 0c 00 00    	jg     a758 <fwp_hof0.constprop.0+0x12f8>
    9b51:	4d 85 e4             	test   %r12,%r12
    9b54:	0f 84 db 10 00 00    	je     ac35 <fwp_hof0.constprop.0+0x17d5>
    9b5a:	31 f6                	xor    %esi,%esi
    9b5c:	4c 89 e7             	mov    %r12,%rdi
    9b5f:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    9b64:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    9b68:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9b6f:	00 
    9b70:	e8 4b 99 ff ff       	call   34c0 <memset@plt>
    9b75:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
    9b7a:	45 31 db             	xor    %r11d,%r11d
    9b7d:	f2 0f 10 05 13 60 00 	movsd  0x6013(%rip),%xmm0        # fb98 <msg.4+0x28>
    9b84:	00 
    9b85:	f2 43 0f 58 04 d4    	addsd  (%r12,%r10,8),%xmm0
    9b8b:	f2 43 0f 11 04 d4    	movsd  %xmm0,(%r12,%r10,8)
    9b91:	bf 03 00 00 00       	mov    $0x3,%edi
    9b96:	4c 01 35 63 95 01 00 	add    %r14,0x19563(%rip)        # 23100 <descent_inputs>
    9b9d:	4c 01 1d 64 95 01 00 	add    %r11,0x19564(%rip)        # 23108 <descent_nodes>
    9ba4:	e8 a7 a6 ff ff       	call   4250 <descent_phase_step>
    9ba9:	4d 39 f7             	cmp    %r14,%r15
    9bac:	0f 8c 86 00 00 00    	jl     9c38 <fwp_hof0.constprop.0+0x7d8>
    9bb2:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    9bb7:	4c 8b 14 24          	mov    (%rsp),%r10
    9bbb:	4d 29 f7             	sub    %r14,%r15
    9bbe:	4b 8d 2c f4          	lea    (%r12,%r14,8),%rbp
    9bc2:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9bc7:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9bcc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9bd0:	4b 8d 14 fb          	lea    (%r11,%r15,8),%rdx
    9bd4:	4c 29 dd             	sub    %r11,%rbp
    9bd7:	4d 29 da             	sub    %r11,%r10
    9bda:	4a 8d 04 bf          	lea    (%rdi,%r15,4),%rax
    9bde:	48 29 fe             	sub    %rdi,%rsi
    9be1:	eb 09                	jmp    9bec <fwp_hof0.constprop.0+0x78c>
    9be3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9be8:	48 83 e8 04          	sub    $0x4,%rax
    9bec:	f2 0f 10 44 15 00    	movsd  0x0(%rbp,%rdx,1),%xmm0
    9bf2:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9bf6:	7a 02                	jp     9bfa <fwp_hof0.constprop.0+0x79a>
    9bf8:	74 35                	je     9c2f <fwp_hof0.constprop.0+0x7cf>
    9bfa:	48 63 0c 06          	movslq (%rsi,%rax,1),%rcx
    9bfe:	85 c9                	test   %ecx,%ecx
    9c00:	78 16                	js     9c18 <fwp_hof0.constprop.0+0x7b8>
    9c02:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    9c08:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9c0c:	f2 41 0f 58 0c cc    	addsd  (%r12,%rcx,8),%xmm1
    9c12:	f2 41 0f 11 0c cc    	movsd  %xmm1,(%r12,%rcx,8)
    9c18:	48 63 08             	movslq (%rax),%rcx
    9c1b:	85 c9                	test   %ecx,%ecx
    9c1d:	78 10                	js     9c2f <fwp_hof0.constprop.0+0x7cf>
    9c1f:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9c23:	f2 41 0f 58 04 cc    	addsd  (%r12,%rcx,8),%xmm0
    9c29:	f2 41 0f 11 04 cc    	movsd  %xmm0,(%r12,%rcx,8)
    9c2f:	48 83 ea 08          	sub    $0x8,%rdx
    9c33:	48 39 c7             	cmp    %rax,%rdi
    9c36:	75 b0                	jne    9be8 <fwp_hof0.constprop.0+0x788>
    9c38:	bf 04 00 00 00       	mov    $0x4,%edi
    9c3d:	e8 0e a6 ff ff       	call   4250 <descent_phase_step>
    9c42:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9c49:	ff ff 1f 
    9c4c:	4c 39 f0             	cmp    %r14,%rax
    9c4f:	0f 82 af 0f 00 00    	jb     ac04 <fwp_hof0.constprop.0+0x17a4>
    9c55:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9c5c:	00 
    9c5d:	be 02 00 00 00       	mov    $0x2,%esi
    9c62:	e8 29 c0 ff ff       	call   5c90 <fwp_heap_alloc>
    9c67:	4c 89 30             	mov    %r14,(%rax)
    9c6a:	49 89 c7             	mov    %rax,%r15
    9c6d:	4d 85 f6             	test   %r14,%r14
    9c70:	74 20                	je     9c92 <fwp_hof0.constprop.0+0x832>
    9c72:	0f 1f 00             	nopl   (%rax)
    9c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9c7c:	00 00 00 00 
    9c80:	49 8b 04 dc          	mov    (%r12,%rbx,8),%rax
    9c84:	49 89 44 df 08       	mov    %rax,0x8(%r15,%rbx,8)
    9c89:	48 83 c3 01          	add    $0x1,%rbx
    9c8d:	49 39 de             	cmp    %rbx,%r14
    9c90:	75 ee                	jne    9c80 <fwp_hof0.constprop.0+0x820>
    9c92:	bf 05 00 00 00       	mov    $0x5,%edi
    9c97:	e8 b4 a5 ff ff       	call   4250 <descent_phase_step>
    9c9c:	4c 8b a4 24 a0 00 00 	mov    0xa0(%rsp),%r12
    9ca3:	00 
    9ca4:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    9ca9:	4c 89 25 a8 b7 01 00 	mov    %r12,0x1b7a8(%rip)        # 25458 <fwp_cleanups>
    9cb0:	e8 bb b3 ff ff       	call   5070 <fwp_tape_buffers_release>
    9cb5:	bf 06 00 00 00       	mov    $0x6,%edi
    9cba:	e8 91 a5 ff ff       	call   4250 <descent_phase_step>
    9cbf:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9cc6:	4c 89 f8             	mov    %r15,%rax
    9cc9:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9cd0:	48 c1 e2 10          	shl    $0x10,%rdx
    9cd4:	48 39 d0             	cmp    %rdx,%rax
    9cd7:	73 57                	jae    9d30 <fwp_hof0.constprop.0+0x8d0>
    9cd9:	48 89 c2             	mov    %rax,%rdx
    9cdc:	48 c1 ea 10          	shr    $0x10,%rdx
    9ce0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ce4:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9ceb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9cef:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9cf3:	48 85 ed             	test   %rbp,%rbp
    9cf6:	74 38                	je     9d30 <fwp_hof0.constprop.0+0x8d0>
    9cf8:	0f b6 0a             	movzbl (%rdx),%ecx
    9cfb:	80 f9 02             	cmp    $0x2,%cl
    9cfe:	0f 84 8c 0b 00 00    	je     a890 <fwp_hof0.constprop.0+0x1430>
    9d04:	80 f9 01             	cmp    $0x1,%cl
    9d07:	75 27                	jne    9d30 <fwp_hof0.constprop.0+0x8d0>
    9d09:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d0c:	0f b7 c0             	movzwl %ax,%eax
    9d0f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d12:	48 0f af c1          	imul   %rcx,%rax
    9d16:	48 c1 e8 20          	shr    $0x20,%rax
    9d1a:	48 39 d0             	cmp    %rdx,%rax
    9d1d:	73 11                	jae    9d30 <fwp_hof0.constprop.0+0x8d0>
    9d1f:	48 01 c5             	add    %rax,%rbp
    9d22:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9d26:	0f 84 77 0b 00 00    	je     a8a3 <fwp_hof0.constprop.0+0x1443>
    9d2c:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9d30:	4c 3b 64 24 50       	cmp    0x50(%rsp),%r12
    9d35:	0f 85 10 9a ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9d3b:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9d42:	00 
    9d43:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
    9d48:	48 89 05 09 b7 01 00 	mov    %rax,0x1b709(%rip)        # 25458 <fwp_cleanups>
    9d4f:	e8 4c d0 ff ff       	call   6da0 <fwp_tape_scope_release>
    9d54:	49 8b 07             	mov    (%r15),%rax
    9d57:	49 89 c6             	mov    %rax,%r14
    9d5a:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9d5f:	48 85 c0             	test   %rax,%rax
    9d62:	0f 88 d8 07 00 00    	js     a540 <fwp_hof0.constprop.0+0x10e0>
    9d68:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9d6f:	4c 89 f8             	mov    %r15,%rax
    9d72:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9d79:	48 c1 e2 10          	shl    $0x10,%rdx
    9d7d:	48 39 d0             	cmp    %rdx,%rax
    9d80:	0f 83 ba 07 00 00    	jae    a540 <fwp_hof0.constprop.0+0x10e0>
    9d86:	48 89 c2             	mov    %rax,%rdx
    9d89:	48 c1 ea 10          	shr    $0x10,%rdx
    9d8d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d91:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9d98:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d9c:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9da0:	48 85 c9             	test   %rcx,%rcx
    9da3:	0f 84 97 07 00 00    	je     a540 <fwp_hof0.constprop.0+0x10e0>
    9da9:	0f b6 32             	movzbl (%rdx),%esi
    9dac:	40 80 fe 02          	cmp    $0x2,%sil
    9db0:	0f 84 7a 07 00 00    	je     a530 <fwp_hof0.constprop.0+0x10d0>
    9db6:	40 80 fe 01          	cmp    $0x1,%sil
    9dba:	0f 85 80 07 00 00    	jne    a540 <fwp_hof0.constprop.0+0x10e0>
    9dc0:	8b 72 18             	mov    0x18(%rdx),%esi
    9dc3:	0f b7 c0             	movzwl %ax,%eax
    9dc6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9dc9:	48 0f af c6          	imul   %rsi,%rax
    9dcd:	48 c1 e8 20          	shr    $0x20,%rax
    9dd1:	48 39 d0             	cmp    %rdx,%rax
    9dd4:	0f 83 66 07 00 00    	jae    a540 <fwp_hof0.constprop.0+0x10e0>
    9dda:	48 01 c1             	add    %rax,%rcx
    9ddd:	80 39 01             	cmpb   $0x1,(%rcx)
    9de0:	0f 85 5a 07 00 00    	jne    a540 <fwp_hof0.constprop.0+0x10e0>
    9de6:	4c 89 3c 24          	mov    %r15,(%rsp)
    9dea:	4c 89 fd             	mov    %r15,%rbp
    9ded:	31 ff                	xor    %edi,%edi
    9def:	48 8b 04 24          	mov    (%rsp),%rax
    9df3:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9df7:	31 c0                	xor    %eax,%eax
    9df9:	4d 85 f6             	test   %r14,%r14
    9dfc:	75 2c                	jne    9e2a <fwp_hof0.constprop.0+0x9ca>
    9dfe:	eb 40                	jmp    9e40 <fwp_hof0.constprop.0+0x9e0>
    9e00:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9e05:	0f 88 da 0d 00 00    	js     abe5 <fwp_hof0.constprop.0+0x1785>
    9e0b:	f2 0f 10 05 9d 5d 00 	movsd  0x5d9d(%rip),%xmm0        # fbb0 <msg.4+0x40>
    9e12:	00 
    9e13:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    9e18:	48 83 c0 01          	add    $0x1,%rax
    9e1c:	48 83 c2 08          	add    $0x8,%rdx
    9e20:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9e25:	49 39 c6             	cmp    %rax,%r14
    9e28:	74 16                	je     9e40 <fwp_hof0.constprop.0+0x9e0>
    9e2a:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    9e2e:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9e32:	79 cc                	jns    9e00 <fwp_hof0.constprop.0+0x9a0>
    9e34:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    9e38:	eb c6                	jmp    9e00 <fwp_hof0.constprop.0+0x9a0>
    9e3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e40:	e8 8b de ff ff       	call   7cd0 <fwp_drop10>
    9e45:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9e4a:	31 d2                	xor    %edx,%edx
    9e4c:	48 89 f8             	mov    %rdi,%rax
    9e4f:	48 85 ff             	test   %rdi,%rdi
    9e52:	0f 84 d7 0b 00 00    	je     aa2f <fwp_hof0.constprop.0+0x15cf>
    9e58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e5f:	00 
    9e60:	48 8b 40 10          	mov    0x10(%rax),%rax
    9e64:	48 83 c2 01          	add    $0x1,%rdx
    9e68:	48 85 c0             	test   %rax,%rax
    9e6b:	75 f3                	jne    9e60 <fwp_hof0.constprop.0+0xa00>
    9e6d:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9e71:	49 89 c7             	mov    %rax,%r15
    9e74:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9e79:	48 85 c0             	test   %rax,%rax
    9e7c:	0f 88 9b 05 00 00    	js     a41d <fwp_hof0.constprop.0+0xfbd>
    9e82:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    9e89:	48 8b 0c 24          	mov    (%rsp),%rcx
    9e8d:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    9e94:	48 c1 e0 10          	shl    $0x10,%rax
    9e98:	48 39 c1             	cmp    %rax,%rcx
    9e9b:	0f 83 7c 05 00 00    	jae    a41d <fwp_hof0.constprop.0+0xfbd>
    9ea1:	48 89 c8             	mov    %rcx,%rax
    9ea4:	48 c1 e8 10          	shr    $0x10,%rax
    9ea8:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    9eac:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    9eb3:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9eb7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9ebb:	48 85 ff             	test   %rdi,%rdi
    9ebe:	0f 84 59 05 00 00    	je     a41d <fwp_hof0.constprop.0+0xfbd>
    9ec4:	0f b6 06             	movzbl (%rsi),%eax
    9ec7:	3c 02                	cmp    $0x2,%al
    9ec9:	0f 84 39 05 00 00    	je     a408 <fwp_hof0.constprop.0+0xfa8>
    9ecf:	3c 01                	cmp    $0x1,%al
    9ed1:	0f 85 3a 05 00 00    	jne    a411 <fwp_hof0.constprop.0+0xfb1>
    9ed7:	8b 46 18             	mov    0x18(%rsi),%eax
    9eda:	0f b7 c9             	movzwl %cx,%ecx
    9edd:	48 0f af c8          	imul   %rax,%rcx
    9ee1:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9ee4:	48 c1 e9 20          	shr    $0x20,%rcx
    9ee8:	48 39 c1             	cmp    %rax,%rcx
    9eeb:	0f 83 20 05 00 00    	jae    a411 <fwp_hof0.constprop.0+0xfb1>
    9ef1:	48 01 cf             	add    %rcx,%rdi
    9ef4:	80 3f 01             	cmpb   $0x1,(%rdi)
    9ef7:	0f 85 14 05 00 00    	jne    a411 <fwp_hof0.constprop.0+0xfb1>
    9efd:	49 39 d7             	cmp    %rdx,%r15
    9f00:	48 89 d0             	mov    %rdx,%rax
    9f03:	49 0f 46 c7          	cmovbe %r15,%rax
    9f07:	48 85 c0             	test   %rax,%rax
    9f0a:	0f 84 e1 0c 00 00    	je     abf1 <fwp_hof0.constprop.0+0x1791>
    9f10:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    9f17:	00 
    9f18:	48 8d 5d 08          	lea    0x8(%rbp),%rbx
    9f1c:	4c 8b 04 24          	mov    (%rsp),%r8
    9f20:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    9f25:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    9f2c:	00 
    9f2d:	31 d2                	xor    %edx,%edx
    9f2f:	49 8d 78 08          	lea    0x8(%r8),%rdi
    9f33:	eb 27                	jmp    9f5c <fwp_hof0.constprop.0+0xafc>
    9f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f3c:	00 00 00 00 
    9f40:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9f45:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    9f4a:	f2 0f 11 04 13       	movsd  %xmm0,(%rbx,%rdx,1)
    9f4f:	48 83 c2 08          	add    $0x8,%rdx
    9f53:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9f57:	49 39 d1             	cmp    %rdx,%r9
    9f5a:	74 14                	je     9f70 <fwp_hof0.constprop.0+0xb10>
    9f5c:	48 89 fe             	mov    %rdi,%rsi
    9f5f:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9f64:	79 da                	jns    9f40 <fwp_hof0.constprop.0+0xae0>
    9f66:	49 8b 70 10          	mov    0x10(%r8),%rsi
    9f6a:	eb d4                	jmp    9f40 <fwp_hof0.constprop.0+0xae0>
    9f6c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f70:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    9f75:	48 85 c9             	test   %rcx,%rcx
    9f78:	0f 84 47 0c 00 00    	je     abc5 <fwp_hof0.constprop.0+0x1765>
    9f7e:	4d 8b 8d d8 13 00 00 	mov    0x13d8(%r13),%r9
    9f85:	4d 8b 95 b0 13 00 00 	mov    0x13b0(%r13),%r10
    9f8c:	45 31 ff             	xor    %r15d,%r15d
    9f8f:	4d 8b 9d f8 13 00 00 	mov    0x13f8(%r13),%r11
    9f96:	49 c1 e1 10          	shl    $0x10,%r9
    9f9a:	eb 1a                	jmp    9fb6 <fwp_hof0.constprop.0+0xb56>
    9f9c:	0f 1f 40 00          	nopl   0x0(%rax)
    9fa0:	49 83 c7 01          	add    $0x1,%r15
    9fa4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9fa8:	49 39 c7             	cmp    %rax,%r15
    9fab:	0f 83 5f 01 00 00    	jae    a110 <fwp_hof0.constprop.0+0xcb0>
    9fb1:	48 85 c9             	test   %rcx,%rcx
    9fb4:	74 56                	je     a00c <fwp_hof0.constprop.0+0xbac>
    9fb6:	48 89 ca             	mov    %rcx,%rdx
    9fb9:	4c 29 d2             	sub    %r10,%rdx
    9fbc:	4c 39 ca             	cmp    %r9,%rdx
    9fbf:	73 4b                	jae    a00c <fwp_hof0.constprop.0+0xbac>
    9fc1:	48 89 d6             	mov    %rdx,%rsi
    9fc4:	48 c1 ee 10          	shr    $0x10,%rsi
    9fc8:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9fcc:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    9fd0:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9fd4:	48 85 ff             	test   %rdi,%rdi
    9fd7:	74 33                	je     a00c <fwp_hof0.constprop.0+0xbac>
    9fd9:	44 0f b6 06          	movzbl (%rsi),%r8d
    9fdd:	41 80 f8 02          	cmp    $0x2,%r8b
    9fe1:	0f 84 11 01 00 00    	je     a0f8 <fwp_hof0.constprop.0+0xc98>
    9fe7:	41 80 f8 01          	cmp    $0x1,%r8b
    9feb:	75 1f                	jne    a00c <fwp_hof0.constprop.0+0xbac>
    9fed:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9ff1:	0f b7 d2             	movzwl %dx,%edx
    9ff4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9ff7:	49 0f af d0          	imul   %r8,%rdx
    9ffb:	48 c1 ea 20          	shr    $0x20,%rdx
    9fff:	48 39 f2             	cmp    %rsi,%rdx
    a002:	73 08                	jae    a00c <fwp_hof0.constprop.0+0xbac>
    a004:	48 01 d7             	add    %rdx,%rdi
    a007:	80 3f 01             	cmpb   $0x1,(%rdi)
    a00a:	74 94                	je     9fa0 <fwp_hof0.constprop.0+0xb40>
    a00c:	49 39 c7             	cmp    %rax,%r15
    a00f:	0f 83 fb 00 00 00    	jae    a110 <fwp_hof0.constprop.0+0xcb0>
    a015:	49 89 c4             	mov    %rax,%r12
    a018:	45 31 f6             	xor    %r14d,%r14d
    a01b:	48 8d ac 24 00 01 00 	lea    0x100(%rsp),%rbp
    a022:	00 
    a023:	eb 37                	jmp    a05c <fwp_hof0.constprop.0+0xbfc>
    a025:	0f 1f 00             	nopl   (%rax)
    a028:	40 80 fe 01          	cmp    $0x1,%sil
    a02c:	75 25                	jne    a053 <fwp_hof0.constprop.0+0xbf3>
    a02e:	8b 71 18             	mov    0x18(%rcx),%esi
    a031:	0f b7 c0             	movzwl %ax,%eax
    a034:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a037:	48 0f af c6          	imul   %rsi,%rax
    a03b:	48 c1 e8 20          	shr    $0x20,%rax
    a03f:	48 39 c8             	cmp    %rcx,%rax
    a042:	73 0f                	jae    a053 <fwp_hof0.constprop.0+0xbf3>
    a044:	48 01 c2             	add    %rax,%rdx
    a047:	80 3a ff             	cmpb   $0xff,(%rdx)
    a04a:	0f 84 98 05 00 00    	je     a5e8 <fwp_hof0.constprop.0+0x1188>
    a050:	c6 02 01             	movb   $0x1,(%rdx)
    a053:	4d 39 e7             	cmp    %r12,%r15
    a056:	0f 83 84 00 00 00    	jae    a0e0 <fwp_hof0.constprop.0+0xc80>
    a05c:	49 83 ec 01          	sub    $0x1,%r12
    a060:	66 49 0f 6e ee       	movq   %r14,%xmm5
    a065:	48 89 ee             	mov    %rbp,%rsi
    a068:	bf 01 00 00 00       	mov    $0x1,%edi
    a06d:	f3 42 0f 7e 04 e3    	movq   (%rbx,%r12,8),%xmm0
    a073:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a077:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    a07e:	00 
    a07f:	e8 2c bd ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    a084:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a08b:	49 89 c6             	mov    %rax,%r14
    a08e:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a095:	48 c1 e2 10          	shl    $0x10,%rdx
    a099:	48 39 d0             	cmp    %rdx,%rax
    a09c:	73 b5                	jae    a053 <fwp_hof0.constprop.0+0xbf3>
    a09e:	48 89 c2             	mov    %rax,%rdx
    a0a1:	48 c1 ea 10          	shr    $0x10,%rdx
    a0a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a0a9:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a0b0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a0b4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a0b8:	48 85 d2             	test   %rdx,%rdx
    a0bb:	74 96                	je     a053 <fwp_hof0.constprop.0+0xbf3>
    a0bd:	0f b6 31             	movzbl (%rcx),%esi
    a0c0:	40 80 fe 02          	cmp    $0x2,%sil
    a0c4:	0f 85 5e ff ff ff    	jne    a028 <fwp_hof0.constprop.0+0xbc8>
    a0ca:	66 85 c0             	test   %ax,%ax
    a0cd:	0f 84 74 ff ff ff    	je     a047 <fwp_hof0.constprop.0+0xbe7>
    a0d3:	4d 39 e7             	cmp    %r12,%r15
    a0d6:	72 84                	jb     a05c <fwp_hof0.constprop.0+0xbfc>
    a0d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a0df:	00 
    a0e0:	4d 85 ff             	test   %r15,%r15
    a0e3:	75 2e                	jne    a113 <fwp_hof0.constprop.0+0xcb3>
    a0e5:	8b 44 24 10          	mov    0x10(%rsp),%eax
    a0e9:	85 c0                	test   %eax,%eax
    a0eb:	49 0f 45 df          	cmovne %r15,%rbx
    a0ef:	eb 62                	jmp    a153 <fwp_hof0.constprop.0+0xcf3>
    a0f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a0f8:	66 85 d2             	test   %dx,%dx
    a0fb:	0f 84 06 ff ff ff    	je     a007 <fwp_hof0.constprop.0+0xba7>
    a101:	49 39 c7             	cmp    %rax,%r15
    a104:	0f 82 0b ff ff ff    	jb     a015 <fwp_hof0.constprop.0+0xbb5>
    a10a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a110:	45 31 f6             	xor    %r14d,%r14d
    a113:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    a118:	48 89 da             	mov    %rbx,%rdx
    a11b:	4e 8d 0c fb          	lea    (%rbx,%r15,8),%r9
    a11f:	90                   	nop
    a120:	48 8b 0a             	mov    (%rdx),%rcx
    a123:	48 83 c2 08          	add    $0x8,%rdx
    a127:	48 89 c7             	mov    %rax,%rdi
    a12a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    a12e:	48 8b 40 10          	mov    0x10(%rax),%rax
    a132:	4c 39 ca             	cmp    %r9,%rdx
    a135:	75 e9                	jne    a120 <fwp_hof0.constprop.0+0xcc0>
    a137:	8b 54 24 10          	mov    0x10(%rsp),%edx
    a13b:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    a13f:	85 d2                	test   %edx,%edx
    a141:	0f 84 69 07 00 00    	je     a8b0 <fwp_hof0.constprop.0+0x1450>
    a147:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
    a14c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    a151:	31 db                	xor    %ebx,%ebx
    a153:	48 89 df             	mov    %rbx,%rdi
    a156:	e8 35 b6 ff ff       	call   5790 <fwp_mem_free>
    a15b:	48 8b 3c 24          	mov    (%rsp),%rdi
    a15f:	e8 6c db ff ff       	call   7cd0 <fwp_drop10>
    a164:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a16b:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    a170:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a177:	48 c1 e2 10          	shl    $0x10,%rdx
    a17b:	48 39 d0             	cmp    %rdx,%rax
    a17e:	73 70                	jae    a1f0 <fwp_hof0.constprop.0+0xd90>
    a180:	48 89 c2             	mov    %rax,%rdx
    a183:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    a18a:	48 c1 ea 10          	shr    $0x10,%rdx
    a18e:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a192:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a196:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a19a:	48 85 ed             	test   %rbp,%rbp
    a19d:	74 51                	je     a1f0 <fwp_hof0.constprop.0+0xd90>
    a19f:	0f b6 0a             	movzbl (%rdx),%ecx
    a1a2:	80 f9 02             	cmp    $0x2,%cl
    a1a5:	0f 84 8d 06 00 00    	je     a838 <fwp_hof0.constprop.0+0x13d8>
    a1ab:	80 f9 01             	cmp    $0x1,%cl
    a1ae:	75 40                	jne    a1f0 <fwp_hof0.constprop.0+0xd90>
    a1b0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1b3:	0f b7 c0             	movzwl %ax,%eax
    a1b6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1b9:	48 0f af c1          	imul   %rcx,%rax
    a1bd:	48 c1 e8 20          	shr    $0x20,%rax
    a1c1:	48 39 d0             	cmp    %rdx,%rax
    a1c4:	73 2a                	jae    a1f0 <fwp_hof0.constprop.0+0xd90>
    a1c6:	48 01 c5             	add    %rax,%rbp
    a1c9:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a1cd:	84 c0                	test   %al,%al
    a1cf:	74 1f                	je     a1f0 <fwp_hof0.constprop.0+0xd90>
    a1d1:	3c 01                	cmp    $0x1,%al
    a1d3:	0f 84 e7 06 00 00    	je     a8c0 <fwp_hof0.constprop.0+0x1460>
    a1d9:	3c ff                	cmp    $0xff,%al
    a1db:	0f 84 b8 08 00 00    	je     aa99 <fwp_hof0.constprop.0+0x1639>
    a1e1:	83 e8 01             	sub    $0x1,%eax
    a1e4:	88 45 00             	mov    %al,0x0(%rbp)
    a1e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1ee:	00 00 
    a1f0:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
    a1f6:	0f 85 f4 04 00 00    	jne    a6f0 <fwp_hof0.constprop.0+0x1290>
    a1fc:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    a201:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a205:	4c 89 f6             	mov    %r14,%rsi
    a208:	4c 89 f5             	mov    %r14,%rbp
    a20b:	b9 01 00 00 00       	mov    $0x1,%ecx
    a210:	48 8d 15 69 89 00 00 	lea    0x8969(%rip),%rdx        # 12b80 <d0>
    a217:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a21e:	00 00 00 00 00 
    a223:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    a22a:	00 
    a22b:	e8 f0 e1 ff ff       	call   8420 <fwp_write>
    a230:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    a237:	00 
    a238:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
    a23f:	00 
    a240:	48 8d 05 4a 4e 00 00 	lea    0x4e4a(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    a247:	48 85 c9             	test   %rcx,%rcx
    a24a:	48 0f 44 c8          	cmove  %rax,%rcx
    a24e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a252:	0f 87 6f 0a 00 00    	ja     acc7 <fwp_hof0.constprop.0+0x1867>
    a258:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a25c:	be 01 00 00 00       	mov    $0x1,%esi
    a261:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    a266:	e8 25 ba ff ff       	call   5c90 <fwp_heap_alloc>
    a26b:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    a270:	4c 89 fa             	mov    %r15,%rdx
    a273:	4c 89 38             	mov    %r15,(%rax)
    a276:	4c 8d 70 08          	lea    0x8(%rax),%r14
    a27a:	48 89 c3             	mov    %rax,%rbx
    a27d:	4c 89 f7             	mov    %r14,%rdi
    a280:	e8 1b 93 ff ff       	call   35a0 <memcpy@plt>
    a285:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a28b:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    a292:	00 
    a293:	e8 28 91 ff ff       	call   33c0 <free@plt>
    a298:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a29f:	48 89 d8             	mov    %rbx,%rax
    a2a2:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a2a9:	48 c1 e2 10          	shl    $0x10,%rdx
    a2ad:	48 39 d0             	cmp    %rdx,%rax
    a2b0:	73 57                	jae    a309 <fwp_hof0.constprop.0+0xea9>
    a2b2:	48 89 c2             	mov    %rax,%rdx
    a2b5:	48 c1 ea 10          	shr    $0x10,%rdx
    a2b9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a2bd:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a2c4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a2c8:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a2cc:	4d 85 ff             	test   %r15,%r15
    a2cf:	74 38                	je     a309 <fwp_hof0.constprop.0+0xea9>
    a2d1:	0f b6 0a             	movzbl (%rdx),%ecx
    a2d4:	80 f9 02             	cmp    $0x2,%cl
    a2d7:	0f 84 e3 06 00 00    	je     a9c0 <fwp_hof0.constprop.0+0x1560>
    a2dd:	80 f9 01             	cmp    $0x1,%cl
    a2e0:	75 27                	jne    a309 <fwp_hof0.constprop.0+0xea9>
    a2e2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a2e5:	0f b7 c0             	movzwl %ax,%eax
    a2e8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a2eb:	48 0f af c1          	imul   %rcx,%rax
    a2ef:	48 c1 e8 20          	shr    $0x20,%rax
    a2f3:	48 39 d0             	cmp    %rdx,%rax
    a2f6:	73 11                	jae    a309 <fwp_hof0.constprop.0+0xea9>
    a2f8:	49 01 c7             	add    %rax,%r15
    a2fb:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a2ff:	0f 84 ce 06 00 00    	je     a9d3 <fwp_hof0.constprop.0+0x1573>
    a305:	41 c6 07 01          	movb   $0x1,(%r15)
    a309:	48 89 ef             	mov    %rbp,%rdi
    a30c:	e8 cf d5 ff ff       	call   78e0 <fwp_drop0>
    a311:	48 8b 13             	mov    (%rbx),%rdx
    a314:	be 01 00 00 00       	mov    $0x1,%esi
    a319:	4c 89 f7             	mov    %r14,%rdi
    a31c:	48 8b 0d fd b0 01 00 	mov    0x1b0fd(%rip),%rcx        # 25420 <fwp_prog_out>
    a323:	e8 58 93 ff ff       	call   3680 <fwrite@plt>
    a328:	48 8b 35 f1 b0 01 00 	mov    0x1b0f1(%rip),%rsi        # 25420 <fwp_prog_out>
    a32f:	bf 0a 00 00 00       	mov    $0xa,%edi
    a334:	e8 a7 91 ff ff       	call   34e0 <fputc@plt>
    a339:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a340:	48 89 d8             	mov    %rbx,%rax
    a343:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a34a:	48 c1 e2 10          	shl    $0x10,%rdx
    a34e:	48 39 d0             	cmp    %rdx,%rax
    a351:	73 6d                	jae    a3c0 <fwp_hof0.constprop.0+0xf60>
    a353:	48 89 c2             	mov    %rax,%rdx
    a356:	48 c1 ea 10          	shr    $0x10,%rdx
    a35a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a35e:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a365:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a369:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a36d:	48 85 ed             	test   %rbp,%rbp
    a370:	74 4e                	je     a3c0 <fwp_hof0.constprop.0+0xf60>
    a372:	0f b6 0a             	movzbl (%rdx),%ecx
    a375:	80 f9 02             	cmp    $0x2,%cl
    a378:	0f 84 62 06 00 00    	je     a9e0 <fwp_hof0.constprop.0+0x1580>
    a37e:	80 f9 01             	cmp    $0x1,%cl
    a381:	75 3d                	jne    a3c0 <fwp_hof0.constprop.0+0xf60>
    a383:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a386:	0f b7 c0             	movzwl %ax,%eax
    a389:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a38c:	48 0f af c1          	imul   %rcx,%rax
    a390:	48 c1 e8 20          	shr    $0x20,%rax
    a394:	48 39 d0             	cmp    %rdx,%rax
    a397:	73 27                	jae    a3c0 <fwp_hof0.constprop.0+0xf60>
    a399:	48 01 c5             	add    %rax,%rbp
    a39c:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a3a0:	84 c0                	test   %al,%al
    a3a2:	74 1c                	je     a3c0 <fwp_hof0.constprop.0+0xf60>
    a3a4:	3c 01                	cmp    $0x1,%al
    a3a6:	0f 84 51 06 00 00    	je     a9fd <fwp_hof0.constprop.0+0x159d>
    a3ac:	3c ff                	cmp    $0xff,%al
    a3ae:	0f 84 51 07 00 00    	je     ab05 <fwp_hof0.constprop.0+0x16a5>
    a3b4:	83 e8 01             	sub    $0x1,%eax
    a3b7:	88 45 00             	mov    %al,0x0(%rbp)
    a3ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3c0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    a3c5:	48 8b 40 10          	mov    0x10(%rax),%rax
    a3c9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a3ce:	48 85 c0             	test   %rax,%rax
    a3d1:	0f 85 c9 f0 ff ff    	jne    94a0 <fwp_hof0.constprop.0+0x40>
    a3d7:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    a3de:	00 
    a3df:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a3e6:	00 00 
    a3e8:	0f 85 d4 08 00 00    	jne    acc2 <fwp_hof0.constprop.0+0x1862>
    a3ee:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    a3f5:	31 c0                	xor    %eax,%eax
    a3f7:	5b                   	pop    %rbx
    a3f8:	5d                   	pop    %rbp
    a3f9:	41 5c                	pop    %r12
    a3fb:	41 5d                	pop    %r13
    a3fd:	41 5e                	pop    %r14
    a3ff:	41 5f                	pop    %r15
    a401:	c3                   	ret
    a402:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a408:	66 85 c9             	test   %cx,%cx
    a40b:	0f 84 e3 fa ff ff    	je     9ef4 <fwp_hof0.constprop.0+0xa94>
    a411:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
    a417:	0f 84 74 02 00 00    	je     a691 <fwp_hof0.constprop.0+0x1231>
    a41d:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    a422:	45 31 f6             	xor    %r14d,%r14d
    a425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a42c:	00 00 00 00 
    a430:	48 8b 40 10          	mov    0x10(%rax),%rax
    a434:	4c 89 f2             	mov    %r14,%rdx
    a437:	49 83 c6 01          	add    $0x1,%r14
    a43b:	48 85 c0             	test   %rax,%rax
    a43e:	75 f0                	jne    a430 <fwp_hof0.constprop.0+0xfd0>
    a440:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a447:	ff ff 1f 
    a44a:	4c 39 f0             	cmp    %r14,%rax
    a44d:	0f 82 bd 07 00 00    	jb     ac10 <fwp_hof0.constprop.0+0x17b0>
    a453:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a45a:	00 
    a45b:	be 02 00 00 00       	mov    $0x2,%esi
    a460:	e8 2b b8 ff ff       	call   5c90 <fwp_heap_alloc>
    a465:	4d 39 f7             	cmp    %r14,%r15
    a468:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    a46d:	48 89 c3             	mov    %rax,%rbx
    a470:	4c 89 f0             	mov    %r14,%rax
    a473:	49 0f 46 c7          	cmovbe %r15,%rax
    a477:	48 89 d9             	mov    %rbx,%rcx
    a47a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a480:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a484:	48 83 c1 08          	add    $0x8,%rcx
    a488:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a48c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a490:	48 85 d2             	test   %rdx,%rdx
    a493:	75 eb                	jne    a480 <fwp_hof0.constprop.0+0x1020>
    a495:	48 85 c0             	test   %rax,%rax
    a498:	0f 84 05 02 00 00    	je     a6a3 <fwp_hof0.constprop.0+0x1243>
    a49e:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    a4a5:	00 
    a4a6:	e9 71 fa ff ff       	jmp    9f1c <fwp_hof0.constprop.0+0xabc>
    a4ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4b0:	48 83 3d d0 8b 01 00 	cmpq   $0x0,0x18bd0(%rip)        # 23088 <fwp_tape_cached_bytes>
    a4b7:	00 
    a4b8:	0f 84 d8 f2 ff ff    	je     9796 <fwp_hof0.constprop.0+0x336>
    a4be:	66 0f 6f 0d da 8b 01 	movdqa 0x18bda(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a4c5:	00 
    a4c6:	48 c7 05 b7 8b 01 00 	movq   $0x0,0x18bb7(%rip)        # 23088 <fwp_tape_cached_bytes>
    a4cd:	00 00 00 00 
    a4d1:	0f 11 49 20          	movups %xmm1,0x20(%rcx)
    a4d5:	48 8b 05 e4 8b 01 00 	mov    0x18be4(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a4dc:	66 0f 6f 0d cc 8b 01 	movdqa 0x18bcc(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    a4e3:	00 
    a4e4:	48 89 41 40          	mov    %rax,0x40(%rcx)
    a4e8:	48 8b 05 d9 8b 01 00 	mov    0x18bd9(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    a4ef:	0f 11 49 30          	movups %xmm1,0x30(%rcx)
    a4f3:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a4f7:	48 89 41 18          	mov    %rax,0x18(%rcx)
    a4fb:	48 8b 05 ce 8b 01 00 	mov    0x18bce(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    a502:	0f 29 0d 97 8b 01 00 	movaps %xmm1,0x18b97(%rip)        # 230a0 <fwp_tape_workspace>
    a509:	48 89 41 48          	mov    %rax,0x48(%rcx)
    a50d:	0f 29 0d 9c 8b 01 00 	movaps %xmm1,0x18b9c(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a514:	48 c7 05 b1 8b 01 00 	movq   $0x0,0x18bb1(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    a51b:	00 00 00 00 
    a51f:	0f 29 0d 9a 8b 01 00 	movaps %xmm1,0x18b9a(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a526:	e9 6b f2 ff ff       	jmp    9796 <fwp_hof0.constprop.0+0x336>
    a52b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a530:	66 85 c0             	test   %ax,%ax
    a533:	0f 84 a4 f8 ff ff    	je     9ddd <fwp_hof0.constprop.0+0x97d>
    a539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a540:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a547:	ff ff 1f 
    a54a:	4c 39 f0             	cmp    %r14,%rax
    a54d:	0f 82 b1 06 00 00    	jb     ac04 <fwp_hof0.constprop.0+0x17a4>
    a553:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a55a:	00 
    a55b:	be 01 00 00 00       	mov    $0x1,%esi
    a560:	e8 2b b7 ff ff       	call   5c90 <fwp_heap_alloc>
    a565:	4c 89 30             	mov    %r14,(%rax)
    a568:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a56f:	48 89 c5             	mov    %rax,%rbp
    a572:	48 89 04 24          	mov    %rax,(%rsp)
    a576:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a57d:	48 c1 e2 10          	shl    $0x10,%rdx
    a581:	48 39 d0             	cmp    %rdx,%rax
    a584:	73 57                	jae    a5dd <fwp_hof0.constprop.0+0x117d>
    a586:	48 89 c2             	mov    %rax,%rdx
    a589:	48 c1 ea 10          	shr    $0x10,%rdx
    a58d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a591:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a598:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a59c:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    a5a0:	48 85 db             	test   %rbx,%rbx
    a5a3:	74 38                	je     a5dd <fwp_hof0.constprop.0+0x117d>
    a5a5:	0f b6 31             	movzbl (%rcx),%esi
    a5a8:	40 80 fe 02          	cmp    $0x2,%sil
    a5ac:	0f 84 b6 03 00 00    	je     a968 <fwp_hof0.constprop.0+0x1508>
    a5b2:	40 80 fe 01          	cmp    $0x1,%sil
    a5b6:	75 25                	jne    a5dd <fwp_hof0.constprop.0+0x117d>
    a5b8:	8b 71 18             	mov    0x18(%rcx),%esi
    a5bb:	0f b7 c0             	movzwl %ax,%eax
    a5be:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a5c1:	48 0f af c6          	imul   %rsi,%rax
    a5c5:	48 c1 e8 20          	shr    $0x20,%rax
    a5c9:	48 39 c8             	cmp    %rcx,%rax
    a5cc:	73 0f                	jae    a5dd <fwp_hof0.constprop.0+0x117d>
    a5ce:	48 01 c3             	add    %rax,%rbx
    a5d1:	80 3b ff             	cmpb   $0xff,(%rbx)
    a5d4:	0f 84 a0 03 00 00    	je     a97a <fwp_hof0.constprop.0+0x151a>
    a5da:	c6 03 01             	movb   $0x1,(%rbx)
    a5dd:	4c 89 ff             	mov    %r15,%rdi
    a5e0:	e9 0a f8 ff ff       	jmp    9def <fwp_hof0.constprop.0+0x98f>
    a5e5:	0f 1f 00             	nopl   (%rax)
    a5e8:	48 89 d7             	mov    %rdx,%rdi
    a5eb:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    a5f0:	e8 5b af ff ff       	call   5550 <fwp_rc_forget_slot>
    a5f5:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    a5fa:	e9 51 fa ff ff       	jmp    a050 <fwp_hof0.constprop.0+0xbf0>
    a5ff:	90                   	nop
    a600:	44 89 f2             	mov    %r14d,%edx
    a603:	be 02 00 00 00       	mov    $0x2,%esi
    a608:	bf 08 00 00 00       	mov    $0x8,%edi
    a60d:	48 c1 e2 10          	shl    $0x10,%rdx
    a611:	48 09 d5             	or     %rdx,%rbp
    a614:	e8 77 b6 ff ff       	call   5c90 <fwp_heap_alloc>
    a619:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a620:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a627:	49 89 c6             	mov    %rax,%r14
    a62a:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a631:	48 c1 e2 10          	shl    $0x10,%rdx
    a635:	48 39 d0             	cmp    %rdx,%rax
    a638:	0f 83 82 00 00 00    	jae    a6c0 <fwp_hof0.constprop.0+0x1260>
    a63e:	48 89 c2             	mov    %rax,%rdx
    a641:	48 c1 ea 10          	shr    $0x10,%rdx
    a645:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a649:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a650:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a654:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a658:	4d 85 ff             	test   %r15,%r15
    a65b:	0f 84 13 f3 ff ff    	je     9974 <fwp_hof0.constprop.0+0x514>
    a661:	0f b6 32             	movzbl (%rdx),%esi
    a664:	45 31 e4             	xor    %r12d,%r12d
    a667:	40 80 fe 02          	cmp    $0x2,%sil
    a66b:	0f 85 89 f2 ff ff    	jne    98fa <fwp_hof0.constprop.0+0x49a>
    a671:	66 85 c0             	test   %ax,%ax
    a674:	0f 85 ad f2 ff ff    	jne    9927 <fwp_hof0.constprop.0+0x4c7>
    a67a:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a67e:	0f 85 9f f2 ff ff    	jne    9923 <fwp_hof0.constprop.0+0x4c3>
    a684:	4c 89 ff             	mov    %r15,%rdi
    a687:	e8 c4 ae ff ff       	call   5550 <fwp_rc_forget_slot>
    a68c:	e9 92 f2 ff ff       	jmp    9923 <fwp_hof0.constprop.0+0x4c3>
    a691:	be 02 00 00 00       	mov    $0x2,%esi
    a696:	bf 08 00 00 00       	mov    $0x8,%edi
    a69b:	e8 f0 b5 ff ff       	call   5c90 <fwp_heap_alloc>
    a6a0:	48 89 c3             	mov    %rax,%rbx
    a6a3:	45 31 f6             	xor    %r14d,%r14d
    a6a6:	e9 a8 fa ff ff       	jmp    a153 <fwp_hof0.constprop.0+0xcf3>
    a6ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a6b0:	4d 85 e4             	test   %r12,%r12
    a6b3:	0f 85 73 f2 ff ff    	jne    992c <fwp_hof0.constprop.0+0x4cc>
    a6b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6c0:	31 d2                	xor    %edx,%edx
    a6c2:	e9 1b f3 ff ff       	jmp    99e2 <fwp_hof0.constprop.0+0x582>
    a6c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a6ce:	00 00 
    a6d0:	49 39 d4             	cmp    %rdx,%r12
    a6d3:	0f 84 c7 ef ff ff    	je     96a0 <fwp_hof0.constprop.0+0x240>
    a6d9:	4c 8b 0d 10 8a 01 00 	mov    0x18a10(%rip),%r9        # 230f0 <fwp_tapes>
    a6e0:	49 89 d4             	mov    %rdx,%r12
    a6e3:	48 8d 6a 01          	lea    0x1(%rdx),%rbp
    a6e7:	e9 52 f0 ff ff       	jmp    973e <fwp_hof0.constprop.0+0x2de>
    a6ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a6f0:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a6f5:	45 31 c0             	xor    %r8d,%r8d
    a6f8:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
    a6fd:	48 83 e8 01          	sub    $0x1,%rax
    a701:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a706:	41 0f 90 c0          	seto   %r8b
    a70a:	e9 20 ee ff ff       	jmp    952f <fwp_hof0.constprop.0+0xcf>
    a70f:	90                   	nop
    a710:	49 8d 6a 01          	lea    0x1(%r10),%rbp
    a714:	48 39 ea             	cmp    %rbp,%rdx
    a717:	7c 42                	jl     a75b <fwp_hof0.constprop.0+0x12fb>
    a719:	4d 85 e4             	test   %r12,%r12
    a71c:	0f 84 13 05 00 00    	je     ac35 <fwp_hof0.constprop.0+0x17d5>
    a722:	49 89 eb             	mov    %rbp,%r11
    a725:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    a72c:	00 
    a72d:	31 f6                	xor    %esi,%esi
    a72f:	4c 89 e7             	mov    %r12,%rdi
    a732:	4d 29 f3             	sub    %r14,%r11
    a735:	4c 89 54 24 68       	mov    %r10,0x68(%rsp)
    a73a:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
    a73f:	e8 7c 8d ff ff       	call   34c0 <memset@plt>
    a744:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    a749:	4c 8b 54 24 68       	mov    0x68(%rsp),%r10
    a74e:	e9 2a f4 ff ff       	jmp    9b7d <fwp_hof0.constprop.0+0x71d>
    a753:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a758:	4c 89 f5             	mov    %r14,%rbp
    a75b:	48 85 d2             	test   %rdx,%rdx
    a75e:	48 0f 44 d5          	cmove  %rbp,%rdx
    a762:	eb 31                	jmp    a795 <fwp_hof0.constprop.0+0x1335>
    a764:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a76a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a771:	00 00 00 00 
    a775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a77c:	00 00 00 00 
    a780:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    a784:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    a78b:	48 89 e8             	mov    %rbp,%rax
    a78e:	48 0f 4c c1          	cmovl  %rcx,%rax
    a792:	48 89 c2             	mov    %rax,%rdx
    a795:	48 39 ea             	cmp    %rbp,%rdx
    a798:	7c e6                	jl     a780 <fwp_hof0.constprop.0+0x1320>
    a79a:	4d 85 e4             	test   %r12,%r12
    a79d:	0f 84 ed 01 00 00    	je     a990 <fwp_hof0.constprop.0+0x1530>
    a7a3:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    a7aa:	00 
    a7ab:	4c 89 e7             	mov    %r12,%rdi
    a7ae:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
    a7b3:	e8 18 8e ff ff       	call   35d0 <realloc@plt>
    a7b8:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    a7bd:	49 89 c4             	mov    %rax,%r12
    a7c0:	4d 85 e4             	test   %r12,%r12
    a7c3:	0f 84 63 04 00 00    	je     ac2c <fwp_hof0.constprop.0+0x17cc>
    a7c9:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    a7d0:	00 
    a7d1:	48 89 94 24 f0 00 00 	mov    %rdx,0xf0(%rsp)
    a7d8:	00 
    a7d9:	48 85 ed             	test   %rbp,%rbp
    a7dc:	0f 85 56 03 00 00    	jne    ab38 <fwp_hof0.constprop.0+0x16d8>
    a7e2:	4d 89 f3             	mov    %r14,%r11
    a7e5:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a7ec:	49 f7 db             	neg    %r11
    a7ef:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a7f4:	48 85 c0             	test   %rax,%rax
    a7f7:	0f 88 94 f3 ff ff    	js     9b91 <fwp_hof0.constprop.0+0x731>
    a7fd:	41 89 c2             	mov    %eax,%r10d
    a800:	e9 78 f3 ff ff       	jmp    9b7d <fwp_hof0.constprop.0+0x71d>
    a805:	0f 1f 00             	nopl   (%rax)
    a808:	48 8d 3d b1 c4 ff ff 	lea    -0x3b4f(%rip),%rdi        # 6cc0 <fwp_tape_finish>
    a80f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    a814:	e8 47 3b 00 00       	call   e360 <atexit>
    a819:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    a81e:	85 c0                	test   %eax,%eax
    a820:	0f 85 ad 04 00 00    	jne    acd3 <fwp_hof0.constprop.0+0x1873>
    a826:	c7 05 30 88 00 00 01 	movl   $0x1,0x8830(%rip)        # 13060 <registered_finish.1>
    a82d:	00 00 00 
    a830:	e9 1f ee ff ff       	jmp    9654 <fwp_hof0.constprop.0+0x1f4>
    a835:	0f 1f 00             	nopl   (%rax)
    a838:	66 85 c0             	test   %ax,%ax
    a83b:	0f 85 af f9 ff ff    	jne    a1f0 <fwp_hof0.constprop.0+0xd90>
    a841:	e9 83 f9 ff ff       	jmp    a1c9 <fwp_hof0.constprop.0+0xd69>
    a846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a84d:	00 00 00 
    a850:	66 85 c0             	test   %ax,%ax
    a853:	0f 85 a9 ed ff ff    	jne    9602 <fwp_hof0.constprop.0+0x1a2>
    a859:	e9 90 ed ff ff       	jmp    95ee <fwp_hof0.constprop.0+0x18e>
    a85e:	66 90                	xchg   %ax,%ax
    a860:	49 39 d6             	cmp    %rdx,%r14
    a863:	0f 8f ef fe ff ff    	jg     a758 <fwp_hof0.constprop.0+0x12f8>
    a869:	4d 85 f6             	test   %r14,%r14
    a86c:	74 12                	je     a880 <fwp_hof0.constprop.0+0x1420>
    a86e:	4d 85 e4             	test   %r12,%r12
    a871:	0f 84 be 03 00 00    	je     ac35 <fwp_hof0.constprop.0+0x17d5>
    a877:	4d 85 f6             	test   %r14,%r14
    a87a:	0f 85 b5 02 00 00    	jne    ab35 <fwp_hof0.constprop.0+0x16d5>
    a880:	45 31 db             	xor    %r11d,%r11d
    a883:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a88a:	e9 02 f3 ff ff       	jmp    9b91 <fwp_hof0.constprop.0+0x731>
    a88f:	90                   	nop
    a890:	66 85 c0             	test   %ax,%ax
    a893:	0f 85 97 f4 ff ff    	jne    9d30 <fwp_hof0.constprop.0+0x8d0>
    a899:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a89d:	0f 85 89 f4 ff ff    	jne    9d2c <fwp_hof0.constprop.0+0x8cc>
    a8a3:	48 89 ef             	mov    %rbp,%rdi
    a8a6:	e8 a5 ac ff ff       	call   5550 <fwp_rc_forget_slot>
    a8ab:	e9 7c f4 ff ff       	jmp    9d2c <fwp_hof0.constprop.0+0x8cc>
    a8b0:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
    a8b5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    a8ba:	e9 94 f8 ff ff       	jmp    a153 <fwp_hof0.constprop.0+0xcf3>
    a8bf:	90                   	nop
    a8c0:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    a8c5:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a8cc:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a8d3:	48 8b 58 10          	mov    0x10(%rax),%rbx
    a8d7:	48 29 c8             	sub    %rcx,%rax
    a8da:	48 c1 e2 10          	shl    $0x10,%rdx
    a8de:	48 39 d0             	cmp    %rdx,%rax
    a8e1:	73 67                	jae    a94a <fwp_hof0.constprop.0+0x14ea>
    a8e3:	48 89 c7             	mov    %rax,%rdi
    a8e6:	48 c1 ef 10          	shr    $0x10,%rdi
    a8ea:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    a8ee:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a8f2:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a8f6:	48 85 ff             	test   %rdi,%rdi
    a8f9:	74 4f                	je     a94a <fwp_hof0.constprop.0+0x14ea>
    a8fb:	44 0f b6 06          	movzbl (%rsi),%r8d
    a8ff:	41 80 f8 02          	cmp    $0x2,%r8b
    a903:	0f 84 82 01 00 00    	je     aa8b <fwp_hof0.constprop.0+0x162b>
    a909:	41 80 f8 01          	cmp    $0x1,%r8b
    a90d:	75 3b                	jne    a94a <fwp_hof0.constprop.0+0x14ea>
    a90f:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a913:	0f b7 c0             	movzwl %ax,%eax
    a916:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a919:	49 0f af c0          	imul   %r8,%rax
    a91d:	48 c1 e8 20          	shr    $0x20,%rax
    a921:	48 39 f0             	cmp    %rsi,%rax
    a924:	73 24                	jae    a94a <fwp_hof0.constprop.0+0x14ea>
    a926:	48 01 c7             	add    %rax,%rdi
    a929:	80 3f 01             	cmpb   $0x1,(%rdi)
    a92c:	75 1c                	jne    a94a <fwp_hof0.constprop.0+0x14ea>
    a92e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    a933:	e8 58 ae ff ff       	call   5790 <fwp_mem_free>
    a938:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a93f:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a946:	48 c1 e2 10          	shl    $0x10,%rdx
    a94a:	48 89 d8             	mov    %rbx,%rax
    a94d:	48 29 c8             	sub    %rcx,%rax
    a950:	48 39 d0             	cmp    %rdx,%rax
    a953:	0f 83 97 f8 ff ff    	jae    a1f0 <fwp_hof0.constprop.0+0xd90>
    a959:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
    a95e:	e9 1d f8 ff ff       	jmp    a180 <fwp_hof0.constprop.0+0xd20>
    a963:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a968:	66 85 c0             	test   %ax,%ax
    a96b:	0f 85 6c fc ff ff    	jne    a5dd <fwp_hof0.constprop.0+0x117d>
    a971:	80 3b ff             	cmpb   $0xff,(%rbx)
    a974:	0f 85 60 fc ff ff    	jne    a5da <fwp_hof0.constprop.0+0x117a>
    a97a:	48 89 df             	mov    %rbx,%rdi
    a97d:	e8 ce ab ff ff       	call   5550 <fwp_rc_forget_slot>
    a982:	e9 53 fc ff ff       	jmp    a5da <fwp_hof0.constprop.0+0x117a>
    a987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a98e:	00 00 
    a990:	48 89 d7             	mov    %rdx,%rdi
    a993:	be 08 00 00 00       	mov    $0x8,%esi
    a998:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
    a99d:	e8 7e 8b ff ff       	call   3520 <calloc@plt>
    a9a2:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    a9a7:	49 89 c4             	mov    %rax,%r12
    a9aa:	e9 11 fe ff ff       	jmp    a7c0 <fwp_hof0.constprop.0+0x1360>
    a9af:	90                   	nop
    a9b0:	66 85 c0             	test   %ax,%ax
    a9b3:	0f 85 60 eb ff ff    	jne    9519 <fwp_hof0.constprop.0+0xb9>
    a9b9:	e9 47 eb ff ff       	jmp    9505 <fwp_hof0.constprop.0+0xa5>
    a9be:	66 90                	xchg   %ax,%ax
    a9c0:	66 85 c0             	test   %ax,%ax
    a9c3:	0f 85 40 f9 ff ff    	jne    a309 <fwp_hof0.constprop.0+0xea9>
    a9c9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a9cd:	0f 85 32 f9 ff ff    	jne    a305 <fwp_hof0.constprop.0+0xea5>
    a9d3:	4c 89 ff             	mov    %r15,%rdi
    a9d6:	e8 75 ab ff ff       	call   5550 <fwp_rc_forget_slot>
    a9db:	e9 25 f9 ff ff       	jmp    a305 <fwp_hof0.constprop.0+0xea5>
    a9e0:	66 85 c0             	test   %ax,%ax
    a9e3:	0f 85 d7 f9 ff ff    	jne    a3c0 <fwp_hof0.constprop.0+0xf60>
    a9e9:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a9ed:	84 c0                	test   %al,%al
    a9ef:	0f 84 cb f9 ff ff    	je     a3c0 <fwp_hof0.constprop.0+0xf60>
    a9f5:	3c 01                	cmp    $0x1,%al
    a9f7:	0f 85 af f9 ff ff    	jne    a3ac <fwp_hof0.constprop.0+0xf4c>
    a9fd:	48 89 df             	mov    %rbx,%rdi
    aa00:	e8 8b ad ff ff       	call   5790 <fwp_mem_free>
    aa05:	e9 b6 f9 ff ff       	jmp    a3c0 <fwp_hof0.constprop.0+0xf60>
    aa0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa10:	be 68 00 00 00       	mov    $0x68,%esi
    aa15:	bd 01 00 00 00       	mov    $0x1,%ebp
    aa1a:	e9 bb ec ff ff       	jmp    96da <fwp_hof0.constprop.0+0x27a>
    aa1f:	31 ff                	xor    %edi,%edi
    aa21:	e8 2a 98 ff ff       	call   4250 <descent_phase_step>
    aa26:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aa2a:	e9 17 ec ff ff       	jmp    9646 <fwp_hof0.constprop.0+0x1e6>
    aa2f:	48 8b 45 00          	mov    0x0(%rbp),%rax
    aa33:	48 85 c0             	test   %rax,%rax
    aa36:	0f 88 55 fc ff ff    	js     a691 <fwp_hof0.constprop.0+0x1231>
    aa3c:	49 8b b5 d8 13 00 00 	mov    0x13d8(%r13),%rsi
    aa43:	48 8b 0c 24          	mov    (%rsp),%rcx
    aa47:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    aa4e:	48 c1 e6 10          	shl    $0x10,%rsi
    aa52:	48 39 f1             	cmp    %rsi,%rcx
    aa55:	0f 83 36 fc ff ff    	jae    a691 <fwp_hof0.constprop.0+0x1231>
    aa5b:	48 89 ce             	mov    %rcx,%rsi
    aa5e:	48 c1 ee 10          	shr    $0x10,%rsi
    aa62:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    aa66:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    aa6d:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    aa71:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    aa75:	48 85 ff             	test   %rdi,%rdi
    aa78:	0f 84 13 fc ff ff    	je     a691 <fwp_hof0.constprop.0+0x1231>
    aa7e:	48 0f ba f0 3f       	btr    $0x3f,%rax
    aa83:	49 89 c7             	mov    %rax,%r15
    aa86:	e9 39 f4 ff ff       	jmp    9ec4 <fwp_hof0.constprop.0+0xa64>
    aa8b:	66 85 c0             	test   %ax,%ax
    aa8e:	0f 85 b6 fe ff ff    	jne    a94a <fwp_hof0.constprop.0+0x14ea>
    aa94:	e9 90 fe ff ff       	jmp    a929 <fwp_hof0.constprop.0+0x14c9>
    aa99:	48 89 ea             	mov    %rbp,%rdx
    aa9c:	48 c1 ea 11          	shr    $0x11,%rdx
    aaa0:	48 31 ea             	xor    %rbp,%rdx
    aaa3:	48 89 d0             	mov    %rdx,%rax
    aaa6:	48 c1 e8 09          	shr    $0x9,%rax
    aaaa:	48 31 c2             	xor    %rax,%rdx
    aaad:	0f b6 d2             	movzbl %dl,%edx
    aab0:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    aab7:	00 
    aab8:	48 85 c0             	test   %rax,%rax
    aabb:	75 0c                	jne    aac9 <fwp_hof0.constprop.0+0x1669>
    aabd:	eb 6a                	jmp    ab29 <fwp_hof0.constprop.0+0x16c9>
    aabf:	90                   	nop
    aac0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    aac4:	48 85 c0             	test   %rax,%rax
    aac7:	74 60                	je     ab29 <fwp_hof0.constprop.0+0x16c9>
    aac9:	48 89 c2             	mov    %rax,%rdx
    aacc:	48 39 28             	cmp    %rbp,(%rax)
    aacf:	75 ef                	jne    aac0 <fwp_hof0.constprop.0+0x1660>
    aad1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    aad5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    aad9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    aadd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    aae4:	0f 85 06 f7 ff ff    	jne    a1f0 <fwp_hof0.constprop.0+0xd90>
    aaea:	48 89 ef             	mov    %rbp,%rdi
    aaed:	e8 5e aa ff ff       	call   5550 <fwp_rc_forget_slot>
    aaf2:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    aaf6:	e9 f5 f6 ff ff       	jmp    a1f0 <fwp_hof0.constprop.0+0xd90>
    aafb:	e8 30 a9 ff ff       	call   5430 <fwp_rc_wide_dup>
    ab00:	e9 fd ea ff ff       	jmp    9602 <fwp_hof0.constprop.0+0x1a2>
    ab05:	48 89 e8             	mov    %rbp,%rax
    ab08:	48 c1 e8 11          	shr    $0x11,%rax
    ab0c:	48 31 e8             	xor    %rbp,%rax
    ab0f:	48 89 c2             	mov    %rax,%rdx
    ab12:	48 c1 ea 09          	shr    $0x9,%rdx
    ab16:	48 31 d0             	xor    %rdx,%rax
    ab19:	0f b6 d0             	movzbl %al,%edx
    ab1c:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    ab23:	00 
    ab24:	48 85 c0             	test   %rax,%rax
    ab27:	75 60                	jne    ab89 <fwp_hof0.constprop.0+0x1729>
    ab29:	48 8d 3d 60 4d 00 00 	lea    0x4d60(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    ab30:	e8 bb 98 ff ff       	call   43f0 <fwp_trap>
    ab35:	4c 89 f5             	mov    %r14,%rbp
    ab38:	49 89 eb             	mov    %rbp,%r11
    ab3b:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    ab42:	00 
    ab43:	31 f6                	xor    %esi,%esi
    ab45:	4c 89 e7             	mov    %r12,%rdi
    ab48:	4d 29 f3             	sub    %r14,%r11
    ab4b:	4c 8d 7d ff          	lea    -0x1(%rbp),%r15
    ab4f:	4c 89 5c 24 68       	mov    %r11,0x68(%rsp)
    ab54:	e8 67 89 ff ff       	call   34c0 <memset@plt>
    ab59:	4c 8b 5c 24 68       	mov    0x68(%rsp),%r11
    ab5e:	e9 8c fc ff ff       	jmp    a7ef <fwp_hof0.constprop.0+0x138f>
    ab63:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab71:	00 00 00 00 
    ab75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab7c:	00 00 00 00 
    ab80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    ab84:	48 85 c0             	test   %rax,%rax
    ab87:	74 a0                	je     ab29 <fwp_hof0.constprop.0+0x16c9>
    ab89:	48 89 c2             	mov    %rax,%rdx
    ab8c:	48 3b 28             	cmp    (%rax),%rbp
    ab8f:	75 ef                	jne    ab80 <fwp_hof0.constprop.0+0x1720>
    ab91:	48 8b 78 08          	mov    0x8(%rax),%rdi
    ab95:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    ab99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    ab9d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    aba4:	0f 85 16 f8 ff ff    	jne    a3c0 <fwp_hof0.constprop.0+0xf60>
    abaa:	48 89 ef             	mov    %rbp,%rdi
    abad:	e8 9e a9 ff ff       	call   5550 <fwp_rc_forget_slot>
    abb2:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    abb6:	e9 05 f8 ff ff       	jmp    a3c0 <fwp_hof0.constprop.0+0xf60>
    abbb:	e8 70 a8 ff ff       	call   5430 <fwp_rc_wide_dup>
    abc0:	e9 54 e9 ff ff       	jmp    9519 <fwp_hof0.constprop.0+0xb9>
    abc5:	45 31 ff             	xor    %r15d,%r15d
    abc8:	e9 48 f4 ff ff       	jmp    a015 <fwp_hof0.constprop.0+0xbb5>
    abcd:	48 8d 3d e4 4c 00 00 	lea    0x4ce4(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    abd4:	e8 17 98 ff ff       	call   43f0 <fwp_trap>
    abd9:	48 8d 3d 87 45 00 00 	lea    0x4587(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    abe0:	e8 0b 98 ff ff       	call   43f0 <fwp_trap>
    abe5:	48 8d 3d a4 4d 00 00 	lea    0x4da4(%rip),%rdi        # f990 <_IO_stdin_used+0x990>
    abec:	e8 ff 97 ff ff       	call   43f0 <fwp_trap>
    abf1:	31 db                	xor    %ebx,%ebx
    abf3:	e9 ab fa ff ff       	jmp    a6a3 <fwp_hof0.constprop.0+0x1243>
    abf8:	48 8d 3d 1d 46 00 00 	lea    0x461d(%rip),%rdi        # f21c <_IO_stdin_used+0x21c>
    abff:	e8 ec 97 ff ff       	call   43f0 <fwp_trap>
    ac04:	48 8d 3d 2b 46 00 00 	lea    0x462b(%rip),%rdi        # f236 <_IO_stdin_used+0x236>
    ac0b:	e8 e0 97 ff ff       	call   43f0 <fwp_trap>
    ac10:	48 8d 3d 79 45 00 00 	lea    0x4579(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    ac17:	e8 d4 97 ff ff       	call   43f0 <fwp_trap>
    ac1c:	0f 1f 40 00          	nopl   0x0(%rax)
    ac20:	48 8d 3d 91 4d 00 00 	lea    0x4d91(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    ac27:	e8 c4 97 ff ff       	call   43f0 <fwp_trap>
    ac2c:	48 85 ed             	test   %rbp,%rbp
    ac2f:	0f 84 ad fb ff ff    	je     a7e2 <fwp_hof0.constprop.0+0x1382>
    ac35:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    ac3c:	00 
    ac3d:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    ac42:	48 89 05 0f a8 01 00 	mov    %rax,0x1a80f(%rip)        # 25458 <fwp_cleanups>
    ac49:	e8 22 a4 ff ff       	call   5070 <fwp_tape_buffers_release>
    ac4e:	ba 13 00 00 00       	mov    $0x13,%edx
    ac53:	48 8b 0d e6 83 00 00 	mov    0x83e6(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ac5a:	be 01 00 00 00       	mov    $0x1,%esi
    ac5f:	48 8d 3d a2 43 00 00 	lea    0x43a2(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    ac66:	e8 15 8a ff ff       	call   3680 <fwrite@plt>
    ac6b:	31 ff                	xor    %edi,%edi
    ac6d:	e8 4e 89 ff ff       	call   35c0 <fflush@plt>
    ac72:	bf 66 00 00 00       	mov    $0x66,%edi
    ac77:	e8 24 8a ff ff       	call   36a0 <_Exit@plt>
    ac7c:	48 8d 3d dd 4c 00 00 	lea    0x4cdd(%rip),%rdi        # f960 <_IO_stdin_used+0x960>
    ac83:	e8 68 97 ff ff       	call   43f0 <fwp_trap>
    ac88:	48 8b 0d b1 83 00 00 	mov    0x83b1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ac8f:	ba 13 00 00 00       	mov    $0x13,%edx
    ac94:	be 01 00 00 00       	mov    $0x1,%esi
    ac99:	48 8d 3d 68 43 00 00 	lea    0x4368(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aca0:	e8 db 89 ff ff       	call   3680 <fwrite@plt>
    aca5:	31 ff                	xor    %edi,%edi
    aca7:	e8 14 89 ff ff       	call   35c0 <fflush@plt>
    acac:	bf 66 00 00 00       	mov    $0x66,%edi
    acb1:	e8 ea 89 ff ff       	call   36a0 <_Exit@plt>
    acb6:	48 8d 3d 43 4c 00 00 	lea    0x4c43(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    acbd:	e8 2e 97 ff ff       	call   43f0 <fwp_trap>
    acc2:	e8 99 87 ff ff       	call   3460 <__stack_chk_fail@plt>
    acc7:	48 8d 3d 78 45 00 00 	lea    0x4578(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    acce:	e8 1d 97 ff ff       	call   43f0 <fwp_trap>
    acd3:	48 8b 0d 66 83 00 00 	mov    0x8366(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    acda:	ba 13 00 00 00       	mov    $0x13,%edx
    acdf:	be 01 00 00 00       	mov    $0x1,%esi
    ace4:	48 8d 3d 1d 43 00 00 	lea    0x431d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aceb:	e8 90 89 ff ff       	call   3680 <fwrite@plt>
    acf0:	31 ff                	xor    %edi,%edi
    acf2:	e8 c9 88 ff ff       	call   35c0 <fflush@plt>
    acf7:	bf 66 00 00 00       	mov    $0x66,%edi
    acfc:	e8 9f 89 ff ff       	call   36a0 <_Exit@plt>
    ad01:	0f 1f 40 00          	nopl   0x0(%rax)
    ad05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad0c:	00 00 00 00 

000000000000ad10 <f0>:
    ad10:	41 56                	push   %r14
    ad12:	4c 8d 35 a7 8a 01 00 	lea    0x18aa7(%rip),%r14        # 237c0 <fwp_heap>
    ad19:	41 55                	push   %r13
    ad1b:	41 54                	push   %r12
    ad1d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    ad23:	55                   	push   %rbp
    ad24:	53                   	push   %rbx
    ad25:	31 db                	xor    %ebx,%ebx
    ad27:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    ad2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ad35:	00 00 
    ad37:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    ad3e:	00 
    ad3f:	31 c0                	xor    %eax,%eax
    ad41:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    ad48:	00 
    ad49:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    ad50:	00 00 
    ad52:	66 48 0f 6e c0       	movq   %rax,%xmm0
    ad57:	48 8d 05 72 cd ff ff 	lea    -0x328e(%rip),%rax        # 7ad0 <fwp_drop1>
    ad5e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    ad63:	48 8b 05 ee a6 01 00 	mov    0x1a6ee(%rip),%rax        # 25458 <fwp_cleanups>
    ad6a:	48 89 25 e7 a6 01 00 	mov    %rsp,0x1a6e7(%rip)        # 25458 <fwp_cleanups>
    ad71:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    ad75:	48 89 04 24          	mov    %rax,(%rsp)
    ad79:	48 8d 05 50 8e ff ff 	lea    -0x71b0(%rip),%rax        # 3bd0 <fwp_range_release>
    ad80:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ad85:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    ad8a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    ad8f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    ad94:	eb 47                	jmp    addd <f0+0xcd>
    ad96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ad9d:	00 00 00 
    ada0:	80 f9 01             	cmp    $0x1,%cl
    ada3:	75 29                	jne    adce <f0+0xbe>
    ada5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ada8:	0f b7 c0             	movzwl %ax,%eax
    adab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    adae:	48 0f af c1          	imul   %rcx,%rax
    adb2:	48 c1 e8 20          	shr    $0x20,%rax
    adb6:	48 39 d0             	cmp    %rdx,%rax
    adb9:	73 13                	jae    adce <f0+0xbe>
    adbb:	49 01 c5             	add    %rax,%r13
    adbe:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    adc3:	0f 84 c7 27 00 00    	je     d590 <f0+0x2880>
    adc9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    adce:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    add3:	49 83 ec 01          	sub    $0x1,%r12
    add7:	0f 82 83 00 00 00    	jb     ae60 <f0+0x150>
    addd:	48 89 ee             	mov    %rbp,%rsi
    ade0:	bf 01 00 00 00       	mov    $0x1,%edi
    ade5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    adec:	00 
    aded:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    adf2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    adf9:	00 
    adfa:	e8 b1 af ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    adff:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    ae06:	48 89 c3             	mov    %rax,%rbx
    ae09:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    ae10:	48 c1 e2 10          	shl    $0x10,%rdx
    ae14:	48 39 d0             	cmp    %rdx,%rax
    ae17:	73 b5                	jae    adce <f0+0xbe>
    ae19:	48 89 c2             	mov    %rax,%rdx
    ae1c:	48 c1 ea 10          	shr    $0x10,%rdx
    ae20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae24:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    ae2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae2f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    ae33:	4d 85 ed             	test   %r13,%r13
    ae36:	74 96                	je     adce <f0+0xbe>
    ae38:	0f b6 0a             	movzbl (%rdx),%ecx
    ae3b:	80 f9 02             	cmp    $0x2,%cl
    ae3e:	0f 85 5c ff ff ff    	jne    ada0 <f0+0x90>
    ae44:	66 85 c0             	test   %ax,%ax
    ae47:	0f 84 71 ff ff ff    	je     adbe <f0+0xae>
    ae4d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    ae52:	49 83 ec 01          	sub    $0x1,%r12
    ae56:	73 85                	jae    addd <f0+0xcd>
    ae58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ae5f:	00 
    ae60:	48 8b 04 24          	mov    (%rsp),%rax
    ae64:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    ae69:	bf 01 00 00 00       	mov    $0x1,%edi
    ae6e:	66 0f 6f 05 ca 4d 00 	movdqa 0x4dca(%rip),%xmm0        # fc40 <msg.4+0xd0>
    ae75:	00 
    ae76:	48 89 05 db a5 01 00 	mov    %rax,0x1a5db(%rip)        # 25458 <fwp_cleanups>
    ae7d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    ae82:	e8 29 af ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ae87:	48 8b 15 0a 9d 01 00 	mov    0x19d0a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ae8e:	49 89 c5             	mov    %rax,%r13
    ae91:	48 2b 05 d8 9c 01 00 	sub    0x19cd8(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ae98:	48 c1 e2 10          	shl    $0x10,%rdx
    ae9c:	48 39 d0             	cmp    %rdx,%rax
    ae9f:	73 59                	jae    aefa <f0+0x1ea>
    aea1:	48 89 c2             	mov    %rax,%rdx
    aea4:	48 c1 ea 10          	shr    $0x10,%rdx
    aea8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aeac:	48 8b 15 05 9d 01 00 	mov    0x19d05(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    aeb3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aeb7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aebb:	4d 85 e4             	test   %r12,%r12
    aebe:	74 3a                	je     aefa <f0+0x1ea>
    aec0:	0f b6 0a             	movzbl (%rdx),%ecx
    aec3:	80 f9 02             	cmp    $0x2,%cl
    aec6:	0f 84 74 27 00 00    	je     d640 <f0+0x2930>
    aecc:	80 f9 01             	cmp    $0x1,%cl
    aecf:	75 29                	jne    aefa <f0+0x1ea>
    aed1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aed4:	0f b7 c0             	movzwl %ax,%eax
    aed7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aeda:	48 0f af c1          	imul   %rcx,%rax
    aede:	48 c1 e8 20          	shr    $0x20,%rax
    aee2:	48 39 d0             	cmp    %rdx,%rax
    aee5:	73 13                	jae    aefa <f0+0x1ea>
    aee7:	49 01 c4             	add    %rax,%r12
    aeea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    aeef:	0f 84 26 29 00 00    	je     d81b <f0+0x2b0b>
    aef5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    aefa:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    aeff:	bf 01 00 00 00       	mov    $0x1,%edi
    af04:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    af09:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    af10:	00 f0 3f 
    af13:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    af18:	e8 93 ae ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    af1d:	48 8b 15 74 9c 01 00 	mov    0x19c74(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    af24:	49 89 c5             	mov    %rax,%r13
    af27:	48 2b 05 42 9c 01 00 	sub    0x19c42(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    af2e:	48 c1 e2 10          	shl    $0x10,%rdx
    af32:	48 39 d0             	cmp    %rdx,%rax
    af35:	73 59                	jae    af90 <f0+0x280>
    af37:	48 89 c2             	mov    %rax,%rdx
    af3a:	48 c1 ea 10          	shr    $0x10,%rdx
    af3e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af42:	48 8b 15 6f 9c 01 00 	mov    0x19c6f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    af49:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af4d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    af51:	4d 85 e4             	test   %r12,%r12
    af54:	74 3a                	je     af90 <f0+0x280>
    af56:	0f b6 0a             	movzbl (%rdx),%ecx
    af59:	80 f9 02             	cmp    $0x2,%cl
    af5c:	0f 84 ce 26 00 00    	je     d630 <f0+0x2920>
    af62:	80 f9 01             	cmp    $0x1,%cl
    af65:	75 29                	jne    af90 <f0+0x280>
    af67:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af6a:	0f b7 c0             	movzwl %ax,%eax
    af6d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af70:	48 0f af c1          	imul   %rcx,%rax
    af74:	48 c1 e8 20          	shr    $0x20,%rax
    af78:	48 39 d0             	cmp    %rdx,%rax
    af7b:	73 13                	jae    af90 <f0+0x280>
    af7d:	49 01 c4             	add    %rax,%r12
    af80:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    af85:	0f 84 9d 28 00 00    	je     d828 <f0+0x2b18>
    af8b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    af90:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    af95:	bf 01 00 00 00       	mov    $0x1,%edi
    af9a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    af9f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    afa6:	33 f3 bf 
    afa9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    afae:	e8 fd ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    afb3:	48 8b 15 de 9b 01 00 	mov    0x19bde(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    afba:	49 89 c5             	mov    %rax,%r13
    afbd:	48 2b 05 ac 9b 01 00 	sub    0x19bac(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    afc4:	48 c1 e2 10          	shl    $0x10,%rdx
    afc8:	48 39 d0             	cmp    %rdx,%rax
    afcb:	73 59                	jae    b026 <f0+0x316>
    afcd:	48 89 c2             	mov    %rax,%rdx
    afd0:	48 c1 ea 10          	shr    $0x10,%rdx
    afd4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    afd8:	48 8b 15 d9 9b 01 00 	mov    0x19bd9(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    afdf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    afe3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    afe7:	4d 85 e4             	test   %r12,%r12
    afea:	74 3a                	je     b026 <f0+0x316>
    afec:	0f b6 0a             	movzbl (%rdx),%ecx
    afef:	80 f9 02             	cmp    $0x2,%cl
    aff2:	0f 84 28 26 00 00    	je     d620 <f0+0x2910>
    aff8:	80 f9 01             	cmp    $0x1,%cl
    affb:	75 29                	jne    b026 <f0+0x316>
    affd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b000:	0f b7 c0             	movzwl %ax,%eax
    b003:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b006:	48 0f af c1          	imul   %rcx,%rax
    b00a:	48 c1 e8 20          	shr    $0x20,%rax
    b00e:	48 39 d0             	cmp    %rdx,%rax
    b011:	73 13                	jae    b026 <f0+0x316>
    b013:	49 01 c4             	add    %rax,%r12
    b016:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b01b:	0f 84 14 28 00 00    	je     d835 <f0+0x2b25>
    b021:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b026:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b02b:	bf 01 00 00 00       	mov    $0x1,%edi
    b030:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b035:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b03c:	00 f0 3f 
    b03f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b044:	e8 67 ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b049:	48 8b 15 48 9b 01 00 	mov    0x19b48(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b050:	49 89 c5             	mov    %rax,%r13
    b053:	48 2b 05 16 9b 01 00 	sub    0x19b16(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b05a:	48 c1 e2 10          	shl    $0x10,%rdx
    b05e:	48 39 d0             	cmp    %rdx,%rax
    b061:	73 59                	jae    b0bc <f0+0x3ac>
    b063:	48 89 c2             	mov    %rax,%rdx
    b066:	48 c1 ea 10          	shr    $0x10,%rdx
    b06a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b06e:	48 8b 15 43 9b 01 00 	mov    0x19b43(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b075:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b079:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b07d:	4d 85 e4             	test   %r12,%r12
    b080:	74 3a                	je     b0bc <f0+0x3ac>
    b082:	0f b6 0a             	movzbl (%rdx),%ecx
    b085:	80 f9 02             	cmp    $0x2,%cl
    b088:	0f 84 f2 25 00 00    	je     d680 <f0+0x2970>
    b08e:	80 f9 01             	cmp    $0x1,%cl
    b091:	75 29                	jne    b0bc <f0+0x3ac>
    b093:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b096:	0f b7 c0             	movzwl %ax,%eax
    b099:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b09c:	48 0f af c1          	imul   %rcx,%rax
    b0a0:	48 c1 e8 20          	shr    $0x20,%rax
    b0a4:	48 39 d0             	cmp    %rdx,%rax
    b0a7:	73 13                	jae    b0bc <f0+0x3ac>
    b0a9:	49 01 c4             	add    %rax,%r12
    b0ac:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b0b1:	0f 84 8b 27 00 00    	je     d842 <f0+0x2b32>
    b0b7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b0bc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b0c3:	33 f3 bf 
    b0c6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b0cd:	00 
    b0ce:	bf 01 00 00 00       	mov    $0x1,%edi
    b0d3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b0da:	00 
    b0db:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b0e2:	00 
    b0e3:	e8 c8 ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b0e8:	48 8b 15 a9 9a 01 00 	mov    0x19aa9(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b0ef:	49 89 c5             	mov    %rax,%r13
    b0f2:	48 2b 05 77 9a 01 00 	sub    0x19a77(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b0f9:	48 c1 e2 10          	shl    $0x10,%rdx
    b0fd:	48 39 d0             	cmp    %rdx,%rax
    b100:	73 59                	jae    b15b <f0+0x44b>
    b102:	48 89 c2             	mov    %rax,%rdx
    b105:	48 c1 ea 10          	shr    $0x10,%rdx
    b109:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b10d:	48 8b 15 a4 9a 01 00 	mov    0x19aa4(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b114:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b118:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b11c:	4d 85 e4             	test   %r12,%r12
    b11f:	74 3a                	je     b15b <f0+0x44b>
    b121:	0f b6 0a             	movzbl (%rdx),%ecx
    b124:	80 f9 02             	cmp    $0x2,%cl
    b127:	0f 84 43 25 00 00    	je     d670 <f0+0x2960>
    b12d:	80 f9 01             	cmp    $0x1,%cl
    b130:	75 29                	jne    b15b <f0+0x44b>
    b132:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b135:	0f b7 c0             	movzwl %ax,%eax
    b138:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b13b:	48 0f af c1          	imul   %rcx,%rax
    b13f:	48 c1 e8 20          	shr    $0x20,%rax
    b143:	48 39 d0             	cmp    %rdx,%rax
    b146:	73 13                	jae    b15b <f0+0x44b>
    b148:	49 01 c4             	add    %rax,%r12
    b14b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b150:	0f 84 f9 26 00 00    	je     d84f <f0+0x2b3f>
    b156:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b15b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b162:	00 f0 3f 
    b165:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b16c:	00 
    b16d:	bf 01 00 00 00       	mov    $0x1,%edi
    b172:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b179:	00 
    b17a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b181:	00 
    b182:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b189:	33 f3 bf 
    b18c:	e8 1f ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b191:	48 89 c7             	mov    %rax,%rdi
    b194:	e8 07 b5 ff ff       	call   66a0 <fwp_rc_fresh>
    b199:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b1a0:	00 
    b1a1:	bf 01 00 00 00       	mov    $0x1,%edi
    b1a6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b1ad:	00 
    b1ae:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b1b5:	00 
    b1b6:	e8 f5 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b1bb:	48 89 c7             	mov    %rax,%rdi
    b1be:	e8 dd b4 ff ff       	call   66a0 <fwp_rc_fresh>
    b1c3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b1ca:	00 
    b1cb:	bf 01 00 00 00       	mov    $0x1,%edi
    b1d0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b1d7:	00 
    b1d8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b1df:	00 
    b1e0:	e8 cb ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b1e5:	48 89 c7             	mov    %rax,%rdi
    b1e8:	e8 b3 b4 ff ff       	call   66a0 <fwp_rc_fresh>
    b1ed:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b1f4:	00 
    b1f5:	bf 01 00 00 00       	mov    $0x1,%edi
    b1fa:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b201:	00 
    b202:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b209:	00 
    b20a:	e8 a1 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b20f:	48 89 c7             	mov    %rax,%rdi
    b212:	e8 89 b4 ff ff       	call   66a0 <fwp_rc_fresh>
    b217:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b21e:	00 
    b21f:	bf 01 00 00 00       	mov    $0x1,%edi
    b224:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b22b:	00 
    b22c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b233:	00 
    b234:	e8 77 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b239:	48 89 c7             	mov    %rax,%rdi
    b23c:	e8 5f b4 ff ff       	call   66a0 <fwp_rc_fresh>
    b241:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b248:	00 
    b249:	bf 01 00 00 00       	mov    $0x1,%edi
    b24e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b255:	00 
    b256:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b25d:	00 
    b25e:	e8 4d ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b263:	48 89 c7             	mov    %rax,%rdi
    b266:	e8 35 b4 ff ff       	call   66a0 <fwp_rc_fresh>
    b26b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b272:	00 
    b273:	bf 01 00 00 00       	mov    $0x1,%edi
    b278:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b27f:	00 
    b280:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b287:	00 
    b288:	e8 23 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b28d:	48 89 c7             	mov    %rax,%rdi
    b290:	e8 0b b4 ff ff       	call   66a0 <fwp_rc_fresh>
    b295:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b29c:	00 
    b29d:	bf 01 00 00 00       	mov    $0x1,%edi
    b2a2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b2a9:	00 
    b2aa:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b2b1:	00 
    b2b2:	e8 f9 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b2b7:	48 89 c7             	mov    %rax,%rdi
    b2ba:	e8 e1 b3 ff ff       	call   66a0 <fwp_rc_fresh>
    b2bf:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b2c6:	00 
    b2c7:	bf 01 00 00 00       	mov    $0x1,%edi
    b2cc:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b2d3:	00 
    b2d4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b2db:	00 
    b2dc:	e8 cf aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b2e1:	48 89 c7             	mov    %rax,%rdi
    b2e4:	e8 b7 b3 ff ff       	call   66a0 <fwp_rc_fresh>
    b2e9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b2f0:	00 
    b2f1:	bf 01 00 00 00       	mov    $0x1,%edi
    b2f6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b2fd:	00 
    b2fe:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b305:	00 
    b306:	e8 a5 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b30b:	48 89 c7             	mov    %rax,%rdi
    b30e:	e8 8d b3 ff ff       	call   66a0 <fwp_rc_fresh>
    b313:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b31a:	00 
    b31b:	bf 01 00 00 00       	mov    $0x1,%edi
    b320:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b327:	00 
    b328:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b32f:	00 
    b330:	e8 7b aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b335:	48 89 c7             	mov    %rax,%rdi
    b338:	e8 63 b3 ff ff       	call   66a0 <fwp_rc_fresh>
    b33d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b344:	00 
    b345:	bf 01 00 00 00       	mov    $0x1,%edi
    b34a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b351:	00 
    b352:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b359:	00 
    b35a:	e8 51 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b35f:	48 89 c7             	mov    %rax,%rdi
    b362:	e8 39 b3 ff ff       	call   66a0 <fwp_rc_fresh>
    b367:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b36e:	00 
    b36f:	bf 01 00 00 00       	mov    $0x1,%edi
    b374:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b37b:	00 
    b37c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b383:	00 
    b384:	e8 27 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b389:	48 89 c7             	mov    %rax,%rdi
    b38c:	e8 0f b3 ff ff       	call   66a0 <fwp_rc_fresh>
    b391:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b398:	00 
    b399:	bf 01 00 00 00       	mov    $0x1,%edi
    b39e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b3a5:	00 
    b3a6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b3ad:	00 
    b3ae:	e8 fd a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b3b3:	48 89 c7             	mov    %rax,%rdi
    b3b6:	e8 e5 b2 ff ff       	call   66a0 <fwp_rc_fresh>
    b3bb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b3c2:	00 
    b3c3:	bf 01 00 00 00       	mov    $0x1,%edi
    b3c8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b3cf:	00 
    b3d0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b3d7:	00 
    b3d8:	e8 d3 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b3dd:	48 89 c7             	mov    %rax,%rdi
    b3e0:	e8 bb b2 ff ff       	call   66a0 <fwp_rc_fresh>
    b3e5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b3ec:	00 
    b3ed:	bf 01 00 00 00       	mov    $0x1,%edi
    b3f2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b3f9:	00 
    b3fa:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b401:	00 
    b402:	e8 a9 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b407:	48 89 c7             	mov    %rax,%rdi
    b40a:	e8 91 b2 ff ff       	call   66a0 <fwp_rc_fresh>
    b40f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b416:	00 
    b417:	bf 01 00 00 00       	mov    $0x1,%edi
    b41c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b423:	00 
    b424:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b42b:	00 
    b42c:	e8 7f a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b431:	48 89 c7             	mov    %rax,%rdi
    b434:	e8 67 b2 ff ff       	call   66a0 <fwp_rc_fresh>
    b439:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b440:	00 
    b441:	bf 01 00 00 00       	mov    $0x1,%edi
    b446:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b44d:	00 
    b44e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b455:	00 
    b456:	e8 55 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b45b:	48 89 c7             	mov    %rax,%rdi
    b45e:	e8 3d b2 ff ff       	call   66a0 <fwp_rc_fresh>
    b463:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b46a:	00 
    b46b:	bf 01 00 00 00       	mov    $0x1,%edi
    b470:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b477:	00 
    b478:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b47f:	00 
    b480:	e8 2b a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b485:	48 89 c7             	mov    %rax,%rdi
    b488:	e8 13 b2 ff ff       	call   66a0 <fwp_rc_fresh>
    b48d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b494:	00 
    b495:	bf 01 00 00 00       	mov    $0x1,%edi
    b49a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b4a1:	00 
    b4a2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b4a9:	00 
    b4aa:	e8 01 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b4af:	48 89 c7             	mov    %rax,%rdi
    b4b2:	e8 e9 b1 ff ff       	call   66a0 <fwp_rc_fresh>
    b4b7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b4be:	00 
    b4bf:	bf 01 00 00 00       	mov    $0x1,%edi
    b4c4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b4cb:	00 
    b4cc:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b4d3:	00 
    b4d4:	e8 d7 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b4d9:	48 89 c7             	mov    %rax,%rdi
    b4dc:	e8 bf b1 ff ff       	call   66a0 <fwp_rc_fresh>
    b4e1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b4e8:	00 
    b4e9:	bf 01 00 00 00       	mov    $0x1,%edi
    b4ee:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b4f5:	00 
    b4f6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b4fd:	00 
    b4fe:	e8 ad a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b503:	48 89 c7             	mov    %rax,%rdi
    b506:	e8 95 b1 ff ff       	call   66a0 <fwp_rc_fresh>
    b50b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b512:	00 
    b513:	bf 01 00 00 00       	mov    $0x1,%edi
    b518:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b51f:	00 
    b520:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b527:	00 
    b528:	e8 83 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b52d:	48 89 c7             	mov    %rax,%rdi
    b530:	e8 6b b1 ff ff       	call   66a0 <fwp_rc_fresh>
    b535:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b53c:	00 
    b53d:	bf 01 00 00 00       	mov    $0x1,%edi
    b542:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b549:	00 
    b54a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b551:	00 
    b552:	e8 59 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b557:	48 89 c7             	mov    %rax,%rdi
    b55a:	e8 41 b1 ff ff       	call   66a0 <fwp_rc_fresh>
    b55f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b566:	00 
    b567:	bf 01 00 00 00       	mov    $0x1,%edi
    b56c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b573:	00 
    b574:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b57b:	00 
    b57c:	e8 2f a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b581:	48 89 c7             	mov    %rax,%rdi
    b584:	e8 17 b1 ff ff       	call   66a0 <fwp_rc_fresh>
    b589:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b590:	00 
    b591:	bf 01 00 00 00       	mov    $0x1,%edi
    b596:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b59d:	00 
    b59e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b5a5:	00 
    b5a6:	e8 05 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5ab:	48 89 c7             	mov    %rax,%rdi
    b5ae:	e8 ed b0 ff ff       	call   66a0 <fwp_rc_fresh>
    b5b3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b5ba:	00 
    b5bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b5c0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b5c7:	00 
    b5c8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b5cf:	00 
    b5d0:	e8 db a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5d5:	48 89 c7             	mov    %rax,%rdi
    b5d8:	e8 c3 b0 ff ff       	call   66a0 <fwp_rc_fresh>
    b5dd:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b5e4:	00 
    b5e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b5ea:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b5f1:	00 
    b5f2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b5f9:	00 
    b5fa:	e8 b1 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5ff:	48 89 c7             	mov    %rax,%rdi
    b602:	e8 99 b0 ff ff       	call   66a0 <fwp_rc_fresh>
    b607:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b60e:	00 
    b60f:	bf 01 00 00 00       	mov    $0x1,%edi
    b614:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b61b:	00 
    b61c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b623:	00 
    b624:	e8 87 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b629:	48 89 c7             	mov    %rax,%rdi
    b62c:	e8 6f b0 ff ff       	call   66a0 <fwp_rc_fresh>
    b631:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b638:	00 
    b639:	bf 01 00 00 00       	mov    $0x1,%edi
    b63e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b645:	00 
    b646:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b64d:	00 
    b64e:	e8 5d a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b653:	48 89 c7             	mov    %rax,%rdi
    b656:	e8 45 b0 ff ff       	call   66a0 <fwp_rc_fresh>
    b65b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b662:	00 
    b663:	bf 01 00 00 00       	mov    $0x1,%edi
    b668:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b66f:	00 
    b670:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b677:	00 
    b678:	e8 33 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b67d:	48 89 c7             	mov    %rax,%rdi
    b680:	e8 1b b0 ff ff       	call   66a0 <fwp_rc_fresh>
    b685:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b68c:	00 
    b68d:	bf 01 00 00 00       	mov    $0x1,%edi
    b692:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b699:	00 
    b69a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b6a1:	00 
    b6a2:	e8 09 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6a7:	48 89 c7             	mov    %rax,%rdi
    b6aa:	e8 f1 af ff ff       	call   66a0 <fwp_rc_fresh>
    b6af:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b6b6:	00 
    b6b7:	bf 01 00 00 00       	mov    $0x1,%edi
    b6bc:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b6c3:	00 
    b6c4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b6cb:	00 
    b6cc:	e8 df a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6d1:	48 89 c7             	mov    %rax,%rdi
    b6d4:	e8 c7 af ff ff       	call   66a0 <fwp_rc_fresh>
    b6d9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b6e0:	00 
    b6e1:	bf 01 00 00 00       	mov    $0x1,%edi
    b6e6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b6ed:	00 
    b6ee:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b6f5:	00 
    b6f6:	e8 b5 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6fb:	48 89 c7             	mov    %rax,%rdi
    b6fe:	e8 9d af ff ff       	call   66a0 <fwp_rc_fresh>
    b703:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b70a:	00 
    b70b:	bf 01 00 00 00       	mov    $0x1,%edi
    b710:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b717:	00 
    b718:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b71f:	00 
    b720:	e8 8b a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b725:	48 89 c7             	mov    %rax,%rdi
    b728:	e8 73 af ff ff       	call   66a0 <fwp_rc_fresh>
    b72d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b734:	00 
    b735:	bf 01 00 00 00       	mov    $0x1,%edi
    b73a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b741:	00 
    b742:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b749:	00 
    b74a:	e8 61 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b74f:	48 89 c7             	mov    %rax,%rdi
    b752:	e8 49 af ff ff       	call   66a0 <fwp_rc_fresh>
    b757:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b75e:	00 
    b75f:	bf 01 00 00 00       	mov    $0x1,%edi
    b764:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b76b:	00 
    b76c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b773:	00 
    b774:	e8 37 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b779:	48 89 c7             	mov    %rax,%rdi
    b77c:	e8 1f af ff ff       	call   66a0 <fwp_rc_fresh>
    b781:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b788:	00 
    b789:	bf 01 00 00 00       	mov    $0x1,%edi
    b78e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b795:	00 
    b796:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b79d:	00 
    b79e:	e8 0d a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7a3:	48 89 c7             	mov    %rax,%rdi
    b7a6:	e8 f5 ae ff ff       	call   66a0 <fwp_rc_fresh>
    b7ab:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b7b2:	00 
    b7b3:	bf 01 00 00 00       	mov    $0x1,%edi
    b7b8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b7bf:	00 
    b7c0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b7c7:	00 
    b7c8:	e8 e3 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7cd:	48 89 c7             	mov    %rax,%rdi
    b7d0:	e8 cb ae ff ff       	call   66a0 <fwp_rc_fresh>
    b7d5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b7dc:	00 
    b7dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b7e2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b7e9:	00 
    b7ea:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b7f1:	00 
    b7f2:	e8 b9 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7f7:	48 89 c7             	mov    %rax,%rdi
    b7fa:	e8 a1 ae ff ff       	call   66a0 <fwp_rc_fresh>
    b7ff:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    b806:	00 
    b807:	bf 01 00 00 00       	mov    $0x1,%edi
    b80c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    b813:	00 
    b814:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    b81b:	00 
    b81c:	e8 8f a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b821:	48 89 c7             	mov    %rax,%rdi
    b824:	e8 77 ae ff ff       	call   66a0 <fwp_rc_fresh>
    b829:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    b830:	00 
    b831:	bf 01 00 00 00       	mov    $0x1,%edi
    b836:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    b83d:	00 
    b83e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    b845:	00 
    b846:	e8 65 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b84b:	48 89 c7             	mov    %rax,%rdi
    b84e:	e8 4d ae ff ff       	call   66a0 <fwp_rc_fresh>
    b853:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    b85a:	00 
    b85b:	bf 01 00 00 00       	mov    $0x1,%edi
    b860:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    b867:	00 
    b868:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    b86f:	00 
    b870:	e8 3b a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b875:	48 89 c7             	mov    %rax,%rdi
    b878:	e8 23 ae ff ff       	call   66a0 <fwp_rc_fresh>
    b87d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    b884:	00 
    b885:	bf 01 00 00 00       	mov    $0x1,%edi
    b88a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    b891:	00 
    b892:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    b899:	00 
    b89a:	e8 11 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b89f:	48 89 c7             	mov    %rax,%rdi
    b8a2:	e8 f9 ad ff ff       	call   66a0 <fwp_rc_fresh>
    b8a7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    b8ae:	00 
    b8af:	bf 01 00 00 00       	mov    $0x1,%edi
    b8b4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    b8bb:	00 
    b8bc:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    b8c3:	00 
    b8c4:	e8 e7 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b8c9:	48 89 c7             	mov    %rax,%rdi
    b8cc:	e8 cf ad ff ff       	call   66a0 <fwp_rc_fresh>
    b8d1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    b8d8:	00 
    b8d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b8de:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    b8e5:	00 
    b8e6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    b8ed:	00 
    b8ee:	e8 bd a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b8f3:	48 89 c7             	mov    %rax,%rdi
    b8f6:	e8 a5 ad ff ff       	call   66a0 <fwp_rc_fresh>
    b8fb:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    b902:	00 
    b903:	bf 01 00 00 00       	mov    $0x1,%edi
    b908:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    b90f:	00 
    b910:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    b917:	00 
    b918:	e8 93 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b91d:	48 89 c7             	mov    %rax,%rdi
    b920:	e8 7b ad ff ff       	call   66a0 <fwp_rc_fresh>
    b925:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    b92c:	00 
    b92d:	bf 01 00 00 00       	mov    $0x1,%edi
    b932:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    b939:	00 
    b93a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    b941:	00 
    b942:	e8 69 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b947:	48 89 c7             	mov    %rax,%rdi
    b94a:	e8 51 ad ff ff       	call   66a0 <fwp_rc_fresh>
    b94f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    b956:	00 
    b957:	bf 01 00 00 00       	mov    $0x1,%edi
    b95c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    b963:	00 
    b964:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    b96b:	00 
    b96c:	e8 3f a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b971:	48 89 c7             	mov    %rax,%rdi
    b974:	e8 27 ad ff ff       	call   66a0 <fwp_rc_fresh>
    b979:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    b980:	00 
    b981:	bf 01 00 00 00       	mov    $0x1,%edi
    b986:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    b98d:	00 
    b98e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    b995:	00 
    b996:	e8 15 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b99b:	48 89 c7             	mov    %rax,%rdi
    b99e:	e8 fd ac ff ff       	call   66a0 <fwp_rc_fresh>
    b9a3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    b9aa:	00 
    b9ab:	bf 01 00 00 00       	mov    $0x1,%edi
    b9b0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    b9b7:	00 
    b9b8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    b9bf:	00 
    b9c0:	e8 eb a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b9c5:	48 89 c7             	mov    %rax,%rdi
    b9c8:	e8 d3 ac ff ff       	call   66a0 <fwp_rc_fresh>
    b9cd:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    b9d4:	00 
    b9d5:	bf 01 00 00 00       	mov    $0x1,%edi
    b9da:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    b9e1:	00 
    b9e2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    b9e9:	00 
    b9ea:	e8 c1 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b9ef:	48 89 c7             	mov    %rax,%rdi
    b9f2:	e8 a9 ac ff ff       	call   66a0 <fwp_rc_fresh>
    b9f7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    b9fe:	00 
    b9ff:	bf 01 00 00 00       	mov    $0x1,%edi
    ba04:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    ba0b:	00 
    ba0c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    ba13:	00 
    ba14:	e8 97 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba19:	48 89 c7             	mov    %rax,%rdi
    ba1c:	e8 7f ac ff ff       	call   66a0 <fwp_rc_fresh>
    ba21:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    ba28:	00 
    ba29:	bf 01 00 00 00       	mov    $0x1,%edi
    ba2e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    ba35:	00 
    ba36:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    ba3d:	00 
    ba3e:	e8 6d a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba43:	48 89 c7             	mov    %rax,%rdi
    ba46:	e8 55 ac ff ff       	call   66a0 <fwp_rc_fresh>
    ba4b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    ba52:	00 
    ba53:	bf 01 00 00 00       	mov    $0x1,%edi
    ba58:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    ba5f:	00 
    ba60:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    ba67:	00 
    ba68:	e8 43 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba6d:	48 89 c7             	mov    %rax,%rdi
    ba70:	e8 2b ac ff ff       	call   66a0 <fwp_rc_fresh>
    ba75:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    ba7c:	00 
    ba7d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba82:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    ba89:	00 
    ba8a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    ba91:	00 
    ba92:	e8 19 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba97:	48 89 c7             	mov    %rax,%rdi
    ba9a:	e8 01 ac ff ff       	call   66a0 <fwp_rc_fresh>
    ba9f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    baa6:	00 
    baa7:	bf 01 00 00 00       	mov    $0x1,%edi
    baac:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    bab3:	00 
    bab4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    babb:	00 
    babc:	e8 ef a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bac1:	48 89 c7             	mov    %rax,%rdi
    bac4:	e8 d7 ab ff ff       	call   66a0 <fwp_rc_fresh>
    bac9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    bad0:	00 
    bad1:	bf 01 00 00 00       	mov    $0x1,%edi
    bad6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    badd:	00 
    bade:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    bae5:	00 
    bae6:	e8 c5 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    baeb:	48 89 c7             	mov    %rax,%rdi
    baee:	e8 ad ab ff ff       	call   66a0 <fwp_rc_fresh>
    baf3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    bafa:	00 
    bafb:	bf 01 00 00 00       	mov    $0x1,%edi
    bb00:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    bb07:	00 
    bb08:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    bb0f:	00 
    bb10:	e8 9b a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb15:	48 89 c7             	mov    %rax,%rdi
    bb18:	e8 83 ab ff ff       	call   66a0 <fwp_rc_fresh>
    bb1d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    bb24:	00 
    bb25:	bf 01 00 00 00       	mov    $0x1,%edi
    bb2a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    bb31:	00 
    bb32:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    bb39:	00 
    bb3a:	e8 71 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb3f:	48 89 c7             	mov    %rax,%rdi
    bb42:	e8 59 ab ff ff       	call   66a0 <fwp_rc_fresh>
    bb47:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    bb4e:	00 
    bb4f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb54:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    bb5b:	00 
    bb5c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    bb63:	00 
    bb64:	e8 47 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb69:	48 89 c7             	mov    %rax,%rdi
    bb6c:	e8 2f ab ff ff       	call   66a0 <fwp_rc_fresh>
    bb71:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    bb78:	00 
    bb79:	bf 01 00 00 00       	mov    $0x1,%edi
    bb7e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    bb85:	00 
    bb86:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    bb8d:	00 
    bb8e:	e8 1d a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb93:	48 89 c7             	mov    %rax,%rdi
    bb96:	e8 05 ab ff ff       	call   66a0 <fwp_rc_fresh>
    bb9b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    bba2:	00 
    bba3:	bf 01 00 00 00       	mov    $0x1,%edi
    bba8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    bbaf:	00 
    bbb0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    bbb7:	00 
    bbb8:	e8 f3 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bbbd:	48 89 c7             	mov    %rax,%rdi
    bbc0:	e8 db aa ff ff       	call   66a0 <fwp_rc_fresh>
    bbc5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    bbcc:	00 
    bbcd:	bf 01 00 00 00       	mov    $0x1,%edi
    bbd2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    bbd9:	00 
    bbda:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    bbe1:	00 
    bbe2:	e8 c9 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bbe7:	48 89 c7             	mov    %rax,%rdi
    bbea:	e8 b1 aa ff ff       	call   66a0 <fwp_rc_fresh>
    bbef:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    bbf6:	00 
    bbf7:	bf 01 00 00 00       	mov    $0x1,%edi
    bbfc:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    bc03:	00 
    bc04:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    bc0b:	00 
    bc0c:	e8 9f a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc11:	48 89 c7             	mov    %rax,%rdi
    bc14:	e8 87 aa ff ff       	call   66a0 <fwp_rc_fresh>
    bc19:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    bc20:	00 
    bc21:	bf 01 00 00 00       	mov    $0x1,%edi
    bc26:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    bc2d:	00 
    bc2e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    bc35:	00 
    bc36:	e8 75 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc3b:	48 89 c7             	mov    %rax,%rdi
    bc3e:	e8 5d aa ff ff       	call   66a0 <fwp_rc_fresh>
    bc43:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    bc4a:	00 
    bc4b:	bf 01 00 00 00       	mov    $0x1,%edi
    bc50:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    bc57:	00 
    bc58:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    bc5f:	00 
    bc60:	e8 4b a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc65:	48 89 c7             	mov    %rax,%rdi
    bc68:	e8 33 aa ff ff       	call   66a0 <fwp_rc_fresh>
    bc6d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    bc74:	00 
    bc75:	bf 01 00 00 00       	mov    $0x1,%edi
    bc7a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    bc81:	00 
    bc82:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    bc89:	00 
    bc8a:	e8 21 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc8f:	48 89 c7             	mov    %rax,%rdi
    bc92:	e8 09 aa ff ff       	call   66a0 <fwp_rc_fresh>
    bc97:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    bc9e:	00 
    bc9f:	bf 01 00 00 00       	mov    $0x1,%edi
    bca4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    bcab:	00 
    bcac:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    bcb3:	00 
    bcb4:	e8 f7 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bcb9:	48 89 c7             	mov    %rax,%rdi
    bcbc:	e8 df a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bcc1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    bcc8:	00 
    bcc9:	bf 01 00 00 00       	mov    $0x1,%edi
    bcce:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    bcd5:	00 
    bcd6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    bcdd:	00 
    bcde:	e8 cd a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bce3:	48 89 c7             	mov    %rax,%rdi
    bce6:	e8 b5 a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bceb:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    bcf2:	00 
    bcf3:	bf 01 00 00 00       	mov    $0x1,%edi
    bcf8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    bcff:	00 
    bd00:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    bd07:	00 
    bd08:	e8 a3 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd0d:	48 89 c7             	mov    %rax,%rdi
    bd10:	e8 8b a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bd15:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    bd1c:	00 
    bd1d:	bf 01 00 00 00       	mov    $0x1,%edi
    bd22:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    bd29:	00 
    bd2a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    bd31:	00 
    bd32:	e8 79 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd37:	48 89 c7             	mov    %rax,%rdi
    bd3a:	e8 61 a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bd3f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    bd46:	00 
    bd47:	bf 01 00 00 00       	mov    $0x1,%edi
    bd4c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    bd53:	00 
    bd54:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    bd5b:	00 
    bd5c:	e8 4f a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd61:	48 89 c7             	mov    %rax,%rdi
    bd64:	e8 37 a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bd69:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    bd70:	00 
    bd71:	bf 01 00 00 00       	mov    $0x1,%edi
    bd76:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    bd7d:	00 
    bd7e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    bd85:	00 
    bd86:	e8 25 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd8b:	48 89 c7             	mov    %rax,%rdi
    bd8e:	e8 0d a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bd93:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    bd9a:	00 
    bd9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bda0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    bda7:	00 
    bda8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    bdaf:	00 
    bdb0:	e8 fb 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bdb5:	48 89 c7             	mov    %rax,%rdi
    bdb8:	e8 e3 a8 ff ff       	call   66a0 <fwp_rc_fresh>
    bdbd:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    bdc4:	00 
    bdc5:	bf 01 00 00 00       	mov    $0x1,%edi
    bdca:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    bdd1:	00 
    bdd2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    bdd9:	00 
    bdda:	e8 d1 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bddf:	48 89 c7             	mov    %rax,%rdi
    bde2:	e8 b9 a8 ff ff       	call   66a0 <fwp_rc_fresh>
    bde7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    bdee:	00 
    bdef:	bf 01 00 00 00       	mov    $0x1,%edi
    bdf4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    bdfb:	00 
    bdfc:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    be03:	00 
    be04:	e8 a7 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be09:	48 89 c7             	mov    %rax,%rdi
    be0c:	e8 8f a8 ff ff       	call   66a0 <fwp_rc_fresh>
    be11:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    be18:	00 
    be19:	bf 01 00 00 00       	mov    $0x1,%edi
    be1e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    be25:	00 
    be26:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    be2d:	00 
    be2e:	e8 7d 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be33:	48 89 c7             	mov    %rax,%rdi
    be36:	e8 65 a8 ff ff       	call   66a0 <fwp_rc_fresh>
    be3b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    be42:	00 
    be43:	bf 01 00 00 00       	mov    $0x1,%edi
    be48:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    be4f:	00 
    be50:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    be57:	00 
    be58:	e8 53 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be5d:	48 89 c7             	mov    %rax,%rdi
    be60:	e8 3b a8 ff ff       	call   66a0 <fwp_rc_fresh>
    be65:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    be6c:	00 
    be6d:	bf 01 00 00 00       	mov    $0x1,%edi
    be72:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    be79:	00 
    be7a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    be81:	00 
    be82:	e8 29 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be87:	48 89 c7             	mov    %rax,%rdi
    be8a:	e8 11 a8 ff ff       	call   66a0 <fwp_rc_fresh>
    be8f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    be96:	00 
    be97:	bf 01 00 00 00       	mov    $0x1,%edi
    be9c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    bea3:	00 
    bea4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    beab:	00 
    beac:	e8 ff 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    beb1:	48 89 c7             	mov    %rax,%rdi
    beb4:	e8 e7 a7 ff ff       	call   66a0 <fwp_rc_fresh>
    beb9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    bec0:	00 
    bec1:	bf 01 00 00 00       	mov    $0x1,%edi
    bec6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    becd:	00 
    bece:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    bed5:	00 
    bed6:	e8 d5 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bedb:	48 89 c7             	mov    %rax,%rdi
    bede:	e8 bd a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bee3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    beea:	00 
    beeb:	bf 01 00 00 00       	mov    $0x1,%edi
    bef0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    bef7:	00 
    bef8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    beff:	00 
    bf00:	e8 ab 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bf05:	48 89 c7             	mov    %rax,%rdi
    bf08:	e8 93 a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bf0d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    bf14:	00 
    bf15:	bf 01 00 00 00       	mov    $0x1,%edi
    bf1a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    bf21:	00 
    bf22:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    bf29:	00 
    bf2a:	e8 81 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bf2f:	48 89 c7             	mov    %rax,%rdi
    bf32:	e8 69 a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bf37:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    bf3e:	00 
    bf3f:	bf 01 00 00 00       	mov    $0x1,%edi
    bf44:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    bf4b:	00 
    bf4c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    bf53:	00 
    bf54:	e8 57 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bf59:	48 89 c7             	mov    %rax,%rdi
    bf5c:	e8 3f a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bf61:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    bf68:	00 
    bf69:	bf 01 00 00 00       	mov    $0x1,%edi
    bf6e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    bf75:	00 
    bf76:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    bf7d:	00 
    bf7e:	e8 2d 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bf83:	48 89 c7             	mov    %rax,%rdi
    bf86:	e8 15 a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bf8b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    bf92:	00 
    bf93:	bf 01 00 00 00       	mov    $0x1,%edi
    bf98:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    bf9f:	00 
    bfa0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    bfa7:	00 
    bfa8:	e8 03 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bfad:	48 89 c7             	mov    %rax,%rdi
    bfb0:	e8 eb a6 ff ff       	call   66a0 <fwp_rc_fresh>
    bfb5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    bfbc:	00 
    bfbd:	bf 01 00 00 00       	mov    $0x1,%edi
    bfc2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    bfc9:	00 
    bfca:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    bfd1:	00 
    bfd2:	e8 d9 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bfd7:	48 89 c7             	mov    %rax,%rdi
    bfda:	e8 c1 a6 ff ff       	call   66a0 <fwp_rc_fresh>
    bfdf:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    bfe6:	00 
    bfe7:	bf 01 00 00 00       	mov    $0x1,%edi
    bfec:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    bff3:	00 
    bff4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    bffb:	00 
    bffc:	e8 af 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c001:	48 89 c7             	mov    %rax,%rdi
    c004:	e8 97 a6 ff ff       	call   66a0 <fwp_rc_fresh>
    c009:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c010:	00 
    c011:	bf 01 00 00 00       	mov    $0x1,%edi
    c016:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c01d:	00 
    c01e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c025:	00 
    c026:	e8 85 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c02b:	48 89 c7             	mov    %rax,%rdi
    c02e:	e8 6d a6 ff ff       	call   66a0 <fwp_rc_fresh>
    c033:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c03a:	00 
    c03b:	bf 01 00 00 00       	mov    $0x1,%edi
    c040:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c047:	00 
    c048:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c04f:	00 
    c050:	e8 5b 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c055:	48 8b 15 3c 8b 01 00 	mov    0x18b3c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c05c:	49 89 c5             	mov    %rax,%r13
    c05f:	48 2b 05 0a 8b 01 00 	sub    0x18b0a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c066:	48 c1 e2 10          	shl    $0x10,%rdx
    c06a:	48 39 d0             	cmp    %rdx,%rax
    c06d:	73 59                	jae    c0c8 <f0+0x13b8>
    c06f:	48 89 c2             	mov    %rax,%rdx
    c072:	48 c1 ea 10          	shr    $0x10,%rdx
    c076:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c07a:	48 8b 15 37 8b 01 00 	mov    0x18b37(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c081:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c085:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c089:	4d 85 e4             	test   %r12,%r12
    c08c:	74 3a                	je     c0c8 <f0+0x13b8>
    c08e:	0f b6 0a             	movzbl (%rdx),%ecx
    c091:	80 f9 02             	cmp    $0x2,%cl
    c094:	0f 84 c6 15 00 00    	je     d660 <f0+0x2950>
    c09a:	80 f9 01             	cmp    $0x1,%cl
    c09d:	75 29                	jne    c0c8 <f0+0x13b8>
    c09f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0a2:	0f b7 c0             	movzwl %ax,%eax
    c0a5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0a8:	48 0f af c1          	imul   %rcx,%rax
    c0ac:	48 c1 e8 20          	shr    $0x20,%rax
    c0b0:	48 39 d0             	cmp    %rdx,%rax
    c0b3:	73 13                	jae    c0c8 <f0+0x13b8>
    c0b5:	49 01 c4             	add    %rax,%r12
    c0b8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c0bd:	0f 84 99 17 00 00    	je     d85c <f0+0x2b4c>
    c0c3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c0c8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c0cf:	33 f3 bf 
    c0d2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c0d9:	00 
    c0da:	bf 01 00 00 00       	mov    $0x1,%edi
    c0df:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c0e6:	00 
    c0e7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c0ee:	00 
    c0ef:	e8 bc 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c0f4:	48 8b 15 9d 8a 01 00 	mov    0x18a9d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c0fb:	49 89 c5             	mov    %rax,%r13
    c0fe:	48 2b 05 6b 8a 01 00 	sub    0x18a6b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c105:	48 c1 e2 10          	shl    $0x10,%rdx
    c109:	48 39 d0             	cmp    %rdx,%rax
    c10c:	73 59                	jae    c167 <f0+0x1457>
    c10e:	48 89 c2             	mov    %rax,%rdx
    c111:	48 c1 ea 10          	shr    $0x10,%rdx
    c115:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c119:	48 8b 15 98 8a 01 00 	mov    0x18a98(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c120:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c124:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c128:	4d 85 e4             	test   %r12,%r12
    c12b:	74 3a                	je     c167 <f0+0x1457>
    c12d:	0f b6 0a             	movzbl (%rdx),%ecx
    c130:	80 f9 02             	cmp    $0x2,%cl
    c133:	0f 84 17 15 00 00    	je     d650 <f0+0x2940>
    c139:	80 f9 01             	cmp    $0x1,%cl
    c13c:	75 29                	jne    c167 <f0+0x1457>
    c13e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c141:	0f b7 c0             	movzwl %ax,%eax
    c144:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c147:	48 0f af c1          	imul   %rcx,%rax
    c14b:	48 c1 e8 20          	shr    $0x20,%rax
    c14f:	48 39 d0             	cmp    %rdx,%rax
    c152:	73 13                	jae    c167 <f0+0x1457>
    c154:	49 01 c4             	add    %rax,%r12
    c157:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c15c:	0f 84 07 17 00 00    	je     d869 <f0+0x2b59>
    c162:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c167:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c16e:	00 f0 3f 
    c171:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c178:	00 
    c179:	bf 01 00 00 00       	mov    $0x1,%edi
    c17e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c185:	00 
    c186:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c18d:	00 
    c18e:	e8 1d 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c193:	48 8b 15 fe 89 01 00 	mov    0x189fe(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c19a:	49 89 c5             	mov    %rax,%r13
    c19d:	48 2b 05 cc 89 01 00 	sub    0x189cc(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c1a4:	48 c1 e2 10          	shl    $0x10,%rdx
    c1a8:	48 39 d0             	cmp    %rdx,%rax
    c1ab:	73 59                	jae    c206 <f0+0x14f6>
    c1ad:	48 89 c2             	mov    %rax,%rdx
    c1b0:	48 c1 ea 10          	shr    $0x10,%rdx
    c1b4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c1b8:	48 8b 15 f9 89 01 00 	mov    0x189f9(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c1bf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c1c3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c1c7:	4d 85 e4             	test   %r12,%r12
    c1ca:	74 3a                	je     c206 <f0+0x14f6>
    c1cc:	0f b6 0a             	movzbl (%rdx),%ecx
    c1cf:	80 f9 02             	cmp    $0x2,%cl
    c1d2:	0f 84 28 15 00 00    	je     d700 <f0+0x29f0>
    c1d8:	80 f9 01             	cmp    $0x1,%cl
    c1db:	75 29                	jne    c206 <f0+0x14f6>
    c1dd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c1e0:	0f b7 c0             	movzwl %ax,%eax
    c1e3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c1e6:	48 0f af c1          	imul   %rcx,%rax
    c1ea:	48 c1 e8 20          	shr    $0x20,%rax
    c1ee:	48 39 d0             	cmp    %rdx,%rax
    c1f1:	73 13                	jae    c206 <f0+0x14f6>
    c1f3:	49 01 c4             	add    %rax,%r12
    c1f6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c1fb:	0f 84 75 16 00 00    	je     d876 <f0+0x2b66>
    c201:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c206:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c20d:	33 f3 bf 
    c210:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c217:	00 
    c218:	bf 01 00 00 00       	mov    $0x1,%edi
    c21d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c224:	00 
    c225:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c22c:	00 
    c22d:	e8 7e 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c232:	48 8b 15 5f 89 01 00 	mov    0x1895f(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c239:	49 89 c5             	mov    %rax,%r13
    c23c:	48 2b 05 2d 89 01 00 	sub    0x1892d(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c243:	48 c1 e2 10          	shl    $0x10,%rdx
    c247:	48 39 d0             	cmp    %rdx,%rax
    c24a:	73 59                	jae    c2a5 <f0+0x1595>
    c24c:	48 89 c2             	mov    %rax,%rdx
    c24f:	48 c1 ea 10          	shr    $0x10,%rdx
    c253:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c257:	48 8b 15 5a 89 01 00 	mov    0x1895a(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c25e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c262:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c266:	4d 85 e4             	test   %r12,%r12
    c269:	74 3a                	je     c2a5 <f0+0x1595>
    c26b:	0f b6 0a             	movzbl (%rdx),%ecx
    c26e:	80 f9 02             	cmp    $0x2,%cl
    c271:	0f 84 79 14 00 00    	je     d6f0 <f0+0x29e0>
    c277:	80 f9 01             	cmp    $0x1,%cl
    c27a:	75 29                	jne    c2a5 <f0+0x1595>
    c27c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c27f:	0f b7 c0             	movzwl %ax,%eax
    c282:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c285:	48 0f af c1          	imul   %rcx,%rax
    c289:	48 c1 e8 20          	shr    $0x20,%rax
    c28d:	48 39 d0             	cmp    %rdx,%rax
    c290:	73 13                	jae    c2a5 <f0+0x1595>
    c292:	49 01 c4             	add    %rax,%r12
    c295:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c29a:	0f 84 e3 15 00 00    	je     d883 <f0+0x2b73>
    c2a0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2a5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c2ac:	00 f0 3f 
    c2af:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c2b6:	00 
    c2b7:	bf 01 00 00 00       	mov    $0x1,%edi
    c2bc:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c2c3:	00 
    c2c4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c2cb:	00 
    c2cc:	e8 df 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c2d1:	48 8b 15 c0 88 01 00 	mov    0x188c0(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c2d8:	49 89 c5             	mov    %rax,%r13
    c2db:	48 2b 05 8e 88 01 00 	sub    0x1888e(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c2e2:	48 c1 e2 10          	shl    $0x10,%rdx
    c2e6:	48 39 d0             	cmp    %rdx,%rax
    c2e9:	73 59                	jae    c344 <f0+0x1634>
    c2eb:	48 89 c2             	mov    %rax,%rdx
    c2ee:	48 c1 ea 10          	shr    $0x10,%rdx
    c2f2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c2f6:	48 8b 15 bb 88 01 00 	mov    0x188bb(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c2fd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c301:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c305:	4d 85 e4             	test   %r12,%r12
    c308:	74 3a                	je     c344 <f0+0x1634>
    c30a:	0f b6 0a             	movzbl (%rdx),%ecx
    c30d:	80 f9 02             	cmp    $0x2,%cl
    c310:	0f 84 ca 13 00 00    	je     d6e0 <f0+0x29d0>
    c316:	80 f9 01             	cmp    $0x1,%cl
    c319:	75 29                	jne    c344 <f0+0x1634>
    c31b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c31e:	0f b7 c0             	movzwl %ax,%eax
    c321:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c324:	48 0f af c1          	imul   %rcx,%rax
    c328:	48 c1 e8 20          	shr    $0x20,%rax
    c32c:	48 39 d0             	cmp    %rdx,%rax
    c32f:	73 13                	jae    c344 <f0+0x1634>
    c331:	49 01 c4             	add    %rax,%r12
    c334:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c339:	0f 84 51 15 00 00    	je     d890 <f0+0x2b80>
    c33f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c344:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c34b:	33 f3 bf 
    c34e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c355:	00 
    c356:	bf 01 00 00 00       	mov    $0x1,%edi
    c35b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c362:	00 
    c363:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c36a:	00 
    c36b:	e8 40 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c370:	48 8b 15 21 88 01 00 	mov    0x18821(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c377:	49 89 c5             	mov    %rax,%r13
    c37a:	48 2b 05 ef 87 01 00 	sub    0x187ef(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c381:	48 c1 e2 10          	shl    $0x10,%rdx
    c385:	48 39 d0             	cmp    %rdx,%rax
    c388:	73 59                	jae    c3e3 <f0+0x16d3>
    c38a:	48 89 c2             	mov    %rax,%rdx
    c38d:	48 c1 ea 10          	shr    $0x10,%rdx
    c391:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c395:	48 8b 15 1c 88 01 00 	mov    0x1881c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c39c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3a0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3a4:	4d 85 e4             	test   %r12,%r12
    c3a7:	74 3a                	je     c3e3 <f0+0x16d3>
    c3a9:	0f b6 0a             	movzbl (%rdx),%ecx
    c3ac:	80 f9 02             	cmp    $0x2,%cl
    c3af:	0f 84 1b 13 00 00    	je     d6d0 <f0+0x29c0>
    c3b5:	80 f9 01             	cmp    $0x1,%cl
    c3b8:	75 29                	jne    c3e3 <f0+0x16d3>
    c3ba:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c3bd:	0f b7 c0             	movzwl %ax,%eax
    c3c0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c3c3:	48 0f af c1          	imul   %rcx,%rax
    c3c7:	48 c1 e8 20          	shr    $0x20,%rax
    c3cb:	48 39 d0             	cmp    %rdx,%rax
    c3ce:	73 13                	jae    c3e3 <f0+0x16d3>
    c3d0:	49 01 c4             	add    %rax,%r12
    c3d3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c3d8:	0f 84 bf 14 00 00    	je     d89d <f0+0x2b8d>
    c3de:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c3e3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c3ea:	00 f0 3f 
    c3ed:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c3f4:	00 
    c3f5:	bf 01 00 00 00       	mov    $0x1,%edi
    c3fa:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c401:	00 
    c402:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c409:	00 
    c40a:	e8 a1 99 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c40f:	48 8b 15 82 87 01 00 	mov    0x18782(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c416:	49 89 c5             	mov    %rax,%r13
    c419:	48 2b 05 50 87 01 00 	sub    0x18750(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c420:	48 c1 e2 10          	shl    $0x10,%rdx
    c424:	48 39 d0             	cmp    %rdx,%rax
    c427:	73 59                	jae    c482 <f0+0x1772>
    c429:	48 89 c2             	mov    %rax,%rdx
    c42c:	48 c1 ea 10          	shr    $0x10,%rdx
    c430:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c434:	48 8b 15 7d 87 01 00 	mov    0x1877d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c43b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c43f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c443:	4d 85 e4             	test   %r12,%r12
    c446:	74 3a                	je     c482 <f0+0x1772>
    c448:	0f b6 0a             	movzbl (%rdx),%ecx
    c44b:	80 f9 02             	cmp    $0x2,%cl
    c44e:	0f 84 6c 12 00 00    	je     d6c0 <f0+0x29b0>
    c454:	80 f9 01             	cmp    $0x1,%cl
    c457:	75 29                	jne    c482 <f0+0x1772>
    c459:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c45c:	0f b7 c0             	movzwl %ax,%eax
    c45f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c462:	48 0f af c1          	imul   %rcx,%rax
    c466:	48 c1 e8 20          	shr    $0x20,%rax
    c46a:	48 39 d0             	cmp    %rdx,%rax
    c46d:	73 13                	jae    c482 <f0+0x1772>
    c46f:	49 01 c4             	add    %rax,%r12
    c472:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c477:	0f 84 2d 14 00 00    	je     d8aa <f0+0x2b9a>
    c47d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c482:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c489:	33 f3 bf 
    c48c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c493:	00 
    c494:	bf 01 00 00 00       	mov    $0x1,%edi
    c499:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c4a0:	00 
    c4a1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c4a8:	00 
    c4a9:	e8 02 99 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c4ae:	48 8b 15 e3 86 01 00 	mov    0x186e3(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c4b5:	49 89 c5             	mov    %rax,%r13
    c4b8:	48 2b 05 b1 86 01 00 	sub    0x186b1(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c4bf:	48 c1 e2 10          	shl    $0x10,%rdx
    c4c3:	48 39 d0             	cmp    %rdx,%rax
    c4c6:	73 59                	jae    c521 <f0+0x1811>
    c4c8:	48 89 c2             	mov    %rax,%rdx
    c4cb:	48 c1 ea 10          	shr    $0x10,%rdx
    c4cf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c4d3:	48 8b 15 de 86 01 00 	mov    0x186de(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c4da:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c4de:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c4e2:	4d 85 e4             	test   %r12,%r12
    c4e5:	74 3a                	je     c521 <f0+0x1811>
    c4e7:	0f b6 0a             	movzbl (%rdx),%ecx
    c4ea:	80 f9 02             	cmp    $0x2,%cl
    c4ed:	0f 84 bd 11 00 00    	je     d6b0 <f0+0x29a0>
    c4f3:	80 f9 01             	cmp    $0x1,%cl
    c4f6:	75 29                	jne    c521 <f0+0x1811>
    c4f8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c4fb:	0f b7 c0             	movzwl %ax,%eax
    c4fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c501:	48 0f af c1          	imul   %rcx,%rax
    c505:	48 c1 e8 20          	shr    $0x20,%rax
    c509:	48 39 d0             	cmp    %rdx,%rax
    c50c:	73 13                	jae    c521 <f0+0x1811>
    c50e:	49 01 c4             	add    %rax,%r12
    c511:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c516:	0f 84 9b 13 00 00    	je     d8b7 <f0+0x2ba7>
    c51c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c521:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c528:	00 f0 3f 
    c52b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c532:	00 
    c533:	bf 01 00 00 00       	mov    $0x1,%edi
    c538:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c53f:	00 
    c540:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c547:	00 
    c548:	e8 63 98 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c54d:	48 8b 15 44 86 01 00 	mov    0x18644(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c554:	49 89 c5             	mov    %rax,%r13
    c557:	48 2b 05 12 86 01 00 	sub    0x18612(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c55e:	48 c1 e2 10          	shl    $0x10,%rdx
    c562:	48 39 d0             	cmp    %rdx,%rax
    c565:	73 59                	jae    c5c0 <f0+0x18b0>
    c567:	48 89 c2             	mov    %rax,%rdx
    c56a:	48 c1 ea 10          	shr    $0x10,%rdx
    c56e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c572:	48 8b 15 3f 86 01 00 	mov    0x1863f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c579:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c57d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c581:	4d 85 e4             	test   %r12,%r12
    c584:	74 3a                	je     c5c0 <f0+0x18b0>
    c586:	0f b6 0a             	movzbl (%rdx),%ecx
    c589:	80 f9 02             	cmp    $0x2,%cl
    c58c:	0f 84 0e 11 00 00    	je     d6a0 <f0+0x2990>
    c592:	80 f9 01             	cmp    $0x1,%cl
    c595:	75 29                	jne    c5c0 <f0+0x18b0>
    c597:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c59a:	0f b7 c0             	movzwl %ax,%eax
    c59d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5a0:	48 0f af c1          	imul   %rcx,%rax
    c5a4:	48 c1 e8 20          	shr    $0x20,%rax
    c5a8:	48 39 d0             	cmp    %rdx,%rax
    c5ab:	73 13                	jae    c5c0 <f0+0x18b0>
    c5ad:	49 01 c4             	add    %rax,%r12
    c5b0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5b5:	0f 84 09 13 00 00    	je     d8c4 <f0+0x2bb4>
    c5bb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c5c0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c5c7:	33 f3 bf 
    c5ca:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c5d1:	00 
    c5d2:	bf 01 00 00 00       	mov    $0x1,%edi
    c5d7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c5de:	00 
    c5df:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c5e6:	00 
    c5e7:	e8 c4 97 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c5ec:	48 8b 15 a5 85 01 00 	mov    0x185a5(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c5f3:	49 89 c5             	mov    %rax,%r13
    c5f6:	48 2b 05 73 85 01 00 	sub    0x18573(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c5fd:	48 c1 e2 10          	shl    $0x10,%rdx
    c601:	48 39 d0             	cmp    %rdx,%rax
    c604:	73 59                	jae    c65f <f0+0x194f>
    c606:	48 89 c2             	mov    %rax,%rdx
    c609:	48 c1 ea 10          	shr    $0x10,%rdx
    c60d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c611:	48 8b 15 a0 85 01 00 	mov    0x185a0(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c618:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c61c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c620:	4d 85 e4             	test   %r12,%r12
    c623:	74 3a                	je     c65f <f0+0x194f>
    c625:	0f b6 0a             	movzbl (%rdx),%ecx
    c628:	80 f9 02             	cmp    $0x2,%cl
    c62b:	0f 84 5f 10 00 00    	je     d690 <f0+0x2980>
    c631:	80 f9 01             	cmp    $0x1,%cl
    c634:	75 29                	jne    c65f <f0+0x194f>
    c636:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c639:	0f b7 c0             	movzwl %ax,%eax
    c63c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c63f:	48 0f af c1          	imul   %rcx,%rax
    c643:	48 c1 e8 20          	shr    $0x20,%rax
    c647:	48 39 d0             	cmp    %rdx,%rax
    c64a:	73 13                	jae    c65f <f0+0x194f>
    c64c:	49 01 c4             	add    %rax,%r12
    c64f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c654:	0f 84 77 12 00 00    	je     d8d1 <f0+0x2bc1>
    c65a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c65f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c666:	00 f0 3f 
    c669:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c670:	00 
    c671:	bf 01 00 00 00       	mov    $0x1,%edi
    c676:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c67d:	00 
    c67e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c685:	00 
    c686:	e8 25 97 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c68b:	48 8b 15 06 85 01 00 	mov    0x18506(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c692:	49 89 c5             	mov    %rax,%r13
    c695:	48 2b 05 d4 84 01 00 	sub    0x184d4(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c69c:	48 c1 e2 10          	shl    $0x10,%rdx
    c6a0:	48 39 d0             	cmp    %rdx,%rax
    c6a3:	73 59                	jae    c6fe <f0+0x19ee>
    c6a5:	48 89 c2             	mov    %rax,%rdx
    c6a8:	48 c1 ea 10          	shr    $0x10,%rdx
    c6ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6b0:	48 8b 15 01 85 01 00 	mov    0x18501(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c6b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c6bb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c6bf:	4d 85 e4             	test   %r12,%r12
    c6c2:	74 3a                	je     c6fe <f0+0x19ee>
    c6c4:	0f b6 0a             	movzbl (%rdx),%ecx
    c6c7:	80 f9 02             	cmp    $0x2,%cl
    c6ca:	0f 84 40 0f 00 00    	je     d610 <f0+0x2900>
    c6d0:	80 f9 01             	cmp    $0x1,%cl
    c6d3:	75 29                	jne    c6fe <f0+0x19ee>
    c6d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c6d8:	0f b7 c0             	movzwl %ax,%eax
    c6db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c6de:	48 0f af c1          	imul   %rcx,%rax
    c6e2:	48 c1 e8 20          	shr    $0x20,%rax
    c6e6:	48 39 d0             	cmp    %rdx,%rax
    c6e9:	73 13                	jae    c6fe <f0+0x19ee>
    c6eb:	49 01 c4             	add    %rax,%r12
    c6ee:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6f3:	0f 84 e5 11 00 00    	je     d8de <f0+0x2bce>
    c6f9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6fe:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c705:	33 f3 bf 
    c708:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c70f:	00 
    c710:	bf 01 00 00 00       	mov    $0x1,%edi
    c715:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c71c:	00 
    c71d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c724:	00 
    c725:	e8 86 96 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c72a:	48 8b 15 67 84 01 00 	mov    0x18467(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c731:	49 89 c5             	mov    %rax,%r13
    c734:	48 2b 05 35 84 01 00 	sub    0x18435(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c73b:	48 c1 e2 10          	shl    $0x10,%rdx
    c73f:	48 39 d0             	cmp    %rdx,%rax
    c742:	73 59                	jae    c79d <f0+0x1a8d>
    c744:	48 89 c2             	mov    %rax,%rdx
    c747:	48 c1 ea 10          	shr    $0x10,%rdx
    c74b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c74f:	48 8b 15 62 84 01 00 	mov    0x18462(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c756:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c75a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c75e:	4d 85 e4             	test   %r12,%r12
    c761:	74 3a                	je     c79d <f0+0x1a8d>
    c763:	0f b6 0a             	movzbl (%rdx),%ecx
    c766:	80 f9 02             	cmp    $0x2,%cl
    c769:	0f 84 91 0e 00 00    	je     d600 <f0+0x28f0>
    c76f:	80 f9 01             	cmp    $0x1,%cl
    c772:	75 29                	jne    c79d <f0+0x1a8d>
    c774:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c777:	0f b7 c0             	movzwl %ax,%eax
    c77a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c77d:	48 0f af c1          	imul   %rcx,%rax
    c781:	48 c1 e8 20          	shr    $0x20,%rax
    c785:	48 39 d0             	cmp    %rdx,%rax
    c788:	73 13                	jae    c79d <f0+0x1a8d>
    c78a:	49 01 c4             	add    %rax,%r12
    c78d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c792:	0f 84 53 11 00 00    	je     d8eb <f0+0x2bdb>
    c798:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c79d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c7a4:	00 f0 3f 
    c7a7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c7ae:	00 
    c7af:	bf 01 00 00 00       	mov    $0x1,%edi
    c7b4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c7bb:	00 
    c7bc:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c7c3:	00 
    c7c4:	e8 e7 95 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c7c9:	48 8b 15 c8 83 01 00 	mov    0x183c8(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c7d0:	49 89 c5             	mov    %rax,%r13
    c7d3:	48 2b 05 96 83 01 00 	sub    0x18396(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c7da:	48 c1 e2 10          	shl    $0x10,%rdx
    c7de:	48 39 d0             	cmp    %rdx,%rax
    c7e1:	73 59                	jae    c83c <f0+0x1b2c>
    c7e3:	48 89 c2             	mov    %rax,%rdx
    c7e6:	48 c1 ea 10          	shr    $0x10,%rdx
    c7ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7ee:	48 8b 15 c3 83 01 00 	mov    0x183c3(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c7f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7f9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7fd:	4d 85 e4             	test   %r12,%r12
    c800:	74 3a                	je     c83c <f0+0x1b2c>
    c802:	0f b6 0a             	movzbl (%rdx),%ecx
    c805:	80 f9 02             	cmp    $0x2,%cl
    c808:	0f 84 e2 0d 00 00    	je     d5f0 <f0+0x28e0>
    c80e:	80 f9 01             	cmp    $0x1,%cl
    c811:	75 29                	jne    c83c <f0+0x1b2c>
    c813:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c816:	0f b7 c0             	movzwl %ax,%eax
    c819:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c81c:	48 0f af c1          	imul   %rcx,%rax
    c820:	48 c1 e8 20          	shr    $0x20,%rax
    c824:	48 39 d0             	cmp    %rdx,%rax
    c827:	73 13                	jae    c83c <f0+0x1b2c>
    c829:	49 01 c4             	add    %rax,%r12
    c82c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c831:	0f 84 c1 10 00 00    	je     d8f8 <f0+0x2be8>
    c837:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c83c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c843:	33 f3 bf 
    c846:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    c84d:	00 
    c84e:	bf 01 00 00 00       	mov    $0x1,%edi
    c853:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    c85a:	00 
    c85b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    c862:	00 
    c863:	e8 48 95 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c868:	48 8b 15 29 83 01 00 	mov    0x18329(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c86f:	49 89 c5             	mov    %rax,%r13
    c872:	48 2b 05 f7 82 01 00 	sub    0x182f7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c879:	48 c1 e2 10          	shl    $0x10,%rdx
    c87d:	48 39 d0             	cmp    %rdx,%rax
    c880:	73 59                	jae    c8db <f0+0x1bcb>
    c882:	48 89 c2             	mov    %rax,%rdx
    c885:	48 c1 ea 10          	shr    $0x10,%rdx
    c889:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c88d:	48 8b 15 24 83 01 00 	mov    0x18324(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c894:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c898:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c89c:	4d 85 e4             	test   %r12,%r12
    c89f:	74 3a                	je     c8db <f0+0x1bcb>
    c8a1:	0f b6 0a             	movzbl (%rdx),%ecx
    c8a4:	80 f9 02             	cmp    $0x2,%cl
    c8a7:	0f 84 33 0d 00 00    	je     d5e0 <f0+0x28d0>
    c8ad:	80 f9 01             	cmp    $0x1,%cl
    c8b0:	75 29                	jne    c8db <f0+0x1bcb>
    c8b2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8b5:	0f b7 c0             	movzwl %ax,%eax
    c8b8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8bb:	48 0f af c1          	imul   %rcx,%rax
    c8bf:	48 c1 e8 20          	shr    $0x20,%rax
    c8c3:	48 39 d0             	cmp    %rdx,%rax
    c8c6:	73 13                	jae    c8db <f0+0x1bcb>
    c8c8:	49 01 c4             	add    %rax,%r12
    c8cb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8d0:	0f 84 2f 10 00 00    	je     d905 <f0+0x2bf5>
    c8d6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8db:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c8e2:	00 f0 3f 
    c8e5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    c8ec:	00 
    c8ed:	bf 01 00 00 00       	mov    $0x1,%edi
    c8f2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    c8f9:	00 
    c8fa:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    c901:	00 
    c902:	e8 a9 94 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c907:	48 8b 15 8a 82 01 00 	mov    0x1828a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c90e:	49 89 c5             	mov    %rax,%r13
    c911:	48 2b 05 58 82 01 00 	sub    0x18258(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c918:	48 c1 e2 10          	shl    $0x10,%rdx
    c91c:	48 39 d0             	cmp    %rdx,%rax
    c91f:	73 59                	jae    c97a <f0+0x1c6a>
    c921:	48 89 c2             	mov    %rax,%rdx
    c924:	48 c1 ea 10          	shr    $0x10,%rdx
    c928:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c92c:	48 8b 15 85 82 01 00 	mov    0x18285(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c933:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c937:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c93b:	4d 85 e4             	test   %r12,%r12
    c93e:	74 3a                	je     c97a <f0+0x1c6a>
    c940:	0f b6 0a             	movzbl (%rdx),%ecx
    c943:	80 f9 02             	cmp    $0x2,%cl
    c946:	0f 84 84 0c 00 00    	je     d5d0 <f0+0x28c0>
    c94c:	80 f9 01             	cmp    $0x1,%cl
    c94f:	75 29                	jne    c97a <f0+0x1c6a>
    c951:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c954:	0f b7 c0             	movzwl %ax,%eax
    c957:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c95a:	48 0f af c1          	imul   %rcx,%rax
    c95e:	48 c1 e8 20          	shr    $0x20,%rax
    c962:	48 39 d0             	cmp    %rdx,%rax
    c965:	73 13                	jae    c97a <f0+0x1c6a>
    c967:	49 01 c4             	add    %rax,%r12
    c96a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c96f:	0f 84 9d 0f 00 00    	je     d912 <f0+0x2c02>
    c975:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c97a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c981:	33 f3 bf 
    c984:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    c98b:	00 
    c98c:	bf 01 00 00 00       	mov    $0x1,%edi
    c991:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    c998:	00 
    c999:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    c9a0:	00 
    c9a1:	e8 0a 94 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c9a6:	48 8b 15 eb 81 01 00 	mov    0x181eb(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c9ad:	49 89 c5             	mov    %rax,%r13
    c9b0:	48 2b 05 b9 81 01 00 	sub    0x181b9(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c9b7:	48 c1 e2 10          	shl    $0x10,%rdx
    c9bb:	48 39 d0             	cmp    %rdx,%rax
    c9be:	73 59                	jae    ca19 <f0+0x1d09>
    c9c0:	48 89 c2             	mov    %rax,%rdx
    c9c3:	48 c1 ea 10          	shr    $0x10,%rdx
    c9c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9cb:	48 8b 15 e6 81 01 00 	mov    0x181e6(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c9d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9d6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9da:	4d 85 e4             	test   %r12,%r12
    c9dd:	74 3a                	je     ca19 <f0+0x1d09>
    c9df:	0f b6 0a             	movzbl (%rdx),%ecx
    c9e2:	80 f9 02             	cmp    $0x2,%cl
    c9e5:	0f 84 d5 0b 00 00    	je     d5c0 <f0+0x28b0>
    c9eb:	80 f9 01             	cmp    $0x1,%cl
    c9ee:	75 29                	jne    ca19 <f0+0x1d09>
    c9f0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9f3:	0f b7 c0             	movzwl %ax,%eax
    c9f6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9f9:	48 0f af c1          	imul   %rcx,%rax
    c9fd:	48 c1 e8 20          	shr    $0x20,%rax
    ca01:	48 39 d0             	cmp    %rdx,%rax
    ca04:	73 13                	jae    ca19 <f0+0x1d09>
    ca06:	49 01 c4             	add    %rax,%r12
    ca09:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca0e:	0f 84 0b 0f 00 00    	je     d91f <f0+0x2c0f>
    ca14:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca19:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca20:	00 f0 3f 
    ca23:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    ca2a:	00 
    ca2b:	bf 01 00 00 00       	mov    $0x1,%edi
    ca30:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    ca37:	00 
    ca38:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    ca3f:	00 
    ca40:	e8 6b 93 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ca45:	48 8b 15 4c 81 01 00 	mov    0x1814c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ca4c:	49 89 c5             	mov    %rax,%r13
    ca4f:	48 2b 05 1a 81 01 00 	sub    0x1811a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ca56:	48 c1 e2 10          	shl    $0x10,%rdx
    ca5a:	48 39 d0             	cmp    %rdx,%rax
    ca5d:	73 59                	jae    cab8 <f0+0x1da8>
    ca5f:	48 89 c2             	mov    %rax,%rdx
    ca62:	48 c1 ea 10          	shr    $0x10,%rdx
    ca66:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca6a:	48 8b 15 47 81 01 00 	mov    0x18147(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ca71:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca75:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca79:	4d 85 e4             	test   %r12,%r12
    ca7c:	74 3a                	je     cab8 <f0+0x1da8>
    ca7e:	0f b6 0a             	movzbl (%rdx),%ecx
    ca81:	80 f9 02             	cmp    $0x2,%cl
    ca84:	0f 84 26 0b 00 00    	je     d5b0 <f0+0x28a0>
    ca8a:	80 f9 01             	cmp    $0x1,%cl
    ca8d:	75 29                	jne    cab8 <f0+0x1da8>
    ca8f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca92:	0f b7 c0             	movzwl %ax,%eax
    ca95:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca98:	48 0f af c1          	imul   %rcx,%rax
    ca9c:	48 c1 e8 20          	shr    $0x20,%rax
    caa0:	48 39 d0             	cmp    %rdx,%rax
    caa3:	73 13                	jae    cab8 <f0+0x1da8>
    caa5:	49 01 c4             	add    %rax,%r12
    caa8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    caad:	0f 84 79 0e 00 00    	je     d92c <f0+0x2c1c>
    cab3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cab8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cabf:	33 f3 bf 
    cac2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    cac9:	00 
    caca:	bf 01 00 00 00       	mov    $0x1,%edi
    cacf:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    cad6:	00 
    cad7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    cade:	00 
    cadf:	e8 cc 92 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cae4:	48 8b 15 ad 80 01 00 	mov    0x180ad(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    caeb:	49 89 c5             	mov    %rax,%r13
    caee:	48 2b 05 7b 80 01 00 	sub    0x1807b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    caf5:	48 c1 e2 10          	shl    $0x10,%rdx
    caf9:	48 39 d0             	cmp    %rdx,%rax
    cafc:	73 59                	jae    cb57 <f0+0x1e47>
    cafe:	48 89 c2             	mov    %rax,%rdx
    cb01:	48 c1 ea 10          	shr    $0x10,%rdx
    cb05:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb09:	48 8b 15 a8 80 01 00 	mov    0x180a8(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cb10:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb14:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb18:	4d 85 e4             	test   %r12,%r12
    cb1b:	74 3a                	je     cb57 <f0+0x1e47>
    cb1d:	0f b6 0a             	movzbl (%rdx),%ecx
    cb20:	80 f9 02             	cmp    $0x2,%cl
    cb23:	0f 84 77 0a 00 00    	je     d5a0 <f0+0x2890>
    cb29:	80 f9 01             	cmp    $0x1,%cl
    cb2c:	75 29                	jne    cb57 <f0+0x1e47>
    cb2e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb31:	0f b7 c0             	movzwl %ax,%eax
    cb34:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb37:	48 0f af c1          	imul   %rcx,%rax
    cb3b:	48 c1 e8 20          	shr    $0x20,%rax
    cb3f:	48 39 d0             	cmp    %rdx,%rax
    cb42:	73 13                	jae    cb57 <f0+0x1e47>
    cb44:	49 01 c4             	add    %rax,%r12
    cb47:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb4c:	0f 84 e7 0d 00 00    	je     d939 <f0+0x2c29>
    cb52:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb57:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb5e:	00 f0 3f 
    cb61:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    cb68:	00 
    cb69:	bf 01 00 00 00       	mov    $0x1,%edi
    cb6e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    cb75:	00 
    cb76:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    cb7d:	00 
    cb7e:	e8 2d 92 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cb83:	48 8b 15 0e 80 01 00 	mov    0x1800e(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cb8a:	49 89 c5             	mov    %rax,%r13
    cb8d:	48 2b 05 dc 7f 01 00 	sub    0x17fdc(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cb94:	48 c1 e2 10          	shl    $0x10,%rdx
    cb98:	48 39 d0             	cmp    %rdx,%rax
    cb9b:	73 59                	jae    cbf6 <f0+0x1ee6>
    cb9d:	48 89 c2             	mov    %rax,%rdx
    cba0:	48 c1 ea 10          	shr    $0x10,%rdx
    cba4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cba8:	48 8b 15 09 80 01 00 	mov    0x18009(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cbaf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbb3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbb7:	4d 85 e4             	test   %r12,%r12
    cbba:	74 3a                	je     cbf6 <f0+0x1ee6>
    cbbc:	0f b6 0a             	movzbl (%rdx),%ecx
    cbbf:	80 f9 02             	cmp    $0x2,%cl
    cbc2:	0f 84 38 0c 00 00    	je     d800 <f0+0x2af0>
    cbc8:	80 f9 01             	cmp    $0x1,%cl
    cbcb:	75 29                	jne    cbf6 <f0+0x1ee6>
    cbcd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbd0:	0f b7 c0             	movzwl %ax,%eax
    cbd3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbd6:	48 0f af c1          	imul   %rcx,%rax
    cbda:	48 c1 e8 20          	shr    $0x20,%rax
    cbde:	48 39 d0             	cmp    %rdx,%rax
    cbe1:	73 13                	jae    cbf6 <f0+0x1ee6>
    cbe3:	49 01 c4             	add    %rax,%r12
    cbe6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cbeb:	0f 84 55 0d 00 00    	je     d946 <f0+0x2c36>
    cbf1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbf6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbfd:	33 f3 bf 
    cc00:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    cc07:	00 
    cc08:	bf 01 00 00 00       	mov    $0x1,%edi
    cc0d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    cc14:	00 
    cc15:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    cc1c:	00 
    cc1d:	e8 8e 91 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cc22:	48 8b 15 6f 7f 01 00 	mov    0x17f6f(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cc29:	49 89 c5             	mov    %rax,%r13
    cc2c:	48 2b 05 3d 7f 01 00 	sub    0x17f3d(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cc33:	48 c1 e2 10          	shl    $0x10,%rdx
    cc37:	48 39 d0             	cmp    %rdx,%rax
    cc3a:	73 59                	jae    cc95 <f0+0x1f85>
    cc3c:	48 89 c2             	mov    %rax,%rdx
    cc3f:	48 c1 ea 10          	shr    $0x10,%rdx
    cc43:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc47:	48 8b 15 6a 7f 01 00 	mov    0x17f6a(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cc4e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc52:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc56:	4d 85 e4             	test   %r12,%r12
    cc59:	74 3a                	je     cc95 <f0+0x1f85>
    cc5b:	0f b6 0a             	movzbl (%rdx),%ecx
    cc5e:	80 f9 02             	cmp    $0x2,%cl
    cc61:	0f 84 89 0b 00 00    	je     d7f0 <f0+0x2ae0>
    cc67:	80 f9 01             	cmp    $0x1,%cl
    cc6a:	75 29                	jne    cc95 <f0+0x1f85>
    cc6c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc6f:	0f b7 c0             	movzwl %ax,%eax
    cc72:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc75:	48 0f af c1          	imul   %rcx,%rax
    cc79:	48 c1 e8 20          	shr    $0x20,%rax
    cc7d:	48 39 d0             	cmp    %rdx,%rax
    cc80:	73 13                	jae    cc95 <f0+0x1f85>
    cc82:	49 01 c4             	add    %rax,%r12
    cc85:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc8a:	0f 84 c3 0c 00 00    	je     d953 <f0+0x2c43>
    cc90:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc95:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc9c:	00 f0 3f 
    cc9f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    cca6:	00 
    cca7:	bf 01 00 00 00       	mov    $0x1,%edi
    ccac:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    ccb3:	00 
    ccb4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    ccbb:	00 
    ccbc:	e8 ef 90 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ccc1:	48 8b 15 d0 7e 01 00 	mov    0x17ed0(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ccc8:	49 89 c5             	mov    %rax,%r13
    cccb:	48 2b 05 9e 7e 01 00 	sub    0x17e9e(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ccd2:	48 c1 e2 10          	shl    $0x10,%rdx
    ccd6:	48 39 d0             	cmp    %rdx,%rax
    ccd9:	73 59                	jae    cd34 <f0+0x2024>
    ccdb:	48 89 c2             	mov    %rax,%rdx
    ccde:	48 c1 ea 10          	shr    $0x10,%rdx
    cce2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cce6:	48 8b 15 cb 7e 01 00 	mov    0x17ecb(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cced:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccf1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccf5:	4d 85 e4             	test   %r12,%r12
    ccf8:	74 3a                	je     cd34 <f0+0x2024>
    ccfa:	0f b6 0a             	movzbl (%rdx),%ecx
    ccfd:	80 f9 02             	cmp    $0x2,%cl
    cd00:	0f 84 da 0a 00 00    	je     d7e0 <f0+0x2ad0>
    cd06:	80 f9 01             	cmp    $0x1,%cl
    cd09:	75 29                	jne    cd34 <f0+0x2024>
    cd0b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd0e:	0f b7 c0             	movzwl %ax,%eax
    cd11:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd14:	48 0f af c1          	imul   %rcx,%rax
    cd18:	48 c1 e8 20          	shr    $0x20,%rax
    cd1c:	48 39 d0             	cmp    %rdx,%rax
    cd1f:	73 13                	jae    cd34 <f0+0x2024>
    cd21:	49 01 c4             	add    %rax,%r12
    cd24:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd29:	0f 84 31 0c 00 00    	je     d960 <f0+0x2c50>
    cd2f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd34:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd3b:	33 f3 bf 
    cd3e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    cd45:	00 
    cd46:	bf 01 00 00 00       	mov    $0x1,%edi
    cd4b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    cd52:	00 
    cd53:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    cd5a:	00 
    cd5b:	e8 50 90 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cd60:	48 8b 15 31 7e 01 00 	mov    0x17e31(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cd67:	49 89 c5             	mov    %rax,%r13
    cd6a:	48 2b 05 ff 7d 01 00 	sub    0x17dff(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cd71:	48 c1 e2 10          	shl    $0x10,%rdx
    cd75:	48 39 d0             	cmp    %rdx,%rax
    cd78:	73 59                	jae    cdd3 <f0+0x20c3>
    cd7a:	48 89 c2             	mov    %rax,%rdx
    cd7d:	48 c1 ea 10          	shr    $0x10,%rdx
    cd81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd85:	48 8b 15 2c 7e 01 00 	mov    0x17e2c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cd8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd90:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd94:	4d 85 e4             	test   %r12,%r12
    cd97:	74 3a                	je     cdd3 <f0+0x20c3>
    cd99:	0f b6 0a             	movzbl (%rdx),%ecx
    cd9c:	80 f9 02             	cmp    $0x2,%cl
    cd9f:	0f 84 2b 0a 00 00    	je     d7d0 <f0+0x2ac0>
    cda5:	80 f9 01             	cmp    $0x1,%cl
    cda8:	75 29                	jne    cdd3 <f0+0x20c3>
    cdaa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdad:	0f b7 c0             	movzwl %ax,%eax
    cdb0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdb3:	48 0f af c1          	imul   %rcx,%rax
    cdb7:	48 c1 e8 20          	shr    $0x20,%rax
    cdbb:	48 39 d0             	cmp    %rdx,%rax
    cdbe:	73 13                	jae    cdd3 <f0+0x20c3>
    cdc0:	49 01 c4             	add    %rax,%r12
    cdc3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cdc8:	0f 84 9f 0b 00 00    	je     d96d <f0+0x2c5d>
    cdce:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdd3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdda:	00 f0 3f 
    cddd:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    cde4:	00 
    cde5:	bf 01 00 00 00       	mov    $0x1,%edi
    cdea:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    cdf1:	00 
    cdf2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    cdf9:	00 
    cdfa:	e8 b1 8f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cdff:	48 8b 15 92 7d 01 00 	mov    0x17d92(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ce06:	49 89 c5             	mov    %rax,%r13
    ce09:	48 2b 05 60 7d 01 00 	sub    0x17d60(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ce10:	48 c1 e2 10          	shl    $0x10,%rdx
    ce14:	48 39 d0             	cmp    %rdx,%rax
    ce17:	73 59                	jae    ce72 <f0+0x2162>
    ce19:	48 89 c2             	mov    %rax,%rdx
    ce1c:	48 c1 ea 10          	shr    $0x10,%rdx
    ce20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce24:	48 8b 15 8d 7d 01 00 	mov    0x17d8d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ce2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce2f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce33:	4d 85 e4             	test   %r12,%r12
    ce36:	74 3a                	je     ce72 <f0+0x2162>
    ce38:	0f b6 0a             	movzbl (%rdx),%ecx
    ce3b:	80 f9 02             	cmp    $0x2,%cl
    ce3e:	0f 84 7c 09 00 00    	je     d7c0 <f0+0x2ab0>
    ce44:	80 f9 01             	cmp    $0x1,%cl
    ce47:	75 29                	jne    ce72 <f0+0x2162>
    ce49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce4c:	0f b7 c0             	movzwl %ax,%eax
    ce4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce52:	48 0f af c1          	imul   %rcx,%rax
    ce56:	48 c1 e8 20          	shr    $0x20,%rax
    ce5a:	48 39 d0             	cmp    %rdx,%rax
    ce5d:	73 13                	jae    ce72 <f0+0x2162>
    ce5f:	49 01 c4             	add    %rax,%r12
    ce62:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce67:	0f 84 0d 0b 00 00    	je     d97a <f0+0x2c6a>
    ce6d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce72:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce79:	33 f3 bf 
    ce7c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    ce83:	00 
    ce84:	bf 01 00 00 00       	mov    $0x1,%edi
    ce89:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    ce90:	00 
    ce91:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    ce98:	00 
    ce99:	e8 12 8f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ce9e:	48 8b 15 f3 7c 01 00 	mov    0x17cf3(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cea5:	49 89 c5             	mov    %rax,%r13
    cea8:	48 2b 05 c1 7c 01 00 	sub    0x17cc1(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ceaf:	48 c1 e2 10          	shl    $0x10,%rdx
    ceb3:	48 39 d0             	cmp    %rdx,%rax
    ceb6:	73 59                	jae    cf11 <f0+0x2201>
    ceb8:	48 89 c2             	mov    %rax,%rdx
    cebb:	48 c1 ea 10          	shr    $0x10,%rdx
    cebf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cec3:	48 8b 15 ee 7c 01 00 	mov    0x17cee(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ceca:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cece:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ced2:	4d 85 e4             	test   %r12,%r12
    ced5:	74 3a                	je     cf11 <f0+0x2201>
    ced7:	0f b6 0a             	movzbl (%rdx),%ecx
    ceda:	80 f9 02             	cmp    $0x2,%cl
    cedd:	0f 84 cd 08 00 00    	je     d7b0 <f0+0x2aa0>
    cee3:	80 f9 01             	cmp    $0x1,%cl
    cee6:	75 29                	jne    cf11 <f0+0x2201>
    cee8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ceeb:	0f b7 c0             	movzwl %ax,%eax
    ceee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cef1:	48 0f af c1          	imul   %rcx,%rax
    cef5:	48 c1 e8 20          	shr    $0x20,%rax
    cef9:	48 39 d0             	cmp    %rdx,%rax
    cefc:	73 13                	jae    cf11 <f0+0x2201>
    cefe:	49 01 c4             	add    %rax,%r12
    cf01:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf06:	0f 84 7b 0a 00 00    	je     d987 <f0+0x2c77>
    cf0c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf11:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf18:	00 f0 3f 
    cf1b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    cf22:	00 
    cf23:	bf 01 00 00 00       	mov    $0x1,%edi
    cf28:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    cf2f:	00 
    cf30:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    cf37:	00 
    cf38:	e8 73 8e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cf3d:	48 8b 15 54 7c 01 00 	mov    0x17c54(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cf44:	49 89 c5             	mov    %rax,%r13
    cf47:	48 2b 05 22 7c 01 00 	sub    0x17c22(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cf4e:	48 c1 e2 10          	shl    $0x10,%rdx
    cf52:	48 39 d0             	cmp    %rdx,%rax
    cf55:	73 59                	jae    cfb0 <f0+0x22a0>
    cf57:	48 89 c2             	mov    %rax,%rdx
    cf5a:	48 c1 ea 10          	shr    $0x10,%rdx
    cf5e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf62:	48 8b 15 4f 7c 01 00 	mov    0x17c4f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cf69:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf6d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf71:	4d 85 e4             	test   %r12,%r12
    cf74:	74 3a                	je     cfb0 <f0+0x22a0>
    cf76:	0f b6 0a             	movzbl (%rdx),%ecx
    cf79:	80 f9 02             	cmp    $0x2,%cl
    cf7c:	0f 84 1e 08 00 00    	je     d7a0 <f0+0x2a90>
    cf82:	80 f9 01             	cmp    $0x1,%cl
    cf85:	75 29                	jne    cfb0 <f0+0x22a0>
    cf87:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf8a:	0f b7 c0             	movzwl %ax,%eax
    cf8d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf90:	48 0f af c1          	imul   %rcx,%rax
    cf94:	48 c1 e8 20          	shr    $0x20,%rax
    cf98:	48 39 d0             	cmp    %rdx,%rax
    cf9b:	73 13                	jae    cfb0 <f0+0x22a0>
    cf9d:	49 01 c4             	add    %rax,%r12
    cfa0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfa5:	0f 84 e9 09 00 00    	je     d994 <f0+0x2c84>
    cfab:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfb0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cfb7:	33 f3 bf 
    cfba:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    cfc1:	00 
    cfc2:	bf 01 00 00 00       	mov    $0x1,%edi
    cfc7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    cfce:	00 
    cfcf:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    cfd6:	00 
    cfd7:	e8 d4 8d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cfdc:	48 8b 15 b5 7b 01 00 	mov    0x17bb5(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cfe3:	49 89 c5             	mov    %rax,%r13
    cfe6:	48 2b 05 83 7b 01 00 	sub    0x17b83(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cfed:	48 c1 e2 10          	shl    $0x10,%rdx
    cff1:	48 39 d0             	cmp    %rdx,%rax
    cff4:	73 59                	jae    d04f <f0+0x233f>
    cff6:	48 89 c2             	mov    %rax,%rdx
    cff9:	48 c1 ea 10          	shr    $0x10,%rdx
    cffd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d001:	48 8b 15 b0 7b 01 00 	mov    0x17bb0(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d008:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d00c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d010:	4d 85 e4             	test   %r12,%r12
    d013:	74 3a                	je     d04f <f0+0x233f>
    d015:	0f b6 0a             	movzbl (%rdx),%ecx
    d018:	80 f9 02             	cmp    $0x2,%cl
    d01b:	0f 84 6f 07 00 00    	je     d790 <f0+0x2a80>
    d021:	80 f9 01             	cmp    $0x1,%cl
    d024:	75 29                	jne    d04f <f0+0x233f>
    d026:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d029:	0f b7 c0             	movzwl %ax,%eax
    d02c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d02f:	48 0f af c1          	imul   %rcx,%rax
    d033:	48 c1 e8 20          	shr    $0x20,%rax
    d037:	48 39 d0             	cmp    %rdx,%rax
    d03a:	73 13                	jae    d04f <f0+0x233f>
    d03c:	49 01 c4             	add    %rax,%r12
    d03f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d044:	0f 84 57 09 00 00    	je     d9a1 <f0+0x2c91>
    d04a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d04f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d056:	00 f0 3f 
    d059:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d060:	00 
    d061:	bf 01 00 00 00       	mov    $0x1,%edi
    d066:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d06d:	00 
    d06e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d075:	00 
    d076:	e8 35 8d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d07b:	48 8b 15 16 7b 01 00 	mov    0x17b16(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d082:	49 89 c5             	mov    %rax,%r13
    d085:	48 2b 05 e4 7a 01 00 	sub    0x17ae4(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d08c:	48 c1 e2 10          	shl    $0x10,%rdx
    d090:	48 39 d0             	cmp    %rdx,%rax
    d093:	73 59                	jae    d0ee <f0+0x23de>
    d095:	48 89 c2             	mov    %rax,%rdx
    d098:	48 c1 ea 10          	shr    $0x10,%rdx
    d09c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0a0:	48 8b 15 11 7b 01 00 	mov    0x17b11(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d0a7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0ab:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0af:	4d 85 e4             	test   %r12,%r12
    d0b2:	74 3a                	je     d0ee <f0+0x23de>
    d0b4:	0f b6 0a             	movzbl (%rdx),%ecx
    d0b7:	80 f9 02             	cmp    $0x2,%cl
    d0ba:	0f 84 c0 06 00 00    	je     d780 <f0+0x2a70>
    d0c0:	80 f9 01             	cmp    $0x1,%cl
    d0c3:	75 29                	jne    d0ee <f0+0x23de>
    d0c5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0c8:	0f b7 c0             	movzwl %ax,%eax
    d0cb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0ce:	48 0f af c1          	imul   %rcx,%rax
    d0d2:	48 c1 e8 20          	shr    $0x20,%rax
    d0d6:	48 39 d0             	cmp    %rdx,%rax
    d0d9:	73 13                	jae    d0ee <f0+0x23de>
    d0db:	49 01 c4             	add    %rax,%r12
    d0de:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0e3:	0f 84 c5 08 00 00    	je     d9ae <f0+0x2c9e>
    d0e9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0ee:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0f5:	33 f3 bf 
    d0f8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d0ff:	00 
    d100:	bf 01 00 00 00       	mov    $0x1,%edi
    d105:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d10c:	00 
    d10d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d114:	00 
    d115:	e8 96 8c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d11a:	48 8b 15 77 7a 01 00 	mov    0x17a77(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d121:	49 89 c5             	mov    %rax,%r13
    d124:	48 2b 05 45 7a 01 00 	sub    0x17a45(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d12b:	48 c1 e2 10          	shl    $0x10,%rdx
    d12f:	48 39 d0             	cmp    %rdx,%rax
    d132:	73 59                	jae    d18d <f0+0x247d>
    d134:	48 89 c2             	mov    %rax,%rdx
    d137:	48 c1 ea 10          	shr    $0x10,%rdx
    d13b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d13f:	48 8b 15 72 7a 01 00 	mov    0x17a72(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d146:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d14a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d14e:	4d 85 e4             	test   %r12,%r12
    d151:	74 3a                	je     d18d <f0+0x247d>
    d153:	0f b6 0a             	movzbl (%rdx),%ecx
    d156:	80 f9 02             	cmp    $0x2,%cl
    d159:	0f 84 11 06 00 00    	je     d770 <f0+0x2a60>
    d15f:	80 f9 01             	cmp    $0x1,%cl
    d162:	75 29                	jne    d18d <f0+0x247d>
    d164:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d167:	0f b7 c0             	movzwl %ax,%eax
    d16a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d16d:	48 0f af c1          	imul   %rcx,%rax
    d171:	48 c1 e8 20          	shr    $0x20,%rax
    d175:	48 39 d0             	cmp    %rdx,%rax
    d178:	73 13                	jae    d18d <f0+0x247d>
    d17a:	49 01 c4             	add    %rax,%r12
    d17d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d182:	0f 84 33 08 00 00    	je     d9bb <f0+0x2cab>
    d188:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d18d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d194:	00 f0 3f 
    d197:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d19e:	00 
    d19f:	bf 01 00 00 00       	mov    $0x1,%edi
    d1a4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d1ab:	00 
    d1ac:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d1b3:	00 
    d1b4:	e8 f7 8b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d1b9:	48 8b 15 d8 79 01 00 	mov    0x179d8(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d1c0:	49 89 c5             	mov    %rax,%r13
    d1c3:	48 2b 05 a6 79 01 00 	sub    0x179a6(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d1ca:	48 c1 e2 10          	shl    $0x10,%rdx
    d1ce:	48 39 d0             	cmp    %rdx,%rax
    d1d1:	73 59                	jae    d22c <f0+0x251c>
    d1d3:	48 89 c2             	mov    %rax,%rdx
    d1d6:	48 c1 ea 10          	shr    $0x10,%rdx
    d1da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1de:	48 8b 15 d3 79 01 00 	mov    0x179d3(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d1e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1e9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1ed:	4d 85 e4             	test   %r12,%r12
    d1f0:	74 3a                	je     d22c <f0+0x251c>
    d1f2:	0f b6 0a             	movzbl (%rdx),%ecx
    d1f5:	80 f9 02             	cmp    $0x2,%cl
    d1f8:	0f 84 62 05 00 00    	je     d760 <f0+0x2a50>
    d1fe:	80 f9 01             	cmp    $0x1,%cl
    d201:	75 29                	jne    d22c <f0+0x251c>
    d203:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d206:	0f b7 c0             	movzwl %ax,%eax
    d209:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d20c:	48 0f af c1          	imul   %rcx,%rax
    d210:	48 c1 e8 20          	shr    $0x20,%rax
    d214:	48 39 d0             	cmp    %rdx,%rax
    d217:	73 13                	jae    d22c <f0+0x251c>
    d219:	49 01 c4             	add    %rax,%r12
    d21c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d221:	0f 84 a1 07 00 00    	je     d9c8 <f0+0x2cb8>
    d227:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d22c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d233:	33 f3 bf 
    d236:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d23d:	00 
    d23e:	bf 01 00 00 00       	mov    $0x1,%edi
    d243:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d24a:	00 
    d24b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d252:	00 
    d253:	e8 58 8b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d258:	48 8b 15 39 79 01 00 	mov    0x17939(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d25f:	49 89 c5             	mov    %rax,%r13
    d262:	48 2b 05 07 79 01 00 	sub    0x17907(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d269:	48 c1 e2 10          	shl    $0x10,%rdx
    d26d:	48 39 d0             	cmp    %rdx,%rax
    d270:	73 59                	jae    d2cb <f0+0x25bb>
    d272:	48 89 c2             	mov    %rax,%rdx
    d275:	48 c1 ea 10          	shr    $0x10,%rdx
    d279:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d27d:	48 8b 15 34 79 01 00 	mov    0x17934(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d284:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d288:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d28c:	4d 85 e4             	test   %r12,%r12
    d28f:	74 3a                	je     d2cb <f0+0x25bb>
    d291:	0f b6 0a             	movzbl (%rdx),%ecx
    d294:	80 f9 02             	cmp    $0x2,%cl
    d297:	0f 84 b3 04 00 00    	je     d750 <f0+0x2a40>
    d29d:	80 f9 01             	cmp    $0x1,%cl
    d2a0:	75 29                	jne    d2cb <f0+0x25bb>
    d2a2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2a5:	0f b7 c0             	movzwl %ax,%eax
    d2a8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2ab:	48 0f af c1          	imul   %rcx,%rax
    d2af:	48 c1 e8 20          	shr    $0x20,%rax
    d2b3:	48 39 d0             	cmp    %rdx,%rax
    d2b6:	73 13                	jae    d2cb <f0+0x25bb>
    d2b8:	49 01 c4             	add    %rax,%r12
    d2bb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2c0:	0f 84 0f 07 00 00    	je     d9d5 <f0+0x2cc5>
    d2c6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2cb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2d2:	00 f0 3f 
    d2d5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d2dc:	00 
    d2dd:	bf 01 00 00 00       	mov    $0x1,%edi
    d2e2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d2e9:	00 
    d2ea:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d2f1:	00 
    d2f2:	e8 b9 8a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d2f7:	48 8b 15 9a 78 01 00 	mov    0x1789a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d2fe:	49 89 c5             	mov    %rax,%r13
    d301:	48 2b 05 68 78 01 00 	sub    0x17868(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d308:	48 c1 e2 10          	shl    $0x10,%rdx
    d30c:	48 39 d0             	cmp    %rdx,%rax
    d30f:	73 59                	jae    d36a <f0+0x265a>
    d311:	48 89 c2             	mov    %rax,%rdx
    d314:	48 c1 ea 10          	shr    $0x10,%rdx
    d318:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d31c:	48 8b 15 95 78 01 00 	mov    0x17895(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d323:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d327:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d32b:	4d 85 e4             	test   %r12,%r12
    d32e:	74 3a                	je     d36a <f0+0x265a>
    d330:	0f b6 0a             	movzbl (%rdx),%ecx
    d333:	80 f9 02             	cmp    $0x2,%cl
    d336:	0f 84 04 04 00 00    	je     d740 <f0+0x2a30>
    d33c:	80 f9 01             	cmp    $0x1,%cl
    d33f:	75 29                	jne    d36a <f0+0x265a>
    d341:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d344:	0f b7 c0             	movzwl %ax,%eax
    d347:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d34a:	48 0f af c1          	imul   %rcx,%rax
    d34e:	48 c1 e8 20          	shr    $0x20,%rax
    d352:	48 39 d0             	cmp    %rdx,%rax
    d355:	73 13                	jae    d36a <f0+0x265a>
    d357:	49 01 c4             	add    %rax,%r12
    d35a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d35f:	0f 84 7d 06 00 00    	je     d9e2 <f0+0x2cd2>
    d365:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d36a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d371:	33 f3 bf 
    d374:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d37b:	00 
    d37c:	bf 01 00 00 00       	mov    $0x1,%edi
    d381:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d388:	00 
    d389:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d390:	00 
    d391:	e8 1a 8a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d396:	48 8b 15 fb 77 01 00 	mov    0x177fb(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d39d:	49 89 c5             	mov    %rax,%r13
    d3a0:	48 2b 05 c9 77 01 00 	sub    0x177c9(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d3a7:	48 c1 e2 10          	shl    $0x10,%rdx
    d3ab:	48 39 d0             	cmp    %rdx,%rax
    d3ae:	73 59                	jae    d409 <f0+0x26f9>
    d3b0:	48 89 c2             	mov    %rax,%rdx
    d3b3:	48 c1 ea 10          	shr    $0x10,%rdx
    d3b7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3bb:	48 8b 15 f6 77 01 00 	mov    0x177f6(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d3c2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3c6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3ca:	4d 85 e4             	test   %r12,%r12
    d3cd:	74 3a                	je     d409 <f0+0x26f9>
    d3cf:	0f b6 0a             	movzbl (%rdx),%ecx
    d3d2:	80 f9 02             	cmp    $0x2,%cl
    d3d5:	0f 84 55 03 00 00    	je     d730 <f0+0x2a20>
    d3db:	80 f9 01             	cmp    $0x1,%cl
    d3de:	75 29                	jne    d409 <f0+0x26f9>
    d3e0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3e3:	0f b7 c0             	movzwl %ax,%eax
    d3e6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3e9:	48 0f af c1          	imul   %rcx,%rax
    d3ed:	48 c1 e8 20          	shr    $0x20,%rax
    d3f1:	48 39 d0             	cmp    %rdx,%rax
    d3f4:	73 13                	jae    d409 <f0+0x26f9>
    d3f6:	49 01 c4             	add    %rax,%r12
    d3f9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3fe:	0f 84 eb 05 00 00    	je     d9ef <f0+0x2cdf>
    d404:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d409:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d410:	00 f0 3f 
    d413:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d41a:	00 
    d41b:	bf 01 00 00 00       	mov    $0x1,%edi
    d420:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d427:	00 
    d428:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d42f:	00 
    d430:	e8 7b 89 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d435:	48 8b 15 5c 77 01 00 	mov    0x1775c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d43c:	49 89 c5             	mov    %rax,%r13
    d43f:	48 2b 05 2a 77 01 00 	sub    0x1772a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d446:	48 c1 e2 10          	shl    $0x10,%rdx
    d44a:	48 39 d0             	cmp    %rdx,%rax
    d44d:	73 59                	jae    d4a8 <f0+0x2798>
    d44f:	48 89 c2             	mov    %rax,%rdx
    d452:	48 c1 ea 10          	shr    $0x10,%rdx
    d456:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d45a:	48 8b 15 57 77 01 00 	mov    0x17757(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d461:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d465:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d469:	4d 85 e4             	test   %r12,%r12
    d46c:	74 3a                	je     d4a8 <f0+0x2798>
    d46e:	0f b6 0a             	movzbl (%rdx),%ecx
    d471:	80 f9 02             	cmp    $0x2,%cl
    d474:	0f 84 a6 02 00 00    	je     d720 <f0+0x2a10>
    d47a:	80 f9 01             	cmp    $0x1,%cl
    d47d:	75 29                	jne    d4a8 <f0+0x2798>
    d47f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d482:	0f b7 c0             	movzwl %ax,%eax
    d485:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d488:	48 0f af c1          	imul   %rcx,%rax
    d48c:	48 c1 e8 20          	shr    $0x20,%rax
    d490:	48 39 d0             	cmp    %rdx,%rax
    d493:	73 13                	jae    d4a8 <f0+0x2798>
    d495:	49 01 c4             	add    %rax,%r12
    d498:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d49d:	0f 84 59 05 00 00    	je     d9fc <f0+0x2cec>
    d4a3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4a8:	48 89 ee             	mov    %rbp,%rsi
    d4ab:	bf 01 00 00 00       	mov    $0x1,%edi
    d4b0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d4b7:	33 f3 bf 
    d4ba:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d4c1:	00 
    d4c2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d4c9:	00 
    d4ca:	e8 e1 88 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d4cf:	48 8b 15 c2 76 01 00 	mov    0x176c2(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d4d6:	48 89 c5             	mov    %rax,%rbp
    d4d9:	48 2b 05 90 76 01 00 	sub    0x17690(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d4e0:	48 c1 e2 10          	shl    $0x10,%rdx
    d4e4:	48 39 d0             	cmp    %rdx,%rax
    d4e7:	73 59                	jae    d542 <f0+0x2832>
    d4e9:	48 89 c2             	mov    %rax,%rdx
    d4ec:	48 c1 ea 10          	shr    $0x10,%rdx
    d4f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4f4:	48 8b 15 bd 76 01 00 	mov    0x176bd(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d4fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4ff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d503:	4d 85 e4             	test   %r12,%r12
    d506:	74 3a                	je     d542 <f0+0x2832>
    d508:	0f b6 0a             	movzbl (%rdx),%ecx
    d50b:	80 f9 02             	cmp    $0x2,%cl
    d50e:	0f 84 fc 01 00 00    	je     d710 <f0+0x2a00>
    d514:	80 f9 01             	cmp    $0x1,%cl
    d517:	75 29                	jne    d542 <f0+0x2832>
    d519:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d51c:	0f b7 c0             	movzwl %ax,%eax
    d51f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d522:	48 0f af c1          	imul   %rcx,%rax
    d526:	48 c1 e8 20          	shr    $0x20,%rax
    d52a:	48 39 d0             	cmp    %rdx,%rax
    d52d:	73 13                	jae    d542 <f0+0x2832>
    d52f:	49 01 c4             	add    %rax,%r12
    d532:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d537:	0f 84 d1 02 00 00    	je     d80e <f0+0x2afe>
    d53d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d542:	48 89 de             	mov    %rbx,%rsi
    d545:	48 89 ef             	mov    %rbp,%rdi
    d548:	e8 13 bf ff ff       	call   9460 <fwp_hof0.constprop.0>
    d54d:	48 89 ef             	mov    %rbp,%rdi
    d550:	e8 8b a3 ff ff       	call   78e0 <fwp_drop0>
    d555:	48 89 df             	mov    %rbx,%rdi
    d558:	e8 83 a3 ff ff       	call   78e0 <fwp_drop0>
    d55d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d564:	00 
    d565:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d56c:	00 00 
    d56e:	0f 85 95 04 00 00    	jne    da09 <f0+0x2cf9>
    d574:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d57b:	31 c0                	xor    %eax,%eax
    d57d:	5b                   	pop    %rbx
    d57e:	5d                   	pop    %rbp
    d57f:	41 5c                	pop    %r12
    d581:	41 5d                	pop    %r13
    d583:	41 5e                	pop    %r14
    d585:	c3                   	ret
    d586:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d58d:	00 00 00 
    d590:	4c 89 ef             	mov    %r13,%rdi
    d593:	e8 b8 7f ff ff       	call   5550 <fwp_rc_forget_slot>
    d598:	e9 2c d8 ff ff       	jmp    adc9 <f0+0xb9>
    d59d:	0f 1f 00             	nopl   (%rax)
    d5a0:	66 85 c0             	test   %ax,%ax
    d5a3:	0f 85 ae f5 ff ff    	jne    cb57 <f0+0x1e47>
    d5a9:	e9 99 f5 ff ff       	jmp    cb47 <f0+0x1e37>
    d5ae:	66 90                	xchg   %ax,%ax
    d5b0:	66 85 c0             	test   %ax,%ax
    d5b3:	0f 85 ff f4 ff ff    	jne    cab8 <f0+0x1da8>
    d5b9:	e9 ea f4 ff ff       	jmp    caa8 <f0+0x1d98>
    d5be:	66 90                	xchg   %ax,%ax
    d5c0:	66 85 c0             	test   %ax,%ax
    d5c3:	0f 85 50 f4 ff ff    	jne    ca19 <f0+0x1d09>
    d5c9:	e9 3b f4 ff ff       	jmp    ca09 <f0+0x1cf9>
    d5ce:	66 90                	xchg   %ax,%ax
    d5d0:	66 85 c0             	test   %ax,%ax
    d5d3:	0f 85 a1 f3 ff ff    	jne    c97a <f0+0x1c6a>
    d5d9:	e9 8c f3 ff ff       	jmp    c96a <f0+0x1c5a>
    d5de:	66 90                	xchg   %ax,%ax
    d5e0:	66 85 c0             	test   %ax,%ax
    d5e3:	0f 85 f2 f2 ff ff    	jne    c8db <f0+0x1bcb>
    d5e9:	e9 dd f2 ff ff       	jmp    c8cb <f0+0x1bbb>
    d5ee:	66 90                	xchg   %ax,%ax
    d5f0:	66 85 c0             	test   %ax,%ax
    d5f3:	0f 85 43 f2 ff ff    	jne    c83c <f0+0x1b2c>
    d5f9:	e9 2e f2 ff ff       	jmp    c82c <f0+0x1b1c>
    d5fe:	66 90                	xchg   %ax,%ax
    d600:	66 85 c0             	test   %ax,%ax
    d603:	0f 85 94 f1 ff ff    	jne    c79d <f0+0x1a8d>
    d609:	e9 7f f1 ff ff       	jmp    c78d <f0+0x1a7d>
    d60e:	66 90                	xchg   %ax,%ax
    d610:	66 85 c0             	test   %ax,%ax
    d613:	0f 85 e5 f0 ff ff    	jne    c6fe <f0+0x19ee>
    d619:	e9 d0 f0 ff ff       	jmp    c6ee <f0+0x19de>
    d61e:	66 90                	xchg   %ax,%ax
    d620:	66 85 c0             	test   %ax,%ax
    d623:	0f 85 fd d9 ff ff    	jne    b026 <f0+0x316>
    d629:	e9 e8 d9 ff ff       	jmp    b016 <f0+0x306>
    d62e:	66 90                	xchg   %ax,%ax
    d630:	66 85 c0             	test   %ax,%ax
    d633:	0f 85 57 d9 ff ff    	jne    af90 <f0+0x280>
    d639:	e9 42 d9 ff ff       	jmp    af80 <f0+0x270>
    d63e:	66 90                	xchg   %ax,%ax
    d640:	66 85 c0             	test   %ax,%ax
    d643:	0f 85 b1 d8 ff ff    	jne    aefa <f0+0x1ea>
    d649:	e9 9c d8 ff ff       	jmp    aeea <f0+0x1da>
    d64e:	66 90                	xchg   %ax,%ax
    d650:	66 85 c0             	test   %ax,%ax
    d653:	0f 85 0e eb ff ff    	jne    c167 <f0+0x1457>
    d659:	e9 f9 ea ff ff       	jmp    c157 <f0+0x1447>
    d65e:	66 90                	xchg   %ax,%ax
    d660:	66 85 c0             	test   %ax,%ax
    d663:	0f 85 5f ea ff ff    	jne    c0c8 <f0+0x13b8>
    d669:	e9 4a ea ff ff       	jmp    c0b8 <f0+0x13a8>
    d66e:	66 90                	xchg   %ax,%ax
    d670:	66 85 c0             	test   %ax,%ax
    d673:	0f 85 e2 da ff ff    	jne    b15b <f0+0x44b>
    d679:	e9 cd da ff ff       	jmp    b14b <f0+0x43b>
    d67e:	66 90                	xchg   %ax,%ax
    d680:	66 85 c0             	test   %ax,%ax
    d683:	0f 85 33 da ff ff    	jne    b0bc <f0+0x3ac>
    d689:	e9 1e da ff ff       	jmp    b0ac <f0+0x39c>
    d68e:	66 90                	xchg   %ax,%ax
    d690:	66 85 c0             	test   %ax,%ax
    d693:	0f 85 c6 ef ff ff    	jne    c65f <f0+0x194f>
    d699:	e9 b1 ef ff ff       	jmp    c64f <f0+0x193f>
    d69e:	66 90                	xchg   %ax,%ax
    d6a0:	66 85 c0             	test   %ax,%ax
    d6a3:	0f 85 17 ef ff ff    	jne    c5c0 <f0+0x18b0>
    d6a9:	e9 02 ef ff ff       	jmp    c5b0 <f0+0x18a0>
    d6ae:	66 90                	xchg   %ax,%ax
    d6b0:	66 85 c0             	test   %ax,%ax
    d6b3:	0f 85 68 ee ff ff    	jne    c521 <f0+0x1811>
    d6b9:	e9 53 ee ff ff       	jmp    c511 <f0+0x1801>
    d6be:	66 90                	xchg   %ax,%ax
    d6c0:	66 85 c0             	test   %ax,%ax
    d6c3:	0f 85 b9 ed ff ff    	jne    c482 <f0+0x1772>
    d6c9:	e9 a4 ed ff ff       	jmp    c472 <f0+0x1762>
    d6ce:	66 90                	xchg   %ax,%ax
    d6d0:	66 85 c0             	test   %ax,%ax
    d6d3:	0f 85 0a ed ff ff    	jne    c3e3 <f0+0x16d3>
    d6d9:	e9 f5 ec ff ff       	jmp    c3d3 <f0+0x16c3>
    d6de:	66 90                	xchg   %ax,%ax
    d6e0:	66 85 c0             	test   %ax,%ax
    d6e3:	0f 85 5b ec ff ff    	jne    c344 <f0+0x1634>
    d6e9:	e9 46 ec ff ff       	jmp    c334 <f0+0x1624>
    d6ee:	66 90                	xchg   %ax,%ax
    d6f0:	66 85 c0             	test   %ax,%ax
    d6f3:	0f 85 ac eb ff ff    	jne    c2a5 <f0+0x1595>
    d6f9:	e9 97 eb ff ff       	jmp    c295 <f0+0x1585>
    d6fe:	66 90                	xchg   %ax,%ax
    d700:	66 85 c0             	test   %ax,%ax
    d703:	0f 85 fd ea ff ff    	jne    c206 <f0+0x14f6>
    d709:	e9 e8 ea ff ff       	jmp    c1f6 <f0+0x14e6>
    d70e:	66 90                	xchg   %ax,%ax
    d710:	66 85 c0             	test   %ax,%ax
    d713:	0f 85 29 fe ff ff    	jne    d542 <f0+0x2832>
    d719:	e9 14 fe ff ff       	jmp    d532 <f0+0x2822>
    d71e:	66 90                	xchg   %ax,%ax
    d720:	66 85 c0             	test   %ax,%ax
    d723:	0f 85 7f fd ff ff    	jne    d4a8 <f0+0x2798>
    d729:	e9 6a fd ff ff       	jmp    d498 <f0+0x2788>
    d72e:	66 90                	xchg   %ax,%ax
    d730:	66 85 c0             	test   %ax,%ax
    d733:	0f 85 d0 fc ff ff    	jne    d409 <f0+0x26f9>
    d739:	e9 bb fc ff ff       	jmp    d3f9 <f0+0x26e9>
    d73e:	66 90                	xchg   %ax,%ax
    d740:	66 85 c0             	test   %ax,%ax
    d743:	0f 85 21 fc ff ff    	jne    d36a <f0+0x265a>
    d749:	e9 0c fc ff ff       	jmp    d35a <f0+0x264a>
    d74e:	66 90                	xchg   %ax,%ax
    d750:	66 85 c0             	test   %ax,%ax
    d753:	0f 85 72 fb ff ff    	jne    d2cb <f0+0x25bb>
    d759:	e9 5d fb ff ff       	jmp    d2bb <f0+0x25ab>
    d75e:	66 90                	xchg   %ax,%ax
    d760:	66 85 c0             	test   %ax,%ax
    d763:	0f 85 c3 fa ff ff    	jne    d22c <f0+0x251c>
    d769:	e9 ae fa ff ff       	jmp    d21c <f0+0x250c>
    d76e:	66 90                	xchg   %ax,%ax
    d770:	66 85 c0             	test   %ax,%ax
    d773:	0f 85 14 fa ff ff    	jne    d18d <f0+0x247d>
    d779:	e9 ff f9 ff ff       	jmp    d17d <f0+0x246d>
    d77e:	66 90                	xchg   %ax,%ax
    d780:	66 85 c0             	test   %ax,%ax
    d783:	0f 85 65 f9 ff ff    	jne    d0ee <f0+0x23de>
    d789:	e9 50 f9 ff ff       	jmp    d0de <f0+0x23ce>
    d78e:	66 90                	xchg   %ax,%ax
    d790:	66 85 c0             	test   %ax,%ax
    d793:	0f 85 b6 f8 ff ff    	jne    d04f <f0+0x233f>
    d799:	e9 a1 f8 ff ff       	jmp    d03f <f0+0x232f>
    d79e:	66 90                	xchg   %ax,%ax
    d7a0:	66 85 c0             	test   %ax,%ax
    d7a3:	0f 85 07 f8 ff ff    	jne    cfb0 <f0+0x22a0>
    d7a9:	e9 f2 f7 ff ff       	jmp    cfa0 <f0+0x2290>
    d7ae:	66 90                	xchg   %ax,%ax
    d7b0:	66 85 c0             	test   %ax,%ax
    d7b3:	0f 85 58 f7 ff ff    	jne    cf11 <f0+0x2201>
    d7b9:	e9 43 f7 ff ff       	jmp    cf01 <f0+0x21f1>
    d7be:	66 90                	xchg   %ax,%ax
    d7c0:	66 85 c0             	test   %ax,%ax
    d7c3:	0f 85 a9 f6 ff ff    	jne    ce72 <f0+0x2162>
    d7c9:	e9 94 f6 ff ff       	jmp    ce62 <f0+0x2152>
    d7ce:	66 90                	xchg   %ax,%ax
    d7d0:	66 85 c0             	test   %ax,%ax
    d7d3:	0f 85 fa f5 ff ff    	jne    cdd3 <f0+0x20c3>
    d7d9:	e9 e5 f5 ff ff       	jmp    cdc3 <f0+0x20b3>
    d7de:	66 90                	xchg   %ax,%ax
    d7e0:	66 85 c0             	test   %ax,%ax
    d7e3:	0f 85 4b f5 ff ff    	jne    cd34 <f0+0x2024>
    d7e9:	e9 36 f5 ff ff       	jmp    cd24 <f0+0x2014>
    d7ee:	66 90                	xchg   %ax,%ax
    d7f0:	66 85 c0             	test   %ax,%ax
    d7f3:	0f 85 9c f4 ff ff    	jne    cc95 <f0+0x1f85>
    d7f9:	e9 87 f4 ff ff       	jmp    cc85 <f0+0x1f75>
    d7fe:	66 90                	xchg   %ax,%ax
    d800:	66 85 c0             	test   %ax,%ax
    d803:	0f 85 ed f3 ff ff    	jne    cbf6 <f0+0x1ee6>
    d809:	e9 d8 f3 ff ff       	jmp    cbe6 <f0+0x1ed6>
    d80e:	4c 89 e7             	mov    %r12,%rdi
    d811:	e8 3a 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d816:	e9 22 fd ff ff       	jmp    d53d <f0+0x282d>
    d81b:	4c 89 e7             	mov    %r12,%rdi
    d81e:	e8 2d 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d823:	e9 cd d6 ff ff       	jmp    aef5 <f0+0x1e5>
    d828:	4c 89 e7             	mov    %r12,%rdi
    d82b:	e8 20 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d830:	e9 56 d7 ff ff       	jmp    af8b <f0+0x27b>
    d835:	4c 89 e7             	mov    %r12,%rdi
    d838:	e8 13 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d83d:	e9 df d7 ff ff       	jmp    b021 <f0+0x311>
    d842:	4c 89 e7             	mov    %r12,%rdi
    d845:	e8 06 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d84a:	e9 68 d8 ff ff       	jmp    b0b7 <f0+0x3a7>
    d84f:	4c 89 e7             	mov    %r12,%rdi
    d852:	e8 f9 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d857:	e9 fa d8 ff ff       	jmp    b156 <f0+0x446>
    d85c:	4c 89 e7             	mov    %r12,%rdi
    d85f:	e8 ec 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d864:	e9 5a e8 ff ff       	jmp    c0c3 <f0+0x13b3>
    d869:	4c 89 e7             	mov    %r12,%rdi
    d86c:	e8 df 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d871:	e9 ec e8 ff ff       	jmp    c162 <f0+0x1452>
    d876:	4c 89 e7             	mov    %r12,%rdi
    d879:	e8 d2 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d87e:	e9 7e e9 ff ff       	jmp    c201 <f0+0x14f1>
    d883:	4c 89 e7             	mov    %r12,%rdi
    d886:	e8 c5 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d88b:	e9 10 ea ff ff       	jmp    c2a0 <f0+0x1590>
    d890:	4c 89 e7             	mov    %r12,%rdi
    d893:	e8 b8 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d898:	e9 a2 ea ff ff       	jmp    c33f <f0+0x162f>
    d89d:	4c 89 e7             	mov    %r12,%rdi
    d8a0:	e8 ab 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d8a5:	e9 34 eb ff ff       	jmp    c3de <f0+0x16ce>
    d8aa:	4c 89 e7             	mov    %r12,%rdi
    d8ad:	e8 9e 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d8b2:	e9 c6 eb ff ff       	jmp    c47d <f0+0x176d>
    d8b7:	4c 89 e7             	mov    %r12,%rdi
    d8ba:	e8 91 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d8bf:	e9 58 ec ff ff       	jmp    c51c <f0+0x180c>
    d8c4:	4c 89 e7             	mov    %r12,%rdi
    d8c7:	e8 84 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d8cc:	e9 ea ec ff ff       	jmp    c5bb <f0+0x18ab>
    d8d1:	4c 89 e7             	mov    %r12,%rdi
    d8d4:	e8 77 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d8d9:	e9 7c ed ff ff       	jmp    c65a <f0+0x194a>
    d8de:	4c 89 e7             	mov    %r12,%rdi
    d8e1:	e8 6a 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d8e6:	e9 0e ee ff ff       	jmp    c6f9 <f0+0x19e9>
    d8eb:	4c 89 e7             	mov    %r12,%rdi
    d8ee:	e8 5d 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d8f3:	e9 a0 ee ff ff       	jmp    c798 <f0+0x1a88>
    d8f8:	4c 89 e7             	mov    %r12,%rdi
    d8fb:	e8 50 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d900:	e9 32 ef ff ff       	jmp    c837 <f0+0x1b27>
    d905:	4c 89 e7             	mov    %r12,%rdi
    d908:	e8 43 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d90d:	e9 c4 ef ff ff       	jmp    c8d6 <f0+0x1bc6>
    d912:	4c 89 e7             	mov    %r12,%rdi
    d915:	e8 36 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d91a:	e9 56 f0 ff ff       	jmp    c975 <f0+0x1c65>
    d91f:	4c 89 e7             	mov    %r12,%rdi
    d922:	e8 29 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d927:	e9 e8 f0 ff ff       	jmp    ca14 <f0+0x1d04>
    d92c:	4c 89 e7             	mov    %r12,%rdi
    d92f:	e8 1c 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d934:	e9 7a f1 ff ff       	jmp    cab3 <f0+0x1da3>
    d939:	4c 89 e7             	mov    %r12,%rdi
    d93c:	e8 0f 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d941:	e9 0c f2 ff ff       	jmp    cb52 <f0+0x1e42>
    d946:	4c 89 e7             	mov    %r12,%rdi
    d949:	e8 02 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d94e:	e9 9e f2 ff ff       	jmp    cbf1 <f0+0x1ee1>
    d953:	4c 89 e7             	mov    %r12,%rdi
    d956:	e8 f5 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d95b:	e9 30 f3 ff ff       	jmp    cc90 <f0+0x1f80>
    d960:	4c 89 e7             	mov    %r12,%rdi
    d963:	e8 e8 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d968:	e9 c2 f3 ff ff       	jmp    cd2f <f0+0x201f>
    d96d:	4c 89 e7             	mov    %r12,%rdi
    d970:	e8 db 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d975:	e9 54 f4 ff ff       	jmp    cdce <f0+0x20be>
    d97a:	4c 89 e7             	mov    %r12,%rdi
    d97d:	e8 ce 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d982:	e9 e6 f4 ff ff       	jmp    ce6d <f0+0x215d>
    d987:	4c 89 e7             	mov    %r12,%rdi
    d98a:	e8 c1 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d98f:	e9 78 f5 ff ff       	jmp    cf0c <f0+0x21fc>
    d994:	4c 89 e7             	mov    %r12,%rdi
    d997:	e8 b4 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d99c:	e9 0a f6 ff ff       	jmp    cfab <f0+0x229b>
    d9a1:	4c 89 e7             	mov    %r12,%rdi
    d9a4:	e8 a7 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d9a9:	e9 9c f6 ff ff       	jmp    d04a <f0+0x233a>
    d9ae:	4c 89 e7             	mov    %r12,%rdi
    d9b1:	e8 9a 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d9b6:	e9 2e f7 ff ff       	jmp    d0e9 <f0+0x23d9>
    d9bb:	4c 89 e7             	mov    %r12,%rdi
    d9be:	e8 8d 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d9c3:	e9 c0 f7 ff ff       	jmp    d188 <f0+0x2478>
    d9c8:	4c 89 e7             	mov    %r12,%rdi
    d9cb:	e8 80 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d9d0:	e9 52 f8 ff ff       	jmp    d227 <f0+0x2517>
    d9d5:	4c 89 e7             	mov    %r12,%rdi
    d9d8:	e8 73 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d9dd:	e9 e4 f8 ff ff       	jmp    d2c6 <f0+0x25b6>
    d9e2:	4c 89 e7             	mov    %r12,%rdi
    d9e5:	e8 66 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d9ea:	e9 76 f9 ff ff       	jmp    d365 <f0+0x2655>
    d9ef:	4c 89 e7             	mov    %r12,%rdi
    d9f2:	e8 59 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    d9f7:	e9 08 fa ff ff       	jmp    d404 <f0+0x26f4>
    d9fc:	4c 89 e7             	mov    %r12,%rdi
    d9ff:	e8 4c 7b ff ff       	call   5550 <fwp_rc_forget_slot>
    da04:	e9 9a fa ff ff       	jmp    d4a3 <f0+0x2793>
    da09:	e8 52 5a ff ff       	call   3460 <__stack_chk_fail@plt>
    da0e:	66 90                	xchg   %ax,%ax

000000000000da10 <fwp_main_thread>:
    da10:	f3 0f 1e fa          	endbr64
    da14:	41 54                	push   %r12
    da16:	55                   	push   %rbp
    da17:	53                   	push   %rbx
    da18:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    da1f:	8b 35 3f 71 01 00    	mov    0x1713f(%rip),%esi        # 24b64 <fwp_heap+0x13a4>
    da25:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    da2c:	00 00 
    da2e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    da35:	00 
    da36:	31 c0                	xor    %eax,%eax
    da38:	85 f6                	test   %esi,%esi
    da3a:	0f 84 a8 06 00 00    	je     e0e8 <fwp_main_thread+0x6d8>
    da40:	8b 0d 22 71 01 00    	mov    0x17122(%rip),%ecx        # 24b68 <fwp_heap+0x13a8>
    da46:	85 c9                	test   %ecx,%ecx
    da48:	0f 85 82 06 00 00    	jne    e0d0 <fwp_main_thread+0x6c0>
    da4e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    da53:	31 f6                	xor    %esi,%esi
    da55:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    da5a:	48 c7 05 eb 56 01 00 	movq   $0x40000000,0x156eb(%rip)        # 23150 <fwp_main_stack_size>
    da61:	00 00 00 40 
    da65:	48 89 05 ec 56 01 00 	mov    %rax,0x156ec(%rip)        # 23158 <fwp_main_stack_top>
    da6c:	48 8d 05 0d 56 00 00 	lea    0x560d(%rip),%rax        # 13080 <alt.5>
    da73:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    da78:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    da7f:	01 00 
    da81:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    da88:	00 
    da89:	e8 32 5c ff ff       	call   36c0 <sigaltstack@plt>
    da8e:	85 c0                	test   %eax,%eax
    da90:	0f 85 8a 06 00 00    	jne    e120 <fwp_main_thread+0x710>
    da96:	31 c0                	xor    %eax,%eax
    da98:	b9 12 00 00 00       	mov    $0x12,%ecx
    da9d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    daa2:	f3 48 ab             	rep stos %rax,(%rdi)
    daa5:	48 8d 05 44 62 ff ff 	lea    -0x9dbc(%rip),%rax        # 3cf0 <fwp_segv>
    daac:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dab1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    dab8:	04 00 00 08 
    dabc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    dac1:	e8 ba 5a ff ff       	call   3580 <sigemptyset@plt>
    dac6:	85 c0                	test   %eax,%eax
    dac8:	0f 85 52 06 00 00    	jne    e120 <fwp_main_thread+0x710>
    dace:	31 d2                	xor    %edx,%edx
    dad0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    dad5:	bf 0b 00 00 00       	mov    $0xb,%edi
    dada:	e8 21 59 ff ff       	call   3400 <sigaction@plt>
    dadf:	85 c0                	test   %eax,%eax
    dae1:	0f 85 39 06 00 00    	jne    e120 <fwp_main_thread+0x710>
    dae7:	31 d2                	xor    %edx,%edx
    dae9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    daee:	bf 07 00 00 00       	mov    $0x7,%edi
    daf3:	e8 08 59 ff ff       	call   3400 <sigaction@plt>
    daf8:	85 c0                	test   %eax,%eax
    dafa:	0f 85 20 06 00 00    	jne    e120 <fwp_main_thread+0x710>
    db00:	8b 15 f2 55 01 00    	mov    0x155f2(%rip),%edx        # 230f8 <descent_registered>
    db06:	85 d2                	test   %edx,%edx
    db08:	0f 84 72 05 00 00    	je     e080 <fwp_main_thread+0x670>
    db0e:	8b 05 5c 55 00 00    	mov    0x555c(%rip),%eax        # 13070 <st.3>
    db14:	85 c0                	test   %eax,%eax
    db16:	0f 84 90 05 00 00    	je     e0ac <fwp_main_thread+0x69c>
    db1c:	48 8b 2d 7d 5c 01 00 	mov    0x15c7d(%rip),%rbp        # 237a0 <fwp_cur>
    db23:	48 85 ed             	test   %rbp,%rbp
    db26:	0f 84 74 03 00 00    	je     dea0 <fwp_main_thread+0x490>
    db2c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    db31:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    db35:	48 89 eb             	mov    %rbp,%rbx
    db38:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    db3d:	0f 84 41 01 00 00    	je     dc84 <fwp_main_thread+0x274>
    db43:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    db48:	0f 84 82 02 00 00    	je     ddd0 <fwp_main_thread+0x3c0>
    db4e:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    db52:	0f 84 68 02 00 00    	je     ddc0 <fwp_main_thread+0x3b0>
    db58:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    db5c:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    db60:	0f 85 ea 02 00 00    	jne    de50 <fwp_main_thread+0x440>
    db66:	48 8b 43 60          	mov    0x60(%rbx),%rax
    db6a:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    db71:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    db75:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    db7c:	00 00 00 00 
    db80:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    db87:	48 85 d2             	test   %rdx,%rdx
    db8a:	74 07                	je     db93 <fwp_main_thread+0x183>
    db8c:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    db93:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    db97:	48 85 c0             	test   %rax,%rax
    db9a:	74 34                	je     dbd0 <fwp_main_thread+0x1c0>
    db9c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    dba0:	48 8b 05 d1 5b 01 00 	mov    0x15bd1(%rip),%rax        # 23778 <fwp_timers>
    dba7:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    dbab:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    dbb2:	00 00 00 00 
    dbb6:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    dbbd:	48 85 c0             	test   %rax,%rax
    dbc0:	74 07                	je     dbc9 <fwp_main_thread+0x1b9>
    dbc2:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    dbc9:	48 89 1d a8 5b 01 00 	mov    %rbx,0x15ba8(%rip)        # 23778 <fwp_timers>
    dbd0:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    dbd4:	e8 d7 98 ff ff       	call   74b0 <fwp_block>
    dbd9:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    dbe0:	48 85 c9             	test   %rcx,%rcx
    dbe3:	74 47                	je     dc2c <fwp_main_thread+0x21c>
    dbe5:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    dbec:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dbf3:	48 85 d2             	test   %rdx,%rdx
    dbf6:	0f 84 94 02 00 00    	je     de90 <fwp_main_thread+0x480>
    dbfc:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    dc03:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dc0a:	48 85 c0             	test   %rax,%rax
    dc0d:	74 07                	je     dc16 <fwp_main_thread+0x206>
    dc0f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    dc16:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    dc1d:	00 00 00 00 
    dc21:	66 0f ef c0          	pxor   %xmm0,%xmm0
    dc25:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    dc2c:	48 8b 0d 6d 5b 01 00 	mov    0x15b6d(%rip),%rcx        # 237a0 <fwp_cur>
    dc33:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    dc37:	0f 84 03 02 00 00    	je     de40 <fwp_main_thread+0x430>
    dc3d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    dc44:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    dc4b:	48 85 d2             	test   %rdx,%rdx
    dc4e:	0f 84 fc 03 00 00    	je     e050 <fwp_main_thread+0x640>
    dc54:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    dc5b:	48 85 c0             	test   %rax,%rax
    dc5e:	74 07                	je     dc67 <fwp_main_thread+0x257>
    dc60:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    dc67:	66 0f ef c9          	pxor   %xmm1,%xmm1
    dc6b:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    dc6f:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    dc76:	48 89 cb             	mov    %rcx,%rbx
    dc79:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    dc7e:	0f 85 bf fe ff ff    	jne    db43 <fwp_main_thread+0x133>
    dc84:	48 83 3d ac 77 01 00 	cmpq   $0x0,0x177ac(%rip)        # 25438 <fwp_state_len>
    dc8b:	00 
    dc8c:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    dc90:	0f 84 bc 00 00 00    	je     dd52 <fwp_main_thread+0x342>
    dc96:	48 39 1d fb 5a 01 00 	cmp    %rbx,0x15afb(%rip)        # 23798 <fwp_root>
    dc9d:	c7 05 d9 53 01 00 00 	movl   $0x0,0x153d9(%rip)        # 23080 <fwp_exit_code>
    dca4:	00 00 00 
    dca7:	0f 85 91 04 00 00    	jne    e13e <fwp_main_thread+0x72e>
    dcad:	48 85 db             	test   %rbx,%rbx
    dcb0:	0f 84 10 02 00 00    	je     dec6 <fwp_main_thread+0x4b6>
    dcb6:	48 8b 15 ab 5a 01 00 	mov    0x15aab(%rip),%rdx        # 23768 <fwp_tasks_active>
    dcbd:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    dcc1:	48 85 d2             	test   %rdx,%rdx
    dcc4:	0f 84 fc 01 00 00    	je     dec6 <fwp_main_thread+0x4b6>
    dcca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    dcd0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    dcd4:	75 08                	jne    dcde <fwp_main_thread+0x2ce>
    dcd6:	48 89 d7             	mov    %rdx,%rdi
    dcd9:	e8 22 66 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    dcde:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    dce5:	48 85 d2             	test   %rdx,%rdx
    dce8:	75 e6                	jne    dcd0 <fwp_main_thread+0x2c0>
    dcea:	eb 31                	jmp    dd1d <fwp_main_thread+0x30d>
    dcec:	0f 1f 40 00          	nopl   0x0(%rax)
    dcf0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    dcf7:	48 89 1d 82 5a 01 00 	mov    %rbx,0x15a82(%rip)        # 23780 <fwp_ready_tail>
    dcfe:	e8 ad 97 ff ff       	call   74b0 <fwp_block>
    dd03:	e8 98 95 ff ff       	call   72a0 <fwp_free_zombie>
    dd08:	48 83 3d 58 5a 01 00 	cmpq   $0x0,0x15a58(%rip)        # 23768 <fwp_tasks_active>
    dd0f:	00 
    dd10:	0f 84 b0 01 00 00    	je     dec6 <fwp_main_thread+0x4b6>
    dd16:	48 8b 1d 7b 5a 01 00 	mov    0x15a7b(%rip),%rbx        # 23798 <fwp_root>
    dd1d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    dd21:	75 db                	jne    dcfe <fwp_main_thread+0x2ee>
    dd23:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    dd27:	75 d5                	jne    dcfe <fwp_main_thread+0x2ee>
    dd29:	48 8b 05 50 5a 01 00 	mov    0x15a50(%rip),%rax        # 23780 <fwp_ready_tail>
    dd30:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    dd34:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    dd3b:	00 00 00 00 
    dd3f:	48 85 c0             	test   %rax,%rax
    dd42:	75 ac                	jne    dcf0 <fwp_main_thread+0x2e0>
    dd44:	48 89 1d 3d 5a 01 00 	mov    %rbx,0x15a3d(%rip)        # 23788 <fwp_ready_head>
    dd4b:	eb aa                	jmp    dcf7 <fwp_main_thread+0x2e7>
    dd4d:	0f 1f 00             	nopl   (%rax)
    dd50:	31 db                	xor    %ebx,%ebx
    dd52:	48 83 3d ce 76 01 00 	cmpq   $0x0,0x176ce(%rip)        # 25428 <fwp_state_owners>
    dd59:	00 
    dd5a:	0f 85 36 ff ff ff    	jne    dc96 <fwp_main_thread+0x286>
    dd60:	48 8b 3d d9 76 01 00 	mov    0x176d9(%rip),%rdi        # 25440 <fwp_state>
    dd67:	e8 24 7a ff ff       	call   5790 <fwp_mem_free>
    dd6c:	48 c7 05 c9 76 01 00 	movq   $0x0,0x176c9(%rip)        # 25440 <fwp_state>
    dd73:	00 00 00 00 
    dd77:	48 c7 05 ae 76 01 00 	movq   $0x0,0x176ae(%rip)        # 25430 <fwp_state_cap>
    dd7e:	00 00 00 00 
    dd82:	48 85 db             	test   %rbx,%rbx
    dd85:	0f 84 76 03 00 00    	je     e101 <fwp_main_thread+0x6f1>
    dd8b:	48 39 1d 06 5a 01 00 	cmp    %rbx,0x15a06(%rip)        # 23798 <fwp_root>
    dd92:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    dd99:	00 00 00 00 
    dd9d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    dda4:	00 00 00 00 
    dda8:	c7 05 ce 52 01 00 00 	movl   $0x0,0x152ce(%rip)        # 23080 <fwp_exit_code>
    ddaf:	00 00 00 
    ddb2:	0f 84 fe fe ff ff    	je     dcb6 <fwp_main_thread+0x2a6>
    ddb8:	e9 98 59 ff ff       	jmp    3755 <fwp_main_thread.cold>
    ddbd:	0f 1f 00             	nopl   (%rax)
    ddc0:	e8 9b 67 ff ff       	call   4560 <fwp_now_ns>
    ddc5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    ddc9:	0f 8d 91 02 00 00    	jge    e060 <fwp_main_thread+0x650>
    ddcf:	90                   	nop
    ddd0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ddd4:	0f 85 7e fd ff ff    	jne    db58 <fwp_main_thread+0x148>
    ddda:	48 8b 45 60          	mov    0x60(%rbp),%rax
    ddde:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    dde2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dde6:	0f 85 7e fd ff ff    	jne    db6a <fwp_main_thread+0x15a>
    ddec:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    ddf0:	48 85 c9             	test   %rcx,%rcx
    ddf3:	0f 84 71 fd ff ff    	je     db6a <fwp_main_thread+0x15a>
    ddf9:	48 85 c0             	test   %rax,%rax
    ddfc:	0f 84 2f 03 00 00    	je     e131 <fwp_main_thread+0x721>
    de02:	48 39 c8             	cmp    %rcx,%rax
    de05:	48 0f 4f c1          	cmovg  %rcx,%rax
    de09:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    de10:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    de14:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    de1b:	00 00 00 00 
    de1f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    de26:	48 85 d2             	test   %rdx,%rdx
    de29:	74 07                	je     de32 <fwp_main_thread+0x422>
    de2b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    de32:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    de36:	e9 61 fd ff ff       	jmp    db9c <fwp_main_thread+0x18c>
    de3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    de40:	48 89 cb             	mov    %rcx,%rbx
    de43:	e9 f0 fc ff ff       	jmp    db38 <fwp_main_thread+0x128>
    de48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    de4f:	00 
    de50:	48 8b 45 40          	mov    0x40(%rbp),%rax
    de54:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    de5b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    de62:	00 00 00 00 
    de66:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    de6d:	48 85 c0             	test   %rax,%rax
    de70:	0f 84 82 02 00 00    	je     e0f8 <fwp_main_thread+0x6e8>
    de76:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    de7d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    de81:	e9 4a fd ff ff       	jmp    dbd0 <fwp_main_thread+0x1c0>
    de86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    de8d:	00 00 00 
    de90:	48 89 01             	mov    %rax,(%rcx)
    de93:	e9 72 fd ff ff       	jmp    dc0a <fwp_main_thread+0x1fa>
    de98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    de9f:	00 
    dea0:	48 83 3d 90 75 01 00 	cmpq   $0x0,0x17590(%rip)        # 25438 <fwp_state_len>
    dea7:	00 
    dea8:	0f 84 a2 fe ff ff    	je     dd50 <fwp_main_thread+0x340>
    deae:	48 83 3d e2 58 01 00 	cmpq   $0x0,0x158e2(%rip)        # 23798 <fwp_root>
    deb5:	00 
    deb6:	c7 05 c0 51 01 00 00 	movl   $0x0,0x151c0(%rip)        # 23080 <fwp_exit_code>
    debd:	00 00 00 
    dec0:	0f 85 7d 02 00 00    	jne    e143 <fwp_main_thread+0x733>
    dec6:	e8 d5 93 ff ff       	call   72a0 <fwp_free_zombie>
    decb:	48 83 3d b5 58 01 00 	cmpq   $0x0,0x158b5(%rip)        # 23788 <fwp_ready_head>
    ded2:	00 
    ded3:	0f 85 7c 58 ff ff    	jne    3755 <fwp_main_thread.cold>
    ded9:	48 83 3d 97 58 01 00 	cmpq   $0x0,0x15897(%rip)        # 23778 <fwp_timers>
    dee0:	00 
    dee1:	0f 85 6e 58 ff ff    	jne    3755 <fwp_main_thread.cold>
    dee7:	8b 1d 77 52 01 00    	mov    0x15277(%rip),%ebx        # 23164 <fwp_stack_pool_n>
    deed:	85 db                	test   %ebx,%ebx
    deef:	74 36                	je     df27 <fwp_main_thread+0x517>
    def1:	83 eb 01             	sub    $0x1,%ebx
    def4:	48 8d 05 85 52 01 00 	lea    0x15285(%rip),%rax        # 23180 <fwp_stack_pool>
    defb:	48 63 d3             	movslq %ebx,%rdx
    defe:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    df02:	eb 07                	jmp    df0b <fwp_main_thread+0x4fb>
    df04:	0f 1f 40 00          	nopl   0x0(%rax)
    df08:	83 eb 01             	sub    $0x1,%ebx
    df0b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    df0f:	be 00 00 00 10       	mov    $0x10000000,%esi
    df14:	89 1d 4a 52 01 00    	mov    %ebx,0x1524a(%rip)        # 23164 <fwp_stack_pool_n>
    df1a:	48 83 ed 08          	sub    $0x8,%rbp
    df1e:	e8 bd 56 ff ff       	call   35e0 <munmap@plt>
    df23:	85 db                	test   %ebx,%ebx
    df25:	75 e1                	jne    df08 <fwp_main_thread+0x4f8>
    df27:	8b 3d ef 50 00 00    	mov    0x50ef(%rip),%edi        # 1301c <fwp_epfd>
    df2d:	85 ff                	test   %edi,%edi
    df2f:	78 05                	js     df36 <fwp_main_thread+0x526>
    df31:	e8 9a 55 ff ff       	call   34d0 <close@plt>
    df36:	4c 8b 25 43 54 01 00 	mov    0x15443(%rip),%r12        # 23380 <fwp_nfdws>
    df3d:	48 8b 2d 44 54 01 00 	mov    0x15444(%rip),%rbp        # 23388 <fwp_fdws>
    df44:	31 db                	xor    %ebx,%ebx
    df46:	c7 05 cc 50 00 00 ff 	movl   $0xffffffff,0x50cc(%rip)        # 1301c <fwp_epfd>
    df4d:	ff ff ff 
    df50:	4d 85 e4             	test   %r12,%r12
    df53:	74 38                	je     df8d <fwp_main_thread+0x57d>
    df55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    df5c:	00 00 00 00 
    df60:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    df65:	48 85 ff             	test   %rdi,%rdi
    df68:	74 1a                	je     df84 <fwp_main_thread+0x574>
    df6a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    df6e:	0f 85 e1 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    df74:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    df79:	0f 85 d6 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    df7f:	e8 0c 78 ff ff       	call   5790 <fwp_mem_free>
    df84:	48 83 c3 01          	add    $0x1,%rbx
    df88:	4c 39 e3             	cmp    %r12,%rbx
    df8b:	75 d3                	jne    df60 <fwp_main_thread+0x550>
    df8d:	48 89 ef             	mov    %rbp,%rdi
    df90:	e8 fb 77 ff ff       	call   5790 <fwp_mem_free>
    df95:	48 8b 15 fc 57 01 00 	mov    0x157fc(%rip),%rdx        # 23798 <fwp_root>
    df9c:	48 c7 05 e1 53 01 00 	movq   $0x0,0x153e1(%rip)        # 23388 <fwp_fdws>
    dfa3:	00 00 00 00 
    dfa7:	48 c7 05 ce 53 01 00 	movq   $0x0,0x153ce(%rip)        # 23380 <fwp_nfdws>
    dfae:	00 00 00 00 
    dfb2:	48 85 d2             	test   %rdx,%rdx
    dfb5:	74 4e                	je     e005 <fwp_main_thread+0x5f5>
    dfb7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    dfbc:	0f 85 93 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    dfc2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    dfc9:	00 
    dfca:	0f 85 85 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    dfd0:	48 83 3d 60 74 01 00 	cmpq   $0x0,0x17460(%rip)        # 25438 <fwp_state_len>
    dfd7:	00 
    dfd8:	0f 85 77 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    dfde:	48 83 3d 42 74 01 00 	cmpq   $0x0,0x17442(%rip)        # 25428 <fwp_state_owners>
    dfe5:	00 
    dfe6:	0f 85 69 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    dfec:	b9 79 00 00 00       	mov    $0x79,%ecx
    dff1:	31 c0                	xor    %eax,%eax
    dff3:	48 8d 3d a6 53 01 00 	lea    0x153a6(%rip),%rdi        # 233a0 <fwp_root_context>
    dffa:	f3 48 ab             	rep stos %rax,(%rdi)
    dffd:	48 89 d7             	mov    %rdx,%rdi
    e000:	e8 8b 77 ff ff       	call   5790 <fwp_mem_free>
    e005:	48 8b 3d 14 50 00 00 	mov    0x5014(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e00c:	48 c7 05 89 57 01 00 	movq   $0x0,0x15789(%rip)        # 237a0 <fwp_cur>
    e013:	00 00 00 00 
    e017:	48 c7 05 76 57 01 00 	movq   $0x0,0x15776(%rip)        # 23798 <fwp_root>
    e01e:	00 00 00 00 
    e022:	e8 99 55 ff ff       	call   35c0 <fflush@plt>
    e027:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e02e:	00 
    e02f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e036:	00 00 
    e038:	0f 85 fb 00 00 00    	jne    e139 <fwp_main_thread+0x729>
    e03e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e045:	31 c0                	xor    %eax,%eax
    e047:	5b                   	pop    %rbx
    e048:	5d                   	pop    %rbp
    e049:	41 5c                	pop    %r12
    e04b:	c3                   	ret
    e04c:	0f 1f 40 00          	nopl   0x0(%rax)
    e050:	48 89 05 21 57 01 00 	mov    %rax,0x15721(%rip)        # 23778 <fwp_timers>
    e057:	e9 ff fb ff ff       	jmp    dc5b <fwp_main_thread+0x24b>
    e05c:	0f 1f 40 00          	nopl   0x0(%rax)
    e060:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e064:	0f 85 66 fd ff ff    	jne    ddd0 <fwp_main_thread+0x3c0>
    e06a:	48 89 ef             	mov    %rbp,%rdi
    e06d:	e8 8e 62 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e072:	e9 59 fd ff ff       	jmp    ddd0 <fwp_main_thread+0x3c0>
    e077:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e07e:	00 00 
    e080:	48 8d 3d 89 5d ff ff 	lea    -0xa277(%rip),%rdi        # 3e10 <descent_phase_report>
    e087:	e8 d4 02 00 00       	call   e360 <atexit>
    e08c:	85 c0                	test   %eax,%eax
    e08e:	0f 85 98 00 00 00    	jne    e12c <fwp_main_thread+0x71c>
    e094:	c7 05 5a 50 01 00 01 	movl   $0x1,0x1505a(%rip)        # 230f8 <descent_registered>
    e09b:	00 00 00 
    e09e:	8b 05 cc 4f 00 00    	mov    0x4fcc(%rip),%eax        # 13070 <st.3>
    e0a4:	85 c0                	test   %eax,%eax
    e0a6:	0f 85 70 fa ff ff    	jne    db1c <fwp_main_thread+0x10c>
    e0ac:	e8 5f cc ff ff       	call   ad10 <f0>
    e0b1:	48 c7 05 ac 4f 00 00 	movq   $0x0,0x4fac(%rip)        # 13068 <v.2>
    e0b8:	00 00 00 00 
    e0bc:	c7 05 aa 4f 00 00 01 	movl   $0x1,0x4faa(%rip)        # 13070 <st.3>
    e0c3:	00 00 00 
    e0c6:	e9 51 fa ff ff       	jmp    db1c <fwp_main_thread+0x10c>
    e0cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e0d0:	48 8d 3d 89 6b ff ff 	lea    -0x9477(%rip),%rdi        # 4c60 <fwp_heap_report>
    e0d7:	e8 84 02 00 00       	call   e360 <atexit>
    e0dc:	e9 6d f9 ff ff       	jmp    da4e <fwp_main_thread+0x3e>
    e0e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e0e8:	e8 83 6c ff ff       	call   4d70 <fwp_heap_init>
    e0ed:	e9 4e f9 ff ff       	jmp    da40 <fwp_main_thread+0x30>
    e0f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e0f8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e0fc:	e9 cf fa ff ff       	jmp    dbd0 <fwp_main_thread+0x1c0>
    e101:	48 83 3d 8f 56 01 00 	cmpq   $0x0,0x1568f(%rip)        # 23798 <fwp_root>
    e108:	00 
    e109:	c7 05 6d 4f 01 00 00 	movl   $0x0,0x14f6d(%rip)        # 23080 <fwp_exit_code>
    e110:	00 00 00 
    e113:	0f 84 ad fd ff ff    	je     dec6 <fwp_main_thread+0x4b6>
    e119:	e9 37 56 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e11e:	66 90                	xchg   %ax,%ax
    e120:	48 8d 3d c1 18 00 00 	lea    0x18c1(%rip),%rdi        # f9e8 <_IO_stdin_used+0x9e8>
    e127:	e8 c4 62 ff ff       	call   43f0 <fwp_trap>
    e12c:	e8 af 5c ff ff       	call   3de0 <descent_phase_fail>
    e131:	48 89 c8             	mov    %rcx,%rax
    e134:	e9 d0 fc ff ff       	jmp    de09 <fwp_main_thread+0x3f9>
    e139:	e8 22 53 ff ff       	call   3460 <__stack_chk_fail@plt>
    e13e:	e9 12 56 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e143:	e9 0d 56 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e148:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e14f:	00 

000000000000e150 <__divmodti4>:
    e150:	f3 0f 1e fa          	endbr64
    e154:	55                   	push   %rbp
    e155:	49 89 f1             	mov    %rsi,%r9
    e158:	49 89 d2             	mov    %rdx,%r10
    e15b:	48 89 fe             	mov    %rdi,%rsi
    e15e:	49 89 cb             	mov    %rcx,%r11
    e161:	48 89 e5             	mov    %rsp,%rbp
    e164:	41 57                	push   %r15
    e166:	41 56                	push   %r14
    e168:	41 55                	push   %r13
    e16a:	41 54                	push   %r12
    e16c:	53                   	push   %rbx
    e16d:	4c 89 c3             	mov    %r8,%rbx
    e170:	45 31 c0             	xor    %r8d,%r8d
    e173:	4d 85 c9             	test   %r9,%r9
    e176:	79 12                	jns    e18a <__divmodti4+0x3a>
    e178:	31 ff                	xor    %edi,%edi
    e17a:	48 f7 de             	neg    %rsi
    e17d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e184:	4c 19 cf             	sbb    %r9,%rdi
    e187:	49 89 f9             	mov    %rdi,%r9
    e18a:	4c 89 d8             	mov    %r11,%rax
    e18d:	4d 85 db             	test   %r11,%r11
    e190:	0f 88 1a 01 00 00    	js     e2b0 <__divmodti4+0x160>
    e196:	4c 89 d9             	mov    %r11,%rcx
    e199:	49 89 f3             	mov    %rsi,%r11
    e19c:	75 62                	jne    e200 <__divmodti4+0xb0>
    e19e:	4d 89 c4             	mov    %r8,%r12
    e1a1:	4d 39 d1             	cmp    %r10,%r9
    e1a4:	0f 83 46 01 00 00    	jae    e2f0 <__divmodti4+0x1a0>
    e1aa:	4c 89 d8             	mov    %r11,%rax
    e1ad:	4c 89 ca             	mov    %r9,%rdx
    e1b0:	49 f7 f2             	div    %r10
    e1b3:	49 89 c3             	mov    %rax,%r11
    e1b6:	31 c0                	xor    %eax,%eax
    e1b8:	48 89 d6             	mov    %rdx,%rsi
    e1bb:	31 ff                	xor    %edi,%edi
    e1bd:	4c 89 d9             	mov    %r11,%rcx
    e1c0:	48 89 c2             	mov    %rax,%rdx
    e1c3:	48 89 c8             	mov    %rcx,%rax
    e1c6:	4d 85 e4             	test   %r12,%r12
    e1c9:	74 0a                	je     e1d5 <__divmodti4+0x85>
    e1cb:	48 f7 d8             	neg    %rax
    e1ce:	48 83 d2 00          	adc    $0x0,%rdx
    e1d2:	48 f7 da             	neg    %rdx
    e1d5:	4d 85 c0             	test   %r8,%r8
    e1d8:	74 0a                	je     e1e4 <__divmodti4+0x94>
    e1da:	48 f7 de             	neg    %rsi
    e1dd:	48 83 d7 00          	adc    $0x0,%rdi
    e1e1:	48 f7 df             	neg    %rdi
    e1e4:	48 89 33             	mov    %rsi,(%rbx)
    e1e7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e1eb:	5b                   	pop    %rbx
    e1ec:	41 5c                	pop    %r12
    e1ee:	41 5d                	pop    %r13
    e1f0:	41 5e                	pop    %r14
    e1f2:	41 5f                	pop    %r15
    e1f4:	5d                   	pop    %rbp
    e1f5:	c3                   	ret
    e1f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e1fd:	00 00 00 
    e200:	4d 89 c4             	mov    %r8,%r12
    e203:	49 39 c1             	cmp    %rax,%r9
    e206:	0f 82 ce 00 00 00    	jb     e2da <__divmodti4+0x18a>
    e20c:	31 ff                	xor    %edi,%edi
    e20e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e213:	48 63 c7             	movslq %edi,%rax
    e216:	be 40 00 00 00       	mov    $0x40,%esi
    e21b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e220:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e225:	48 29 c6             	sub    %rax,%rsi
    e228:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e22d:	48 09 c8             	or     %rcx,%rax
    e230:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e235:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e23a:	49 89 c6             	mov    %rax,%r14
    e23d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e241:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e246:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e24b:	49 09 c1             	or     %rax,%r9
    e24e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e252:	4c 89 c8             	mov    %r9,%rax
    e255:	49 f7 f6             	div    %r14
    e258:	48 89 d1             	mov    %rdx,%rcx
    e25b:	49 89 c3             	mov    %rax,%r11
    e25e:	49 89 c1             	mov    %rax,%r9
    e261:	49 f7 e2             	mul    %r10
    e264:	49 89 c6             	mov    %rax,%r14
    e267:	49 89 d2             	mov    %rdx,%r10
    e26a:	48 39 d1             	cmp    %rdx,%rcx
    e26d:	72 07                	jb     e276 <__divmodti4+0x126>
    e26f:	75 17                	jne    e288 <__divmodti4+0x138>
    e271:	49 39 c7             	cmp    %rax,%r15
    e274:	73 12                	jae    e288 <__divmodti4+0x138>
    e276:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e27a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e27e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e282:	49 89 d2             	mov    %rdx,%r10
    e285:	49 89 c6             	mov    %rax,%r14
    e288:	4c 89 f8             	mov    %r15,%rax
    e28b:	4c 29 f0             	sub    %r14,%rax
    e28e:	4c 19 d1             	sbb    %r10,%rcx
    e291:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e296:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e29b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e2a0:	48 09 c6             	or     %rax,%rsi
    e2a3:	48 89 cf             	mov    %rcx,%rdi
    e2a6:	31 c0                	xor    %eax,%eax
    e2a8:	4c 89 c9             	mov    %r9,%rcx
    e2ab:	e9 10 ff ff ff       	jmp    e1c0 <__divmodti4+0x70>
    e2b0:	4c 89 d0             	mov    %r10,%rax
    e2b3:	4c 89 da             	mov    %r11,%rdx
    e2b6:	4d 89 c4             	mov    %r8,%r12
    e2b9:	49 89 f3             	mov    %rsi,%r11
    e2bc:	48 f7 d8             	neg    %rax
    e2bf:	49 f7 d4             	not    %r12
    e2c2:	48 83 d2 00          	adc    $0x0,%rdx
    e2c6:	49 89 c2             	mov    %rax,%r10
    e2c9:	48 f7 da             	neg    %rdx
    e2cc:	48 89 d1             	mov    %rdx,%rcx
    e2cf:	0f 84 cc fe ff ff    	je     e1a1 <__divmodti4+0x51>
    e2d5:	49 39 d1             	cmp    %rdx,%r9
    e2d8:	73 46                	jae    e320 <__divmodti4+0x1d0>
    e2da:	4c 89 cf             	mov    %r9,%rdi
    e2dd:	31 c0                	xor    %eax,%eax
    e2df:	31 c9                	xor    %ecx,%ecx
    e2e1:	e9 da fe ff ff       	jmp    e1c0 <__divmodti4+0x70>
    e2e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e2ed:	00 00 00 
    e2f0:	4d 85 d2             	test   %r10,%r10
    e2f3:	75 0d                	jne    e302 <__divmodti4+0x1b2>
    e2f5:	b8 01 00 00 00       	mov    $0x1,%eax
    e2fa:	31 d2                	xor    %edx,%edx
    e2fc:	49 f7 f2             	div    %r10
    e2ff:	49 89 c2             	mov    %rax,%r10
    e302:	4c 89 c8             	mov    %r9,%rax
    e305:	31 d2                	xor    %edx,%edx
    e307:	49 f7 f2             	div    %r10
    e30a:	49 89 c1             	mov    %rax,%r9
    e30d:	4c 89 d8             	mov    %r11,%rax
    e310:	49 f7 f2             	div    %r10
    e313:	49 89 c3             	mov    %rax,%r11
    e316:	4c 89 c8             	mov    %r9,%rax
    e319:	e9 9a fe ff ff       	jmp    e1b8 <__divmodti4+0x68>
    e31e:	66 90                	xchg   %ax,%ax
    e320:	45 31 f6             	xor    %r14d,%r14d
    e323:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e328:	44 89 f7             	mov    %r14d,%edi
    e32b:	45 85 f6             	test   %r14d,%r14d
    e32e:	0f 85 df fe ff ff    	jne    e213 <__divmodti4+0xc3>
    e334:	4c 39 ca             	cmp    %r9,%rdx
    e337:	72 17                	jb     e350 <__divmodti4+0x200>
    e339:	31 c9                	xor    %ecx,%ecx
    e33b:	48 39 c6             	cmp    %rax,%rsi
    e33e:	73 10                	jae    e350 <__divmodti4+0x200>
    e340:	4c 89 cf             	mov    %r9,%rdi
    e343:	31 c0                	xor    %eax,%eax
    e345:	e9 76 fe ff ff       	jmp    e1c0 <__divmodti4+0x70>
    e34a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e350:	4c 89 de             	mov    %r11,%rsi
    e353:	b9 01 00 00 00       	mov    $0x1,%ecx
    e358:	48 29 c6             	sub    %rax,%rsi
    e35b:	49 19 d1             	sbb    %rdx,%r9
    e35e:	eb e0                	jmp    e340 <__divmodti4+0x1f0>

000000000000e360 <atexit>:
    e360:	f3 0f 1e fa          	endbr64
    e364:	48 8b 15 9d 4c 00 00 	mov    0x4c9d(%rip),%rdx        # 13008 <__dso_handle>
    e36b:	31 f6                	xor    %esi,%esi
    e36d:	e9 ee 52 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e374 <_fini>:
    e374:	f3 0f 1e fa          	endbr64
    e378:	48 83 ec 08          	sub    $0x8,%rsp
    e37c:	48 83 c4 08          	add    $0x8,%rsp
    e380:	c3                   	ret
