
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-identical:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ff 00 00 	mov    0xffc9(%rip),%rax        # 12fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 fd 00 00    	push   0xfde2(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 fd 00 00    	jmp    *0xfde4(%rip)        # 12e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e fc 00 00    	jmp    *0xfc4e(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a b9 00 00 	lea    0xb97a(%rip),%r9        # f091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 b9 00 00 	lea    0xb977(%rip),%r8        # f095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 db 00 00 	lea    0xdba1(%rip),%rax        # 11320 <fwp_fn_table>
    377f:	48 89 05 32 1c 02 00 	mov    %rax,0x21c32(%rip)        # 253b8 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c 1c 02 00 	mov    %rax,0x21c2c(%rip)        # 253c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 ba 00 00 	lea    0xba59(%rip),%rdi        # f1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 8f 9f 00 00 	lea    0x9f8f(%rip),%rdx        # d7f0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 b9 00 00 	lea    0xb909(%rip),%rdi        # f202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 96 c0 00 00 	lea    0xc096(%rip),%rdi        # f9a0 <_IO_stdin_used+0x9a0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 50 c0 00 00 	lea    0xc050(%rip),%rdi        # f978 <_IO_stdin_used+0x978>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 14 c0 00 00 	lea    0xc014(%rip),%rdi        # f948 <_IO_stdin_used+0x948>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d e0 bf 00 00 	lea    0xbfe0(%rip),%rdi        # f920 <_IO_stdin_used+0x920>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 f6 00 00    	call   *0xf653(%rip)        # 12fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 f6 00 00 	mov    0xf636(%rip),%rax        # 12fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 f6 00 00 	mov    0xf605(%rip),%rax        # 12fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 f5 00 00 	cmpq   $0x0,0xf5e2(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce f4 01 00 	add    0x1f4ce(%rip),%rdx        # 230f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc f4 01 00 	add    0x1f4bc(%rip),%rax        # 230f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 17 02 00 	mov    0x21749(%rip),%rdi        # 253c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 f3 00 00 	mov    0xf394(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 f3 00 00 	mov    0xf381(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 f3 00 00 	mov    0xf372(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 fa 01 00 	mov    0x1fa41(%rip),%rax        # 23740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 f3 01 00 	mov    0x1f381(%rip),%rax        # 23100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d f3 01 00 	sub    0x1f36d(%rip),%rax        # 230f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd bc 00 00 	lea    0xbcbd(%rip),%rsi        # fa80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b 0d 02 00 	mov    0x20d5b(%rip),%rax        # 24b50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 0d 02 00 	lea    0x20d54(%rip),%r8        # 24b50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 0d 02 00 	mov    0x20d35(%rip),%rbx        # 24b38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 0d 02 00 	mov    0x20d45(%rip),%rcx        # 24b58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 0c 02 00 	mov    0x20ce1(%rip),%rdi        # 24b40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a 0d 02 00 	sub    %rsi,0x20d2a(%rip)        # 24b90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba 0c 02 00 	mov    0x20cba(%rip),%rax        # 24b30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 0c 02 00 	add    0x20c70(%rip),%rdi        # 24b10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e 0c 02 00 	mov    0x20c7e(%rip),%rsi        # 24b40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c 0c 02 00 	mov    0x20c8c(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b 0c 02 00 	mov    %r12,0x20c3b(%rip)        # 24b40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 0c 02 00 	mov    %rbp,0x20c29(%rip)        # 24b38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e 0c 02 00 	cmp    %rdi,0x20c0e(%rip)        # 24b28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 0c 02 00 	mov    %rdi,0x20c05(%rip)        # 24b28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 0c 02 00 	sub    %rdi,0x20c49(%rip)        # 24b90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 0b 02 00 	mov    0x20bf1(%rip),%rax        # 24b48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea 0b 02 00 	lea    0x20bea(%rip),%r8        # 24b48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd ef 00 00 	mov    0xeffd(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 af 00 00 	lea    0xafb4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 f6 01 00 	cmp    0x1f689(%rip),%rdi        # 23740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f f6 01 00 	mov    0x1f64f(%rip),%rax        # 23720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d f6 01 00 	mov    %rdi,0x1f62d(%rip)        # 23720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 f6 01 00 	mov    %rdi,0x1f609(%rip)        # 23728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db af 00 00 	lea    0xafdb(%rip),%rsi        # f13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 ae 00 00 	lea    0xaea7(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 ee 00 00 	mov    0xee78(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 ae 00 00 	lea    0xae51(%rip),%rdx        # f020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 ee 00 00 	mov    0xee60(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 ed 00 00 	mov    0xed71(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 ad 00 00 	lea    0xad28(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 ad 00 00 	lea    0xad32(%rip),%rdi        # f02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba ac 00 00 	lea    0xacba(%rip),%rdi        # f049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 70 b2 00 00 	lea    0xb270(%rip),%rdi        # f610 <_IO_stdin_used+0x610>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 10 b7 00 	movdqa 0xb710(%rip),%xmm0        # fad0 <msg.4+0x50>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a 0f 02 00 	add    0x20f9a(%rip),%rax        # 253b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d cc b1 00 00 	lea    0xb1cc(%rip),%rdi        # f640 <_IO_stdin_used+0x640>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 ec 01 00 	cmp    %rax,0x1ec55(%rip)        # 230e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 ec 01 00 	add    0x1ec50(%rip),%rax        # 230f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d b5 b1 00 00 	lea    0xb1b5(%rip),%rdi        # f670 <_IO_stdin_used+0x670>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 ab 00 00 	lea    0xab92(%rip),%r8        # f065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 a9 00 00 	lea    0xa9e7(%rip),%r8        # f074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 a8 00 00 	lea    0xa874(%rip),%r8        # f06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c a6 00 00 	lea    0xa64c(%rip),%rdi        # f079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 a7 00 00 	lea    0xa736(%rip),%rsi        # f184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 00 02 00 	mov    0x20065(%rip),%r9        # 24b28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be 00 02 00 	mov    0x200be(%rip),%r8        # 24b88 <fwp_heap+0x1428>
    4aca:	48 8d 15 ef ab 00 00 	lea    0xabef(%rip),%rdx        # f6c0 <_IO_stdin_used+0x6c0>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 00 02 00 	mov    0x200a6(%rip),%rcx        # 24b80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 00 02 	movsd  0x200b4(%rip),%xmm1        # 24ba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 00 02 	movsd  0x200a4(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 e5 00 00 	mov    0xe545(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 a8 af 00 	movdqa 0xafa8(%rip),%xmm0        # fae0 <msg.4+0x60>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f fb 01 00 	lea    0x1fb5f(%rip),%rax        # 246a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 d1 af 00 	movdqa 0xafd1(%rip),%xmm2        # fb20 <msg.4+0xa0>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 fb 01 00 	movaps %xmm0,0x1fb05(%rip)        # 24660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 8d af 00 	movdqa 0xaf8d(%rip),%xmm0        # faf0 <msg.4+0x70>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 ff 01 00 01 	movl   $0x1,0x1ff93(%rip)        # 24b04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 fa 01 00 	movaps %xmm0,0x1faf3(%rip)        # 24670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 7b af 00 	movdqa 0xaf7b(%rip),%xmm0        # fb00 <msg.4+0x80>
    4b84:	00 
    4b85:	0f 29 05 f4 fa 01 00 	movaps %xmm0,0x1faf4(%rip)        # 24680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 7c af 00 	movdqa 0xaf7c(%rip),%xmm0        # fb10 <msg.4+0x90>
    4b93:	00 
    4b94:	0f 29 05 f5 fa 01 00 	movaps %xmm0,0x1faf5(%rip)        # 24690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 eb 01 00 	lea    0x1eb75(%rip),%r8        # 23760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 fe 01 00 	mov    %rax,0x1fe90(%rip)        # 24b18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e fe 01 00 	mov    %r12,0x1fe6e(%rip)        # 24b20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 fe 01 00 	mov    %rax,0x1fe57(%rip)        # 24b10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 fe 01 00 	mov    %rbx,0x1fe70(%rip)        # 24b30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 fe 01 00 	mov    %rsi,0x1fe99(%rip)        # 24b60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 a3 00 00 	lea    0xa3d6(%rip),%rdi        # f0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 fe 01 00 	mov    %rax,0x1fe78(%rip)        # 24b58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc fd 01 00    	mov    %eax,0x1fdfc(%rip)        # 24b08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec e9 01 00 	mov    0x1e9ec(%rip),%r8        # 23720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c e9 01 00 	mov    %rbx,0x1e91c(%rip)        # 23728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 e9 01 00 	mov    %r8,0x1e908(%rip)        # 23720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 a2 00 00 	lea    0xa239(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd e1 01 00 	lea    0x1e1dd(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 e1 01 00 	movaps %xmm0,0x1e1c5(%rip)        # 230a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 e1 01 00 	mov    %rax,0x1e1a1(%rip)        # 23088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 e1 01 00 	movaps %xmm0,0x1e1c2(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 e1 01 00 	movaps %xmm0,0x1e1c6(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 e1 01 00 	mov    %rdx,0x1e1c7(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 a1 00 00 	lea    0xa190(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 e7 01 00 	mov    0x1e797(%rip),%rbx        # 23718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca df 00 00 	mov    0xdfca(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d cb a6 00 00 	lea    0xa6cb(%rip),%rdi        # f748 <_IO_stdin_used+0x748>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d e6 01 00 	mov    0x1e66d(%rip),%rax        # 23720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 e6 01 00 	mov    %rdx,0x1e647(%rip)        # 23720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 e5 01 00 	mov    0x1e594(%rip),%rbx        # 23718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 e5 01 00 	mov    %rbx,0x1e551(%rip)        # 23718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 e5 01 00 	mov    %rdx,0x1e551(%rip)        # 23728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 e5 01 00 	lea    0x1e566(%rip),%rsi        # 23760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 00 02 00 	addq   $0x1,0x200e5(%rip)        # 253a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 9f a4 00 00 	lea    0xa49f(%rip),%rdi        # f778 <_IO_stdin_used+0x778>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d b0 a4 00 00 	lea    0xa4b0(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 9d 00 00 	lea    0x9dd4(%rip),%rdi        # f0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e e4 01 00 	lea    0x1e41e(%rip),%rcx        # 23760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f 00 02 00 	subq   $0x1,0x2001f(%rip)        # 253a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 0b a4 00 00 	lea    0xa40b(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 00 02 00 	cmpq   $0x0,0x20000(%rip)        # 253a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 ff 01 00 	sub    %rax,0x1ff55(%rip)        # 253b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 ff 01 00 	add    %r12,0x1ff33(%rip)        # 253b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f f6 01 00 	mov    0x1f68f(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c e2 01 00 	lea    0x1e28c(%rip),%rax        # 23760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 f5 01 00 	add    0x1f5e3(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 f5 01 00 	mov    0x1f5b0(%rip),%rsi        # 24b10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 f5 01 00 	mov    0x1f5d1(%rip),%rax        # 24b38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 f5 01 00 	add    0x1f5c5(%rip),%r8        # 24b58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d f5 01 	addsd  0x1f58d(%rip),%xmm0        # 24ba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 e1 01 00 	lea    0x1e142(%rip),%rax        # 23760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c f5 01 00 	sub    %rdi,0x1f54c(%rip)        # 24b80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 f5 01 	movsd  %xmm0,0x1f564(%rip)        # 24ba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e f5 01 00 	sub    %rdx,0x1f51e(%rip)        # 24b80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 f5 01 	addsd  0x1f524(%rip),%xmm0        # 24ba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 f5 01 	movsd  %xmm0,0x1f518(%rip)        # 24ba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af f4 01 00 	mov    0x1f4af(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 f4 01 00 	add    %rcx,0x1f4a9(%rip)        # 24b90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 f4 01 00 	cmp    0x1f462(%rip),%r9        # 24b50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 f4 01 00 	mov    %r9,0x1f459(%rip)        # 24b50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a f4 01 00 	cmp    0x1f44a(%rip),%r9        # 24b48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d f4 01 00 	mov    %r9,0x1f43d(%rip)        # 24b48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 f3 01 00 	add    0x1f353(%rip),%rdi        # 24b58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 df 01 00 	lea    0x1df30(%rip),%r15        # 23760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 f2 01 00 	add    0x1f2a0(%rip),%r12        # 24b10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 f2 01 00 	add    0x1f2f9(%rip),%rax        # 24b80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 f2 01 00 	cmp    %rax,0x1f2f8(%rip)        # 24b88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 f2 01 00 	mov    %rax,0x1f2e9(%rip)        # 24b80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 f2 01 00 	mov    %rax,0x1f2e8(%rip)        # 24b88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 f2 01 	addsd  0x1f2e4(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc f2 01 	movsd  %xmm0,0x1f2dc(%rip)        # 24b98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 f2 01 00    	mov    0x1f223(%rip),%eax        # 24b04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f de 01 00 	lea    0x1de5f(%rip),%rdi        # 23760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 f2 01 00 	add    0x1f218(%rip),%rax        # 24b80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 f2 01 00 	cmp    %rax,0x1f213(%rip)        # 24b88 <fwp_heap+0x1428>
    5975:	48 89 05 04 f2 01 00 	mov    %rax,0x1f204(%rip)        # 24b80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 f2 01 00 	mov    %rax,0x1f203(%rip)        # 24b88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff f1 01 	addsd  0x1f1ff(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 f1 01 	movsd  %xmm0,0x1f1f7(%rip)        # 24b98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae f0 01 00    	mov    0x1f0ae(%rip),%eax        # 24b04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 dc 01 00 	lea    0x1dce5(%rip),%rax        # 23760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b f0 01 00 	add    0x1f09b(%rip),%rax        # 24b80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a f0 01 00 	cmp    %rax,0x1f09a(%rip)        # 24b88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b f0 01 00 	mov    %rax,0x1f08b(%rip)        # 24b80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a f0 01 00 	mov    %rax,0x1f08a(%rip)        # 24b88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 f0 01 	addsd  0x1f086(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e f0 01 	movsd  %xmm0,0x1f07e(%rip)        # 24b98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_data.part.0.constprop.0>:
    5b70:	41 56                	push   %r14
    5b72:	41 89 fe             	mov    %edi,%r14d
    5b75:	41 54                	push   %r12
    5b77:	49 89 f4             	mov    %rsi,%r12
    5b7a:	55                   	push   %rbp
    5b7b:	53                   	push   %rbx
    5b7c:	48 83 ec 08          	sub    $0x8,%rsp
    5b80:	8b 05 7e ef 01 00    	mov    0x1ef7e(%rip),%eax        # 24b04 <fwp_heap+0x13a4>
    5b86:	85 c0                	test   %eax,%eax
    5b88:	0f 84 fa 00 00 00    	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5b8e:	0f b6 05 6d eb 01 00 	movzbl 0x1eb6d(%rip),%eax        # 24702 <fwp_heap+0xfa2>
    5b95:	48 8d 15 c4 db 01 00 	lea    0x1dbc4(%rip),%rdx        # 23760 <fwp_heap>
    5b9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5ba3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ba7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5bab:	48 8b 18             	mov    (%rax),%rbx
    5bae:	48 85 db             	test   %rbx,%rbx
    5bb1:	0f 84 a9 00 00 00    	je     5c60 <fwp_data.part.0.constprop.0+0xf0>
    5bb7:	48 8b 13             	mov    (%rbx),%rdx
    5bba:	48 f7 d2             	not    %rdx
    5bbd:	48 89 10             	mov    %rdx,(%rax)
    5bc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5bc4:	76 1b                	jbe    5be1 <fwp_data.part.0.constprop.0+0x71>
    5bc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5bca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5bce:	31 f6                	xor    %esi,%esi
    5bd0:	48 c1 e8 03          	shr    $0x3,%rax
    5bd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5bdb:	00 
    5bdc:	e8 df d8 ff ff       	call   34c0 <memset@plt>
    5be1:	48 89 e8             	mov    %rbp,%rax
    5be4:	48 03 05 95 ef 01 00 	add    0x1ef95(%rip),%rax        # 24b80 <fwp_heap+0x1420>
    5beb:	0f 82 a8 00 00 00    	jb     5c99 <fwp_data.part.0.constprop.0+0x129>
    5bf1:	48 39 05 90 ef 01 00 	cmp    %rax,0x1ef90(%rip)        # 24b88 <fwp_heap+0x1428>
    5bf8:	48 89 05 81 ef 01 00 	mov    %rax,0x1ef81(%rip)        # 24b80 <fwp_heap+0x1420>
    5bff:	73 07                	jae    5c08 <fwp_data.part.0.constprop.0+0x98>
    5c01:	48 89 05 80 ef 01 00 	mov    %rax,0x1ef80(%rip)        # 24b88 <fwp_heap+0x1428>
    5c08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c11:	f2 0f 58 05 7f ef 01 	addsd  0x1ef7f(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    5c18:	00 
    5c19:	f2 0f 11 05 77 ef 01 	movsd  %xmm0,0x1ef77(%rip)        # 24b98 <fwp_heap+0x1438>
    5c20:	00 
    5c21:	b8 02 00 00 00       	mov    $0x2,%eax
    5c26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c37:	49 8b 04 24          	mov    (%r12),%rax
    5c3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c48:	48 83 c4 08          	add    $0x8,%rsp
    5c4c:	48 89 d8             	mov    %rbx,%rax
    5c4f:	5b                   	pop    %rbx
    5c50:	5d                   	pop    %rbp
    5c51:	41 5c                	pop    %r12
    5c53:	41 5e                	pop    %r14
    5c55:	c3                   	ret
    5c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c5d:	00 00 00 
    5c60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c64:	48 85 db             	test   %rbx,%rbx
    5c67:	74 1f                	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c6d:	48 29 da             	sub    %rbx,%rdx
    5c70:	48 39 ea             	cmp    %rbp,%rdx
    5c73:	72 13                	jb     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c7d:	e9 3e ff ff ff       	jmp    5bc0 <fwp_data.part.0.constprop.0+0x50>
    5c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c88:	31 f6                	xor    %esi,%esi
    5c8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c8f:	e8 bc fd ff ff       	call   5a50 <fwp_heap_alloc>
    5c94:	48 89 c3             	mov    %rax,%rbx
    5c97:	eb 88                	jmp    5c21 <fwp_data.part.0.constprop.0+0xb1>
    5c99:	e8 12 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c9e:	66 90                	xchg   %ax,%ax

0000000000005ca0 <fwp_p_ad_push>:
    5ca0:	41 57                	push   %r15
    5ca2:	41 56                	push   %r14
    5ca4:	41 55                	push   %r13
    5ca6:	49 89 d5             	mov    %rdx,%r13
    5ca9:	41 54                	push   %r12
    5cab:	49 89 fc             	mov    %rdi,%r12
    5cae:	55                   	push   %rbp
    5caf:	53                   	push   %rbx
    5cb0:	48 83 ec 48          	sub    $0x48,%rsp
    5cb4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5cb9:	48 85 ff             	test   %rdi,%rdi
    5cbc:	79 09                	jns    5cc7 <fwp_p_ad_push+0x27>
    5cbe:	48 85 d2             	test   %rdx,%rdx
    5cc1:	0f 88 b9 02 00 00    	js     5f80 <fwp_p_ad_push+0x2e0>
    5cc7:	48 89 f8             	mov    %rdi,%rax
    5cca:	48 89 0c 24          	mov    %rcx,(%rsp)
    5cce:	4c 89 c5             	mov    %r8,%rbp
    5cd1:	48 09 d0             	or     %rdx,%rax
    5cd4:	0f 89 7e 02 00 00    	jns    5f58 <fwp_p_ad_push+0x2b8>
    5cda:	48 85 ff             	test   %rdi,%rdi
    5cdd:	0f 89 e6 03 00 00    	jns    60c9 <fwp_p_ad_push+0x429>
    5ce3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5ce8:	49 89 d6             	mov    %rdx,%r14
    5ceb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5cf2:	00 
    5cf3:	49 89 d4             	mov    %rdx,%r12
    5cf6:	49 c1 fe 20          	sar    $0x20,%r14
    5cfa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5d01:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5d07:	48 85 ed             	test   %rbp,%rbp
    5d0a:	0f 84 48 03 00 00    	je     6058 <fwp_p_ad_push+0x3b8>
    5d10:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    5d14:	0f 84 be 02 00 00    	je     5fd8 <fwp_p_ad_push+0x338>
    5d1a:	4c 89 f7             	mov    %r14,%rdi
    5d1d:	e8 5e e7 ff ff       	call   4480 <fwp_tape_of>
    5d22:	48 89 c3             	mov    %rax,%rbx
    5d25:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5d2a:	0f 85 3e 03 00 00    	jne    606e <fwp_p_ad_push+0x3ce>
    5d30:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    5d34:	48 89 45 08          	mov    %rax,0x8(%rbp)
    5d38:	4c 8b 43 10          	mov    0x10(%rbx),%r8
    5d3c:	49 81 f8 fe ff ff 7f 	cmp    $0x7ffffffe,%r8
    5d43:	0f 8f cd 03 00 00    	jg     6116 <fwp_p_ad_push+0x476>
    5d49:	44 89 e0             	mov    %r12d,%eax
    5d4c:	4c 39 c0             	cmp    %r8,%rax
    5d4f:	0f 8d b5 03 00 00    	jge    610a <fwp_p_ad_push+0x46a>
    5d55:	4d 85 ed             	test   %r13,%r13
    5d58:	78 0c                	js     5d66 <fwp_p_ad_push+0xc6>
    5d5a:	44 89 e8             	mov    %r13d,%eax
    5d5d:	4c 39 c0             	cmp    %r8,%rax
    5d60:	0f 8d a4 03 00 00    	jge    610a <fwp_p_ad_push+0x46a>
    5d66:	4d 89 c7             	mov    %r8,%r15
    5d69:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    5d6d:	49 8d 47 01          	lea    0x1(%r15),%rax
    5d71:	4c 89 f9             	mov    %r15,%rcx
    5d74:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5d7a:	0f 87 96 03 00 00    	ja     6116 <fwp_p_ad_push+0x476>
    5d80:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5d84:	48 39 e8             	cmp    %rbp,%rax
    5d87:	0f 8e 23 02 00 00    	jle    5fb0 <fwp_p_ad_push+0x310>
    5d8d:	48 85 ed             	test   %rbp,%rbp
    5d90:	ba 40 00 00 00       	mov    $0x40,%edx
    5d95:	48 0f 44 ea          	cmove  %rdx,%rbp
    5d99:	48 39 e8             	cmp    %rbp,%rax
    5d9c:	7e 22                	jle    5dc0 <fwp_p_ad_push+0x120>
    5d9e:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5da5:	0f 8f f5 01 00 00    	jg     5fa0 <fwp_p_ad_push+0x300>
    5dab:	48 01 ed             	add    %rbp,%rbp
    5dae:	48 39 e8             	cmp    %rbp,%rax
    5db1:	7f eb                	jg     5d9e <fwp_p_ad_push+0xfe>
    5db3:	66 90                	xchg   %ax,%ax
    5db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dbc:	00 00 00 00 
    5dc0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5dc7:	00 
    5dc8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5dcc:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5dd1:	48 89 c6             	mov    %rax,%rsi
    5dd4:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5dd9:	4c 8b 73 60          	mov    0x60(%rbx),%r14
    5ddd:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5de2:	e8 e9 d7 ff ff       	call   35d0 <realloc@plt>
    5de7:	48 85 c0             	test   %rax,%rax
    5dea:	0f 84 32 03 00 00    	je     6122 <fwp_p_ad_push+0x482>
    5df0:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    5df4:	4d 85 f6             	test   %r14,%r14
    5df7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    5dfc:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5e00:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5e05:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5e09:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    5e0d:	0f 84 d5 01 00 00    	je     5fe8 <fwp_p_ad_push+0x348>
    5e13:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5e17:	48 39 ea             	cmp    %rbp,%rdx
    5e1a:	0f 8d bb 00 00 00    	jge    5edb <fwp_p_ad_push+0x23b>
    5e20:	49 8b 76 40          	mov    0x40(%r14),%rsi
    5e24:	48 89 ef             	mov    %rbp,%rdi
    5e27:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5e2c:	48 c1 e7 04          	shl    $0x4,%rdi
    5e30:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5e35:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    5e3a:	be 02 00 00 00       	mov    $0x2,%esi
    5e3f:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    5e44:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    5e49:	e8 02 fc ff ff       	call   5a50 <fwp_heap_alloc>
    5e4e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    5e53:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5e58:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5e5d:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5e62:	48 85 f6             	test   %rsi,%rsi
    5e65:	74 31                	je     5e98 <fwp_p_ad_push+0x1f8>
    5e67:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    5e6c:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    5e71:	48 c1 e2 04          	shl    $0x4,%rdx
    5e75:	48 39 fa             	cmp    %rdi,%rdx
    5e78:	48 0f 47 d7          	cmova  %rdi,%rdx
    5e7c:	48 89 c7             	mov    %rax,%rdi
    5e7f:	e8 1c d7 ff ff       	call   35a0 <memcpy@plt>
    5e84:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    5e89:	e8 c2 f6 ff ff       	call   5550 <fwp_mem_free>
    5e8e:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5e93:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5e98:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5e9c:	48 89 ea             	mov    %rbp,%rdx
    5e9f:	31 f6                	xor    %esi,%esi
    5ea1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    5ea6:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5eab:	48 29 fa             	sub    %rdi,%rdx
    5eae:	48 c1 e7 04          	shl    $0x4,%rdi
    5eb2:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    5eb7:	48 c1 e2 04          	shl    $0x4,%rdx
    5ebb:	e8 00 d6 ff ff       	call   34c0 <memset@plt>
    5ec0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5ec5:	49 89 6e 60          	mov    %rbp,0x60(%r14)
    5ec9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    5ece:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    5ed3:	49 89 46 40          	mov    %rax,0x40(%r14)
    5ed7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    5edb:	4d 85 ff             	test   %r15,%r15
    5ede:	0f 85 9c 01 00 00    	jne    6080 <fwp_p_ad_push+0x3e0>
    5ee4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    5ee8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5eec:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    5ef3:	00 
    5ef4:	49 01 c6             	add    %rax,%r14
    5ef7:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5efb:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    5eff:	46 89 24 38          	mov    %r12d,(%rax,%r15,1)
    5f03:	4d 85 ed             	test   %r13,%r13
    5f06:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5f0c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f13:	4c 0f 48 e8          	cmovs  %rax,%r13
    5f17:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5f1c:	49 8d 40 01          	lea    0x1(%r8),%rax
    5f20:	f2 0f 11 0c 0a       	movsd  %xmm1,(%rdx,%rcx,1)
    5f25:	47 89 2c 3e          	mov    %r13d,(%r14,%r15,1)
    5f29:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    5f2e:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5f32:	48 83 c4 48          	add    $0x48,%rsp
    5f36:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f3d:	ff ff ff 
    5f40:	4c 21 e0             	and    %r12,%rax
    5f43:	5b                   	pop    %rbx
    5f44:	5d                   	pop    %rbp
    5f45:	4c 09 c0             	or     %r8,%rax
    5f48:	41 5c                	pop    %r12
    5f4a:	41 5d                	pop    %r13
    5f4c:	41 5e                	pop    %r14
    5f4e:	41 5f                	pop    %r15
    5f50:	c3                   	ret
    5f51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5f58:	48 c1 fa 20          	sar    $0x20,%rdx
    5f5c:	48 c1 ff 20          	sar    $0x20,%rdi
    5f60:	49 89 d6             	mov    %rdx,%r14
    5f63:	48 39 d7             	cmp    %rdx,%rdi
    5f66:	0f 84 9b fd ff ff    	je     5d07 <fwp_p_ad_push+0x67>
    5f6c:	48 8d 3d 55 98 00 00 	lea    0x9855(%rip),%rdi        # f7c8 <_IO_stdin_used+0x7c8>
    5f73:	e8 28 e2 ff ff       	call   41a0 <fwp_trap>
    5f78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5f7f:	00 
    5f80:	48 83 c4 48          	add    $0x48,%rsp
    5f84:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f8b:	5b                   	pop    %rbx
    5f8c:	5d                   	pop    %rbp
    5f8d:	41 5c                	pop    %r12
    5f8f:	41 5d                	pop    %r13
    5f91:	41 5e                	pop    %r14
    5f93:	41 5f                	pop    %r15
    5f95:	c3                   	ret
    5f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5f9d:	00 00 00 
    5fa0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5fa5:	e9 16 fe ff ff       	jmp    5dc0 <fwp_p_ad_push+0x120>
    5faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5fb0:	48 8b 43 20          	mov    0x20(%rbx),%rax
    5fb4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    5fb8:	48 c1 e1 03          	shl    $0x3,%rcx
    5fbc:	4e 8d 3c bd 00 00 00 	lea    0x0(,%r15,4),%r15
    5fc3:	00 
    5fc4:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    5fc8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5fcc:	e9 2e ff ff ff       	jmp    5eff <fwp_p_ad_push+0x25f>
    5fd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fd8:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    5fdc:	e9 57 fd ff ff       	jmp    5d38 <fwp_p_ad_push+0x98>
    5fe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fe8:	49 89 ee             	mov    %rbp,%r14
    5feb:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5fef:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5ff4:	49 c1 e6 04          	shl    $0x4,%r14
    5ff8:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5ffd:	4c 89 f6             	mov    %r14,%rsi
    6000:	e8 cb d5 ff ff       	call   35d0 <realloc@plt>
    6005:	48 89 c2             	mov    %rax,%rdx
    6008:	48 85 c0             	test   %rax,%rax
    600b:	0f 84 11 01 00 00    	je     6122 <fwp_p_ad_push+0x482>
    6011:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6015:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6019:	4d 85 ff             	test   %r15,%r15
    601c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6021:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6026:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    602a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    602f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6033:	48 8d 3c 02          	lea    (%rdx,%rax,1),%rdi
    6037:	0f 85 98 00 00 00    	jne    60d5 <fwp_p_ad_push+0x435>
    603d:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6041:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6045:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    604c:	00 
    604d:	45 31 ff             	xor    %r15d,%r15d
    6050:	e9 9f fe ff ff       	jmp    5ef4 <fwp_p_ad_push+0x254>
    6055:	0f 1f 00             	nopl   (%rax)
    6058:	4c 89 f7             	mov    %r14,%rdi
    605b:	e8 20 e4 ff ff       	call   4480 <fwp_tape_of>
    6060:	48 89 c3             	mov    %rax,%rbx
    6063:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6068:	0f 84 ca fc ff ff    	je     5d38 <fwp_p_ad_push+0x98>
    606e:	48 8d 3d 9b 97 00 00 	lea    0x979b(%rip),%rdi        # f810 <_IO_stdin_used+0x810>
    6075:	e8 26 e1 ff ff       	call   41a0 <fwp_trap>
    607a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6080:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
    6087:	00 
    6088:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    608d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6091:	49 c1 e7 02          	shl    $0x2,%r15
    6095:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    609a:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    60a1:	00 
    60a2:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    60a6:	4c 89 fa             	mov    %r15,%rdx
    60a9:	e8 62 d5 ff ff       	call   3610 <memmove@plt>
    60ae:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60b2:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    60b6:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    60ba:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    60bf:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    60c4:	e9 2b fe ff ff       	jmp    5ef4 <fwp_p_ad_push+0x254>
    60c9:	48 c1 ff 20          	sar    $0x20,%rdi
    60cd:	49 89 fe             	mov    %rdi,%r14
    60d0:	e9 32 fc ff ff       	jmp    5d07 <fwp_p_ad_push+0x67>
    60d5:	4c 39 f0             	cmp    %r14,%rax
    60d8:	4c 89 f1             	mov    %r14,%rcx
    60db:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
    60e2:	00 
    60e3:	49 89 c6             	mov    %rax,%r14
    60e6:	48 0f 43 c8          	cmovae %rax,%rcx
    60ea:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    60ef:	48 29 c1             	sub    %rax,%rcx
    60f2:	e8 69 d4 ff ff       	call   3560 <__memmove_chk@plt>
    60f7:	4c 03 73 30          	add    0x30(%rbx),%r14
    60fb:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60ff:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6103:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6108:	eb 83                	jmp    608d <fwp_p_ad_push+0x3ed>
    610a:	48 8d 3d f3 8f 00 00 	lea    0x8ff3(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    6111:	e8 8a e0 ff ff       	call   41a0 <fwp_trap>
    6116:	48 8d 3d cc 8f 00 00 	lea    0x8fcc(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    611d:	e8 7e e0 ff ff       	call   41a0 <fwp_trap>
    6122:	48 89 df             	mov    %rbx,%rdi
    6125:	e8 d6 da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    612a:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    612e:	e8 8d d2 ff ff       	call   33c0 <free@plt>
    6133:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6137:	e8 84 d2 ff ff       	call   33c0 <free@plt>
    613c:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6140:	e8 7b d2 ff ff       	call   33c0 <free@plt>
    6145:	31 c9                	xor    %ecx,%ecx
    6147:	31 c0                	xor    %eax,%eax
    6149:	31 d2                	xor    %edx,%edx
    614b:	89 53 04             	mov    %edx,0x4(%rbx)
    614e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6152:	ba 13 00 00 00       	mov    $0x13,%edx
    6157:	be 01 00 00 00       	mov    $0x1,%esi
    615c:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6160:	48 8d 3d a1 8e 00 00 	lea    0x8ea1(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6167:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    616b:	48 8b 0d ce ce 00 00 	mov    0xcece(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    6172:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6176:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    617a:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    617e:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6182:	e8 f9 d4 ff ff       	call   3680 <fwrite@plt>
    6187:	31 ff                	xor    %edi,%edi
    6189:	e8 32 d4 ff ff       	call   35c0 <fflush@plt>
    618e:	bf 66 00 00 00       	mov    $0x66,%edi
    6193:	e8 08 d5 ff ff       	call   36a0 <_Exit@plt>
    6198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    619f:	00 

00000000000061a0 <w120>:
    61a0:	41 56                	push   %r14
    61a2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    61a6:	48 89 fa             	mov    %rdi,%rdx
    61a9:	41 55                	push   %r13
    61ab:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    61af:	49 89 fd             	mov    %rdi,%r13
    61b2:	41 54                	push   %r12
    61b4:	55                   	push   %rbp
    61b5:	53                   	push   %rbx
    61b6:	48 83 ec 40          	sub    $0x40,%rsp
    61ba:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    61c0:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    61c5:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    61cc:	00 00 
    61ce:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    61d3:	48 89 f5             	mov    %rsi,%rbp
    61d6:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    61db:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    61e1:	48 89 f1             	mov    %rsi,%rcx
    61e4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61ea:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    61f1:	ff ff 
    61f3:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    61fa:	00 00 
    61fc:	e8 9f fa ff ff       	call   5ca0 <fwp_p_ad_push>
    6201:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6207:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    620c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6212:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6219:	00 f0 3f 
    621c:	48 89 c7             	mov    %rax,%rdi
    621f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6226:	00 f0 bf 
    6229:	48 89 ea             	mov    %rbp,%rdx
    622c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6231:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6237:	e8 64 fa ff ff       	call   5ca0 <fwp_p_ad_push>
    623c:	f2 0f 10 05 64 98 00 	movsd  0x9864(%rip),%xmm0        # faa8 <msg.4+0x28>
    6243:	00 
    6244:	4c 89 ef             	mov    %r13,%rdi
    6247:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    624d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6252:	49 89 c6             	mov    %rax,%r14
    6255:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    625c:	00 f0 3f 
    625f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6266:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    626d:	00 f0 bf 
    6270:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    6275:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    627b:	e8 20 fa ff ff       	call   5ca0 <fwp_p_ad_push>
    6280:	4c 89 e1             	mov    %r12,%rcx
    6283:	4c 89 e6             	mov    %r12,%rsi
    6286:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    628b:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6291:	4c 89 f2             	mov    %r14,%rdx
    6294:	4c 89 f7             	mov    %r14,%rdi
    6297:	49 89 c5             	mov    %rax,%r13
    629a:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    629e:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    62a4:	e8 f7 f9 ff ff       	call   5ca0 <fwp_p_ad_push>
    62a9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    62af:	f2 0f 59 1d f9 97 00 	mulsd  0x97f9(%rip),%xmm3        # fab0 <msg.4+0x30>
    62b6:	00 
    62b7:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    62bc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    62c1:	48 89 c2             	mov    %rax,%rdx
    62c4:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    62cb:	00 59 40 
    62ce:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    62d5:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    62db:	e8 c0 f9 ff ff       	call   5ca0 <fwp_p_ad_push>
    62e0:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    62e5:	48 89 e9             	mov    %rbp,%rcx
    62e8:	4c 89 ea             	mov    %r13,%rdx
    62eb:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    62f1:	48 89 ee             	mov    %rbp,%rsi
    62f4:	4c 89 ef             	mov    %r13,%rdi
    62f7:	49 89 c4             	mov    %rax,%r12
    62fa:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    62fe:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6304:	e8 97 f9 ff ff       	call   5ca0 <fwp_p_ad_push>
    6309:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    630f:	45 31 c0             	xor    %r8d,%r8d
    6312:	4c 89 e2             	mov    %r12,%rdx
    6315:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    631b:	48 89 c7             	mov    %rax,%rdi
    631e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6325:	00 f0 3f 
    6328:	48 89 ce             	mov    %rcx,%rsi
    632b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6330:	e8 6b f9 ff ff       	call   5ca0 <fwp_p_ad_push>
    6335:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    633a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6341:	00 00 
    6343:	75 12                	jne    6357 <w120+0x1b7>
    6345:	48 83 c4 40          	add    $0x40,%rsp
    6349:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    634e:	5b                   	pop    %rbx
    634f:	5d                   	pop    %rbp
    6350:	41 5c                	pop    %r12
    6352:	41 5d                	pop    %r13
    6354:	41 5e                	pop    %r14
    6356:	c3                   	ret
    6357:	e8 04 d1 ff ff       	call   3460 <__stack_chk_fail@plt>
    635c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006360 <w176.constprop.0>:
    6360:	41 54                	push   %r12
    6362:	55                   	push   %rbp
    6363:	53                   	push   %rbx
    6364:	48 83 ec 10          	sub    $0x10,%rsp
    6368:	4c 8b 27             	mov    (%rdi),%r12
    636b:	4d 85 e4             	test   %r12,%r12
    636e:	74 58                	je     63c8 <w176.constprop.0+0x68>
    6370:	48 89 fd             	mov    %rdi,%rbp
    6373:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6377:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    637e:	31 db                	xor    %ebx,%ebx
    6380:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6386:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    638b:	45 31 c0             	xor    %r8d,%r8d
    638e:	48 83 c3 02          	add    $0x2,%rbx
    6392:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6399:	00 f0 3f 
    639c:	48 89 ce             	mov    %rcx,%rsi
    639f:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    63a5:	e8 f6 f8 ff ff       	call   5ca0 <fwp_p_ad_push>
    63aa:	4c 39 e3             	cmp    %r12,%rbx
    63ad:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    63b3:	48 89 c7             	mov    %rax,%rdi
    63b6:	72 c8                	jb     6380 <w176.constprop.0+0x20>
    63b8:	48 83 c4 10          	add    $0x10,%rsp
    63bc:	48 89 f8             	mov    %rdi,%rax
    63bf:	5b                   	pop    %rbx
    63c0:	5d                   	pop    %rbp
    63c1:	41 5c                	pop    %r12
    63c3:	c3                   	ret
    63c4:	0f 1f 40 00          	nopl   0x0(%rax)
    63c8:	48 83 c4 10          	add    $0x10,%rsp
    63cc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63d3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    63d7:	5b                   	pop    %rbx
    63d8:	48 89 f8             	mov    %rdi,%rax
    63db:	5d                   	pop    %rbp
    63dc:	41 5c                	pop    %r12
    63de:	c3                   	ret
    63df:	90                   	nop

00000000000063e0 <fwp_rc_share>:
    63e0:	48 8b 05 51 e7 01 00 	mov    0x1e751(%rip),%rax        # 24b38 <fwp_heap+0x13d8>
    63e7:	48 2b 3d 22 e7 01 00 	sub    0x1e722(%rip),%rdi        # 24b10 <fwp_heap+0x13b0>
    63ee:	48 c1 e0 10          	shl    $0x10,%rax
    63f2:	48 39 c7             	cmp    %rax,%rdi
    63f5:	73 4a                	jae    6441 <fwp_rc_share+0x61>
    63f7:	48 89 f8             	mov    %rdi,%rax
    63fa:	48 c1 e8 10          	shr    $0x10,%rax
    63fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6402:	48 8b 05 4f e7 01 00 	mov    0x1e74f(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    6409:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    640d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6411:	48 85 d2             	test   %rdx,%rdx
    6414:	74 2b                	je     6441 <fwp_rc_share+0x61>
    6416:	0f b6 08             	movzbl (%rax),%ecx
    6419:	80 f9 02             	cmp    $0x2,%cl
    641c:	74 2a                	je     6448 <fwp_rc_share+0x68>
    641e:	80 f9 01             	cmp    $0x1,%cl
    6421:	75 1e                	jne    6441 <fwp_rc_share+0x61>
    6423:	8b 48 18             	mov    0x18(%rax),%ecx
    6426:	0f b7 ff             	movzwl %di,%edi
    6429:	8b 40 1c             	mov    0x1c(%rax),%eax
    642c:	48 0f af f9          	imul   %rcx,%rdi
    6430:	48 c1 ef 20          	shr    $0x20,%rdi
    6434:	48 39 c7             	cmp    %rax,%rdi
    6437:	73 08                	jae    6441 <fwp_rc_share+0x61>
    6439:	48 01 fa             	add    %rdi,%rdx
    643c:	80 3a 00             	cmpb   $0x0,(%rdx)
    643f:	75 0d                	jne    644e <fwp_rc_share+0x6e>
    6441:	c3                   	ret
    6442:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6448:	66 85 ff             	test   %di,%di
    644b:	74 ef                	je     643c <fwp_rc_share+0x5c>
    644d:	c3                   	ret
    644e:	50                   	push   %rax
    644f:	48 8d 3d ea 93 00 00 	lea    0x93ea(%rip),%rdi        # f840 <_IO_stdin_used+0x840>
    6456:	e8 45 dd ff ff       	call   41a0 <fwp_trap>
    645b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006460 <fwp_rc_fresh>:
    6460:	48 8b 15 d1 e6 01 00 	mov    0x1e6d1(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    6467:	48 89 f8             	mov    %rdi,%rax
    646a:	48 89 fe             	mov    %rdi,%rsi
    646d:	48 2b 05 9c e6 01 00 	sub    0x1e69c(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6474:	48 c1 e2 10          	shl    $0x10,%rdx
    6478:	48 39 d0             	cmp    %rdx,%rax
    647b:	73 4f                	jae    64cc <fwp_rc_fresh+0x6c>
    647d:	48 89 c2             	mov    %rax,%rdx
    6480:	48 c1 ea 10          	shr    $0x10,%rdx
    6484:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6488:	48 8b 15 c9 e6 01 00 	mov    0x1e6c9(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    648f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6493:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6497:	48 85 d2             	test   %rdx,%rdx
    649a:	74 30                	je     64cc <fwp_rc_fresh+0x6c>
    649c:	0f b6 39             	movzbl (%rcx),%edi
    649f:	40 80 ff 02          	cmp    $0x2,%dil
    64a3:	74 2b                	je     64d0 <fwp_rc_fresh+0x70>
    64a5:	40 80 ff 01          	cmp    $0x1,%dil
    64a9:	75 21                	jne    64cc <fwp_rc_fresh+0x6c>
    64ab:	8b 79 18             	mov    0x18(%rcx),%edi
    64ae:	0f b7 c0             	movzwl %ax,%eax
    64b1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    64b4:	48 0f af c7          	imul   %rdi,%rax
    64b8:	48 c1 e8 20          	shr    $0x20,%rax
    64bc:	48 39 c8             	cmp    %rcx,%rax
    64bf:	73 0b                	jae    64cc <fwp_rc_fresh+0x6c>
    64c1:	48 01 c2             	add    %rax,%rdx
    64c4:	80 3a ff             	cmpb   $0xff,(%rdx)
    64c7:	74 17                	je     64e0 <fwp_rc_fresh+0x80>
    64c9:	c6 02 01             	movb   $0x1,(%rdx)
    64cc:	48 89 f0             	mov    %rsi,%rax
    64cf:	c3                   	ret
    64d0:	66 85 c0             	test   %ax,%ax
    64d3:	74 ef                	je     64c4 <fwp_rc_fresh+0x64>
    64d5:	48 89 f0             	mov    %rsi,%rax
    64d8:	c3                   	ret
    64d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    64e0:	48 83 ec 18          	sub    $0x18,%rsp
    64e4:	48 89 d7             	mov    %rdx,%rdi
    64e7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    64ec:	48 89 14 24          	mov    %rdx,(%rsp)
    64f0:	e8 1b ee ff ff       	call   5310 <fwp_rc_forget_slot>
    64f5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    64fa:	48 8b 14 24          	mov    (%rsp),%rdx
    64fe:	48 89 f0             	mov    %rsi,%rax
    6501:	c6 02 01             	movb   $0x1,(%rdx)
    6504:	48 83 c4 18          	add    $0x18,%rsp
    6508:	c3                   	ret
    6509:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006510 <fwp_rc_free_obj>:
    6510:	48 8b 15 21 e6 01 00 	mov    0x1e621(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    6517:	48 89 f8             	mov    %rdi,%rax
    651a:	48 2b 05 ef e5 01 00 	sub    0x1e5ef(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6521:	48 c1 e2 10          	shl    $0x10,%rdx
    6525:	48 39 d0             	cmp    %rdx,%rax
    6528:	73 5b                	jae    6585 <fwp_rc_free_obj+0x75>
    652a:	48 89 c2             	mov    %rax,%rdx
    652d:	48 c1 ea 10          	shr    $0x10,%rdx
    6531:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6535:	48 8b 15 1c e6 01 00 	mov    0x1e61c(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    653c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6540:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6544:	48 85 c9             	test   %rcx,%rcx
    6547:	74 3c                	je     6585 <fwp_rc_free_obj+0x75>
    6549:	0f b6 32             	movzbl (%rdx),%esi
    654c:	40 80 fe 02          	cmp    $0x2,%sil
    6550:	74 2e                	je     6580 <fwp_rc_free_obj+0x70>
    6552:	40 80 fe 01          	cmp    $0x1,%sil
    6556:	75 2d                	jne    6585 <fwp_rc_free_obj+0x75>
    6558:	8b 72 18             	mov    0x18(%rdx),%esi
    655b:	0f b7 c0             	movzwl %ax,%eax
    655e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6561:	48 0f af c6          	imul   %rsi,%rax
    6565:	48 c1 e8 20          	shr    $0x20,%rax
    6569:	48 39 d0             	cmp    %rdx,%rax
    656c:	73 17                	jae    6585 <fwp_rc_free_obj+0x75>
    656e:	48 01 c1             	add    %rax,%rcx
    6571:	80 39 01             	cmpb   $0x1,(%rcx)
    6574:	75 0f                	jne    6585 <fwp_rc_free_obj+0x75>
    6576:	e9 d5 ef ff ff       	jmp    5550 <fwp_mem_free>
    657b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6580:	66 85 c0             	test   %ax,%ax
    6583:	74 ec                	je     6571 <fwp_rc_free_obj+0x61>
    6585:	c3                   	ret
    6586:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    658d:	00 00 00 

0000000000006590 <fwp_rc_dup>:
    6590:	f3 0f 1e fa          	endbr64
    6594:	48 8b 05 9d e5 01 00 	mov    0x1e59d(%rip),%rax        # 24b38 <fwp_heap+0x13d8>
    659b:	48 2b 3d 6e e5 01 00 	sub    0x1e56e(%rip),%rdi        # 24b10 <fwp_heap+0x13b0>
    65a2:	48 c1 e0 10          	shl    $0x10,%rax
    65a6:	48 39 c7             	cmp    %rax,%rdi
    65a9:	73 56                	jae    6601 <fwp_rc_dup+0x71>
    65ab:	48 89 f8             	mov    %rdi,%rax
    65ae:	48 c1 e8 10          	shr    $0x10,%rax
    65b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    65b6:	48 8b 05 9b e5 01 00 	mov    0x1e59b(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    65bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    65c1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    65c5:	48 85 c0             	test   %rax,%rax
    65c8:	74 37                	je     6601 <fwp_rc_dup+0x71>
    65ca:	0f b6 0a             	movzbl (%rdx),%ecx
    65cd:	80 f9 02             	cmp    $0x2,%cl
    65d0:	74 36                	je     6608 <fwp_rc_dup+0x78>
    65d2:	80 f9 01             	cmp    $0x1,%cl
    65d5:	75 2a                	jne    6601 <fwp_rc_dup+0x71>
    65d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    65da:	0f b7 ff             	movzwl %di,%edi
    65dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65e0:	48 0f af f9          	imul   %rcx,%rdi
    65e4:	48 c1 ef 20          	shr    $0x20,%rdi
    65e8:	48 39 d7             	cmp    %rdx,%rdi
    65eb:	73 14                	jae    6601 <fwp_rc_dup+0x71>
    65ed:	48 01 f8             	add    %rdi,%rax
    65f0:	0f b6 10             	movzbl (%rax),%edx
    65f3:	84 d2                	test   %dl,%dl
    65f5:	74 0a                	je     6601 <fwp_rc_dup+0x71>
    65f7:	80 fa fd             	cmp    $0xfd,%dl
    65fa:	77 14                	ja     6610 <fwp_rc_dup+0x80>
    65fc:	83 c2 01             	add    $0x1,%edx
    65ff:	88 10                	mov    %dl,(%rax)
    6601:	c3                   	ret
    6602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6608:	66 85 ff             	test   %di,%di
    660b:	74 e3                	je     65f0 <fwp_rc_dup+0x60>
    660d:	c3                   	ret
    660e:	66 90                	xchg   %ax,%ax
    6610:	48 89 c7             	mov    %rax,%rdi
    6613:	e9 d8 eb ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    661f:	00 

0000000000006620 <fwp_owned_entry173>:
    6620:	f3 0f 1e fa          	endbr64
    6624:	48 83 ec 38          	sub    $0x38,%rsp
    6628:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    662d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6634:	00 00 
    6636:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    663b:	31 c0                	xor    %eax,%eax
    663d:	48 8b 07             	mov    (%rdi),%rax
    6640:	48 03 47 10          	add    0x10(%rdi),%rax
    6644:	0f 80 c2 00 00 00    	jo     670c <fwp_owned_entry173+0xec>
    664a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    664f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6654:	31 ff                	xor    %edi,%edi
    6656:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    665a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    665f:	e8 0c f5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6664:	48 8b 15 cd e4 01 00 	mov    0x1e4cd(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    666b:	48 89 c6             	mov    %rax,%rsi
    666e:	48 2b 05 9b e4 01 00 	sub    0x1e49b(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6675:	48 c1 e2 10          	shl    $0x10,%rdx
    6679:	48 39 d0             	cmp    %rdx,%rax
    667c:	73 4f                	jae    66cd <fwp_owned_entry173+0xad>
    667e:	48 89 c2             	mov    %rax,%rdx
    6681:	48 c1 ea 10          	shr    $0x10,%rdx
    6685:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6689:	48 8b 15 c8 e4 01 00 	mov    0x1e4c8(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    6690:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6694:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6698:	48 85 d2             	test   %rdx,%rdx
    669b:	74 30                	je     66cd <fwp_owned_entry173+0xad>
    669d:	0f b6 39             	movzbl (%rcx),%edi
    66a0:	40 80 ff 02          	cmp    $0x2,%dil
    66a4:	74 42                	je     66e8 <fwp_owned_entry173+0xc8>
    66a6:	40 80 ff 01          	cmp    $0x1,%dil
    66aa:	75 21                	jne    66cd <fwp_owned_entry173+0xad>
    66ac:	8b 79 18             	mov    0x18(%rcx),%edi
    66af:	0f b7 c0             	movzwl %ax,%eax
    66b2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    66b5:	48 0f af c7          	imul   %rdi,%rax
    66b9:	48 c1 e8 20          	shr    $0x20,%rax
    66bd:	48 39 c8             	cmp    %rcx,%rax
    66c0:	73 0b                	jae    66cd <fwp_owned_entry173+0xad>
    66c2:	48 01 c2             	add    %rax,%rdx
    66c5:	80 3a ff             	cmpb   $0xff,(%rdx)
    66c8:	74 26                	je     66f0 <fwp_owned_entry173+0xd0>
    66ca:	c6 02 01             	movb   $0x1,(%rdx)
    66cd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    66d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    66d9:	00 00 
    66db:	75 34                	jne    6711 <fwp_owned_entry173+0xf1>
    66dd:	48 89 f0             	mov    %rsi,%rax
    66e0:	48 83 c4 38          	add    $0x38,%rsp
    66e4:	c3                   	ret
    66e5:	0f 1f 00             	nopl   (%rax)
    66e8:	66 85 c0             	test   %ax,%ax
    66eb:	75 e0                	jne    66cd <fwp_owned_entry173+0xad>
    66ed:	eb d6                	jmp    66c5 <fwp_owned_entry173+0xa5>
    66ef:	90                   	nop
    66f0:	48 89 d7             	mov    %rdx,%rdi
    66f3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    66f8:	48 89 14 24          	mov    %rdx,(%rsp)
    66fc:	e8 0f ec ff ff       	call   5310 <fwp_rc_forget_slot>
    6701:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6706:	48 8b 14 24          	mov    (%rsp),%rdx
    670a:	eb be                	jmp    66ca <fwp_owned_entry173+0xaa>
    670c:	e8 ef cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6711:	e8 4a cd ff ff       	call   3460 <__stack_chk_fail@plt>
    6716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    671d:	00 00 00 

0000000000006720 <e173>:
    6720:	f3 0f 1e fa          	endbr64
    6724:	53                   	push   %rbx
    6725:	48 83 ec 30          	sub    $0x30,%rsp
    6729:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    672e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6735:	00 00 
    6737:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    673c:	31 c0                	xor    %eax,%eax
    673e:	48 8b 07             	mov    (%rdi),%rax
    6741:	48 03 47 10          	add    0x10(%rdi),%rax
    6745:	0f 80 c9 00 00 00    	jo     6814 <e173+0xf4>
    674b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6750:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6755:	31 ff                	xor    %edi,%edi
    6757:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    675b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6760:	e8 0b f4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6765:	48 8b 15 cc e3 01 00 	mov    0x1e3cc(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    676c:	48 89 c3             	mov    %rax,%rbx
    676f:	48 2b 05 9a e3 01 00 	sub    0x1e39a(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6776:	48 c1 e2 10          	shl    $0x10,%rdx
    677a:	48 39 d0             	cmp    %rdx,%rax
    677d:	73 4f                	jae    67ce <e173+0xae>
    677f:	48 89 c2             	mov    %rax,%rdx
    6782:	48 c1 ea 10          	shr    $0x10,%rdx
    6786:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    678a:	48 8b 15 c7 e3 01 00 	mov    0x1e3c7(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    6791:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6795:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6799:	48 85 d2             	test   %rdx,%rdx
    679c:	74 30                	je     67ce <e173+0xae>
    679e:	0f b6 31             	movzbl (%rcx),%esi
    67a1:	40 80 fe 02          	cmp    $0x2,%sil
    67a5:	74 49                	je     67f0 <e173+0xd0>
    67a7:	40 80 fe 01          	cmp    $0x1,%sil
    67ab:	75 21                	jne    67ce <e173+0xae>
    67ad:	8b 71 18             	mov    0x18(%rcx),%esi
    67b0:	0f b7 c0             	movzwl %ax,%eax
    67b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    67b6:	48 0f af c6          	imul   %rsi,%rax
    67ba:	48 c1 e8 20          	shr    $0x20,%rax
    67be:	48 39 c8             	cmp    %rcx,%rax
    67c1:	73 0b                	jae    67ce <e173+0xae>
    67c3:	48 01 c2             	add    %rax,%rdx
    67c6:	80 3a ff             	cmpb   $0xff,(%rdx)
    67c9:	74 35                	je     6800 <e173+0xe0>
    67cb:	c6 02 01             	movb   $0x1,(%rdx)
    67ce:	48 89 df             	mov    %rbx,%rdi
    67d1:	e8 0a fc ff ff       	call   63e0 <fwp_rc_share>
    67d6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    67db:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    67e2:	00 00 
    67e4:	75 33                	jne    6819 <e173+0xf9>
    67e6:	48 83 c4 30          	add    $0x30,%rsp
    67ea:	48 89 d8             	mov    %rbx,%rax
    67ed:	5b                   	pop    %rbx
    67ee:	c3                   	ret
    67ef:	90                   	nop
    67f0:	66 85 c0             	test   %ax,%ax
    67f3:	75 d9                	jne    67ce <e173+0xae>
    67f5:	eb cf                	jmp    67c6 <e173+0xa6>
    67f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    67fe:	00 00 
    6800:	48 89 d7             	mov    %rdx,%rdi
    6803:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6808:	e8 03 eb ff ff       	call   5310 <fwp_rc_forget_slot>
    680d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6812:	eb b7                	jmp    67cb <e173+0xab>
    6814:	e8 e7 ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6819:	e8 42 cc ff ff       	call   3460 <__stack_chk_fail@plt>
    681e:	66 90                	xchg   %ax,%ax

0000000000006820 <fwp_closure_drop>:
    6820:	48 8b 15 11 e3 01 00 	mov    0x1e311(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    6827:	48 89 f8             	mov    %rdi,%rax
    682a:	48 2b 05 df e2 01 00 	sub    0x1e2df(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6831:	48 c1 e2 10          	shl    $0x10,%rdx
    6835:	48 39 d0             	cmp    %rdx,%rax
    6838:	73 6b                	jae    68a5 <fwp_closure_drop+0x85>
    683a:	48 89 c2             	mov    %rax,%rdx
    683d:	48 c1 ea 10          	shr    $0x10,%rdx
    6841:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6845:	48 8b 15 0c e3 01 00 	mov    0x1e30c(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    684c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6850:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6854:	48 85 d2             	test   %rdx,%rdx
    6857:	74 4c                	je     68a5 <fwp_closure_drop+0x85>
    6859:	0f b6 31             	movzbl (%rcx),%esi
    685c:	40 80 fe 02          	cmp    $0x2,%sil
    6860:	74 3e                	je     68a0 <fwp_closure_drop+0x80>
    6862:	40 80 fe 01          	cmp    $0x1,%sil
    6866:	75 3d                	jne    68a5 <fwp_closure_drop+0x85>
    6868:	8b 71 18             	mov    0x18(%rcx),%esi
    686b:	0f b7 c0             	movzwl %ax,%eax
    686e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6871:	48 0f af c6          	imul   %rsi,%rax
    6875:	48 c1 e8 20          	shr    $0x20,%rax
    6879:	48 39 c8             	cmp    %rcx,%rax
    687c:	73 27                	jae    68a5 <fwp_closure_drop+0x85>
    687e:	48 01 c2             	add    %rax,%rdx
    6881:	0f b6 02             	movzbl (%rdx),%eax
    6884:	84 c0                	test   %al,%al
    6886:	74 1d                	je     68a5 <fwp_closure_drop+0x85>
    6888:	3c 01                	cmp    $0x1,%al
    688a:	74 24                	je     68b0 <fwp_closure_drop+0x90>
    688c:	3c ff                	cmp    $0xff,%al
    688e:	74 48                	je     68d8 <fwp_closure_drop+0xb8>
    6890:	83 e8 01             	sub    $0x1,%eax
    6893:	88 02                	mov    %al,(%rdx)
    6895:	c3                   	ret
    6896:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    689d:	00 00 00 
    68a0:	66 85 c0             	test   %ax,%ax
    68a3:	74 dc                	je     6881 <fwp_closure_drop+0x61>
    68a5:	c3                   	ret
    68a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68ad:	00 00 00 
    68b0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    68b7:	ff ff 
    68b9:	48 85 c0             	test   %rax,%rax
    68bc:	74 12                	je     68d0 <fwp_closure_drop+0xb0>
    68be:	48 89 fe             	mov    %rdi,%rsi
    68c1:	48 89 c7             	mov    %rax,%rdi
    68c4:	e9 37 d9 ff ff       	jmp    4200 <fwp_closure_drop_push>
    68c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68d0:	e9 db da ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    68d5:	0f 1f 00             	nopl   (%rax)
    68d8:	48 89 d0             	mov    %rdx,%rax
    68db:	48 8d 35 7e ce 01 00 	lea    0x1ce7e(%rip),%rsi        # 23760 <fwp_heap>
    68e2:	48 83 ec 18          	sub    $0x18,%rsp
    68e6:	48 c1 e8 11          	shr    $0x11,%rax
    68ea:	48 31 d0             	xor    %rdx,%rax
    68ed:	48 89 c1             	mov    %rax,%rcx
    68f0:	48 c1 e9 09          	shr    $0x9,%rcx
    68f4:	48 31 c8             	xor    %rcx,%rax
    68f7:	0f b6 c8             	movzbl %al,%ecx
    68fa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6901:	00 
    6902:	48 85 c0             	test   %rax,%rax
    6905:	75 22                	jne    6929 <fwp_closure_drop+0x109>
    6907:	eb 59                	jmp    6962 <fwp_closure_drop+0x142>
    6909:	90                   	nop
    690a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6911:	00 00 00 00 
    6915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    691c:	00 00 00 00 
    6920:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6924:	48 85 c0             	test   %rax,%rax
    6927:	74 39                	je     6962 <fwp_closure_drop+0x142>
    6929:	48 89 c1             	mov    %rax,%rcx
    692c:	48 39 10             	cmp    %rdx,(%rax)
    692f:	75 ef                	jne    6920 <fwp_closure_drop+0x100>
    6931:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6935:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6939:	48 89 48 08          	mov    %rcx,0x8(%rax)
    693d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6944:	74 05                	je     694b <fwp_closure_drop+0x12b>
    6946:	48 83 c4 18          	add    $0x18,%rsp
    694a:	c3                   	ret
    694b:	48 89 d7             	mov    %rdx,%rdi
    694e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6953:	e8 b8 e9 ff ff       	call   5310 <fwp_rc_forget_slot>
    6958:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    695d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6960:	eb e4                	jmp    6946 <fwp_closure_drop+0x126>
    6962:	48 8d 3d 37 8e 00 00 	lea    0x8e37(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    6969:	e8 32 d8 ff ff       	call   41a0 <fwp_trap>
    696e:	66 90                	xchg   %ax,%ax

0000000000006970 <fwp_owned_tape_release>:
    6970:	48 85 ff             	test   %rdi,%rdi
    6973:	0f 84 f7 00 00 00    	je     6a70 <fwp_owned_tape_release+0x100>
    6979:	41 54                	push   %r12
    697b:	55                   	push   %rbp
    697c:	53                   	push   %rbx
    697d:	48 8b 07             	mov    (%rdi),%rax
    6980:	48 85 c0             	test   %rax,%rax
    6983:	74 08                	je     698d <fwp_owned_tape_release+0x1d>
    6985:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6989:	48 89 50 08          	mov    %rdx,0x8(%rax)
    698d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6991:	48 85 d2             	test   %rdx,%rdx
    6994:	74 03                	je     6999 <fwp_owned_tape_release+0x29>
    6996:	48 89 02             	mov    %rax,(%rdx)
    6999:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    699d:	48 89 fb             	mov    %rdi,%rbx
    69a0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    69a4:	48 85 c0             	test   %rax,%rax
    69a7:	0f 84 89 00 00 00    	je     6a36 <fwp_owned_tape_release+0xc6>
    69ad:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    69b1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    69b5:	7e 47                	jle    69fe <fwp_owned_tape_release+0x8e>
    69b7:	31 ed                	xor    %ebp,%ebp
    69b9:	eb 0d                	jmp    69c8 <fwp_owned_tape_release+0x58>
    69bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    69c0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    69c4:	48 8b 40 68          	mov    0x68(%rax),%rax
    69c8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    69cc:	49 89 ec             	mov    %rbp,%r12
    69cf:	48 83 c5 01          	add    $0x1,%rbp
    69d3:	49 c1 e4 04          	shl    $0x4,%r12
    69d7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    69db:	ff d0                	call   *%rax
    69dd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    69e1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    69e6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    69ea:	ff 50 68             	call   *0x68(%rax)
    69ed:	48 8b 43 58          	mov    0x58(%rbx),%rax
    69f1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    69f5:	48 39 e8             	cmp    %rbp,%rax
    69f8:	7f c6                	jg     69c0 <fwp_owned_tape_release+0x50>
    69fa:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    69fe:	31 ed                	xor    %ebp,%ebp
    6a00:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6a05:	7e 28                	jle    6a2f <fwp_owned_tape_release+0xbf>
    6a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a0e:	00 00 
    6a10:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6a14:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6a18:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6a1c:	74 07                	je     6a25 <fwp_owned_tape_release+0xb5>
    6a1e:	ff 52 68             	call   *0x68(%rdx)
    6a21:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a25:	48 83 c5 01          	add    $0x1,%rbp
    6a29:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6a2d:	7f e1                	jg     6a10 <fwp_owned_tape_release+0xa0>
    6a2f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6a33:	ff 52 68             	call   *0x68(%rdx)
    6a36:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6a3a:	e8 e1 fd ff ff       	call   6820 <fwp_closure_drop>
    6a3f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6a43:	e8 d8 fd ff ff       	call   6820 <fwp_closure_drop>
    6a48:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6a4c:	e8 cf fd ff ff       	call   6820 <fwp_closure_drop>
    6a51:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6a55:	e8 f6 ea ff ff       	call   5550 <fwp_mem_free>
    6a5a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6a5e:	e8 ed ea ff ff       	call   5550 <fwp_mem_free>
    6a63:	48 89 df             	mov    %rbx,%rdi
    6a66:	5b                   	pop    %rbx
    6a67:	5d                   	pop    %rbp
    6a68:	41 5c                	pop    %r12
    6a6a:	e9 e1 ea ff ff       	jmp    5550 <fwp_mem_free>
    6a6f:	90                   	nop
    6a70:	c3                   	ret
    6a71:	0f 1f 40 00          	nopl   0x0(%rax)
    6a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a7c:	00 00 00 00 

0000000000006a80 <fwp_tape_finish>:
    6a80:	f3 0f 1e fa          	endbr64
    6a84:	41 56                	push   %r14
    6a86:	48 8d 3d 13 c6 01 00 	lea    0x1c613(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    6a8d:	41 55                	push   %r13
    6a8f:	41 54                	push   %r12
    6a91:	55                   	push   %rbp
    6a92:	53                   	push   %rbx
    6a93:	e8 d8 d4 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6a98:	48 83 3d 48 c6 01 00 	cmpq   $0x0,0x1c648(%rip)        # 230e8 <fwp_ntapes>
    6a9f:	00 
    6aa0:	48 c7 05 dd c5 01 00 	movq   $0x0,0x1c5dd(%rip)        # 23088 <fwp_tape_cached_bytes>
    6aa7:	00 00 00 00 
    6aab:	7e 68                	jle    6b15 <fwp_tape_finish+0x95>
    6aad:	45 31 e4             	xor    %r12d,%r12d
    6ab0:	31 ed                	xor    %ebp,%ebp
    6ab2:	0f 1f 00             	nopl   (%rax)
    6ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6abc:	00 00 00 00 
    6ac0:	48 8b 1d 29 c6 01 00 	mov    0x1c629(%rip),%rbx        # 230f0 <fwp_tapes>
    6ac7:	48 83 c5 01          	add    $0x1,%rbp
    6acb:	4c 01 e3             	add    %r12,%rbx
    6ace:	49 83 c4 68          	add    $0x68,%r12
    6ad2:	48 89 df             	mov    %rbx,%rdi
    6ad5:	e8 26 d1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6ada:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6ade:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6ae2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6ae6:	e8 d5 c8 ff ff       	call   33c0 <free@plt>
    6aeb:	4c 89 f7             	mov    %r14,%rdi
    6aee:	e8 cd c8 ff ff       	call   33c0 <free@plt>
    6af3:	4c 89 ef             	mov    %r13,%rdi
    6af6:	e8 c5 c8 ff ff       	call   33c0 <free@plt>
    6afb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6aff:	e8 6c fe ff ff       	call   6970 <fwp_owned_tape_release>
    6b04:	48 39 2d dd c5 01 00 	cmp    %rbp,0x1c5dd(%rip)        # 230e8 <fwp_ntapes>
    6b0b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6b12:	00 
    6b13:	7f ab                	jg     6ac0 <fwp_tape_finish+0x40>
    6b15:	48 8b 3d d4 c5 01 00 	mov    0x1c5d4(%rip),%rdi        # 230f0 <fwp_tapes>
    6b1c:	e8 9f c8 ff ff       	call   33c0 <free@plt>
    6b21:	5b                   	pop    %rbx
    6b22:	5d                   	pop    %rbp
    6b23:	48 c7 05 c2 c5 01 00 	movq   $0x0,0x1c5c2(%rip)        # 230f0 <fwp_tapes>
    6b2a:	00 00 00 00 
    6b2e:	48 c7 05 a7 c5 01 00 	movq   $0x0,0x1c5a7(%rip)        # 230e0 <fwp_tapes_cap>
    6b35:	00 00 00 00 
    6b39:	41 5c                	pop    %r12
    6b3b:	48 c7 05 a2 c5 01 00 	movq   $0x0,0x1c5a2(%rip)        # 230e8 <fwp_ntapes>
    6b42:	00 00 00 00 
    6b46:	41 5d                	pop    %r13
    6b48:	48 c7 05 85 c5 01 00 	movq   $0x0,0x1c585(%rip)        # 230d8 <fwp_tape_next_slot>
    6b4f:	00 00 00 00 
    6b53:	41 5e                	pop    %r14
    6b55:	c3                   	ret
    6b56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b5d:	00 00 00 

0000000000006b60 <fwp_tape_scope_release>:
    6b60:	f3 0f 1e fa          	endbr64
    6b64:	41 55                	push   %r13
    6b66:	41 54                	push   %r12
    6b68:	55                   	push   %rbp
    6b69:	53                   	push   %rbx
    6b6a:	48 83 ec 58          	sub    $0x58,%rsp
    6b6e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b75:	00 00 
    6b77:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6b7c:	48 63 07             	movslq (%rdi),%rax
    6b7f:	85 c0                	test   %eax,%eax
    6b81:	0f 88 05 01 00 00    	js     6c8c <fwp_tape_scope_release+0x12c>
    6b87:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6b8e:	ec c4 4e 
    6b91:	48 89 fb             	mov    %rdi,%rbx
    6b94:	eb 3c                	jmp    6bd2 <fwp_tape_scope_release+0x72>
    6b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b9d:	00 00 00 
    6ba0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6ba5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6ba9:	e8 12 c8 ff ff       	call   33c0 <free@plt>
    6bae:	48 8b 3c 24          	mov    (%rsp),%rdi
    6bb2:	e8 09 c8 ff ff       	call   33c0 <free@plt>
    6bb7:	4c 89 ef             	mov    %r13,%rdi
    6bba:	e8 01 c8 ff ff       	call   33c0 <free@plt>
    6bbf:	4c 89 e7             	mov    %r12,%rdi
    6bc2:	e8 a9 fd ff ff       	call   6970 <fwp_owned_tape_release>
    6bc7:	48 63 03             	movslq (%rbx),%rax
    6bca:	85 c0                	test   %eax,%eax
    6bcc:	0f 88 ba 00 00 00    	js     6c8c <fwp_tape_scope_release+0x12c>
    6bd2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6bd6:	48 8b 35 13 c5 01 00 	mov    0x1c513(%rip),%rsi        # 230f0 <fwp_tapes>
    6bdd:	4c 01 c6             	add    %r8,%rsi
    6be0:	48 89 f7             	mov    %rsi,%rdi
    6be3:	e8 18 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6be8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6bed:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6bf2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6bf9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6bfd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6c01:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6c08:	00 
    6c09:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6c0e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6c12:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6c17:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6c1b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6c20:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6c27:	00 
    6c28:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6c2f:	00 
    6c30:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6c37:	00 
    6c38:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6c3d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6c42:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6c46:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6c4a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6c4e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6c54:	77 18                	ja     6c6e <fwp_tape_scope_release+0x10e>
    6c56:	49 c1 f8 03          	sar    $0x3,%r8
    6c5a:	4c 0f af c5          	imul   %rbp,%r8
    6c5e:	4c 3b 05 73 c4 01 00 	cmp    0x1c473(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    6c65:	7d 07                	jge    6c6e <fwp_tape_scope_release+0x10e>
    6c67:	4c 89 05 6a c4 01 00 	mov    %r8,0x1c46a(%rip)        # 230d8 <fwp_tape_next_slot>
    6c6e:	4d 85 e4             	test   %r12,%r12
    6c71:	0f 85 29 ff ff ff    	jne    6ba0 <fwp_tape_scope_release+0x40>
    6c77:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6c7c:	e8 af e1 ff ff       	call   4e30 <fwp_tape_buffers_release>
    6c81:	48 63 03             	movslq (%rbx),%rax
    6c84:	85 c0                	test   %eax,%eax
    6c86:	0f 89 46 ff ff ff    	jns    6bd2 <fwp_tape_scope_release+0x72>
    6c8c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6c91:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c98:	00 00 
    6c9a:	75 0b                	jne    6ca7 <fwp_tape_scope_release+0x147>
    6c9c:	48 83 c4 58          	add    $0x58,%rsp
    6ca0:	5b                   	pop    %rbx
    6ca1:	5d                   	pop    %rbp
    6ca2:	41 5c                	pop    %r12
    6ca4:	41 5d                	pop    %r13
    6ca6:	c3                   	ret
    6ca7:	e8 b4 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6cac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006cb0 <fwp_drop4>:
    6cb0:	48 8b 0d 81 de 01 00 	mov    0x1de81(%rip),%rcx        # 24b38 <fwp_heap+0x13d8>
    6cb7:	48 89 f8             	mov    %rdi,%rax
    6cba:	48 2b 05 4f de 01 00 	sub    0x1de4f(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6cc1:	48 c1 e1 10          	shl    $0x10,%rcx
    6cc5:	48 39 c8             	cmp    %rcx,%rax
    6cc8:	0f 83 42 01 00 00    	jae    6e10 <fwp_drop4+0x160>
    6cce:	48 83 ec 18          	sub    $0x18,%rsp
    6cd2:	48 89 fa             	mov    %rdi,%rdx
    6cd5:	4c 8d 05 84 ca 01 00 	lea    0x1ca84(%rip),%r8        # 23760 <fwp_heap>
    6cdc:	48 89 c1             	mov    %rax,%rcx
    6cdf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6ce6:	48 c1 e9 10          	shr    $0x10,%rcx
    6cea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6cee:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6cf2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6cf6:	48 85 c9             	test   %rcx,%rcx
    6cf9:	74 40                	je     6d3b <fwp_drop4+0x8b>
    6cfb:	0f b6 3e             	movzbl (%rsi),%edi
    6cfe:	40 80 ff 02          	cmp    $0x2,%dil
    6d02:	74 3c                	je     6d40 <fwp_drop4+0x90>
    6d04:	40 80 ff 01          	cmp    $0x1,%dil
    6d08:	75 31                	jne    6d3b <fwp_drop4+0x8b>
    6d0a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6d0d:	0f b7 c0             	movzwl %ax,%eax
    6d10:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6d13:	48 0f af c7          	imul   %rdi,%rax
    6d17:	48 c1 e8 20          	shr    $0x20,%rax
    6d1b:	48 39 f0             	cmp    %rsi,%rax
    6d1e:	73 1b                	jae    6d3b <fwp_drop4+0x8b>
    6d20:	48 01 c1             	add    %rax,%rcx
    6d23:	0f b6 01             	movzbl (%rcx),%eax
    6d26:	84 c0                	test   %al,%al
    6d28:	74 11                	je     6d3b <fwp_drop4+0x8b>
    6d2a:	3c 01                	cmp    $0x1,%al
    6d2c:	74 22                	je     6d50 <fwp_drop4+0xa0>
    6d2e:	3c ff                	cmp    $0xff,%al
    6d30:	0f 84 0a 01 00 00    	je     6e40 <fwp_drop4+0x190>
    6d36:	83 e8 01             	sub    $0x1,%eax
    6d39:	88 01                	mov    %al,(%rcx)
    6d3b:	48 83 c4 18          	add    $0x18,%rsp
    6d3f:	c3                   	ret
    6d40:	66 85 c0             	test   %ax,%ax
    6d43:	74 de                	je     6d23 <fwp_drop4+0x73>
    6d45:	48 83 c4 18          	add    $0x18,%rsp
    6d49:	c3                   	ret
    6d4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d50:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6d54:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6d5b:	48 89 f8             	mov    %rdi,%rax
    6d5e:	48 c1 e1 10          	shl    $0x10,%rcx
    6d62:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6d69:	48 39 c8             	cmp    %rcx,%rax
    6d6c:	73 62                	jae    6dd0 <fwp_drop4+0x120>
    6d6e:	48 89 c1             	mov    %rax,%rcx
    6d71:	48 c1 e9 10          	shr    $0x10,%rcx
    6d75:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6d79:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6d7d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6d81:	48 85 c9             	test   %rcx,%rcx
    6d84:	74 4a                	je     6dd0 <fwp_drop4+0x120>
    6d86:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6d8a:	41 80 f9 02          	cmp    $0x2,%r9b
    6d8e:	0f 84 9c 00 00 00    	je     6e30 <fwp_drop4+0x180>
    6d94:	41 80 f9 01          	cmp    $0x1,%r9b
    6d98:	75 36                	jne    6dd0 <fwp_drop4+0x120>
    6d9a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6d9e:	0f b7 c0             	movzwl %ax,%eax
    6da1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6da4:	49 0f af c1          	imul   %r9,%rax
    6da8:	48 c1 e8 20          	shr    $0x20,%rax
    6dac:	48 39 f0             	cmp    %rsi,%rax
    6daf:	73 1f                	jae    6dd0 <fwp_drop4+0x120>
    6db1:	48 01 c1             	add    %rax,%rcx
    6db4:	0f b6 01             	movzbl (%rcx),%eax
    6db7:	84 c0                	test   %al,%al
    6db9:	74 15                	je     6dd0 <fwp_drop4+0x120>
    6dbb:	3c 01                	cmp    $0x1,%al
    6dbd:	74 59                	je     6e18 <fwp_drop4+0x168>
    6dbf:	3c ff                	cmp    $0xff,%al
    6dc1:	0f 84 ff 00 00 00    	je     6ec6 <fwp_drop4+0x216>
    6dc7:	83 e8 01             	sub    $0x1,%eax
    6dca:	88 01                	mov    %al,(%rcx)
    6dcc:	0f 1f 40 00          	nopl   0x0(%rax)
    6dd0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6dd4:	48 89 d7             	mov    %rdx,%rdi
    6dd7:	48 89 0c 24          	mov    %rcx,(%rsp)
    6ddb:	e8 30 f7 ff ff       	call   6510 <fwp_rc_free_obj>
    6de0:	4c 8d 05 79 c9 01 00 	lea    0x1c979(%rip),%r8        # 23760 <fwp_heap>
    6de7:	48 8b 04 24          	mov    (%rsp),%rax
    6deb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6df2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6df9:	48 c1 e2 10          	shl    $0x10,%rdx
    6dfd:	48 39 d0             	cmp    %rdx,%rax
    6e00:	0f 83 35 ff ff ff    	jae    6d3b <fwp_drop4+0x8b>
    6e06:	48 8b 14 24          	mov    (%rsp),%rdx
    6e0a:	e9 cd fe ff ff       	jmp    6cdc <fwp_drop4+0x2c>
    6e0f:	90                   	nop
    6e10:	c3                   	ret
    6e11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e18:	48 89 14 24          	mov    %rdx,(%rsp)
    6e1c:	e8 ef f6 ff ff       	call   6510 <fwp_rc_free_obj>
    6e21:	48 8b 14 24          	mov    (%rsp),%rdx
    6e25:	eb a9                	jmp    6dd0 <fwp_drop4+0x120>
    6e27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e2e:	00 00 
    6e30:	66 85 c0             	test   %ax,%ax
    6e33:	75 9b                	jne    6dd0 <fwp_drop4+0x120>
    6e35:	e9 7a ff ff ff       	jmp    6db4 <fwp_drop4+0x104>
    6e3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e40:	48 89 c8             	mov    %rcx,%rax
    6e43:	48 c1 e8 11          	shr    $0x11,%rax
    6e47:	48 31 c8             	xor    %rcx,%rax
    6e4a:	48 89 c2             	mov    %rax,%rdx
    6e4d:	48 c1 ea 09          	shr    $0x9,%rdx
    6e51:	48 31 d0             	xor    %rdx,%rax
    6e54:	0f b6 d0             	movzbl %al,%edx
    6e57:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6e5e:	00 
    6e5f:	48 85 c0             	test   %rax,%rax
    6e62:	75 29                	jne    6e8d <fwp_drop4+0x1dd>
    6e64:	e9 e3 00 00 00       	jmp    6f4c <fwp_drop4+0x29c>
    6e69:	90                   	nop
    6e6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e71:	00 00 00 00 
    6e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e7c:	00 00 00 00 
    6e80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6e84:	48 85 c0             	test   %rax,%rax
    6e87:	0f 84 bf 00 00 00    	je     6f4c <fwp_drop4+0x29c>
    6e8d:	48 89 c2             	mov    %rax,%rdx
    6e90:	48 39 08             	cmp    %rcx,(%rax)
    6e93:	75 eb                	jne    6e80 <fwp_drop4+0x1d0>
    6e95:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6e99:	48 83 ea 01          	sub    $0x1,%rdx
    6e9d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ea1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6ea8:	0f 85 8d fe ff ff    	jne    6d3b <fwp_drop4+0x8b>
    6eae:	48 89 cf             	mov    %rcx,%rdi
    6eb1:	48 89 0c 24          	mov    %rcx,(%rsp)
    6eb5:	e8 56 e4 ff ff       	call   5310 <fwp_rc_forget_slot>
    6eba:	48 8b 0c 24          	mov    (%rsp),%rcx
    6ebe:	c6 01 fe             	movb   $0xfe,(%rcx)
    6ec1:	e9 75 fe ff ff       	jmp    6d3b <fwp_drop4+0x8b>
    6ec6:	48 89 ce             	mov    %rcx,%rsi
    6ec9:	48 c1 ee 11          	shr    $0x11,%rsi
    6ecd:	48 31 ce             	xor    %rcx,%rsi
    6ed0:	48 89 f0             	mov    %rsi,%rax
    6ed3:	48 c1 e8 09          	shr    $0x9,%rax
    6ed7:	48 31 c6             	xor    %rax,%rsi
    6eda:	40 0f b6 f6          	movzbl %sil,%esi
    6ede:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6ee5:	00 
    6ee6:	48 85 c0             	test   %rax,%rax
    6ee9:	75 1e                	jne    6f09 <fwp_drop4+0x259>
    6eeb:	eb 5f                	jmp    6f4c <fwp_drop4+0x29c>
    6eed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6ef4:	00 
    6ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6efc:	00 00 00 00 
    6f00:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6f04:	48 85 c0             	test   %rax,%rax
    6f07:	74 43                	je     6f4c <fwp_drop4+0x29c>
    6f09:	48 89 c6             	mov    %rax,%rsi
    6f0c:	48 39 08             	cmp    %rcx,(%rax)
    6f0f:	75 ef                	jne    6f00 <fwp_drop4+0x250>
    6f11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f15:	48 83 ee 01          	sub    $0x1,%rsi
    6f19:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6f1d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6f24:	0f 85 a6 fe ff ff    	jne    6dd0 <fwp_drop4+0x120>
    6f2a:	48 89 cf             	mov    %rcx,%rdi
    6f2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f32:	48 89 0c 24          	mov    %rcx,(%rsp)
    6f36:	e8 d5 e3 ff ff       	call   5310 <fwp_rc_forget_slot>
    6f3b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6f3f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f44:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f47:	e9 84 fe ff ff       	jmp    6dd0 <fwp_drop4+0x120>
    6f4c:	48 8d 3d 4d 88 00 00 	lea    0x884d(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    6f53:	e8 48 d2 ff ff       	call   41a0 <fwp_trap>
    6f58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f5f:	00 

0000000000006f60 <fwp_arg_drop37>:
    6f60:	f3 0f 1e fa          	endbr64
    6f64:	85 f6                	test   %esi,%esi
    6f66:	75 04                	jne    6f6c <fwp_arg_drop37+0xc>
    6f68:	85 d2                	test   %edx,%edx
    6f6a:	75 04                	jne    6f70 <fwp_arg_drop37+0x10>
    6f6c:	c3                   	ret
    6f6d:	0f 1f 00             	nopl   (%rax)
    6f70:	48 8b 3f             	mov    (%rdi),%rdi
    6f73:	e9 38 fd ff ff       	jmp    6cb0 <fwp_drop4>
    6f78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f7f:	00 

0000000000006f80 <fwp_task_dispose>:
    6f80:	53                   	push   %rbx
    6f81:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6f85:	0f 84 bb c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    6f8b:	48 89 fb             	mov    %rdi,%rbx
    6f8e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6f93:	0f 85 ad c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6f99:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6f9d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6fa4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6fab:	00 
    6fac:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6fb0:	48 85 ff             	test   %rdi,%rdi
    6fb3:	74 07                	je     6fbc <fwp_task_dispose+0x3c>
    6fb5:	48 85 c0             	test   %rax,%rax
    6fb8:	74 02                	je     6fbc <fwp_task_dispose+0x3c>
    6fba:	ff d0                	call   *%rax
    6fbc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6fc3:	e8 88 e5 ff ff       	call   5550 <fwp_mem_free>
    6fc8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6fcf:	00 00 00 00 
    6fd3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6fd7:	74 6f                	je     7048 <fwp_task_dispose+0xc8>
    6fd9:	48 8b 15 58 db 01 00 	mov    0x1db58(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    6fe0:	48 89 d8             	mov    %rbx,%rax
    6fe3:	48 2b 05 26 db 01 00 	sub    0x1db26(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6fea:	48 c1 e2 10          	shl    $0x10,%rdx
    6fee:	48 39 d0             	cmp    %rdx,%rax
    6ff1:	73 4c                	jae    703f <fwp_task_dispose+0xbf>
    6ff3:	48 89 c2             	mov    %rax,%rdx
    6ff6:	48 c1 ea 10          	shr    $0x10,%rdx
    6ffa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ffe:	48 8b 15 53 db 01 00 	mov    0x1db53(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    7005:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7009:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    700d:	48 85 c9             	test   %rcx,%rcx
    7010:	74 2d                	je     703f <fwp_task_dispose+0xbf>
    7012:	0f b6 32             	movzbl (%rdx),%esi
    7015:	40 80 fe 02          	cmp    $0x2,%sil
    7019:	74 3d                	je     7058 <fwp_task_dispose+0xd8>
    701b:	40 80 fe 01          	cmp    $0x1,%sil
    701f:	75 1e                	jne    703f <fwp_task_dispose+0xbf>
    7021:	8b 72 18             	mov    0x18(%rdx),%esi
    7024:	0f b7 c0             	movzwl %ax,%eax
    7027:	8b 52 1c             	mov    0x1c(%rdx),%edx
    702a:	48 0f af c6          	imul   %rsi,%rax
    702e:	48 c1 e8 20          	shr    $0x20,%rax
    7032:	48 39 d0             	cmp    %rdx,%rax
    7035:	73 08                	jae    703f <fwp_task_dispose+0xbf>
    7037:	48 01 c1             	add    %rax,%rcx
    703a:	80 39 01             	cmpb   $0x1,(%rcx)
    703d:	74 09                	je     7048 <fwp_task_dispose+0xc8>
    703f:	5b                   	pop    %rbx
    7040:	c3                   	ret
    7041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7048:	48 89 df             	mov    %rbx,%rdi
    704b:	5b                   	pop    %rbx
    704c:	e9 ff e4 ff ff       	jmp    5550 <fwp_mem_free>
    7051:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7058:	66 85 c0             	test   %ax,%ax
    705b:	74 dd                	je     703a <fwp_task_dispose+0xba>
    705d:	5b                   	pop    %rbx
    705e:	c3                   	ret
    705f:	90                   	nop

0000000000007060 <fwp_free_zombie>:
    7060:	48 8b 15 c9 c6 01 00 	mov    0x1c6c9(%rip),%rdx        # 23730 <fwp_zombie>
    7067:	48 85 d2             	test   %rdx,%rdx
    706a:	0f 84 98 00 00 00    	je     7108 <fwp_free_zombie+0xa8>
    7070:	48 3b 15 c9 c6 01 00 	cmp    0x1c6c9(%rip),%rdx        # 23740 <fwp_cur>
    7077:	0f 84 8b 00 00 00    	je     7108 <fwp_free_zombie+0xa8>
    707d:	48 83 ec 18          	sub    $0x18,%rsp
    7081:	48 63 05 84 c0 01 00 	movslq 0x1c084(%rip),%rax        # 2310c <fwp_stack_pool_n>
    7088:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    708c:	83 f8 3f             	cmp    $0x3f,%eax
    708f:	7f 7f                	jg     7110 <fwp_free_zombie+0xb0>
    7091:	8d 48 01             	lea    0x1(%rax),%ecx
    7094:	89 0d 72 c0 01 00    	mov    %ecx,0x1c072(%rip)        # 2310c <fwp_stack_pool_n>
    709a:	48 8d 0d 7f c0 01 00 	lea    0x1c07f(%rip),%rcx        # 23120 <fwp_stack_pool>
    70a1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    70a5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    70ac:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70b0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    70b7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    70bb:	48 85 c9             	test   %rcx,%rcx
    70be:	0f 84 fc 00 00 00    	je     71c0 <fwp_free_zombie+0x160>
    70c4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    70cb:	48 85 c0             	test   %rax,%rax
    70ce:	74 07                	je     70d7 <fwp_free_zombie+0x77>
    70d0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    70d7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    70da:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70de:	48 c7 05 47 c6 01 00 	movq   $0x0,0x1c647(%rip)        # 23730 <fwp_zombie>
    70e5:	00 00 00 00 
    70e9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    70f0:	85 c0                	test   %eax,%eax
    70f2:	74 34                	je     7128 <fwp_free_zombie+0xc8>
    70f4:	83 f8 01             	cmp    $0x1,%eax
    70f7:	0f 84 b3 00 00 00    	je     71b0 <fwp_free_zombie+0x150>
    70fd:	48 83 c4 18          	add    $0x18,%rsp
    7101:	c3                   	ret
    7102:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7108:	c3                   	ret
    7109:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7110:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7114:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7119:	e8 c2 c4 ff ff       	call   35e0 <munmap@plt>
    711e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7123:	eb 80                	jmp    70a5 <fwp_free_zombie+0x45>
    7125:	0f 1f 00             	nopl   (%rax)
    7128:	48 8b 0d 09 da 01 00 	mov    0x1da09(%rip),%rcx        # 24b38 <fwp_heap+0x13d8>
    712f:	48 89 d0             	mov    %rdx,%rax
    7132:	48 2b 05 d7 d9 01 00 	sub    0x1d9d7(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    7139:	48 c1 e1 10          	shl    $0x10,%rcx
    713d:	48 39 c8             	cmp    %rcx,%rax
    7140:	73 bb                	jae    70fd <fwp_free_zombie+0x9d>
    7142:	48 89 c1             	mov    %rax,%rcx
    7145:	48 c1 e9 10          	shr    $0x10,%rcx
    7149:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    714d:	48 8b 0d 04 da 01 00 	mov    0x1da04(%rip),%rcx        # 24b58 <fwp_heap+0x13f8>
    7154:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7158:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    715c:	48 85 c9             	test   %rcx,%rcx
    715f:	74 9c                	je     70fd <fwp_free_zombie+0x9d>
    7161:	0f b6 3e             	movzbl (%rsi),%edi
    7164:	40 80 ff 02          	cmp    $0x2,%dil
    7168:	74 66                	je     71d0 <fwp_free_zombie+0x170>
    716a:	40 80 ff 01          	cmp    $0x1,%dil
    716e:	75 8d                	jne    70fd <fwp_free_zombie+0x9d>
    7170:	8b 7e 18             	mov    0x18(%rsi),%edi
    7173:	0f b7 c0             	movzwl %ax,%eax
    7176:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7179:	48 0f af c7          	imul   %rdi,%rax
    717d:	48 c1 e8 20          	shr    $0x20,%rax
    7181:	48 39 f0             	cmp    %rsi,%rax
    7184:	0f 83 73 ff ff ff    	jae    70fd <fwp_free_zombie+0x9d>
    718a:	48 01 c1             	add    %rax,%rcx
    718d:	0f b6 01             	movzbl (%rcx),%eax
    7190:	84 c0                	test   %al,%al
    7192:	0f 84 65 ff ff ff    	je     70fd <fwp_free_zombie+0x9d>
    7198:	3c 01                	cmp    $0x1,%al
    719a:	74 14                	je     71b0 <fwp_free_zombie+0x150>
    719c:	3c ff                	cmp    $0xff,%al
    719e:	74 3b                	je     71db <fwp_free_zombie+0x17b>
    71a0:	83 e8 01             	sub    $0x1,%eax
    71a3:	88 01                	mov    %al,(%rcx)
    71a5:	e9 53 ff ff ff       	jmp    70fd <fwp_free_zombie+0x9d>
    71aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71b0:	48 89 d7             	mov    %rdx,%rdi
    71b3:	48 83 c4 18          	add    $0x18,%rsp
    71b7:	e9 c4 fd ff ff       	jmp    6f80 <fwp_task_dispose>
    71bc:	0f 1f 40 00          	nopl   0x0(%rax)
    71c0:	48 89 05 41 c5 01 00 	mov    %rax,0x1c541(%rip)        # 23708 <fwp_tasks_active>
    71c7:	e9 ff fe ff ff       	jmp    70cb <fwp_free_zombie+0x6b>
    71cc:	0f 1f 40 00          	nopl   0x0(%rax)
    71d0:	66 85 c0             	test   %ax,%ax
    71d3:	0f 85 24 ff ff ff    	jne    70fd <fwp_free_zombie+0x9d>
    71d9:	eb b2                	jmp    718d <fwp_free_zombie+0x12d>
    71db:	48 89 ca             	mov    %rcx,%rdx
    71de:	48 8d 35 7b c5 01 00 	lea    0x1c57b(%rip),%rsi        # 23760 <fwp_heap>
    71e5:	48 c1 ea 11          	shr    $0x11,%rdx
    71e9:	48 31 ca             	xor    %rcx,%rdx
    71ec:	48 89 d0             	mov    %rdx,%rax
    71ef:	48 c1 e8 09          	shr    $0x9,%rax
    71f3:	48 31 c2             	xor    %rax,%rdx
    71f6:	0f b6 d2             	movzbl %dl,%edx
    71f9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7200:	00 
    7201:	48 85 c0             	test   %rax,%rax
    7204:	75 23                	jne    7229 <fwp_free_zombie+0x1c9>
    7206:	eb 5c                	jmp    7264 <fwp_free_zombie+0x204>
    7208:	66 90                	xchg   %ax,%ax
    720a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7211:	00 00 00 00 
    7215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    721c:	00 00 00 00 
    7220:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7224:	48 85 c0             	test   %rax,%rax
    7227:	74 3b                	je     7264 <fwp_free_zombie+0x204>
    7229:	48 89 c2             	mov    %rax,%rdx
    722c:	48 39 08             	cmp    %rcx,(%rax)
    722f:	75 ef                	jne    7220 <fwp_free_zombie+0x1c0>
    7231:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7235:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7239:	48 89 50 08          	mov    %rdx,0x8(%rax)
    723d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7244:	0f 85 b3 fe ff ff    	jne    70fd <fwp_free_zombie+0x9d>
    724a:	48 89 cf             	mov    %rcx,%rdi
    724d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7252:	e8 b9 e0 ff ff       	call   5310 <fwp_rc_forget_slot>
    7257:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    725c:	c6 01 fe             	movb   $0xfe,(%rcx)
    725f:	e9 99 fe ff ff       	jmp    70fd <fwp_free_zombie+0x9d>
    7264:	48 8d 3d 35 85 00 00 	lea    0x8535(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    726b:	e8 30 cf ff ff       	call   41a0 <fwp_trap>

0000000000007270 <fwp_block>:
    7270:	48 83 ec 08          	sub    $0x8,%rsp
    7274:	48 8b 05 ad c4 01 00 	mov    0x1c4ad(%rip),%rax        # 23728 <fwp_ready_head>
    727b:	48 85 c0             	test   %rax,%rax
    727e:	0f 84 1c 01 00 00    	je     73a0 <fwp_block+0x130>
    7284:	90                   	nop
    7285:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    728c:	00 00 00 00 
    7290:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7297:	48 89 15 8a c4 01 00 	mov    %rdx,0x1c48a(%rip)        # 23728 <fwp_ready_head>
    729e:	48 85 d2             	test   %rdx,%rdx
    72a1:	0f 84 19 01 00 00    	je     73c0 <fwp_block+0x150>
    72a7:	48 8b 15 92 c4 01 00 	mov    0x1c492(%rip),%rdx        # 23740 <fwp_cur>
    72ae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    72b2:	48 39 c2             	cmp    %rax,%rdx
    72b5:	0f 84 d5 00 00 00    	je     7390 <fwp_block+0x120>
    72bb:	48 8b 0d 06 e1 01 00 	mov    0x1e106(%rip),%rcx        # 253c8 <fwp_state_owners>
    72c2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    72c6:	48 89 05 73 c4 01 00 	mov    %rax,0x1c473(%rip)        # 23740 <fwp_cur>
    72cd:	f3 0f 7e 05 1b e1 01 	movq   0x1e11b(%rip),%xmm0        # 253f0 <fwp_foreign_callbacks>
    72d4:	00 
    72d5:	0f 16 05 04 e1 01 00 	movhps 0x1e104(%rip),%xmm0        # 253e0 <fwp_state>
    72dc:	f3 0f 7e 0d 04 e1 01 	movq   0x1e104(%rip),%xmm1        # 253e8 <fwp_handlers>
    72e3:	00 
    72e4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    72eb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    72f2:	0f 16 0d ff e0 01 00 	movhps 0x1e0ff(%rip),%xmm1        # 253f8 <fwp_cleanups>
    72f9:	f3 0f 7e 05 d7 e0 01 	movq   0x1e0d7(%rip),%xmm0        # 253d8 <fwp_state_len>
    7300:	00 
    7301:	0f 16 05 c8 e0 01 00 	movhps 0x1e0c8(%rip),%xmm0        # 253d0 <fwp_state_cap>
    7308:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    730f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7316:	48 8b 70 08          	mov    0x8(%rax),%rsi
    731a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7321:	48 89 0d c0 e0 01 00 	mov    %rcx,0x1e0c0(%rip)        # 253e8 <fwp_handlers>
    7328:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    732f:	48 89 0d c2 e0 01 00 	mov    %rcx,0x1e0c2(%rip)        # 253f8 <fwp_cleanups>
    7336:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    733d:	48 89 0d ac e0 01 00 	mov    %rcx,0x1e0ac(%rip)        # 253f0 <fwp_foreign_callbacks>
    7344:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    734b:	48 89 0d 8e e0 01 00 	mov    %rcx,0x1e08e(%rip)        # 253e0 <fwp_state>
    7352:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7359:	48 89 0d 78 e0 01 00 	mov    %rcx,0x1e078(%rip)        # 253d8 <fwp_state_len>
    7360:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7367:	48 89 0d 62 e0 01 00 	mov    %rcx,0x1e062(%rip)        # 253d0 <fwp_state_cap>
    736e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7375:	48 89 0d 4c e0 01 00 	mov    %rcx,0x1e04c(%rip)        # 253c8 <fwp_state_owners>
    737c:	e8 0f c1 ff ff       	call   3490 <swapcontext@plt>
    7381:	f3 0f 1e fa          	endbr64
    7385:	e8 d6 fc ff ff       	call   7060 <fwp_free_zombie>
    738a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7390:	8b 05 72 bd 01 00    	mov    0x1bd72(%rip),%eax        # 23108 <fwp_slice>
    7396:	85 c0                	test   %eax,%eax
    7398:	74 36                	je     73d0 <fwp_block+0x160>
    739a:	48 83 c4 08          	add    $0x8,%rsp
    739e:	c3                   	ret
    739f:	90                   	nop
    73a0:	e8 bb db ff ff       	call   4f60 <fwp_poll_events>
    73a5:	48 8b 05 7c c3 01 00 	mov    0x1c37c(%rip),%rax        # 23728 <fwp_ready_head>
    73ac:	48 85 c0             	test   %rax,%rax
    73af:	0f 85 db fe ff ff    	jne    7290 <fwp_block+0x20>
    73b5:	eb e9                	jmp    73a0 <fwp_block+0x130>
    73b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    73be:	00 00 
    73c0:	48 c7 05 55 c3 01 00 	movq   $0x0,0x1c355(%rip)        # 23720 <fwp_ready_tail>
    73c7:	00 00 00 00 
    73cb:	e9 d7 fe ff ff       	jmp    72a7 <fwp_block+0x37>
    73d0:	48 8d 3d 4a 7d 00 00 	lea    0x7d4a(%rip),%rdi        # f121 <_IO_stdin_used+0x121>
    73d7:	e8 c4 bf ff ff       	call   33a0 <getenv@plt>
    73dc:	ba 10 27 00 00       	mov    $0x2710,%edx
    73e1:	48 85 c0             	test   %rax,%rax
    73e4:	74 05                	je     73eb <fwp_block+0x17b>
    73e6:	80 38 00             	cmpb   $0x0,(%rax)
    73e9:	75 0b                	jne    73f6 <fwp_block+0x186>
    73eb:	89 15 17 bd 01 00    	mov    %edx,0x1bd17(%rip)        # 23108 <fwp_slice>
    73f1:	48 83 c4 08          	add    $0x8,%rsp
    73f5:	c3                   	ret
    73f6:	ba 0a 00 00 00       	mov    $0xa,%edx
    73fb:	31 f6                	xor    %esi,%esi
    73fd:	48 89 c7             	mov    %rax,%rdi
    7400:	e8 4b c1 ff ff       	call   3550 <strtoll@plt>
    7405:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7409:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7410:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7415:	0f 46 d0             	cmovbe %eax,%edx
    7418:	eb d1                	jmp    73eb <fwp_block+0x17b>
    741a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007420 <fwp_caps173>:
    7420:	f3 0f 1e fa          	endbr64
    7424:	85 f6                	test   %esi,%esi
    7426:	74 08                	je     7430 <fwp_caps173+0x10>
    7428:	c3                   	ret
    7429:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7430:	48 8b 15 01 d7 01 00 	mov    0x1d701(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    7437:	48 89 f8             	mov    %rdi,%rax
    743a:	48 2b 05 cf d6 01 00 	sub    0x1d6cf(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    7441:	48 c1 e2 10          	shl    $0x10,%rdx
    7445:	48 39 d0             	cmp    %rdx,%rax
    7448:	73 de                	jae    7428 <fwp_caps173+0x8>
    744a:	48 89 c2             	mov    %rax,%rdx
    744d:	48 c1 ea 10          	shr    $0x10,%rdx
    7451:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7455:	48 8b 15 fc d6 01 00 	mov    0x1d6fc(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    745c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7460:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7464:	48 85 c9             	test   %rcx,%rcx
    7467:	74 bf                	je     7428 <fwp_caps173+0x8>
    7469:	0f b6 32             	movzbl (%rdx),%esi
    746c:	40 80 fe 02          	cmp    $0x2,%sil
    7470:	74 2e                	je     74a0 <fwp_caps173+0x80>
    7472:	40 80 fe 01          	cmp    $0x1,%sil
    7476:	75 b0                	jne    7428 <fwp_caps173+0x8>
    7478:	8b 72 18             	mov    0x18(%rdx),%esi
    747b:	0f b7 c0             	movzwl %ax,%eax
    747e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7481:	48 0f af c6          	imul   %rsi,%rax
    7485:	48 c1 e8 20          	shr    $0x20,%rax
    7489:	48 39 d0             	cmp    %rdx,%rax
    748c:	73 9a                	jae    7428 <fwp_caps173+0x8>
    748e:	48 01 c1             	add    %rax,%rcx
    7491:	80 39 01             	cmpb   $0x1,(%rcx)
    7494:	75 92                	jne    7428 <fwp_caps173+0x8>
    7496:	e9 b5 e0 ff ff       	jmp    5550 <fwp_mem_free>
    749b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    74a0:	66 85 c0             	test   %ax,%ax
    74a3:	74 ec                	je     7491 <fwp_caps173+0x71>
    74a5:	c3                   	ret
    74a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    74ad:	00 00 00 

00000000000074b0 <fwp_args37>:
    74b0:	f3 0f 1e fa          	endbr64
    74b4:	85 d2                	test   %edx,%edx
    74b6:	74 04                	je     74bc <fwp_args37+0xc>
    74b8:	85 f6                	test   %esi,%esi
    74ba:	74 04                	je     74c0 <fwp_args37+0x10>
    74bc:	c3                   	ret
    74bd:	0f 1f 00             	nopl   (%rax)
    74c0:	48 8b 15 71 d6 01 00 	mov    0x1d671(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    74c7:	48 8b 07             	mov    (%rdi),%rax
    74ca:	48 2b 05 3f d6 01 00 	sub    0x1d63f(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    74d1:	48 c1 e2 10          	shl    $0x10,%rdx
    74d5:	48 39 d0             	cmp    %rdx,%rax
    74d8:	73 e2                	jae    74bc <fwp_args37+0xc>
    74da:	48 89 c2             	mov    %rax,%rdx
    74dd:	48 c1 ea 10          	shr    $0x10,%rdx
    74e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74e5:	48 8b 15 6c d6 01 00 	mov    0x1d66c(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    74ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    74f4:	48 85 ff             	test   %rdi,%rdi
    74f7:	74 c3                	je     74bc <fwp_args37+0xc>
    74f9:	0f b6 0a             	movzbl (%rdx),%ecx
    74fc:	80 f9 02             	cmp    $0x2,%cl
    74ff:	74 2f                	je     7530 <fwp_args37+0x80>
    7501:	80 f9 01             	cmp    $0x1,%cl
    7504:	75 b6                	jne    74bc <fwp_args37+0xc>
    7506:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7509:	0f b7 c0             	movzwl %ax,%eax
    750c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    750f:	48 0f af c1          	imul   %rcx,%rax
    7513:	48 c1 e8 20          	shr    $0x20,%rax
    7517:	48 39 d0             	cmp    %rdx,%rax
    751a:	73 a0                	jae    74bc <fwp_args37+0xc>
    751c:	48 01 c7             	add    %rax,%rdi
    751f:	0f b6 07             	movzbl (%rdi),%eax
    7522:	84 c0                	test   %al,%al
    7524:	74 96                	je     74bc <fwp_args37+0xc>
    7526:	3c fd                	cmp    $0xfd,%al
    7528:	77 0c                	ja     7536 <fwp_args37+0x86>
    752a:	83 c0 01             	add    $0x1,%eax
    752d:	88 07                	mov    %al,(%rdi)
    752f:	c3                   	ret
    7530:	66 85 c0             	test   %ax,%ax
    7533:	74 ea                	je     751f <fwp_args37+0x6f>
    7535:	c3                   	ret
    7536:	e9 b5 dc ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    753b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007540 <fwp_caps37>:
    7540:	f3 0f 1e fa          	endbr64
    7544:	48 83 ec 18          	sub    $0x18,%rsp
    7548:	8b 57 04             	mov    0x4(%rdi),%edx
    754b:	48 89 f8             	mov    %rdi,%rax
    754e:	85 d2                	test   %edx,%edx
    7550:	0f 84 9a 00 00 00    	je     75f0 <fwp_caps37+0xb0>
    7556:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    755a:	85 f6                	test   %esi,%esi
    755c:	0f 85 9e 00 00 00    	jne    7600 <fwp_caps37+0xc0>
    7562:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7567:	e8 44 f7 ff ff       	call   6cb0 <fwp_drop4>
    756c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7571:	48 8b 0d c0 d5 01 00 	mov    0x1d5c0(%rip),%rcx        # 24b38 <fwp_heap+0x13d8>
    7578:	48 89 c2             	mov    %rax,%rdx
    757b:	48 2b 15 8e d5 01 00 	sub    0x1d58e(%rip),%rdx        # 24b10 <fwp_heap+0x13b0>
    7582:	48 c1 e1 10          	shl    $0x10,%rcx
    7586:	48 39 ca             	cmp    %rcx,%rdx
    7589:	73 6d                	jae    75f8 <fwp_caps37+0xb8>
    758b:	48 89 d1             	mov    %rdx,%rcx
    758e:	48 c1 e9 10          	shr    $0x10,%rcx
    7592:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7596:	48 8b 0d bb d5 01 00 	mov    0x1d5bb(%rip),%rcx        # 24b58 <fwp_heap+0x13f8>
    759d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    75a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    75a5:	48 85 f6             	test   %rsi,%rsi
    75a8:	74 4e                	je     75f8 <fwp_caps37+0xb8>
    75aa:	0f b6 39             	movzbl (%rcx),%edi
    75ad:	40 80 ff 02          	cmp    $0x2,%dil
    75b1:	0f 84 b9 00 00 00    	je     7670 <fwp_caps37+0x130>
    75b7:	40 80 ff 01          	cmp    $0x1,%dil
    75bb:	75 3b                	jne    75f8 <fwp_caps37+0xb8>
    75bd:	8b 79 18             	mov    0x18(%rcx),%edi
    75c0:	0f b7 d2             	movzwl %dx,%edx
    75c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    75c6:	48 0f af d7          	imul   %rdi,%rdx
    75ca:	48 c1 ea 20          	shr    $0x20,%rdx
    75ce:	48 39 ca             	cmp    %rcx,%rdx
    75d1:	73 25                	jae    75f8 <fwp_caps37+0xb8>
    75d3:	48 01 d6             	add    %rdx,%rsi
    75d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    75d9:	75 1d                	jne    75f8 <fwp_caps37+0xb8>
    75db:	48 89 c7             	mov    %rax,%rdi
    75de:	48 83 c4 18          	add    $0x18,%rsp
    75e2:	e9 69 df ff ff       	jmp    5550 <fwp_mem_free>
    75e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75ee:	00 00 
    75f0:	85 f6                	test   %esi,%esi
    75f2:	0f 84 79 ff ff ff    	je     7571 <fwp_caps37+0x31>
    75f8:	48 83 c4 18          	add    $0x18,%rsp
    75fc:	c3                   	ret
    75fd:	0f 1f 00             	nopl   (%rax)
    7600:	48 8b 05 31 d5 01 00 	mov    0x1d531(%rip),%rax        # 24b38 <fwp_heap+0x13d8>
    7607:	48 2b 3d 02 d5 01 00 	sub    0x1d502(%rip),%rdi        # 24b10 <fwp_heap+0x13b0>
    760e:	48 c1 e0 10          	shl    $0x10,%rax
    7612:	48 39 c7             	cmp    %rax,%rdi
    7615:	73 e1                	jae    75f8 <fwp_caps37+0xb8>
    7617:	48 89 f8             	mov    %rdi,%rax
    761a:	48 c1 e8 10          	shr    $0x10,%rax
    761e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7622:	48 8b 05 2f d5 01 00 	mov    0x1d52f(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    7629:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    762d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7631:	48 85 c0             	test   %rax,%rax
    7634:	74 c2                	je     75f8 <fwp_caps37+0xb8>
    7636:	0f b6 0a             	movzbl (%rdx),%ecx
    7639:	80 f9 02             	cmp    $0x2,%cl
    763c:	74 42                	je     7680 <fwp_caps37+0x140>
    763e:	80 f9 01             	cmp    $0x1,%cl
    7641:	75 b5                	jne    75f8 <fwp_caps37+0xb8>
    7643:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7646:	0f b7 ff             	movzwl %di,%edi
    7649:	8b 52 1c             	mov    0x1c(%rdx),%edx
    764c:	48 0f af f9          	imul   %rcx,%rdi
    7650:	48 c1 ef 20          	shr    $0x20,%rdi
    7654:	48 39 d7             	cmp    %rdx,%rdi
    7657:	73 9f                	jae    75f8 <fwp_caps37+0xb8>
    7659:	48 01 f8             	add    %rdi,%rax
    765c:	0f b6 10             	movzbl (%rax),%edx
    765f:	84 d2                	test   %dl,%dl
    7661:	74 95                	je     75f8 <fwp_caps37+0xb8>
    7663:	80 fa fd             	cmp    $0xfd,%dl
    7666:	77 23                	ja     768b <fwp_caps37+0x14b>
    7668:	83 c2 01             	add    $0x1,%edx
    766b:	88 10                	mov    %dl,(%rax)
    766d:	eb 89                	jmp    75f8 <fwp_caps37+0xb8>
    766f:	90                   	nop
    7670:	66 85 d2             	test   %dx,%dx
    7673:	0f 85 7f ff ff ff    	jne    75f8 <fwp_caps37+0xb8>
    7679:	e9 58 ff ff ff       	jmp    75d6 <fwp_caps37+0x96>
    767e:	66 90                	xchg   %ax,%ax
    7680:	66 85 ff             	test   %di,%di
    7683:	0f 85 6f ff ff ff    	jne    75f8 <fwp_caps37+0xb8>
    7689:	eb d1                	jmp    765c <fwp_caps37+0x11c>
    768b:	48 89 c7             	mov    %rax,%rdi
    768e:	48 83 c4 18          	add    $0x18,%rsp
    7692:	e9 59 db ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7697:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    769e:	00 00 

00000000000076a0 <fwp_drop0>:
    76a0:	f3 0f 1e fa          	endbr64
    76a4:	48 8b 15 8d d4 01 00 	mov    0x1d48d(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    76ab:	48 89 f8             	mov    %rdi,%rax
    76ae:	48 2b 05 5b d4 01 00 	sub    0x1d45b(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    76b5:	48 c1 e2 10          	shl    $0x10,%rdx
    76b9:	48 39 d0             	cmp    %rdx,%rax
    76bc:	0f 83 36 01 00 00    	jae    77f8 <fwp_drop0+0x158>
    76c2:	48 83 ec 18          	sub    $0x18,%rsp
    76c6:	48 8d 35 93 c0 01 00 	lea    0x1c093(%rip),%rsi        # 23760 <fwp_heap>
    76cd:	48 89 c2             	mov    %rax,%rdx
    76d0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    76d7:	48 c1 ea 10          	shr    $0x10,%rdx
    76db:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    76df:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    76e3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    76e7:	48 85 d2             	test   %rdx,%rdx
    76ea:	74 42                	je     772e <fwp_drop0+0x8e>
    76ec:	44 0f b6 01          	movzbl (%rcx),%r8d
    76f0:	41 80 f8 02          	cmp    $0x2,%r8b
    76f4:	74 42                	je     7738 <fwp_drop0+0x98>
    76f6:	41 80 f8 01          	cmp    $0x1,%r8b
    76fa:	75 32                	jne    772e <fwp_drop0+0x8e>
    76fc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7700:	0f b7 c0             	movzwl %ax,%eax
    7703:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7706:	49 0f af c0          	imul   %r8,%rax
    770a:	48 c1 e8 20          	shr    $0x20,%rax
    770e:	48 39 c8             	cmp    %rcx,%rax
    7711:	73 1b                	jae    772e <fwp_drop0+0x8e>
    7713:	48 01 c2             	add    %rax,%rdx
    7716:	0f b6 02             	movzbl (%rdx),%eax
    7719:	84 c0                	test   %al,%al
    771b:	74 11                	je     772e <fwp_drop0+0x8e>
    771d:	3c 01                	cmp    $0x1,%al
    771f:	74 27                	je     7748 <fwp_drop0+0xa8>
    7721:	3c ff                	cmp    $0xff,%al
    7723:	0f 84 e7 00 00 00    	je     7810 <fwp_drop0+0x170>
    7729:	83 e8 01             	sub    $0x1,%eax
    772c:	88 02                	mov    %al,(%rdx)
    772e:	48 83 c4 18          	add    $0x18,%rsp
    7732:	c3                   	ret
    7733:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7738:	66 85 c0             	test   %ax,%ax
    773b:	74 d9                	je     7716 <fwp_drop0+0x76>
    773d:	48 83 c4 18          	add    $0x18,%rsp
    7741:	c3                   	ret
    7742:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7748:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    774f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7756:	48 89 f8             	mov    %rdi,%rax
    7759:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    775d:	48 29 c8             	sub    %rcx,%rax
    7760:	48 c1 e2 10          	shl    $0x10,%rdx
    7764:	48 39 d0             	cmp    %rdx,%rax
    7767:	73 71                	jae    77da <fwp_drop0+0x13a>
    7769:	49 89 c2             	mov    %rax,%r10
    776c:	49 c1 ea 10          	shr    $0x10,%r10
    7770:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7774:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7778:	4d 8b 51 20          	mov    0x20(%r9),%r10
    777c:	4d 85 d2             	test   %r10,%r10
    777f:	74 59                	je     77da <fwp_drop0+0x13a>
    7781:	45 0f b6 19          	movzbl (%r9),%r11d
    7785:	41 80 fb 02          	cmp    $0x2,%r11b
    7789:	74 75                	je     7800 <fwp_drop0+0x160>
    778b:	41 80 fb 01          	cmp    $0x1,%r11b
    778f:	75 49                	jne    77da <fwp_drop0+0x13a>
    7791:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7795:	0f b7 c0             	movzwl %ax,%eax
    7798:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    779c:	49 0f af c3          	imul   %r11,%rax
    77a0:	48 c1 e8 20          	shr    $0x20,%rax
    77a4:	4c 39 c8             	cmp    %r9,%rax
    77a7:	73 31                	jae    77da <fwp_drop0+0x13a>
    77a9:	49 01 c2             	add    %rax,%r10
    77ac:	41 80 3a 01          	cmpb   $0x1,(%r10)
    77b0:	75 28                	jne    77da <fwp_drop0+0x13a>
    77b2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    77b7:	e8 94 dd ff ff       	call   5550 <fwp_mem_free>
    77bc:	48 8d 35 9d bf 01 00 	lea    0x1bf9d(%rip),%rsi        # 23760 <fwp_heap>
    77c3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    77c8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    77cf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    77d6:	48 c1 e2 10          	shl    $0x10,%rdx
    77da:	4c 89 c0             	mov    %r8,%rax
    77dd:	48 29 c8             	sub    %rcx,%rax
    77e0:	48 39 d0             	cmp    %rdx,%rax
    77e3:	0f 83 45 ff ff ff    	jae    772e <fwp_drop0+0x8e>
    77e9:	4c 89 c7             	mov    %r8,%rdi
    77ec:	e9 dc fe ff ff       	jmp    76cd <fwp_drop0+0x2d>
    77f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77f8:	c3                   	ret
    77f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7800:	66 85 c0             	test   %ax,%ax
    7803:	75 d5                	jne    77da <fwp_drop0+0x13a>
    7805:	eb a5                	jmp    77ac <fwp_drop0+0x10c>
    7807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    780e:	00 00 
    7810:	48 89 d0             	mov    %rdx,%rax
    7813:	48 c1 e8 11          	shr    $0x11,%rax
    7817:	48 31 d0             	xor    %rdx,%rax
    781a:	48 89 c1             	mov    %rax,%rcx
    781d:	48 c1 e9 09          	shr    $0x9,%rcx
    7821:	48 31 c8             	xor    %rcx,%rax
    7824:	0f b6 c8             	movzbl %al,%ecx
    7827:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    782e:	00 
    782f:	48 85 c0             	test   %rax,%rax
    7832:	75 15                	jne    7849 <fwp_drop0+0x1a9>
    7834:	eb 4e                	jmp    7884 <fwp_drop0+0x1e4>
    7836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    783d:	00 00 00 
    7840:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7844:	48 85 c0             	test   %rax,%rax
    7847:	74 3b                	je     7884 <fwp_drop0+0x1e4>
    7849:	48 89 c1             	mov    %rax,%rcx
    784c:	48 39 10             	cmp    %rdx,(%rax)
    784f:	75 ef                	jne    7840 <fwp_drop0+0x1a0>
    7851:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7855:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7859:	48 89 48 08          	mov    %rcx,0x8(%rax)
    785d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7864:	0f 85 c4 fe ff ff    	jne    772e <fwp_drop0+0x8e>
    786a:	48 89 d7             	mov    %rdx,%rdi
    786d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7872:	e8 99 da ff ff       	call   5310 <fwp_rc_forget_slot>
    7877:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    787c:	c6 02 fe             	movb   $0xfe,(%rdx)
    787f:	e9 aa fe ff ff       	jmp    772e <fwp_drop0+0x8e>
    7884:	48 8d 3d 15 7f 00 00 	lea    0x7f15(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    788b:	e8 10 c9 ff ff       	call   41a0 <fwp_trap>

0000000000007890 <fwp_drop1>:
    7890:	f3 0f 1e fa          	endbr64
    7894:	48 8b 15 9d d2 01 00 	mov    0x1d29d(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    789b:	48 89 f8             	mov    %rdi,%rax
    789e:	48 2b 05 6b d2 01 00 	sub    0x1d26b(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    78a5:	48 c1 e2 10          	shl    $0x10,%rdx
    78a9:	48 39 d0             	cmp    %rdx,%rax
    78ac:	0f 83 36 01 00 00    	jae    79e8 <fwp_drop1+0x158>
    78b2:	48 83 ec 18          	sub    $0x18,%rsp
    78b6:	48 8d 35 a3 be 01 00 	lea    0x1bea3(%rip),%rsi        # 23760 <fwp_heap>
    78bd:	48 89 c2             	mov    %rax,%rdx
    78c0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    78c7:	48 c1 ea 10          	shr    $0x10,%rdx
    78cb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    78cf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    78d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    78d7:	48 85 d2             	test   %rdx,%rdx
    78da:	74 42                	je     791e <fwp_drop1+0x8e>
    78dc:	44 0f b6 01          	movzbl (%rcx),%r8d
    78e0:	41 80 f8 02          	cmp    $0x2,%r8b
    78e4:	74 42                	je     7928 <fwp_drop1+0x98>
    78e6:	41 80 f8 01          	cmp    $0x1,%r8b
    78ea:	75 32                	jne    791e <fwp_drop1+0x8e>
    78ec:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    78f0:	0f b7 c0             	movzwl %ax,%eax
    78f3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    78f6:	49 0f af c0          	imul   %r8,%rax
    78fa:	48 c1 e8 20          	shr    $0x20,%rax
    78fe:	48 39 c8             	cmp    %rcx,%rax
    7901:	73 1b                	jae    791e <fwp_drop1+0x8e>
    7903:	48 01 c2             	add    %rax,%rdx
    7906:	0f b6 02             	movzbl (%rdx),%eax
    7909:	84 c0                	test   %al,%al
    790b:	74 11                	je     791e <fwp_drop1+0x8e>
    790d:	3c 01                	cmp    $0x1,%al
    790f:	74 27                	je     7938 <fwp_drop1+0xa8>
    7911:	3c ff                	cmp    $0xff,%al
    7913:	0f 84 e7 00 00 00    	je     7a00 <fwp_drop1+0x170>
    7919:	83 e8 01             	sub    $0x1,%eax
    791c:	88 02                	mov    %al,(%rdx)
    791e:	48 83 c4 18          	add    $0x18,%rsp
    7922:	c3                   	ret
    7923:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7928:	66 85 c0             	test   %ax,%ax
    792b:	74 d9                	je     7906 <fwp_drop1+0x76>
    792d:	48 83 c4 18          	add    $0x18,%rsp
    7931:	c3                   	ret
    7932:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7938:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    793f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7946:	48 89 f8             	mov    %rdi,%rax
    7949:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    794d:	48 29 c8             	sub    %rcx,%rax
    7950:	48 c1 e2 10          	shl    $0x10,%rdx
    7954:	48 39 d0             	cmp    %rdx,%rax
    7957:	73 71                	jae    79ca <fwp_drop1+0x13a>
    7959:	49 89 c2             	mov    %rax,%r10
    795c:	49 c1 ea 10          	shr    $0x10,%r10
    7960:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7964:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7968:	4d 8b 51 20          	mov    0x20(%r9),%r10
    796c:	4d 85 d2             	test   %r10,%r10
    796f:	74 59                	je     79ca <fwp_drop1+0x13a>
    7971:	45 0f b6 19          	movzbl (%r9),%r11d
    7975:	41 80 fb 02          	cmp    $0x2,%r11b
    7979:	74 75                	je     79f0 <fwp_drop1+0x160>
    797b:	41 80 fb 01          	cmp    $0x1,%r11b
    797f:	75 49                	jne    79ca <fwp_drop1+0x13a>
    7981:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7985:	0f b7 c0             	movzwl %ax,%eax
    7988:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    798c:	49 0f af c3          	imul   %r11,%rax
    7990:	48 c1 e8 20          	shr    $0x20,%rax
    7994:	4c 39 c8             	cmp    %r9,%rax
    7997:	73 31                	jae    79ca <fwp_drop1+0x13a>
    7999:	49 01 c2             	add    %rax,%r10
    799c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    79a0:	75 28                	jne    79ca <fwp_drop1+0x13a>
    79a2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    79a7:	e8 a4 db ff ff       	call   5550 <fwp_mem_free>
    79ac:	48 8d 35 ad bd 01 00 	lea    0x1bdad(%rip),%rsi        # 23760 <fwp_heap>
    79b3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    79b8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    79bf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    79c6:	48 c1 e2 10          	shl    $0x10,%rdx
    79ca:	4c 89 c0             	mov    %r8,%rax
    79cd:	48 29 c8             	sub    %rcx,%rax
    79d0:	48 39 d0             	cmp    %rdx,%rax
    79d3:	0f 83 45 ff ff ff    	jae    791e <fwp_drop1+0x8e>
    79d9:	4c 89 c7             	mov    %r8,%rdi
    79dc:	e9 dc fe ff ff       	jmp    78bd <fwp_drop1+0x2d>
    79e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79e8:	c3                   	ret
    79e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79f0:	66 85 c0             	test   %ax,%ax
    79f3:	75 d5                	jne    79ca <fwp_drop1+0x13a>
    79f5:	eb a5                	jmp    799c <fwp_drop1+0x10c>
    79f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    79fe:	00 00 
    7a00:	48 89 d0             	mov    %rdx,%rax
    7a03:	48 c1 e8 11          	shr    $0x11,%rax
    7a07:	48 31 d0             	xor    %rdx,%rax
    7a0a:	48 89 c1             	mov    %rax,%rcx
    7a0d:	48 c1 e9 09          	shr    $0x9,%rcx
    7a11:	48 31 c8             	xor    %rcx,%rax
    7a14:	0f b6 c8             	movzbl %al,%ecx
    7a17:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7a1e:	00 
    7a1f:	48 85 c0             	test   %rax,%rax
    7a22:	75 25                	jne    7a49 <fwp_drop1+0x1b9>
    7a24:	eb 5e                	jmp    7a84 <fwp_drop1+0x1f4>
    7a26:	0f 1f 40 00          	nopl   0x0(%rax)
    7a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a31:	00 00 00 00 
    7a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a3c:	00 00 00 00 
    7a40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7a44:	48 85 c0             	test   %rax,%rax
    7a47:	74 3b                	je     7a84 <fwp_drop1+0x1f4>
    7a49:	48 89 c1             	mov    %rax,%rcx
    7a4c:	48 39 10             	cmp    %rdx,(%rax)
    7a4f:	75 ef                	jne    7a40 <fwp_drop1+0x1b0>
    7a51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7a59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7a5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7a64:	0f 85 b4 fe ff ff    	jne    791e <fwp_drop1+0x8e>
    7a6a:	48 89 d7             	mov    %rdx,%rdi
    7a6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a72:	e8 99 d8 ff ff       	call   5310 <fwp_rc_forget_slot>
    7a77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7a7f:	e9 9a fe ff ff       	jmp    791e <fwp_drop1+0x8e>
    7a84:	48 8d 3d 15 7d 00 00 	lea    0x7d15(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    7a8b:	e8 10 c7 ff ff       	call   41a0 <fwp_trap>

0000000000007a90 <fwp_drop10>:
    7a90:	48 8b 0d a1 d0 01 00 	mov    0x1d0a1(%rip),%rcx        # 24b38 <fwp_heap+0x13d8>
    7a97:	48 89 f8             	mov    %rdi,%rax
    7a9a:	48 2b 05 6f d0 01 00 	sub    0x1d06f(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    7aa1:	48 c1 e1 10          	shl    $0x10,%rcx
    7aa5:	48 39 c8             	cmp    %rcx,%rax
    7aa8:	0f 83 c2 01 00 00    	jae    7c70 <fwp_drop10+0x1e0>
    7aae:	48 83 ec 18          	sub    $0x18,%rsp
    7ab2:	48 89 fa             	mov    %rdi,%rdx
    7ab5:	48 8d 35 a4 bc 01 00 	lea    0x1bca4(%rip),%rsi        # 23760 <fwp_heap>
    7abc:	48 89 c1             	mov    %rax,%rcx
    7abf:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7ac6:	48 c1 e9 10          	shr    $0x10,%rcx
    7aca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7ace:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7ad2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7ad6:	48 85 c9             	test   %rcx,%rcx
    7ad9:	74 46                	je     7b21 <fwp_drop10+0x91>
    7adb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7adf:	41 80 f9 02          	cmp    $0x2,%r9b
    7ae3:	0f 84 d7 00 00 00    	je     7bc0 <fwp_drop10+0x130>
    7ae9:	41 80 f9 01          	cmp    $0x1,%r9b
    7aed:	75 32                	jne    7b21 <fwp_drop10+0x91>
    7aef:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7af3:	0f b7 c0             	movzwl %ax,%eax
    7af6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7af9:	49 0f af c1          	imul   %r9,%rax
    7afd:	48 c1 e8 20          	shr    $0x20,%rax
    7b01:	48 39 f8             	cmp    %rdi,%rax
    7b04:	73 1b                	jae    7b21 <fwp_drop10+0x91>
    7b06:	48 01 c1             	add    %rax,%rcx
    7b09:	0f b6 01             	movzbl (%rcx),%eax
    7b0c:	84 c0                	test   %al,%al
    7b0e:	74 11                	je     7b21 <fwp_drop10+0x91>
    7b10:	3c 01                	cmp    $0x1,%al
    7b12:	74 1c                	je     7b30 <fwp_drop10+0xa0>
    7b14:	3c ff                	cmp    $0xff,%al
    7b16:	0f 84 5c 01 00 00    	je     7c78 <fwp_drop10+0x1e8>
    7b1c:	83 e8 01             	sub    $0x1,%eax
    7b1f:	88 01                	mov    %al,(%rcx)
    7b21:	48 83 c4 18          	add    $0x18,%rsp
    7b25:	c3                   	ret
    7b26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b2d:	00 00 00 
    7b30:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7b37:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7b3e:	48 89 d0             	mov    %rdx,%rax
    7b41:	49 89 d1             	mov    %rdx,%r9
    7b44:	48 c1 e1 10          	shl    $0x10,%rcx
    7b48:	48 29 f8             	sub    %rdi,%rax
    7b4b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7b4f:	78 7f                	js     7bd0 <fwp_drop10+0x140>
    7b51:	48 39 c8             	cmp    %rcx,%rax
    7b54:	73 cb                	jae    7b21 <fwp_drop10+0x91>
    7b56:	48 89 c1             	mov    %rax,%rcx
    7b59:	48 c1 e9 10          	shr    $0x10,%rcx
    7b5d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7b61:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7b65:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7b69:	48 85 f6             	test   %rsi,%rsi
    7b6c:	74 b3                	je     7b21 <fwp_drop10+0x91>
    7b6e:	0f b6 39             	movzbl (%rcx),%edi
    7b71:	40 80 ff 02          	cmp    $0x2,%dil
    7b75:	74 39                	je     7bb0 <fwp_drop10+0x120>
    7b77:	40 80 ff 01          	cmp    $0x1,%dil
    7b7b:	75 a4                	jne    7b21 <fwp_drop10+0x91>
    7b7d:	8b 79 18             	mov    0x18(%rcx),%edi
    7b80:	0f b7 c0             	movzwl %ax,%eax
    7b83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b86:	48 0f af c7          	imul   %rdi,%rax
    7b8a:	48 c1 e8 20          	shr    $0x20,%rax
    7b8e:	48 39 c8             	cmp    %rcx,%rax
    7b91:	73 8e                	jae    7b21 <fwp_drop10+0x91>
    7b93:	48 01 c6             	add    %rax,%rsi
    7b96:	80 3e 01             	cmpb   $0x1,(%rsi)
    7b99:	75 86                	jne    7b21 <fwp_drop10+0x91>
    7b9b:	48 89 d7             	mov    %rdx,%rdi
    7b9e:	48 83 c4 18          	add    $0x18,%rsp
    7ba2:	e9 a9 d9 ff ff       	jmp    5550 <fwp_mem_free>
    7ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bae:	00 00 
    7bb0:	66 85 c0             	test   %ax,%ax
    7bb3:	74 e1                	je     7b96 <fwp_drop10+0x106>
    7bb5:	48 83 c4 18          	add    $0x18,%rsp
    7bb9:	c3                   	ret
    7bba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bc0:	66 85 c0             	test   %ax,%ax
    7bc3:	0f 84 40 ff ff ff    	je     7b09 <fwp_drop10+0x79>
    7bc9:	48 83 c4 18          	add    $0x18,%rsp
    7bcd:	c3                   	ret
    7bce:	66 90                	xchg   %ax,%ax
    7bd0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7bd4:	48 39 c8             	cmp    %rcx,%rax
    7bd7:	73 74                	jae    7c4d <fwp_drop10+0x1bd>
    7bd9:	49 89 c2             	mov    %rax,%r10
    7bdc:	49 c1 ea 10          	shr    $0x10,%r10
    7be0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7be4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7be8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7bec:	4d 85 d2             	test   %r10,%r10
    7bef:	74 5c                	je     7c4d <fwp_drop10+0x1bd>
    7bf1:	45 0f b6 18          	movzbl (%r8),%r11d
    7bf5:	41 80 fb 02          	cmp    $0x2,%r11b
    7bf9:	74 6d                	je     7c68 <fwp_drop10+0x1d8>
    7bfb:	41 80 fb 01          	cmp    $0x1,%r11b
    7bff:	75 4c                	jne    7c4d <fwp_drop10+0x1bd>
    7c01:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7c05:	0f b7 c0             	movzwl %ax,%eax
    7c08:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7c0c:	49 0f af c3          	imul   %r11,%rax
    7c10:	48 c1 e8 20          	shr    $0x20,%rax
    7c14:	4c 39 c0             	cmp    %r8,%rax
    7c17:	73 34                	jae    7c4d <fwp_drop10+0x1bd>
    7c19:	49 01 c2             	add    %rax,%r10
    7c1c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c20:	75 2b                	jne    7c4d <fwp_drop10+0x1bd>
    7c22:	4c 89 cf             	mov    %r9,%rdi
    7c25:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c2a:	e8 21 d9 ff ff       	call   5550 <fwp_mem_free>
    7c2f:	48 8d 35 2a bb 01 00 	lea    0x1bb2a(%rip),%rsi        # 23760 <fwp_heap>
    7c36:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c3b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7c42:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7c49:	48 c1 e1 10          	shl    $0x10,%rcx
    7c4d:	48 89 d0             	mov    %rdx,%rax
    7c50:	48 29 f8             	sub    %rdi,%rax
    7c53:	48 39 c8             	cmp    %rcx,%rax
    7c56:	0f 82 60 fe ff ff    	jb     7abc <fwp_drop10+0x2c>
    7c5c:	e9 c0 fe ff ff       	jmp    7b21 <fwp_drop10+0x91>
    7c61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c68:	66 85 c0             	test   %ax,%ax
    7c6b:	75 e0                	jne    7c4d <fwp_drop10+0x1bd>
    7c6d:	eb ad                	jmp    7c1c <fwp_drop10+0x18c>
    7c6f:	90                   	nop
    7c70:	c3                   	ret
    7c71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c78:	48 89 c8             	mov    %rcx,%rax
    7c7b:	48 c1 e8 11          	shr    $0x11,%rax
    7c7f:	48 31 c8             	xor    %rcx,%rax
    7c82:	48 89 c2             	mov    %rax,%rdx
    7c85:	48 c1 ea 09          	shr    $0x9,%rdx
    7c89:	48 31 d0             	xor    %rdx,%rax
    7c8c:	0f b6 d0             	movzbl %al,%edx
    7c8f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7c96:	00 
    7c97:	48 85 c0             	test   %rax,%rax
    7c9a:	75 0d                	jne    7ca9 <fwp_drop10+0x219>
    7c9c:	eb 46                	jmp    7ce4 <fwp_drop10+0x254>
    7c9e:	66 90                	xchg   %ax,%ax
    7ca0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7ca4:	48 85 c0             	test   %rax,%rax
    7ca7:	74 3b                	je     7ce4 <fwp_drop10+0x254>
    7ca9:	48 89 c2             	mov    %rax,%rdx
    7cac:	48 39 08             	cmp    %rcx,(%rax)
    7caf:	75 ef                	jne    7ca0 <fwp_drop10+0x210>
    7cb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7cb5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7cb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7cbd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7cc4:	0f 85 57 fe ff ff    	jne    7b21 <fwp_drop10+0x91>
    7cca:	48 89 cf             	mov    %rcx,%rdi
    7ccd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7cd2:	e8 39 d6 ff ff       	call   5310 <fwp_rc_forget_slot>
    7cd7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7cdc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7cdf:	e9 3d fe ff ff       	jmp    7b21 <fwp_drop10+0x91>
    7ce4:	48 8d 3d b5 7a 00 00 	lea    0x7ab5(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    7ceb:	e8 b0 c4 ff ff       	call   41a0 <fwp_trap>

0000000000007cf0 <f37>:
    7cf0:	41 57                	push   %r15
    7cf2:	41 56                	push   %r14
    7cf4:	41 55                	push   %r13
    7cf6:	41 54                	push   %r12
    7cf8:	55                   	push   %rbp
    7cf9:	53                   	push   %rbx
    7cfa:	48 83 ec 38          	sub    $0x38,%rsp
    7cfe:	48 8b 15 33 ce 01 00 	mov    0x1ce33(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    7d05:	48 8b 0d 04 ce 01 00 	mov    0x1ce04(%rip),%rcx        # 24b10 <fwp_heap+0x13b0>
    7d0c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7d13:	00 00 
    7d15:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7d1a:	49 89 fc             	mov    %rdi,%r12
    7d1d:	48 c1 e2 10          	shl    $0x10,%rdx
    7d21:	48 85 ff             	test   %rdi,%rdi
    7d24:	0f 84 bc 02 00 00    	je     7fe6 <f37+0x2f6>
    7d2a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7d2f:	48 89 d8             	mov    %rbx,%rax
    7d32:	48 29 c8             	sub    %rcx,%rax
    7d35:	48 39 d0             	cmp    %rdx,%rax
    7d38:	0f 83 72 03 00 00    	jae    80b0 <f37+0x3c0>
    7d3e:	48 89 c2             	mov    %rax,%rdx
    7d41:	48 c1 ea 10          	shr    $0x10,%rdx
    7d45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d49:	48 8b 15 08 ce 01 00 	mov    0x1ce08(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    7d50:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d54:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d58:	48 85 ff             	test   %rdi,%rdi
    7d5b:	0f 84 4f 03 00 00    	je     80b0 <f37+0x3c0>
    7d61:	0f b6 0a             	movzbl (%rdx),%ecx
    7d64:	80 f9 02             	cmp    $0x2,%cl
    7d67:	0f 84 53 02 00 00    	je     7fc0 <f37+0x2d0>
    7d6d:	80 f9 01             	cmp    $0x1,%cl
    7d70:	75 24                	jne    7d96 <f37+0xa6>
    7d72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d75:	0f b7 c0             	movzwl %ax,%eax
    7d78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d7b:	48 0f af c1          	imul   %rcx,%rax
    7d7f:	48 c1 e8 20          	shr    $0x20,%rax
    7d83:	48 39 d0             	cmp    %rdx,%rax
    7d86:	73 0e                	jae    7d96 <f37+0xa6>
    7d88:	48 01 c7             	add    %rax,%rdi
    7d8b:	0f b6 07             	movzbl (%rdi),%eax
    7d8e:	84 c0                	test   %al,%al
    7d90:	0f 85 ca 02 00 00    	jne    8060 <f37+0x370>
    7d96:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7d9b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7da0:	ba 01 00 00 00       	mov    $0x1,%edx
    7da5:	48 85 db             	test   %rbx,%rbx
    7da8:	74 13                	je     7dbd <f37+0xcd>
    7daa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7db0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7db4:	48 83 c2 01          	add    $0x1,%rdx
    7db8:	48 85 db             	test   %rbx,%rbx
    7dbb:	75 f3                	jne    7db0 <f37+0xc0>
    7dbd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7dc2:	48 85 c0             	test   %rax,%rax
    7dc5:	0f 84 15 03 00 00    	je     80e0 <f37+0x3f0>
    7dcb:	31 db                	xor    %ebx,%ebx
    7dcd:	0f 1f 00             	nopl   (%rax)
    7dd0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7dd4:	48 83 c3 01          	add    $0x1,%rbx
    7dd8:	48 85 c0             	test   %rax,%rax
    7ddb:	75 f3                	jne    7dd0 <f37+0xe0>
    7ddd:	48 39 d3             	cmp    %rdx,%rbx
    7de0:	48 0f 47 da          	cmova  %rdx,%rbx
    7de4:	48 89 d8             	mov    %rbx,%rax
    7de7:	48 c1 e8 3c          	shr    $0x3c,%rax
    7deb:	0f 85 8f 03 00 00    	jne    8180 <f37+0x490>
    7df1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7df5:	be 02 00 00 00       	mov    $0x2,%esi
    7dfa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7e01:	00 
    7e02:	e8 49 dc ff ff       	call   5a50 <fwp_heap_alloc>
    7e07:	48 89 28             	mov    %rbp,(%rax)
    7e0a:	48 8b 15 27 cd 01 00 	mov    0x1cd27(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    7e11:	49 89 c6             	mov    %rax,%r14
    7e14:	48 2b 05 f5 cc 01 00 	sub    0x1ccf5(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    7e1b:	48 c1 e2 10          	shl    $0x10,%rdx
    7e1f:	48 39 d0             	cmp    %rdx,%rax
    7e22:	73 57                	jae    7e7b <f37+0x18b>
    7e24:	48 89 c2             	mov    %rax,%rdx
    7e27:	48 c1 ea 10          	shr    $0x10,%rdx
    7e2b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e2f:	48 8b 15 22 cd 01 00 	mov    0x1cd22(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    7e36:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e3a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7e3e:	48 85 ed             	test   %rbp,%rbp
    7e41:	74 38                	je     7e7b <f37+0x18b>
    7e43:	0f b6 0a             	movzbl (%rdx),%ecx
    7e46:	80 f9 02             	cmp    $0x2,%cl
    7e49:	0f 84 51 02 00 00    	je     80a0 <f37+0x3b0>
    7e4f:	80 f9 01             	cmp    $0x1,%cl
    7e52:	75 27                	jne    7e7b <f37+0x18b>
    7e54:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e57:	0f b7 c0             	movzwl %ax,%eax
    7e5a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e5d:	48 0f af c1          	imul   %rcx,%rax
    7e61:	48 c1 e8 20          	shr    $0x20,%rax
    7e65:	48 39 d0             	cmp    %rdx,%rax
    7e68:	73 11                	jae    7e7b <f37+0x18b>
    7e6a:	48 01 c5             	add    %rax,%rbp
    7e6d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7e71:	0f 84 d5 02 00 00    	je     814c <f37+0x45c>
    7e77:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7e7b:	48 85 db             	test   %rbx,%rbx
    7e7e:	74 5d                	je     7edd <f37+0x1ed>
    7e80:	48 c1 e3 04          	shl    $0x4,%rbx
    7e84:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7e89:	4c 89 f5             	mov    %r14,%rbp
    7e8c:	4d 89 e5             	mov    %r12,%r13
    7e8f:	4c 01 f3             	add    %r14,%rbx
    7e92:	0f 1f 00             	nopl   (%rax)
    7e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e9c:	00 00 00 00 
    7ea0:	49 8b 45 08          	mov    0x8(%r13),%rax
    7ea4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7ea8:	48 83 c5 10          	add    $0x10,%rbp
    7eac:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7eb1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7eb5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7eb9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7ebe:	e8 dd e2 ff ff       	call   61a0 <w120>
    7ec3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7ec8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7ecc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7ed0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7ed4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7ed8:	48 39 dd             	cmp    %rbx,%rbp
    7edb:	75 c3                	jne    7ea0 <f37+0x1b0>
    7edd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7ee2:	e8 c9 ed ff ff       	call   6cb0 <fwp_drop4>
    7ee7:	4c 89 e7             	mov    %r12,%rdi
    7eea:	e8 c1 ed ff ff       	call   6cb0 <fwp_drop4>
    7eef:	4c 89 f7             	mov    %r14,%rdi
    7ef2:	e8 69 e4 ff ff       	call   6360 <w176.constprop.0>
    7ef7:	4c 89 f7             	mov    %r14,%rdi
    7efa:	48 89 c3             	mov    %rax,%rbx
    7efd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7f03:	e8 88 fb ff ff       	call   7a90 <fwp_drop10>
    7f08:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7f0e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7f13:	31 ff                	xor    %edi,%edi
    7f15:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7f1a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7f1e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7f23:	e8 48 dc ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    7f28:	48 8b 15 09 cc 01 00 	mov    0x1cc09(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    7f2f:	48 89 c5             	mov    %rax,%rbp
    7f32:	48 2b 05 d7 cb 01 00 	sub    0x1cbd7(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    7f39:	48 c1 e2 10          	shl    $0x10,%rdx
    7f3d:	48 39 d0             	cmp    %rdx,%rax
    7f40:	73 55                	jae    7f97 <f37+0x2a7>
    7f42:	48 89 c2             	mov    %rax,%rdx
    7f45:	48 c1 ea 10          	shr    $0x10,%rdx
    7f49:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f4d:	48 8b 15 04 cc 01 00 	mov    0x1cc04(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    7f54:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f58:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7f5c:	48 85 db             	test   %rbx,%rbx
    7f5f:	74 36                	je     7f97 <f37+0x2a7>
    7f61:	0f b6 0a             	movzbl (%rdx),%ecx
    7f64:	80 f9 02             	cmp    $0x2,%cl
    7f67:	0f 84 1b 01 00 00    	je     8088 <f37+0x398>
    7f6d:	80 f9 01             	cmp    $0x1,%cl
    7f70:	75 25                	jne    7f97 <f37+0x2a7>
    7f72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f75:	0f b7 c0             	movzwl %ax,%eax
    7f78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f7b:	48 0f af c1          	imul   %rcx,%rax
    7f7f:	48 c1 e8 20          	shr    $0x20,%rax
    7f83:	48 39 d0             	cmp    %rdx,%rax
    7f86:	73 0f                	jae    7f97 <f37+0x2a7>
    7f88:	48 01 c3             	add    %rax,%rbx
    7f8b:	80 3b ff             	cmpb   $0xff,(%rbx)
    7f8e:	0f 84 ab 01 00 00    	je     813f <f37+0x44f>
    7f94:	c6 03 01             	movb   $0x1,(%rbx)
    7f97:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7f9c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7fa3:	00 00 
    7fa5:	0f 85 d0 01 00 00    	jne    817b <f37+0x48b>
    7fab:	48 83 c4 38          	add    $0x38,%rsp
    7faf:	48 89 e8             	mov    %rbp,%rax
    7fb2:	5b                   	pop    %rbx
    7fb3:	5d                   	pop    %rbp
    7fb4:	41 5c                	pop    %r12
    7fb6:	41 5d                	pop    %r13
    7fb8:	41 5e                	pop    %r14
    7fba:	41 5f                	pop    %r15
    7fbc:	c3                   	ret
    7fbd:	0f 1f 00             	nopl   (%rax)
    7fc0:	66 85 c0             	test   %ax,%ax
    7fc3:	0f 85 cd fd ff ff    	jne    7d96 <f37+0xa6>
    7fc9:	0f b6 07             	movzbl (%rdi),%eax
    7fcc:	84 c0                	test   %al,%al
    7fce:	0f 84 c2 fd ff ff    	je     7d96 <f37+0xa6>
    7fd4:	3c fd                	cmp    $0xfd,%al
    7fd6:	0f 87 95 01 00 00    	ja     8171 <f37+0x481>
    7fdc:	83 c0 01             	add    $0x1,%eax
    7fdf:	88 07                	mov    %al,(%rdi)
    7fe1:	e9 b0 fd ff ff       	jmp    7d96 <f37+0xa6>
    7fe6:	48 f7 d9             	neg    %rcx
    7fe9:	48 39 d1             	cmp    %rdx,%rcx
    7fec:	0f 83 ee 00 00 00    	jae    80e0 <f37+0x3f0>
    7ff2:	48 89 c8             	mov    %rcx,%rax
    7ff5:	48 c1 e8 10          	shr    $0x10,%rax
    7ff9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ffd:	48 8b 05 54 cb 01 00 	mov    0x1cb54(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    8004:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8008:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    800c:	48 85 ff             	test   %rdi,%rdi
    800f:	0f 84 cb 00 00 00    	je     80e0 <f37+0x3f0>
    8015:	0f b6 02             	movzbl (%rdx),%eax
    8018:	3c 02                	cmp    $0x2,%al
    801a:	0f 84 9a 00 00 00    	je     80ba <f37+0x3ca>
    8020:	3c 01                	cmp    $0x1,%al
    8022:	0f 85 b8 00 00 00    	jne    80e0 <f37+0x3f0>
    8028:	0f b7 c1             	movzwl %cx,%eax
    802b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    802e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8031:	48 0f af c1          	imul   %rcx,%rax
    8035:	48 c1 e8 20          	shr    $0x20,%rax
    8039:	48 39 d0             	cmp    %rdx,%rax
    803c:	0f 83 9e 00 00 00    	jae    80e0 <f37+0x3f0>
    8042:	48 01 c7             	add    %rax,%rdi
    8045:	0f b6 07             	movzbl (%rdi),%eax
    8048:	84 c0                	test   %al,%al
    804a:	0f 84 90 00 00 00    	je     80e0 <f37+0x3f0>
    8050:	31 db                	xor    %ebx,%ebx
    8052:	0f 1f 00             	nopl   (%rax)
    8055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    805c:	00 00 00 00 
    8060:	3c fd                	cmp    $0xfd,%al
    8062:	0f 87 f1 00 00 00    	ja     8159 <f37+0x469>
    8068:	83 c0 01             	add    $0x1,%eax
    806b:	88 07                	mov    %al,(%rdi)
    806d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8072:	31 d2                	xor    %edx,%edx
    8074:	4d 85 e4             	test   %r12,%r12
    8077:	0f 85 1e fd ff ff    	jne    7d9b <f37+0xab>
    807d:	e9 3b fd ff ff       	jmp    7dbd <f37+0xcd>
    8082:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8088:	66 85 c0             	test   %ax,%ax
    808b:	0f 85 06 ff ff ff    	jne    7f97 <f37+0x2a7>
    8091:	e9 f5 fe ff ff       	jmp    7f8b <f37+0x29b>
    8096:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    809d:	00 00 00 
    80a0:	66 85 c0             	test   %ax,%ax
    80a3:	0f 85 d2 fd ff ff    	jne    7e7b <f37+0x18b>
    80a9:	e9 bf fd ff ff       	jmp    7e6d <f37+0x17d>
    80ae:	66 90                	xchg   %ax,%ax
    80b0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    80b5:	e9 e6 fc ff ff       	jmp    7da0 <f37+0xb0>
    80ba:	66 85 c9             	test   %cx,%cx
    80bd:	75 21                	jne    80e0 <f37+0x3f0>
    80bf:	0f b6 07             	movzbl (%rdi),%eax
    80c2:	84 c0                	test   %al,%al
    80c4:	74 1a                	je     80e0 <f37+0x3f0>
    80c6:	3c fd                	cmp    $0xfd,%al
    80c8:	0f 87 be 00 00 00    	ja     818c <f37+0x49c>
    80ce:	83 c0 01             	add    $0x1,%eax
    80d1:	88 07                	mov    %al,(%rdi)
    80d3:	66 90                	xchg   %ax,%ax
    80d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80dc:	00 00 00 00 
    80e0:	be 02 00 00 00       	mov    $0x2,%esi
    80e5:	bf 08 00 00 00       	mov    $0x8,%edi
    80ea:	e8 61 d9 ff ff       	call   5a50 <fwp_heap_alloc>
    80ef:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    80f6:	48 8b 15 3b ca 01 00 	mov    0x1ca3b(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    80fd:	49 89 c6             	mov    %rax,%r14
    8100:	48 2b 05 09 ca 01 00 	sub    0x1ca09(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    8107:	48 c1 e2 10          	shl    $0x10,%rdx
    810b:	48 39 d0             	cmp    %rdx,%rax
    810e:	73 53                	jae    8163 <f37+0x473>
    8110:	48 89 c2             	mov    %rax,%rdx
    8113:	48 c1 ea 10          	shr    $0x10,%rdx
    8117:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    811b:	48 8b 15 36 ca 01 00 	mov    0x1ca36(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    8122:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8126:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    812a:	48 85 ed             	test   %rbp,%rbp
    812d:	74 34                	je     8163 <f37+0x473>
    812f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8136:	00 00 
    8138:	31 db                	xor    %ebx,%ebx
    813a:	e9 04 fd ff ff       	jmp    7e43 <f37+0x153>
    813f:	48 89 df             	mov    %rbx,%rdi
    8142:	e8 c9 d1 ff ff       	call   5310 <fwp_rc_forget_slot>
    8147:	e9 48 fe ff ff       	jmp    7f94 <f37+0x2a4>
    814c:	48 89 ef             	mov    %rbp,%rdi
    814f:	e8 bc d1 ff ff       	call   5310 <fwp_rc_forget_slot>
    8154:	e9 1e fd ff ff       	jmp    7e77 <f37+0x187>
    8159:	e8 92 d0 ff ff       	call   51f0 <fwp_rc_wide_dup>
    815e:	e9 0a ff ff ff       	jmp    806d <f37+0x37d>
    8163:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    816a:	00 00 
    816c:	e9 6c fd ff ff       	jmp    7edd <f37+0x1ed>
    8171:	e8 7a d0 ff ff       	call   51f0 <fwp_rc_wide_dup>
    8176:	e9 1b fc ff ff       	jmp    7d96 <f37+0xa6>
    817b:	e8 e0 b2 ff ff       	call   3460 <__stack_chk_fail@plt>
    8180:	48 8d 3d a6 6f 00 00 	lea    0x6fa6(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    8187:	e8 14 c0 ff ff       	call   41a0 <fwp_trap>
    818c:	e8 5f d0 ff ff       	call   51f0 <fwp_rc_wide_dup>
    8191:	e9 4a ff ff ff       	jmp    80e0 <f37+0x3f0>
    8196:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    819d:	00 00 00 

00000000000081a0 <fwp_owned_entry37>:
    81a0:	f3 0f 1e fa          	endbr64
    81a4:	48 8b 3f             	mov    (%rdi),%rdi
    81a7:	e9 44 fb ff ff       	jmp    7cf0 <f37>
    81ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000081b0 <e37>:
    81b0:	f3 0f 1e fa          	endbr64
    81b4:	53                   	push   %rbx
    81b5:	48 8b 1f             	mov    (%rdi),%rbx
    81b8:	48 89 df             	mov    %rbx,%rdi
    81bb:	e8 20 e2 ff ff       	call   63e0 <fwp_rc_share>
    81c0:	48 89 df             	mov    %rbx,%rdi
    81c3:	e8 28 fb ff ff       	call   7cf0 <f37>
    81c8:	48 89 c3             	mov    %rax,%rbx
    81cb:	48 89 c7             	mov    %rax,%rdi
    81ce:	e8 0d e2 ff ff       	call   63e0 <fwp_rc_share>
    81d3:	48 89 d8             	mov    %rbx,%rax
    81d6:	5b                   	pop    %rbx
    81d7:	c3                   	ret
    81d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    81df:	00 

00000000000081e0 <fwp_write>:
    81e0:	41 57                	push   %r15
    81e2:	41 56                	push   %r14
    81e4:	41 55                	push   %r13
    81e6:	41 54                	push   %r12
    81e8:	55                   	push   %rbp
    81e9:	53                   	push   %rbx
    81ea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    81f1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    81f8:	00 00 
    81fa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8201:	00 
    8202:	49 89 d4             	mov    %rdx,%r12
    8205:	8b 12                	mov    (%rdx),%edx
    8207:	83 fa 19             	cmp    $0x19,%edx
    820a:	77 6a                	ja     8276 <fwp_write+0x96>
    820c:	48 89 f5             	mov    %rsi,%rbp
    820f:	89 d0                	mov    %edx,%eax
    8211:	89 ce                	mov    %ecx,%esi
    8213:	48 89 fb             	mov    %rdi,%rbx
    8216:	48 8d 0d f3 77 00 00 	lea    0x77f3(%rip),%rcx        # fa10 <_IO_stdin_used+0xa10>
    821d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8221:	48 01 c8             	add    %rcx,%rax
    8224:	3e ff e0             	notrack jmp *%rax
    8227:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    822e:	00 00 
    8230:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8234:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8238:	48 89 ca             	mov    %rcx,%rdx
    823b:	48 85 c9             	test   %rcx,%rcx
    823e:	0f 88 9c 0c 00 00    	js     8ee0 <fwp_write+0xd00>
    8244:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    824b:	00 
    824c:	48 89 c6             	mov    %rax,%rsi
    824f:	4c 89 e7             	mov    %r12,%rdi
    8252:	e8 e9 b7 ff ff       	call   3a40 <fwp_fmt_u128>
    8257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    825e:	00 00 
    8260:	4c 89 e7             	mov    %r12,%rdi
    8263:	e8 e8 b1 ff ff       	call   3450 <strlen@plt>
    8268:	4c 89 e6             	mov    %r12,%rsi
    826b:	48 89 df             	mov    %rbx,%rdi
    826e:	48 89 c2             	mov    %rax,%rdx
    8271:	e8 fa bd ff ff       	call   4070 <buf_put>
    8276:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    827d:	00 
    827e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8285:	00 00 
    8287:	0f 85 28 04 00 00    	jne    86b5 <fwp_write+0x4d5>
    828d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8294:	5b                   	pop    %rbx
    8295:	5d                   	pop    %rbp
    8296:	41 5c                	pop    %r12
    8298:	41 5d                	pop    %r13
    829a:	41 5e                	pop    %r14
    829c:	41 5f                	pop    %r15
    829e:	c3                   	ret
    829f:	90                   	nop
    82a0:	49 89 e9             	mov    %rbp,%r9
    82a3:	4c 8d 05 ad 6e 00 00 	lea    0x6ead(%rip),%r8        # f157 <_IO_stdin_used+0x157>
    82aa:	b9 00 02 00 00       	mov    $0x200,%ecx
    82af:	ba 02 00 00 00       	mov    $0x2,%edx
    82b4:	be 00 02 00 00       	mov    $0x200,%esi
    82b9:	31 c0                	xor    %eax,%eax
    82bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    82c2:	00 
    82c3:	e8 e8 b0 ff ff       	call   33b0 <__snprintf_chk@plt>
    82c8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    82cf:	00 
    82d0:	e8 7b b1 ff ff       	call   3450 <strlen@plt>
    82d5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    82dc:	00 
    82dd:	48 89 df             	mov    %rbx,%rdi
    82e0:	48 89 c2             	mov    %rax,%rdx
    82e3:	e8 88 bd ff ff       	call   4070 <buf_put>
    82e8:	eb 8c                	jmp    8276 <fwp_write+0x96>
    82ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    82f0:	49 89 e9             	mov    %rbp,%r9
    82f3:	4c 8d 05 58 6e 00 00 	lea    0x6e58(%rip),%r8        # f152 <_IO_stdin_used+0x152>
    82fa:	eb ae                	jmp    82aa <fwp_write+0xca>
    82fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8300:	83 fa 13             	cmp    $0x13,%edx
    8303:	48 8d 05 3e 6e 00 00 	lea    0x6e3e(%rip),%rax        # f148 <_IO_stdin_used+0x148>
    830a:	48 8d 35 3c 6e 00 00 	lea    0x6e3c(%rip),%rsi        # f14d <_IO_stdin_used+0x14d>
    8311:	ba 04 00 00 00       	mov    $0x4,%edx
    8316:	48 0f 44 f0          	cmove  %rax,%rsi
    831a:	45 31 ed             	xor    %r13d,%r13d
    831d:	e8 4e bd ff ff       	call   4070 <buf_put>
    8322:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8327:	0f 84 a3 08 00 00    	je     8bd0 <fwp_write+0x9f0>
    832d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8332:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8337:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    833c:	48 89 df             	mov    %rbx,%rdi
    833f:	49 0f 44 c5          	cmove  %r13,%rax
    8343:	31 c9                	xor    %ecx,%ecx
    8345:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    834a:	e8 91 fe ff ff       	call   81e0 <fwp_write>
    834f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8354:	0f 84 6e 09 00 00    	je     8cc8 <fwp_write+0xae8>
    835a:	49 83 c5 01          	add    $0x1,%r13
    835e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8362:	0f 83 68 08 00 00    	jae    8bd0 <fwp_write+0x9f0>
    8368:	ba 02 00 00 00       	mov    $0x2,%edx
    836d:	48 8d 35 23 6e 00 00 	lea    0x6e23(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8374:	48 89 df             	mov    %rbx,%rdi
    8377:	e8 f4 bc ff ff       	call   4070 <buf_put>
    837c:	eb af                	jmp    832d <fwp_write+0x14d>
    837e:	66 90                	xchg   %ax,%ax
    8380:	ba 06 00 00 00       	mov    $0x6,%edx
    8385:	48 8d 35 e4 6d 00 00 	lea    0x6de4(%rip),%rsi        # f170 <_IO_stdin_used+0x170>
    838c:	48 83 c5 10          	add    $0x10,%rbp
    8390:	e8 db bc ff ff       	call   4070 <buf_put>
    8395:	48 89 ef             	mov    %rbp,%rdi
    8398:	e8 b3 b0 ff ff       	call   3450 <strlen@plt>
    839d:	48 89 ee             	mov    %rbp,%rsi
    83a0:	48 89 df             	mov    %rbx,%rdi
    83a3:	48 89 c2             	mov    %rax,%rdx
    83a6:	e8 c5 bc ff ff       	call   4070 <buf_put>
    83ab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    83b0:	ba 01 00 00 00       	mov    $0x1,%edx
    83b5:	48 89 df             	mov    %rbx,%rdi
    83b8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    83bd:	e8 ae bc ff ff       	call   4070 <buf_put>
    83c2:	e9 af fe ff ff       	jmp    8276 <fwp_write+0x96>
    83c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    83ce:	00 00 
    83d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    83d7:	00 
    83d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    83df:	00 00 
    83e1:	0f 85 ce 02 00 00    	jne    86b5 <fwp_write+0x4d5>
    83e7:	ba 0a 00 00 00       	mov    $0xa,%edx
    83ec:	48 8d 35 69 6d 00 00 	lea    0x6d69(%rip),%rsi        # f15c <_IO_stdin_used+0x15c>
    83f3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    83fa:	48 89 df             	mov    %rbx,%rdi
    83fd:	5b                   	pop    %rbx
    83fe:	5d                   	pop    %rbp
    83ff:	41 5c                	pop    %r12
    8401:	41 5d                	pop    %r13
    8403:	41 5e                	pop    %r14
    8405:	41 5f                	pop    %r15
    8407:	e9 64 bc ff ff       	jmp    4070 <buf_put>
    840c:	0f 1f 40 00          	nopl   0x0(%rax)
    8410:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8415:	4d 85 ed             	test   %r13,%r13
    8418:	0f 84 02 0c 00 00    	je     9020 <fwp_write+0xe40>
    841e:	48 8d 35 7f 6d 00 00 	lea    0x6d7f(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    8425:	4c 89 ef             	mov    %r13,%rdi
    8428:	e8 03 b1 ff ff       	call   3530 <strcmp@plt>
    842d:	41 89 c1             	mov    %eax,%r9d
    8430:	85 c0                	test   %eax,%eax
    8432:	0f 84 6c 0c 00 00    	je     90a4 <fwp_write+0xec4>
    8438:	4c 89 ef             	mov    %r13,%rdi
    843b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8440:	e8 0b b0 ff ff       	call   3450 <strlen@plt>
    8445:	4c 89 ee             	mov    %r13,%rsi
    8448:	48 89 df             	mov    %rbx,%rdi
    844b:	48 89 c2             	mov    %rax,%rdx
    844e:	e8 1d bc ff ff       	call   4070 <buf_put>
    8453:	ba 01 00 00 00       	mov    $0x1,%edx
    8458:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    845d:	48 89 df             	mov    %rbx,%rdi
    8460:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8465:	e8 06 bc ff ff       	call   4070 <buf_put>
    846a:	ba 01 00 00 00       	mov    $0x1,%edx
    846f:	4c 89 fe             	mov    %r15,%rsi
    8472:	48 89 df             	mov    %rbx,%rdi
    8475:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    847a:	e8 f1 bb ff ff       	call   4070 <buf_put>
    847f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8484:	45 31 f6             	xor    %r14d,%r14d
    8487:	85 d2                	test   %edx,%edx
    8489:	0f 8e 81 0a 00 00    	jle    8f10 <fwp_write+0xd30>
    848f:	45 31 ed             	xor    %r13d,%r13d
    8492:	4d 85 ed             	test   %r13,%r13
    8495:	0f 85 75 07 00 00    	jne    8c10 <fwp_write+0xa30>
    849b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    84a2:	00 
    84a3:	45 85 f6             	test   %r14d,%r14d
    84a6:	0f 84 84 07 00 00    	je     8c30 <fwp_write+0xa50>
    84ac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    84b1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    84b6:	48 89 df             	mov    %rbx,%rdi
    84b9:	49 83 c5 01          	add    $0x1,%r13
    84bd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    84c1:	31 c9                	xor    %ecx,%ecx
    84c3:	e8 18 fd ff ff       	call   81e0 <fwp_write>
    84c8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    84cd:	7f c3                	jg     8492 <fwp_write+0x2b2>
    84cf:	45 85 f6             	test   %r14d,%r14d
    84d2:	0f 84 38 0a 00 00    	je     8f10 <fwp_write+0xd30>
    84d8:	b8 29 00 00 00       	mov    $0x29,%eax
    84dd:	ba 01 00 00 00       	mov    $0x1,%edx
    84e2:	4c 89 fe             	mov    %r15,%rsi
    84e5:	48 89 df             	mov    %rbx,%rdi
    84e8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    84ec:	e8 7f bb ff ff       	call   4070 <buf_put>
    84f1:	e9 80 fd ff ff       	jmp    8276 <fwp_write+0x96>
    84f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    84fd:	00 00 00 
    8500:	ba 01 00 00 00       	mov    $0x1,%edx
    8505:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    850a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    850f:	e8 5c bb ff ff       	call   4070 <buf_put>
    8514:	48 85 ed             	test   %rbp,%rbp
    8517:	0f 84 93 06 00 00    	je     8bb0 <fwp_write+0x9d0>
    851d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8521:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8526:	31 c9                	xor    %ecx,%ecx
    8528:	48 89 df             	mov    %rbx,%rdi
    852b:	e8 b0 fc ff ff       	call   81e0 <fwp_write>
    8530:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8534:	48 85 ed             	test   %rbp,%rbp
    8537:	0f 84 73 06 00 00    	je     8bb0 <fwp_write+0x9d0>
    853d:	ba 02 00 00 00       	mov    $0x2,%edx
    8542:	48 8d 35 4e 6c 00 00 	lea    0x6c4e(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8549:	48 89 df             	mov    %rbx,%rdi
    854c:	e8 1f bb ff ff       	call   4070 <buf_put>
    8551:	eb ca                	jmp    851d <fwp_write+0x33d>
    8553:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8558:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    855c:	85 f6                	test   %esi,%esi
    855e:	0f 84 fc 07 00 00    	je     8d60 <fwp_write+0xb80>
    8564:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    856b:	00 
    856c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8573:	00 00 
    8575:	0f 85 3a 01 00 00    	jne    86b5 <fwp_write+0x4d5>
    857b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    857f:	4c 89 ea             	mov    %r13,%rdx
    8582:	e9 6c fe ff ff       	jmp    83f3 <fwp_write+0x213>
    8587:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    858e:	00 00 
    8590:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8595:	ba 01 00 00 00       	mov    $0x1,%edx
    859a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    859f:	48 89 ee             	mov    %rbp,%rsi
    85a2:	e8 c9 ba ff ff       	call   4070 <buf_put>
    85a7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    85ac:	4c 89 e7             	mov    %r12,%rdi
    85af:	e8 9c ae ff ff       	call   3450 <strlen@plt>
    85b4:	4c 89 e6             	mov    %r12,%rsi
    85b7:	48 89 df             	mov    %rbx,%rdi
    85ba:	48 89 c2             	mov    %rax,%rdx
    85bd:	e8 ae ba ff ff       	call   4070 <buf_put>
    85c2:	ba 01 00 00 00       	mov    $0x1,%edx
    85c7:	48 89 ee             	mov    %rbp,%rsi
    85ca:	48 89 df             	mov    %rbx,%rdi
    85cd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    85d2:	e8 99 ba ff ff       	call   4070 <buf_put>
    85d7:	e9 9a fc ff ff       	jmp    8276 <fwp_write+0x96>
    85dc:	0f 1f 40 00          	nopl   0x0(%rax)
    85e0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    85e5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    85e9:	0f 8a 8e 0b 00 00    	jp     917d <fwp_write+0xf9d>
    85ef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    85f3:	66 0f 54 05 45 75 00 	andpd  0x7545(%rip),%xmm0        # fb40 <msg.4+0xc0>
    85fa:	00 
    85fb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8600:	66 0f 2e 05 b0 74 00 	ucomisd 0x74b0(%rip),%xmm0        # fab8 <msg.4+0x38>
    8607:	00 
    8608:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    860f:	00 
    8610:	0f 87 b2 09 00 00    	ja     8fc8 <fwp_write+0xde8>
    8616:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    861d:	00 00 00 
    8620:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8624:	89 ee                	mov    %ebp,%esi
    8626:	4c 89 e7             	mov    %r12,%rdi
    8629:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    862e:	e8 8d be ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8633:	31 f6                	xor    %esi,%esi
    8635:	4c 89 e7             	mov    %r12,%rdi
    8638:	e8 d3 ad ff ff       	call   3410 <strtod@plt>
    863d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8642:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8646:	7a 06                	jp     864e <fwp_write+0x46e>
    8648:	0f 84 e9 01 00 00    	je     8837 <fwp_write+0x657>
    864e:	83 c5 01             	add    $0x1,%ebp
    8651:	83 fd 12             	cmp    $0x12,%ebp
    8654:	75 ca                	jne    8620 <fwp_write+0x440>
    8656:	be 11 00 00 00       	mov    $0x11,%esi
    865b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    865f:	4c 89 e7             	mov    %r12,%rdi
    8662:	e8 59 be ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8667:	e9 cb 01 00 00       	jmp    8837 <fwp_write+0x657>
    866c:	0f 1f 40 00          	nopl   0x0(%rax)
    8670:	48 83 fd 01          	cmp    $0x1,%rbp
    8674:	0f 84 e6 08 00 00    	je     8f60 <fwp_write+0xd80>
    867a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    867e:	b8 02 00 00 00       	mov    $0x2,%eax
    8683:	ba 01 00 00 00       	mov    $0x1,%edx
    8688:	48 0f 44 d0          	cmove  %rax,%rdx
    868c:	48 8d 35 ad 6a 00 00 	lea    0x6aad(%rip),%rsi        # f140 <_IO_stdin_used+0x140>
    8693:	48 8d 05 ab 6a 00 00 	lea    0x6aab(%rip),%rax        # f145 <_IO_stdin_used+0x145>
    869a:	48 0f 44 f0          	cmove  %rax,%rsi
    869e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    86a5:	00 
    86a6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    86ad:	00 00 
    86af:	0f 84 3e fd ff ff    	je     83f3 <fwp_write+0x213>
    86b5:	e8 a6 ad ff ff       	call   3460 <__stack_chk_fail@plt>
    86ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86c0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    86c5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    86ca:	e8 e1 b8 ff ff       	call   3fb0 <buf_grow>
    86cf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    86d3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    86d9:	4c 03 0b             	add    (%rbx),%r9
    86dc:	66 45 89 11          	mov    %r10w,(%r9)
    86e0:	45 85 e4             	test   %r12d,%r12d
    86e3:	0f 8e 07 05 00 00    	jle    8bf0 <fwp_write+0xa10>
    86e9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    86f0:	55 55 55 
    86f3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    86f8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    86ff:	aa aa aa 
    8702:	49 83 c1 01          	add    $0x1,%r9
    8706:	eb 45                	jmp    874d <fwp_write+0x56d>
    8708:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    870f:	00 
    8710:	be 01 00 00 00       	mov    $0x1,%esi
    8715:	b8 2d 00 00 00       	mov    $0x2d,%eax
    871a:	88 07                	mov    %al,(%rdi)
    871c:	48 89 e8             	mov    %rbp,%rax
    871f:	49 f7 e8             	imul   %r8
    8722:	48 89 e8             	mov    %rbp,%rax
    8725:	48 c1 f8 3f          	sar    $0x3f,%rax
    8729:	48 29 c2             	sub    %rax,%rdx
    872c:	48 85 c9             	test   %rcx,%rcx
    872f:	0f 95 c0             	setne  %al
    8732:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8736:	48 83 ef 01          	sub    $0x1,%rdi
    873a:	48 21 c5             	and    %rax,%rbp
    873d:	48 29 ea             	sub    %rbp,%rdx
    8740:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8744:	49 39 f9             	cmp    %rdi,%r9
    8747:	0f 84 a3 04 00 00    	je     8bf0 <fwp_write+0xa10>
    874d:	48 89 e8             	mov    %rbp,%rax
    8750:	49 f7 e8             	imul   %r8
    8753:	48 89 e8             	mov    %rbp,%rax
    8756:	48 c1 f8 3f          	sar    $0x3f,%rax
    875a:	48 89 d1             	mov    %rdx,%rcx
    875d:	48 29 c1             	sub    %rax,%rcx
    8760:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8764:	48 89 e9             	mov    %rbp,%rcx
    8767:	48 29 c1             	sub    %rax,%rcx
    876a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    876e:	49 f7 e2             	mul    %r10
    8771:	b8 30 00 00 00       	mov    $0x30,%eax
    8776:	48 89 d6             	mov    %rdx,%rsi
    8779:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    877d:	48 d1 ee             	shr    $1,%rsi
    8780:	48 01 f2             	add    %rsi,%rdx
    8783:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8787:	48 29 d6             	sub    %rdx,%rsi
    878a:	74 8e                	je     871a <fwp_write+0x53a>
    878c:	48 83 fe 01          	cmp    $0x1,%rsi
    8790:	0f 85 7a ff ff ff    	jne    8710 <fwp_write+0x530>
    8796:	31 f6                	xor    %esi,%esi
    8798:	b8 2b 00 00 00       	mov    $0x2b,%eax
    879d:	e9 78 ff ff ff       	jmp    871a <fwp_write+0x53a>
    87a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87a8:	66 0f 6e cd          	movd   %ebp,%xmm1
    87ac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    87af:	0f 8a c8 09 00 00    	jp     917d <fwp_write+0xf9d>
    87b5:	0f 28 c1             	movaps %xmm1,%xmm0
    87b8:	0f 54 05 71 73 00 00 	andps  0x7371(%rip),%xmm0        # fb30 <msg.4+0xb0>
    87bf:	0f 2e 05 3e 68 00 00 	ucomiss 0x683e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    87c6:	0f 87 24 08 00 00    	ja     8ff0 <fwp_write+0xe10>
    87cc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    87d0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    87d6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    87dd:	00 
    87de:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    87e2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    87e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    87ee:	00 00 
    87f0:	44 89 ee             	mov    %r13d,%esi
    87f3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    87f8:	4c 89 e7             	mov    %r12,%rdi
    87fb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8800:	e8 bb bc ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8805:	31 f6                	xor    %esi,%esi
    8807:	4c 89 e7             	mov    %r12,%rdi
    880a:	e8 a1 ac ff ff       	call   34b0 <strtof@plt>
    880f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8814:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8817:	7a 02                	jp     881b <fwp_write+0x63b>
    8819:	74 1c                	je     8837 <fwp_write+0x657>
    881b:	41 83 c5 01          	add    $0x1,%r13d
    881f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8823:	75 cb                	jne    87f0 <fwp_write+0x610>
    8825:	be 09 00 00 00       	mov    $0x9,%esi
    882a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    882f:	4c 89 e7             	mov    %r12,%rdi
    8832:	e8 89 bc ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8837:	4c 89 e7             	mov    %r12,%rdi
    883a:	e8 f1 b8 ff ff       	call   4130 <fwp_finish_float>
    883f:	e9 1c fa ff ff       	jmp    8260 <fwp_write+0x80>
    8844:	0f 1f 40 00          	nopl   0x0(%rax)
    8848:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    884c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8850:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8857:	00 
    8858:	48 89 ef             	mov    %rbp,%rdi
    885b:	e8 e0 b1 ff ff       	call   3a40 <fwp_fmt_u128>
    8860:	48 89 ef             	mov    %rbp,%rdi
    8863:	e8 e8 ab ff ff       	call   3450 <strlen@plt>
    8868:	48 89 ee             	mov    %rbp,%rsi
    886b:	48 89 df             	mov    %rbx,%rdi
    886e:	48 89 c2             	mov    %rax,%rdx
    8871:	e8 fa b7 ff ff       	call   4070 <buf_put>
    8876:	e9 fb f9 ff ff       	jmp    8276 <fwp_write+0x96>
    887b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8880:	ba 06 00 00 00       	mov    $0x6,%edx
    8885:	48 8d 35 0e 69 00 00 	lea    0x690e(%rip),%rsi        # f19a <_IO_stdin_used+0x19a>
    888c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8892:	e8 d9 b7 ff ff       	call   4070 <buf_put>
    8897:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    889e:	ff ff 7f 
    88a1:	48 23 55 00          	and    0x0(%rbp),%rdx
    88a5:	0f 84 86 02 00 00    	je     8b31 <fwp_write+0x951>
    88ab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    88b0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    88b4:	48 85 d2             	test   %rdx,%rdx
    88b7:	0f 84 ae 00 00 00    	je     896b <fwp_write+0x78b>
    88bd:	8b 0a                	mov    (%rdx),%ecx
    88bf:	83 f9 1c             	cmp    $0x1c,%ecx
    88c2:	0f 84 58 06 00 00    	je     8f20 <fwp_write+0xd40>
    88c8:	83 f9 1b             	cmp    $0x1b,%ecx
    88cb:	0f 87 9a 00 00 00    	ja     896b <fwp_write+0x78b>
    88d1:	be 01 00 00 00       	mov    $0x1,%esi
    88d6:	48 d3 e6             	shl    %cl,%rsi
    88d9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    88df:	0f 85 4b 04 00 00    	jne    8d30 <fwp_write+0xb50>
    88e5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    88eb:	0f 85 0f 04 00 00    	jne    8d00 <fwp_write+0xb20>
    88f1:	83 e6 21             	and    $0x21,%esi
    88f4:	74 75                	je     896b <fwp_write+0x78b>
    88f6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    88fb:	48 85 ff             	test   %rdi,%rdi
    88fe:	79 07                	jns    8907 <fwp_write+0x727>
    8900:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8904:	4c 01 ee             	add    %r13,%rsi
    8907:	48 0f be 3e          	movsbq (%rsi),%rdi
    890b:	85 c9                	test   %ecx,%ecx
    890d:	40 0f b6 f7          	movzbl %dil,%esi
    8911:	48 0f 44 f7          	cmove  %rdi,%rsi
    8915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    891c:	00 00 00 00 
    8920:	31 c9                	xor    %ecx,%ecx
    8922:	48 89 df             	mov    %rbx,%rdi
    8925:	49 83 c5 01          	add    $0x1,%r13
    8929:	e8 b2 f8 ff ff       	call   81e0 <fwp_write>
    892e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8935:	ff ff 7f 
    8938:	48 23 55 00          	and    0x0(%rbp),%rdx
    893c:	49 39 d5             	cmp    %rdx,%r13
    893f:	0f 83 ec 01 00 00    	jae    8b31 <fwp_write+0x951>
    8945:	ba 02 00 00 00       	mov    $0x2,%edx
    894a:	48 89 df             	mov    %rbx,%rdi
    894d:	48 8d 35 43 68 00 00 	lea    0x6843(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8954:	e8 17 b7 ff ff       	call   4070 <buf_put>
    8959:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    895e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8962:	48 85 d2             	test   %rdx,%rdx
    8965:	0f 85 52 ff ff ff    	jne    88bd <fwp_write+0x6dd>
    896b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8970:	48 85 ff             	test   %rdi,%rdi
    8973:	0f 88 cf 05 00 00    	js     8f48 <fwp_write+0xd68>
    8979:	48 8b 31             	mov    (%rcx),%rsi
    897c:	eb a2                	jmp    8920 <fwp_write+0x740>
    897e:	66 90                	xchg   %ax,%ax
    8980:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8987:	00 
    8988:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    898f:	00 00 
    8991:	0f 85 1e fd ff ff    	jne    86b5 <fwp_write+0x4d5>
    8997:	ba 08 00 00 00       	mov    $0x8,%edx
    899c:	48 8d 35 c4 67 00 00 	lea    0x67c4(%rip),%rsi        # f167 <_IO_stdin_used+0x167>
    89a3:	e9 4b fa ff ff       	jmp    83f3 <fwp_write+0x213>
    89a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    89af:	00 
    89b0:	89 e8                	mov    %ebp,%eax
    89b2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    89b9:	76 03                	jbe    89be <fwp_write+0x7de>
    89bb:	8b 45 00             	mov    0x0(%rbp),%eax
    89be:	41 89 c6             	mov    %eax,%r14d
    89c1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    89c6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    89cb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    89cf:	4c 89 ef             	mov    %r13,%rdi
    89d2:	e8 79 aa ff ff       	call   3450 <strlen@plt>
    89d7:	4c 89 ee             	mov    %r13,%rsi
    89da:	48 89 df             	mov    %rbx,%rdi
    89dd:	48 89 c2             	mov    %rax,%rdx
    89e0:	e8 8b b6 ff ff       	call   4070 <buf_put>
    89e5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    89ea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    89ee:	85 f6                	test   %esi,%esi
    89f0:	0f 8e 80 f8 ff ff    	jle    8276 <fwp_write+0x96>
    89f6:	45 31 ed             	xor    %r13d,%r13d
    89f9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    89fe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8a03:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8a08:	ba 01 00 00 00       	mov    $0x1,%edx
    8a0d:	4c 89 fe             	mov    %r15,%rsi
    8a10:	48 89 04 24          	mov    %rax,(%rsp)
    8a14:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8a19:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8a1d:	48 89 df             	mov    %rbx,%rdi
    8a20:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8a24:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8a29:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8a2e:	e8 3d b6 ff ff       	call   4070 <buf_put>
    8a33:	41 8b 06             	mov    (%r14),%eax
    8a36:	83 f8 0e             	cmp    $0xe,%eax
    8a39:	0f 84 71 02 00 00    	je     8cb0 <fwp_write+0xad0>
    8a3f:	83 f8 10             	cmp    $0x10,%eax
    8a42:	0f 84 38 02 00 00    	je     8c80 <fwp_write+0xaa0>
    8a48:	83 f8 0a             	cmp    $0xa,%eax
    8a4b:	0f 84 7f 04 00 00    	je     8ed0 <fwp_write+0xcf0>
    8a51:	0f 8f f9 00 00 00    	jg     8b50 <fwp_write+0x970>
    8a57:	83 f8 03             	cmp    $0x3,%eax
    8a5a:	0f 8f 50 04 00 00    	jg     8eb0 <fwp_write+0xcd0>
    8a60:	85 c0                	test   %eax,%eax
    8a62:	78 10                	js     8a74 <fwp_write+0x894>
    8a64:	48 8b 04 24          	mov    (%rsp),%rax
    8a68:	48 c1 e8 3f          	shr    $0x3f,%rax
    8a6c:	85 c0                	test   %eax,%eax
    8a6e:	0f 85 f9 00 00 00    	jne    8b6d <fwp_write+0x98d>
    8a74:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8a79:	48 8b 34 24          	mov    (%rsp),%rsi
    8a7d:	31 c9                	xor    %ecx,%ecx
    8a7f:	48 89 df             	mov    %rbx,%rdi
    8a82:	e8 59 f7 ff ff       	call   81e0 <fwp_write>
    8a87:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8a8c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8a91:	49 83 c5 01          	add    $0x1,%r13
    8a95:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8a99:	0f 8f 5f ff ff ff    	jg     89fe <fwp_write+0x81e>
    8a9f:	e9 d2 f7 ff ff       	jmp    8276 <fwp_write+0x96>
    8aa4:	0f 1f 40 00          	nopl   0x0(%rax)
    8aa8:	ba 06 00 00 00       	mov    $0x6,%edx
    8aad:	48 8d 35 d9 66 00 00 	lea    0x66d9(%rip),%rsi        # f18d <_IO_stdin_used+0x18d>
    8ab4:	45 31 ed             	xor    %r13d,%r13d
    8ab7:	e8 b4 b5 ff ff       	call   4070 <buf_put>
    8abc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8ac1:	75 19                	jne    8adc <fwp_write+0x8fc>
    8ac3:	eb 6c                	jmp    8b31 <fwp_write+0x951>
    8ac5:	0f 1f 00             	nopl   (%rax)
    8ac8:	ba 02 00 00 00       	mov    $0x2,%edx
    8acd:	48 8d 35 c3 66 00 00 	lea    0x66c3(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8ad4:	48 89 df             	mov    %rbx,%rdi
    8ad7:	e8 94 b5 ff ff       	call   4070 <buf_put>
    8adc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8ae2:	b9 00 02 00 00       	mov    $0x200,%ecx
    8ae7:	31 c0                	xor    %eax,%eax
    8ae9:	49 83 c5 01          	add    $0x1,%r13
    8aed:	4c 8d 05 a0 66 00 00 	lea    0x66a0(%rip),%r8        # f194 <_IO_stdin_used+0x194>
    8af4:	ba 02 00 00 00       	mov    $0x2,%edx
    8af9:	be 00 02 00 00       	mov    $0x200,%esi
    8afe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b05:	00 
    8b06:	e8 a5 a8 ff ff       	call   33b0 <__snprintf_chk@plt>
    8b0b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b12:	00 
    8b13:	e8 38 a9 ff ff       	call   3450 <strlen@plt>
    8b18:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8b1f:	00 
    8b20:	48 89 df             	mov    %rbx,%rdi
    8b23:	48 89 c2             	mov    %rax,%rdx
    8b26:	e8 45 b5 ff ff       	call   4070 <buf_put>
    8b2b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8b2f:	72 97                	jb     8ac8 <fwp_write+0x8e8>
    8b31:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b36:	ba 01 00 00 00       	mov    $0x1,%edx
    8b3b:	48 89 df             	mov    %rbx,%rdi
    8b3e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8b43:	e8 28 b5 ff ff       	call   4070 <buf_put>
    8b48:	e9 29 f7 ff ff       	jmp    8276 <fwp_write+0x96>
    8b4d:	0f 1f 00             	nopl   (%rax)
    8b50:	83 f8 0b             	cmp    $0xb,%eax
    8b53:	0f 85 1b ff ff ff    	jne    8a74 <fwp_write+0x894>
    8b59:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8b5e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8b62:	83 e0 01             	and    $0x1,%eax
    8b65:	85 c0                	test   %eax,%eax
    8b67:	0f 84 07 ff ff ff    	je     8a74 <fwp_write+0x894>
    8b6d:	4c 89 fe             	mov    %r15,%rsi
    8b70:	48 89 df             	mov    %rbx,%rdi
    8b73:	ba 01 00 00 00       	mov    $0x1,%edx
    8b78:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8b7d:	e8 ee b4 ff ff       	call   4070 <buf_put>
    8b82:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8b87:	48 8b 34 24          	mov    (%rsp),%rsi
    8b8b:	31 c9                	xor    %ecx,%ecx
    8b8d:	48 89 df             	mov    %rbx,%rdi
    8b90:	e8 4b f6 ff ff       	call   81e0 <fwp_write>
    8b95:	ba 01 00 00 00       	mov    $0x1,%edx
    8b9a:	4c 89 fe             	mov    %r15,%rsi
    8b9d:	48 89 df             	mov    %rbx,%rdi
    8ba0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8ba5:	e8 c6 b4 ff ff       	call   4070 <buf_put>
    8baa:	e9 d8 fe ff ff       	jmp    8a87 <fwp_write+0x8a7>
    8baf:	90                   	nop
    8bb0:	ba 01 00 00 00       	mov    $0x1,%edx
    8bb5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8bba:	48 89 df             	mov    %rbx,%rdi
    8bbd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8bc2:	e8 a9 b4 ff ff       	call   4070 <buf_put>
    8bc7:	e9 aa f6 ff ff       	jmp    8276 <fwp_write+0x96>
    8bcc:	0f 1f 40 00          	nopl   0x0(%rax)
    8bd0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8bd5:	ba 01 00 00 00       	mov    $0x1,%edx
    8bda:	48 89 df             	mov    %rbx,%rdi
    8bdd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8be2:	e8 89 b4 ff ff       	call   4070 <buf_put>
    8be7:	e9 8a f6 ff ff       	jmp    8276 <fwp_write+0x96>
    8bec:	0f 1f 40 00          	nopl   0x0(%rax)
    8bf0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8bf4:	48 8b 13             	mov    (%rbx),%rdx
    8bf7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8bfc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8c00:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8c04:	e9 6d f6 ff ff       	jmp    8276 <fwp_write+0x96>
    8c09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c10:	ba 02 00 00 00       	mov    $0x2,%edx
    8c15:	48 8d 35 7b 65 00 00 	lea    0x657b(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8c1c:	48 89 df             	mov    %rbx,%rdi
    8c1f:	e8 4c b4 ff ff       	call   4070 <buf_put>
    8c24:	e9 72 f8 ff ff       	jmp    849b <fwp_write+0x2bb>
    8c29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c30:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8c35:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8c3a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8c3e:	48 89 f7             	mov    %rsi,%rdi
    8c41:	48 89 34 24          	mov    %rsi,(%rsp)
    8c45:	e8 06 a8 ff ff       	call   3450 <strlen@plt>
    8c4a:	48 8b 34 24          	mov    (%rsp),%rsi
    8c4e:	48 89 df             	mov    %rbx,%rdi
    8c51:	48 89 c2             	mov    %rax,%rdx
    8c54:	e8 17 b4 ff ff       	call   4070 <buf_put>
    8c59:	ba 03 00 00 00       	mov    $0x3,%edx
    8c5e:	48 8d 35 55 65 00 00 	lea    0x6555(%rip),%rsi        # f1ba <_IO_stdin_used+0x1ba>
    8c65:	48 89 df             	mov    %rbx,%rdi
    8c68:	e8 03 b4 ff ff       	call   4070 <buf_put>
    8c6d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8c72:	e9 35 f8 ff ff       	jmp    84ac <fwp_write+0x2cc>
    8c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c7e:	00 00 
    8c80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8c85:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8c89:	48 85 ff             	test   %rdi,%rdi
    8c8c:	0f 84 e2 fd ff ff    	je     8a74 <fwp_write+0x894>
    8c92:	48 8d 35 0b 65 00 00 	lea    0x650b(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    8c99:	e8 92 a8 ff ff       	call   3530 <strcmp@plt>
    8c9e:	85 c0                	test   %eax,%eax
    8ca0:	0f 95 c0             	setne  %al
    8ca3:	0f b6 c0             	movzbl %al,%eax
    8ca6:	e9 c1 fd ff ff       	jmp    8a6c <fwp_write+0x88c>
    8cab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8cb0:	31 c0                	xor    %eax,%eax
    8cb2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8cb9:	00 
    8cba:	0f 97 c0             	seta   %al
    8cbd:	e9 aa fd ff ff       	jmp    8a6c <fwp_write+0x88c>
    8cc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8cc8:	48 89 df             	mov    %rbx,%rdi
    8ccb:	ba 02 00 00 00       	mov    $0x2,%edx
    8cd0:	48 8d 35 ca 64 00 00 	lea    0x64ca(%rip),%rsi        # f1a1 <_IO_stdin_used+0x1a1>
    8cd7:	e8 94 b3 ff ff       	call   4070 <buf_put>
    8cdc:	4c 89 e8             	mov    %r13,%rax
    8cdf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8ce4:	31 c9                	xor    %ecx,%ecx
    8ce6:	48 c1 e0 04          	shl    $0x4,%rax
    8cea:	48 89 df             	mov    %rbx,%rdi
    8ced:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8cf2:	e8 e9 f4 ff ff       	call   81e0 <fwp_write>
    8cf7:	e9 5e f6 ff ff       	jmp    835a <fwp_write+0x17a>
    8cfc:	0f 1f 40 00          	nopl   0x0(%rax)
    8d00:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8d05:	48 85 ff             	test   %rdi,%rdi
    8d08:	79 0c                	jns    8d16 <fwp_write+0xb36>
    8d0a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8d11:	00 
    8d12:	48 03 75 10          	add    0x10(%rbp),%rsi
    8d16:	48 63 3e             	movslq (%rsi),%rdi
    8d19:	83 f9 02             	cmp    $0x2,%ecx
    8d1c:	89 fe                	mov    %edi,%esi
    8d1e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d22:	e9 f9 fb ff ff       	jmp    8920 <fwp_write+0x740>
    8d27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d2e:	00 00 
    8d30:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8d35:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8d3a:	48 85 ff             	test   %rdi,%rdi
    8d3d:	0f 88 0f 03 00 00    	js     9052 <fwp_write+0xe72>
    8d43:	49 0f bf 38          	movswq (%r8),%rdi
    8d47:	83 f9 01             	cmp    $0x1,%ecx
    8d4a:	0f b7 f7             	movzwl %di,%esi
    8d4d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d51:	e9 ca fb ff ff       	jmp    8920 <fwp_write+0x740>
    8d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d5d:	00 00 00 
    8d60:	ba 01 00 00 00       	mov    $0x1,%edx
    8d65:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d6a:	48 83 c5 08          	add    $0x8,%rbp
    8d6e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8d73:	e8 f8 b2 ff ff       	call   4070 <buf_put>
    8d78:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8d7d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8d82:	4d 85 ed             	test   %r13,%r13
    8d85:	75 46                	jne    8dcd <fwp_write+0xbed>
    8d87:	e9 04 01 00 00       	jmp    8e90 <fwp_write+0xcb0>
    8d8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d90:	41 80 f9 09          	cmp    $0x9,%r9b
    8d94:	0f 84 d6 00 00 00    	je     8e70 <fwp_write+0xc90>
    8d9a:	41 80 f9 0a          	cmp    $0xa,%r9b
    8d9e:	0f 85 9c 00 00 00    	jne    8e40 <fwp_write+0xc60>
    8da4:	ba 02 00 00 00       	mov    $0x2,%edx
    8da9:	48 8d 35 cd 63 00 00 	lea    0x63cd(%rip),%rsi        # f17d <_IO_stdin_used+0x17d>
    8db0:	48 89 df             	mov    %rbx,%rdi
    8db3:	e8 b8 b2 ff ff       	call   4070 <buf_put>
    8db8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8dbf:	00 
    8dc0:	48 83 c5 01          	add    $0x1,%rbp
    8dc4:	49 39 ec             	cmp    %rbp,%r12
    8dc7:	0f 84 c3 00 00 00    	je     8e90 <fwp_write+0xcb0>
    8dcd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8dd2:	41 80 f9 0d          	cmp    $0xd,%r9b
    8dd6:	74 28                	je     8e00 <fwp_write+0xc20>
    8dd8:	7e b6                	jle    8d90 <fwp_write+0xbb0>
    8dda:	41 80 f9 22          	cmp    $0x22,%r9b
    8dde:	74 40                	je     8e20 <fwp_write+0xc40>
    8de0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8de4:	75 5a                	jne    8e40 <fwp_write+0xc60>
    8de6:	ba 02 00 00 00       	mov    $0x2,%edx
    8deb:	48 8d 35 88 63 00 00 	lea    0x6388(%rip),%rsi        # f17a <_IO_stdin_used+0x17a>
    8df2:	48 89 df             	mov    %rbx,%rdi
    8df5:	e8 76 b2 ff ff       	call   4070 <buf_put>
    8dfa:	eb c4                	jmp    8dc0 <fwp_write+0xbe0>
    8dfc:	0f 1f 40 00          	nopl   0x0(%rax)
    8e00:	ba 02 00 00 00       	mov    $0x2,%edx
    8e05:	48 8d 35 77 63 00 00 	lea    0x6377(%rip),%rsi        # f183 <_IO_stdin_used+0x183>
    8e0c:	48 89 df             	mov    %rbx,%rdi
    8e0f:	e8 5c b2 ff ff       	call   4070 <buf_put>
    8e14:	eb aa                	jmp    8dc0 <fwp_write+0xbe0>
    8e16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e1d:	00 00 00 
    8e20:	ba 02 00 00 00       	mov    $0x2,%edx
    8e25:	48 8d 35 4b 63 00 00 	lea    0x634b(%rip),%rsi        # f177 <_IO_stdin_used+0x177>
    8e2c:	48 89 df             	mov    %rbx,%rdi
    8e2f:	e8 3c b2 ff ff       	call   4070 <buf_put>
    8e34:	eb 8a                	jmp    8dc0 <fwp_write+0xbe0>
    8e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e3d:	00 00 00 
    8e40:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8e44:	0f 86 2e 01 00 00    	jbe    8f78 <fwp_write+0xd98>
    8e4a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8e4e:	0f 84 24 01 00 00    	je     8f78 <fwp_write+0xd98>
    8e54:	ba 01 00 00 00       	mov    $0x1,%edx
    8e59:	4c 89 fe             	mov    %r15,%rsi
    8e5c:	48 89 df             	mov    %rbx,%rdi
    8e5f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8e64:	e8 07 b2 ff ff       	call   4070 <buf_put>
    8e69:	e9 52 ff ff ff       	jmp    8dc0 <fwp_write+0xbe0>
    8e6e:	66 90                	xchg   %ax,%ax
    8e70:	ba 02 00 00 00       	mov    $0x2,%edx
    8e75:	48 8d 35 04 63 00 00 	lea    0x6304(%rip),%rsi        # f180 <_IO_stdin_used+0x180>
    8e7c:	48 89 df             	mov    %rbx,%rdi
    8e7f:	e8 ec b1 ff ff       	call   4070 <buf_put>
    8e84:	e9 37 ff ff ff       	jmp    8dc0 <fwp_write+0xbe0>
    8e89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e90:	ba 01 00 00 00       	mov    $0x1,%edx
    8e95:	4c 89 fe             	mov    %r15,%rsi
    8e98:	48 89 df             	mov    %rbx,%rdi
    8e9b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8ea0:	e8 cb b1 ff ff       	call   4070 <buf_put>
    8ea5:	e9 cc f3 ff ff       	jmp    8276 <fwp_write+0x96>
    8eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8eb0:	83 f8 04             	cmp    $0x4,%eax
    8eb3:	0f 85 bb fb ff ff    	jne    8a74 <fwp_write+0x894>
    8eb9:	48 8b 04 24          	mov    (%rsp),%rax
    8ebd:	48 8b 40 08          	mov    0x8(%rax),%rax
    8ec1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8ec6:	48 c1 e8 3f          	shr    $0x3f,%rax
    8eca:	e9 96 fc ff ff       	jmp    8b65 <fwp_write+0x985>
    8ecf:	90                   	nop
    8ed0:	8b 0c 24             	mov    (%rsp),%ecx
    8ed3:	31 c0                	xor    %eax,%eax
    8ed5:	85 c9                	test   %ecx,%ecx
    8ed7:	0f 98 c0             	sets   %al
    8eda:	e9 86 fc ff ff       	jmp    8b65 <fwp_write+0x985>
    8edf:	90                   	nop
    8ee0:	48 f7 d8             	neg    %rax
    8ee3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8eea:	00 
    8eeb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8ef2:	2d 
    8ef3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8efa:	00 
    8efb:	48 83 d2 00          	adc    $0x0,%rdx
    8eff:	48 89 c6             	mov    %rax,%rsi
    8f02:	48 f7 da             	neg    %rdx
    8f05:	e8 36 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8f0a:	e9 51 f3 ff ff       	jmp    8260 <fwp_write+0x80>
    8f0f:	90                   	nop
    8f10:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8f15:	e9 c3 f5 ff ff       	jmp    84dd <fwp_write+0x2fd>
    8f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f20:	4c 89 e9             	mov    %r13,%rcx
    8f23:	48 c1 e1 04          	shl    $0x4,%rcx
    8f27:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8f2c:	48 85 ff             	test   %rdi,%rdi
    8f2f:	0f 89 eb f9 ff ff    	jns    8920 <fwp_write+0x740>
    8f35:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f39:	48 89 ce             	mov    %rcx,%rsi
    8f3c:	e9 df f9 ff ff       	jmp    8920 <fwp_write+0x740>
    8f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f48:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8f4f:	00 
    8f50:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f54:	e9 20 fa ff ff       	jmp    8979 <fwp_write+0x799>
    8f59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f60:	ba 02 00 00 00       	mov    $0x2,%edx
    8f65:	48 8d 35 d6 61 00 00 	lea    0x61d6(%rip),%rsi        # f142 <_IO_stdin_used+0x142>
    8f6c:	e9 2d f7 ff ff       	jmp    869e <fwp_write+0x4be>
    8f71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f78:	4c 8d 05 07 62 00 00 	lea    0x6207(%rip),%r8        # f186 <_IO_stdin_used+0x186>
    8f7f:	b9 10 00 00 00       	mov    $0x10,%ecx
    8f84:	31 c0                	xor    %eax,%eax
    8f86:	ba 02 00 00 00       	mov    $0x2,%edx
    8f8b:	be 10 00 00 00       	mov    $0x10,%esi
    8f90:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f97:	00 
    8f98:	e8 13 a4 ff ff       	call   33b0 <__snprintf_chk@plt>
    8f9d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fa4:	00 
    8fa5:	e8 a6 a4 ff ff       	call   3450 <strlen@plt>
    8faa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8fb1:	00 
    8fb2:	48 89 df             	mov    %rbx,%rdi
    8fb5:	48 89 c2             	mov    %rax,%rdx
    8fb8:	e8 b3 b0 ff ff       	call   4070 <buf_put>
    8fbd:	e9 fe fd ff ff       	jmp    8dc0 <fwp_write+0xbe0>
    8fc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8fc8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8fcc:	48 8d 35 69 61 00 00 	lea    0x6169(%rip),%rsi        # f13c <_IO_stdin_used+0x13c>
    8fd3:	48 8d 05 61 61 00 00 	lea    0x6161(%rip),%rax        # f13b <_IO_stdin_used+0x13b>
    8fda:	4c 89 e7             	mov    %r12,%rdi
    8fdd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8fe1:	48 0f 46 f0          	cmovbe %rax,%rsi
    8fe5:	e8 06 a4 ff ff       	call   33f0 <strcpy@plt>
    8fea:	e9 71 f2 ff ff       	jmp    8260 <fwp_write+0x80>
    8fef:	90                   	nop
    8ff0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8ff4:	48 8d 35 41 61 00 00 	lea    0x6141(%rip),%rsi        # f13c <_IO_stdin_used+0x13c>
    8ffb:	48 8d 05 39 61 00 00 	lea    0x6139(%rip),%rax        # f13b <_IO_stdin_used+0x13b>
    9002:	0f 2f c8             	comiss %xmm0,%xmm1
    9005:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    900c:	00 
    900d:	4c 89 e7             	mov    %r12,%rdi
    9010:	48 0f 46 f0          	cmovbe %rax,%rsi
    9014:	e8 d7 a3 ff ff       	call   33f0 <strcpy@plt>
    9019:	e9 42 f2 ff ff       	jmp    8260 <fwp_write+0x80>
    901e:	66 90                	xchg   %ax,%ax
    9020:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9025:	45 85 c0             	test   %r8d,%r8d
    9028:	75 34                	jne    905e <fwp_write+0xe7e>
    902a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9031:	00 
    9032:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9039:	00 00 
    903b:	0f 85 74 f6 ff ff    	jne    86b5 <fwp_write+0x4d5>
    9041:	ba 02 00 00 00       	mov    $0x2,%edx
    9046:	48 8d 35 6a 61 00 00 	lea    0x616a(%rip),%rsi        # f1b7 <_IO_stdin_used+0x1b7>
    904d:	e9 a1 f3 ff ff       	jmp    83f3 <fwp_write+0x213>
    9052:	48 03 75 10          	add    0x10(%rbp),%rsi
    9056:	49 89 f0             	mov    %rsi,%r8
    9059:	e9 e5 fc ff ff       	jmp    8d43 <fwp_write+0xb63>
    905e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9063:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9068:	85 ff                	test   %edi,%edi
    906a:	0f 84 fa f3 ff ff    	je     846a <fwp_write+0x28a>
    9070:	ba 01 00 00 00       	mov    $0x1,%edx
    9075:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    907a:	48 89 df             	mov    %rbx,%rdi
    907d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9082:	e8 e9 af ff ff       	call   4070 <buf_put>
    9087:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    908c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9091:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9097:	85 c0                	test   %eax,%eax
    9099:	0f 8f f0 f3 ff ff    	jg     848f <fwp_write+0x2af>
    909f:	e9 34 f4 ff ff       	jmp    84d8 <fwp_write+0x2f8>
    90a4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    90a8:	49 89 c5             	mov    %rax,%r13
    90ab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    90b0:	49 89 c4             	mov    %rax,%r12
    90b3:	49 c1 fd 3f          	sar    $0x3f,%r13
    90b7:	4c 09 e8             	or     %r13,%rax
    90ba:	0f 84 a7 00 00 00    	je     9167 <fwp_write+0xf87>
    90c0:	48 8d 2d f9 81 00 00 	lea    0x81f9(%rip),%rbp        # 112c0 <units.0>
    90c7:	4d 89 e7             	mov    %r12,%r15
    90ca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    90ce:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    90d3:	4c 89 ff             	mov    %r15,%rdi
    90d6:	4c 89 ee             	mov    %r13,%rsi
    90d9:	44 89 0c 24          	mov    %r9d,(%rsp)
    90dd:	48 99                	cqto
    90df:	48 89 d1             	mov    %rdx,%rcx
    90e2:	48 89 c2             	mov    %rax,%rdx
    90e5:	e8 06 4e 00 00       	call   def0 <__divmodti4>
    90ea:	44 8b 0c 24          	mov    (%rsp),%r9d
    90ee:	48 89 c1             	mov    %rax,%rcx
    90f1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    90f6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    90fb:	0f 84 94 00 00 00    	je     9195 <fwp_write+0xfb5>
    9101:	41 83 c1 01          	add    $0x1,%r9d
    9105:	48 83 c5 10          	add    $0x10,%rbp
    9109:	41 83 f9 05          	cmp    $0x5,%r9d
    910d:	75 bb                	jne    90ca <fwp_write+0xeea>
    910f:	4d 85 ed             	test   %r13,%r13
    9112:	79 53                	jns    9167 <fwp_write+0xf87>
    9114:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9119:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    911e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9123:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9128:	48 99                	cqto
    912a:	48 f7 d8             	neg    %rax
    912d:	48 83 d2 00          	adc    $0x0,%rdx
    9131:	48 89 c6             	mov    %rax,%rsi
    9134:	48 f7 da             	neg    %rdx
    9137:	e8 04 a9 ff ff       	call   3a40 <fwp_fmt_u128>
    913c:	49 89 e8             	mov    %rbp,%r8
    913f:	ba 00 02 00 00       	mov    $0x200,%edx
    9144:	be 02 00 00 00       	mov    $0x2,%esi
    9149:	31 c0                	xor    %eax,%eax
    914b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9152:	00 
    9153:	48 8d 0d 58 60 00 00 	lea    0x6058(%rip),%rcx        # f1b2 <_IO_stdin_used+0x1b2>
    915a:	4c 89 e7             	mov    %r12,%rdi
    915d:	e8 7e a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    9162:	e9 f9 f0 ff ff       	jmp    8260 <fwp_write+0x80>
    9167:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    916c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9171:	31 d2                	xor    %edx,%edx
    9173:	48 89 ef             	mov    %rbp,%rdi
    9176:	e8 c5 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    917b:	eb bf                	jmp    913c <fwp_write+0xf5c>
    917d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9184:	4e 61 4e 00 
    9188:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    918f:	00 
    9190:	e9 cb f0 ff ff       	jmp    8260 <fwp_write+0x80>
    9195:	44 89 0c 24          	mov    %r9d,(%rsp)
    9199:	48 89 c8             	mov    %rcx,%rax
    919c:	48 85 d2             	test   %rdx,%rdx
    919f:	78 51                	js     91f2 <fwp_write+0x1012>
    91a1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    91a6:	48 89 c6             	mov    %rax,%rsi
    91a9:	48 89 ef             	mov    %rbp,%rdi
    91ac:	e8 8f a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91b1:	44 8b 0c 24          	mov    (%rsp),%r9d
    91b5:	49 63 c1             	movslq %r9d,%rax
    91b8:	49 89 e8             	mov    %rbp,%r8
    91bb:	ba 00 02 00 00       	mov    $0x200,%edx
    91c0:	be 02 00 00 00       	mov    $0x2,%esi
    91c5:	48 c1 e0 04          	shl    $0x4,%rax
    91c9:	48 8d 3d f0 80 00 00 	lea    0x80f0(%rip),%rdi        # 112c0 <units.0>
    91d0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    91d7:	00 
    91d8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    91dc:	48 8d 0d ca 5f 00 00 	lea    0x5fca(%rip),%rcx        # f1ad <_IO_stdin_used+0x1ad>
    91e3:	4c 89 e7             	mov    %r12,%rdi
    91e6:	31 c0                	xor    %eax,%eax
    91e8:	e8 f3 a4 ff ff       	call   36e0 <__sprintf_chk@plt>
    91ed:	e9 6e f0 ff ff       	jmp    8260 <fwp_write+0x80>
    91f2:	48 f7 d8             	neg    %rax
    91f5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    91fa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    91ff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9204:	48 83 d2 00          	adc    $0x0,%rdx
    9208:	48 89 c6             	mov    %rax,%rsi
    920b:	48 f7 da             	neg    %rdx
    920e:	e8 2d a8 ff ff       	call   3a40 <fwp_fmt_u128>
    9213:	44 8b 0c 24          	mov    (%rsp),%r9d
    9217:	eb 9c                	jmp    91b5 <fwp_write+0xfd5>
    9219:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009220 <fwp_hof0.constprop.0>:
    9220:	41 57                	push   %r15
    9222:	41 56                	push   %r14
    9224:	41 55                	push   %r13
    9226:	41 54                	push   %r12
    9228:	55                   	push   %rbp
    9229:	53                   	push   %rbx
    922a:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
    9231:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9238:	00 00 
    923a:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    9241:	00 
    9242:	31 c0                	xor    %eax,%eax
    9244:	48 85 f6             	test   %rsi,%rsi
    9247:	0f 84 4a 0f 00 00    	je     a197 <fwp_hof0.constprop.0+0xf77>
    924d:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
    9252:	4c 8d 2d 07 a5 01 00 	lea    0x1a507(%rip),%r13        # 23760 <fwp_heap>
    9259:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    925e:	66 90                	xchg   %ax,%ax
    9260:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9267:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    926c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9273:	48 c1 e2 10          	shl    $0x10,%rdx
    9277:	48 39 d0             	cmp    %rdx,%rax
    927a:	73 5d                	jae    92d9 <fwp_hof0.constprop.0+0xb9>
    927c:	48 89 c2             	mov    %rax,%rdx
    927f:	48 c1 ea 10          	shr    $0x10,%rdx
    9283:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9287:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    928e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9292:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9296:	48 85 ff             	test   %rdi,%rdi
    9299:	74 3e                	je     92d9 <fwp_hof0.constprop.0+0xb9>
    929b:	0f b6 0a             	movzbl (%rdx),%ecx
    929e:	80 f9 02             	cmp    $0x2,%cl
    92a1:	0f 84 e9 14 00 00    	je     a790 <fwp_hof0.constprop.0+0x1570>
    92a7:	80 f9 01             	cmp    $0x1,%cl
    92aa:	75 2d                	jne    92d9 <fwp_hof0.constprop.0+0xb9>
    92ac:	8b 4a 18             	mov    0x18(%rdx),%ecx
    92af:	0f b7 c0             	movzwl %ax,%eax
    92b2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    92b5:	48 0f af c1          	imul   %rcx,%rax
    92b9:	48 c1 e8 20          	shr    $0x20,%rax
    92bd:	48 39 d0             	cmp    %rdx,%rax
    92c0:	73 17                	jae    92d9 <fwp_hof0.constprop.0+0xb9>
    92c2:	48 01 c7             	add    %rax,%rdi
    92c5:	0f b6 07             	movzbl (%rdi),%eax
    92c8:	84 c0                	test   %al,%al
    92ca:	74 0d                	je     92d9 <fwp_hof0.constprop.0+0xb9>
    92cc:	3c fd                	cmp    $0xfd,%al
    92ce:	0f 87 c7 16 00 00    	ja     a99b <fwp_hof0.constprop.0+0x177b>
    92d4:	83 c0 01             	add    $0x1,%eax
    92d7:	88 07                	mov    %al,(%rdi)
    92d9:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    92de:	45 31 c0             	xor    %r8d,%r8d
    92e1:	48 c7 44 24 28 c6 00 	movq   $0xc6,0x28(%rsp)
    92e8:	00 00 
    92ea:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    92ef:	4d 89 c6             	mov    %r8,%r14
    92f2:	4d 85 c0             	test   %r8,%r8
    92f5:	0f 85 55 a4 ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    92fb:	48 8b 05 f6 c0 01 00 	mov    0x1c0f6(%rip),%rax        # 253f8 <fwp_cleanups>
    9302:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9309:	4c 8d 25 50 d8 ff ff 	lea    -0x27b0(%rip),%r12        # 6b60 <fwp_tape_scope_release>
    9310:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    9317:	ff ff ff ff 
    931b:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
    9322:	00 
    9323:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    932a:	00 
    932b:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    9332:	00 
    9333:	48 c1 e2 10          	shl    $0x10,%rdx
    9337:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    933c:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9343:	00 
    9344:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    934b:	00 
    934c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9351:	48 89 05 a0 c0 01 00 	mov    %rax,0x1c0a0(%rip)        # 253f8 <fwp_cleanups>
    9358:	48 8d 05 b1 9c 00 00 	lea    0x9cb1(%rip),%rax        # 13010 <fc37>
    935f:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9366:	48 39 d0             	cmp    %rdx,%rax
    9369:	73 5d                	jae    93c8 <fwp_hof0.constprop.0+0x1a8>
    936b:	48 89 c2             	mov    %rax,%rdx
    936e:	48 c1 ea 10          	shr    $0x10,%rdx
    9372:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9376:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    937d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9381:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9385:	48 85 ff             	test   %rdi,%rdi
    9388:	74 3e                	je     93c8 <fwp_hof0.constprop.0+0x1a8>
    938a:	0f b6 0a             	movzbl (%rdx),%ecx
    938d:	80 f9 02             	cmp    $0x2,%cl
    9390:	0f 84 8a 12 00 00    	je     a620 <fwp_hof0.constprop.0+0x1400>
    9396:	80 f9 01             	cmp    $0x1,%cl
    9399:	75 2d                	jne    93c8 <fwp_hof0.constprop.0+0x1a8>
    939b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    939e:	0f b7 c0             	movzwl %ax,%eax
    93a1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93a4:	48 0f af c1          	imul   %rcx,%rax
    93a8:	48 c1 e8 20          	shr    $0x20,%rax
    93ac:	48 39 d0             	cmp    %rdx,%rax
    93af:	73 17                	jae    93c8 <fwp_hof0.constprop.0+0x1a8>
    93b1:	48 01 c7             	add    %rax,%rdi
    93b4:	0f b6 07             	movzbl (%rdi),%eax
    93b7:	84 c0                	test   %al,%al
    93b9:	74 0d                	je     93c8 <fwp_hof0.constprop.0+0x1a8>
    93bb:	3c fd                	cmp    $0xfd,%al
    93bd:	0f 87 18 15 00 00    	ja     a8db <fwp_hof0.constprop.0+0x16bb>
    93c3:	83 c0 01             	add    $0x1,%eax
    93c6:	88 07                	mov    %al,(%rdi)
    93c8:	48 8d 3d 41 9c 00 00 	lea    0x9c41(%rip),%rdi        # 13010 <fc37>
    93cf:	e8 4c d4 ff ff       	call   6820 <fwp_closure_drop>
    93d4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    93d9:	48 85 c0             	test   %rax,%rax
    93dc:	0f 84 0e 14 00 00    	je     a7f0 <fwp_hof0.constprop.0+0x15d0>
    93e2:	31 d2                	xor    %edx,%edx
    93e4:	90                   	nop
    93e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    93ec:	00 00 00 00 
    93f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    93f4:	48 83 c2 01          	add    $0x1,%rdx
    93f8:	48 85 c0             	test   %rax,%rax
    93fb:	75 f3                	jne    93f0 <fwp_hof0.constprop.0+0x1d0>
    93fd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    9404:	0f 87 cf 15 00 00    	ja     a9d9 <fwp_hof0.constprop.0+0x17b9>
    940a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    940f:	8b 35 4b 9c 00 00    	mov    0x9c4b(%rip),%esi        # 13060 <registered_finish.1>
    9415:	85 f6                	test   %esi,%esi
    9417:	0f 84 c3 11 00 00    	je     a5e0 <fwp_hof0.constprop.0+0x13c0>
    941d:	4c 8b 3d b4 9c 01 00 	mov    0x19cb4(%rip),%r15        # 230d8 <fwp_tape_next_slot>
    9424:	48 8b 2d bd 9c 01 00 	mov    0x19cbd(%rip),%rbp        # 230e8 <fwp_ntapes>
    942b:	4c 39 fd             	cmp    %r15,%rbp
    942e:	0f 8e 3c 0e 00 00    	jle    a270 <fwp_hof0.constprop.0+0x1050>
    9434:	49 6b c7 68          	imul   $0x68,%r15,%rax
    9438:	48 03 05 b1 9c 01 00 	add    0x19cb1(%rip),%rax        # 230f0 <fwp_tapes>
    943f:	90                   	nop
    9440:	8b 48 04             	mov    0x4(%rax),%ecx
    9443:	85 c9                	test   %ecx,%ecx
    9445:	75 0c                	jne    9453 <fwp_hof0.constprop.0+0x233>
    9447:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    944d:	0f 86 1d 0e 00 00    	jbe    a270 <fwp_hof0.constprop.0+0x1050>
    9453:	49 83 c7 01          	add    $0x1,%r15
    9457:	48 83 c0 68          	add    $0x68,%rax
    945b:	4c 39 fd             	cmp    %r15,%rbp
    945e:	75 e0                	jne    9440 <fwp_hof0.constprop.0+0x220>
    9460:	48 81 fd fe ff 00 00 	cmp    $0xfffe,%rbp
    9467:	0f 8f ef 15 00 00    	jg     aa5c <fwp_hof0.constprop.0+0x183c>
    946d:	48 3b 2d 6c 9c 01 00 	cmp    0x19c6c(%rip),%rbp        # 230e0 <fwp_tapes_cap>
    9474:	48 8b 1d 75 9c 01 00 	mov    0x19c75(%rip),%rbx        # 230f0 <fwp_tapes>
    947b:	75 4c                	jne    94c9 <fwp_hof0.constprop.0+0x2a9>
    947d:	48 85 ed             	test   %rbp,%rbp
    9480:	0f 84 d0 13 00 00    	je     a856 <fwp_hof0.constprop.0+0x1636>
    9486:	4c 8d 7c 2d 00       	lea    0x0(%rbp,%rbp,1),%r15
    948b:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9490:	49 39 c7             	cmp    %rax,%r15
    9493:	4c 0f 4f f8          	cmovg  %rax,%r15
    9497:	49 6b f7 68          	imul   $0x68,%r15,%rsi
    949b:	48 89 df             	mov    %rbx,%rdi
    949e:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    94a4:	e8 27 a1 ff ff       	call   35d0 <realloc@plt>
    94a9:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    94af:	48 85 c0             	test   %rax,%rax
    94b2:	48 89 c3             	mov    %rax,%rbx
    94b5:	0f 84 ad 15 00 00    	je     aa68 <fwp_hof0.constprop.0+0x1848>
    94bb:	48 89 05 2e 9c 01 00 	mov    %rax,0x19c2e(%rip)        # 230f0 <fwp_tapes>
    94c2:	4c 89 3d 17 9c 01 00 	mov    %r15,0x19c17(%rip)        # 230e0 <fwp_tapes_cap>
    94c9:	48 6b cd 68          	imul   $0x68,%rbp,%rcx
    94cd:	31 c0                	xor    %eax,%eax
    94cf:	49 89 ef             	mov    %rbp,%r15
    94d2:	48 01 d9             	add    %rbx,%rcx
    94d5:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    94d9:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    94e0:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    94e4:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    94eb:	00 
    94ec:	48 29 f9             	sub    %rdi,%rcx
    94ef:	83 c1 68             	add    $0x68,%ecx
    94f2:	c1 e9 03             	shr    $0x3,%ecx
    94f5:	f3 48 ab             	rep stos %rax,(%rdi)
    94f8:	48 8d 45 01          	lea    0x1(%rbp),%rax
    94fc:	48 89 05 e5 9b 01 00 	mov    %rax,0x19be5(%rip)        # 230e8 <fwp_ntapes>
    9503:	49 6b ef 68          	imul   $0x68,%r15,%rbp
    9507:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    950b:	48 8d 3d ad 5b 00 00 	lea    0x5bad(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    9512:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9517:	48 01 dd             	add    %rbx,%rbp
    951a:	48 c7 45 60 00 00 00 	movq   $0x0,0x60(%rbp)
    9521:	00 
    9522:	e8 79 9e ff ff       	call   33a0 <getenv@plt>
    9527:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    952d:	48 85 c0             	test   %rax,%rax
    9530:	0f 84 52 0d 00 00    	je     a288 <fwp_hof0.constprop.0+0x1068>
    9536:	80 38 30             	cmpb   $0x30,(%rax)
    9539:	0f 85 49 0d 00 00    	jne    a288 <fwp_hof0.constprop.0+0x1068>
    953f:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9543:	0f 85 3f 0d 00 00    	jne    a288 <fwp_hof0.constprop.0+0x1068>
    9549:	8b 45 00             	mov    0x0(%rbp),%eax
    954c:	49 8d 77 01          	lea    0x1(%r15),%rsi
    9550:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    9554:	c7 45 04 01 00 00 00 	movl   $0x1,0x4(%rbp)
    955b:	8d 48 01             	lea    0x1(%rax),%ecx
    955e:	48 8b 05 3b 65 00 00 	mov    0x653b(%rip),%rax        # faa0 <msg.4+0x20>
    9565:	48 89 35 6c 9b 01 00 	mov    %rsi,0x19b6c(%rip)        # 230d8 <fwp_tape_next_slot>
    956c:	89 4d 00             	mov    %ecx,0x0(%rbp)
    956f:	48 89 45 58          	mov    %rax,0x58(%rbp)
    9573:	48 8b 05 7e be 01 00 	mov    0x1be7e(%rip),%rax        # 253f8 <fwp_cleanups>
    957a:	48 c7 45 50 00 00 00 	movq   $0x0,0x50(%rbp)
    9581:	00 
    9582:	48 85 c0             	test   %rax,%rax
    9585:	75 15                	jne    959c <fwp_hof0.constprop.0+0x37c>
    9587:	e9 74 14 00 00       	jmp    aa00 <fwp_hof0.constprop.0+0x17e0>
    958c:	0f 1f 40 00          	nopl   0x0(%rax)
    9590:	48 8b 00             	mov    (%rax),%rax
    9593:	48 85 c0             	test   %rax,%rax
    9596:	0f 84 64 14 00 00    	je     aa00 <fwp_hof0.constprop.0+0x17e0>
    959c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    95a0:	75 ee                	jne    9590 <fwp_hof0.constprop.0+0x370>
    95a2:	4c 8b 48 10          	mov    0x10(%rax),%r9
    95a6:	44 89 ff             	mov    %r15d,%edi
    95a9:	49 63 01             	movslq (%r9),%rax
    95ac:	4c 89 4d 50          	mov    %r9,0x50(%rbp)
    95b0:	89 45 5c             	mov    %eax,0x5c(%rbp)
    95b3:	85 c0                	test   %eax,%eax
    95b5:	78 09                	js     95c0 <fwp_hof0.constprop.0+0x3a0>
    95b7:	48 6b c0 68          	imul   $0x68,%rax,%rax
    95bb:	44 89 7c 03 58       	mov    %r15d,0x58(%rbx,%rax,1)
    95c0:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    95c5:	41 89 39             	mov    %edi,(%r9)
    95c8:	45 31 e4             	xor    %r12d,%r12d
    95cb:	48 89 d8             	mov    %rbx,%rax
    95ce:	48 85 db             	test   %rbx,%rbx
    95d1:	0f 84 19 0e 00 00    	je     a3f0 <fwp_hof0.constprop.0+0x11d0>
    95d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    95de:	00 00 
    95e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    95e4:	49 83 c4 01          	add    $0x1,%r12
    95e8:	48 85 c0             	test   %rax,%rax
    95eb:	75 f3                	jne    95e0 <fwp_hof0.constprop.0+0x3c0>
    95ed:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    95f2:	0f 1f 00             	nopl   (%rax)
    95f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    95fc:	00 00 00 00 
    9600:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9604:	48 83 c0 01          	add    $0x1,%rax
    9608:	48 85 d2             	test   %rdx,%rdx
    960b:	75 f3                	jne    9600 <fwp_hof0.constprop.0+0x3e0>
    960d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9614:	ff ff 1f 
    9617:	48 39 c2             	cmp    %rax,%rdx
    961a:	0f 82 d1 13 00 00    	jb     a9f1 <fwp_hof0.constprop.0+0x17d1>
    9620:	4d 85 e4             	test   %r12,%r12
    9623:	0f 8e c7 0d 00 00    	jle    a3f0 <fwp_hof0.constprop.0+0x11d0>
    9629:	49 39 c4             	cmp    %rax,%r12
    962c:	4c 0f 47 e0          	cmova  %rax,%r12
    9630:	4c 89 e0             	mov    %r12,%rax
    9633:	48 c1 e8 3c          	shr    $0x3c,%rax
    9637:	0f 85 b4 13 00 00    	jne    a9f1 <fwp_hof0.constprop.0+0x17d1>
    963d:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    9641:	48 c1 e1 10          	shl    $0x10,%rcx
    9645:	48 09 f1             	or     %rsi,%rcx
    9648:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    964f:	00 
    9650:	be 02 00 00 00       	mov    $0x2,%esi
    9655:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    965a:	e8 f1 c3 ff ff       	call   5a50 <fwp_heap_alloc>
    965f:	4c 89 38             	mov    %r15,(%rax)
    9662:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9669:	48 89 c5             	mov    %rax,%rbp
    966c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9673:	48 c1 e2 10          	shl    $0x10,%rdx
    9677:	48 39 d0             	cmp    %rdx,%rax
    967a:	0f 83 20 0e 00 00    	jae    a4a0 <fwp_hof0.constprop.0+0x1280>
    9680:	48 89 c2             	mov    %rax,%rdx
    9683:	48 c1 ea 10          	shr    $0x10,%rdx
    9687:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    968b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9692:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    9696:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    969a:	4d 85 ff             	test   %r15,%r15
    969d:	74 3a                	je     96d9 <fwp_hof0.constprop.0+0x4b9>
    969f:	0f b6 32             	movzbl (%rdx),%esi
    96a2:	40 80 fe 02          	cmp    $0x2,%sil
    96a6:	0f 84 b7 0d 00 00    	je     a463 <fwp_hof0.constprop.0+0x1243>
    96ac:	40 80 fe 01          	cmp    $0x1,%sil
    96b0:	75 27                	jne    96d9 <fwp_hof0.constprop.0+0x4b9>
    96b2:	8b 72 18             	mov    0x18(%rdx),%esi
    96b5:	0f b7 c0             	movzwl %ax,%eax
    96b8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96bb:	48 0f af c6          	imul   %rsi,%rax
    96bf:	48 c1 e8 20          	shr    $0x20,%rax
    96c3:	48 39 d0             	cmp    %rdx,%rax
    96c6:	73 11                	jae    96d9 <fwp_hof0.constprop.0+0x4b9>
    96c8:	49 01 c7             	add    %rax,%r15
    96cb:	41 80 3f ff          	cmpb   $0xff,(%r15)
    96cf:	0f 84 a1 0d 00 00    	je     a476 <fwp_hof0.constprop.0+0x1256>
    96d5:	41 c6 07 01          	movb   $0x1,(%r15)
    96d9:	4d 85 e4             	test   %r12,%r12
    96dc:	74 55                	je     9733 <fwp_hof0.constprop.0+0x513>
    96de:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    96e3:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    96e8:	31 c0                	xor    %eax,%eax
    96ea:	48 c1 e6 20          	shl    $0x20,%rsi
    96ee:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    96f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    96fc:	00 00 00 00 
    9700:	48 89 c1             	mov    %rax,%rcx
    9703:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9708:	48 01 f1             	add    %rsi,%rcx
    970b:	0f 80 3f a0 ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9711:	66 48 0f 6e e1       	movq   %rcx,%xmm4
    9716:	48 89 c1             	mov    %rax,%rcx
    9719:	48 83 c0 01          	add    $0x1,%rax
    971d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9721:	48 c1 e1 04          	shl    $0x4,%rcx
    9725:	0f 11 44 0d 08       	movups %xmm0,0x8(%rbp,%rcx,1)
    972a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    972e:	4c 39 e0             	cmp    %r12,%rax
    9731:	72 cd                	jb     9700 <fwp_hof0.constprop.0+0x4e0>
    9733:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9737:	48 d1 e8             	shr    $1,%rax
    973a:	0f 84 70 0d 00 00    	je     a4b0 <fwp_hof0.constprop.0+0x1290>
    9740:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9744:	48 89 f3             	mov    %rsi,%rbx
    9747:	48 c1 eb 3c          	shr    $0x3c,%rbx
    974b:	0f 85 a0 12 00 00    	jne    a9f1 <fwp_hof0.constprop.0+0x17d1>
    9751:	48 8d 1c 36          	lea    (%rsi,%rsi,1),%rbx
    9755:	48 85 f6             	test   %rsi,%rsi
    9758:	74 44                	je     979e <fwp_hof0.constprop.0+0x57e>
    975a:	48 c1 e0 04          	shl    $0x4,%rax
    975e:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
    9762:	4c 8d 64 05 f8       	lea    -0x8(%rbp,%rax,1),%r12
    9767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    976e:	00 00 
    9770:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    9775:	49 8b 77 18          	mov    0x18(%r15),%rsi
    9779:	49 83 c7 10          	add    $0x10,%r15
    977d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    9781:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    9786:	e8 15 ca ff ff       	call   61a0 <w120>
    978b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9790:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9794:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    9799:	4d 39 fc             	cmp    %r15,%r12
    979c:	75 d2                	jne    9770 <fwp_hof0.constprop.0+0x550>
    979e:	48 89 5d 00          	mov    %rbx,0x0(%rbp)
    97a2:	48 89 ef             	mov    %rbp,%rdi
    97a5:	e8 b6 cb ff ff       	call   6360 <w176.constprop.0>
    97aa:	48 89 ef             	mov    %rbp,%rdi
    97ad:	49 89 c4             	mov    %rax,%r12
    97b0:	e8 db e2 ff ff       	call   7a90 <fwp_drop10>
    97b5:	4c 63 7c 24 10       	movslq 0x10(%rsp),%r15
    97ba:	4c 89 ff             	mov    %r15,%rdi
    97bd:	e8 be ac ff ff       	call   4480 <fwp_tape_of>
    97c2:	48 89 c6             	mov    %rax,%rsi
    97c5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    97ca:	0f 85 c6 12 00 00    	jne    aa96 <fwp_hof0.constprop.0+0x1876>
    97d0:	48 89 c7             	mov    %rax,%rdi
    97d3:	e8 28 a4 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    97d8:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    97dc:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    97e1:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    97e8:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    97ec:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    97f0:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    97f5:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    97fa:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    97ff:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    9803:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    9807:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    980d:	77 1a                	ja     9829 <fwp_hof0.constprop.0+0x609>
    980f:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
    9814:	83 e8 01             	sub    $0x1,%eax
    9817:	48 98                	cltq
    9819:	48 3b 05 b8 98 01 00 	cmp    0x198b8(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    9820:	7d 07                	jge    9829 <fwp_hof0.constprop.0+0x609>
    9822:	48 89 05 af 98 01 00 	mov    %rax,0x198af(%rip)        # 230d8 <fwp_tape_next_slot>
    9829:	48 8b 05 c8 bb 01 00 	mov    0x1bbc8(%rip),%rax        # 253f8 <fwp_cleanups>
    9830:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9834:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    983b:	00 
    983c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9840:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9847:	00 
    9848:	48 8d 05 e1 b5 ff ff 	lea    -0x4a1f(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    984f:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    9856:	00 
    9857:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    985e:	00 
    985f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9864:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    986b:	00 
    986c:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    9873:	00 
    9874:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    987b:	00 
    987c:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9883:	00 
    9884:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9888:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    988c:	48 89 05 65 bb 01 00 	mov    %rax,0x1bb65(%rip)        # 253f8 <fwp_cleanups>
    9893:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    989a:	00 
    989b:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
    98a2:	00 
    98a3:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
    98aa:	00 
    98ab:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    98b2:	00 
    98b3:	4d 85 e4             	test   %r12,%r12
    98b6:	0f 88 74 0d 00 00    	js     a630 <fwp_hof0.constprop.0+0x1410>
    98bc:	4c 89 e0             	mov    %r12,%rax
    98bf:	48 c1 f8 20          	sar    $0x20,%rax
    98c3:	49 39 c7             	cmp    %rax,%r15
    98c6:	0f 85 e1 10 00 00    	jne    a9ad <fwp_hof0.constprop.0+0x178d>
    98cc:	45 89 e7             	mov    %r12d,%r15d
    98cf:	4c 89 fd             	mov    %r15,%rbp
    98d2:	4c 39 ff             	cmp    %r15,%rdi
    98d5:	0f 8e de 10 00 00    	jle    a9b9 <fwp_hof0.constprop.0+0x1799>
    98db:	4c 39 fb             	cmp    %r15,%rbx
    98de:	0f 8e fc 0b 00 00    	jle    a4e0 <fwp_hof0.constprop.0+0x12c0>
    98e4:	48 39 d3             	cmp    %rdx,%rbx
    98e7:	0f 8f 3b 0c 00 00    	jg     a528 <fwp_hof0.constprop.0+0x1308>
    98ed:	48 85 c9             	test   %rcx,%rcx
    98f0:	0f 84 1f 11 00 00    	je     aa15 <fwp_hof0.constprop.0+0x17f5>
    98f6:	48 89 cf             	mov    %rcx,%rdi
    98f9:	31 f6                	xor    %esi,%esi
    98fb:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    9900:	48 8d 6b ff          	lea    -0x1(%rbx),%rbp
    9904:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    990b:	00 
    990c:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    9911:	e8 aa 9b ff ff       	call   34c0 <memset@plt>
    9916:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    991c:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    9922:	48 89 c1             	mov    %rax,%rcx
    9925:	f2 0f 10 05 7b 61 00 	movsd  0x617b(%rip),%xmm0        # faa8 <msg.4+0x28>
    992c:	00 
    992d:	f2 42 0f 58 04 f9    	addsd  (%rcx,%r15,8),%xmm0
    9933:	f2 42 0f 11 04 f9    	movsd  %xmm0,(%rcx,%r15,8)
    9939:	48 39 eb             	cmp    %rbp,%rbx
    993c:	0f 8f 90 00 00 00    	jg     99d2 <fwp_hof0.constprop.0+0x7b2>
    9942:	0f 12 fb             	movhlps %xmm3,%xmm7
    9945:	66 49 0f 7e d2       	movq   %xmm2,%r10
    994a:	66 48 0f 7e de       	movq   %xmm3,%rsi
    994f:	48 29 dd             	sub    %rbx,%rbp
    9952:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    9957:	0f 12 fa             	movhlps %xmm2,%xmm7
    995a:	66 0f ef d2          	pxor   %xmm2,%xmm2
    995e:	66 49 0f 7e fb       	movq   %xmm7,%r11
    9963:	48 8d 04 af          	lea    (%rdi,%rbp,4),%rax
    9967:	48 29 fe             	sub    %rdi,%rsi
    996a:	49 8d 14 eb          	lea    (%r11,%rbp,8),%rdx
    996e:	48 8d 2c d9          	lea    (%rcx,%rbx,8),%rbp
    9972:	4d 29 da             	sub    %r11,%r10
    9975:	4c 29 dd             	sub    %r11,%rbp
    9978:	eb 0a                	jmp    9984 <fwp_hof0.constprop.0+0x764>
    997a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9980:	48 83 e8 04          	sub    $0x4,%rax
    9984:	f2 0f 10 44 15 00    	movsd  0x0(%rbp,%rdx,1),%xmm0
    998a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    998e:	7a 02                	jp     9992 <fwp_hof0.constprop.0+0x772>
    9990:	74 37                	je     99c9 <fwp_hof0.constprop.0+0x7a9>
    9992:	4c 63 04 06          	movslq (%rsi,%rax,1),%r8
    9996:	45 85 c0             	test   %r8d,%r8d
    9999:	78 16                	js     99b1 <fwp_hof0.constprop.0+0x791>
    999b:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    99a1:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    99a5:	f2 42 0f 58 0c c1    	addsd  (%rcx,%r8,8),%xmm1
    99ab:	f2 42 0f 11 0c c1    	movsd  %xmm1,(%rcx,%r8,8)
    99b1:	4c 63 00             	movslq (%rax),%r8
    99b4:	45 85 c0             	test   %r8d,%r8d
    99b7:	78 10                	js     99c9 <fwp_hof0.constprop.0+0x7a9>
    99b9:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    99bd:	f2 42 0f 58 04 c1    	addsd  (%rcx,%r8,8),%xmm0
    99c3:	f2 42 0f 11 04 c1    	movsd  %xmm0,(%rcx,%r8,8)
    99c9:	48 83 ea 08          	sub    $0x8,%rdx
    99cd:	48 39 c7             	cmp    %rax,%rdi
    99d0:	75 ae                	jne    9980 <fwp_hof0.constprop.0+0x760>
    99d2:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    99d9:	ff ff 1f 
    99dc:	48 39 d8             	cmp    %rbx,%rax
    99df:	0f 82 00 10 00 00    	jb     a9e5 <fwp_hof0.constprop.0+0x17c5>
    99e5:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    99ec:	00 
    99ed:	be 02 00 00 00       	mov    $0x2,%esi
    99f2:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    99f7:	e8 54 c0 ff ff       	call   5a50 <fwp_heap_alloc>
    99fc:	48 85 db             	test   %rbx,%rbx
    99ff:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9a04:	48 89 18             	mov    %rbx,(%rax)
    9a07:	49 89 c7             	mov    %rax,%r15
    9a0a:	74 26                	je     9a32 <fwp_hof0.constprop.0+0x812>
    9a0c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a13:	00 00 
    9a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9a1c:	00 00 00 00 
    9a20:	4a 8b 04 f1          	mov    (%rcx,%r14,8),%rax
    9a24:	4b 89 44 f7 08       	mov    %rax,0x8(%r15,%r14,8)
    9a29:	49 83 c6 01          	add    $0x1,%r14
    9a2d:	4c 39 f3             	cmp    %r14,%rbx
    9a30:	75 ee                	jne    9a20 <fwp_hof0.constprop.0+0x800>
    9a32:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
    9a39:	00 
    9a3a:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    9a3f:	4c 89 25 b2 b9 01 00 	mov    %r12,0x1b9b2(%rip)        # 253f8 <fwp_cleanups>
    9a46:	e8 e5 b3 ff ff       	call   4e30 <fwp_tape_buffers_release>
    9a4b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9a52:	4c 89 f8             	mov    %r15,%rax
    9a55:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9a5c:	48 c1 e2 10          	shl    $0x10,%rdx
    9a60:	48 39 d0             	cmp    %rdx,%rax
    9a63:	73 57                	jae    9abc <fwp_hof0.constprop.0+0x89c>
    9a65:	48 89 c2             	mov    %rax,%rdx
    9a68:	48 c1 ea 10          	shr    $0x10,%rdx
    9a6c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a70:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9a77:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a7b:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9a7f:	48 85 ed             	test   %rbp,%rbp
    9a82:	74 38                	je     9abc <fwp_hof0.constprop.0+0x89c>
    9a84:	0f b6 0a             	movzbl (%rdx),%ecx
    9a87:	80 f9 02             	cmp    $0x2,%cl
    9a8a:	0f 84 d0 0b 00 00    	je     a660 <fwp_hof0.constprop.0+0x1440>
    9a90:	80 f9 01             	cmp    $0x1,%cl
    9a93:	75 27                	jne    9abc <fwp_hof0.constprop.0+0x89c>
    9a95:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a98:	0f b7 c0             	movzwl %ax,%eax
    9a9b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a9e:	48 0f af c1          	imul   %rcx,%rax
    9aa2:	48 c1 e8 20          	shr    $0x20,%rax
    9aa6:	48 39 d0             	cmp    %rdx,%rax
    9aa9:	73 11                	jae    9abc <fwp_hof0.constprop.0+0x89c>
    9aab:	48 01 c5             	add    %rax,%rbp
    9aae:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9ab2:	0f 84 bb 0b 00 00    	je     a673 <fwp_hof0.constprop.0+0x1453>
    9ab8:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9abc:	4c 3b 64 24 38       	cmp    0x38(%rsp),%r12
    9ac1:	0f 85 84 9c ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9ac7:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    9ace:	00 
    9acf:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9ad4:	48 89 05 1d b9 01 00 	mov    %rax,0x1b91d(%rip)        # 253f8 <fwp_cleanups>
    9adb:	e8 80 d0 ff ff       	call   6b60 <fwp_tape_scope_release>
    9ae0:	49 8b 07             	mov    (%r15),%rax
    9ae3:	49 89 c6             	mov    %rax,%r14
    9ae6:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9aeb:	48 85 c0             	test   %rax,%rax
    9aee:	0f 88 2c 08 00 00    	js     a320 <fwp_hof0.constprop.0+0x1100>
    9af4:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9afb:	4c 89 f8             	mov    %r15,%rax
    9afe:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9b05:	48 c1 e2 10          	shl    $0x10,%rdx
    9b09:	48 39 d0             	cmp    %rdx,%rax
    9b0c:	0f 83 0e 08 00 00    	jae    a320 <fwp_hof0.constprop.0+0x1100>
    9b12:	48 89 c2             	mov    %rax,%rdx
    9b15:	48 c1 ea 10          	shr    $0x10,%rdx
    9b19:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b1d:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9b24:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b28:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9b2c:	48 85 c9             	test   %rcx,%rcx
    9b2f:	0f 84 eb 07 00 00    	je     a320 <fwp_hof0.constprop.0+0x1100>
    9b35:	0f b6 32             	movzbl (%rdx),%esi
    9b38:	40 80 fe 02          	cmp    $0x2,%sil
    9b3c:	0f 84 c6 07 00 00    	je     a308 <fwp_hof0.constprop.0+0x10e8>
    9b42:	40 80 fe 01          	cmp    $0x1,%sil
    9b46:	0f 85 d4 07 00 00    	jne    a320 <fwp_hof0.constprop.0+0x1100>
    9b4c:	8b 72 18             	mov    0x18(%rdx),%esi
    9b4f:	0f b7 c0             	movzwl %ax,%eax
    9b52:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b55:	48 0f af c6          	imul   %rsi,%rax
    9b59:	48 c1 e8 20          	shr    $0x20,%rax
    9b5d:	48 39 d0             	cmp    %rdx,%rax
    9b60:	0f 83 ba 07 00 00    	jae    a320 <fwp_hof0.constprop.0+0x1100>
    9b66:	48 01 c1             	add    %rax,%rcx
    9b69:	80 39 01             	cmpb   $0x1,(%rcx)
    9b6c:	0f 85 ae 07 00 00    	jne    a320 <fwp_hof0.constprop.0+0x1100>
    9b72:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    9b77:	4c 89 fd             	mov    %r15,%rbp
    9b7a:	31 ff                	xor    %edi,%edi
    9b7c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9b81:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9b85:	31 c0                	xor    %eax,%eax
    9b87:	4d 85 f6             	test   %r14,%r14
    9b8a:	75 2e                	jne    9bba <fwp_hof0.constprop.0+0x99a>
    9b8c:	eb 42                	jmp    9bd0 <fwp_hof0.constprop.0+0x9b0>
    9b8e:	66 90                	xchg   %ax,%ax
    9b90:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9b95:	0f 88 2a 0e 00 00    	js     a9c5 <fwp_hof0.constprop.0+0x17a5>
    9b9b:	f2 0f 10 05 1d 5f 00 	movsd  0x5f1d(%rip),%xmm0        # fac0 <msg.4+0x40>
    9ba2:	00 
    9ba3:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    9ba8:	48 83 c0 01          	add    $0x1,%rax
    9bac:	48 83 c2 08          	add    $0x8,%rdx
    9bb0:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9bb5:	49 39 c6             	cmp    %rax,%r14
    9bb8:	74 16                	je     9bd0 <fwp_hof0.constprop.0+0x9b0>
    9bba:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    9bbe:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9bc2:	79 cc                	jns    9b90 <fwp_hof0.constprop.0+0x970>
    9bc4:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    9bc8:	eb c6                	jmp    9b90 <fwp_hof0.constprop.0+0x970>
    9bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9bd0:	e8 bb de ff ff       	call   7a90 <fwp_drop10>
    9bd5:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    9bda:	31 d2                	xor    %edx,%edx
    9bdc:	48 89 d8             	mov    %rbx,%rax
    9bdf:	48 85 db             	test   %rbx,%rbx
    9be2:	0f 84 11 0c 00 00    	je     a7f9 <fwp_hof0.constprop.0+0x15d9>
    9be8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9bef:	00 
    9bf0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9bf4:	48 83 c2 01          	add    $0x1,%rdx
    9bf8:	48 85 c0             	test   %rax,%rax
    9bfb:	75 f3                	jne    9bf0 <fwp_hof0.constprop.0+0x9d0>
    9bfd:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9c01:	49 89 c7             	mov    %rax,%r15
    9c04:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9c09:	48 85 c0             	test   %rax,%rax
    9c0c:	0f 88 cb 05 00 00    	js     a1dd <fwp_hof0.constprop.0+0xfbd>
    9c12:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    9c19:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9c1e:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    9c25:	48 c1 e0 10          	shl    $0x10,%rax
    9c29:	48 39 c1             	cmp    %rax,%rcx
    9c2c:	0f 83 ab 05 00 00    	jae    a1dd <fwp_hof0.constprop.0+0xfbd>
    9c32:	48 89 c8             	mov    %rcx,%rax
    9c35:	48 c1 e8 10          	shr    $0x10,%rax
    9c39:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    9c3d:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    9c44:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9c48:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9c4c:	48 85 ff             	test   %rdi,%rdi
    9c4f:	0f 84 88 05 00 00    	je     a1dd <fwp_hof0.constprop.0+0xfbd>
    9c55:	0f b6 06             	movzbl (%rsi),%eax
    9c58:	3c 02                	cmp    $0x2,%al
    9c5a:	0f 84 68 05 00 00    	je     a1c8 <fwp_hof0.constprop.0+0xfa8>
    9c60:	3c 01                	cmp    $0x1,%al
    9c62:	0f 85 69 05 00 00    	jne    a1d1 <fwp_hof0.constprop.0+0xfb1>
    9c68:	8b 46 18             	mov    0x18(%rsi),%eax
    9c6b:	0f b7 c9             	movzwl %cx,%ecx
    9c6e:	48 0f af c8          	imul   %rax,%rcx
    9c72:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9c75:	48 c1 e9 20          	shr    $0x20,%rcx
    9c79:	48 39 c1             	cmp    %rax,%rcx
    9c7c:	0f 83 4f 05 00 00    	jae    a1d1 <fwp_hof0.constprop.0+0xfb1>
    9c82:	48 01 cf             	add    %rcx,%rdi
    9c85:	80 3f 01             	cmpb   $0x1,(%rdi)
    9c88:	0f 85 43 05 00 00    	jne    a1d1 <fwp_hof0.constprop.0+0xfb1>
    9c8e:	4c 39 fa             	cmp    %r15,%rdx
    9c91:	4c 89 f8             	mov    %r15,%rax
    9c94:	48 0f 46 c2          	cmovbe %rdx,%rax
    9c98:	48 85 c0             	test   %rax,%rax
    9c9b:	0f 84 30 0d 00 00    	je     a9d1 <fwp_hof0.constprop.0+0x17b1>
    9ca1:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
    9ca8:	00 
    9ca9:	4c 8d 65 08          	lea    0x8(%rbp),%r12
    9cad:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    9cb2:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9cb7:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    9cbe:	00 
    9cbf:	31 d2                	xor    %edx,%edx
    9cc1:	49 8d 78 08          	lea    0x8(%r8),%rdi
    9cc5:	eb 56                	jmp    9d1d <fwp_hof0.constprop.0+0xafd>
    9cc7:	66 90                	xchg   %ax,%ax
    9cc9:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9cd0:	00 00 00 00 
    9cd4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9cdb:	00 00 00 00 
    9cdf:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9ce6:	00 00 00 00 
    9cea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9cf1:	00 00 00 00 
    9cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9cfc:	00 00 00 00 
    9d00:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9d05:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    9d0a:	f2 41 0f 11 04 14    	movsd  %xmm0,(%r12,%rdx,1)
    9d10:	48 83 c2 08          	add    $0x8,%rdx
    9d14:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9d18:	49 39 d1             	cmp    %rdx,%r9
    9d1b:	74 13                	je     9d30 <fwp_hof0.constprop.0+0xb10>
    9d1d:	48 89 fe             	mov    %rdi,%rsi
    9d20:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9d25:	79 d9                	jns    9d00 <fwp_hof0.constprop.0+0xae0>
    9d27:	49 8b 70 10          	mov    0x10(%r8),%rsi
    9d2b:	eb d3                	jmp    9d00 <fwp_hof0.constprop.0+0xae0>
    9d2d:	0f 1f 00             	nopl   (%rax)
    9d30:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9d35:	48 85 c9             	test   %rcx,%rcx
    9d38:	0f 84 67 0c 00 00    	je     a9a5 <fwp_hof0.constprop.0+0x1785>
    9d3e:	4d 8b 8d d8 13 00 00 	mov    0x13d8(%r13),%r9
    9d45:	4d 8b 95 b0 13 00 00 	mov    0x13b0(%r13),%r10
    9d4c:	45 31 ff             	xor    %r15d,%r15d
    9d4f:	4d 8b 9d f8 13 00 00 	mov    0x13f8(%r13),%r11
    9d56:	49 c1 e1 10          	shl    $0x10,%r9
    9d5a:	eb 1a                	jmp    9d76 <fwp_hof0.constprop.0+0xb56>
    9d5c:	0f 1f 40 00          	nopl   0x0(%rax)
    9d60:	49 83 c7 01          	add    $0x1,%r15
    9d64:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9d68:	49 39 c7             	cmp    %rax,%r15
    9d6b:	0f 83 5f 01 00 00    	jae    9ed0 <fwp_hof0.constprop.0+0xcb0>
    9d71:	48 85 c9             	test   %rcx,%rcx
    9d74:	74 56                	je     9dcc <fwp_hof0.constprop.0+0xbac>
    9d76:	48 89 ca             	mov    %rcx,%rdx
    9d79:	4c 29 d2             	sub    %r10,%rdx
    9d7c:	4c 39 ca             	cmp    %r9,%rdx
    9d7f:	73 4b                	jae    9dcc <fwp_hof0.constprop.0+0xbac>
    9d81:	48 89 d6             	mov    %rdx,%rsi
    9d84:	48 c1 ee 10          	shr    $0x10,%rsi
    9d88:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9d8c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    9d90:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9d94:	48 85 ff             	test   %rdi,%rdi
    9d97:	74 33                	je     9dcc <fwp_hof0.constprop.0+0xbac>
    9d99:	44 0f b6 06          	movzbl (%rsi),%r8d
    9d9d:	41 80 f8 02          	cmp    $0x2,%r8b
    9da1:	0f 84 11 01 00 00    	je     9eb8 <fwp_hof0.constprop.0+0xc98>
    9da7:	41 80 f8 01          	cmp    $0x1,%r8b
    9dab:	75 1f                	jne    9dcc <fwp_hof0.constprop.0+0xbac>
    9dad:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9db1:	0f b7 d2             	movzwl %dx,%edx
    9db4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9db7:	49 0f af d0          	imul   %r8,%rdx
    9dbb:	48 c1 ea 20          	shr    $0x20,%rdx
    9dbf:	48 39 f2             	cmp    %rsi,%rdx
    9dc2:	73 08                	jae    9dcc <fwp_hof0.constprop.0+0xbac>
    9dc4:	48 01 d7             	add    %rdx,%rdi
    9dc7:	80 3f 01             	cmpb   $0x1,(%rdi)
    9dca:	74 94                	je     9d60 <fwp_hof0.constprop.0+0xb40>
    9dcc:	49 39 c7             	cmp    %rax,%r15
    9dcf:	0f 83 fb 00 00 00    	jae    9ed0 <fwp_hof0.constprop.0+0xcb0>
    9dd5:	48 89 c3             	mov    %rax,%rbx
    9dd8:	45 31 f6             	xor    %r14d,%r14d
    9ddb:	48 8d ac 24 10 01 00 	lea    0x110(%rsp),%rbp
    9de2:	00 
    9de3:	eb 37                	jmp    9e1c <fwp_hof0.constprop.0+0xbfc>
    9de5:	0f 1f 00             	nopl   (%rax)
    9de8:	40 80 fe 01          	cmp    $0x1,%sil
    9dec:	75 25                	jne    9e13 <fwp_hof0.constprop.0+0xbf3>
    9dee:	8b 71 18             	mov    0x18(%rcx),%esi
    9df1:	0f b7 c0             	movzwl %ax,%eax
    9df4:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9df7:	48 0f af c6          	imul   %rsi,%rax
    9dfb:	48 c1 e8 20          	shr    $0x20,%rax
    9dff:	48 39 c8             	cmp    %rcx,%rax
    9e02:	73 0f                	jae    9e13 <fwp_hof0.constprop.0+0xbf3>
    9e04:	48 01 c2             	add    %rax,%rdx
    9e07:	80 3a ff             	cmpb   $0xff,(%rdx)
    9e0a:	0f 84 c0 05 00 00    	je     a3d0 <fwp_hof0.constprop.0+0x11b0>
    9e10:	c6 02 01             	movb   $0x1,(%rdx)
    9e13:	49 39 df             	cmp    %rbx,%r15
    9e16:	0f 83 84 00 00 00    	jae    9ea0 <fwp_hof0.constprop.0+0xc80>
    9e1c:	48 83 eb 01          	sub    $0x1,%rbx
    9e20:	66 49 0f 6e f6       	movq   %r14,%xmm6
    9e25:	48 89 ee             	mov    %rbp,%rsi
    9e28:	bf 01 00 00 00       	mov    $0x1,%edi
    9e2d:	f3 41 0f 7e 04 dc    	movq   (%r12,%rbx,8),%xmm0
    9e33:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9e37:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
    9e3e:	00 
    9e3f:	e8 2c bd ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9e44:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9e4b:	49 89 c6             	mov    %rax,%r14
    9e4e:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9e55:	48 c1 e2 10          	shl    $0x10,%rdx
    9e59:	48 39 d0             	cmp    %rdx,%rax
    9e5c:	73 b5                	jae    9e13 <fwp_hof0.constprop.0+0xbf3>
    9e5e:	48 89 c2             	mov    %rax,%rdx
    9e61:	48 c1 ea 10          	shr    $0x10,%rdx
    9e65:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e69:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9e70:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9e74:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9e78:	48 85 d2             	test   %rdx,%rdx
    9e7b:	74 96                	je     9e13 <fwp_hof0.constprop.0+0xbf3>
    9e7d:	0f b6 31             	movzbl (%rcx),%esi
    9e80:	40 80 fe 02          	cmp    $0x2,%sil
    9e84:	0f 85 5e ff ff ff    	jne    9de8 <fwp_hof0.constprop.0+0xbc8>
    9e8a:	66 85 c0             	test   %ax,%ax
    9e8d:	0f 84 74 ff ff ff    	je     9e07 <fwp_hof0.constprop.0+0xbe7>
    9e93:	49 39 df             	cmp    %rbx,%r15
    9e96:	72 84                	jb     9e1c <fwp_hof0.constprop.0+0xbfc>
    9e98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e9f:	00 
    9ea0:	4d 85 ff             	test   %r15,%r15
    9ea3:	75 2e                	jne    9ed3 <fwp_hof0.constprop.0+0xcb3>
    9ea5:	8b 44 24 30          	mov    0x30(%rsp),%eax
    9ea9:	85 c0                	test   %eax,%eax
    9eab:	4d 0f 45 e7          	cmovne %r15,%r12
    9eaf:	eb 63                	jmp    9f14 <fwp_hof0.constprop.0+0xcf4>
    9eb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9eb8:	66 85 d2             	test   %dx,%dx
    9ebb:	0f 84 06 ff ff ff    	je     9dc7 <fwp_hof0.constprop.0+0xba7>
    9ec1:	49 39 c7             	cmp    %rax,%r15
    9ec4:	0f 82 0b ff ff ff    	jb     9dd5 <fwp_hof0.constprop.0+0xbb5>
    9eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ed0:	45 31 f6             	xor    %r14d,%r14d
    9ed3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9ed8:	4c 89 e2             	mov    %r12,%rdx
    9edb:	4f 8d 0c fc          	lea    (%r12,%r15,8),%r9
    9edf:	90                   	nop
    9ee0:	48 8b 0a             	mov    (%rdx),%rcx
    9ee3:	48 83 c2 08          	add    $0x8,%rdx
    9ee7:	48 89 c7             	mov    %rax,%rdi
    9eea:	48 89 48 08          	mov    %rcx,0x8(%rax)
    9eee:	48 8b 40 10          	mov    0x10(%rax),%rax
    9ef2:	4c 39 ca             	cmp    %r9,%rdx
    9ef5:	75 e9                	jne    9ee0 <fwp_hof0.constprop.0+0xcc0>
    9ef7:	8b 54 24 30          	mov    0x30(%rsp),%edx
    9efb:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    9eff:	85 d2                	test   %edx,%edx
    9f01:	0f 84 79 07 00 00    	je     a680 <fwp_hof0.constprop.0+0x1460>
    9f07:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    9f0c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9f11:	45 31 e4             	xor    %r12d,%r12d
    9f14:	4c 89 e7             	mov    %r12,%rdi
    9f17:	e8 34 b6 ff ff       	call   5550 <fwp_mem_free>
    9f1c:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    9f21:	e8 6a db ff ff       	call   7a90 <fwp_drop10>
    9f26:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9f2d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9f32:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9f39:	48 c1 e2 10          	shl    $0x10,%rdx
    9f3d:	48 39 d0             	cmp    %rdx,%rax
    9f40:	73 6e                	jae    9fb0 <fwp_hof0.constprop.0+0xd90>
    9f42:	48 89 c2             	mov    %rax,%rdx
    9f45:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    9f4c:	48 c1 ea 10          	shr    $0x10,%rdx
    9f50:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    9f54:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    9f58:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9f5c:	48 85 ed             	test   %rbp,%rbp
    9f5f:	74 4f                	je     9fb0 <fwp_hof0.constprop.0+0xd90>
    9f61:	0f b6 0a             	movzbl (%rdx),%ecx
    9f64:	80 f9 02             	cmp    $0x2,%cl
    9f67:	0f 84 a3 06 00 00    	je     a610 <fwp_hof0.constprop.0+0x13f0>
    9f6d:	80 f9 01             	cmp    $0x1,%cl
    9f70:	75 3e                	jne    9fb0 <fwp_hof0.constprop.0+0xd90>
    9f72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f75:	0f b7 c0             	movzwl %ax,%eax
    9f78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f7b:	48 0f af c1          	imul   %rcx,%rax
    9f7f:	48 c1 e8 20          	shr    $0x20,%rax
    9f83:	48 39 d0             	cmp    %rdx,%rax
    9f86:	73 28                	jae    9fb0 <fwp_hof0.constprop.0+0xd90>
    9f88:	48 01 c5             	add    %rax,%rbp
    9f8b:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    9f8f:	84 c0                	test   %al,%al
    9f91:	74 1d                	je     9fb0 <fwp_hof0.constprop.0+0xd90>
    9f93:	3c 01                	cmp    $0x1,%al
    9f95:	0f 84 f5 06 00 00    	je     a690 <fwp_hof0.constprop.0+0x1470>
    9f9b:	3c ff                	cmp    $0xff,%al
    9f9d:	0f 84 d1 08 00 00    	je     a874 <fwp_hof0.constprop.0+0x1654>
    9fa3:	83 e8 01             	sub    $0x1,%eax
    9fa6:	88 45 00             	mov    %al,0x0(%rbp)
    9fa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9fb0:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    9fb6:	0f 85 04 05 00 00    	jne    a4c0 <fwp_hof0.constprop.0+0x12a0>
    9fbc:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    9fc1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9fc5:	4c 89 f6             	mov    %r14,%rsi
    9fc8:	4c 89 f5             	mov    %r14,%rbp
    9fcb:	b9 01 00 00 00       	mov    $0x1,%ecx
    9fd0:	48 8d 15 c9 8b 00 00 	lea    0x8bc9(%rip),%rdx        # 12ba0 <d0>
    9fd7:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    9fde:	00 00 00 00 00 
    9fe3:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    9fea:	00 
    9feb:	e8 f0 e1 ff ff       	call   81e0 <fwp_write>
    9ff0:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
    9ff7:	00 
    9ff8:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    9fff:	00 
    a000:	48 8d 05 27 50 00 00 	lea    0x5027(%rip),%rax        # f02e <_IO_stdin_used+0x2e>
    a007:	48 85 c9             	test   %rcx,%rcx
    a00a:	48 0f 44 c8          	cmove  %rax,%rcx
    a00e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a012:	0f 87 8f 0a 00 00    	ja     aaa7 <fwp_hof0.constprop.0+0x1887>
    a018:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a01c:	be 01 00 00 00       	mov    $0x1,%esi
    a021:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a026:	e8 25 ba ff ff       	call   5a50 <fwp_heap_alloc>
    a02b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a030:	4c 89 fa             	mov    %r15,%rdx
    a033:	4c 89 38             	mov    %r15,(%rax)
    a036:	4c 8d 60 08          	lea    0x8(%rax),%r12
    a03a:	48 89 c3             	mov    %rax,%rbx
    a03d:	4c 89 e7             	mov    %r12,%rdi
    a040:	e8 5b 95 ff ff       	call   35a0 <memcpy@plt>
    a045:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a04b:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    a052:	00 
    a053:	e8 68 93 ff ff       	call   33c0 <free@plt>
    a058:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a05f:	48 89 d8             	mov    %rbx,%rax
    a062:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a069:	48 c1 e2 10          	shl    $0x10,%rdx
    a06d:	48 39 d0             	cmp    %rdx,%rax
    a070:	73 57                	jae    a0c9 <fwp_hof0.constprop.0+0xea9>
    a072:	48 89 c2             	mov    %rax,%rdx
    a075:	48 c1 ea 10          	shr    $0x10,%rdx
    a079:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a07d:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a084:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a088:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a08c:	4d 85 ff             	test   %r15,%r15
    a08f:	74 38                	je     a0c9 <fwp_hof0.constprop.0+0xea9>
    a091:	0f b6 0a             	movzbl (%rdx),%ecx
    a094:	80 f9 02             	cmp    $0x2,%cl
    a097:	0f 84 33 07 00 00    	je     a7d0 <fwp_hof0.constprop.0+0x15b0>
    a09d:	80 f9 01             	cmp    $0x1,%cl
    a0a0:	75 27                	jne    a0c9 <fwp_hof0.constprop.0+0xea9>
    a0a2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a0a5:	0f b7 c0             	movzwl %ax,%eax
    a0a8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0ab:	48 0f af c1          	imul   %rcx,%rax
    a0af:	48 c1 e8 20          	shr    $0x20,%rax
    a0b3:	48 39 d0             	cmp    %rdx,%rax
    a0b6:	73 11                	jae    a0c9 <fwp_hof0.constprop.0+0xea9>
    a0b8:	49 01 c7             	add    %rax,%r15
    a0bb:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a0bf:	0f 84 1e 07 00 00    	je     a7e3 <fwp_hof0.constprop.0+0x15c3>
    a0c5:	41 c6 07 01          	movb   $0x1,(%r15)
    a0c9:	48 89 ef             	mov    %rbp,%rdi
    a0cc:	e8 cf d5 ff ff       	call   76a0 <fwp_drop0>
    a0d1:	48 8b 13             	mov    (%rbx),%rdx
    a0d4:	be 01 00 00 00       	mov    $0x1,%esi
    a0d9:	4c 89 e7             	mov    %r12,%rdi
    a0dc:	48 8b 0d dd b2 01 00 	mov    0x1b2dd(%rip),%rcx        # 253c0 <fwp_prog_out>
    a0e3:	e8 98 95 ff ff       	call   3680 <fwrite@plt>
    a0e8:	48 8b 35 d1 b2 01 00 	mov    0x1b2d1(%rip),%rsi        # 253c0 <fwp_prog_out>
    a0ef:	bf 0a 00 00 00       	mov    $0xa,%edi
    a0f4:	e8 e7 93 ff ff       	call   34e0 <fputc@plt>
    a0f9:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a100:	48 89 d8             	mov    %rbx,%rax
    a103:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a10a:	48 c1 e2 10          	shl    $0x10,%rdx
    a10e:	48 39 d0             	cmp    %rdx,%rax
    a111:	73 6d                	jae    a180 <fwp_hof0.constprop.0+0xf60>
    a113:	48 89 c2             	mov    %rax,%rdx
    a116:	48 c1 ea 10          	shr    $0x10,%rdx
    a11a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a11e:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a125:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a129:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a12d:	48 85 ed             	test   %rbp,%rbp
    a130:	74 4e                	je     a180 <fwp_hof0.constprop.0+0xf60>
    a132:	0f b6 0a             	movzbl (%rdx),%ecx
    a135:	80 f9 02             	cmp    $0x2,%cl
    a138:	0f 84 62 06 00 00    	je     a7a0 <fwp_hof0.constprop.0+0x1580>
    a13e:	80 f9 01             	cmp    $0x1,%cl
    a141:	75 3d                	jne    a180 <fwp_hof0.constprop.0+0xf60>
    a143:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a146:	0f b7 c0             	movzwl %ax,%eax
    a149:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a14c:	48 0f af c1          	imul   %rcx,%rax
    a150:	48 c1 e8 20          	shr    $0x20,%rax
    a154:	48 39 d0             	cmp    %rdx,%rax
    a157:	73 27                	jae    a180 <fwp_hof0.constprop.0+0xf60>
    a159:	48 01 c5             	add    %rax,%rbp
    a15c:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a160:	84 c0                	test   %al,%al
    a162:	74 1c                	je     a180 <fwp_hof0.constprop.0+0xf60>
    a164:	3c 01                	cmp    $0x1,%al
    a166:	0f 84 51 06 00 00    	je     a7bd <fwp_hof0.constprop.0+0x159d>
    a16c:	3c ff                	cmp    $0xff,%al
    a16e:	0f 84 71 07 00 00    	je     a8e5 <fwp_hof0.constprop.0+0x16c5>
    a174:	83 e8 01             	sub    $0x1,%eax
    a177:	88 45 00             	mov    %al,0x0(%rbp)
    a17a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a180:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a185:	48 8b 40 10          	mov    0x10(%rax),%rax
    a189:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a18e:	48 85 c0             	test   %rax,%rax
    a191:	0f 85 c9 f0 ff ff    	jne    9260 <fwp_hof0.constprop.0+0x40>
    a197:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    a19e:	00 
    a19f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a1a6:	00 00 
    a1a8:	0f 85 f4 08 00 00    	jne    aaa2 <fwp_hof0.constprop.0+0x1882>
    a1ae:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
    a1b5:	31 c0                	xor    %eax,%eax
    a1b7:	5b                   	pop    %rbx
    a1b8:	5d                   	pop    %rbp
    a1b9:	41 5c                	pop    %r12
    a1bb:	41 5d                	pop    %r13
    a1bd:	41 5e                	pop    %r14
    a1bf:	41 5f                	pop    %r15
    a1c1:	c3                   	ret
    a1c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a1c8:	66 85 c9             	test   %cx,%cx
    a1cb:	0f 84 b4 fa ff ff    	je     9c85 <fwp_hof0.constprop.0+0xa65>
    a1d1:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    a1d7:	0f 84 a6 02 00 00    	je     a483 <fwp_hof0.constprop.0+0x1263>
    a1dd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a1e2:	45 31 f6             	xor    %r14d,%r14d
    a1e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1ec:	00 00 00 00 
    a1f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a1f4:	4c 89 f2             	mov    %r14,%rdx
    a1f7:	49 83 c6 01          	add    $0x1,%r14
    a1fb:	48 85 c0             	test   %rax,%rax
    a1fe:	75 f0                	jne    a1f0 <fwp_hof0.constprop.0+0xfd0>
    a200:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a207:	ff ff 1f 
    a20a:	4c 39 f0             	cmp    %r14,%rax
    a20d:	0f 82 de 07 00 00    	jb     a9f1 <fwp_hof0.constprop.0+0x17d1>
    a213:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a21a:	00 
    a21b:	be 02 00 00 00       	mov    $0x2,%esi
    a220:	e8 2b b8 ff ff       	call   5a50 <fwp_heap_alloc>
    a225:	4d 39 f7             	cmp    %r14,%r15
    a228:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a22d:	49 89 c4             	mov    %rax,%r12
    a230:	4c 89 f0             	mov    %r14,%rax
    a233:	49 0f 46 c7          	cmovbe %r15,%rax
    a237:	4c 89 e1             	mov    %r12,%rcx
    a23a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a240:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a244:	48 83 c1 08          	add    $0x8,%rcx
    a248:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a24c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a250:	48 85 d2             	test   %rdx,%rdx
    a253:	75 eb                	jne    a240 <fwp_hof0.constprop.0+0x1020>
    a255:	48 85 c0             	test   %rax,%rax
    a258:	0f 84 37 02 00 00    	je     a495 <fwp_hof0.constprop.0+0x1275>
    a25e:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    a265:	00 
    a266:	e9 42 fa ff ff       	jmp    9cad <fwp_hof0.constprop.0+0xa8d>
    a26b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a270:	4c 39 fd             	cmp    %r15,%rbp
    a273:	0f 84 e7 f1 ff ff    	je     9460 <fwp_hof0.constprop.0+0x240>
    a279:	48 8b 1d 70 8e 01 00 	mov    0x18e70(%rip),%rbx        # 230f0 <fwp_tapes>
    a280:	e9 7e f2 ff ff       	jmp    9503 <fwp_hof0.constprop.0+0x2e3>
    a285:	0f 1f 00             	nopl   (%rax)
    a288:	48 83 3d f8 8d 01 00 	cmpq   $0x0,0x18df8(%rip)        # 23088 <fwp_tape_cached_bytes>
    a28f:	00 
    a290:	0f 84 b3 f2 ff ff    	je     9549 <fwp_hof0.constprop.0+0x329>
    a296:	66 0f 6f 0d 02 8e 01 	movdqa 0x18e02(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a29d:	00 
    a29e:	48 c7 05 df 8d 01 00 	movq   $0x0,0x18ddf(%rip)        # 23088 <fwp_tape_cached_bytes>
    a2a5:	00 00 00 00 
    a2a9:	0f 11 4d 20          	movups %xmm1,0x20(%rbp)
    a2ad:	48 8b 05 0c 8e 01 00 	mov    0x18e0c(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a2b4:	66 0f 6f 0d f4 8d 01 	movdqa 0x18df4(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    a2bb:	00 
    a2bc:	48 89 45 40          	mov    %rax,0x40(%rbp)
    a2c0:	48 8b 05 01 8e 01 00 	mov    0x18e01(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    a2c7:	0f 11 4d 30          	movups %xmm1,0x30(%rbp)
    a2cb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a2cf:	48 89 45 18          	mov    %rax,0x18(%rbp)
    a2d3:	48 8b 05 f6 8d 01 00 	mov    0x18df6(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    a2da:	0f 29 0d bf 8d 01 00 	movaps %xmm1,0x18dbf(%rip)        # 230a0 <fwp_tape_workspace>
    a2e1:	48 89 45 48          	mov    %rax,0x48(%rbp)
    a2e5:	0f 29 0d c4 8d 01 00 	movaps %xmm1,0x18dc4(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a2ec:	48 c7 05 d9 8d 01 00 	movq   $0x0,0x18dd9(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    a2f3:	00 00 00 00 
    a2f7:	0f 29 0d c2 8d 01 00 	movaps %xmm1,0x18dc2(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a2fe:	e9 46 f2 ff ff       	jmp    9549 <fwp_hof0.constprop.0+0x329>
    a303:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a308:	66 85 c0             	test   %ax,%ax
    a30b:	0f 84 58 f8 ff ff    	je     9b69 <fwp_hof0.constprop.0+0x949>
    a311:	0f 1f 40 00          	nopl   0x0(%rax)
    a315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a31c:	00 00 00 00 
    a320:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a327:	ff ff 1f 
    a32a:	4c 39 f0             	cmp    %r14,%rax
    a32d:	0f 82 b2 06 00 00    	jb     a9e5 <fwp_hof0.constprop.0+0x17c5>
    a333:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a33a:	00 
    a33b:	be 01 00 00 00       	mov    $0x1,%esi
    a340:	e8 0b b7 ff ff       	call   5a50 <fwp_heap_alloc>
    a345:	4c 89 30             	mov    %r14,(%rax)
    a348:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a34f:	48 89 c5             	mov    %rax,%rbp
    a352:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a357:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a35e:	48 c1 e2 10          	shl    $0x10,%rdx
    a362:	48 39 d0             	cmp    %rdx,%rax
    a365:	73 57                	jae    a3be <fwp_hof0.constprop.0+0x119e>
    a367:	48 89 c2             	mov    %rax,%rdx
    a36a:	48 c1 ea 10          	shr    $0x10,%rdx
    a36e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a372:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a379:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a37d:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    a381:	48 85 db             	test   %rbx,%rbx
    a384:	74 38                	je     a3be <fwp_hof0.constprop.0+0x119e>
    a386:	0f b6 31             	movzbl (%rcx),%esi
    a389:	40 80 fe 02          	cmp    $0x2,%sil
    a38d:	0f 84 a5 03 00 00    	je     a738 <fwp_hof0.constprop.0+0x1518>
    a393:	40 80 fe 01          	cmp    $0x1,%sil
    a397:	75 25                	jne    a3be <fwp_hof0.constprop.0+0x119e>
    a399:	8b 71 18             	mov    0x18(%rcx),%esi
    a39c:	0f b7 c0             	movzwl %ax,%eax
    a39f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a3a2:	48 0f af c6          	imul   %rsi,%rax
    a3a6:	48 c1 e8 20          	shr    $0x20,%rax
    a3aa:	48 39 c8             	cmp    %rcx,%rax
    a3ad:	73 0f                	jae    a3be <fwp_hof0.constprop.0+0x119e>
    a3af:	48 01 c3             	add    %rax,%rbx
    a3b2:	80 3b ff             	cmpb   $0xff,(%rbx)
    a3b5:	0f 84 8f 03 00 00    	je     a74a <fwp_hof0.constprop.0+0x152a>
    a3bb:	c6 03 01             	movb   $0x1,(%rbx)
    a3be:	4c 89 ff             	mov    %r15,%rdi
    a3c1:	e9 b6 f7 ff ff       	jmp    9b7c <fwp_hof0.constprop.0+0x95c>
    a3c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a3cd:	00 00 00 
    a3d0:	48 89 d7             	mov    %rdx,%rdi
    a3d3:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    a3d8:	e8 33 af ff ff       	call   5310 <fwp_rc_forget_slot>
    a3dd:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    a3e2:	e9 29 fa ff ff       	jmp    9e10 <fwp_hof0.constprop.0+0xbf0>
    a3e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a3ee:	00 00 
    a3f0:	48 c1 e1 10          	shl    $0x10,%rcx
    a3f4:	bf 08 00 00 00       	mov    $0x8,%edi
    a3f9:	48 09 f1             	or     %rsi,%rcx
    a3fc:	be 02 00 00 00       	mov    $0x2,%esi
    a401:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a406:	e8 45 b6 ff ff       	call   5a50 <fwp_heap_alloc>
    a40b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a412:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a419:	48 89 c5             	mov    %rax,%rbp
    a41c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a423:	48 c1 e2 10          	shl    $0x10,%rdx
    a427:	48 39 d0             	cmp    %rdx,%rax
    a42a:	0f 83 80 00 00 00    	jae    a4b0 <fwp_hof0.constprop.0+0x1290>
    a430:	48 89 c2             	mov    %rax,%rdx
    a433:	48 c1 ea 10          	shr    $0x10,%rdx
    a437:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a43b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a442:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a446:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a44a:	4d 85 ff             	test   %r15,%r15
    a44d:	0f 84 e0 f2 ff ff    	je     9733 <fwp_hof0.constprop.0+0x513>
    a453:	0f b6 32             	movzbl (%rdx),%esi
    a456:	45 31 e4             	xor    %r12d,%r12d
    a459:	40 80 fe 02          	cmp    $0x2,%sil
    a45d:	0f 85 49 f2 ff ff    	jne    96ac <fwp_hof0.constprop.0+0x48c>
    a463:	66 85 c0             	test   %ax,%ax
    a466:	0f 85 6d f2 ff ff    	jne    96d9 <fwp_hof0.constprop.0+0x4b9>
    a46c:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a470:	0f 85 5f f2 ff ff    	jne    96d5 <fwp_hof0.constprop.0+0x4b5>
    a476:	4c 89 ff             	mov    %r15,%rdi
    a479:	e8 92 ae ff ff       	call   5310 <fwp_rc_forget_slot>
    a47e:	e9 52 f2 ff ff       	jmp    96d5 <fwp_hof0.constprop.0+0x4b5>
    a483:	be 02 00 00 00       	mov    $0x2,%esi
    a488:	bf 08 00 00 00       	mov    $0x8,%edi
    a48d:	e8 be b5 ff ff       	call   5a50 <fwp_heap_alloc>
    a492:	49 89 c4             	mov    %rax,%r12
    a495:	45 31 f6             	xor    %r14d,%r14d
    a498:	e9 77 fa ff ff       	jmp    9f14 <fwp_hof0.constprop.0+0xcf4>
    a49d:	0f 1f 00             	nopl   (%rax)
    a4a0:	4d 85 e4             	test   %r12,%r12
    a4a3:	0f 85 35 f2 ff ff    	jne    96de <fwp_hof0.constprop.0+0x4be>
    a4a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a4b0:	31 db                	xor    %ebx,%ebx
    a4b2:	e9 e7 f2 ff ff       	jmp    979e <fwp_hof0.constprop.0+0x57e>
    a4b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4be:	00 00 
    a4c0:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    a4c5:	45 31 c0             	xor    %r8d,%r8d
    a4c8:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a4cd:	48 83 e8 01          	sub    $0x1,%rax
    a4d1:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    a4d6:	41 0f 90 c0          	seto   %r8b
    a4da:	e9 10 ee ff ff       	jmp    92ef <fwp_hof0.constprop.0+0xcf>
    a4df:	90                   	nop
    a4e0:	4d 8d 57 01          	lea    0x1(%r15),%r10
    a4e4:	4c 39 d2             	cmp    %r10,%rdx
    a4e7:	7c 42                	jl     a52b <fwp_hof0.constprop.0+0x130b>
    a4e9:	48 85 c9             	test   %rcx,%rcx
    a4ec:	0f 84 23 05 00 00    	je     aa15 <fwp_hof0.constprop.0+0x17f5>
    a4f2:	48 89 cf             	mov    %rcx,%rdi
    a4f5:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    a4fc:	00 
    a4fd:	31 f6                	xor    %esi,%esi
    a4ff:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    a504:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a509:	e8 b2 8f ff ff       	call   34c0 <memset@plt>
    a50e:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    a514:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a51a:	48 89 c1             	mov    %rax,%rcx
    a51d:	e9 03 f4 ff ff       	jmp    9925 <fwp_hof0.constprop.0+0x705>
    a522:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a528:	49 89 da             	mov    %rbx,%r10
    a52b:	48 85 d2             	test   %rdx,%rdx
    a52e:	49 0f 44 d2          	cmove  %r10,%rdx
    a532:	eb 21                	jmp    a555 <fwp_hof0.constprop.0+0x1335>
    a534:	90                   	nop
    a535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a53c:	00 00 00 00 
    a540:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    a544:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    a54b:	4c 89 d0             	mov    %r10,%rax
    a54e:	48 0f 4c c6          	cmovl  %rsi,%rax
    a552:	48 89 c2             	mov    %rax,%rdx
    a555:	4c 39 d2             	cmp    %r10,%rdx
    a558:	7c e6                	jl     a540 <fwp_hof0.constprop.0+0x1320>
    a55a:	4c 89 54 24 50       	mov    %r10,0x50(%rsp)
    a55f:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    a564:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    a569:	48 85 c9             	test   %rcx,%rcx
    a56c:	0f 84 ee 01 00 00    	je     a760 <fwp_hof0.constprop.0+0x1540>
    a572:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    a579:	00 
    a57a:	48 89 cf             	mov    %rcx,%rdi
    a57d:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a582:	e8 49 90 ff ff       	call   35d0 <realloc@plt>
    a587:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a58c:	4c 8b 54 24 50       	mov    0x50(%rsp),%r10
    a591:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    a597:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    a59d:	48 89 c1             	mov    %rax,%rcx
    a5a0:	48 85 c9             	test   %rcx,%rcx
    a5a3:	0f 84 63 04 00 00    	je     aa0c <fwp_hof0.constprop.0+0x17ec>
    a5a9:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    a5b0:	00 
    a5b1:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
    a5b8:	00 
    a5b9:	4d 85 d2             	test   %r10,%r10
    a5bc:	0f 85 56 03 00 00    	jne    a918 <fwp_hof0.constprop.0+0x16f8>
    a5c2:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    a5c9:	4d 85 e4             	test   %r12,%r12
    a5cc:	0f 88 67 f3 ff ff    	js     9939 <fwp_hof0.constprop.0+0x719>
    a5d2:	45 89 e7             	mov    %r12d,%r15d
    a5d5:	e9 4b f3 ff ff       	jmp    9925 <fwp_hof0.constprop.0+0x705>
    a5da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5e0:	48 8d 3d 99 c4 ff ff 	lea    -0x3b67(%rip),%rdi        # 6a80 <fwp_tape_finish>
    a5e7:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    a5ed:	e8 0e 3b 00 00       	call   e100 <atexit>
    a5f2:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    a5f8:	85 c0                	test   %eax,%eax
    a5fa:	0f 85 b3 04 00 00    	jne    aab3 <fwp_hof0.constprop.0+0x1893>
    a600:	c7 05 56 8a 00 00 01 	movl   $0x1,0x8a56(%rip)        # 13060 <registered_finish.1>
    a607:	00 00 00 
    a60a:	e9 0e ee ff ff       	jmp    941d <fwp_hof0.constprop.0+0x1fd>
    a60f:	90                   	nop
    a610:	66 85 c0             	test   %ax,%ax
    a613:	0f 85 97 f9 ff ff    	jne    9fb0 <fwp_hof0.constprop.0+0xd90>
    a619:	e9 6d f9 ff ff       	jmp    9f8b <fwp_hof0.constprop.0+0xd6b>
    a61e:	66 90                	xchg   %ax,%ax
    a620:	66 85 c0             	test   %ax,%ax
    a623:	0f 85 9f ed ff ff    	jne    93c8 <fwp_hof0.constprop.0+0x1a8>
    a629:	e9 86 ed ff ff       	jmp    93b4 <fwp_hof0.constprop.0+0x194>
    a62e:	66 90                	xchg   %ax,%ax
    a630:	48 39 d3             	cmp    %rdx,%rbx
    a633:	0f 8f ef fe ff ff    	jg     a528 <fwp_hof0.constprop.0+0x1308>
    a639:	48 85 db             	test   %rbx,%rbx
    a63c:	74 12                	je     a650 <fwp_hof0.constprop.0+0x1430>
    a63e:	48 85 c9             	test   %rcx,%rcx
    a641:	0f 84 ce 03 00 00    	je     aa15 <fwp_hof0.constprop.0+0x17f5>
    a647:	48 85 db             	test   %rbx,%rbx
    a64a:	0f 85 c5 02 00 00    	jne    a915 <fwp_hof0.constprop.0+0x16f5>
    a650:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    a657:	e9 dd f2 ff ff       	jmp    9939 <fwp_hof0.constprop.0+0x719>
    a65c:	0f 1f 40 00          	nopl   0x0(%rax)
    a660:	66 85 c0             	test   %ax,%ax
    a663:	0f 85 53 f4 ff ff    	jne    9abc <fwp_hof0.constprop.0+0x89c>
    a669:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a66d:	0f 85 45 f4 ff ff    	jne    9ab8 <fwp_hof0.constprop.0+0x898>
    a673:	48 89 ef             	mov    %rbp,%rdi
    a676:	e8 95 ac ff ff       	call   5310 <fwp_rc_forget_slot>
    a67b:	e9 38 f4 ff ff       	jmp    9ab8 <fwp_hof0.constprop.0+0x898>
    a680:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    a685:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a68a:	e9 85 f8 ff ff       	jmp    9f14 <fwp_hof0.constprop.0+0xcf4>
    a68f:	90                   	nop
    a690:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a695:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a69c:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a6a3:	48 8b 58 10          	mov    0x10(%rax),%rbx
    a6a7:	48 29 c8             	sub    %rcx,%rax
    a6aa:	48 c1 e2 10          	shl    $0x10,%rdx
    a6ae:	48 39 d0             	cmp    %rdx,%rax
    a6b1:	73 67                	jae    a71a <fwp_hof0.constprop.0+0x14fa>
    a6b3:	48 89 c7             	mov    %rax,%rdi
    a6b6:	48 c1 ef 10          	shr    $0x10,%rdi
    a6ba:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    a6be:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a6c2:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a6c6:	48 85 ff             	test   %rdi,%rdi
    a6c9:	74 4f                	je     a71a <fwp_hof0.constprop.0+0x14fa>
    a6cb:	44 0f b6 06          	movzbl (%rsi),%r8d
    a6cf:	41 80 f8 02          	cmp    $0x2,%r8b
    a6d3:	0f 84 8d 01 00 00    	je     a866 <fwp_hof0.constprop.0+0x1646>
    a6d9:	41 80 f8 01          	cmp    $0x1,%r8b
    a6dd:	75 3b                	jne    a71a <fwp_hof0.constprop.0+0x14fa>
    a6df:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a6e3:	0f b7 c0             	movzwl %ax,%eax
    a6e6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a6e9:	49 0f af c0          	imul   %r8,%rax
    a6ed:	48 c1 e8 20          	shr    $0x20,%rax
    a6f1:	48 39 f0             	cmp    %rsi,%rax
    a6f4:	73 24                	jae    a71a <fwp_hof0.constprop.0+0x14fa>
    a6f6:	48 01 c7             	add    %rax,%rdi
    a6f9:	80 3f 01             	cmpb   $0x1,(%rdi)
    a6fc:	75 1c                	jne    a71a <fwp_hof0.constprop.0+0x14fa>
    a6fe:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a703:	e8 48 ae ff ff       	call   5550 <fwp_mem_free>
    a708:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a70f:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a716:	48 c1 e2 10          	shl    $0x10,%rdx
    a71a:	48 89 d8             	mov    %rbx,%rax
    a71d:	48 29 c8             	sub    %rcx,%rax
    a720:	48 39 d0             	cmp    %rdx,%rax
    a723:	0f 83 87 f8 ff ff    	jae    9fb0 <fwp_hof0.constprop.0+0xd90>
    a729:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    a72e:	e9 0f f8 ff ff       	jmp    9f42 <fwp_hof0.constprop.0+0xd22>
    a733:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a738:	66 85 c0             	test   %ax,%ax
    a73b:	0f 85 7d fc ff ff    	jne    a3be <fwp_hof0.constprop.0+0x119e>
    a741:	80 3b ff             	cmpb   $0xff,(%rbx)
    a744:	0f 85 71 fc ff ff    	jne    a3bb <fwp_hof0.constprop.0+0x119b>
    a74a:	48 89 df             	mov    %rbx,%rdi
    a74d:	e8 be ab ff ff       	call   5310 <fwp_rc_forget_slot>
    a752:	e9 64 fc ff ff       	jmp    a3bb <fwp_hof0.constprop.0+0x119b>
    a757:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a75e:	00 00 
    a760:	48 89 d7             	mov    %rdx,%rdi
    a763:	be 08 00 00 00       	mov    $0x8,%esi
    a768:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a76d:	e8 ae 8d ff ff       	call   3520 <calloc@plt>
    a772:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    a778:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    a77e:	4c 8b 54 24 50       	mov    0x50(%rsp),%r10
    a783:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a788:	48 89 c1             	mov    %rax,%rcx
    a78b:	e9 10 fe ff ff       	jmp    a5a0 <fwp_hof0.constprop.0+0x1380>
    a790:	66 85 c0             	test   %ax,%ax
    a793:	0f 85 40 eb ff ff    	jne    92d9 <fwp_hof0.constprop.0+0xb9>
    a799:	e9 27 eb ff ff       	jmp    92c5 <fwp_hof0.constprop.0+0xa5>
    a79e:	66 90                	xchg   %ax,%ax
    a7a0:	66 85 c0             	test   %ax,%ax
    a7a3:	0f 85 d7 f9 ff ff    	jne    a180 <fwp_hof0.constprop.0+0xf60>
    a7a9:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a7ad:	84 c0                	test   %al,%al
    a7af:	0f 84 cb f9 ff ff    	je     a180 <fwp_hof0.constprop.0+0xf60>
    a7b5:	3c 01                	cmp    $0x1,%al
    a7b7:	0f 85 af f9 ff ff    	jne    a16c <fwp_hof0.constprop.0+0xf4c>
    a7bd:	48 89 df             	mov    %rbx,%rdi
    a7c0:	e8 8b ad ff ff       	call   5550 <fwp_mem_free>
    a7c5:	e9 b6 f9 ff ff       	jmp    a180 <fwp_hof0.constprop.0+0xf60>
    a7ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7d0:	66 85 c0             	test   %ax,%ax
    a7d3:	0f 85 f0 f8 ff ff    	jne    a0c9 <fwp_hof0.constprop.0+0xea9>
    a7d9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a7dd:	0f 85 e2 f8 ff ff    	jne    a0c5 <fwp_hof0.constprop.0+0xea5>
    a7e3:	4c 89 ff             	mov    %r15,%rdi
    a7e6:	e8 25 ab ff ff       	call   5310 <fwp_rc_forget_slot>
    a7eb:	e9 d5 f8 ff ff       	jmp    a0c5 <fwp_hof0.constprop.0+0xea5>
    a7f0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a7f4:	e9 16 ec ff ff       	jmp    940f <fwp_hof0.constprop.0+0x1ef>
    a7f9:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a7fd:	48 85 c0             	test   %rax,%rax
    a800:	0f 88 7d fc ff ff    	js     a483 <fwp_hof0.constprop.0+0x1263>
    a806:	49 8b b5 d8 13 00 00 	mov    0x13d8(%r13),%rsi
    a80d:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a812:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    a819:	48 c1 e6 10          	shl    $0x10,%rsi
    a81d:	48 39 f1             	cmp    %rsi,%rcx
    a820:	0f 83 5d fc ff ff    	jae    a483 <fwp_hof0.constprop.0+0x1263>
    a826:	48 89 ce             	mov    %rcx,%rsi
    a829:	48 c1 ee 10          	shr    $0x10,%rsi
    a82d:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a831:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    a838:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a83c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a840:	48 85 ff             	test   %rdi,%rdi
    a843:	0f 84 3a fc ff ff    	je     a483 <fwp_hof0.constprop.0+0x1263>
    a849:	48 0f ba f0 3f       	btr    $0x3f,%rax
    a84e:	49 89 c7             	mov    %rax,%r15
    a851:	e9 ff f3 ff ff       	jmp    9c55 <fwp_hof0.constprop.0+0xa35>
    a856:	be 68 00 00 00       	mov    $0x68,%esi
    a85b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    a861:	e9 35 ec ff ff       	jmp    949b <fwp_hof0.constprop.0+0x27b>
    a866:	66 85 c0             	test   %ax,%ax
    a869:	0f 85 ab fe ff ff    	jne    a71a <fwp_hof0.constprop.0+0x14fa>
    a86f:	e9 85 fe ff ff       	jmp    a6f9 <fwp_hof0.constprop.0+0x14d9>
    a874:	48 89 ea             	mov    %rbp,%rdx
    a877:	48 c1 ea 11          	shr    $0x11,%rdx
    a87b:	48 31 ea             	xor    %rbp,%rdx
    a87e:	48 89 d0             	mov    %rdx,%rax
    a881:	48 c1 e8 09          	shr    $0x9,%rax
    a885:	48 31 c2             	xor    %rax,%rdx
    a888:	0f b6 d2             	movzbl %dl,%edx
    a88b:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a892:	00 
    a893:	48 85 c0             	test   %rax,%rax
    a896:	75 11                	jne    a8a9 <fwp_hof0.constprop.0+0x1689>
    a898:	eb 6f                	jmp    a909 <fwp_hof0.constprop.0+0x16e9>
    a89a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a8a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a8a4:	48 85 c0             	test   %rax,%rax
    a8a7:	74 60                	je     a909 <fwp_hof0.constprop.0+0x16e9>
    a8a9:	48 89 c2             	mov    %rax,%rdx
    a8ac:	48 39 28             	cmp    %rbp,(%rax)
    a8af:	75 ef                	jne    a8a0 <fwp_hof0.constprop.0+0x1680>
    a8b1:	48 8b 58 08          	mov    0x8(%rax),%rbx
    a8b5:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    a8b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a8bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a8c4:	0f 85 e6 f6 ff ff    	jne    9fb0 <fwp_hof0.constprop.0+0xd90>
    a8ca:	48 89 ef             	mov    %rbp,%rdi
    a8cd:	e8 3e aa ff ff       	call   5310 <fwp_rc_forget_slot>
    a8d2:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a8d6:	e9 d5 f6 ff ff       	jmp    9fb0 <fwp_hof0.constprop.0+0xd90>
    a8db:	e8 10 a9 ff ff       	call   51f0 <fwp_rc_wide_dup>
    a8e0:	e9 e3 ea ff ff       	jmp    93c8 <fwp_hof0.constprop.0+0x1a8>
    a8e5:	48 89 e8             	mov    %rbp,%rax
    a8e8:	48 c1 e8 11          	shr    $0x11,%rax
    a8ec:	48 31 e8             	xor    %rbp,%rax
    a8ef:	48 89 c2             	mov    %rax,%rdx
    a8f2:	48 c1 ea 09          	shr    $0x9,%rdx
    a8f6:	48 31 d0             	xor    %rdx,%rax
    a8f9:	0f b6 d0             	movzbl %al,%edx
    a8fc:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a903:	00 
    a904:	48 85 c0             	test   %rax,%rax
    a907:	75 60                	jne    a969 <fwp_hof0.constprop.0+0x1749>
    a909:	48 8d 3d 90 4e 00 00 	lea    0x4e90(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    a910:	e8 8b 98 ff ff       	call   41a0 <fwp_trap>
    a915:	49 89 da             	mov    %rbx,%r10
    a918:	48 89 cf             	mov    %rcx,%rdi
    a91b:	31 f6                	xor    %esi,%esi
    a91d:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a922:	49 8d 6a ff          	lea    -0x1(%r10),%rbp
    a926:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    a92d:	00 
    a92e:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    a933:	e8 88 8b ff ff       	call   34c0 <memset@plt>
    a938:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    a93e:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a944:	48 89 c1             	mov    %rax,%rcx
    a947:	e9 7d fc ff ff       	jmp    a5c9 <fwp_hof0.constprop.0+0x13a9>
    a94c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a953:	00 00 
    a955:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a95c:	00 00 00 00 
    a960:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a964:	48 85 c0             	test   %rax,%rax
    a967:	74 a0                	je     a909 <fwp_hof0.constprop.0+0x16e9>
    a969:	48 89 c2             	mov    %rax,%rdx
    a96c:	48 3b 28             	cmp    (%rax),%rbp
    a96f:	75 ef                	jne    a960 <fwp_hof0.constprop.0+0x1740>
    a971:	48 8b 58 08          	mov    0x8(%rax),%rbx
    a975:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    a979:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a97d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a984:	0f 85 f6 f7 ff ff    	jne    a180 <fwp_hof0.constprop.0+0xf60>
    a98a:	48 89 ef             	mov    %rbp,%rdi
    a98d:	e8 7e a9 ff ff       	call   5310 <fwp_rc_forget_slot>
    a992:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a996:	e9 e5 f7 ff ff       	jmp    a180 <fwp_hof0.constprop.0+0xf60>
    a99b:	e8 50 a8 ff ff       	call   51f0 <fwp_rc_wide_dup>
    a9a0:	e9 34 e9 ff ff       	jmp    92d9 <fwp_hof0.constprop.0+0xb9>
    a9a5:	45 31 ff             	xor    %r15d,%r15d
    a9a8:	e9 28 f4 ff ff       	jmp    9dd5 <fwp_hof0.constprop.0+0xbb5>
    a9ad:	48 8d 3d 14 4e 00 00 	lea    0x4e14(%rip),%rdi        # f7c8 <_IO_stdin_used+0x7c8>
    a9b4:	e8 e7 97 ff ff       	call   41a0 <fwp_trap>
    a9b9:	48 8d 3d 44 47 00 00 	lea    0x4744(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    a9c0:	e8 db 97 ff ff       	call   41a0 <fwp_trap>
    a9c5:	48 8d 3d d4 4e 00 00 	lea    0x4ed4(%rip),%rdi        # f8a0 <_IO_stdin_used+0x8a0>
    a9cc:	e8 cf 97 ff ff       	call   41a0 <fwp_trap>
    a9d1:	45 31 e4             	xor    %r12d,%r12d
    a9d4:	e9 bc fa ff ff       	jmp    a495 <fwp_hof0.constprop.0+0x1275>
    a9d9:	48 8d 3d de 47 00 00 	lea    0x47de(%rip),%rdi        # f1be <_IO_stdin_used+0x1be>
    a9e0:	e8 bb 97 ff ff       	call   41a0 <fwp_trap>
    a9e5:	48 8d 3d ec 47 00 00 	lea    0x47ec(%rip),%rdi        # f1d8 <_IO_stdin_used+0x1d8>
    a9ec:	e8 af 97 ff ff       	call   41a0 <fwp_trap>
    a9f1:	48 8d 3d 35 47 00 00 	lea    0x4735(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    a9f8:	e8 a3 97 ff ff       	call   41a0 <fwp_trap>
    a9fd:	0f 1f 00             	nopl   (%rax)
    aa00:	48 8d 3d c1 4e 00 00 	lea    0x4ec1(%rip),%rdi        # f8c8 <_IO_stdin_used+0x8c8>
    aa07:	e8 94 97 ff ff       	call   41a0 <fwp_trap>
    aa0c:	4d 85 d2             	test   %r10,%r10
    aa0f:	0f 84 ad fb ff ff    	je     a5c2 <fwp_hof0.constprop.0+0x13a2>
    aa15:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    aa1c:	00 
    aa1d:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    aa22:	48 89 05 cf a9 01 00 	mov    %rax,0x1a9cf(%rip)        # 253f8 <fwp_cleanups>
    aa29:	e8 02 a4 ff ff       	call   4e30 <fwp_tape_buffers_release>
    aa2e:	ba 13 00 00 00       	mov    $0x13,%edx
    aa33:	48 8b 0d 06 86 00 00 	mov    0x8606(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    aa3a:	be 01 00 00 00       	mov    $0x1,%esi
    aa3f:	48 8d 3d c2 45 00 00 	lea    0x45c2(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aa46:	e8 35 8c ff ff       	call   3680 <fwrite@plt>
    aa4b:	31 ff                	xor    %edi,%edi
    aa4d:	e8 6e 8b ff ff       	call   35c0 <fflush@plt>
    aa52:	bf 66 00 00 00       	mov    $0x66,%edi
    aa57:	e8 44 8c ff ff       	call   36a0 <_Exit@plt>
    aa5c:	48 8d 3d 0d 4e 00 00 	lea    0x4e0d(%rip),%rdi        # f870 <_IO_stdin_used+0x870>
    aa63:	e8 38 97 ff ff       	call   41a0 <fwp_trap>
    aa68:	48 8b 0d d1 85 00 00 	mov    0x85d1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    aa6f:	ba 13 00 00 00       	mov    $0x13,%edx
    aa74:	be 01 00 00 00       	mov    $0x1,%esi
    aa79:	48 8d 3d 88 45 00 00 	lea    0x4588(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aa80:	e8 fb 8b ff ff       	call   3680 <fwrite@plt>
    aa85:	31 ff                	xor    %edi,%edi
    aa87:	e8 34 8b ff ff       	call   35c0 <fflush@plt>
    aa8c:	bf 66 00 00 00       	mov    $0x66,%edi
    aa91:	e8 0a 8c ff ff       	call   36a0 <_Exit@plt>
    aa96:	48 8d 3d 73 4d 00 00 	lea    0x4d73(%rip),%rdi        # f810 <_IO_stdin_used+0x810>
    aa9d:	e8 fe 96 ff ff       	call   41a0 <fwp_trap>
    aaa2:	e8 b9 89 ff ff       	call   3460 <__stack_chk_fail@plt>
    aaa7:	48 8d 3d 3a 47 00 00 	lea    0x473a(%rip),%rdi        # f1e8 <_IO_stdin_used+0x1e8>
    aaae:	e8 ed 96 ff ff       	call   41a0 <fwp_trap>
    aab3:	48 8b 0d 86 85 00 00 	mov    0x8586(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    aaba:	ba 13 00 00 00       	mov    $0x13,%edx
    aabf:	be 01 00 00 00       	mov    $0x1,%esi
    aac4:	48 8d 3d 3d 45 00 00 	lea    0x453d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aacb:	e8 b0 8b ff ff       	call   3680 <fwrite@plt>
    aad0:	31 ff                	xor    %edi,%edi
    aad2:	e8 e9 8a ff ff       	call   35c0 <fflush@plt>
    aad7:	bf 66 00 00 00       	mov    $0x66,%edi
    aadc:	e8 bf 8b ff ff       	call   36a0 <_Exit@plt>
    aae1:	0f 1f 40 00          	nopl   0x0(%rax)
    aae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aaec:	00 00 00 00 

000000000000aaf0 <f0>:
    aaf0:	41 56                	push   %r14
    aaf2:	4c 8d 35 67 8c 01 00 	lea    0x18c67(%rip),%r14        # 23760 <fwp_heap>
    aaf9:	41 55                	push   %r13
    aafb:	41 54                	push   %r12
    aafd:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    ab03:	55                   	push   %rbp
    ab04:	53                   	push   %rbx
    ab05:	31 db                	xor    %ebx,%ebx
    ab07:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    ab0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ab15:	00 00 
    ab17:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    ab1e:	00 
    ab1f:	31 c0                	xor    %eax,%eax
    ab21:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    ab28:	00 
    ab29:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    ab30:	00 00 
    ab32:	66 48 0f 6e c0       	movq   %rax,%xmm0
    ab37:	48 8d 05 52 cd ff ff 	lea    -0x32ae(%rip),%rax        # 7890 <fwp_drop1>
    ab3e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    ab43:	48 8b 05 ae a8 01 00 	mov    0x1a8ae(%rip),%rax        # 253f8 <fwp_cleanups>
    ab4a:	48 89 25 a7 a8 01 00 	mov    %rsp,0x1a8a7(%rip)        # 253f8 <fwp_cleanups>
    ab51:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    ab55:	48 89 04 24          	mov    %rax,(%rsp)
    ab59:	48 8d 05 70 90 ff ff 	lea    -0x6f90(%rip),%rax        # 3bd0 <fwp_range_release>
    ab60:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ab65:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    ab6a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    ab6f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    ab74:	eb 47                	jmp    abbd <f0+0xcd>
    ab76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ab7d:	00 00 00 
    ab80:	80 f9 01             	cmp    $0x1,%cl
    ab83:	75 29                	jne    abae <f0+0xbe>
    ab85:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ab88:	0f b7 c0             	movzwl %ax,%eax
    ab8b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab8e:	48 0f af c1          	imul   %rcx,%rax
    ab92:	48 c1 e8 20          	shr    $0x20,%rax
    ab96:	48 39 d0             	cmp    %rdx,%rax
    ab99:	73 13                	jae    abae <f0+0xbe>
    ab9b:	49 01 c5             	add    %rax,%r13
    ab9e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    aba3:	0f 84 c7 27 00 00    	je     d370 <f0+0x2880>
    aba9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    abae:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    abb3:	49 83 ec 01          	sub    $0x1,%r12
    abb7:	0f 82 83 00 00 00    	jb     ac40 <f0+0x150>
    abbd:	48 89 ee             	mov    %rbp,%rsi
    abc0:	bf 01 00 00 00       	mov    $0x1,%edi
    abc5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    abcc:	00 
    abcd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    abd2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    abd9:	00 
    abda:	e8 91 af ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    abdf:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    abe6:	48 89 c3             	mov    %rax,%rbx
    abe9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    abf0:	48 c1 e2 10          	shl    $0x10,%rdx
    abf4:	48 39 d0             	cmp    %rdx,%rax
    abf7:	73 b5                	jae    abae <f0+0xbe>
    abf9:	48 89 c2             	mov    %rax,%rdx
    abfc:	48 c1 ea 10          	shr    $0x10,%rdx
    ac00:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac04:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    ac0b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac0f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    ac13:	4d 85 ed             	test   %r13,%r13
    ac16:	74 96                	je     abae <f0+0xbe>
    ac18:	0f b6 0a             	movzbl (%rdx),%ecx
    ac1b:	80 f9 02             	cmp    $0x2,%cl
    ac1e:	0f 85 5c ff ff ff    	jne    ab80 <f0+0x90>
    ac24:	66 85 c0             	test   %ax,%ax
    ac27:	0f 84 71 ff ff ff    	je     ab9e <f0+0xae>
    ac2d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    ac32:	49 83 ec 01          	sub    $0x1,%r12
    ac36:	73 85                	jae    abbd <f0+0xcd>
    ac38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ac3f:	00 
    ac40:	48 8b 04 24          	mov    (%rsp),%rax
    ac44:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    ac49:	bf 01 00 00 00       	mov    $0x1,%edi
    ac4e:	66 0f 6f 05 fa 4e 00 	movdqa 0x4efa(%rip),%xmm0        # fb50 <msg.4+0xd0>
    ac55:	00 
    ac56:	48 89 05 9b a7 01 00 	mov    %rax,0x1a79b(%rip)        # 253f8 <fwp_cleanups>
    ac5d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    ac62:	e8 09 af ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ac67:	48 8b 15 ca 9e 01 00 	mov    0x19eca(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    ac6e:	49 89 c5             	mov    %rax,%r13
    ac71:	48 2b 05 98 9e 01 00 	sub    0x19e98(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    ac78:	48 c1 e2 10          	shl    $0x10,%rdx
    ac7c:	48 39 d0             	cmp    %rdx,%rax
    ac7f:	73 59                	jae    acda <f0+0x1ea>
    ac81:	48 89 c2             	mov    %rax,%rdx
    ac84:	48 c1 ea 10          	shr    $0x10,%rdx
    ac88:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac8c:	48 8b 15 c5 9e 01 00 	mov    0x19ec5(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    ac93:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac97:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ac9b:	4d 85 e4             	test   %r12,%r12
    ac9e:	74 3a                	je     acda <f0+0x1ea>
    aca0:	0f b6 0a             	movzbl (%rdx),%ecx
    aca3:	80 f9 02             	cmp    $0x2,%cl
    aca6:	0f 84 74 27 00 00    	je     d420 <f0+0x2930>
    acac:	80 f9 01             	cmp    $0x1,%cl
    acaf:	75 29                	jne    acda <f0+0x1ea>
    acb1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    acb4:	0f b7 c0             	movzwl %ax,%eax
    acb7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    acba:	48 0f af c1          	imul   %rcx,%rax
    acbe:	48 c1 e8 20          	shr    $0x20,%rax
    acc2:	48 39 d0             	cmp    %rdx,%rax
    acc5:	73 13                	jae    acda <f0+0x1ea>
    acc7:	49 01 c4             	add    %rax,%r12
    acca:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    accf:	0f 84 26 29 00 00    	je     d5fb <f0+0x2b0b>
    acd5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    acda:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    acdf:	bf 01 00 00 00       	mov    $0x1,%edi
    ace4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    ace9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    acf0:	00 f0 3f 
    acf3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    acf8:	e8 73 ae ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    acfd:	48 8b 15 34 9e 01 00 	mov    0x19e34(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    ad04:	49 89 c5             	mov    %rax,%r13
    ad07:	48 2b 05 02 9e 01 00 	sub    0x19e02(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    ad0e:	48 c1 e2 10          	shl    $0x10,%rdx
    ad12:	48 39 d0             	cmp    %rdx,%rax
    ad15:	73 59                	jae    ad70 <f0+0x280>
    ad17:	48 89 c2             	mov    %rax,%rdx
    ad1a:	48 c1 ea 10          	shr    $0x10,%rdx
    ad1e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad22:	48 8b 15 2f 9e 01 00 	mov    0x19e2f(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    ad29:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad2d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ad31:	4d 85 e4             	test   %r12,%r12
    ad34:	74 3a                	je     ad70 <f0+0x280>
    ad36:	0f b6 0a             	movzbl (%rdx),%ecx
    ad39:	80 f9 02             	cmp    $0x2,%cl
    ad3c:	0f 84 ce 26 00 00    	je     d410 <f0+0x2920>
    ad42:	80 f9 01             	cmp    $0x1,%cl
    ad45:	75 29                	jne    ad70 <f0+0x280>
    ad47:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad4a:	0f b7 c0             	movzwl %ax,%eax
    ad4d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad50:	48 0f af c1          	imul   %rcx,%rax
    ad54:	48 c1 e8 20          	shr    $0x20,%rax
    ad58:	48 39 d0             	cmp    %rdx,%rax
    ad5b:	73 13                	jae    ad70 <f0+0x280>
    ad5d:	49 01 c4             	add    %rax,%r12
    ad60:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ad65:	0f 84 9d 28 00 00    	je     d608 <f0+0x2b18>
    ad6b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ad70:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    ad75:	bf 01 00 00 00       	mov    $0x1,%edi
    ad7a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    ad7f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ad86:	33 f3 bf 
    ad89:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    ad8e:	e8 dd ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ad93:	48 8b 15 9e 9d 01 00 	mov    0x19d9e(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    ad9a:	49 89 c5             	mov    %rax,%r13
    ad9d:	48 2b 05 6c 9d 01 00 	sub    0x19d6c(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    ada4:	48 c1 e2 10          	shl    $0x10,%rdx
    ada8:	48 39 d0             	cmp    %rdx,%rax
    adab:	73 59                	jae    ae06 <f0+0x316>
    adad:	48 89 c2             	mov    %rax,%rdx
    adb0:	48 c1 ea 10          	shr    $0x10,%rdx
    adb4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    adb8:	48 8b 15 99 9d 01 00 	mov    0x19d99(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    adbf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    adc3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    adc7:	4d 85 e4             	test   %r12,%r12
    adca:	74 3a                	je     ae06 <f0+0x316>
    adcc:	0f b6 0a             	movzbl (%rdx),%ecx
    adcf:	80 f9 02             	cmp    $0x2,%cl
    add2:	0f 84 28 26 00 00    	je     d400 <f0+0x2910>
    add8:	80 f9 01             	cmp    $0x1,%cl
    addb:	75 29                	jne    ae06 <f0+0x316>
    addd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ade0:	0f b7 c0             	movzwl %ax,%eax
    ade3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ade6:	48 0f af c1          	imul   %rcx,%rax
    adea:	48 c1 e8 20          	shr    $0x20,%rax
    adee:	48 39 d0             	cmp    %rdx,%rax
    adf1:	73 13                	jae    ae06 <f0+0x316>
    adf3:	49 01 c4             	add    %rax,%r12
    adf6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    adfb:	0f 84 14 28 00 00    	je     d615 <f0+0x2b25>
    ae01:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ae06:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    ae0b:	bf 01 00 00 00       	mov    $0x1,%edi
    ae10:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    ae15:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ae1c:	00 f0 3f 
    ae1f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    ae24:	e8 47 ad ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ae29:	48 8b 15 08 9d 01 00 	mov    0x19d08(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    ae30:	49 89 c5             	mov    %rax,%r13
    ae33:	48 2b 05 d6 9c 01 00 	sub    0x19cd6(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    ae3a:	48 c1 e2 10          	shl    $0x10,%rdx
    ae3e:	48 39 d0             	cmp    %rdx,%rax
    ae41:	73 59                	jae    ae9c <f0+0x3ac>
    ae43:	48 89 c2             	mov    %rax,%rdx
    ae46:	48 c1 ea 10          	shr    $0x10,%rdx
    ae4a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae4e:	48 8b 15 03 9d 01 00 	mov    0x19d03(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    ae55:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae59:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ae5d:	4d 85 e4             	test   %r12,%r12
    ae60:	74 3a                	je     ae9c <f0+0x3ac>
    ae62:	0f b6 0a             	movzbl (%rdx),%ecx
    ae65:	80 f9 02             	cmp    $0x2,%cl
    ae68:	0f 84 f2 25 00 00    	je     d460 <f0+0x2970>
    ae6e:	80 f9 01             	cmp    $0x1,%cl
    ae71:	75 29                	jne    ae9c <f0+0x3ac>
    ae73:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae76:	0f b7 c0             	movzwl %ax,%eax
    ae79:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae7c:	48 0f af c1          	imul   %rcx,%rax
    ae80:	48 c1 e8 20          	shr    $0x20,%rax
    ae84:	48 39 d0             	cmp    %rdx,%rax
    ae87:	73 13                	jae    ae9c <f0+0x3ac>
    ae89:	49 01 c4             	add    %rax,%r12
    ae8c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ae91:	0f 84 8b 27 00 00    	je     d622 <f0+0x2b32>
    ae97:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ae9c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    aea3:	33 f3 bf 
    aea6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aead:	00 
    aeae:	bf 01 00 00 00       	mov    $0x1,%edi
    aeb3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    aeba:	00 
    aebb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    aec2:	00 
    aec3:	e8 a8 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    aec8:	48 8b 15 69 9c 01 00 	mov    0x19c69(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    aecf:	49 89 c5             	mov    %rax,%r13
    aed2:	48 2b 05 37 9c 01 00 	sub    0x19c37(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    aed9:	48 c1 e2 10          	shl    $0x10,%rdx
    aedd:	48 39 d0             	cmp    %rdx,%rax
    aee0:	73 59                	jae    af3b <f0+0x44b>
    aee2:	48 89 c2             	mov    %rax,%rdx
    aee5:	48 c1 ea 10          	shr    $0x10,%rdx
    aee9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aeed:	48 8b 15 64 9c 01 00 	mov    0x19c64(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    aef4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aef8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aefc:	4d 85 e4             	test   %r12,%r12
    aeff:	74 3a                	je     af3b <f0+0x44b>
    af01:	0f b6 0a             	movzbl (%rdx),%ecx
    af04:	80 f9 02             	cmp    $0x2,%cl
    af07:	0f 84 43 25 00 00    	je     d450 <f0+0x2960>
    af0d:	80 f9 01             	cmp    $0x1,%cl
    af10:	75 29                	jne    af3b <f0+0x44b>
    af12:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af15:	0f b7 c0             	movzwl %ax,%eax
    af18:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af1b:	48 0f af c1          	imul   %rcx,%rax
    af1f:	48 c1 e8 20          	shr    $0x20,%rax
    af23:	48 39 d0             	cmp    %rdx,%rax
    af26:	73 13                	jae    af3b <f0+0x44b>
    af28:	49 01 c4             	add    %rax,%r12
    af2b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    af30:	0f 84 f9 26 00 00    	je     d62f <f0+0x2b3f>
    af36:	41 c6 04 24 01       	movb   $0x1,(%r12)
    af3b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    af42:	00 f0 3f 
    af45:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    af4c:	00 
    af4d:	bf 01 00 00 00       	mov    $0x1,%edi
    af52:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    af59:	00 
    af5a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    af61:	00 
    af62:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    af69:	33 f3 bf 
    af6c:	e8 ff ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af71:	48 89 c7             	mov    %rax,%rdi
    af74:	e8 e7 b4 ff ff       	call   6460 <fwp_rc_fresh>
    af79:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    af80:	00 
    af81:	bf 01 00 00 00       	mov    $0x1,%edi
    af86:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    af8d:	00 
    af8e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    af95:	00 
    af96:	e8 d5 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af9b:	48 89 c7             	mov    %rax,%rdi
    af9e:	e8 bd b4 ff ff       	call   6460 <fwp_rc_fresh>
    afa3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    afaa:	00 
    afab:	bf 01 00 00 00       	mov    $0x1,%edi
    afb0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    afb7:	00 
    afb8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    afbf:	00 
    afc0:	e8 ab ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    afc5:	48 89 c7             	mov    %rax,%rdi
    afc8:	e8 93 b4 ff ff       	call   6460 <fwp_rc_fresh>
    afcd:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    afd4:	00 
    afd5:	bf 01 00 00 00       	mov    $0x1,%edi
    afda:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    afe1:	00 
    afe2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    afe9:	00 
    afea:	e8 81 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    afef:	48 89 c7             	mov    %rax,%rdi
    aff2:	e8 69 b4 ff ff       	call   6460 <fwp_rc_fresh>
    aff7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    affe:	00 
    afff:	bf 01 00 00 00       	mov    $0x1,%edi
    b004:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b00b:	00 
    b00c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b013:	00 
    b014:	e8 57 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b019:	48 89 c7             	mov    %rax,%rdi
    b01c:	e8 3f b4 ff ff       	call   6460 <fwp_rc_fresh>
    b021:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b028:	00 
    b029:	bf 01 00 00 00       	mov    $0x1,%edi
    b02e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b035:	00 
    b036:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b03d:	00 
    b03e:	e8 2d ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b043:	48 89 c7             	mov    %rax,%rdi
    b046:	e8 15 b4 ff ff       	call   6460 <fwp_rc_fresh>
    b04b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b052:	00 
    b053:	bf 01 00 00 00       	mov    $0x1,%edi
    b058:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b05f:	00 
    b060:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b067:	00 
    b068:	e8 03 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b06d:	48 89 c7             	mov    %rax,%rdi
    b070:	e8 eb b3 ff ff       	call   6460 <fwp_rc_fresh>
    b075:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b07c:	00 
    b07d:	bf 01 00 00 00       	mov    $0x1,%edi
    b082:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b089:	00 
    b08a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b091:	00 
    b092:	e8 d9 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b097:	48 89 c7             	mov    %rax,%rdi
    b09a:	e8 c1 b3 ff ff       	call   6460 <fwp_rc_fresh>
    b09f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b0a6:	00 
    b0a7:	bf 01 00 00 00       	mov    $0x1,%edi
    b0ac:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b0b3:	00 
    b0b4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b0bb:	00 
    b0bc:	e8 af aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b0c1:	48 89 c7             	mov    %rax,%rdi
    b0c4:	e8 97 b3 ff ff       	call   6460 <fwp_rc_fresh>
    b0c9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b0d0:	00 
    b0d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b0d6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b0dd:	00 
    b0de:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b0e5:	00 
    b0e6:	e8 85 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b0eb:	48 89 c7             	mov    %rax,%rdi
    b0ee:	e8 6d b3 ff ff       	call   6460 <fwp_rc_fresh>
    b0f3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b0fa:	00 
    b0fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b100:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b107:	00 
    b108:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b10f:	00 
    b110:	e8 5b aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b115:	48 89 c7             	mov    %rax,%rdi
    b118:	e8 43 b3 ff ff       	call   6460 <fwp_rc_fresh>
    b11d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b124:	00 
    b125:	bf 01 00 00 00       	mov    $0x1,%edi
    b12a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b131:	00 
    b132:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b139:	00 
    b13a:	e8 31 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b13f:	48 89 c7             	mov    %rax,%rdi
    b142:	e8 19 b3 ff ff       	call   6460 <fwp_rc_fresh>
    b147:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b14e:	00 
    b14f:	bf 01 00 00 00       	mov    $0x1,%edi
    b154:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b15b:	00 
    b15c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b163:	00 
    b164:	e8 07 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b169:	48 89 c7             	mov    %rax,%rdi
    b16c:	e8 ef b2 ff ff       	call   6460 <fwp_rc_fresh>
    b171:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b178:	00 
    b179:	bf 01 00 00 00       	mov    $0x1,%edi
    b17e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b185:	00 
    b186:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b18d:	00 
    b18e:	e8 dd a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b193:	48 89 c7             	mov    %rax,%rdi
    b196:	e8 c5 b2 ff ff       	call   6460 <fwp_rc_fresh>
    b19b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b1a2:	00 
    b1a3:	bf 01 00 00 00       	mov    $0x1,%edi
    b1a8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b1af:	00 
    b1b0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b1b7:	00 
    b1b8:	e8 b3 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b1bd:	48 89 c7             	mov    %rax,%rdi
    b1c0:	e8 9b b2 ff ff       	call   6460 <fwp_rc_fresh>
    b1c5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b1cc:	00 
    b1cd:	bf 01 00 00 00       	mov    $0x1,%edi
    b1d2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b1d9:	00 
    b1da:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b1e1:	00 
    b1e2:	e8 89 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b1e7:	48 89 c7             	mov    %rax,%rdi
    b1ea:	e8 71 b2 ff ff       	call   6460 <fwp_rc_fresh>
    b1ef:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b1f6:	00 
    b1f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b1fc:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b203:	00 
    b204:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b20b:	00 
    b20c:	e8 5f a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b211:	48 89 c7             	mov    %rax,%rdi
    b214:	e8 47 b2 ff ff       	call   6460 <fwp_rc_fresh>
    b219:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b220:	00 
    b221:	bf 01 00 00 00       	mov    $0x1,%edi
    b226:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b22d:	00 
    b22e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b235:	00 
    b236:	e8 35 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b23b:	48 89 c7             	mov    %rax,%rdi
    b23e:	e8 1d b2 ff ff       	call   6460 <fwp_rc_fresh>
    b243:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b24a:	00 
    b24b:	bf 01 00 00 00       	mov    $0x1,%edi
    b250:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b257:	00 
    b258:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b25f:	00 
    b260:	e8 0b a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b265:	48 89 c7             	mov    %rax,%rdi
    b268:	e8 f3 b1 ff ff       	call   6460 <fwp_rc_fresh>
    b26d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b274:	00 
    b275:	bf 01 00 00 00       	mov    $0x1,%edi
    b27a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b281:	00 
    b282:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b289:	00 
    b28a:	e8 e1 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b28f:	48 89 c7             	mov    %rax,%rdi
    b292:	e8 c9 b1 ff ff       	call   6460 <fwp_rc_fresh>
    b297:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b29e:	00 
    b29f:	bf 01 00 00 00       	mov    $0x1,%edi
    b2a4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b2ab:	00 
    b2ac:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b2b3:	00 
    b2b4:	e8 b7 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b2b9:	48 89 c7             	mov    %rax,%rdi
    b2bc:	e8 9f b1 ff ff       	call   6460 <fwp_rc_fresh>
    b2c1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b2c8:	00 
    b2c9:	bf 01 00 00 00       	mov    $0x1,%edi
    b2ce:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b2d5:	00 
    b2d6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b2dd:	00 
    b2de:	e8 8d a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b2e3:	48 89 c7             	mov    %rax,%rdi
    b2e6:	e8 75 b1 ff ff       	call   6460 <fwp_rc_fresh>
    b2eb:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b2f2:	00 
    b2f3:	bf 01 00 00 00       	mov    $0x1,%edi
    b2f8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b2ff:	00 
    b300:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b307:	00 
    b308:	e8 63 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b30d:	48 89 c7             	mov    %rax,%rdi
    b310:	e8 4b b1 ff ff       	call   6460 <fwp_rc_fresh>
    b315:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b31c:	00 
    b31d:	bf 01 00 00 00       	mov    $0x1,%edi
    b322:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b329:	00 
    b32a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b331:	00 
    b332:	e8 39 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b337:	48 89 c7             	mov    %rax,%rdi
    b33a:	e8 21 b1 ff ff       	call   6460 <fwp_rc_fresh>
    b33f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b346:	00 
    b347:	bf 01 00 00 00       	mov    $0x1,%edi
    b34c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b353:	00 
    b354:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b35b:	00 
    b35c:	e8 0f a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b361:	48 89 c7             	mov    %rax,%rdi
    b364:	e8 f7 b0 ff ff       	call   6460 <fwp_rc_fresh>
    b369:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b370:	00 
    b371:	bf 01 00 00 00       	mov    $0x1,%edi
    b376:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b37d:	00 
    b37e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b385:	00 
    b386:	e8 e5 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b38b:	48 89 c7             	mov    %rax,%rdi
    b38e:	e8 cd b0 ff ff       	call   6460 <fwp_rc_fresh>
    b393:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b39a:	00 
    b39b:	bf 01 00 00 00       	mov    $0x1,%edi
    b3a0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b3a7:	00 
    b3a8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b3af:	00 
    b3b0:	e8 bb a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b3b5:	48 89 c7             	mov    %rax,%rdi
    b3b8:	e8 a3 b0 ff ff       	call   6460 <fwp_rc_fresh>
    b3bd:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b3c4:	00 
    b3c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b3ca:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b3d1:	00 
    b3d2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b3d9:	00 
    b3da:	e8 91 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b3df:	48 89 c7             	mov    %rax,%rdi
    b3e2:	e8 79 b0 ff ff       	call   6460 <fwp_rc_fresh>
    b3e7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b3ee:	00 
    b3ef:	bf 01 00 00 00       	mov    $0x1,%edi
    b3f4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b3fb:	00 
    b3fc:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b403:	00 
    b404:	e8 67 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b409:	48 89 c7             	mov    %rax,%rdi
    b40c:	e8 4f b0 ff ff       	call   6460 <fwp_rc_fresh>
    b411:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b418:	00 
    b419:	bf 01 00 00 00       	mov    $0x1,%edi
    b41e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b425:	00 
    b426:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b42d:	00 
    b42e:	e8 3d a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b433:	48 89 c7             	mov    %rax,%rdi
    b436:	e8 25 b0 ff ff       	call   6460 <fwp_rc_fresh>
    b43b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b442:	00 
    b443:	bf 01 00 00 00       	mov    $0x1,%edi
    b448:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b44f:	00 
    b450:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b457:	00 
    b458:	e8 13 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b45d:	48 89 c7             	mov    %rax,%rdi
    b460:	e8 fb af ff ff       	call   6460 <fwp_rc_fresh>
    b465:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b46c:	00 
    b46d:	bf 01 00 00 00       	mov    $0x1,%edi
    b472:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b479:	00 
    b47a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b481:	00 
    b482:	e8 e9 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b487:	48 89 c7             	mov    %rax,%rdi
    b48a:	e8 d1 af ff ff       	call   6460 <fwp_rc_fresh>
    b48f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b496:	00 
    b497:	bf 01 00 00 00       	mov    $0x1,%edi
    b49c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b4a3:	00 
    b4a4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b4ab:	00 
    b4ac:	e8 bf a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b4b1:	48 89 c7             	mov    %rax,%rdi
    b4b4:	e8 a7 af ff ff       	call   6460 <fwp_rc_fresh>
    b4b9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b4c0:	00 
    b4c1:	bf 01 00 00 00       	mov    $0x1,%edi
    b4c6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b4cd:	00 
    b4ce:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b4d5:	00 
    b4d6:	e8 95 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b4db:	48 89 c7             	mov    %rax,%rdi
    b4de:	e8 7d af ff ff       	call   6460 <fwp_rc_fresh>
    b4e3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b4ea:	00 
    b4eb:	bf 01 00 00 00       	mov    $0x1,%edi
    b4f0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b4f7:	00 
    b4f8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b4ff:	00 
    b500:	e8 6b a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b505:	48 89 c7             	mov    %rax,%rdi
    b508:	e8 53 af ff ff       	call   6460 <fwp_rc_fresh>
    b50d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b514:	00 
    b515:	bf 01 00 00 00       	mov    $0x1,%edi
    b51a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b521:	00 
    b522:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b529:	00 
    b52a:	e8 41 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b52f:	48 89 c7             	mov    %rax,%rdi
    b532:	e8 29 af ff ff       	call   6460 <fwp_rc_fresh>
    b537:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b53e:	00 
    b53f:	bf 01 00 00 00       	mov    $0x1,%edi
    b544:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b54b:	00 
    b54c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b553:	00 
    b554:	e8 17 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b559:	48 89 c7             	mov    %rax,%rdi
    b55c:	e8 ff ae ff ff       	call   6460 <fwp_rc_fresh>
    b561:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b568:	00 
    b569:	bf 01 00 00 00       	mov    $0x1,%edi
    b56e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b575:	00 
    b576:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b57d:	00 
    b57e:	e8 ed a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b583:	48 89 c7             	mov    %rax,%rdi
    b586:	e8 d5 ae ff ff       	call   6460 <fwp_rc_fresh>
    b58b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b592:	00 
    b593:	bf 01 00 00 00       	mov    $0x1,%edi
    b598:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b59f:	00 
    b5a0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b5a7:	00 
    b5a8:	e8 c3 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b5ad:	48 89 c7             	mov    %rax,%rdi
    b5b0:	e8 ab ae ff ff       	call   6460 <fwp_rc_fresh>
    b5b5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b5bc:	00 
    b5bd:	bf 01 00 00 00       	mov    $0x1,%edi
    b5c2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b5c9:	00 
    b5ca:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b5d1:	00 
    b5d2:	e8 99 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b5d7:	48 89 c7             	mov    %rax,%rdi
    b5da:	e8 81 ae ff ff       	call   6460 <fwp_rc_fresh>
    b5df:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    b5e6:	00 
    b5e7:	bf 01 00 00 00       	mov    $0x1,%edi
    b5ec:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    b5f3:	00 
    b5f4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    b5fb:	00 
    b5fc:	e8 6f a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b601:	48 89 c7             	mov    %rax,%rdi
    b604:	e8 57 ae ff ff       	call   6460 <fwp_rc_fresh>
    b609:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    b610:	00 
    b611:	bf 01 00 00 00       	mov    $0x1,%edi
    b616:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    b61d:	00 
    b61e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    b625:	00 
    b626:	e8 45 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b62b:	48 89 c7             	mov    %rax,%rdi
    b62e:	e8 2d ae ff ff       	call   6460 <fwp_rc_fresh>
    b633:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    b63a:	00 
    b63b:	bf 01 00 00 00       	mov    $0x1,%edi
    b640:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    b647:	00 
    b648:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    b64f:	00 
    b650:	e8 1b a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b655:	48 89 c7             	mov    %rax,%rdi
    b658:	e8 03 ae ff ff       	call   6460 <fwp_rc_fresh>
    b65d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    b664:	00 
    b665:	bf 01 00 00 00       	mov    $0x1,%edi
    b66a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    b671:	00 
    b672:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    b679:	00 
    b67a:	e8 f1 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b67f:	48 89 c7             	mov    %rax,%rdi
    b682:	e8 d9 ad ff ff       	call   6460 <fwp_rc_fresh>
    b687:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    b68e:	00 
    b68f:	bf 01 00 00 00       	mov    $0x1,%edi
    b694:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    b69b:	00 
    b69c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    b6a3:	00 
    b6a4:	e8 c7 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b6a9:	48 89 c7             	mov    %rax,%rdi
    b6ac:	e8 af ad ff ff       	call   6460 <fwp_rc_fresh>
    b6b1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    b6b8:	00 
    b6b9:	bf 01 00 00 00       	mov    $0x1,%edi
    b6be:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    b6c5:	00 
    b6c6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    b6cd:	00 
    b6ce:	e8 9d a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b6d3:	48 89 c7             	mov    %rax,%rdi
    b6d6:	e8 85 ad ff ff       	call   6460 <fwp_rc_fresh>
    b6db:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    b6e2:	00 
    b6e3:	bf 01 00 00 00       	mov    $0x1,%edi
    b6e8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    b6ef:	00 
    b6f0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    b6f7:	00 
    b6f8:	e8 73 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b6fd:	48 89 c7             	mov    %rax,%rdi
    b700:	e8 5b ad ff ff       	call   6460 <fwp_rc_fresh>
    b705:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    b70c:	00 
    b70d:	bf 01 00 00 00       	mov    $0x1,%edi
    b712:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    b719:	00 
    b71a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    b721:	00 
    b722:	e8 49 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b727:	48 89 c7             	mov    %rax,%rdi
    b72a:	e8 31 ad ff ff       	call   6460 <fwp_rc_fresh>
    b72f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    b736:	00 
    b737:	bf 01 00 00 00       	mov    $0x1,%edi
    b73c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    b743:	00 
    b744:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    b74b:	00 
    b74c:	e8 1f a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b751:	48 89 c7             	mov    %rax,%rdi
    b754:	e8 07 ad ff ff       	call   6460 <fwp_rc_fresh>
    b759:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    b760:	00 
    b761:	bf 01 00 00 00       	mov    $0x1,%edi
    b766:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    b76d:	00 
    b76e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    b775:	00 
    b776:	e8 f5 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b77b:	48 89 c7             	mov    %rax,%rdi
    b77e:	e8 dd ac ff ff       	call   6460 <fwp_rc_fresh>
    b783:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    b78a:	00 
    b78b:	bf 01 00 00 00       	mov    $0x1,%edi
    b790:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    b797:	00 
    b798:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    b79f:	00 
    b7a0:	e8 cb a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b7a5:	48 89 c7             	mov    %rax,%rdi
    b7a8:	e8 b3 ac ff ff       	call   6460 <fwp_rc_fresh>
    b7ad:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    b7b4:	00 
    b7b5:	bf 01 00 00 00       	mov    $0x1,%edi
    b7ba:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    b7c1:	00 
    b7c2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    b7c9:	00 
    b7ca:	e8 a1 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b7cf:	48 89 c7             	mov    %rax,%rdi
    b7d2:	e8 89 ac ff ff       	call   6460 <fwp_rc_fresh>
    b7d7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    b7de:	00 
    b7df:	bf 01 00 00 00       	mov    $0x1,%edi
    b7e4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    b7eb:	00 
    b7ec:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    b7f3:	00 
    b7f4:	e8 77 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b7f9:	48 89 c7             	mov    %rax,%rdi
    b7fc:	e8 5f ac ff ff       	call   6460 <fwp_rc_fresh>
    b801:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    b808:	00 
    b809:	bf 01 00 00 00       	mov    $0x1,%edi
    b80e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    b815:	00 
    b816:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    b81d:	00 
    b81e:	e8 4d a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b823:	48 89 c7             	mov    %rax,%rdi
    b826:	e8 35 ac ff ff       	call   6460 <fwp_rc_fresh>
    b82b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    b832:	00 
    b833:	bf 01 00 00 00       	mov    $0x1,%edi
    b838:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    b83f:	00 
    b840:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    b847:	00 
    b848:	e8 23 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b84d:	48 89 c7             	mov    %rax,%rdi
    b850:	e8 0b ac ff ff       	call   6460 <fwp_rc_fresh>
    b855:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    b85c:	00 
    b85d:	bf 01 00 00 00       	mov    $0x1,%edi
    b862:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    b869:	00 
    b86a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    b871:	00 
    b872:	e8 f9 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b877:	48 89 c7             	mov    %rax,%rdi
    b87a:	e8 e1 ab ff ff       	call   6460 <fwp_rc_fresh>
    b87f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    b886:	00 
    b887:	bf 01 00 00 00       	mov    $0x1,%edi
    b88c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    b893:	00 
    b894:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    b89b:	00 
    b89c:	e8 cf a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b8a1:	48 89 c7             	mov    %rax,%rdi
    b8a4:	e8 b7 ab ff ff       	call   6460 <fwp_rc_fresh>
    b8a9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    b8b0:	00 
    b8b1:	bf 01 00 00 00       	mov    $0x1,%edi
    b8b6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    b8bd:	00 
    b8be:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    b8c5:	00 
    b8c6:	e8 a5 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b8cb:	48 89 c7             	mov    %rax,%rdi
    b8ce:	e8 8d ab ff ff       	call   6460 <fwp_rc_fresh>
    b8d3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    b8da:	00 
    b8db:	bf 01 00 00 00       	mov    $0x1,%edi
    b8e0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    b8e7:	00 
    b8e8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    b8ef:	00 
    b8f0:	e8 7b a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b8f5:	48 89 c7             	mov    %rax,%rdi
    b8f8:	e8 63 ab ff ff       	call   6460 <fwp_rc_fresh>
    b8fd:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    b904:	00 
    b905:	bf 01 00 00 00       	mov    $0x1,%edi
    b90a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    b911:	00 
    b912:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    b919:	00 
    b91a:	e8 51 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b91f:	48 89 c7             	mov    %rax,%rdi
    b922:	e8 39 ab ff ff       	call   6460 <fwp_rc_fresh>
    b927:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    b92e:	00 
    b92f:	bf 01 00 00 00       	mov    $0x1,%edi
    b934:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    b93b:	00 
    b93c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    b943:	00 
    b944:	e8 27 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b949:	48 89 c7             	mov    %rax,%rdi
    b94c:	e8 0f ab ff ff       	call   6460 <fwp_rc_fresh>
    b951:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    b958:	00 
    b959:	bf 01 00 00 00       	mov    $0x1,%edi
    b95e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    b965:	00 
    b966:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    b96d:	00 
    b96e:	e8 fd a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b973:	48 89 c7             	mov    %rax,%rdi
    b976:	e8 e5 aa ff ff       	call   6460 <fwp_rc_fresh>
    b97b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    b982:	00 
    b983:	bf 01 00 00 00       	mov    $0x1,%edi
    b988:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    b98f:	00 
    b990:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    b997:	00 
    b998:	e8 d3 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b99d:	48 89 c7             	mov    %rax,%rdi
    b9a0:	e8 bb aa ff ff       	call   6460 <fwp_rc_fresh>
    b9a5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    b9ac:	00 
    b9ad:	bf 01 00 00 00       	mov    $0x1,%edi
    b9b2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    b9b9:	00 
    b9ba:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    b9c1:	00 
    b9c2:	e8 a9 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9c7:	48 89 c7             	mov    %rax,%rdi
    b9ca:	e8 91 aa ff ff       	call   6460 <fwp_rc_fresh>
    b9cf:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    b9d6:	00 
    b9d7:	bf 01 00 00 00       	mov    $0x1,%edi
    b9dc:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    b9e3:	00 
    b9e4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    b9eb:	00 
    b9ec:	e8 7f a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9f1:	48 89 c7             	mov    %rax,%rdi
    b9f4:	e8 67 aa ff ff       	call   6460 <fwp_rc_fresh>
    b9f9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    ba00:	00 
    ba01:	bf 01 00 00 00       	mov    $0x1,%edi
    ba06:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    ba0d:	00 
    ba0e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    ba15:	00 
    ba16:	e8 55 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba1b:	48 89 c7             	mov    %rax,%rdi
    ba1e:	e8 3d aa ff ff       	call   6460 <fwp_rc_fresh>
    ba23:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    ba2a:	00 
    ba2b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba30:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    ba37:	00 
    ba38:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    ba3f:	00 
    ba40:	e8 2b a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba45:	48 89 c7             	mov    %rax,%rdi
    ba48:	e8 13 aa ff ff       	call   6460 <fwp_rc_fresh>
    ba4d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    ba54:	00 
    ba55:	bf 01 00 00 00       	mov    $0x1,%edi
    ba5a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    ba61:	00 
    ba62:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    ba69:	00 
    ba6a:	e8 01 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba6f:	48 89 c7             	mov    %rax,%rdi
    ba72:	e8 e9 a9 ff ff       	call   6460 <fwp_rc_fresh>
    ba77:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    ba7e:	00 
    ba7f:	bf 01 00 00 00       	mov    $0x1,%edi
    ba84:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    ba8b:	00 
    ba8c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    ba93:	00 
    ba94:	e8 d7 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba99:	48 89 c7             	mov    %rax,%rdi
    ba9c:	e8 bf a9 ff ff       	call   6460 <fwp_rc_fresh>
    baa1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    baa8:	00 
    baa9:	bf 01 00 00 00       	mov    $0x1,%edi
    baae:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    bab5:	00 
    bab6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    babd:	00 
    babe:	e8 ad a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bac3:	48 89 c7             	mov    %rax,%rdi
    bac6:	e8 95 a9 ff ff       	call   6460 <fwp_rc_fresh>
    bacb:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    bad2:	00 
    bad3:	bf 01 00 00 00       	mov    $0x1,%edi
    bad8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    badf:	00 
    bae0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    bae7:	00 
    bae8:	e8 83 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    baed:	48 89 c7             	mov    %rax,%rdi
    baf0:	e8 6b a9 ff ff       	call   6460 <fwp_rc_fresh>
    baf5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    bafc:	00 
    bafd:	bf 01 00 00 00       	mov    $0x1,%edi
    bb02:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    bb09:	00 
    bb0a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    bb11:	00 
    bb12:	e8 59 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb17:	48 89 c7             	mov    %rax,%rdi
    bb1a:	e8 41 a9 ff ff       	call   6460 <fwp_rc_fresh>
    bb1f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    bb26:	00 
    bb27:	bf 01 00 00 00       	mov    $0x1,%edi
    bb2c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    bb33:	00 
    bb34:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    bb3b:	00 
    bb3c:	e8 2f a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb41:	48 89 c7             	mov    %rax,%rdi
    bb44:	e8 17 a9 ff ff       	call   6460 <fwp_rc_fresh>
    bb49:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    bb50:	00 
    bb51:	bf 01 00 00 00       	mov    $0x1,%edi
    bb56:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    bb5d:	00 
    bb5e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    bb65:	00 
    bb66:	e8 05 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb6b:	48 89 c7             	mov    %rax,%rdi
    bb6e:	e8 ed a8 ff ff       	call   6460 <fwp_rc_fresh>
    bb73:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    bb7a:	00 
    bb7b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb80:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    bb87:	00 
    bb88:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    bb8f:	00 
    bb90:	e8 db 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb95:	48 89 c7             	mov    %rax,%rdi
    bb98:	e8 c3 a8 ff ff       	call   6460 <fwp_rc_fresh>
    bb9d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    bba4:	00 
    bba5:	bf 01 00 00 00       	mov    $0x1,%edi
    bbaa:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    bbb1:	00 
    bbb2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    bbb9:	00 
    bbba:	e8 b1 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bbbf:	48 89 c7             	mov    %rax,%rdi
    bbc2:	e8 99 a8 ff ff       	call   6460 <fwp_rc_fresh>
    bbc7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    bbce:	00 
    bbcf:	bf 01 00 00 00       	mov    $0x1,%edi
    bbd4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    bbdb:	00 
    bbdc:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    bbe3:	00 
    bbe4:	e8 87 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bbe9:	48 89 c7             	mov    %rax,%rdi
    bbec:	e8 6f a8 ff ff       	call   6460 <fwp_rc_fresh>
    bbf1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    bbf8:	00 
    bbf9:	bf 01 00 00 00       	mov    $0x1,%edi
    bbfe:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    bc05:	00 
    bc06:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    bc0d:	00 
    bc0e:	e8 5d 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc13:	48 89 c7             	mov    %rax,%rdi
    bc16:	e8 45 a8 ff ff       	call   6460 <fwp_rc_fresh>
    bc1b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    bc22:	00 
    bc23:	bf 01 00 00 00       	mov    $0x1,%edi
    bc28:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    bc2f:	00 
    bc30:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    bc37:	00 
    bc38:	e8 33 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc3d:	48 89 c7             	mov    %rax,%rdi
    bc40:	e8 1b a8 ff ff       	call   6460 <fwp_rc_fresh>
    bc45:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    bc4c:	00 
    bc4d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc52:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    bc59:	00 
    bc5a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    bc61:	00 
    bc62:	e8 09 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc67:	48 89 c7             	mov    %rax,%rdi
    bc6a:	e8 f1 a7 ff ff       	call   6460 <fwp_rc_fresh>
    bc6f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    bc76:	00 
    bc77:	bf 01 00 00 00       	mov    $0x1,%edi
    bc7c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    bc83:	00 
    bc84:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    bc8b:	00 
    bc8c:	e8 df 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc91:	48 89 c7             	mov    %rax,%rdi
    bc94:	e8 c7 a7 ff ff       	call   6460 <fwp_rc_fresh>
    bc99:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    bca0:	00 
    bca1:	bf 01 00 00 00       	mov    $0x1,%edi
    bca6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    bcad:	00 
    bcae:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    bcb5:	00 
    bcb6:	e8 b5 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bcbb:	48 89 c7             	mov    %rax,%rdi
    bcbe:	e8 9d a7 ff ff       	call   6460 <fwp_rc_fresh>
    bcc3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    bcca:	00 
    bccb:	bf 01 00 00 00       	mov    $0x1,%edi
    bcd0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    bcd7:	00 
    bcd8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    bcdf:	00 
    bce0:	e8 8b 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bce5:	48 89 c7             	mov    %rax,%rdi
    bce8:	e8 73 a7 ff ff       	call   6460 <fwp_rc_fresh>
    bced:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    bcf4:	00 
    bcf5:	bf 01 00 00 00       	mov    $0x1,%edi
    bcfa:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    bd01:	00 
    bd02:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    bd09:	00 
    bd0a:	e8 61 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd0f:	48 89 c7             	mov    %rax,%rdi
    bd12:	e8 49 a7 ff ff       	call   6460 <fwp_rc_fresh>
    bd17:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    bd1e:	00 
    bd1f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd24:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    bd2b:	00 
    bd2c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    bd33:	00 
    bd34:	e8 37 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd39:	48 89 c7             	mov    %rax,%rdi
    bd3c:	e8 1f a7 ff ff       	call   6460 <fwp_rc_fresh>
    bd41:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    bd48:	00 
    bd49:	bf 01 00 00 00       	mov    $0x1,%edi
    bd4e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    bd55:	00 
    bd56:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    bd5d:	00 
    bd5e:	e8 0d 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd63:	48 89 c7             	mov    %rax,%rdi
    bd66:	e8 f5 a6 ff ff       	call   6460 <fwp_rc_fresh>
    bd6b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    bd72:	00 
    bd73:	bf 01 00 00 00       	mov    $0x1,%edi
    bd78:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    bd7f:	00 
    bd80:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    bd87:	00 
    bd88:	e8 e3 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd8d:	48 89 c7             	mov    %rax,%rdi
    bd90:	e8 cb a6 ff ff       	call   6460 <fwp_rc_fresh>
    bd95:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    bd9c:	00 
    bd9d:	bf 01 00 00 00       	mov    $0x1,%edi
    bda2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    bda9:	00 
    bdaa:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    bdb1:	00 
    bdb2:	e8 b9 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bdb7:	48 89 c7             	mov    %rax,%rdi
    bdba:	e8 a1 a6 ff ff       	call   6460 <fwp_rc_fresh>
    bdbf:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    bdc6:	00 
    bdc7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdcc:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    bdd3:	00 
    bdd4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    bddb:	00 
    bddc:	e8 8f 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bde1:	48 89 c7             	mov    %rax,%rdi
    bde4:	e8 77 a6 ff ff       	call   6460 <fwp_rc_fresh>
    bde9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    bdf0:	00 
    bdf1:	bf 01 00 00 00       	mov    $0x1,%edi
    bdf6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    bdfd:	00 
    bdfe:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    be05:	00 
    be06:	e8 65 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    be0b:	48 89 c7             	mov    %rax,%rdi
    be0e:	e8 4d a6 ff ff       	call   6460 <fwp_rc_fresh>
    be13:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    be1a:	00 
    be1b:	bf 01 00 00 00       	mov    $0x1,%edi
    be20:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    be27:	00 
    be28:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    be2f:	00 
    be30:	e8 3b 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    be35:	48 8b 15 fc 8c 01 00 	mov    0x18cfc(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    be3c:	49 89 c5             	mov    %rax,%r13
    be3f:	48 2b 05 ca 8c 01 00 	sub    0x18cca(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    be46:	48 c1 e2 10          	shl    $0x10,%rdx
    be4a:	48 39 d0             	cmp    %rdx,%rax
    be4d:	73 59                	jae    bea8 <f0+0x13b8>
    be4f:	48 89 c2             	mov    %rax,%rdx
    be52:	48 c1 ea 10          	shr    $0x10,%rdx
    be56:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be5a:	48 8b 15 f7 8c 01 00 	mov    0x18cf7(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    be61:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be65:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    be69:	4d 85 e4             	test   %r12,%r12
    be6c:	74 3a                	je     bea8 <f0+0x13b8>
    be6e:	0f b6 0a             	movzbl (%rdx),%ecx
    be71:	80 f9 02             	cmp    $0x2,%cl
    be74:	0f 84 c6 15 00 00    	je     d440 <f0+0x2950>
    be7a:	80 f9 01             	cmp    $0x1,%cl
    be7d:	75 29                	jne    bea8 <f0+0x13b8>
    be7f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be82:	0f b7 c0             	movzwl %ax,%eax
    be85:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be88:	48 0f af c1          	imul   %rcx,%rax
    be8c:	48 c1 e8 20          	shr    $0x20,%rax
    be90:	48 39 d0             	cmp    %rdx,%rax
    be93:	73 13                	jae    bea8 <f0+0x13b8>
    be95:	49 01 c4             	add    %rax,%r12
    be98:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    be9d:	0f 84 99 17 00 00    	je     d63c <f0+0x2b4c>
    bea3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bea8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    beaf:	33 f3 bf 
    beb2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    beb9:	00 
    beba:	bf 01 00 00 00       	mov    $0x1,%edi
    bebf:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    bec6:	00 
    bec7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    bece:	00 
    becf:	e8 9c 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bed4:	48 8b 15 5d 8c 01 00 	mov    0x18c5d(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    bedb:	49 89 c5             	mov    %rax,%r13
    bede:	48 2b 05 2b 8c 01 00 	sub    0x18c2b(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    bee5:	48 c1 e2 10          	shl    $0x10,%rdx
    bee9:	48 39 d0             	cmp    %rdx,%rax
    beec:	73 59                	jae    bf47 <f0+0x1457>
    beee:	48 89 c2             	mov    %rax,%rdx
    bef1:	48 c1 ea 10          	shr    $0x10,%rdx
    bef5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bef9:	48 8b 15 58 8c 01 00 	mov    0x18c58(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    bf00:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf04:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf08:	4d 85 e4             	test   %r12,%r12
    bf0b:	74 3a                	je     bf47 <f0+0x1457>
    bf0d:	0f b6 0a             	movzbl (%rdx),%ecx
    bf10:	80 f9 02             	cmp    $0x2,%cl
    bf13:	0f 84 17 15 00 00    	je     d430 <f0+0x2940>
    bf19:	80 f9 01             	cmp    $0x1,%cl
    bf1c:	75 29                	jne    bf47 <f0+0x1457>
    bf1e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf21:	0f b7 c0             	movzwl %ax,%eax
    bf24:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf27:	48 0f af c1          	imul   %rcx,%rax
    bf2b:	48 c1 e8 20          	shr    $0x20,%rax
    bf2f:	48 39 d0             	cmp    %rdx,%rax
    bf32:	73 13                	jae    bf47 <f0+0x1457>
    bf34:	49 01 c4             	add    %rax,%r12
    bf37:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf3c:	0f 84 07 17 00 00    	je     d649 <f0+0x2b59>
    bf42:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf47:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bf4e:	00 f0 3f 
    bf51:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    bf58:	00 
    bf59:	bf 01 00 00 00       	mov    $0x1,%edi
    bf5e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    bf65:	00 
    bf66:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    bf6d:	00 
    bf6e:	e8 fd 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bf73:	48 8b 15 be 8b 01 00 	mov    0x18bbe(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    bf7a:	49 89 c5             	mov    %rax,%r13
    bf7d:	48 2b 05 8c 8b 01 00 	sub    0x18b8c(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    bf84:	48 c1 e2 10          	shl    $0x10,%rdx
    bf88:	48 39 d0             	cmp    %rdx,%rax
    bf8b:	73 59                	jae    bfe6 <f0+0x14f6>
    bf8d:	48 89 c2             	mov    %rax,%rdx
    bf90:	48 c1 ea 10          	shr    $0x10,%rdx
    bf94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf98:	48 8b 15 b9 8b 01 00 	mov    0x18bb9(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    bf9f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bfa3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bfa7:	4d 85 e4             	test   %r12,%r12
    bfaa:	74 3a                	je     bfe6 <f0+0x14f6>
    bfac:	0f b6 0a             	movzbl (%rdx),%ecx
    bfaf:	80 f9 02             	cmp    $0x2,%cl
    bfb2:	0f 84 28 15 00 00    	je     d4e0 <f0+0x29f0>
    bfb8:	80 f9 01             	cmp    $0x1,%cl
    bfbb:	75 29                	jne    bfe6 <f0+0x14f6>
    bfbd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bfc0:	0f b7 c0             	movzwl %ax,%eax
    bfc3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bfc6:	48 0f af c1          	imul   %rcx,%rax
    bfca:	48 c1 e8 20          	shr    $0x20,%rax
    bfce:	48 39 d0             	cmp    %rdx,%rax
    bfd1:	73 13                	jae    bfe6 <f0+0x14f6>
    bfd3:	49 01 c4             	add    %rax,%r12
    bfd6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bfdb:	0f 84 75 16 00 00    	je     d656 <f0+0x2b66>
    bfe1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bfe6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bfed:	33 f3 bf 
    bff0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    bff7:	00 
    bff8:	bf 01 00 00 00       	mov    $0x1,%edi
    bffd:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c004:	00 
    c005:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c00c:	00 
    c00d:	e8 5e 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c012:	48 8b 15 1f 8b 01 00 	mov    0x18b1f(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c019:	49 89 c5             	mov    %rax,%r13
    c01c:	48 2b 05 ed 8a 01 00 	sub    0x18aed(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c023:	48 c1 e2 10          	shl    $0x10,%rdx
    c027:	48 39 d0             	cmp    %rdx,%rax
    c02a:	73 59                	jae    c085 <f0+0x1595>
    c02c:	48 89 c2             	mov    %rax,%rdx
    c02f:	48 c1 ea 10          	shr    $0x10,%rdx
    c033:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c037:	48 8b 15 1a 8b 01 00 	mov    0x18b1a(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c03e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c042:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c046:	4d 85 e4             	test   %r12,%r12
    c049:	74 3a                	je     c085 <f0+0x1595>
    c04b:	0f b6 0a             	movzbl (%rdx),%ecx
    c04e:	80 f9 02             	cmp    $0x2,%cl
    c051:	0f 84 79 14 00 00    	je     d4d0 <f0+0x29e0>
    c057:	80 f9 01             	cmp    $0x1,%cl
    c05a:	75 29                	jne    c085 <f0+0x1595>
    c05c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c05f:	0f b7 c0             	movzwl %ax,%eax
    c062:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c065:	48 0f af c1          	imul   %rcx,%rax
    c069:	48 c1 e8 20          	shr    $0x20,%rax
    c06d:	48 39 d0             	cmp    %rdx,%rax
    c070:	73 13                	jae    c085 <f0+0x1595>
    c072:	49 01 c4             	add    %rax,%r12
    c075:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c07a:	0f 84 e3 15 00 00    	je     d663 <f0+0x2b73>
    c080:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c085:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c08c:	00 f0 3f 
    c08f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c096:	00 
    c097:	bf 01 00 00 00       	mov    $0x1,%edi
    c09c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c0a3:	00 
    c0a4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c0ab:	00 
    c0ac:	e8 bf 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c0b1:	48 8b 15 80 8a 01 00 	mov    0x18a80(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c0b8:	49 89 c5             	mov    %rax,%r13
    c0bb:	48 2b 05 4e 8a 01 00 	sub    0x18a4e(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c0c2:	48 c1 e2 10          	shl    $0x10,%rdx
    c0c6:	48 39 d0             	cmp    %rdx,%rax
    c0c9:	73 59                	jae    c124 <f0+0x1634>
    c0cb:	48 89 c2             	mov    %rax,%rdx
    c0ce:	48 c1 ea 10          	shr    $0x10,%rdx
    c0d2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c0d6:	48 8b 15 7b 8a 01 00 	mov    0x18a7b(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c0dd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c0e1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c0e5:	4d 85 e4             	test   %r12,%r12
    c0e8:	74 3a                	je     c124 <f0+0x1634>
    c0ea:	0f b6 0a             	movzbl (%rdx),%ecx
    c0ed:	80 f9 02             	cmp    $0x2,%cl
    c0f0:	0f 84 ca 13 00 00    	je     d4c0 <f0+0x29d0>
    c0f6:	80 f9 01             	cmp    $0x1,%cl
    c0f9:	75 29                	jne    c124 <f0+0x1634>
    c0fb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0fe:	0f b7 c0             	movzwl %ax,%eax
    c101:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c104:	48 0f af c1          	imul   %rcx,%rax
    c108:	48 c1 e8 20          	shr    $0x20,%rax
    c10c:	48 39 d0             	cmp    %rdx,%rax
    c10f:	73 13                	jae    c124 <f0+0x1634>
    c111:	49 01 c4             	add    %rax,%r12
    c114:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c119:	0f 84 51 15 00 00    	je     d670 <f0+0x2b80>
    c11f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c124:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c12b:	33 f3 bf 
    c12e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c135:	00 
    c136:	bf 01 00 00 00       	mov    $0x1,%edi
    c13b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c142:	00 
    c143:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c14a:	00 
    c14b:	e8 20 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c150:	48 8b 15 e1 89 01 00 	mov    0x189e1(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c157:	49 89 c5             	mov    %rax,%r13
    c15a:	48 2b 05 af 89 01 00 	sub    0x189af(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c161:	48 c1 e2 10          	shl    $0x10,%rdx
    c165:	48 39 d0             	cmp    %rdx,%rax
    c168:	73 59                	jae    c1c3 <f0+0x16d3>
    c16a:	48 89 c2             	mov    %rax,%rdx
    c16d:	48 c1 ea 10          	shr    $0x10,%rdx
    c171:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c175:	48 8b 15 dc 89 01 00 	mov    0x189dc(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c17c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c180:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c184:	4d 85 e4             	test   %r12,%r12
    c187:	74 3a                	je     c1c3 <f0+0x16d3>
    c189:	0f b6 0a             	movzbl (%rdx),%ecx
    c18c:	80 f9 02             	cmp    $0x2,%cl
    c18f:	0f 84 1b 13 00 00    	je     d4b0 <f0+0x29c0>
    c195:	80 f9 01             	cmp    $0x1,%cl
    c198:	75 29                	jne    c1c3 <f0+0x16d3>
    c19a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c19d:	0f b7 c0             	movzwl %ax,%eax
    c1a0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c1a3:	48 0f af c1          	imul   %rcx,%rax
    c1a7:	48 c1 e8 20          	shr    $0x20,%rax
    c1ab:	48 39 d0             	cmp    %rdx,%rax
    c1ae:	73 13                	jae    c1c3 <f0+0x16d3>
    c1b0:	49 01 c4             	add    %rax,%r12
    c1b3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c1b8:	0f 84 bf 14 00 00    	je     d67d <f0+0x2b8d>
    c1be:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c1c3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c1ca:	00 f0 3f 
    c1cd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c1d4:	00 
    c1d5:	bf 01 00 00 00       	mov    $0x1,%edi
    c1da:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c1e1:	00 
    c1e2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c1e9:	00 
    c1ea:	e8 81 99 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c1ef:	48 8b 15 42 89 01 00 	mov    0x18942(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c1f6:	49 89 c5             	mov    %rax,%r13
    c1f9:	48 2b 05 10 89 01 00 	sub    0x18910(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c200:	48 c1 e2 10          	shl    $0x10,%rdx
    c204:	48 39 d0             	cmp    %rdx,%rax
    c207:	73 59                	jae    c262 <f0+0x1772>
    c209:	48 89 c2             	mov    %rax,%rdx
    c20c:	48 c1 ea 10          	shr    $0x10,%rdx
    c210:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c214:	48 8b 15 3d 89 01 00 	mov    0x1893d(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c21b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c21f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c223:	4d 85 e4             	test   %r12,%r12
    c226:	74 3a                	je     c262 <f0+0x1772>
    c228:	0f b6 0a             	movzbl (%rdx),%ecx
    c22b:	80 f9 02             	cmp    $0x2,%cl
    c22e:	0f 84 6c 12 00 00    	je     d4a0 <f0+0x29b0>
    c234:	80 f9 01             	cmp    $0x1,%cl
    c237:	75 29                	jne    c262 <f0+0x1772>
    c239:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c23c:	0f b7 c0             	movzwl %ax,%eax
    c23f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c242:	48 0f af c1          	imul   %rcx,%rax
    c246:	48 c1 e8 20          	shr    $0x20,%rax
    c24a:	48 39 d0             	cmp    %rdx,%rax
    c24d:	73 13                	jae    c262 <f0+0x1772>
    c24f:	49 01 c4             	add    %rax,%r12
    c252:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c257:	0f 84 2d 14 00 00    	je     d68a <f0+0x2b9a>
    c25d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c262:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c269:	33 f3 bf 
    c26c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c273:	00 
    c274:	bf 01 00 00 00       	mov    $0x1,%edi
    c279:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c280:	00 
    c281:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c288:	00 
    c289:	e8 e2 98 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c28e:	48 8b 15 a3 88 01 00 	mov    0x188a3(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c295:	49 89 c5             	mov    %rax,%r13
    c298:	48 2b 05 71 88 01 00 	sub    0x18871(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c29f:	48 c1 e2 10          	shl    $0x10,%rdx
    c2a3:	48 39 d0             	cmp    %rdx,%rax
    c2a6:	73 59                	jae    c301 <f0+0x1811>
    c2a8:	48 89 c2             	mov    %rax,%rdx
    c2ab:	48 c1 ea 10          	shr    $0x10,%rdx
    c2af:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c2b3:	48 8b 15 9e 88 01 00 	mov    0x1889e(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c2ba:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c2be:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c2c2:	4d 85 e4             	test   %r12,%r12
    c2c5:	74 3a                	je     c301 <f0+0x1811>
    c2c7:	0f b6 0a             	movzbl (%rdx),%ecx
    c2ca:	80 f9 02             	cmp    $0x2,%cl
    c2cd:	0f 84 bd 11 00 00    	je     d490 <f0+0x29a0>
    c2d3:	80 f9 01             	cmp    $0x1,%cl
    c2d6:	75 29                	jne    c301 <f0+0x1811>
    c2d8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c2db:	0f b7 c0             	movzwl %ax,%eax
    c2de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2e1:	48 0f af c1          	imul   %rcx,%rax
    c2e5:	48 c1 e8 20          	shr    $0x20,%rax
    c2e9:	48 39 d0             	cmp    %rdx,%rax
    c2ec:	73 13                	jae    c301 <f0+0x1811>
    c2ee:	49 01 c4             	add    %rax,%r12
    c2f1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2f6:	0f 84 9b 13 00 00    	je     d697 <f0+0x2ba7>
    c2fc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c301:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c308:	00 f0 3f 
    c30b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c312:	00 
    c313:	bf 01 00 00 00       	mov    $0x1,%edi
    c318:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c31f:	00 
    c320:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c327:	00 
    c328:	e8 43 98 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c32d:	48 8b 15 04 88 01 00 	mov    0x18804(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c334:	49 89 c5             	mov    %rax,%r13
    c337:	48 2b 05 d2 87 01 00 	sub    0x187d2(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c33e:	48 c1 e2 10          	shl    $0x10,%rdx
    c342:	48 39 d0             	cmp    %rdx,%rax
    c345:	73 59                	jae    c3a0 <f0+0x18b0>
    c347:	48 89 c2             	mov    %rax,%rdx
    c34a:	48 c1 ea 10          	shr    $0x10,%rdx
    c34e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c352:	48 8b 15 ff 87 01 00 	mov    0x187ff(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c359:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c35d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c361:	4d 85 e4             	test   %r12,%r12
    c364:	74 3a                	je     c3a0 <f0+0x18b0>
    c366:	0f b6 0a             	movzbl (%rdx),%ecx
    c369:	80 f9 02             	cmp    $0x2,%cl
    c36c:	0f 84 0e 11 00 00    	je     d480 <f0+0x2990>
    c372:	80 f9 01             	cmp    $0x1,%cl
    c375:	75 29                	jne    c3a0 <f0+0x18b0>
    c377:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c37a:	0f b7 c0             	movzwl %ax,%eax
    c37d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c380:	48 0f af c1          	imul   %rcx,%rax
    c384:	48 c1 e8 20          	shr    $0x20,%rax
    c388:	48 39 d0             	cmp    %rdx,%rax
    c38b:	73 13                	jae    c3a0 <f0+0x18b0>
    c38d:	49 01 c4             	add    %rax,%r12
    c390:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c395:	0f 84 09 13 00 00    	je     d6a4 <f0+0x2bb4>
    c39b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c3a0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c3a7:	33 f3 bf 
    c3aa:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c3b1:	00 
    c3b2:	bf 01 00 00 00       	mov    $0x1,%edi
    c3b7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c3be:	00 
    c3bf:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c3c6:	00 
    c3c7:	e8 a4 97 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c3cc:	48 8b 15 65 87 01 00 	mov    0x18765(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c3d3:	49 89 c5             	mov    %rax,%r13
    c3d6:	48 2b 05 33 87 01 00 	sub    0x18733(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c3dd:	48 c1 e2 10          	shl    $0x10,%rdx
    c3e1:	48 39 d0             	cmp    %rdx,%rax
    c3e4:	73 59                	jae    c43f <f0+0x194f>
    c3e6:	48 89 c2             	mov    %rax,%rdx
    c3e9:	48 c1 ea 10          	shr    $0x10,%rdx
    c3ed:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c3f1:	48 8b 15 60 87 01 00 	mov    0x18760(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c3f8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3fc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c400:	4d 85 e4             	test   %r12,%r12
    c403:	74 3a                	je     c43f <f0+0x194f>
    c405:	0f b6 0a             	movzbl (%rdx),%ecx
    c408:	80 f9 02             	cmp    $0x2,%cl
    c40b:	0f 84 5f 10 00 00    	je     d470 <f0+0x2980>
    c411:	80 f9 01             	cmp    $0x1,%cl
    c414:	75 29                	jne    c43f <f0+0x194f>
    c416:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c419:	0f b7 c0             	movzwl %ax,%eax
    c41c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c41f:	48 0f af c1          	imul   %rcx,%rax
    c423:	48 c1 e8 20          	shr    $0x20,%rax
    c427:	48 39 d0             	cmp    %rdx,%rax
    c42a:	73 13                	jae    c43f <f0+0x194f>
    c42c:	49 01 c4             	add    %rax,%r12
    c42f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c434:	0f 84 77 12 00 00    	je     d6b1 <f0+0x2bc1>
    c43a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c43f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c446:	00 f0 3f 
    c449:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c450:	00 
    c451:	bf 01 00 00 00       	mov    $0x1,%edi
    c456:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c45d:	00 
    c45e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c465:	00 
    c466:	e8 05 97 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c46b:	48 8b 15 c6 86 01 00 	mov    0x186c6(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c472:	49 89 c5             	mov    %rax,%r13
    c475:	48 2b 05 94 86 01 00 	sub    0x18694(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c47c:	48 c1 e2 10          	shl    $0x10,%rdx
    c480:	48 39 d0             	cmp    %rdx,%rax
    c483:	73 59                	jae    c4de <f0+0x19ee>
    c485:	48 89 c2             	mov    %rax,%rdx
    c488:	48 c1 ea 10          	shr    $0x10,%rdx
    c48c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c490:	48 8b 15 c1 86 01 00 	mov    0x186c1(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c497:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c49b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c49f:	4d 85 e4             	test   %r12,%r12
    c4a2:	74 3a                	je     c4de <f0+0x19ee>
    c4a4:	0f b6 0a             	movzbl (%rdx),%ecx
    c4a7:	80 f9 02             	cmp    $0x2,%cl
    c4aa:	0f 84 40 0f 00 00    	je     d3f0 <f0+0x2900>
    c4b0:	80 f9 01             	cmp    $0x1,%cl
    c4b3:	75 29                	jne    c4de <f0+0x19ee>
    c4b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c4b8:	0f b7 c0             	movzwl %ax,%eax
    c4bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c4be:	48 0f af c1          	imul   %rcx,%rax
    c4c2:	48 c1 e8 20          	shr    $0x20,%rax
    c4c6:	48 39 d0             	cmp    %rdx,%rax
    c4c9:	73 13                	jae    c4de <f0+0x19ee>
    c4cb:	49 01 c4             	add    %rax,%r12
    c4ce:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c4d3:	0f 84 e5 11 00 00    	je     d6be <f0+0x2bce>
    c4d9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4de:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c4e5:	33 f3 bf 
    c4e8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c4ef:	00 
    c4f0:	bf 01 00 00 00       	mov    $0x1,%edi
    c4f5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c4fc:	00 
    c4fd:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c504:	00 
    c505:	e8 66 96 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c50a:	48 8b 15 27 86 01 00 	mov    0x18627(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c511:	49 89 c5             	mov    %rax,%r13
    c514:	48 2b 05 f5 85 01 00 	sub    0x185f5(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c51b:	48 c1 e2 10          	shl    $0x10,%rdx
    c51f:	48 39 d0             	cmp    %rdx,%rax
    c522:	73 59                	jae    c57d <f0+0x1a8d>
    c524:	48 89 c2             	mov    %rax,%rdx
    c527:	48 c1 ea 10          	shr    $0x10,%rdx
    c52b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c52f:	48 8b 15 22 86 01 00 	mov    0x18622(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c536:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c53a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c53e:	4d 85 e4             	test   %r12,%r12
    c541:	74 3a                	je     c57d <f0+0x1a8d>
    c543:	0f b6 0a             	movzbl (%rdx),%ecx
    c546:	80 f9 02             	cmp    $0x2,%cl
    c549:	0f 84 91 0e 00 00    	je     d3e0 <f0+0x28f0>
    c54f:	80 f9 01             	cmp    $0x1,%cl
    c552:	75 29                	jne    c57d <f0+0x1a8d>
    c554:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c557:	0f b7 c0             	movzwl %ax,%eax
    c55a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c55d:	48 0f af c1          	imul   %rcx,%rax
    c561:	48 c1 e8 20          	shr    $0x20,%rax
    c565:	48 39 d0             	cmp    %rdx,%rax
    c568:	73 13                	jae    c57d <f0+0x1a8d>
    c56a:	49 01 c4             	add    %rax,%r12
    c56d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c572:	0f 84 53 11 00 00    	je     d6cb <f0+0x2bdb>
    c578:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c57d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c584:	00 f0 3f 
    c587:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c58e:	00 
    c58f:	bf 01 00 00 00       	mov    $0x1,%edi
    c594:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c59b:	00 
    c59c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c5a3:	00 
    c5a4:	e8 c7 95 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c5a9:	48 8b 15 88 85 01 00 	mov    0x18588(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c5b0:	49 89 c5             	mov    %rax,%r13
    c5b3:	48 2b 05 56 85 01 00 	sub    0x18556(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c5ba:	48 c1 e2 10          	shl    $0x10,%rdx
    c5be:	48 39 d0             	cmp    %rdx,%rax
    c5c1:	73 59                	jae    c61c <f0+0x1b2c>
    c5c3:	48 89 c2             	mov    %rax,%rdx
    c5c6:	48 c1 ea 10          	shr    $0x10,%rdx
    c5ca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5ce:	48 8b 15 83 85 01 00 	mov    0x18583(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c5d5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5d9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5dd:	4d 85 e4             	test   %r12,%r12
    c5e0:	74 3a                	je     c61c <f0+0x1b2c>
    c5e2:	0f b6 0a             	movzbl (%rdx),%ecx
    c5e5:	80 f9 02             	cmp    $0x2,%cl
    c5e8:	0f 84 e2 0d 00 00    	je     d3d0 <f0+0x28e0>
    c5ee:	80 f9 01             	cmp    $0x1,%cl
    c5f1:	75 29                	jne    c61c <f0+0x1b2c>
    c5f3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5f6:	0f b7 c0             	movzwl %ax,%eax
    c5f9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5fc:	48 0f af c1          	imul   %rcx,%rax
    c600:	48 c1 e8 20          	shr    $0x20,%rax
    c604:	48 39 d0             	cmp    %rdx,%rax
    c607:	73 13                	jae    c61c <f0+0x1b2c>
    c609:	49 01 c4             	add    %rax,%r12
    c60c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c611:	0f 84 c1 10 00 00    	je     d6d8 <f0+0x2be8>
    c617:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c61c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c623:	33 f3 bf 
    c626:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    c62d:	00 
    c62e:	bf 01 00 00 00       	mov    $0x1,%edi
    c633:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    c63a:	00 
    c63b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    c642:	00 
    c643:	e8 28 95 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c648:	48 8b 15 e9 84 01 00 	mov    0x184e9(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c64f:	49 89 c5             	mov    %rax,%r13
    c652:	48 2b 05 b7 84 01 00 	sub    0x184b7(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c659:	48 c1 e2 10          	shl    $0x10,%rdx
    c65d:	48 39 d0             	cmp    %rdx,%rax
    c660:	73 59                	jae    c6bb <f0+0x1bcb>
    c662:	48 89 c2             	mov    %rax,%rdx
    c665:	48 c1 ea 10          	shr    $0x10,%rdx
    c669:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c66d:	48 8b 15 e4 84 01 00 	mov    0x184e4(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c674:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c678:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c67c:	4d 85 e4             	test   %r12,%r12
    c67f:	74 3a                	je     c6bb <f0+0x1bcb>
    c681:	0f b6 0a             	movzbl (%rdx),%ecx
    c684:	80 f9 02             	cmp    $0x2,%cl
    c687:	0f 84 33 0d 00 00    	je     d3c0 <f0+0x28d0>
    c68d:	80 f9 01             	cmp    $0x1,%cl
    c690:	75 29                	jne    c6bb <f0+0x1bcb>
    c692:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c695:	0f b7 c0             	movzwl %ax,%eax
    c698:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c69b:	48 0f af c1          	imul   %rcx,%rax
    c69f:	48 c1 e8 20          	shr    $0x20,%rax
    c6a3:	48 39 d0             	cmp    %rdx,%rax
    c6a6:	73 13                	jae    c6bb <f0+0x1bcb>
    c6a8:	49 01 c4             	add    %rax,%r12
    c6ab:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6b0:	0f 84 2f 10 00 00    	je     d6e5 <f0+0x2bf5>
    c6b6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6bb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c6c2:	00 f0 3f 
    c6c5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    c6cc:	00 
    c6cd:	bf 01 00 00 00       	mov    $0x1,%edi
    c6d2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    c6d9:	00 
    c6da:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    c6e1:	00 
    c6e2:	e8 89 94 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c6e7:	48 8b 15 4a 84 01 00 	mov    0x1844a(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c6ee:	49 89 c5             	mov    %rax,%r13
    c6f1:	48 2b 05 18 84 01 00 	sub    0x18418(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c6f8:	48 c1 e2 10          	shl    $0x10,%rdx
    c6fc:	48 39 d0             	cmp    %rdx,%rax
    c6ff:	73 59                	jae    c75a <f0+0x1c6a>
    c701:	48 89 c2             	mov    %rax,%rdx
    c704:	48 c1 ea 10          	shr    $0x10,%rdx
    c708:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c70c:	48 8b 15 45 84 01 00 	mov    0x18445(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c713:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c717:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c71b:	4d 85 e4             	test   %r12,%r12
    c71e:	74 3a                	je     c75a <f0+0x1c6a>
    c720:	0f b6 0a             	movzbl (%rdx),%ecx
    c723:	80 f9 02             	cmp    $0x2,%cl
    c726:	0f 84 84 0c 00 00    	je     d3b0 <f0+0x28c0>
    c72c:	80 f9 01             	cmp    $0x1,%cl
    c72f:	75 29                	jne    c75a <f0+0x1c6a>
    c731:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c734:	0f b7 c0             	movzwl %ax,%eax
    c737:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c73a:	48 0f af c1          	imul   %rcx,%rax
    c73e:	48 c1 e8 20          	shr    $0x20,%rax
    c742:	48 39 d0             	cmp    %rdx,%rax
    c745:	73 13                	jae    c75a <f0+0x1c6a>
    c747:	49 01 c4             	add    %rax,%r12
    c74a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c74f:	0f 84 9d 0f 00 00    	je     d6f2 <f0+0x2c02>
    c755:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c75a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c761:	33 f3 bf 
    c764:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    c76b:	00 
    c76c:	bf 01 00 00 00       	mov    $0x1,%edi
    c771:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    c778:	00 
    c779:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    c780:	00 
    c781:	e8 ea 93 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c786:	48 8b 15 ab 83 01 00 	mov    0x183ab(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c78d:	49 89 c5             	mov    %rax,%r13
    c790:	48 2b 05 79 83 01 00 	sub    0x18379(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c797:	48 c1 e2 10          	shl    $0x10,%rdx
    c79b:	48 39 d0             	cmp    %rdx,%rax
    c79e:	73 59                	jae    c7f9 <f0+0x1d09>
    c7a0:	48 89 c2             	mov    %rax,%rdx
    c7a3:	48 c1 ea 10          	shr    $0x10,%rdx
    c7a7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7ab:	48 8b 15 a6 83 01 00 	mov    0x183a6(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c7b2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7b6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7ba:	4d 85 e4             	test   %r12,%r12
    c7bd:	74 3a                	je     c7f9 <f0+0x1d09>
    c7bf:	0f b6 0a             	movzbl (%rdx),%ecx
    c7c2:	80 f9 02             	cmp    $0x2,%cl
    c7c5:	0f 84 d5 0b 00 00    	je     d3a0 <f0+0x28b0>
    c7cb:	80 f9 01             	cmp    $0x1,%cl
    c7ce:	75 29                	jne    c7f9 <f0+0x1d09>
    c7d0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7d3:	0f b7 c0             	movzwl %ax,%eax
    c7d6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7d9:	48 0f af c1          	imul   %rcx,%rax
    c7dd:	48 c1 e8 20          	shr    $0x20,%rax
    c7e1:	48 39 d0             	cmp    %rdx,%rax
    c7e4:	73 13                	jae    c7f9 <f0+0x1d09>
    c7e6:	49 01 c4             	add    %rax,%r12
    c7e9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7ee:	0f 84 0b 0f 00 00    	je     d6ff <f0+0x2c0f>
    c7f4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7f9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c800:	00 f0 3f 
    c803:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    c80a:	00 
    c80b:	bf 01 00 00 00       	mov    $0x1,%edi
    c810:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    c817:	00 
    c818:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    c81f:	00 
    c820:	e8 4b 93 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c825:	48 8b 15 0c 83 01 00 	mov    0x1830c(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c82c:	49 89 c5             	mov    %rax,%r13
    c82f:	48 2b 05 da 82 01 00 	sub    0x182da(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c836:	48 c1 e2 10          	shl    $0x10,%rdx
    c83a:	48 39 d0             	cmp    %rdx,%rax
    c83d:	73 59                	jae    c898 <f0+0x1da8>
    c83f:	48 89 c2             	mov    %rax,%rdx
    c842:	48 c1 ea 10          	shr    $0x10,%rdx
    c846:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c84a:	48 8b 15 07 83 01 00 	mov    0x18307(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c851:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c855:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c859:	4d 85 e4             	test   %r12,%r12
    c85c:	74 3a                	je     c898 <f0+0x1da8>
    c85e:	0f b6 0a             	movzbl (%rdx),%ecx
    c861:	80 f9 02             	cmp    $0x2,%cl
    c864:	0f 84 26 0b 00 00    	je     d390 <f0+0x28a0>
    c86a:	80 f9 01             	cmp    $0x1,%cl
    c86d:	75 29                	jne    c898 <f0+0x1da8>
    c86f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c872:	0f b7 c0             	movzwl %ax,%eax
    c875:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c878:	48 0f af c1          	imul   %rcx,%rax
    c87c:	48 c1 e8 20          	shr    $0x20,%rax
    c880:	48 39 d0             	cmp    %rdx,%rax
    c883:	73 13                	jae    c898 <f0+0x1da8>
    c885:	49 01 c4             	add    %rax,%r12
    c888:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c88d:	0f 84 79 0e 00 00    	je     d70c <f0+0x2c1c>
    c893:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c898:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c89f:	33 f3 bf 
    c8a2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    c8a9:	00 
    c8aa:	bf 01 00 00 00       	mov    $0x1,%edi
    c8af:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    c8b6:	00 
    c8b7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    c8be:	00 
    c8bf:	e8 ac 92 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c8c4:	48 8b 15 6d 82 01 00 	mov    0x1826d(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c8cb:	49 89 c5             	mov    %rax,%r13
    c8ce:	48 2b 05 3b 82 01 00 	sub    0x1823b(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c8d5:	48 c1 e2 10          	shl    $0x10,%rdx
    c8d9:	48 39 d0             	cmp    %rdx,%rax
    c8dc:	73 59                	jae    c937 <f0+0x1e47>
    c8de:	48 89 c2             	mov    %rax,%rdx
    c8e1:	48 c1 ea 10          	shr    $0x10,%rdx
    c8e5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8e9:	48 8b 15 68 82 01 00 	mov    0x18268(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c8f0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8f4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8f8:	4d 85 e4             	test   %r12,%r12
    c8fb:	74 3a                	je     c937 <f0+0x1e47>
    c8fd:	0f b6 0a             	movzbl (%rdx),%ecx
    c900:	80 f9 02             	cmp    $0x2,%cl
    c903:	0f 84 77 0a 00 00    	je     d380 <f0+0x2890>
    c909:	80 f9 01             	cmp    $0x1,%cl
    c90c:	75 29                	jne    c937 <f0+0x1e47>
    c90e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c911:	0f b7 c0             	movzwl %ax,%eax
    c914:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c917:	48 0f af c1          	imul   %rcx,%rax
    c91b:	48 c1 e8 20          	shr    $0x20,%rax
    c91f:	48 39 d0             	cmp    %rdx,%rax
    c922:	73 13                	jae    c937 <f0+0x1e47>
    c924:	49 01 c4             	add    %rax,%r12
    c927:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c92c:	0f 84 e7 0d 00 00    	je     d719 <f0+0x2c29>
    c932:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c937:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c93e:	00 f0 3f 
    c941:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    c948:	00 
    c949:	bf 01 00 00 00       	mov    $0x1,%edi
    c94e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    c955:	00 
    c956:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    c95d:	00 
    c95e:	e8 0d 92 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c963:	48 8b 15 ce 81 01 00 	mov    0x181ce(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c96a:	49 89 c5             	mov    %rax,%r13
    c96d:	48 2b 05 9c 81 01 00 	sub    0x1819c(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c974:	48 c1 e2 10          	shl    $0x10,%rdx
    c978:	48 39 d0             	cmp    %rdx,%rax
    c97b:	73 59                	jae    c9d6 <f0+0x1ee6>
    c97d:	48 89 c2             	mov    %rax,%rdx
    c980:	48 c1 ea 10          	shr    $0x10,%rdx
    c984:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c988:	48 8b 15 c9 81 01 00 	mov    0x181c9(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c98f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c993:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c997:	4d 85 e4             	test   %r12,%r12
    c99a:	74 3a                	je     c9d6 <f0+0x1ee6>
    c99c:	0f b6 0a             	movzbl (%rdx),%ecx
    c99f:	80 f9 02             	cmp    $0x2,%cl
    c9a2:	0f 84 38 0c 00 00    	je     d5e0 <f0+0x2af0>
    c9a8:	80 f9 01             	cmp    $0x1,%cl
    c9ab:	75 29                	jne    c9d6 <f0+0x1ee6>
    c9ad:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9b0:	0f b7 c0             	movzwl %ax,%eax
    c9b3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9b6:	48 0f af c1          	imul   %rcx,%rax
    c9ba:	48 c1 e8 20          	shr    $0x20,%rax
    c9be:	48 39 d0             	cmp    %rdx,%rax
    c9c1:	73 13                	jae    c9d6 <f0+0x1ee6>
    c9c3:	49 01 c4             	add    %rax,%r12
    c9c6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9cb:	0f 84 55 0d 00 00    	je     d726 <f0+0x2c36>
    c9d1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9d6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c9dd:	33 f3 bf 
    c9e0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    c9e7:	00 
    c9e8:	bf 01 00 00 00       	mov    $0x1,%edi
    c9ed:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    c9f4:	00 
    c9f5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    c9fc:	00 
    c9fd:	e8 6e 91 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ca02:	48 8b 15 2f 81 01 00 	mov    0x1812f(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    ca09:	49 89 c5             	mov    %rax,%r13
    ca0c:	48 2b 05 fd 80 01 00 	sub    0x180fd(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    ca13:	48 c1 e2 10          	shl    $0x10,%rdx
    ca17:	48 39 d0             	cmp    %rdx,%rax
    ca1a:	73 59                	jae    ca75 <f0+0x1f85>
    ca1c:	48 89 c2             	mov    %rax,%rdx
    ca1f:	48 c1 ea 10          	shr    $0x10,%rdx
    ca23:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca27:	48 8b 15 2a 81 01 00 	mov    0x1812a(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    ca2e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca32:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca36:	4d 85 e4             	test   %r12,%r12
    ca39:	74 3a                	je     ca75 <f0+0x1f85>
    ca3b:	0f b6 0a             	movzbl (%rdx),%ecx
    ca3e:	80 f9 02             	cmp    $0x2,%cl
    ca41:	0f 84 89 0b 00 00    	je     d5d0 <f0+0x2ae0>
    ca47:	80 f9 01             	cmp    $0x1,%cl
    ca4a:	75 29                	jne    ca75 <f0+0x1f85>
    ca4c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca4f:	0f b7 c0             	movzwl %ax,%eax
    ca52:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca55:	48 0f af c1          	imul   %rcx,%rax
    ca59:	48 c1 e8 20          	shr    $0x20,%rax
    ca5d:	48 39 d0             	cmp    %rdx,%rax
    ca60:	73 13                	jae    ca75 <f0+0x1f85>
    ca62:	49 01 c4             	add    %rax,%r12
    ca65:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca6a:	0f 84 c3 0c 00 00    	je     d733 <f0+0x2c43>
    ca70:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca75:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca7c:	00 f0 3f 
    ca7f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    ca86:	00 
    ca87:	bf 01 00 00 00       	mov    $0x1,%edi
    ca8c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    ca93:	00 
    ca94:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    ca9b:	00 
    ca9c:	e8 cf 90 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    caa1:	48 8b 15 90 80 01 00 	mov    0x18090(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    caa8:	49 89 c5             	mov    %rax,%r13
    caab:	48 2b 05 5e 80 01 00 	sub    0x1805e(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cab2:	48 c1 e2 10          	shl    $0x10,%rdx
    cab6:	48 39 d0             	cmp    %rdx,%rax
    cab9:	73 59                	jae    cb14 <f0+0x2024>
    cabb:	48 89 c2             	mov    %rax,%rdx
    cabe:	48 c1 ea 10          	shr    $0x10,%rdx
    cac2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cac6:	48 8b 15 8b 80 01 00 	mov    0x1808b(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cacd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cad1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cad5:	4d 85 e4             	test   %r12,%r12
    cad8:	74 3a                	je     cb14 <f0+0x2024>
    cada:	0f b6 0a             	movzbl (%rdx),%ecx
    cadd:	80 f9 02             	cmp    $0x2,%cl
    cae0:	0f 84 da 0a 00 00    	je     d5c0 <f0+0x2ad0>
    cae6:	80 f9 01             	cmp    $0x1,%cl
    cae9:	75 29                	jne    cb14 <f0+0x2024>
    caeb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caee:	0f b7 c0             	movzwl %ax,%eax
    caf1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    caf4:	48 0f af c1          	imul   %rcx,%rax
    caf8:	48 c1 e8 20          	shr    $0x20,%rax
    cafc:	48 39 d0             	cmp    %rdx,%rax
    caff:	73 13                	jae    cb14 <f0+0x2024>
    cb01:	49 01 c4             	add    %rax,%r12
    cb04:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb09:	0f 84 31 0c 00 00    	je     d740 <f0+0x2c50>
    cb0f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb14:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb1b:	33 f3 bf 
    cb1e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    cb25:	00 
    cb26:	bf 01 00 00 00       	mov    $0x1,%edi
    cb2b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    cb32:	00 
    cb33:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    cb3a:	00 
    cb3b:	e8 30 90 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cb40:	48 8b 15 f1 7f 01 00 	mov    0x17ff1(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cb47:	49 89 c5             	mov    %rax,%r13
    cb4a:	48 2b 05 bf 7f 01 00 	sub    0x17fbf(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cb51:	48 c1 e2 10          	shl    $0x10,%rdx
    cb55:	48 39 d0             	cmp    %rdx,%rax
    cb58:	73 59                	jae    cbb3 <f0+0x20c3>
    cb5a:	48 89 c2             	mov    %rax,%rdx
    cb5d:	48 c1 ea 10          	shr    $0x10,%rdx
    cb61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb65:	48 8b 15 ec 7f 01 00 	mov    0x17fec(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cb6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb70:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb74:	4d 85 e4             	test   %r12,%r12
    cb77:	74 3a                	je     cbb3 <f0+0x20c3>
    cb79:	0f b6 0a             	movzbl (%rdx),%ecx
    cb7c:	80 f9 02             	cmp    $0x2,%cl
    cb7f:	0f 84 2b 0a 00 00    	je     d5b0 <f0+0x2ac0>
    cb85:	80 f9 01             	cmp    $0x1,%cl
    cb88:	75 29                	jne    cbb3 <f0+0x20c3>
    cb8a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb8d:	0f b7 c0             	movzwl %ax,%eax
    cb90:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb93:	48 0f af c1          	imul   %rcx,%rax
    cb97:	48 c1 e8 20          	shr    $0x20,%rax
    cb9b:	48 39 d0             	cmp    %rdx,%rax
    cb9e:	73 13                	jae    cbb3 <f0+0x20c3>
    cba0:	49 01 c4             	add    %rax,%r12
    cba3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cba8:	0f 84 9f 0b 00 00    	je     d74d <f0+0x2c5d>
    cbae:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbb3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cbba:	00 f0 3f 
    cbbd:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    cbc4:	00 
    cbc5:	bf 01 00 00 00       	mov    $0x1,%edi
    cbca:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    cbd1:	00 
    cbd2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    cbd9:	00 
    cbda:	e8 91 8f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cbdf:	48 8b 15 52 7f 01 00 	mov    0x17f52(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cbe6:	49 89 c5             	mov    %rax,%r13
    cbe9:	48 2b 05 20 7f 01 00 	sub    0x17f20(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cbf0:	48 c1 e2 10          	shl    $0x10,%rdx
    cbf4:	48 39 d0             	cmp    %rdx,%rax
    cbf7:	73 59                	jae    cc52 <f0+0x2162>
    cbf9:	48 89 c2             	mov    %rax,%rdx
    cbfc:	48 c1 ea 10          	shr    $0x10,%rdx
    cc00:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc04:	48 8b 15 4d 7f 01 00 	mov    0x17f4d(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cc0b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc0f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc13:	4d 85 e4             	test   %r12,%r12
    cc16:	74 3a                	je     cc52 <f0+0x2162>
    cc18:	0f b6 0a             	movzbl (%rdx),%ecx
    cc1b:	80 f9 02             	cmp    $0x2,%cl
    cc1e:	0f 84 7c 09 00 00    	je     d5a0 <f0+0x2ab0>
    cc24:	80 f9 01             	cmp    $0x1,%cl
    cc27:	75 29                	jne    cc52 <f0+0x2162>
    cc29:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc2c:	0f b7 c0             	movzwl %ax,%eax
    cc2f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc32:	48 0f af c1          	imul   %rcx,%rax
    cc36:	48 c1 e8 20          	shr    $0x20,%rax
    cc3a:	48 39 d0             	cmp    %rdx,%rax
    cc3d:	73 13                	jae    cc52 <f0+0x2162>
    cc3f:	49 01 c4             	add    %rax,%r12
    cc42:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc47:	0f 84 0d 0b 00 00    	je     d75a <f0+0x2c6a>
    cc4d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc52:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cc59:	33 f3 bf 
    cc5c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    cc63:	00 
    cc64:	bf 01 00 00 00       	mov    $0x1,%edi
    cc69:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    cc70:	00 
    cc71:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    cc78:	00 
    cc79:	e8 f2 8e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cc7e:	48 8b 15 b3 7e 01 00 	mov    0x17eb3(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cc85:	49 89 c5             	mov    %rax,%r13
    cc88:	48 2b 05 81 7e 01 00 	sub    0x17e81(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cc8f:	48 c1 e2 10          	shl    $0x10,%rdx
    cc93:	48 39 d0             	cmp    %rdx,%rax
    cc96:	73 59                	jae    ccf1 <f0+0x2201>
    cc98:	48 89 c2             	mov    %rax,%rdx
    cc9b:	48 c1 ea 10          	shr    $0x10,%rdx
    cc9f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cca3:	48 8b 15 ae 7e 01 00 	mov    0x17eae(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    ccaa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccae:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccb2:	4d 85 e4             	test   %r12,%r12
    ccb5:	74 3a                	je     ccf1 <f0+0x2201>
    ccb7:	0f b6 0a             	movzbl (%rdx),%ecx
    ccba:	80 f9 02             	cmp    $0x2,%cl
    ccbd:	0f 84 cd 08 00 00    	je     d590 <f0+0x2aa0>
    ccc3:	80 f9 01             	cmp    $0x1,%cl
    ccc6:	75 29                	jne    ccf1 <f0+0x2201>
    ccc8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cccb:	0f b7 c0             	movzwl %ax,%eax
    ccce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccd1:	48 0f af c1          	imul   %rcx,%rax
    ccd5:	48 c1 e8 20          	shr    $0x20,%rax
    ccd9:	48 39 d0             	cmp    %rdx,%rax
    ccdc:	73 13                	jae    ccf1 <f0+0x2201>
    ccde:	49 01 c4             	add    %rax,%r12
    cce1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cce6:	0f 84 7b 0a 00 00    	je     d767 <f0+0x2c77>
    ccec:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccf1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ccf8:	00 f0 3f 
    ccfb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    cd02:	00 
    cd03:	bf 01 00 00 00       	mov    $0x1,%edi
    cd08:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    cd0f:	00 
    cd10:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    cd17:	00 
    cd18:	e8 53 8e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cd1d:	48 8b 15 14 7e 01 00 	mov    0x17e14(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cd24:	49 89 c5             	mov    %rax,%r13
    cd27:	48 2b 05 e2 7d 01 00 	sub    0x17de2(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cd2e:	48 c1 e2 10          	shl    $0x10,%rdx
    cd32:	48 39 d0             	cmp    %rdx,%rax
    cd35:	73 59                	jae    cd90 <f0+0x22a0>
    cd37:	48 89 c2             	mov    %rax,%rdx
    cd3a:	48 c1 ea 10          	shr    $0x10,%rdx
    cd3e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd42:	48 8b 15 0f 7e 01 00 	mov    0x17e0f(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cd49:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd4d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd51:	4d 85 e4             	test   %r12,%r12
    cd54:	74 3a                	je     cd90 <f0+0x22a0>
    cd56:	0f b6 0a             	movzbl (%rdx),%ecx
    cd59:	80 f9 02             	cmp    $0x2,%cl
    cd5c:	0f 84 1e 08 00 00    	je     d580 <f0+0x2a90>
    cd62:	80 f9 01             	cmp    $0x1,%cl
    cd65:	75 29                	jne    cd90 <f0+0x22a0>
    cd67:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd6a:	0f b7 c0             	movzwl %ax,%eax
    cd6d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd70:	48 0f af c1          	imul   %rcx,%rax
    cd74:	48 c1 e8 20          	shr    $0x20,%rax
    cd78:	48 39 d0             	cmp    %rdx,%rax
    cd7b:	73 13                	jae    cd90 <f0+0x22a0>
    cd7d:	49 01 c4             	add    %rax,%r12
    cd80:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd85:	0f 84 e9 09 00 00    	je     d774 <f0+0x2c84>
    cd8b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd90:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd97:	33 f3 bf 
    cd9a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    cda1:	00 
    cda2:	bf 01 00 00 00       	mov    $0x1,%edi
    cda7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    cdae:	00 
    cdaf:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    cdb6:	00 
    cdb7:	e8 b4 8d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cdbc:	48 8b 15 75 7d 01 00 	mov    0x17d75(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cdc3:	49 89 c5             	mov    %rax,%r13
    cdc6:	48 2b 05 43 7d 01 00 	sub    0x17d43(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cdcd:	48 c1 e2 10          	shl    $0x10,%rdx
    cdd1:	48 39 d0             	cmp    %rdx,%rax
    cdd4:	73 59                	jae    ce2f <f0+0x233f>
    cdd6:	48 89 c2             	mov    %rax,%rdx
    cdd9:	48 c1 ea 10          	shr    $0x10,%rdx
    cddd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cde1:	48 8b 15 70 7d 01 00 	mov    0x17d70(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cde8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdec:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdf0:	4d 85 e4             	test   %r12,%r12
    cdf3:	74 3a                	je     ce2f <f0+0x233f>
    cdf5:	0f b6 0a             	movzbl (%rdx),%ecx
    cdf8:	80 f9 02             	cmp    $0x2,%cl
    cdfb:	0f 84 6f 07 00 00    	je     d570 <f0+0x2a80>
    ce01:	80 f9 01             	cmp    $0x1,%cl
    ce04:	75 29                	jne    ce2f <f0+0x233f>
    ce06:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce09:	0f b7 c0             	movzwl %ax,%eax
    ce0c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce0f:	48 0f af c1          	imul   %rcx,%rax
    ce13:	48 c1 e8 20          	shr    $0x20,%rax
    ce17:	48 39 d0             	cmp    %rdx,%rax
    ce1a:	73 13                	jae    ce2f <f0+0x233f>
    ce1c:	49 01 c4             	add    %rax,%r12
    ce1f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce24:	0f 84 57 09 00 00    	je     d781 <f0+0x2c91>
    ce2a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce2f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce36:	00 f0 3f 
    ce39:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    ce40:	00 
    ce41:	bf 01 00 00 00       	mov    $0x1,%edi
    ce46:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    ce4d:	00 
    ce4e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    ce55:	00 
    ce56:	e8 15 8d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ce5b:	48 8b 15 d6 7c 01 00 	mov    0x17cd6(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    ce62:	49 89 c5             	mov    %rax,%r13
    ce65:	48 2b 05 a4 7c 01 00 	sub    0x17ca4(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    ce6c:	48 c1 e2 10          	shl    $0x10,%rdx
    ce70:	48 39 d0             	cmp    %rdx,%rax
    ce73:	73 59                	jae    cece <f0+0x23de>
    ce75:	48 89 c2             	mov    %rax,%rdx
    ce78:	48 c1 ea 10          	shr    $0x10,%rdx
    ce7c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce80:	48 8b 15 d1 7c 01 00 	mov    0x17cd1(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    ce87:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce8b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce8f:	4d 85 e4             	test   %r12,%r12
    ce92:	74 3a                	je     cece <f0+0x23de>
    ce94:	0f b6 0a             	movzbl (%rdx),%ecx
    ce97:	80 f9 02             	cmp    $0x2,%cl
    ce9a:	0f 84 c0 06 00 00    	je     d560 <f0+0x2a70>
    cea0:	80 f9 01             	cmp    $0x1,%cl
    cea3:	75 29                	jne    cece <f0+0x23de>
    cea5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cea8:	0f b7 c0             	movzwl %ax,%eax
    ceab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ceae:	48 0f af c1          	imul   %rcx,%rax
    ceb2:	48 c1 e8 20          	shr    $0x20,%rax
    ceb6:	48 39 d0             	cmp    %rdx,%rax
    ceb9:	73 13                	jae    cece <f0+0x23de>
    cebb:	49 01 c4             	add    %rax,%r12
    cebe:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cec3:	0f 84 c5 08 00 00    	je     d78e <f0+0x2c9e>
    cec9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cece:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ced5:	33 f3 bf 
    ced8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    cedf:	00 
    cee0:	bf 01 00 00 00       	mov    $0x1,%edi
    cee5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    ceec:	00 
    ceed:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    cef4:	00 
    cef5:	e8 76 8c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cefa:	48 8b 15 37 7c 01 00 	mov    0x17c37(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cf01:	49 89 c5             	mov    %rax,%r13
    cf04:	48 2b 05 05 7c 01 00 	sub    0x17c05(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cf0b:	48 c1 e2 10          	shl    $0x10,%rdx
    cf0f:	48 39 d0             	cmp    %rdx,%rax
    cf12:	73 59                	jae    cf6d <f0+0x247d>
    cf14:	48 89 c2             	mov    %rax,%rdx
    cf17:	48 c1 ea 10          	shr    $0x10,%rdx
    cf1b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf1f:	48 8b 15 32 7c 01 00 	mov    0x17c32(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cf26:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf2a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf2e:	4d 85 e4             	test   %r12,%r12
    cf31:	74 3a                	je     cf6d <f0+0x247d>
    cf33:	0f b6 0a             	movzbl (%rdx),%ecx
    cf36:	80 f9 02             	cmp    $0x2,%cl
    cf39:	0f 84 11 06 00 00    	je     d550 <f0+0x2a60>
    cf3f:	80 f9 01             	cmp    $0x1,%cl
    cf42:	75 29                	jne    cf6d <f0+0x247d>
    cf44:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf47:	0f b7 c0             	movzwl %ax,%eax
    cf4a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf4d:	48 0f af c1          	imul   %rcx,%rax
    cf51:	48 c1 e8 20          	shr    $0x20,%rax
    cf55:	48 39 d0             	cmp    %rdx,%rax
    cf58:	73 13                	jae    cf6d <f0+0x247d>
    cf5a:	49 01 c4             	add    %rax,%r12
    cf5d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf62:	0f 84 33 08 00 00    	je     d79b <f0+0x2cab>
    cf68:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf6d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf74:	00 f0 3f 
    cf77:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    cf7e:	00 
    cf7f:	bf 01 00 00 00       	mov    $0x1,%edi
    cf84:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    cf8b:	00 
    cf8c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    cf93:	00 
    cf94:	e8 d7 8b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cf99:	48 8b 15 98 7b 01 00 	mov    0x17b98(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cfa0:	49 89 c5             	mov    %rax,%r13
    cfa3:	48 2b 05 66 7b 01 00 	sub    0x17b66(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cfaa:	48 c1 e2 10          	shl    $0x10,%rdx
    cfae:	48 39 d0             	cmp    %rdx,%rax
    cfb1:	73 59                	jae    d00c <f0+0x251c>
    cfb3:	48 89 c2             	mov    %rax,%rdx
    cfb6:	48 c1 ea 10          	shr    $0x10,%rdx
    cfba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfbe:	48 8b 15 93 7b 01 00 	mov    0x17b93(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cfc5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfc9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfcd:	4d 85 e4             	test   %r12,%r12
    cfd0:	74 3a                	je     d00c <f0+0x251c>
    cfd2:	0f b6 0a             	movzbl (%rdx),%ecx
    cfd5:	80 f9 02             	cmp    $0x2,%cl
    cfd8:	0f 84 62 05 00 00    	je     d540 <f0+0x2a50>
    cfde:	80 f9 01             	cmp    $0x1,%cl
    cfe1:	75 29                	jne    d00c <f0+0x251c>
    cfe3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfe6:	0f b7 c0             	movzwl %ax,%eax
    cfe9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfec:	48 0f af c1          	imul   %rcx,%rax
    cff0:	48 c1 e8 20          	shr    $0x20,%rax
    cff4:	48 39 d0             	cmp    %rdx,%rax
    cff7:	73 13                	jae    d00c <f0+0x251c>
    cff9:	49 01 c4             	add    %rax,%r12
    cffc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d001:	0f 84 a1 07 00 00    	je     d7a8 <f0+0x2cb8>
    d007:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d00c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d013:	33 f3 bf 
    d016:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d01d:	00 
    d01e:	bf 01 00 00 00       	mov    $0x1,%edi
    d023:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d02a:	00 
    d02b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d032:	00 
    d033:	e8 38 8b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d038:	48 8b 15 f9 7a 01 00 	mov    0x17af9(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d03f:	49 89 c5             	mov    %rax,%r13
    d042:	48 2b 05 c7 7a 01 00 	sub    0x17ac7(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d049:	48 c1 e2 10          	shl    $0x10,%rdx
    d04d:	48 39 d0             	cmp    %rdx,%rax
    d050:	73 59                	jae    d0ab <f0+0x25bb>
    d052:	48 89 c2             	mov    %rax,%rdx
    d055:	48 c1 ea 10          	shr    $0x10,%rdx
    d059:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d05d:	48 8b 15 f4 7a 01 00 	mov    0x17af4(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d064:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d068:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d06c:	4d 85 e4             	test   %r12,%r12
    d06f:	74 3a                	je     d0ab <f0+0x25bb>
    d071:	0f b6 0a             	movzbl (%rdx),%ecx
    d074:	80 f9 02             	cmp    $0x2,%cl
    d077:	0f 84 b3 04 00 00    	je     d530 <f0+0x2a40>
    d07d:	80 f9 01             	cmp    $0x1,%cl
    d080:	75 29                	jne    d0ab <f0+0x25bb>
    d082:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d085:	0f b7 c0             	movzwl %ax,%eax
    d088:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d08b:	48 0f af c1          	imul   %rcx,%rax
    d08f:	48 c1 e8 20          	shr    $0x20,%rax
    d093:	48 39 d0             	cmp    %rdx,%rax
    d096:	73 13                	jae    d0ab <f0+0x25bb>
    d098:	49 01 c4             	add    %rax,%r12
    d09b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0a0:	0f 84 0f 07 00 00    	je     d7b5 <f0+0x2cc5>
    d0a6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0ab:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d0b2:	00 f0 3f 
    d0b5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d0bc:	00 
    d0bd:	bf 01 00 00 00       	mov    $0x1,%edi
    d0c2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d0c9:	00 
    d0ca:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d0d1:	00 
    d0d2:	e8 99 8a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d0d7:	48 8b 15 5a 7a 01 00 	mov    0x17a5a(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d0de:	49 89 c5             	mov    %rax,%r13
    d0e1:	48 2b 05 28 7a 01 00 	sub    0x17a28(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d0e8:	48 c1 e2 10          	shl    $0x10,%rdx
    d0ec:	48 39 d0             	cmp    %rdx,%rax
    d0ef:	73 59                	jae    d14a <f0+0x265a>
    d0f1:	48 89 c2             	mov    %rax,%rdx
    d0f4:	48 c1 ea 10          	shr    $0x10,%rdx
    d0f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0fc:	48 8b 15 55 7a 01 00 	mov    0x17a55(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d103:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d107:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d10b:	4d 85 e4             	test   %r12,%r12
    d10e:	74 3a                	je     d14a <f0+0x265a>
    d110:	0f b6 0a             	movzbl (%rdx),%ecx
    d113:	80 f9 02             	cmp    $0x2,%cl
    d116:	0f 84 04 04 00 00    	je     d520 <f0+0x2a30>
    d11c:	80 f9 01             	cmp    $0x1,%cl
    d11f:	75 29                	jne    d14a <f0+0x265a>
    d121:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d124:	0f b7 c0             	movzwl %ax,%eax
    d127:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d12a:	48 0f af c1          	imul   %rcx,%rax
    d12e:	48 c1 e8 20          	shr    $0x20,%rax
    d132:	48 39 d0             	cmp    %rdx,%rax
    d135:	73 13                	jae    d14a <f0+0x265a>
    d137:	49 01 c4             	add    %rax,%r12
    d13a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d13f:	0f 84 7d 06 00 00    	je     d7c2 <f0+0x2cd2>
    d145:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d14a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d151:	33 f3 bf 
    d154:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d15b:	00 
    d15c:	bf 01 00 00 00       	mov    $0x1,%edi
    d161:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d168:	00 
    d169:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d170:	00 
    d171:	e8 fa 89 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d176:	48 8b 15 bb 79 01 00 	mov    0x179bb(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d17d:	49 89 c5             	mov    %rax,%r13
    d180:	48 2b 05 89 79 01 00 	sub    0x17989(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d187:	48 c1 e2 10          	shl    $0x10,%rdx
    d18b:	48 39 d0             	cmp    %rdx,%rax
    d18e:	73 59                	jae    d1e9 <f0+0x26f9>
    d190:	48 89 c2             	mov    %rax,%rdx
    d193:	48 c1 ea 10          	shr    $0x10,%rdx
    d197:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d19b:	48 8b 15 b6 79 01 00 	mov    0x179b6(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d1a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1a6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1aa:	4d 85 e4             	test   %r12,%r12
    d1ad:	74 3a                	je     d1e9 <f0+0x26f9>
    d1af:	0f b6 0a             	movzbl (%rdx),%ecx
    d1b2:	80 f9 02             	cmp    $0x2,%cl
    d1b5:	0f 84 55 03 00 00    	je     d510 <f0+0x2a20>
    d1bb:	80 f9 01             	cmp    $0x1,%cl
    d1be:	75 29                	jne    d1e9 <f0+0x26f9>
    d1c0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1c3:	0f b7 c0             	movzwl %ax,%eax
    d1c6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1c9:	48 0f af c1          	imul   %rcx,%rax
    d1cd:	48 c1 e8 20          	shr    $0x20,%rax
    d1d1:	48 39 d0             	cmp    %rdx,%rax
    d1d4:	73 13                	jae    d1e9 <f0+0x26f9>
    d1d6:	49 01 c4             	add    %rax,%r12
    d1d9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1de:	0f 84 eb 05 00 00    	je     d7cf <f0+0x2cdf>
    d1e4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1e9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d1f0:	00 f0 3f 
    d1f3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d1fa:	00 
    d1fb:	bf 01 00 00 00       	mov    $0x1,%edi
    d200:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d207:	00 
    d208:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d20f:	00 
    d210:	e8 5b 89 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d215:	48 8b 15 1c 79 01 00 	mov    0x1791c(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d21c:	49 89 c5             	mov    %rax,%r13
    d21f:	48 2b 05 ea 78 01 00 	sub    0x178ea(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d226:	48 c1 e2 10          	shl    $0x10,%rdx
    d22a:	48 39 d0             	cmp    %rdx,%rax
    d22d:	73 59                	jae    d288 <f0+0x2798>
    d22f:	48 89 c2             	mov    %rax,%rdx
    d232:	48 c1 ea 10          	shr    $0x10,%rdx
    d236:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d23a:	48 8b 15 17 79 01 00 	mov    0x17917(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d241:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d245:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d249:	4d 85 e4             	test   %r12,%r12
    d24c:	74 3a                	je     d288 <f0+0x2798>
    d24e:	0f b6 0a             	movzbl (%rdx),%ecx
    d251:	80 f9 02             	cmp    $0x2,%cl
    d254:	0f 84 a6 02 00 00    	je     d500 <f0+0x2a10>
    d25a:	80 f9 01             	cmp    $0x1,%cl
    d25d:	75 29                	jne    d288 <f0+0x2798>
    d25f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d262:	0f b7 c0             	movzwl %ax,%eax
    d265:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d268:	48 0f af c1          	imul   %rcx,%rax
    d26c:	48 c1 e8 20          	shr    $0x20,%rax
    d270:	48 39 d0             	cmp    %rdx,%rax
    d273:	73 13                	jae    d288 <f0+0x2798>
    d275:	49 01 c4             	add    %rax,%r12
    d278:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d27d:	0f 84 59 05 00 00    	je     d7dc <f0+0x2cec>
    d283:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d288:	48 89 ee             	mov    %rbp,%rsi
    d28b:	bf 01 00 00 00       	mov    $0x1,%edi
    d290:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d297:	33 f3 bf 
    d29a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d2a1:	00 
    d2a2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d2a9:	00 
    d2aa:	e8 c1 88 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d2af:	48 8b 15 82 78 01 00 	mov    0x17882(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d2b6:	48 89 c5             	mov    %rax,%rbp
    d2b9:	48 2b 05 50 78 01 00 	sub    0x17850(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d2c0:	48 c1 e2 10          	shl    $0x10,%rdx
    d2c4:	48 39 d0             	cmp    %rdx,%rax
    d2c7:	73 59                	jae    d322 <f0+0x2832>
    d2c9:	48 89 c2             	mov    %rax,%rdx
    d2cc:	48 c1 ea 10          	shr    $0x10,%rdx
    d2d0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2d4:	48 8b 15 7d 78 01 00 	mov    0x1787d(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d2db:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2df:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2e3:	4d 85 e4             	test   %r12,%r12
    d2e6:	74 3a                	je     d322 <f0+0x2832>
    d2e8:	0f b6 0a             	movzbl (%rdx),%ecx
    d2eb:	80 f9 02             	cmp    $0x2,%cl
    d2ee:	0f 84 fc 01 00 00    	je     d4f0 <f0+0x2a00>
    d2f4:	80 f9 01             	cmp    $0x1,%cl
    d2f7:	75 29                	jne    d322 <f0+0x2832>
    d2f9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2fc:	0f b7 c0             	movzwl %ax,%eax
    d2ff:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d302:	48 0f af c1          	imul   %rcx,%rax
    d306:	48 c1 e8 20          	shr    $0x20,%rax
    d30a:	48 39 d0             	cmp    %rdx,%rax
    d30d:	73 13                	jae    d322 <f0+0x2832>
    d30f:	49 01 c4             	add    %rax,%r12
    d312:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d317:	0f 84 d1 02 00 00    	je     d5ee <f0+0x2afe>
    d31d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d322:	48 89 de             	mov    %rbx,%rsi
    d325:	48 89 ef             	mov    %rbp,%rdi
    d328:	e8 f3 be ff ff       	call   9220 <fwp_hof0.constprop.0>
    d32d:	48 89 ef             	mov    %rbp,%rdi
    d330:	e8 6b a3 ff ff       	call   76a0 <fwp_drop0>
    d335:	48 89 df             	mov    %rbx,%rdi
    d338:	e8 63 a3 ff ff       	call   76a0 <fwp_drop0>
    d33d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d344:	00 
    d345:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d34c:	00 00 
    d34e:	0f 85 95 04 00 00    	jne    d7e9 <f0+0x2cf9>
    d354:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d35b:	31 c0                	xor    %eax,%eax
    d35d:	5b                   	pop    %rbx
    d35e:	5d                   	pop    %rbp
    d35f:	41 5c                	pop    %r12
    d361:	41 5d                	pop    %r13
    d363:	41 5e                	pop    %r14
    d365:	c3                   	ret
    d366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d36d:	00 00 00 
    d370:	4c 89 ef             	mov    %r13,%rdi
    d373:	e8 98 7f ff ff       	call   5310 <fwp_rc_forget_slot>
    d378:	e9 2c d8 ff ff       	jmp    aba9 <f0+0xb9>
    d37d:	0f 1f 00             	nopl   (%rax)
    d380:	66 85 c0             	test   %ax,%ax
    d383:	0f 85 ae f5 ff ff    	jne    c937 <f0+0x1e47>
    d389:	e9 99 f5 ff ff       	jmp    c927 <f0+0x1e37>
    d38e:	66 90                	xchg   %ax,%ax
    d390:	66 85 c0             	test   %ax,%ax
    d393:	0f 85 ff f4 ff ff    	jne    c898 <f0+0x1da8>
    d399:	e9 ea f4 ff ff       	jmp    c888 <f0+0x1d98>
    d39e:	66 90                	xchg   %ax,%ax
    d3a0:	66 85 c0             	test   %ax,%ax
    d3a3:	0f 85 50 f4 ff ff    	jne    c7f9 <f0+0x1d09>
    d3a9:	e9 3b f4 ff ff       	jmp    c7e9 <f0+0x1cf9>
    d3ae:	66 90                	xchg   %ax,%ax
    d3b0:	66 85 c0             	test   %ax,%ax
    d3b3:	0f 85 a1 f3 ff ff    	jne    c75a <f0+0x1c6a>
    d3b9:	e9 8c f3 ff ff       	jmp    c74a <f0+0x1c5a>
    d3be:	66 90                	xchg   %ax,%ax
    d3c0:	66 85 c0             	test   %ax,%ax
    d3c3:	0f 85 f2 f2 ff ff    	jne    c6bb <f0+0x1bcb>
    d3c9:	e9 dd f2 ff ff       	jmp    c6ab <f0+0x1bbb>
    d3ce:	66 90                	xchg   %ax,%ax
    d3d0:	66 85 c0             	test   %ax,%ax
    d3d3:	0f 85 43 f2 ff ff    	jne    c61c <f0+0x1b2c>
    d3d9:	e9 2e f2 ff ff       	jmp    c60c <f0+0x1b1c>
    d3de:	66 90                	xchg   %ax,%ax
    d3e0:	66 85 c0             	test   %ax,%ax
    d3e3:	0f 85 94 f1 ff ff    	jne    c57d <f0+0x1a8d>
    d3e9:	e9 7f f1 ff ff       	jmp    c56d <f0+0x1a7d>
    d3ee:	66 90                	xchg   %ax,%ax
    d3f0:	66 85 c0             	test   %ax,%ax
    d3f3:	0f 85 e5 f0 ff ff    	jne    c4de <f0+0x19ee>
    d3f9:	e9 d0 f0 ff ff       	jmp    c4ce <f0+0x19de>
    d3fe:	66 90                	xchg   %ax,%ax
    d400:	66 85 c0             	test   %ax,%ax
    d403:	0f 85 fd d9 ff ff    	jne    ae06 <f0+0x316>
    d409:	e9 e8 d9 ff ff       	jmp    adf6 <f0+0x306>
    d40e:	66 90                	xchg   %ax,%ax
    d410:	66 85 c0             	test   %ax,%ax
    d413:	0f 85 57 d9 ff ff    	jne    ad70 <f0+0x280>
    d419:	e9 42 d9 ff ff       	jmp    ad60 <f0+0x270>
    d41e:	66 90                	xchg   %ax,%ax
    d420:	66 85 c0             	test   %ax,%ax
    d423:	0f 85 b1 d8 ff ff    	jne    acda <f0+0x1ea>
    d429:	e9 9c d8 ff ff       	jmp    acca <f0+0x1da>
    d42e:	66 90                	xchg   %ax,%ax
    d430:	66 85 c0             	test   %ax,%ax
    d433:	0f 85 0e eb ff ff    	jne    bf47 <f0+0x1457>
    d439:	e9 f9 ea ff ff       	jmp    bf37 <f0+0x1447>
    d43e:	66 90                	xchg   %ax,%ax
    d440:	66 85 c0             	test   %ax,%ax
    d443:	0f 85 5f ea ff ff    	jne    bea8 <f0+0x13b8>
    d449:	e9 4a ea ff ff       	jmp    be98 <f0+0x13a8>
    d44e:	66 90                	xchg   %ax,%ax
    d450:	66 85 c0             	test   %ax,%ax
    d453:	0f 85 e2 da ff ff    	jne    af3b <f0+0x44b>
    d459:	e9 cd da ff ff       	jmp    af2b <f0+0x43b>
    d45e:	66 90                	xchg   %ax,%ax
    d460:	66 85 c0             	test   %ax,%ax
    d463:	0f 85 33 da ff ff    	jne    ae9c <f0+0x3ac>
    d469:	e9 1e da ff ff       	jmp    ae8c <f0+0x39c>
    d46e:	66 90                	xchg   %ax,%ax
    d470:	66 85 c0             	test   %ax,%ax
    d473:	0f 85 c6 ef ff ff    	jne    c43f <f0+0x194f>
    d479:	e9 b1 ef ff ff       	jmp    c42f <f0+0x193f>
    d47e:	66 90                	xchg   %ax,%ax
    d480:	66 85 c0             	test   %ax,%ax
    d483:	0f 85 17 ef ff ff    	jne    c3a0 <f0+0x18b0>
    d489:	e9 02 ef ff ff       	jmp    c390 <f0+0x18a0>
    d48e:	66 90                	xchg   %ax,%ax
    d490:	66 85 c0             	test   %ax,%ax
    d493:	0f 85 68 ee ff ff    	jne    c301 <f0+0x1811>
    d499:	e9 53 ee ff ff       	jmp    c2f1 <f0+0x1801>
    d49e:	66 90                	xchg   %ax,%ax
    d4a0:	66 85 c0             	test   %ax,%ax
    d4a3:	0f 85 b9 ed ff ff    	jne    c262 <f0+0x1772>
    d4a9:	e9 a4 ed ff ff       	jmp    c252 <f0+0x1762>
    d4ae:	66 90                	xchg   %ax,%ax
    d4b0:	66 85 c0             	test   %ax,%ax
    d4b3:	0f 85 0a ed ff ff    	jne    c1c3 <f0+0x16d3>
    d4b9:	e9 f5 ec ff ff       	jmp    c1b3 <f0+0x16c3>
    d4be:	66 90                	xchg   %ax,%ax
    d4c0:	66 85 c0             	test   %ax,%ax
    d4c3:	0f 85 5b ec ff ff    	jne    c124 <f0+0x1634>
    d4c9:	e9 46 ec ff ff       	jmp    c114 <f0+0x1624>
    d4ce:	66 90                	xchg   %ax,%ax
    d4d0:	66 85 c0             	test   %ax,%ax
    d4d3:	0f 85 ac eb ff ff    	jne    c085 <f0+0x1595>
    d4d9:	e9 97 eb ff ff       	jmp    c075 <f0+0x1585>
    d4de:	66 90                	xchg   %ax,%ax
    d4e0:	66 85 c0             	test   %ax,%ax
    d4e3:	0f 85 fd ea ff ff    	jne    bfe6 <f0+0x14f6>
    d4e9:	e9 e8 ea ff ff       	jmp    bfd6 <f0+0x14e6>
    d4ee:	66 90                	xchg   %ax,%ax
    d4f0:	66 85 c0             	test   %ax,%ax
    d4f3:	0f 85 29 fe ff ff    	jne    d322 <f0+0x2832>
    d4f9:	e9 14 fe ff ff       	jmp    d312 <f0+0x2822>
    d4fe:	66 90                	xchg   %ax,%ax
    d500:	66 85 c0             	test   %ax,%ax
    d503:	0f 85 7f fd ff ff    	jne    d288 <f0+0x2798>
    d509:	e9 6a fd ff ff       	jmp    d278 <f0+0x2788>
    d50e:	66 90                	xchg   %ax,%ax
    d510:	66 85 c0             	test   %ax,%ax
    d513:	0f 85 d0 fc ff ff    	jne    d1e9 <f0+0x26f9>
    d519:	e9 bb fc ff ff       	jmp    d1d9 <f0+0x26e9>
    d51e:	66 90                	xchg   %ax,%ax
    d520:	66 85 c0             	test   %ax,%ax
    d523:	0f 85 21 fc ff ff    	jne    d14a <f0+0x265a>
    d529:	e9 0c fc ff ff       	jmp    d13a <f0+0x264a>
    d52e:	66 90                	xchg   %ax,%ax
    d530:	66 85 c0             	test   %ax,%ax
    d533:	0f 85 72 fb ff ff    	jne    d0ab <f0+0x25bb>
    d539:	e9 5d fb ff ff       	jmp    d09b <f0+0x25ab>
    d53e:	66 90                	xchg   %ax,%ax
    d540:	66 85 c0             	test   %ax,%ax
    d543:	0f 85 c3 fa ff ff    	jne    d00c <f0+0x251c>
    d549:	e9 ae fa ff ff       	jmp    cffc <f0+0x250c>
    d54e:	66 90                	xchg   %ax,%ax
    d550:	66 85 c0             	test   %ax,%ax
    d553:	0f 85 14 fa ff ff    	jne    cf6d <f0+0x247d>
    d559:	e9 ff f9 ff ff       	jmp    cf5d <f0+0x246d>
    d55e:	66 90                	xchg   %ax,%ax
    d560:	66 85 c0             	test   %ax,%ax
    d563:	0f 85 65 f9 ff ff    	jne    cece <f0+0x23de>
    d569:	e9 50 f9 ff ff       	jmp    cebe <f0+0x23ce>
    d56e:	66 90                	xchg   %ax,%ax
    d570:	66 85 c0             	test   %ax,%ax
    d573:	0f 85 b6 f8 ff ff    	jne    ce2f <f0+0x233f>
    d579:	e9 a1 f8 ff ff       	jmp    ce1f <f0+0x232f>
    d57e:	66 90                	xchg   %ax,%ax
    d580:	66 85 c0             	test   %ax,%ax
    d583:	0f 85 07 f8 ff ff    	jne    cd90 <f0+0x22a0>
    d589:	e9 f2 f7 ff ff       	jmp    cd80 <f0+0x2290>
    d58e:	66 90                	xchg   %ax,%ax
    d590:	66 85 c0             	test   %ax,%ax
    d593:	0f 85 58 f7 ff ff    	jne    ccf1 <f0+0x2201>
    d599:	e9 43 f7 ff ff       	jmp    cce1 <f0+0x21f1>
    d59e:	66 90                	xchg   %ax,%ax
    d5a0:	66 85 c0             	test   %ax,%ax
    d5a3:	0f 85 a9 f6 ff ff    	jne    cc52 <f0+0x2162>
    d5a9:	e9 94 f6 ff ff       	jmp    cc42 <f0+0x2152>
    d5ae:	66 90                	xchg   %ax,%ax
    d5b0:	66 85 c0             	test   %ax,%ax
    d5b3:	0f 85 fa f5 ff ff    	jne    cbb3 <f0+0x20c3>
    d5b9:	e9 e5 f5 ff ff       	jmp    cba3 <f0+0x20b3>
    d5be:	66 90                	xchg   %ax,%ax
    d5c0:	66 85 c0             	test   %ax,%ax
    d5c3:	0f 85 4b f5 ff ff    	jne    cb14 <f0+0x2024>
    d5c9:	e9 36 f5 ff ff       	jmp    cb04 <f0+0x2014>
    d5ce:	66 90                	xchg   %ax,%ax
    d5d0:	66 85 c0             	test   %ax,%ax
    d5d3:	0f 85 9c f4 ff ff    	jne    ca75 <f0+0x1f85>
    d5d9:	e9 87 f4 ff ff       	jmp    ca65 <f0+0x1f75>
    d5de:	66 90                	xchg   %ax,%ax
    d5e0:	66 85 c0             	test   %ax,%ax
    d5e3:	0f 85 ed f3 ff ff    	jne    c9d6 <f0+0x1ee6>
    d5e9:	e9 d8 f3 ff ff       	jmp    c9c6 <f0+0x1ed6>
    d5ee:	4c 89 e7             	mov    %r12,%rdi
    d5f1:	e8 1a 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d5f6:	e9 22 fd ff ff       	jmp    d31d <f0+0x282d>
    d5fb:	4c 89 e7             	mov    %r12,%rdi
    d5fe:	e8 0d 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d603:	e9 cd d6 ff ff       	jmp    acd5 <f0+0x1e5>
    d608:	4c 89 e7             	mov    %r12,%rdi
    d60b:	e8 00 7d ff ff       	call   5310 <fwp_rc_forget_slot>
    d610:	e9 56 d7 ff ff       	jmp    ad6b <f0+0x27b>
    d615:	4c 89 e7             	mov    %r12,%rdi
    d618:	e8 f3 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d61d:	e9 df d7 ff ff       	jmp    ae01 <f0+0x311>
    d622:	4c 89 e7             	mov    %r12,%rdi
    d625:	e8 e6 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d62a:	e9 68 d8 ff ff       	jmp    ae97 <f0+0x3a7>
    d62f:	4c 89 e7             	mov    %r12,%rdi
    d632:	e8 d9 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d637:	e9 fa d8 ff ff       	jmp    af36 <f0+0x446>
    d63c:	4c 89 e7             	mov    %r12,%rdi
    d63f:	e8 cc 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d644:	e9 5a e8 ff ff       	jmp    bea3 <f0+0x13b3>
    d649:	4c 89 e7             	mov    %r12,%rdi
    d64c:	e8 bf 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d651:	e9 ec e8 ff ff       	jmp    bf42 <f0+0x1452>
    d656:	4c 89 e7             	mov    %r12,%rdi
    d659:	e8 b2 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d65e:	e9 7e e9 ff ff       	jmp    bfe1 <f0+0x14f1>
    d663:	4c 89 e7             	mov    %r12,%rdi
    d666:	e8 a5 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d66b:	e9 10 ea ff ff       	jmp    c080 <f0+0x1590>
    d670:	4c 89 e7             	mov    %r12,%rdi
    d673:	e8 98 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d678:	e9 a2 ea ff ff       	jmp    c11f <f0+0x162f>
    d67d:	4c 89 e7             	mov    %r12,%rdi
    d680:	e8 8b 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d685:	e9 34 eb ff ff       	jmp    c1be <f0+0x16ce>
    d68a:	4c 89 e7             	mov    %r12,%rdi
    d68d:	e8 7e 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d692:	e9 c6 eb ff ff       	jmp    c25d <f0+0x176d>
    d697:	4c 89 e7             	mov    %r12,%rdi
    d69a:	e8 71 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d69f:	e9 58 ec ff ff       	jmp    c2fc <f0+0x180c>
    d6a4:	4c 89 e7             	mov    %r12,%rdi
    d6a7:	e8 64 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d6ac:	e9 ea ec ff ff       	jmp    c39b <f0+0x18ab>
    d6b1:	4c 89 e7             	mov    %r12,%rdi
    d6b4:	e8 57 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d6b9:	e9 7c ed ff ff       	jmp    c43a <f0+0x194a>
    d6be:	4c 89 e7             	mov    %r12,%rdi
    d6c1:	e8 4a 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d6c6:	e9 0e ee ff ff       	jmp    c4d9 <f0+0x19e9>
    d6cb:	4c 89 e7             	mov    %r12,%rdi
    d6ce:	e8 3d 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d6d3:	e9 a0 ee ff ff       	jmp    c578 <f0+0x1a88>
    d6d8:	4c 89 e7             	mov    %r12,%rdi
    d6db:	e8 30 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d6e0:	e9 32 ef ff ff       	jmp    c617 <f0+0x1b27>
    d6e5:	4c 89 e7             	mov    %r12,%rdi
    d6e8:	e8 23 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d6ed:	e9 c4 ef ff ff       	jmp    c6b6 <f0+0x1bc6>
    d6f2:	4c 89 e7             	mov    %r12,%rdi
    d6f5:	e8 16 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d6fa:	e9 56 f0 ff ff       	jmp    c755 <f0+0x1c65>
    d6ff:	4c 89 e7             	mov    %r12,%rdi
    d702:	e8 09 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d707:	e9 e8 f0 ff ff       	jmp    c7f4 <f0+0x1d04>
    d70c:	4c 89 e7             	mov    %r12,%rdi
    d70f:	e8 fc 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d714:	e9 7a f1 ff ff       	jmp    c893 <f0+0x1da3>
    d719:	4c 89 e7             	mov    %r12,%rdi
    d71c:	e8 ef 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d721:	e9 0c f2 ff ff       	jmp    c932 <f0+0x1e42>
    d726:	4c 89 e7             	mov    %r12,%rdi
    d729:	e8 e2 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d72e:	e9 9e f2 ff ff       	jmp    c9d1 <f0+0x1ee1>
    d733:	4c 89 e7             	mov    %r12,%rdi
    d736:	e8 d5 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d73b:	e9 30 f3 ff ff       	jmp    ca70 <f0+0x1f80>
    d740:	4c 89 e7             	mov    %r12,%rdi
    d743:	e8 c8 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d748:	e9 c2 f3 ff ff       	jmp    cb0f <f0+0x201f>
    d74d:	4c 89 e7             	mov    %r12,%rdi
    d750:	e8 bb 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d755:	e9 54 f4 ff ff       	jmp    cbae <f0+0x20be>
    d75a:	4c 89 e7             	mov    %r12,%rdi
    d75d:	e8 ae 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d762:	e9 e6 f4 ff ff       	jmp    cc4d <f0+0x215d>
    d767:	4c 89 e7             	mov    %r12,%rdi
    d76a:	e8 a1 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d76f:	e9 78 f5 ff ff       	jmp    ccec <f0+0x21fc>
    d774:	4c 89 e7             	mov    %r12,%rdi
    d777:	e8 94 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d77c:	e9 0a f6 ff ff       	jmp    cd8b <f0+0x229b>
    d781:	4c 89 e7             	mov    %r12,%rdi
    d784:	e8 87 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d789:	e9 9c f6 ff ff       	jmp    ce2a <f0+0x233a>
    d78e:	4c 89 e7             	mov    %r12,%rdi
    d791:	e8 7a 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d796:	e9 2e f7 ff ff       	jmp    cec9 <f0+0x23d9>
    d79b:	4c 89 e7             	mov    %r12,%rdi
    d79e:	e8 6d 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d7a3:	e9 c0 f7 ff ff       	jmp    cf68 <f0+0x2478>
    d7a8:	4c 89 e7             	mov    %r12,%rdi
    d7ab:	e8 60 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d7b0:	e9 52 f8 ff ff       	jmp    d007 <f0+0x2517>
    d7b5:	4c 89 e7             	mov    %r12,%rdi
    d7b8:	e8 53 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d7bd:	e9 e4 f8 ff ff       	jmp    d0a6 <f0+0x25b6>
    d7c2:	4c 89 e7             	mov    %r12,%rdi
    d7c5:	e8 46 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d7ca:	e9 76 f9 ff ff       	jmp    d145 <f0+0x2655>
    d7cf:	4c 89 e7             	mov    %r12,%rdi
    d7d2:	e8 39 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d7d7:	e9 08 fa ff ff       	jmp    d1e4 <f0+0x26f4>
    d7dc:	4c 89 e7             	mov    %r12,%rdi
    d7df:	e8 2c 7b ff ff       	call   5310 <fwp_rc_forget_slot>
    d7e4:	e9 9a fa ff ff       	jmp    d283 <f0+0x2793>
    d7e9:	e8 72 5c ff ff       	call   3460 <__stack_chk_fail@plt>
    d7ee:	66 90                	xchg   %ax,%ax

000000000000d7f0 <fwp_main_thread>:
    d7f0:	f3 0f 1e fa          	endbr64
    d7f4:	41 54                	push   %r12
    d7f6:	55                   	push   %rbp
    d7f7:	53                   	push   %rbx
    d7f8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    d7ff:	8b 0d ff 72 01 00    	mov    0x172ff(%rip),%ecx        # 24b04 <fwp_heap+0x13a4>
    d805:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    d80c:	00 00 
    d80e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    d815:	00 
    d816:	31 c0                	xor    %eax,%eax
    d818:	85 c9                	test   %ecx,%ecx
    d81a:	0f 84 68 06 00 00    	je     de88 <fwp_main_thread+0x698>
    d820:	8b 15 e2 72 01 00    	mov    0x172e2(%rip),%edx        # 24b08 <fwp_heap+0x13a8>
    d826:	85 d2                	test   %edx,%edx
    d828:	0f 85 42 06 00 00    	jne    de70 <fwp_main_thread+0x680>
    d82e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    d833:	31 f6                	xor    %esi,%esi
    d835:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    d83a:	48 c7 05 b3 58 01 00 	movq   $0x40000000,0x158b3(%rip)        # 230f8 <fwp_main_stack_size>
    d841:	00 00 00 40 
    d845:	48 89 05 b4 58 01 00 	mov    %rax,0x158b4(%rip)        # 23100 <fwp_main_stack_top>
    d84c:	48 8d 05 2d 58 00 00 	lea    0x582d(%rip),%rax        # 13080 <alt.5>
    d853:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    d858:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    d85f:	01 00 
    d861:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    d868:	00 
    d869:	e8 52 5e ff ff       	call   36c0 <sigaltstack@plt>
    d86e:	85 c0                	test   %eax,%eax
    d870:	0f 85 4a 06 00 00    	jne    dec0 <fwp_main_thread+0x6d0>
    d876:	31 c0                	xor    %eax,%eax
    d878:	b9 12 00 00 00       	mov    $0x12,%ecx
    d87d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d882:	f3 48 ab             	rep stos %rax,(%rdi)
    d885:	48 8d 05 64 64 ff ff 	lea    -0x9b9c(%rip),%rax        # 3cf0 <fwp_segv>
    d88c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d891:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    d898:	04 00 00 08 
    d89c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    d8a1:	e8 da 5c ff ff       	call   3580 <sigemptyset@plt>
    d8a6:	85 c0                	test   %eax,%eax
    d8a8:	0f 85 12 06 00 00    	jne    dec0 <fwp_main_thread+0x6d0>
    d8ae:	31 d2                	xor    %edx,%edx
    d8b0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d8b5:	bf 0b 00 00 00       	mov    $0xb,%edi
    d8ba:	e8 41 5b ff ff       	call   3400 <sigaction@plt>
    d8bf:	85 c0                	test   %eax,%eax
    d8c1:	0f 85 f9 05 00 00    	jne    dec0 <fwp_main_thread+0x6d0>
    d8c7:	31 d2                	xor    %edx,%edx
    d8c9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d8ce:	bf 07 00 00 00       	mov    $0x7,%edi
    d8d3:	e8 28 5b ff ff       	call   3400 <sigaction@plt>
    d8d8:	85 c0                	test   %eax,%eax
    d8da:	0f 85 e0 05 00 00    	jne    dec0 <fwp_main_thread+0x6d0>
    d8e0:	8b 05 8a 57 00 00    	mov    0x578a(%rip),%eax        # 13070 <st.3>
    d8e6:	85 c0                	test   %eax,%eax
    d8e8:	0f 84 62 05 00 00    	je     de50 <fwp_main_thread+0x660>
    d8ee:	48 8b 2d 4b 5e 01 00 	mov    0x15e4b(%rip),%rbp        # 23740 <fwp_cur>
    d8f5:	48 85 ed             	test   %rbp,%rbp
    d8f8:	0f 84 72 03 00 00    	je     dc70 <fwp_main_thread+0x480>
    d8fe:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    d903:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    d907:	48 89 eb             	mov    %rbp,%rbx
    d90a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d90f:	0f 84 41 01 00 00    	je     da56 <fwp_main_thread+0x266>
    d915:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    d91a:	0f 84 80 02 00 00    	je     dba0 <fwp_main_thread+0x3b0>
    d920:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    d924:	0f 84 66 02 00 00    	je     db90 <fwp_main_thread+0x3a0>
    d92a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    d92e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    d932:	0f 85 e8 02 00 00    	jne    dc20 <fwp_main_thread+0x430>
    d938:	48 8b 43 60          	mov    0x60(%rbx),%rax
    d93c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    d943:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    d947:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    d94e:	00 00 00 00 
    d952:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    d959:	48 85 d2             	test   %rdx,%rdx
    d95c:	74 07                	je     d965 <fwp_main_thread+0x175>
    d95e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    d965:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    d969:	48 85 c0             	test   %rax,%rax
    d96c:	74 34                	je     d9a2 <fwp_main_thread+0x1b2>
    d96e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    d972:	48 8b 05 9f 5d 01 00 	mov    0x15d9f(%rip),%rax        # 23718 <fwp_timers>
    d979:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    d97d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    d984:	00 00 00 00 
    d988:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    d98f:	48 85 c0             	test   %rax,%rax
    d992:	74 07                	je     d99b <fwp_main_thread+0x1ab>
    d994:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    d99b:	48 89 1d 76 5d 01 00 	mov    %rbx,0x15d76(%rip)        # 23718 <fwp_timers>
    d9a2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    d9a6:	e8 c5 98 ff ff       	call   7270 <fwp_block>
    d9ab:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    d9b2:	48 85 c9             	test   %rcx,%rcx
    d9b5:	74 47                	je     d9fe <fwp_main_thread+0x20e>
    d9b7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    d9be:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    d9c5:	48 85 d2             	test   %rdx,%rdx
    d9c8:	0f 84 92 02 00 00    	je     dc60 <fwp_main_thread+0x470>
    d9ce:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    d9d5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    d9dc:	48 85 c0             	test   %rax,%rax
    d9df:	74 07                	je     d9e8 <fwp_main_thread+0x1f8>
    d9e1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    d9e8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    d9ef:	00 00 00 00 
    d9f3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    d9f7:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    d9fe:	48 8b 0d 3b 5d 01 00 	mov    0x15d3b(%rip),%rcx        # 23740 <fwp_cur>
    da05:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    da09:	0f 84 01 02 00 00    	je     dc10 <fwp_main_thread+0x420>
    da0f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    da16:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    da1d:	48 85 d2             	test   %rdx,%rdx
    da20:	0f 84 fa 03 00 00    	je     de20 <fwp_main_thread+0x630>
    da26:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    da2d:	48 85 c0             	test   %rax,%rax
    da30:	74 07                	je     da39 <fwp_main_thread+0x249>
    da32:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    da39:	66 0f ef c9          	pxor   %xmm1,%xmm1
    da3d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    da41:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    da48:	48 89 cb             	mov    %rcx,%rbx
    da4b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    da50:	0f 85 bf fe ff ff    	jne    d915 <fwp_main_thread+0x125>
    da56:	48 83 3d 7a 79 01 00 	cmpq   $0x0,0x1797a(%rip)        # 253d8 <fwp_state_len>
    da5d:	00 
    da5e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    da62:	0f 84 ba 00 00 00    	je     db22 <fwp_main_thread+0x332>
    da68:	48 39 1d c9 5c 01 00 	cmp    %rbx,0x15cc9(%rip)        # 23738 <fwp_root>
    da6f:	c7 05 07 56 01 00 00 	movl   $0x0,0x15607(%rip)        # 23080 <fwp_exit_code>
    da76:	00 00 00 
    da79:	0f 85 5f 04 00 00    	jne    dede <fwp_main_thread+0x6ee>
    da7f:	48 85 db             	test   %rbx,%rbx
    da82:	0f 84 0e 02 00 00    	je     dc96 <fwp_main_thread+0x4a6>
    da88:	48 8b 15 79 5c 01 00 	mov    0x15c79(%rip),%rdx        # 23708 <fwp_tasks_active>
    da8f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    da93:	48 85 d2             	test   %rdx,%rdx
    da96:	0f 84 fa 01 00 00    	je     dc96 <fwp_main_thread+0x4a6>
    da9c:	0f 1f 40 00          	nopl   0x0(%rax)
    daa0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    daa4:	75 08                	jne    daae <fwp_main_thread+0x2be>
    daa6:	48 89 d7             	mov    %rdx,%rdi
    daa9:	e8 02 66 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    daae:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    dab5:	48 85 d2             	test   %rdx,%rdx
    dab8:	75 e6                	jne    daa0 <fwp_main_thread+0x2b0>
    daba:	eb 31                	jmp    daed <fwp_main_thread+0x2fd>
    dabc:	0f 1f 40 00          	nopl   0x0(%rax)
    dac0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    dac7:	48 89 1d 52 5c 01 00 	mov    %rbx,0x15c52(%rip)        # 23720 <fwp_ready_tail>
    dace:	e8 9d 97 ff ff       	call   7270 <fwp_block>
    dad3:	e8 88 95 ff ff       	call   7060 <fwp_free_zombie>
    dad8:	48 83 3d 28 5c 01 00 	cmpq   $0x0,0x15c28(%rip)        # 23708 <fwp_tasks_active>
    dadf:	00 
    dae0:	0f 84 b0 01 00 00    	je     dc96 <fwp_main_thread+0x4a6>
    dae6:	48 8b 1d 4b 5c 01 00 	mov    0x15c4b(%rip),%rbx        # 23738 <fwp_root>
    daed:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    daf1:	75 db                	jne    dace <fwp_main_thread+0x2de>
    daf3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    daf7:	75 d5                	jne    dace <fwp_main_thread+0x2de>
    daf9:	48 8b 05 20 5c 01 00 	mov    0x15c20(%rip),%rax        # 23720 <fwp_ready_tail>
    db00:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    db04:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    db0b:	00 00 00 00 
    db0f:	48 85 c0             	test   %rax,%rax
    db12:	75 ac                	jne    dac0 <fwp_main_thread+0x2d0>
    db14:	48 89 1d 0d 5c 01 00 	mov    %rbx,0x15c0d(%rip)        # 23728 <fwp_ready_head>
    db1b:	eb aa                	jmp    dac7 <fwp_main_thread+0x2d7>
    db1d:	0f 1f 00             	nopl   (%rax)
    db20:	31 db                	xor    %ebx,%ebx
    db22:	48 83 3d 9e 78 01 00 	cmpq   $0x0,0x1789e(%rip)        # 253c8 <fwp_state_owners>
    db29:	00 
    db2a:	0f 85 38 ff ff ff    	jne    da68 <fwp_main_thread+0x278>
    db30:	48 8b 3d a9 78 01 00 	mov    0x178a9(%rip),%rdi        # 253e0 <fwp_state>
    db37:	e8 14 7a ff ff       	call   5550 <fwp_mem_free>
    db3c:	48 c7 05 99 78 01 00 	movq   $0x0,0x17899(%rip)        # 253e0 <fwp_state>
    db43:	00 00 00 00 
    db47:	48 c7 05 7e 78 01 00 	movq   $0x0,0x1787e(%rip)        # 253d0 <fwp_state_cap>
    db4e:	00 00 00 00 
    db52:	48 85 db             	test   %rbx,%rbx
    db55:	0f 84 46 03 00 00    	je     dea1 <fwp_main_thread+0x6b1>
    db5b:	48 39 1d d6 5b 01 00 	cmp    %rbx,0x15bd6(%rip)        # 23738 <fwp_root>
    db62:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    db69:	00 00 00 00 
    db6d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    db74:	00 00 00 00 
    db78:	c7 05 fe 54 01 00 00 	movl   $0x0,0x154fe(%rip)        # 23080 <fwp_exit_code>
    db7f:	00 00 00 
    db82:	0f 84 00 ff ff ff    	je     da88 <fwp_main_thread+0x298>
    db88:	e9 c8 5b ff ff       	jmp    3755 <fwp_main_thread.cold>
    db8d:	0f 1f 00             	nopl   (%rax)
    db90:	e8 7b 67 ff ff       	call   4310 <fwp_now_ns>
    db95:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    db99:	0f 8d 91 02 00 00    	jge    de30 <fwp_main_thread+0x640>
    db9f:	90                   	nop
    dba0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    dba4:	0f 85 80 fd ff ff    	jne    d92a <fwp_main_thread+0x13a>
    dbaa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    dbae:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    dbb2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dbb6:	0f 85 80 fd ff ff    	jne    d93c <fwp_main_thread+0x14c>
    dbbc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    dbc0:	48 85 c9             	test   %rcx,%rcx
    dbc3:	0f 84 73 fd ff ff    	je     d93c <fwp_main_thread+0x14c>
    dbc9:	48 85 c0             	test   %rax,%rax
    dbcc:	0f 84 ff 02 00 00    	je     ded1 <fwp_main_thread+0x6e1>
    dbd2:	48 39 c8             	cmp    %rcx,%rax
    dbd5:	48 0f 4f c1          	cmovg  %rcx,%rax
    dbd9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dbe0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    dbe4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dbeb:	00 00 00 00 
    dbef:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    dbf6:	48 85 d2             	test   %rdx,%rdx
    dbf9:	74 07                	je     dc02 <fwp_main_thread+0x412>
    dbfb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    dc02:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dc06:	e9 63 fd ff ff       	jmp    d96e <fwp_main_thread+0x17e>
    dc0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    dc10:	48 89 cb             	mov    %rcx,%rbx
    dc13:	e9 f2 fc ff ff       	jmp    d90a <fwp_main_thread+0x11a>
    dc18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dc1f:	00 
    dc20:	48 8b 45 40          	mov    0x40(%rbp),%rax
    dc24:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dc2b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dc32:	00 00 00 00 
    dc36:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    dc3d:	48 85 c0             	test   %rax,%rax
    dc40:	0f 84 52 02 00 00    	je     de98 <fwp_main_thread+0x6a8>
    dc46:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    dc4d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dc51:	e9 4c fd ff ff       	jmp    d9a2 <fwp_main_thread+0x1b2>
    dc56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dc5d:	00 00 00 
    dc60:	48 89 01             	mov    %rax,(%rcx)
    dc63:	e9 74 fd ff ff       	jmp    d9dc <fwp_main_thread+0x1ec>
    dc68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dc6f:	00 
    dc70:	48 83 3d 60 77 01 00 	cmpq   $0x0,0x17760(%rip)        # 253d8 <fwp_state_len>
    dc77:	00 
    dc78:	0f 84 a2 fe ff ff    	je     db20 <fwp_main_thread+0x330>
    dc7e:	48 83 3d b2 5a 01 00 	cmpq   $0x0,0x15ab2(%rip)        # 23738 <fwp_root>
    dc85:	00 
    dc86:	c7 05 f0 53 01 00 00 	movl   $0x0,0x153f0(%rip)        # 23080 <fwp_exit_code>
    dc8d:	00 00 00 
    dc90:	0f 85 43 02 00 00    	jne    ded9 <fwp_main_thread+0x6e9>
    dc96:	e8 c5 93 ff ff       	call   7060 <fwp_free_zombie>
    dc9b:	48 83 3d 85 5a 01 00 	cmpq   $0x0,0x15a85(%rip)        # 23728 <fwp_ready_head>
    dca2:	00 
    dca3:	0f 85 ac 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dca9:	48 83 3d 67 5a 01 00 	cmpq   $0x0,0x15a67(%rip)        # 23718 <fwp_timers>
    dcb0:	00 
    dcb1:	0f 85 9e 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dcb7:	8b 1d 4f 54 01 00    	mov    0x1544f(%rip),%ebx        # 2310c <fwp_stack_pool_n>
    dcbd:	85 db                	test   %ebx,%ebx
    dcbf:	74 36                	je     dcf7 <fwp_main_thread+0x507>
    dcc1:	83 eb 01             	sub    $0x1,%ebx
    dcc4:	48 8d 05 55 54 01 00 	lea    0x15455(%rip),%rax        # 23120 <fwp_stack_pool>
    dccb:	48 63 d3             	movslq %ebx,%rdx
    dcce:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    dcd2:	eb 07                	jmp    dcdb <fwp_main_thread+0x4eb>
    dcd4:	0f 1f 40 00          	nopl   0x0(%rax)
    dcd8:	83 eb 01             	sub    $0x1,%ebx
    dcdb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    dcdf:	be 00 00 00 10       	mov    $0x10000000,%esi
    dce4:	89 1d 22 54 01 00    	mov    %ebx,0x15422(%rip)        # 2310c <fwp_stack_pool_n>
    dcea:	48 83 ed 08          	sub    $0x8,%rbp
    dcee:	e8 ed 58 ff ff       	call   35e0 <munmap@plt>
    dcf3:	85 db                	test   %ebx,%ebx
    dcf5:	75 e1                	jne    dcd8 <fwp_main_thread+0x4e8>
    dcf7:	8b 3d 1b 53 00 00    	mov    0x531b(%rip),%edi        # 13018 <fwp_epfd>
    dcfd:	85 ff                	test   %edi,%edi
    dcff:	78 05                	js     dd06 <fwp_main_thread+0x516>
    dd01:	e8 ca 57 ff ff       	call   34d0 <close@plt>
    dd06:	4c 8b 25 13 56 01 00 	mov    0x15613(%rip),%r12        # 23320 <fwp_nfdws>
    dd0d:	48 8b 2d 14 56 01 00 	mov    0x15614(%rip),%rbp        # 23328 <fwp_fdws>
    dd14:	31 db                	xor    %ebx,%ebx
    dd16:	c7 05 f8 52 00 00 ff 	movl   $0xffffffff,0x52f8(%rip)        # 13018 <fwp_epfd>
    dd1d:	ff ff ff 
    dd20:	4d 85 e4             	test   %r12,%r12
    dd23:	74 38                	je     dd5d <fwp_main_thread+0x56d>
    dd25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    dd2c:	00 00 00 00 
    dd30:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    dd35:	48 85 ff             	test   %rdi,%rdi
    dd38:	74 1a                	je     dd54 <fwp_main_thread+0x564>
    dd3a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    dd3e:	0f 85 11 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dd44:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    dd49:	0f 85 06 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dd4f:	e8 fc 77 ff ff       	call   5550 <fwp_mem_free>
    dd54:	48 83 c3 01          	add    $0x1,%rbx
    dd58:	4c 39 e3             	cmp    %r12,%rbx
    dd5b:	75 d3                	jne    dd30 <fwp_main_thread+0x540>
    dd5d:	48 89 ef             	mov    %rbp,%rdi
    dd60:	e8 eb 77 ff ff       	call   5550 <fwp_mem_free>
    dd65:	48 8b 15 cc 59 01 00 	mov    0x159cc(%rip),%rdx        # 23738 <fwp_root>
    dd6c:	48 c7 05 b1 55 01 00 	movq   $0x0,0x155b1(%rip)        # 23328 <fwp_fdws>
    dd73:	00 00 00 00 
    dd77:	48 c7 05 9e 55 01 00 	movq   $0x0,0x1559e(%rip)        # 23320 <fwp_nfdws>
    dd7e:	00 00 00 00 
    dd82:	48 85 d2             	test   %rdx,%rdx
    dd85:	74 4e                	je     ddd5 <fwp_main_thread+0x5e5>
    dd87:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    dd8c:	0f 85 c3 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    dd92:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    dd99:	00 
    dd9a:	0f 85 b5 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    dda0:	48 83 3d 30 76 01 00 	cmpq   $0x0,0x17630(%rip)        # 253d8 <fwp_state_len>
    dda7:	00 
    dda8:	0f 85 a7 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    ddae:	48 83 3d 12 76 01 00 	cmpq   $0x0,0x17612(%rip)        # 253c8 <fwp_state_owners>
    ddb5:	00 
    ddb6:	0f 85 99 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    ddbc:	b9 79 00 00 00       	mov    $0x79,%ecx
    ddc1:	31 c0                	xor    %eax,%eax
    ddc3:	48 8d 3d 76 55 01 00 	lea    0x15576(%rip),%rdi        # 23340 <fwp_root_context>
    ddca:	f3 48 ab             	rep stos %rax,(%rdi)
    ddcd:	48 89 d7             	mov    %rdx,%rdi
    ddd0:	e8 7b 77 ff ff       	call   5550 <fwp_mem_free>
    ddd5:	48 8b 3d 44 52 00 00 	mov    0x5244(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    dddc:	48 c7 05 59 59 01 00 	movq   $0x0,0x15959(%rip)        # 23740 <fwp_cur>
    dde3:	00 00 00 00 
    dde7:	48 c7 05 46 59 01 00 	movq   $0x0,0x15946(%rip)        # 23738 <fwp_root>
    ddee:	00 00 00 00 
    ddf2:	e8 c9 57 ff ff       	call   35c0 <fflush@plt>
    ddf7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    ddfe:	00 
    ddff:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    de06:	00 00 
    de08:	0f 85 be 00 00 00    	jne    decc <fwp_main_thread+0x6dc>
    de0e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    de15:	31 c0                	xor    %eax,%eax
    de17:	5b                   	pop    %rbx
    de18:	5d                   	pop    %rbp
    de19:	41 5c                	pop    %r12
    de1b:	c3                   	ret
    de1c:	0f 1f 40 00          	nopl   0x0(%rax)
    de20:	48 89 05 f1 58 01 00 	mov    %rax,0x158f1(%rip)        # 23718 <fwp_timers>
    de27:	e9 01 fc ff ff       	jmp    da2d <fwp_main_thread+0x23d>
    de2c:	0f 1f 40 00          	nopl   0x0(%rax)
    de30:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    de34:	0f 85 66 fd ff ff    	jne    dba0 <fwp_main_thread+0x3b0>
    de3a:	48 89 ef             	mov    %rbp,%rdi
    de3d:	e8 6e 62 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    de42:	e9 59 fd ff ff       	jmp    dba0 <fwp_main_thread+0x3b0>
    de47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    de4e:	00 00 
    de50:	e8 9b cc ff ff       	call   aaf0 <f0>
    de55:	48 c7 05 08 52 00 00 	movq   $0x0,0x5208(%rip)        # 13068 <v.2>
    de5c:	00 00 00 00 
    de60:	c7 05 06 52 00 00 01 	movl   $0x1,0x5206(%rip)        # 13070 <st.3>
    de67:	00 00 00 
    de6a:	e9 7f fa ff ff       	jmp    d8ee <fwp_main_thread+0xfe>
    de6f:	90                   	nop
    de70:	48 8d 3d a9 6b ff ff 	lea    -0x9457(%rip),%rdi        # 4a20 <fwp_heap_report>
    de77:	e8 84 02 00 00       	call   e100 <atexit>
    de7c:	e9 ad f9 ff ff       	jmp    d82e <fwp_main_thread+0x3e>
    de81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    de88:	e8 a3 6c ff ff       	call   4b30 <fwp_heap_init>
    de8d:	e9 8e f9 ff ff       	jmp    d820 <fwp_main_thread+0x30>
    de92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    de98:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    de9c:	e9 01 fb ff ff       	jmp    d9a2 <fwp_main_thread+0x1b2>
    dea1:	48 83 3d 8f 58 01 00 	cmpq   $0x0,0x1588f(%rip)        # 23738 <fwp_root>
    dea8:	00 
    dea9:	c7 05 cd 51 01 00 00 	movl   $0x0,0x151cd(%rip)        # 23080 <fwp_exit_code>
    deb0:	00 00 00 
    deb3:	0f 84 dd fd ff ff    	je     dc96 <fwp_main_thread+0x4a6>
    deb9:	e9 97 58 ff ff       	jmp    3755 <fwp_main_thread.cold>
    debe:	66 90                	xchg   %ax,%ax
    dec0:	48 8d 3d 31 1a 00 00 	lea    0x1a31(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    dec7:	e8 d4 62 ff ff       	call   41a0 <fwp_trap>
    decc:	e8 8f 55 ff ff       	call   3460 <__stack_chk_fail@plt>
    ded1:	48 89 c8             	mov    %rcx,%rax
    ded4:	e9 00 fd ff ff       	jmp    dbd9 <fwp_main_thread+0x3e9>
    ded9:	e9 77 58 ff ff       	jmp    3755 <fwp_main_thread.cold>
    dede:	e9 72 58 ff ff       	jmp    3755 <fwp_main_thread.cold>
    dee3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    deea:	00 00 00 
    deed:	0f 1f 00             	nopl   (%rax)

000000000000def0 <__divmodti4>:
    def0:	f3 0f 1e fa          	endbr64
    def4:	55                   	push   %rbp
    def5:	49 89 f1             	mov    %rsi,%r9
    def8:	49 89 d2             	mov    %rdx,%r10
    defb:	48 89 fe             	mov    %rdi,%rsi
    defe:	49 89 cb             	mov    %rcx,%r11
    df01:	48 89 e5             	mov    %rsp,%rbp
    df04:	41 57                	push   %r15
    df06:	41 56                	push   %r14
    df08:	41 55                	push   %r13
    df0a:	41 54                	push   %r12
    df0c:	53                   	push   %rbx
    df0d:	4c 89 c3             	mov    %r8,%rbx
    df10:	45 31 c0             	xor    %r8d,%r8d
    df13:	4d 85 c9             	test   %r9,%r9
    df16:	79 12                	jns    df2a <__divmodti4+0x3a>
    df18:	31 ff                	xor    %edi,%edi
    df1a:	48 f7 de             	neg    %rsi
    df1d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    df24:	4c 19 cf             	sbb    %r9,%rdi
    df27:	49 89 f9             	mov    %rdi,%r9
    df2a:	4c 89 d8             	mov    %r11,%rax
    df2d:	4d 85 db             	test   %r11,%r11
    df30:	0f 88 1a 01 00 00    	js     e050 <__divmodti4+0x160>
    df36:	4c 89 d9             	mov    %r11,%rcx
    df39:	49 89 f3             	mov    %rsi,%r11
    df3c:	75 62                	jne    dfa0 <__divmodti4+0xb0>
    df3e:	4d 89 c4             	mov    %r8,%r12
    df41:	4d 39 d1             	cmp    %r10,%r9
    df44:	0f 83 46 01 00 00    	jae    e090 <__divmodti4+0x1a0>
    df4a:	4c 89 d8             	mov    %r11,%rax
    df4d:	4c 89 ca             	mov    %r9,%rdx
    df50:	49 f7 f2             	div    %r10
    df53:	49 89 c3             	mov    %rax,%r11
    df56:	31 c0                	xor    %eax,%eax
    df58:	48 89 d6             	mov    %rdx,%rsi
    df5b:	31 ff                	xor    %edi,%edi
    df5d:	4c 89 d9             	mov    %r11,%rcx
    df60:	48 89 c2             	mov    %rax,%rdx
    df63:	48 89 c8             	mov    %rcx,%rax
    df66:	4d 85 e4             	test   %r12,%r12
    df69:	74 0a                	je     df75 <__divmodti4+0x85>
    df6b:	48 f7 d8             	neg    %rax
    df6e:	48 83 d2 00          	adc    $0x0,%rdx
    df72:	48 f7 da             	neg    %rdx
    df75:	4d 85 c0             	test   %r8,%r8
    df78:	74 0a                	je     df84 <__divmodti4+0x94>
    df7a:	48 f7 de             	neg    %rsi
    df7d:	48 83 d7 00          	adc    $0x0,%rdi
    df81:	48 f7 df             	neg    %rdi
    df84:	48 89 33             	mov    %rsi,(%rbx)
    df87:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    df8b:	5b                   	pop    %rbx
    df8c:	41 5c                	pop    %r12
    df8e:	41 5d                	pop    %r13
    df90:	41 5e                	pop    %r14
    df92:	41 5f                	pop    %r15
    df94:	5d                   	pop    %rbp
    df95:	c3                   	ret
    df96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    df9d:	00 00 00 
    dfa0:	4d 89 c4             	mov    %r8,%r12
    dfa3:	49 39 c1             	cmp    %rax,%r9
    dfa6:	0f 82 ce 00 00 00    	jb     e07a <__divmodti4+0x18a>
    dfac:	31 ff                	xor    %edi,%edi
    dfae:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    dfb3:	48 63 c7             	movslq %edi,%rax
    dfb6:	be 40 00 00 00       	mov    $0x40,%esi
    dfbb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    dfc0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    dfc5:	48 29 c6             	sub    %rax,%rsi
    dfc8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    dfcd:	48 09 c8             	or     %rcx,%rax
    dfd0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    dfd5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    dfda:	49 89 c6             	mov    %rax,%r14
    dfdd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    dfe1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    dfe6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    dfeb:	49 09 c1             	or     %rax,%r9
    dfee:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    dff2:	4c 89 c8             	mov    %r9,%rax
    dff5:	49 f7 f6             	div    %r14
    dff8:	48 89 d1             	mov    %rdx,%rcx
    dffb:	49 89 c3             	mov    %rax,%r11
    dffe:	49 89 c1             	mov    %rax,%r9
    e001:	49 f7 e2             	mul    %r10
    e004:	49 89 c6             	mov    %rax,%r14
    e007:	49 89 d2             	mov    %rdx,%r10
    e00a:	48 39 d1             	cmp    %rdx,%rcx
    e00d:	72 07                	jb     e016 <__divmodti4+0x126>
    e00f:	75 17                	jne    e028 <__divmodti4+0x138>
    e011:	49 39 c7             	cmp    %rax,%r15
    e014:	73 12                	jae    e028 <__divmodti4+0x138>
    e016:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e01a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e01e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e022:	49 89 d2             	mov    %rdx,%r10
    e025:	49 89 c6             	mov    %rax,%r14
    e028:	4c 89 f8             	mov    %r15,%rax
    e02b:	4c 29 f0             	sub    %r14,%rax
    e02e:	4c 19 d1             	sbb    %r10,%rcx
    e031:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e036:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e03b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e040:	48 09 c6             	or     %rax,%rsi
    e043:	48 89 cf             	mov    %rcx,%rdi
    e046:	31 c0                	xor    %eax,%eax
    e048:	4c 89 c9             	mov    %r9,%rcx
    e04b:	e9 10 ff ff ff       	jmp    df60 <__divmodti4+0x70>
    e050:	4c 89 d0             	mov    %r10,%rax
    e053:	4c 89 da             	mov    %r11,%rdx
    e056:	4d 89 c4             	mov    %r8,%r12
    e059:	49 89 f3             	mov    %rsi,%r11
    e05c:	48 f7 d8             	neg    %rax
    e05f:	49 f7 d4             	not    %r12
    e062:	48 83 d2 00          	adc    $0x0,%rdx
    e066:	49 89 c2             	mov    %rax,%r10
    e069:	48 f7 da             	neg    %rdx
    e06c:	48 89 d1             	mov    %rdx,%rcx
    e06f:	0f 84 cc fe ff ff    	je     df41 <__divmodti4+0x51>
    e075:	49 39 d1             	cmp    %rdx,%r9
    e078:	73 46                	jae    e0c0 <__divmodti4+0x1d0>
    e07a:	4c 89 cf             	mov    %r9,%rdi
    e07d:	31 c0                	xor    %eax,%eax
    e07f:	31 c9                	xor    %ecx,%ecx
    e081:	e9 da fe ff ff       	jmp    df60 <__divmodti4+0x70>
    e086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e08d:	00 00 00 
    e090:	4d 85 d2             	test   %r10,%r10
    e093:	75 0d                	jne    e0a2 <__divmodti4+0x1b2>
    e095:	b8 01 00 00 00       	mov    $0x1,%eax
    e09a:	31 d2                	xor    %edx,%edx
    e09c:	49 f7 f2             	div    %r10
    e09f:	49 89 c2             	mov    %rax,%r10
    e0a2:	4c 89 c8             	mov    %r9,%rax
    e0a5:	31 d2                	xor    %edx,%edx
    e0a7:	49 f7 f2             	div    %r10
    e0aa:	49 89 c1             	mov    %rax,%r9
    e0ad:	4c 89 d8             	mov    %r11,%rax
    e0b0:	49 f7 f2             	div    %r10
    e0b3:	49 89 c3             	mov    %rax,%r11
    e0b6:	4c 89 c8             	mov    %r9,%rax
    e0b9:	e9 9a fe ff ff       	jmp    df58 <__divmodti4+0x68>
    e0be:	66 90                	xchg   %ax,%ax
    e0c0:	45 31 f6             	xor    %r14d,%r14d
    e0c3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e0c8:	44 89 f7             	mov    %r14d,%edi
    e0cb:	45 85 f6             	test   %r14d,%r14d
    e0ce:	0f 85 df fe ff ff    	jne    dfb3 <__divmodti4+0xc3>
    e0d4:	4c 39 ca             	cmp    %r9,%rdx
    e0d7:	72 17                	jb     e0f0 <__divmodti4+0x200>
    e0d9:	31 c9                	xor    %ecx,%ecx
    e0db:	48 39 c6             	cmp    %rax,%rsi
    e0de:	73 10                	jae    e0f0 <__divmodti4+0x200>
    e0e0:	4c 89 cf             	mov    %r9,%rdi
    e0e3:	31 c0                	xor    %eax,%eax
    e0e5:	e9 76 fe ff ff       	jmp    df60 <__divmodti4+0x70>
    e0ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e0f0:	4c 89 de             	mov    %r11,%rsi
    e0f3:	b9 01 00 00 00       	mov    $0x1,%ecx
    e0f8:	48 29 c6             	sub    %rax,%rsi
    e0fb:	49 19 d1             	sbb    %rdx,%r9
    e0fe:	eb e0                	jmp    e0e0 <__divmodti4+0x1f0>

000000000000e100 <atexit>:
    e100:	f3 0f 1e fa          	endbr64
    e104:	48 8b 15 fd 4e 00 00 	mov    0x4efd(%rip),%rdx        # 13008 <__dso_handle>
    e10b:	31 f6                	xor    %esi,%esi
    e10d:	e9 4e 55 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e114 <_fini>:
    e114:	f3 0f 1e fa          	endbr64
    e118:	48 83 ec 08          	sub    $0x8,%rsp
    e11c:	48 83 c4 08          	add    $0x8,%rsp
    e120:	c3                   	ret
