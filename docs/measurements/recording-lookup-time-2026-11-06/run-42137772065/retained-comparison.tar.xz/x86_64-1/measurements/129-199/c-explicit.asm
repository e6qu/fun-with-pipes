
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/c-explicit:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 d9 2f 00 00 	mov    0x2fd9(%rip),%rax        # 3fe8 <__gmon_start__>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 72 2f 00 00    	push   0x2f72(%rip)        # 3f98 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 74 2f 00 00    	jmp    *0x2f74(%rip)        # 3fa0 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)
    1030:	f3 0f 1e fa          	endbr64
    1034:	68 00 00 00 00       	push   $0x0
    1039:	e9 e2 ff ff ff       	jmp    1020 <_init+0x20>
    103e:	66 90                	xchg   %ax,%ax
    1040:	f3 0f 1e fa          	endbr64
    1044:	68 01 00 00 00       	push   $0x1
    1049:	e9 d2 ff ff ff       	jmp    1020 <_init+0x20>
    104e:	66 90                	xchg   %ax,%ax
    1050:	f3 0f 1e fa          	endbr64
    1054:	68 02 00 00 00       	push   $0x2
    1059:	e9 c2 ff ff ff       	jmp    1020 <_init+0x20>
    105e:	66 90                	xchg   %ax,%ax
    1060:	f3 0f 1e fa          	endbr64
    1064:	68 03 00 00 00       	push   $0x3
    1069:	e9 b2 ff ff ff       	jmp    1020 <_init+0x20>
    106e:	66 90                	xchg   %ax,%ax
    1070:	f3 0f 1e fa          	endbr64
    1074:	68 04 00 00 00       	push   $0x4
    1079:	e9 a2 ff ff ff       	jmp    1020 <_init+0x20>
    107e:	66 90                	xchg   %ax,%ax
    1080:	f3 0f 1e fa          	endbr64
    1084:	68 05 00 00 00       	push   $0x5
    1089:	e9 92 ff ff ff       	jmp    1020 <_init+0x20>
    108e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000001090 <__cxa_finalize@plt>:
    1090:	f3 0f 1e fa          	endbr64
    1094:	ff 25 5e 2f 00 00    	jmp    *0x2f5e(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    109a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000010a0 <free@plt>:
    10a0:	f3 0f 1e fa          	endbr64
    10a4:	ff 25 fe 2e 00 00    	jmp    *0x2efe(%rip)        # 3fa8 <free@GLIBC_2.2.5>
    10aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010b0 <puts@plt>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	ff 25 f6 2e 00 00    	jmp    *0x2ef6(%rip)        # 3fb0 <puts@GLIBC_2.2.5>
    10ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010c0 <ferror@plt>:
    10c0:	f3 0f 1e fa          	endbr64
    10c4:	ff 25 ee 2e 00 00    	jmp    *0x2eee(%rip)        # 3fb8 <ferror@GLIBC_2.2.5>
    10ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010d0 <putc@plt>:
    10d0:	f3 0f 1e fa          	endbr64
    10d4:	ff 25 e6 2e 00 00    	jmp    *0x2ee6(%rip)        # 3fc0 <putc@GLIBC_2.2.5>
    10da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010e0 <malloc@plt>:
    10e0:	f3 0f 1e fa          	endbr64
    10e4:	ff 25 de 2e 00 00    	jmp    *0x2ede(%rip)        # 3fc8 <malloc@GLIBC_2.2.5>
    10ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010f0 <__printf_chk@plt>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	ff 25 d6 2e 00 00    	jmp    *0x2ed6(%rip)        # 3fd0 <__printf_chk@GLIBC_2.3.4>
    10fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000001100 <main>:
    1100:	f3 0f 1e fa          	endbr64
    1104:	41 55                	push   %r13
    1106:	41 54                	push   %r12
    1108:	41 bc 08 00 00 00    	mov    $0x8,%r12d
    110e:	55                   	push   %rbp
    110f:	53                   	push   %rbx
    1110:	48 83 ec 08          	sub    $0x8,%rsp
    1114:	bf 08 04 00 00       	mov    $0x408,%edi
    1119:	e8 c2 ff ff ff       	call   10e0 <malloc@plt>
    111e:	bf 08 04 00 00       	mov    $0x408,%edi
    1123:	48 89 c3             	mov    %rax,%rbx
    1126:	e8 b5 ff ff ff       	call   10e0 <malloc@plt>
    112b:	48 89 c5             	mov    %rax,%rbp
    112e:	48 85 db             	test   %rbx,%rbx
    1131:	0f 84 21 02 00 00    	je     1358 <main+0x258>
    1137:	48 85 c0             	test   %rax,%rax
    113a:	66 0f 28 15 fe 0e 00 	movapd 0xefe(%rip),%xmm2        # 2040 <_IO_stdin_used+0x40>
    1141:	00 
    1142:	0f 84 10 02 00 00    	je     1358 <main+0x258>
    1148:	31 c0                	xor    %eax,%eax
    114a:	a8 01                	test   $0x1,%al
    114c:	74 13                	je     1161 <main+0x61>
    114e:	48 8b 35 bb 0e 00 00 	mov    0xebb(%rip),%rsi        # 2010 <_IO_stdin_used+0x10>
    1155:	48 89 34 c3          	mov    %rsi,(%rbx,%rax,8)
    1159:	48 83 c0 01          	add    $0x1,%rax
    115d:	a8 01                	test   $0x1,%al
    115f:	75 ed                	jne    114e <main+0x4e>
    1161:	48 8b 0d b0 0e 00 00 	mov    0xeb0(%rip),%rcx        # 2018 <_IO_stdin_used+0x18>
    1168:	48 89 0c c3          	mov    %rcx,(%rbx,%rax,8)
    116c:	48 83 c0 01          	add    $0x1,%rax
    1170:	48 3d 81 00 00 00    	cmp    $0x81,%rax
    1176:	75 d2                	jne    114a <main+0x4a>
    1178:	f2 0f 10 1d c0 0e 00 	movsd  0xec0(%rip),%xmm3        # 2040 <_IO_stdin_used+0x40>
    117f:	00 
    1180:	be c7 00 00 00       	mov    $0xc7,%esi
    1185:	31 c0                	xor    %eax,%eax
    1187:	b9 81 00 00 00       	mov    $0x81,%ecx
    118c:	48 89 ef             	mov    %rbp,%rdi
    118f:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    1193:	31 d2                	xor    %edx,%edx
    1195:	f3 48 ab             	rep stos %rax,(%rdi)
    1198:	66 0f ef c0          	pxor   %xmm0,%xmm0
    119c:	0f 1f 40 00          	nopl   0x0(%rax)
    11a0:	66 0f 28 f9          	movapd %xmm1,%xmm7
    11a4:	f2 0f 10 4c 13 08    	movsd  0x8(%rbx,%rdx,1),%xmm1
    11aa:	f2 0f 10 35 5e 0e 00 	movsd  0xe5e(%rip),%xmm6        # 2010 <_IO_stdin_used+0x10>
    11b1:	00 
    11b2:	66 0f 28 e7          	movapd %xmm7,%xmm4
    11b6:	f2 0f 59 e7          	mulsd  %xmm7,%xmm4
    11ba:	66 0f 28 e9          	movapd %xmm1,%xmm5
    11be:	f2 0f 5c f7          	subsd  %xmm7,%xmm6
    11c2:	f2 0f 58 f6          	addsd  %xmm6,%xmm6
    11c6:	f2 0f 5c ec          	subsd  %xmm4,%xmm5
    11ca:	f2 0f 10 25 4e 0e 00 	movsd  0xe4e(%rip),%xmm4        # 2020 <_IO_stdin_used+0x20>
    11d1:	00 
    11d2:	f2 0f 59 e7          	mulsd  %xmm7,%xmm4
    11d6:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
    11da:	f2 0f 59 2d 46 0e 00 	mulsd  0xe46(%rip),%xmm5        # 2028 <_IO_stdin_used+0x28>
    11e1:	00 
    11e2:	f2 0f 58 6c 15 08    	addsd  0x8(%rbp,%rdx,1),%xmm5
    11e8:	f2 0f 5c e6          	subsd  %xmm6,%xmm4
    11ec:	f2 0f 11 6c 15 08    	movsd  %xmm5,0x8(%rbp,%rdx,1)
    11f2:	f2 0f 58 e0          	addsd  %xmm0,%xmm4
    11f6:	66 0f 28 c5          	movapd %xmm5,%xmm0
    11fa:	f2 0f 11 64 15 00    	movsd  %xmm4,0x0(%rbp,%rdx,1)
    1200:	48 83 c2 08          	add    $0x8,%rdx
    1204:	48 81 fa 00 04 00 00 	cmp    $0x400,%rdx
    120b:	75 93                	jne    11a0 <main+0xa0>
    120d:	31 d2                	xor    %edx,%edx
    120f:	66 0f 10 4c 15 00    	movupd 0x0(%rbp,%rdx,1),%xmm1
    1215:	66 0f 10 04 13       	movupd (%rbx,%rdx,1),%xmm0
    121a:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
    121e:	66 0f 5c c1          	subpd  %xmm1,%xmm0
    1222:	0f 11 04 13          	movups %xmm0,(%rbx,%rdx,1)
    1226:	48 83 c2 10          	add    $0x10,%rdx
    122a:	48 81 fa 00 04 00 00 	cmp    $0x400,%rdx
    1231:	75 dc                	jne    120f <main+0x10f>
    1233:	f2 0f 10 8d 00 04 00 	movsd  0x400(%rbp),%xmm1
    123a:	00 
    123b:	f2 0f 10 83 00 04 00 	movsd  0x400(%rbx),%xmm0
    1242:	00 
    1243:	f2 0f 59 cb          	mulsd  %xmm3,%xmm1
    1247:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
    124b:	f2 0f 11 83 00 04 00 	movsd  %xmm0,0x400(%rbx)
    1252:	00 
    1253:	48 83 ee 01          	sub    $0x1,%rsi
    1257:	0f 85 2a ff ff ff    	jne    1187 <main+0x87>
    125d:	f2 0f 10 0d cb 0d 00 	movsd  0xdcb(%rip),%xmm1        # 2030 <_IO_stdin_used+0x30>
    1264:	00 
    1265:	48 89 d8             	mov    %rbx,%rax
    1268:	48 8d 93 08 04 00 00 	lea    0x408(%rbx),%rdx
    126f:	eb 09                	jmp    127a <main+0x17a>
    1271:	48 83 c0 08          	add    $0x8,%rax
    1275:	48 39 c2             	cmp    %rax,%rdx
    1278:	74 32                	je     12ac <main+0x1ac>
    127a:	f2 0f 10 00          	movsd  (%rax),%xmm0
    127e:	66 0f 54 05 ca 0d 00 	andpd  0xdca(%rip),%xmm0        # 2050 <_IO_stdin_used+0x50>
    1285:	00 
    1286:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    128a:	73 e5                	jae    1271 <main+0x171>
    128c:	48 89 df             	mov    %rbx,%rdi
    128f:	e8 0c fe ff ff       	call   10a0 <free@plt>
    1294:	48 89 ef             	mov    %rbp,%rdi
    1297:	e8 04 fe ff ff       	call   10a0 <free@plt>
    129c:	b8 03 00 00 00       	mov    $0x3,%eax
    12a1:	48 83 c4 08          	add    $0x8,%rsp
    12a5:	5b                   	pop    %rbx
    12a6:	5d                   	pop    %rbp
    12a7:	41 5c                	pop    %r12
    12a9:	41 5d                	pop    %r13
    12ab:	c3                   	ret
    12ac:	48 8b 35 5d 2d 00 00 	mov    0x2d5d(%rip),%rsi        # 4010 <stdout@GLIBC_2.2.5>
    12b3:	bf 5b 00 00 00       	mov    $0x5b,%edi
    12b8:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    12be:	e8 0d fe ff ff       	call   10d0 <putc@plt>
    12c3:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    12c7:	bf 02 00 00 00       	mov    $0x2,%edi
    12cc:	48 8d 35 33 0d 00 00 	lea    0xd33(%rip),%rsi        # 2006 <_IO_stdin_used+0x6>
    12d3:	b8 01 00 00 00       	mov    $0x1,%eax
    12d8:	e8 13 fe ff ff       	call   10f0 <__printf_chk@plt>
    12dd:	f2 0f 10 43 08       	movsd  0x8(%rbx),%xmm0
    12e2:	eb 06                	jmp    12ea <main+0x1ea>
    12e4:	f2 42 0f 10 04 eb    	movsd  (%rbx,%r13,8),%xmm0
    12ea:	48 8d 35 13 0d 00 00 	lea    0xd13(%rip),%rsi        # 2004 <_IO_stdin_used+0x4>
    12f1:	bf 02 00 00 00       	mov    $0x2,%edi
    12f6:	b8 01 00 00 00       	mov    $0x1,%eax
    12fb:	49 83 c5 01          	add    $0x1,%r13
    12ff:	e8 ec fd ff ff       	call   10f0 <__printf_chk@plt>
    1304:	49 81 fd 81 00 00 00 	cmp    $0x81,%r13
    130b:	75 d7                	jne    12e4 <main+0x1e4>
    130d:	48 8d 3d f8 0c 00 00 	lea    0xcf8(%rip),%rdi        # 200c <_IO_stdin_used+0xc>
    1314:	e8 97 fd ff ff       	call   10b0 <puts@plt>
    1319:	48 89 df             	mov    %rbx,%rdi
    131c:	e8 7f fd ff ff       	call   10a0 <free@plt>
    1321:	48 89 ef             	mov    %rbp,%rdi
    1324:	e8 77 fd ff ff       	call   10a0 <free@plt>
    1329:	48 8b 3d e0 2c 00 00 	mov    0x2ce0(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    1330:	e8 8b fd ff ff       	call   10c0 <ferror@plt>
    1335:	85 c0                	test   %eax,%eax
    1337:	75 15                	jne    134e <main+0x24e>
    1339:	49 83 ec 01          	sub    $0x1,%r12
    133d:	0f 85 d1 fd ff ff    	jne    1114 <main+0x14>
    1343:	48 83 c4 08          	add    $0x8,%rsp
    1347:	5b                   	pop    %rbx
    1348:	5d                   	pop    %rbp
    1349:	41 5c                	pop    %r12
    134b:	41 5d                	pop    %r13
    134d:	c3                   	ret
    134e:	b8 04 00 00 00       	mov    $0x4,%eax
    1353:	e9 49 ff ff ff       	jmp    12a1 <main+0x1a1>
    1358:	48 89 df             	mov    %rbx,%rdi
    135b:	e8 40 fd ff ff       	call   10a0 <free@plt>
    1360:	48 89 ef             	mov    %rbp,%rdi
    1363:	e8 38 fd ff ff       	call   10a0 <free@plt>
    1368:	b8 02 00 00 00       	mov    $0x2,%eax
    136d:	e9 2f ff ff ff       	jmp    12a1 <main+0x1a1>
    1372:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1379:	00 00 00 
    137c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001380 <_start>:
    1380:	f3 0f 1e fa          	endbr64
    1384:	31 ed                	xor    %ebp,%ebp
    1386:	49 89 d1             	mov    %rdx,%r9
    1389:	5e                   	pop    %rsi
    138a:	48 89 e2             	mov    %rsp,%rdx
    138d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    1391:	50                   	push   %rax
    1392:	54                   	push   %rsp
    1393:	45 31 c0             	xor    %r8d,%r8d
    1396:	31 c9                	xor    %ecx,%ecx
    1398:	48 8d 3d 61 fd ff ff 	lea    -0x29f(%rip),%rdi        # 1100 <main>
    139f:	ff 15 33 2c 00 00    	call   *0x2c33(%rip)        # 3fd8 <__libc_start_main@GLIBC_2.34>
    13a5:	f4                   	hlt
    13a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    13ad:	00 00 00 

00000000000013b0 <deregister_tm_clones>:
    13b0:	48 8d 3d 59 2c 00 00 	lea    0x2c59(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    13b7:	48 8d 05 52 2c 00 00 	lea    0x2c52(%rip),%rax        # 4010 <stdout@GLIBC_2.2.5>
    13be:	48 39 f8             	cmp    %rdi,%rax
    13c1:	74 15                	je     13d8 <deregister_tm_clones+0x28>
    13c3:	48 8b 05 16 2c 00 00 	mov    0x2c16(%rip),%rax        # 3fe0 <_ITM_deregisterTMCloneTable>
    13ca:	48 85 c0             	test   %rax,%rax
    13cd:	74 09                	je     13d8 <deregister_tm_clones+0x28>
    13cf:	ff e0                	jmp    *%rax
    13d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    13d8:	c3                   	ret
    13d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000013e0 <register_tm_clones>:
    13e0:	48 8d 3d 29 2c 00 00 	lea    0x2c29(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    13e7:	48 8d 35 22 2c 00 00 	lea    0x2c22(%rip),%rsi        # 4010 <stdout@GLIBC_2.2.5>
    13ee:	48 29 fe             	sub    %rdi,%rsi
    13f1:	48 89 f0             	mov    %rsi,%rax
    13f4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    13f8:	48 c1 f8 03          	sar    $0x3,%rax
    13fc:	48 01 c6             	add    %rax,%rsi
    13ff:	48 d1 fe             	sar    $1,%rsi
    1402:	74 14                	je     1418 <register_tm_clones+0x38>
    1404:	48 8b 05 e5 2b 00 00 	mov    0x2be5(%rip),%rax        # 3ff0 <_ITM_registerTMCloneTable>
    140b:	48 85 c0             	test   %rax,%rax
    140e:	74 08                	je     1418 <register_tm_clones+0x38>
    1410:	ff e0                	jmp    *%rax
    1412:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1418:	c3                   	ret
    1419:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001420 <__do_global_dtors_aux>:
    1420:	f3 0f 1e fa          	endbr64
    1424:	80 3d ed 2b 00 00 00 	cmpb   $0x0,0x2bed(%rip)        # 4018 <completed.0>
    142b:	75 2b                	jne    1458 <__do_global_dtors_aux+0x38>
    142d:	55                   	push   %rbp
    142e:	48 83 3d c2 2b 00 00 	cmpq   $0x0,0x2bc2(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    1435:	00 
    1436:	48 89 e5             	mov    %rsp,%rbp
    1439:	74 0c                	je     1447 <__do_global_dtors_aux+0x27>
    143b:	48 8b 3d c6 2b 00 00 	mov    0x2bc6(%rip),%rdi        # 4008 <__dso_handle>
    1442:	e8 49 fc ff ff       	call   1090 <__cxa_finalize@plt>
    1447:	e8 64 ff ff ff       	call   13b0 <deregister_tm_clones>
    144c:	c6 05 c5 2b 00 00 01 	movb   $0x1,0x2bc5(%rip)        # 4018 <completed.0>
    1453:	5d                   	pop    %rbp
    1454:	c3                   	ret
    1455:	0f 1f 00             	nopl   (%rax)
    1458:	c3                   	ret
    1459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001460 <frame_dummy>:
    1460:	f3 0f 1e fa          	endbr64
    1464:	e9 77 ff ff ff       	jmp    13e0 <register_tm_clones>

Disassembly of section .fini:

000000000000146c <_fini>:
    146c:	f3 0f 1e fa          	endbr64
    1470:	48 83 ec 08          	sub    $0x8,%rsp
    1474:	48 83 c4 08          	add    $0x8,%rsp
    1478:	c3                   	ret
