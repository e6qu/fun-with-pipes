
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 cf 00 00 	mov    0xcfd1(%rip),%rax        # ffe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 cd 00 00    	push   0xcdf2(%rip)        # fe18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 cd 00 00    	jmp    *0xcdf4(%rip)        # fe20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 cc 00 00    	jmp    *0xcc66(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # fe28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # fe30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # fe38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # fe40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # feb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # feb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ff00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ff08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ff10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ff18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ff20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ff28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ffa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ffa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ffb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ffb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ffc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ffc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 89 00 00 	lea    0x89b8(%rip),%r9        # c0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 89 00 00 	lea    0x89b5(%rip),%r8        # c0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 ab 00 00 	lea    0xaba1(%rip),%rax        # e320 <fwp_fn_table>
    377f:	48 89 05 f2 6c 06 00 	mov    %rax,0x66cf2(%rip)        # 6a478 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 6c 06 00 	mov    %rax,0x66cec(%rip)        # 6a480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 8b 00 00 	lea    0x8b4e(%rip),%rdi        # c2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 df 5d 00 00 	lea    0x5ddf(%rip),%rdx        # 9640 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 89 00 00 	lea    0x89fe(%rip),%rdi        # c2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 93 00 00 	lea    0x9356(%rip),%rdi        # cc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 10 93 00 00 	lea    0x9310(%rip),%rdi        # cc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 92 00 00 	lea    0x92d4(%rip),%rdi        # cc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 92 00 00 	lea    0x92a0(%rip),%rdi        # cbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b c6 00 00    	call   *0xc65b(%rip)        # ffd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e c6 00 00 	mov    0xc63e(%rip),%rax        # ffd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d c6 00 00 	mov    0xc60d(%rip),%rax        # ffe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea c5 00 00 	cmpq   $0x0,0xc5ea(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 c5 04 00 	lea    0x4c597(%rip),%r8        # 501a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b c5 04 00 	lea    0x4c53b(%rip),%rcx        # 50160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f c5 04 00 	lea    0x4c50f(%rip),%rcx        # 50140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 c5 04 00 	lea    0x4c541(%rip),%rcx        # 50180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 c5 04 	movdqa 0x4c550(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 c5 04 	paddq  0x4c538(%rip),%xmm0        # 501a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f c4 04 00 	cmp    %rax,0x4c49f(%rip)        # 50120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 c4 04 	movq   %xmm0,0x4c495(%rip)        # 50120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e c4 01 00 	add    0x1c43e(%rip),%rdx        # 200f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c c4 01 00 	add    0x1c42c(%rip),%rax        # 200f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 67 06 00 	mov    0x66779(%rip),%rdi        # 6a480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 c3 00 00 	mov    0xc304(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 c2 00 00 	mov    0xc2f1(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 4a 06 00 	mov    0x64ab1(%rip),%rax        # 68800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 43 06 00 	mov    0x643f9(%rip),%rax        # 681c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 43 06 00 	sub    0x643e5(%rip),%rax        # 681c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d 8f 00 00 	lea    0x8f2d(%rip),%rsi        # cd40 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 81 00 00 	lea    0x81c5(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 c1 00 00 	mov    0xc1f2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 5d 06 00 	mov    0x65d8b(%rip),%rax        # 69c10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 5d 06 00 	lea    0x65d84(%rip),%r8        # 69c10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 5d 06 00 	mov    0x65d65(%rip),%rbx        # 69bf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 5d 06 00 	mov    0x65d75(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 5d 06 00 	mov    0x65d11(%rip),%rdi        # 69c00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 5d 06 00 	sub    %rsi,0x65d5a(%rip)        # 69c50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 5c 06 00 	mov    0x65cea(%rip),%rax        # 69bf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 5c 06 00 	add    0x65ca0(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 5c 06 00 	mov    0x65cae(%rip),%rsi        # 69c00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 5c 06 00 	mov    0x65cbc(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 5c 06 00 	mov    %r12,0x65c6b(%rip)        # 69c00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 5c 06 00 	mov    %rbp,0x65c59(%rip)        # 69bf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 5c 06 00 	cmp    %rdi,0x65c3e(%rip)        # 69be8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 5c 06 00 	mov    %rdi,0x65c35(%rip)        # 69be8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 5c 06 00 	sub    %rdi,0x65c79(%rip)        # 69c50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 5c 06 00 	mov    0x65c21(%rip),%rax        # 69c08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 5c 06 00 	lea    0x65c1a(%rip),%r8        # 69c08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff 86 00 00 	lea    0x86ff(%rip),%rdx        # c708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 c0 00 00 	mov    0xc022(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d bf 00 00 	mov    0xbf7d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 7f 00 00 	lea    0x7f34(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 46 06 00 	cmp    0x646c9(%rip),%rdi        # 68800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 46 06 00 	mov    0x6468f(%rip),%rax        # 687e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 46 06 00 	mov    %rdi,0x6466d(%rip)        # 687e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 46 06 00 	mov    %rdi,0x64649(%rip)        # 687e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 80 00 00 	lea    0x8019(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 7e 00 00 	lea    0x7e27(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 bf 04 	movdqa 0x4bf76(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e bf 04 	paddq  0x4bf5e(%rip),%xmm0        # 501a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 be 01 00 	mov    0x1be84(%rip),%r8        # 200f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e be 04 00 	mov    0x4be9e(%rip),%rcx        # 50120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 bd 00 00 	mov    0xbdb7(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 84 00 00 	lea    0x84c5(%rip),%rdx        # c758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 be 04 00 	lea    0x4bee1(%rip),%r15        # 50180 <ad_raw_peak>
    429f:	4c 8d 35 9a be 04 00 	lea    0x4be9a(%rip),%r14        # 50140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 7d 00 00 	lea    0x7d79(%rip),%rax        # c02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 b9 00 	movq   0xb956(%rip),%xmm0        # fc10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f be 04 00 	lea    0x4be9f(%rip),%r13        # 50160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 7d 00 00 	lea    0x7d6f(%rip),%rax        # c03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 b9 00 	movq   0xb936(%rip),%xmm0        # fc18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 bd 00 00 	mov    0xbd33(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 7d 00 00 	lea    0x7d0c(%rip),%rcx        # c020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d 84 00 00 	lea    0x849d(%rip),%rdx        # c7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 bd 00 00 	mov    0xbd04(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 7c 00 00 	lea    0x7cf8(%rip),%rdi        # c045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 bd 01 00 	cmpq   $0x0,0x1bda6(%rip)        # 20100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd bd 01 00 	mov    0x1bdbd(%rip),%r8        # 20120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be bd 01 00 	mov    0x1bdbe(%rip),%r9        # 20128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af bd 01 00 	lea    0x1bdaf(%rip),%rbx        # 20120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 7c 00 00 	lea    0x7cf4(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 bd 01 00 	mov    0x1bdb1(%rip),%rax        # 20130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 7c 00 00 	lea    0x7c9a(%rip),%r12        # c020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 bc 00 00 	mov    0xbc89(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 84 00 00 	lea    0x8439(%rip),%rdx        # c7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 bd 01 00 	cmp    0x1bd33(%rip),%rbp        # 20100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 bc 00 00 	mov    0xbc58(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 7c 00 00 	lea    0x7c5b(%rip),%rdi        # c059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 bc 00 00 	mov    0xbc23(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 83 00 00 	lea    0x8394(%rip),%rdx        # c7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 7c 00 00 	lea    0x7c40(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea 82 00 00 	lea    0x82ea(%rip),%rdi        # c730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 bb 00 00 	mov    0xbbc8(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 7b 00 00 	lea    0x7bdf(%rip),%rdx        # c05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 bb 00 00 	mov    0xbbb0(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ba 00 00 	mov    0xbac1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 7a 00 00 	lea    0x7a78(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 7a 00 00 	lea    0x7ac0(%rip),%rdi        # c06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 7a 00 00 	lea    0x7a48(%rip),%rdi        # c087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 81 00 00 	lea    0x81e8(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 87 00 	movdqa 0x8720(%rip),%xmm0        # cd90 <msg.4+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 5d 06 00 	add    0x65daa(%rip),%rax        # 6a478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c 81 00 00 	lea    0x813c(%rip),%rdi        # c860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 b9 01 00 	cmp    %rax,0x1b9a5(%rip)        # 200e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 b9 01 00 	add    0x1b9a0(%rip),%rax        # 200f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 81 00 00 	lea    0x8125(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 79 00 00 	lea    0x7920(%rip),%r8        # c0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 77 00 00 	lea    0x7775(%rip),%r8        # c0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 76 00 00 	lea    0x7612(%rip),%r8        # c0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 73 00 00 	lea    0x73ea(%rip),%rdi        # c0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 75 00 00 	lea    0x7554(%rip),%rsi        # c242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 4e 06 00 	mov    0x64e85(%rip),%r9        # 69be8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 4e 06 00 	mov    0x64ede(%rip),%r8        # 69c48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f 7b 00 00 	lea    0x7b6f(%rip),%rdx        # c8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 4e 06 00 	mov    0x64ec6(%rip),%rcx        # 69c40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 4e 06 	movsd  0x64ed4(%rip),%xmm1        # 69c60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 4e 06 	movsd  0x64ec4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 b2 00 00 	mov    0xb2a5(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 7f 00 	movdqa 0x7fc8(%rip),%xmm0        # cda0 <msg.4+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 49 06 00 	lea    0x6497f(%rip),%rax        # 69760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 7f 00 	movdqa 0x7ff1(%rip),%xmm2        # cde0 <msg.4+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 49 06 00 	movaps %xmm0,0x64925(%rip)        # 69720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad 7f 00 	movdqa 0x7fad(%rip),%xmm0        # cdb0 <msg.4+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 4d 06 00 01 	movl   $0x1,0x64db3(%rip)        # 69bc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 49 06 00 	movaps %xmm0,0x64913(%rip)        # 69730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b 7f 00 	movdqa 0x7f9b(%rip),%xmm0        # cdc0 <msg.4+0x80>
    4e24:	00 
    4e25:	0f 29 05 14 49 06 00 	movaps %xmm0,0x64914(%rip)        # 69740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c 7f 00 	movdqa 0x7f9c(%rip),%xmm0        # cdd0 <msg.4+0x90>
    4e33:	00 
    4e34:	0f 29 05 15 49 06 00 	movaps %xmm0,0x64915(%rip)        # 69750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 39 06 00 	lea    0x63995(%rip),%r8        # 68820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 4c 06 00 	mov    %rax,0x64cb0(%rip)        # 69bd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 4c 06 00 	mov    %r12,0x64c8e(%rip)        # 69be0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 4c 06 00 	mov    %rax,0x64c77(%rip)        # 69bd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 4c 06 00 	mov    %rbx,0x64c90(%rip)        # 69bf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 4c 06 00 	mov    %rsi,0x64cb9(%rip)        # 69c20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 71 00 00 	lea    0x7174(%rip),%rdi        # c0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 4c 06 00 	mov    %rax,0x64c98(%rip)        # 69c18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 4c 06 00    	mov    %eax,0x64c1c(%rip)        # 69bc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 38 06 00 	mov    0x6380c(%rip),%r8        # 687e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 37 06 00 	mov    %rbx,0x6373c(%rip)        # 687e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 37 06 00 	mov    %r8,0x63728(%rip)        # 687e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 b0 04 00 	lea    0x4b0e9(%rip),%rcx        # 501c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 b0 04 00 	lea    0x4b098(%rip),%rcx        # 501a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 6f 00 00 	lea    0x6fc2(%rip),%rdi        # c0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 b0 04 00 	lea    0x4b016(%rip),%r12        # 501c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 6e 00 00 	lea    0x6ee8(%rip),%rax        # c112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 6e 00 00 	lea    0x6ecc(%rip),%rdx        # c0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 6f 00 00 	lea    0x6f04(%rip),%rdi        # c148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 6e 00 00 	lea    0x6edd(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 6e 00 00 	lea    0x6eaa(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae ad 01 00 	lea    0x1adae(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 ad 01 00 	movaps %xmm0,0x1ad96(%rip)        # 200a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 ad 01 00 	mov    %rsi,0x1ad72(%rip)        # 20088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 ad 01 00 	movaps %xmm0,0x1ad93(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 ad 01 00 	movaps %xmm0,0x1ad97(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 ad 01 00 	mov    %rax,0x1ad98(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 6e 00 00 	lea    0x6e09(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d ad 01 00 	mov    0x1ad1d(%rip),%rsi        # 20088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d ad 01 00 	imul   $0x68,0x1ad6d(%rip),%rdx        # 200e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 ae 04 00 	cmp    0x4ae26(%rip),%rdx        # 501a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 ae 04 00 	mov    0x4ae25(%rip),%rax        # 501a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f ae 04 00 	add    0x4ae1f(%rip),%rax        # 501b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 ae 04 00 	add    0x4ae20(%rip),%rax        # 501b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c ad 01 00 	mov    0x1ad5c(%rip),%rcx        # 20100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 ad 01 00 	mov    %rdi,0x1ad45(%rip)        # 20100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 ad 01 00 	lea    0x1ad57(%rip),%rcx        # 20120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 72 75 00 00 	lea    0x7572(%rip),%rdi        # c968 <_IO_stdin_used+0x968>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 6d 00 00 	lea    0x6d6f(%rip),%rdi        # c171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 33 06 00 	mov    0x633a7(%rip),%rbx        # 687d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a ab 00 00 	mov    0xab0a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 5b 74 00 00 	lea    0x745b(%rip),%rdi        # c998 <_IO_stdin_used+0x998>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 32 06 00 	mov    0x6326d(%rip),%rax        # 687e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 32 06 00 	mov    %rdx,0x63247(%rip)        # 687e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 31 06 00 	mov    0x63194(%rip),%rbx        # 687d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 31 06 00 	mov    %rbx,0x63151(%rip)        # 687d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 31 06 00 	mov    %rdx,0x63151(%rip)        # 687e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 31 06 00 	lea    0x63166(%rip),%rsi        # 68820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 4c 06 00 	addq   $0x1,0x64ce5(%rip)        # 6a468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 2f 72 00 00 	lea    0x722f(%rip),%rdi        # c9c8 <_IO_stdin_used+0x9c8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 40 72 00 00 	lea    0x7240(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 69 00 00 	lea    0x69d2(%rip),%rdi        # c18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 30 06 00 	lea    0x6301e(%rip),%rcx        # 68820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 4c 06 00 	subq   $0x1,0x64c1f(%rip)        # 6a468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 9b 71 00 00 	lea    0x719b(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 4c 06 00 	cmpq   $0x0,0x64c00(%rip)        # 6a468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 4b 06 00 	sub    %rax,0x64b55(%rip)        # 6a470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 4b 06 00 	add    %r12,0x64b33(%rip)        # 6a470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 42 06 00 	mov    0x6428f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 2e 06 00 	lea    0x62e8c(%rip),%rax        # 68820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 41 06 00 	add    0x641e3(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 41 06 00 	mov    0x641b0(%rip),%rsi        # 69bd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 41 06 00 	mov    0x641d1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 41 06 00 	add    0x641c5(%rip),%r8        # 69c18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 41 06 	addsd  0x6418d(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 2d 06 00 	lea    0x62d42(%rip),%rax        # 68820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 41 06 00 	sub    %rdi,0x6414c(%rip)        # 69c40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 41 06 	movsd  %xmm0,0x64164(%rip)        # 69c60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 41 06 00 	sub    %rdx,0x6411e(%rip)        # 69c40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 41 06 	addsd  0x64124(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 41 06 	movsd  %xmm0,0x64118(%rip)        # 69c60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 40 06 00 	mov    0x640af(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 40 06 00 	add    %rcx,0x640a9(%rip)        # 69c50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 40 06 00 	cmp    0x64062(%rip),%r9        # 69c10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 40 06 00 	mov    %r9,0x64059(%rip)        # 69c10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 40 06 00 	cmp    0x6404a(%rip),%r9        # 69c08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 40 06 00 	mov    %r9,0x6403d(%rip)        # 69c08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 3f 06 00 	add    0x63f53(%rip),%rdi        # 69c18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 2b 06 00 	lea    0x62b30(%rip),%r15        # 68820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 3e 06 00 	add    0x63ea0(%rip),%r12        # 69bd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 3e 06 00 	add    0x63ef9(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 3e 06 00 	cmp    %rax,0x63ef8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 3e 06 00 	mov    %rax,0x63ee9(%rip)        # 69c40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 3e 06 00 	mov    %rax,0x63ee8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 3e 06 	addsd  0x63ee4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 3e 06 	movsd  %xmm0,0x63edc(%rip)        # 69c58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 3e 06 00    	mov    0x63e23(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 2a 06 00 	lea    0x62a5f(%rip),%rdi        # 68820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 3e 06 00 	add    0x63e18(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 3e 06 00 	cmp    %rax,0x63e13(%rip)        # 69c48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 3e 06 00 	mov    %rax,0x63e04(%rip)        # 69c40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 3e 06 00 	mov    %rax,0x63e03(%rip)        # 69c48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 3d 06 	addsd  0x63dff(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 3d 06 	movsd  %xmm0,0x63df7(%rip)        # 69c58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 45 06 00    	mov    0x645ca(%rip),%ebx        # 6a4e8 <iteration_active>
    5f1e:	8b 05 a0 3c 06 00    	mov    0x63ca0(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 28 06 00 	lea    0x628d4(%rip),%rax        # 68820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 3c 06 00 	add    0x63c8e(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 3c 06 00 	cmp    %rax,0x63c89(%rip)        # 69c48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 3c 06 00 	mov    %rax,0x63c7a(%rip)        # 69c40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 3c 06 00 	mov    %rax,0x63c79(%rip)        # 69c48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 3c 06 	addsd  0x63c78(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 3c 06 	movsd  %xmm0,0x63c70(%rip)        # 69c58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 3c 06 00 	mov    0x63c4d(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 44 06 	subsd  0x644bb(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 44 06 	comisd 0x644ab(%rip),%xmm0        # 6a4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 44 06 	movsd  %xmm0,0x644a1(%rip)        # 6a4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 44 06 00 	addq   $0x1,0x644a4(%rip)        # 6a4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 44 06 00 	add    %rdi,0x64495(%rip)        # 6a4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_data.part.0.constprop.0>:
    6100:	41 56                	push   %r14
    6102:	8b 05 bc 3a 06 00    	mov    0x63abc(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    6108:	41 89 fe             	mov    %edi,%r14d
    610b:	41 55                	push   %r13
    610d:	44 8b 2d d4 43 06 00 	mov    0x643d4(%rip),%r13d        # 6a4e8 <iteration_active>
    6114:	41 54                	push   %r12
    6116:	49 89 f4             	mov    %rsi,%r12
    6119:	55                   	push   %rbp
    611a:	53                   	push   %rbx
    611b:	45 85 ed             	test   %r13d,%r13d
    611e:	0f 84 1c 01 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x140>
    6124:	48 83 05 b4 43 06 00 	addq   $0x1,0x643b4(%rip)        # 6a4e0 <iteration_requests>
    612b:	01 
    612c:	48 83 05 a4 43 06 00 	addq   $0x18,0x643a4(%rip)        # 6a4d8 <iteration_bytes>
    6133:	18 
    6134:	85 c0                	test   %eax,%eax
    6136:	0f 84 8c 01 00 00    	je     62c8 <fwp_data.part.0.constprop.0+0x1c8>
    613c:	0f b6 05 7f 36 06 00 	movzbl 0x6367f(%rip),%eax        # 697c2 <fwp_heap+0xfa2>
    6143:	48 8d 15 d6 26 06 00 	lea    0x626d6(%rip),%rdx        # 68820 <fwp_heap>
    614a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6151:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6155:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6159:	48 8b 18             	mov    (%rax),%rbx
    615c:	48 85 db             	test   %rbx,%rbx
    615f:	0f 84 fb 00 00 00    	je     6260 <fwp_data.part.0.constprop.0+0x160>
    6165:	48 8b 13             	mov    (%rbx),%rdx
    6168:	48 f7 d2             	not    %rdx
    616b:	48 89 10             	mov    %rdx,(%rax)
    616e:	48 83 fd 18          	cmp    $0x18,%rbp
    6172:	76 1b                	jbe    618f <fwp_data.part.0.constprop.0+0x8f>
    6174:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6178:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    617c:	31 f6                	xor    %esi,%esi
    617e:	48 c1 e8 03          	shr    $0x3,%rax
    6182:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6189:	00 
    618a:	e8 21 d3 ff ff       	call   34b0 <memset@plt>
    618f:	48 89 e8             	mov    %rbp,%rax
    6192:	48 03 05 a7 3a 06 00 	add    0x63aa7(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    6199:	0f 82 3d 01 00 00    	jb     62dc <fwp_data.part.0.constprop.0+0x1dc>
    619f:	48 39 05 a2 3a 06 00 	cmp    %rax,0x63aa2(%rip)        # 69c48 <fwp_heap+0x1428>
    61a6:	48 89 05 93 3a 06 00 	mov    %rax,0x63a93(%rip)        # 69c40 <fwp_heap+0x1420>
    61ad:	73 07                	jae    61b6 <fwp_data.part.0.constprop.0+0xb6>
    61af:	48 89 05 92 3a 06 00 	mov    %rax,0x63a92(%rip)        # 69c48 <fwp_heap+0x1428>
    61b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61ba:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    61bf:	f2 0f 58 05 91 3a 06 	addsd  0x63a91(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    61c6:	00 
    61c7:	f2 0f 11 05 89 3a 06 	movsd  %xmm0,0x63a89(%rip)        # 69c58 <fwp_heap+0x1438>
    61ce:	00 
    61cf:	45 85 ed             	test   %r13d,%r13d
    61d2:	74 33                	je     6207 <fwp_data.part.0.constprop.0+0x107>
    61d4:	48 8b 05 65 3a 06 00 	mov    0x63a65(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    61db:	48 85 c0             	test   %rax,%rax
    61de:	0f 88 a4 00 00 00    	js     6288 <fwp_data.part.0.constprop.0+0x188>
    61e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61e8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61ed:	f2 0f 5c 05 d3 42 06 	subsd  0x642d3(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    61f4:	00 
    61f5:	66 0f 2f 05 c3 42 06 	comisd 0x642c3(%rip),%xmm0        # 6a4c0 <iteration_peak>
    61fc:	00 
    61fd:	76 08                	jbe    6207 <fwp_data.part.0.constprop.0+0x107>
    61ff:	f2 0f 11 05 b9 42 06 	movsd  %xmm0,0x642b9(%rip)        # 6a4c0 <iteration_peak>
    6206:	00 
    6207:	b8 02 00 00 00       	mov    $0x2,%eax
    620c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6211:	66 0f 6e c8          	movd   %eax,%xmm1
    6215:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6219:	66 0f d6 03          	movq   %xmm0,(%rbx)
    621d:	49 8b 04 24          	mov    (%r12),%rax
    6221:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6225:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    622a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    622e:	48 89 d8             	mov    %rbx,%rax
    6231:	5b                   	pop    %rbx
    6232:	5d                   	pop    %rbp
    6233:	41 5c                	pop    %r12
    6235:	41 5d                	pop    %r13
    6237:	41 5e                	pop    %r14
    6239:	c3                   	ret
    623a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6240:	85 c0                	test   %eax,%eax
    6242:	0f 85 f4 fe ff ff    	jne    613c <fwp_data.part.0.constprop.0+0x3c>
    6248:	31 f6                	xor    %esi,%esi
    624a:	bf 18 00 00 00       	mov    $0x18,%edi
    624f:	e8 bc fc ff ff       	call   5f10 <fwp_heap_alloc>
    6254:	48 89 c3             	mov    %rax,%rbx
    6257:	eb ae                	jmp    6207 <fwp_data.part.0.constprop.0+0x107>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6260:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6264:	48 85 db             	test   %rbx,%rbx
    6267:	74 47                	je     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6269:	48 8b 50 10          	mov    0x10(%rax),%rdx
    626d:	48 29 da             	sub    %rbx,%rdx
    6270:	48 39 ea             	cmp    %rbp,%rdx
    6273:	72 3b                	jb     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6275:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    627d:	e9 ec fe ff ff       	jmp    616e <fwp_data.part.0.constprop.0+0x6e>
    6282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6288:	48 89 c2             	mov    %rax,%rdx
    628b:	83 e0 01             	and    $0x1,%eax
    628e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6292:	48 d1 ea             	shr    $1,%rdx
    6295:	48 09 c2             	or     %rax,%rdx
    6298:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    629d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    62a1:	e9 47 ff ff ff       	jmp    61ed <fwp_data.part.0.constprop.0+0xed>
    62a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ad:	00 00 00 
    62b0:	31 f6                	xor    %esi,%esi
    62b2:	bf 18 00 00 00       	mov    $0x18,%edi
    62b7:	e8 54 fc ff ff       	call   5f10 <fwp_heap_alloc>
    62bc:	48 89 c3             	mov    %rax,%rbx
    62bf:	e9 0b ff ff ff       	jmp    61cf <fwp_data.part.0.constprop.0+0xcf>
    62c4:	0f 1f 40 00          	nopl   0x0(%rax)
    62c8:	31 f6                	xor    %esi,%esi
    62ca:	bf 18 00 00 00       	mov    $0x18,%edi
    62cf:	e8 3c fc ff ff       	call   5f10 <fwp_heap_alloc>
    62d4:	48 89 c3             	mov    %rax,%rbx
    62d7:	e9 f8 fe ff ff       	jmp    61d4 <fwp_data.part.0.constprop.0+0xd4>
    62dc:	e8 4f db ff ff       	call   3e30 <fwp_heap_oom>
    62e1:	0f 1f 40 00          	nopl   0x0(%rax)
    62e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62ec:	00 00 00 00 

00000000000062f0 <fwp_p_ad_push.constprop.0>:
    62f0:	41 57                	push   %r15
    62f2:	41 56                	push   %r14
    62f4:	41 55                	push   %r13
    62f6:	49 89 d5             	mov    %rdx,%r13
    62f9:	41 54                	push   %r12
    62fb:	49 89 fc             	mov    %rdi,%r12
    62fe:	55                   	push   %rbp
    62ff:	53                   	push   %rbx
    6300:	48 83 ec 38          	sub    $0x38,%rsp
    6304:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6309:	48 85 ff             	test   %rdi,%rdi
    630c:	79 09                	jns    6317 <fwp_p_ad_push.constprop.0+0x27>
    630e:	48 85 d2             	test   %rdx,%rdx
    6311:	0f 88 a9 01 00 00    	js     64c0 <fwp_p_ad_push.constprop.0+0x1d0>
    6317:	48 89 f8             	mov    %rdi,%rax
    631a:	48 89 0c 24          	mov    %rcx,(%rsp)
    631e:	48 09 d0             	or     %rdx,%rax
    6321:	0f 89 79 01 00 00    	jns    64a0 <fwp_p_ad_push.constprop.0+0x1b0>
    6327:	48 89 f8             	mov    %rdi,%rax
    632a:	48 c1 f8 20          	sar    $0x20,%rax
    632e:	48 85 ff             	test   %rdi,%rdi
    6331:	79 24                	jns    6357 <fwp_p_ad_push.constprop.0+0x67>
    6333:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6338:	48 89 d0             	mov    %rdx,%rax
    633b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6342:	00 
    6343:	49 89 d4             	mov    %rdx,%r12
    6346:	48 c1 f8 20          	sar    $0x20,%rax
    634a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6351:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6357:	48 89 c7             	mov    %rax,%rdi
    635a:	e8 d1 e3 ff ff       	call   4730 <fwp_tape_of>
    635f:	48 89 c3             	mov    %rax,%rbx
    6362:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6367:	0f 85 f7 02 00 00    	jne    6664 <fwp_p_ad_push.constprop.0+0x374>
    636d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6371:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6378:	0f 8f 49 02 00 00    	jg     65c7 <fwp_p_ad_push.constprop.0+0x2d7>
    637e:	44 89 e0             	mov    %r12d,%eax
    6381:	49 39 c7             	cmp    %rax,%r15
    6384:	0f 8e 49 02 00 00    	jle    65d3 <fwp_p_ad_push.constprop.0+0x2e3>
    638a:	4d 85 ed             	test   %r13,%r13
    638d:	78 0c                	js     639b <fwp_p_ad_push.constprop.0+0xab>
    638f:	44 89 e8             	mov    %r13d,%eax
    6392:	49 39 c7             	cmp    %rax,%r15
    6395:	0f 8e 38 02 00 00    	jle    65d3 <fwp_p_ad_push.constprop.0+0x2e3>
    639b:	4d 89 fe             	mov    %r15,%r14
    639e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    63a2:	49 8d 46 01          	lea    0x1(%r14),%rax
    63a6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    63ac:	0f 87 15 02 00 00    	ja     65c7 <fwp_p_ad_push.constprop.0+0x2d7>
    63b2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    63b6:	48 39 e8             	cmp    %rbp,%rax
    63b9:	0f 8e 31 01 00 00    	jle    64f0 <fwp_p_ad_push.constprop.0+0x200>
    63bf:	48 85 ed             	test   %rbp,%rbp
    63c2:	ba 40 00 00 00       	mov    $0x40,%edx
    63c7:	48 0f 44 ea          	cmove  %rdx,%rbp
    63cb:	48 39 e8             	cmp    %rbp,%rax
    63ce:	7e 20                	jle    63f0 <fwp_p_ad_push.constprop.0+0x100>
    63d0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    63d7:	0f 8f 03 01 00 00    	jg     64e0 <fwp_p_ad_push.constprop.0+0x1f0>
    63dd:	48 01 ed             	add    %rbp,%rbp
    63e0:	48 39 e8             	cmp    %rbp,%rax
    63e3:	7f eb                	jg     63d0 <fwp_p_ad_push.constprop.0+0xe0>
    63e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63ec:	00 00 00 00 
    63f0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    63f7:	00 
    63f8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    63fc:	ba 01 00 00 00       	mov    $0x1,%edx
    6401:	48 89 c6             	mov    %rax,%rsi
    6404:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6409:	e8 82 ed ff ff       	call   5190 <ad_raw_realloc>
    640e:	48 85 c0             	test   %rax,%rax
    6411:	0f 84 c8 01 00 00    	je     65df <fwp_p_ad_push.constprop.0+0x2ef>
    6417:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    641b:	48 89 e9             	mov    %rbp,%rcx
    641e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6422:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6426:	48 c1 e1 04          	shl    $0x4,%rcx
    642a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    642e:	48 89 ce             	mov    %rcx,%rsi
    6431:	ba 02 00 00 00       	mov    $0x2,%edx
    6436:	48 89 43 28          	mov    %rax,0x28(%rbx)
    643a:	e8 51 ed ff ff       	call   5190 <ad_raw_realloc>
    643f:	48 85 c0             	test   %rax,%rax
    6442:	0f 84 97 01 00 00    	je     65df <fwp_p_ad_push.constprop.0+0x2ef>
    6448:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    644c:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6450:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6457:	00 
    6458:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    645f:	00 
    6460:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    6467:	00 
    6468:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    646c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6471:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6475:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    6479:	4d 85 f6             	test   %r14,%r14
    647c:	0f 85 e6 00 00 00    	jne    6568 <fwp_p_ad_push.constprop.0+0x278>
    6482:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6486:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    648a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    648e:	48 01 d1             	add    %rdx,%rcx
    6491:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    6495:	eb 79                	jmp    6510 <fwp_p_ad_push.constprop.0+0x220>
    6497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    649e:	00 00 
    64a0:	48 89 d0             	mov    %rdx,%rax
    64a3:	48 c1 ff 20          	sar    $0x20,%rdi
    64a7:	48 c1 f8 20          	sar    $0x20,%rax
    64ab:	48 39 c7             	cmp    %rax,%rdi
    64ae:	0f 84 a3 fe ff ff    	je     6357 <fwp_p_ad_push.constprop.0+0x67>
    64b4:	48 8d 3d 5d 65 00 00 	lea    0x655d(%rip),%rdi        # ca18 <_IO_stdin_used+0xa18>
    64bb:	e8 90 df ff ff       	call   4450 <fwp_trap>
    64c0:	48 83 c4 38          	add    $0x38,%rsp
    64c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    64cb:	5b                   	pop    %rbx
    64cc:	5d                   	pop    %rbp
    64cd:	41 5c                	pop    %r12
    64cf:	41 5d                	pop    %r13
    64d1:	41 5e                	pop    %r14
    64d3:	41 5f                	pop    %r15
    64d5:	c3                   	ret
    64d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64dd:	00 00 00 
    64e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    64e5:	e9 06 ff ff ff       	jmp    63f0 <fwp_p_ad_push.constprop.0+0x100>
    64ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64f0:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64f4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    64f8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64ff:	00 
    6500:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6507:	00 
    6508:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    650c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6510:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6516:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    651a:	4d 85 ed             	test   %r13,%r13
    651d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6522:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6528:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6533:	49 8d 47 01          	lea    0x1(%r15),%rax
    6537:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    653b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6541:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6545:	48 83 c4 38          	add    $0x38,%rsp
    6549:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6550:	ff ff ff 
    6553:	4c 21 e0             	and    %r12,%rax
    6556:	5b                   	pop    %rbx
    6557:	5d                   	pop    %rbp
    6558:	4c 09 f8             	or     %r15,%rax
    655b:	41 5c                	pop    %r12
    655d:	41 5d                	pop    %r13
    655f:	41 5e                	pop    %r14
    6561:	41 5f                	pop    %r15
    6563:	c3                   	ret
    6564:	0f 1f 40 00          	nopl   0x0(%rax)
    6568:	4c 89 ca             	mov    %r9,%rdx
    656b:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6570:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6575:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    657a:	e8 71 d0 ff ff       	call   35f0 <memmove@plt>
    657f:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    6584:	4c 03 73 30          	add    0x30(%rbx),%r14
    6588:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    658d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6591:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6595:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    659a:	48 03 7b 20          	add    0x20(%rbx),%rdi
    659e:	4c 89 d2             	mov    %r10,%rdx
    65a1:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    65a6:	e8 45 d0 ff ff       	call   35f0 <memmove@plt>
    65ab:	48 8b 43 30          	mov    0x30(%rbx),%rax
    65af:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65b3:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    65b8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    65bd:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    65c2:	e9 bf fe ff ff       	jmp    6486 <fwp_p_ad_push.constprop.0+0x196>
    65c7:	48 8d 3d d9 5b 00 00 	lea    0x5bd9(%rip),%rdi        # c1a7 <_IO_stdin_used+0x1a7>
    65ce:	e8 7d de ff ff       	call   4450 <fwp_trap>
    65d3:	48 8d 3d e8 5b 00 00 	lea    0x5be8(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    65da:	e8 71 de ff ff       	call   4450 <fwp_trap>
    65df:	48 89 df             	mov    %rbx,%rdi
    65e2:	e8 a9 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    65e7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    65eb:	48 85 ff             	test   %rdi,%rdi
    65ee:	74 05                	je     65f5 <fwp_p_ad_push.constprop.0+0x305>
    65f0:	e8 db ea ff ff       	call   50d0 <ad_raw_free.part.0>
    65f5:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    65f9:	48 85 ff             	test   %rdi,%rdi
    65fc:	74 05                	je     6603 <fwp_p_ad_push.constprop.0+0x313>
    65fe:	e8 cd ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6603:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6607:	48 85 ff             	test   %rdi,%rdi
    660a:	74 05                	je     6611 <fwp_p_ad_push.constprop.0+0x321>
    660c:	e8 bf ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6611:	31 c9                	xor    %ecx,%ecx
    6613:	31 c0                	xor    %eax,%eax
    6615:	31 d2                	xor    %edx,%edx
    6617:	be 01 00 00 00       	mov    $0x1,%esi
    661c:	89 53 04             	mov    %edx,0x4(%rbx)
    661f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6623:	ba 13 00 00 00       	mov    $0x13,%edx
    6628:	48 8d 3d d9 59 00 00 	lea    0x59d9(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    662f:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6633:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6637:	48 8b 0d 02 9a 00 00 	mov    0x9a02(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    663e:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6642:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6646:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    664a:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    664e:	e8 0d d0 ff ff       	call   3660 <fwrite@plt>
    6653:	31 ff                	xor    %edi,%edi
    6655:	e8 46 cf ff ff       	call   35a0 <fflush@plt>
    665a:	bf 66 00 00 00       	mov    $0x66,%edi
    665f:	e8 1c d0 ff ff       	call   3680 <_Exit@plt>
    6664:	48 8d 3d f5 63 00 00 	lea    0x63f5(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    666b:	e8 e0 dd ff ff       	call   4450 <fwp_trap>

0000000000006670 <w120>:
    6670:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6674:	41 55                	push   %r13
    6676:	48 89 fa             	mov    %rdi,%rdx
    6679:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    667d:	41 54                	push   %r12
    667f:	49 89 fc             	mov    %rdi,%r12
    6682:	55                   	push   %rbp
    6683:	53                   	push   %rbx
    6684:	48 89 f3             	mov    %rsi,%rbx
    6687:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    668c:	48 89 f1             	mov    %rsi,%rcx
    668f:	48 83 ec 28          	sub    $0x28,%rsp
    6693:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6699:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    669f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    66a5:	e8 46 fc ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    66aa:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    66b0:	48 89 da             	mov    %rbx,%rdx
    66b3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    66b9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66c0:	00 f0 3f 
    66c3:	48 89 c7             	mov    %rax,%rdi
    66c6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    66cd:	00 f0 bf 
    66d0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    66d5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66db:	e8 10 fc ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    66e0:	f2 0f 10 05 80 66 00 	movsd  0x6680(%rip),%xmm0        # cd68 <msg.4+0x28>
    66e7:	00 
    66e8:	4c 89 e7             	mov    %r12,%rdi
    66eb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    66f1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66f8:	00 f0 3f 
    66fb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6702:	49 89 c5             	mov    %rax,%r13
    6705:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    670c:	00 f0 bf 
    670f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6714:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    671a:	e8 d1 fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    671f:	48 89 e9             	mov    %rbp,%rcx
    6722:	4c 89 ea             	mov    %r13,%rdx
    6725:	48 89 ee             	mov    %rbp,%rsi
    6728:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    672e:	4c 89 ef             	mov    %r13,%rdi
    6731:	49 89 c4             	mov    %rax,%r12
    6734:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6738:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    673e:	e8 ad fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    6743:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6749:	f2 0f 59 1d 1f 66 00 	mulsd  0x661f(%rip),%xmm3        # cd70 <msg.4+0x30>
    6750:	00 
    6751:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6758:	00 59 40 
    675b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6760:	48 89 c2             	mov    %rax,%rdx
    6763:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    676a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6770:	e8 7b fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    6775:	48 89 d9             	mov    %rbx,%rcx
    6778:	4c 89 e2             	mov    %r12,%rdx
    677b:	48 89 de             	mov    %rbx,%rsi
    677e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6784:	4c 89 e7             	mov    %r12,%rdi
    6787:	48 89 c5             	mov    %rax,%rbp
    678a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    678e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6794:	e8 57 fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    6799:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    679f:	48 89 ea             	mov    %rbp,%rdx
    67a2:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    67a8:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    67af:	00 f0 3f 
    67b2:	48 89 c7             	mov    %rax,%rdi
    67b5:	48 89 ce             	mov    %rcx,%rsi
    67b8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    67bd:	e8 2e fb ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    67c2:	48 83 c4 28          	add    $0x28,%rsp
    67c6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    67cb:	5b                   	pop    %rbx
    67cc:	5d                   	pop    %rbp
    67cd:	41 5c                	pop    %r12
    67cf:	41 5d                	pop    %r13
    67d1:	c3                   	ret
    67d2:	0f 1f 00             	nopl   (%rax)
    67d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67dc:	00 00 00 00 

00000000000067e0 <w176.constprop.0>:
    67e0:	41 54                	push   %r12
    67e2:	55                   	push   %rbp
    67e3:	53                   	push   %rbx
    67e4:	48 83 ec 10          	sub    $0x10,%rsp
    67e8:	4c 8b 27             	mov    (%rdi),%r12
    67eb:	4d 85 e4             	test   %r12,%r12
    67ee:	74 58                	je     6848 <w176.constprop.0+0x68>
    67f0:	48 89 fd             	mov    %rdi,%rbp
    67f3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67f7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67fe:	31 db                	xor    %ebx,%ebx
    6800:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6806:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    680b:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6812:	00 f0 3f 
    6815:	48 83 c3 02          	add    $0x2,%rbx
    6819:	48 89 ce             	mov    %rcx,%rsi
    681c:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6822:	e8 c9 fa ff ff       	call   62f0 <fwp_p_ad_push.constprop.0>
    6827:	4c 39 e3             	cmp    %r12,%rbx
    682a:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6830:	48 89 c7             	mov    %rax,%rdi
    6833:	72 cb                	jb     6800 <w176.constprop.0+0x20>
    6835:	48 83 c4 10          	add    $0x10,%rsp
    6839:	48 89 f8             	mov    %rdi,%rax
    683c:	5b                   	pop    %rbx
    683d:	5d                   	pop    %rbp
    683e:	41 5c                	pop    %r12
    6840:	c3                   	ret
    6841:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6848:	48 83 c4 10          	add    $0x10,%rsp
    684c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6853:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6857:	5b                   	pop    %rbx
    6858:	48 89 f8             	mov    %rdi,%rax
    685b:	5d                   	pop    %rbp
    685c:	41 5c                	pop    %r12
    685e:	c3                   	ret
    685f:	90                   	nop

0000000000006860 <fwp_rc_share>:
    6860:	48 8b 05 91 33 06 00 	mov    0x63391(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    6867:	48 2b 3d 62 33 06 00 	sub    0x63362(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    686e:	48 c1 e0 10          	shl    $0x10,%rax
    6872:	48 39 c7             	cmp    %rax,%rdi
    6875:	73 4a                	jae    68c1 <fwp_rc_share+0x61>
    6877:	48 89 f8             	mov    %rdi,%rax
    687a:	48 c1 e8 10          	shr    $0x10,%rax
    687e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6882:	48 8b 05 8f 33 06 00 	mov    0x6338f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    6889:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    688d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6891:	48 85 d2             	test   %rdx,%rdx
    6894:	74 2b                	je     68c1 <fwp_rc_share+0x61>
    6896:	0f b6 08             	movzbl (%rax),%ecx
    6899:	80 f9 02             	cmp    $0x2,%cl
    689c:	74 2a                	je     68c8 <fwp_rc_share+0x68>
    689e:	80 f9 01             	cmp    $0x1,%cl
    68a1:	75 1e                	jne    68c1 <fwp_rc_share+0x61>
    68a3:	8b 48 18             	mov    0x18(%rax),%ecx
    68a6:	0f b7 ff             	movzwl %di,%edi
    68a9:	8b 40 1c             	mov    0x1c(%rax),%eax
    68ac:	48 0f af f9          	imul   %rcx,%rdi
    68b0:	48 c1 ef 20          	shr    $0x20,%rdi
    68b4:	48 39 c7             	cmp    %rax,%rdi
    68b7:	73 08                	jae    68c1 <fwp_rc_share+0x61>
    68b9:	48 01 fa             	add    %rdi,%rdx
    68bc:	80 3a 00             	cmpb   $0x0,(%rdx)
    68bf:	75 0d                	jne    68ce <fwp_rc_share+0x6e>
    68c1:	c3                   	ret
    68c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68c8:	66 85 ff             	test   %di,%di
    68cb:	74 ef                	je     68bc <fwp_rc_share+0x5c>
    68cd:	c3                   	ret
    68ce:	50                   	push   %rax
    68cf:	48 8d 3d ba 61 00 00 	lea    0x61ba(%rip),%rdi        # ca90 <_IO_stdin_used+0xa90>
    68d6:	e8 75 db ff ff       	call   4450 <fwp_trap>
    68db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000068e0 <fwp_rc_free_obj>:
    68e0:	48 8b 15 11 33 06 00 	mov    0x63311(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    68e7:	48 89 f8             	mov    %rdi,%rax
    68ea:	48 2b 05 df 32 06 00 	sub    0x632df(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    68f1:	48 c1 e2 10          	shl    $0x10,%rdx
    68f5:	48 39 d0             	cmp    %rdx,%rax
    68f8:	73 5b                	jae    6955 <fwp_rc_free_obj+0x75>
    68fa:	48 89 c2             	mov    %rax,%rdx
    68fd:	48 c1 ea 10          	shr    $0x10,%rdx
    6901:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6905:	48 8b 15 0c 33 06 00 	mov    0x6330c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    690c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6910:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6914:	48 85 c9             	test   %rcx,%rcx
    6917:	74 3c                	je     6955 <fwp_rc_free_obj+0x75>
    6919:	0f b6 32             	movzbl (%rdx),%esi
    691c:	40 80 fe 02          	cmp    $0x2,%sil
    6920:	74 2e                	je     6950 <fwp_rc_free_obj+0x70>
    6922:	40 80 fe 01          	cmp    $0x1,%sil
    6926:	75 2d                	jne    6955 <fwp_rc_free_obj+0x75>
    6928:	8b 72 18             	mov    0x18(%rdx),%esi
    692b:	0f b7 c0             	movzwl %ax,%eax
    692e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6931:	48 0f af c6          	imul   %rsi,%rax
    6935:	48 c1 e8 20          	shr    $0x20,%rax
    6939:	48 39 d0             	cmp    %rdx,%rax
    693c:	73 17                	jae    6955 <fwp_rc_free_obj+0x75>
    693e:	48 01 c1             	add    %rax,%rcx
    6941:	80 39 01             	cmpb   $0x1,(%rcx)
    6944:	75 0f                	jne    6955 <fwp_rc_free_obj+0x75>
    6946:	e9 c5 f0 ff ff       	jmp    5a10 <fwp_mem_free>
    694b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6950:	66 85 c0             	test   %ax,%ax
    6953:	74 ec                	je     6941 <fwp_rc_free_obj+0x61>
    6955:	c3                   	ret
    6956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    695d:	00 00 00 

0000000000006960 <fwp_rc_dup>:
    6960:	f3 0f 1e fa          	endbr64
    6964:	48 8b 05 8d 32 06 00 	mov    0x6328d(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    696b:	48 2b 3d 5e 32 06 00 	sub    0x6325e(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    6972:	48 c1 e0 10          	shl    $0x10,%rax
    6976:	48 39 c7             	cmp    %rax,%rdi
    6979:	73 60                	jae    69db <fwp_rc_dup+0x7b>
    697b:	48 89 f8             	mov    %rdi,%rax
    697e:	48 c1 e8 10          	shr    $0x10,%rax
    6982:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6986:	48 8b 05 8b 32 06 00 	mov    0x6328b(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    698d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6991:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6995:	48 85 c0             	test   %rax,%rax
    6998:	74 41                	je     69db <fwp_rc_dup+0x7b>
    699a:	0f b6 0a             	movzbl (%rdx),%ecx
    699d:	80 f9 02             	cmp    $0x2,%cl
    69a0:	74 3e                	je     69e0 <fwp_rc_dup+0x80>
    69a2:	80 f9 01             	cmp    $0x1,%cl
    69a5:	75 34                	jne    69db <fwp_rc_dup+0x7b>
    69a7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    69aa:	0f b7 ff             	movzwl %di,%edi
    69ad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69b0:	48 0f af f9          	imul   %rcx,%rdi
    69b4:	48 c1 ef 20          	shr    $0x20,%rdi
    69b8:	48 39 d7             	cmp    %rdx,%rdi
    69bb:	73 1e                	jae    69db <fwp_rc_dup+0x7b>
    69bd:	48 01 f8             	add    %rdi,%rax
    69c0:	0f b6 10             	movzbl (%rax),%edx
    69c3:	84 d2                	test   %dl,%dl
    69c5:	74 14                	je     69db <fwp_rc_dup+0x7b>
    69c7:	8b 0d 1b 3b 06 00    	mov    0x63b1b(%rip),%ecx        # 6a4e8 <iteration_active>
    69cd:	85 c9                	test   %ecx,%ecx
    69cf:	75 1f                	jne    69f0 <fwp_rc_dup+0x90>
    69d1:	80 fa fd             	cmp    $0xfd,%dl
    69d4:	77 2a                	ja     6a00 <fwp_rc_dup+0xa0>
    69d6:	83 c2 01             	add    $0x1,%edx
    69d9:	88 10                	mov    %dl,(%rax)
    69db:	c3                   	ret
    69dc:	0f 1f 40 00          	nopl   0x0(%rax)
    69e0:	66 85 ff             	test   %di,%di
    69e3:	74 db                	je     69c0 <fwp_rc_dup+0x60>
    69e5:	c3                   	ret
    69e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69ed:	00 00 00 
    69f0:	48 83 05 d8 3a 06 00 	addq   $0x1,0x63ad8(%rip)        # 6a4d0 <iteration_retains>
    69f7:	01 
    69f8:	eb d7                	jmp    69d1 <fwp_rc_dup+0x71>
    69fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a00:	48 89 c7             	mov    %rax,%rdi
    6a03:	e9 a8 ec ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6a08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a0f:	00 

0000000000006a10 <fwp_owned_entry173>:
    6a10:	f3 0f 1e fa          	endbr64
    6a14:	48 83 ec 38          	sub    $0x38,%rsp
    6a18:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6a1d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6a24:	00 00 
    6a26:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6a2b:	31 c0                	xor    %eax,%eax
    6a2d:	48 8b 07             	mov    (%rdi),%rax
    6a30:	48 03 47 10          	add    0x10(%rdi),%rax
    6a34:	0f 80 c2 00 00 00    	jo     6afc <fwp_owned_entry173+0xec>
    6a3a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6a3f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6a44:	31 ff                	xor    %edi,%edi
    6a46:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6a4a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6a4f:	e8 ac f6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6a54:	48 8b 15 9d 31 06 00 	mov    0x6319d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6a5b:	48 89 c6             	mov    %rax,%rsi
    6a5e:	48 2b 05 6b 31 06 00 	sub    0x6316b(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6a65:	48 c1 e2 10          	shl    $0x10,%rdx
    6a69:	48 39 d0             	cmp    %rdx,%rax
    6a6c:	73 4f                	jae    6abd <fwp_owned_entry173+0xad>
    6a6e:	48 89 c2             	mov    %rax,%rdx
    6a71:	48 c1 ea 10          	shr    $0x10,%rdx
    6a75:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a79:	48 8b 15 98 31 06 00 	mov    0x63198(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6a80:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a84:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a88:	48 85 d2             	test   %rdx,%rdx
    6a8b:	74 30                	je     6abd <fwp_owned_entry173+0xad>
    6a8d:	0f b6 39             	movzbl (%rcx),%edi
    6a90:	40 80 ff 02          	cmp    $0x2,%dil
    6a94:	74 42                	je     6ad8 <fwp_owned_entry173+0xc8>
    6a96:	40 80 ff 01          	cmp    $0x1,%dil
    6a9a:	75 21                	jne    6abd <fwp_owned_entry173+0xad>
    6a9c:	8b 79 18             	mov    0x18(%rcx),%edi
    6a9f:	0f b7 c0             	movzwl %ax,%eax
    6aa2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6aa5:	48 0f af c7          	imul   %rdi,%rax
    6aa9:	48 c1 e8 20          	shr    $0x20,%rax
    6aad:	48 39 c8             	cmp    %rcx,%rax
    6ab0:	73 0b                	jae    6abd <fwp_owned_entry173+0xad>
    6ab2:	48 01 c2             	add    %rax,%rdx
    6ab5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6ab8:	74 26                	je     6ae0 <fwp_owned_entry173+0xd0>
    6aba:	c6 02 01             	movb   $0x1,(%rdx)
    6abd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6ac2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ac9:	00 00 
    6acb:	75 34                	jne    6b01 <fwp_owned_entry173+0xf1>
    6acd:	48 89 f0             	mov    %rsi,%rax
    6ad0:	48 83 c4 38          	add    $0x38,%rsp
    6ad4:	c3                   	ret
    6ad5:	0f 1f 00             	nopl   (%rax)
    6ad8:	66 85 c0             	test   %ax,%ax
    6adb:	75 e0                	jne    6abd <fwp_owned_entry173+0xad>
    6add:	eb d6                	jmp    6ab5 <fwp_owned_entry173+0xa5>
    6adf:	90                   	nop
    6ae0:	48 89 d7             	mov    %rdx,%rdi
    6ae3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6ae8:	48 89 14 24          	mov    %rdx,(%rsp)
    6aec:	e8 df ec ff ff       	call   57d0 <fwp_rc_forget_slot>
    6af1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6af6:	48 8b 14 24          	mov    (%rsp),%rdx
    6afa:	eb be                	jmp    6aba <fwp_owned_entry173+0xaa>
    6afc:	e8 ff cb ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6b01:	e8 4a c9 ff ff       	call   3450 <__stack_chk_fail@plt>
    6b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b0d:	00 00 00 

0000000000006b10 <e173>:
    6b10:	f3 0f 1e fa          	endbr64
    6b14:	53                   	push   %rbx
    6b15:	48 83 ec 30          	sub    $0x30,%rsp
    6b19:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6b1e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b25:	00 00 
    6b27:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6b2c:	31 c0                	xor    %eax,%eax
    6b2e:	48 8b 07             	mov    (%rdi),%rax
    6b31:	48 03 47 10          	add    0x10(%rdi),%rax
    6b35:	0f 80 c9 00 00 00    	jo     6c04 <e173+0xf4>
    6b3b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6b40:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6b45:	31 ff                	xor    %edi,%edi
    6b47:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6b4b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6b50:	e8 ab f5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6b55:	48 8b 15 9c 30 06 00 	mov    0x6309c(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6b5c:	48 89 c3             	mov    %rax,%rbx
    6b5f:	48 2b 05 6a 30 06 00 	sub    0x6306a(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6b66:	48 c1 e2 10          	shl    $0x10,%rdx
    6b6a:	48 39 d0             	cmp    %rdx,%rax
    6b6d:	73 4f                	jae    6bbe <e173+0xae>
    6b6f:	48 89 c2             	mov    %rax,%rdx
    6b72:	48 c1 ea 10          	shr    $0x10,%rdx
    6b76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b7a:	48 8b 15 97 30 06 00 	mov    0x63097(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6b81:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b85:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b89:	48 85 d2             	test   %rdx,%rdx
    6b8c:	74 30                	je     6bbe <e173+0xae>
    6b8e:	0f b6 31             	movzbl (%rcx),%esi
    6b91:	40 80 fe 02          	cmp    $0x2,%sil
    6b95:	74 49                	je     6be0 <e173+0xd0>
    6b97:	40 80 fe 01          	cmp    $0x1,%sil
    6b9b:	75 21                	jne    6bbe <e173+0xae>
    6b9d:	8b 71 18             	mov    0x18(%rcx),%esi
    6ba0:	0f b7 c0             	movzwl %ax,%eax
    6ba3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ba6:	48 0f af c6          	imul   %rsi,%rax
    6baa:	48 c1 e8 20          	shr    $0x20,%rax
    6bae:	48 39 c8             	cmp    %rcx,%rax
    6bb1:	73 0b                	jae    6bbe <e173+0xae>
    6bb3:	48 01 c2             	add    %rax,%rdx
    6bb6:	80 3a ff             	cmpb   $0xff,(%rdx)
    6bb9:	74 35                	je     6bf0 <e173+0xe0>
    6bbb:	c6 02 01             	movb   $0x1,(%rdx)
    6bbe:	48 89 df             	mov    %rbx,%rdi
    6bc1:	e8 9a fc ff ff       	call   6860 <fwp_rc_share>
    6bc6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6bcb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6bd2:	00 00 
    6bd4:	75 33                	jne    6c09 <e173+0xf9>
    6bd6:	48 83 c4 30          	add    $0x30,%rsp
    6bda:	48 89 d8             	mov    %rbx,%rax
    6bdd:	5b                   	pop    %rbx
    6bde:	c3                   	ret
    6bdf:	90                   	nop
    6be0:	66 85 c0             	test   %ax,%ax
    6be3:	75 d9                	jne    6bbe <e173+0xae>
    6be5:	eb cf                	jmp    6bb6 <e173+0xa6>
    6be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6bee:	00 00 
    6bf0:	48 89 d7             	mov    %rdx,%rdi
    6bf3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6bf8:	e8 d3 eb ff ff       	call   57d0 <fwp_rc_forget_slot>
    6bfd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c02:	eb b7                	jmp    6bbb <e173+0xab>
    6c04:	e8 f7 ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6c09:	e8 42 c8 ff ff       	call   3450 <__stack_chk_fail@plt>
    6c0e:	66 90                	xchg   %ax,%ax

0000000000006c10 <fwp_closure_drop>:
    6c10:	48 8b 15 e1 2f 06 00 	mov    0x62fe1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6c17:	48 89 f8             	mov    %rdi,%rax
    6c1a:	48 2b 05 af 2f 06 00 	sub    0x62faf(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6c21:	48 c1 e2 10          	shl    $0x10,%rdx
    6c25:	48 39 d0             	cmp    %rdx,%rax
    6c28:	73 6b                	jae    6c95 <fwp_closure_drop+0x85>
    6c2a:	48 89 c2             	mov    %rax,%rdx
    6c2d:	48 c1 ea 10          	shr    $0x10,%rdx
    6c31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c35:	48 8b 15 dc 2f 06 00 	mov    0x62fdc(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6c3c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c40:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c44:	48 85 d2             	test   %rdx,%rdx
    6c47:	74 4c                	je     6c95 <fwp_closure_drop+0x85>
    6c49:	0f b6 31             	movzbl (%rcx),%esi
    6c4c:	40 80 fe 02          	cmp    $0x2,%sil
    6c50:	74 3e                	je     6c90 <fwp_closure_drop+0x80>
    6c52:	40 80 fe 01          	cmp    $0x1,%sil
    6c56:	75 3d                	jne    6c95 <fwp_closure_drop+0x85>
    6c58:	8b 71 18             	mov    0x18(%rcx),%esi
    6c5b:	0f b7 c0             	movzwl %ax,%eax
    6c5e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c61:	48 0f af c6          	imul   %rsi,%rax
    6c65:	48 c1 e8 20          	shr    $0x20,%rax
    6c69:	48 39 c8             	cmp    %rcx,%rax
    6c6c:	73 27                	jae    6c95 <fwp_closure_drop+0x85>
    6c6e:	48 01 c2             	add    %rax,%rdx
    6c71:	0f b6 02             	movzbl (%rdx),%eax
    6c74:	84 c0                	test   %al,%al
    6c76:	74 1d                	je     6c95 <fwp_closure_drop+0x85>
    6c78:	3c 01                	cmp    $0x1,%al
    6c7a:	74 24                	je     6ca0 <fwp_closure_drop+0x90>
    6c7c:	3c ff                	cmp    $0xff,%al
    6c7e:	74 48                	je     6cc8 <fwp_closure_drop+0xb8>
    6c80:	83 e8 01             	sub    $0x1,%eax
    6c83:	88 02                	mov    %al,(%rdx)
    6c85:	c3                   	ret
    6c86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c8d:	00 00 00 
    6c90:	66 85 c0             	test   %ax,%ax
    6c93:	74 dc                	je     6c71 <fwp_closure_drop+0x61>
    6c95:	c3                   	ret
    6c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c9d:	00 00 00 
    6ca0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6ca7:	ff ff 
    6ca9:	48 85 c0             	test   %rax,%rax
    6cac:	74 12                	je     6cc0 <fwp_closure_drop+0xb0>
    6cae:	48 89 fe             	mov    %rdi,%rsi
    6cb1:	48 89 c7             	mov    %rax,%rdi
    6cb4:	e9 f7 d7 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    6cb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6cc0:	e9 9b d9 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    6cc5:	0f 1f 00             	nopl   (%rax)
    6cc8:	48 89 d0             	mov    %rdx,%rax
    6ccb:	48 8d 35 4e 1b 06 00 	lea    0x61b4e(%rip),%rsi        # 68820 <fwp_heap>
    6cd2:	48 83 ec 18          	sub    $0x18,%rsp
    6cd6:	48 c1 e8 11          	shr    $0x11,%rax
    6cda:	48 31 d0             	xor    %rdx,%rax
    6cdd:	48 89 c1             	mov    %rax,%rcx
    6ce0:	48 c1 e9 09          	shr    $0x9,%rcx
    6ce4:	48 31 c8             	xor    %rcx,%rax
    6ce7:	0f b6 c8             	movzbl %al,%ecx
    6cea:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6cf1:	00 
    6cf2:	48 85 c0             	test   %rax,%rax
    6cf5:	75 12                	jne    6d09 <fwp_closure_drop+0xf9>
    6cf7:	eb 49                	jmp    6d42 <fwp_closure_drop+0x132>
    6cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6d04:	48 85 c0             	test   %rax,%rax
    6d07:	74 39                	je     6d42 <fwp_closure_drop+0x132>
    6d09:	48 89 c1             	mov    %rax,%rcx
    6d0c:	48 39 10             	cmp    %rdx,(%rax)
    6d0f:	75 ef                	jne    6d00 <fwp_closure_drop+0xf0>
    6d11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6d19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6d1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d24:	74 05                	je     6d2b <fwp_closure_drop+0x11b>
    6d26:	48 83 c4 18          	add    $0x18,%rsp
    6d2a:	c3                   	ret
    6d2b:	48 89 d7             	mov    %rdx,%rdi
    6d2e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d33:	e8 98 ea ff ff       	call   57d0 <fwp_rc_forget_slot>
    6d38:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d3d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6d40:	eb e4                	jmp    6d26 <fwp_closure_drop+0x116>
    6d42:	48 8d 3d a7 5c 00 00 	lea    0x5ca7(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    6d49:	e8 02 d7 ff ff       	call   4450 <fwp_trap>
    6d4e:	66 90                	xchg   %ax,%ax

0000000000006d50 <fwp_owned_tape_release>:
    6d50:	48 85 ff             	test   %rdi,%rdi
    6d53:	0f 84 f7 00 00 00    	je     6e50 <fwp_owned_tape_release+0x100>
    6d59:	41 54                	push   %r12
    6d5b:	55                   	push   %rbp
    6d5c:	53                   	push   %rbx
    6d5d:	48 8b 07             	mov    (%rdi),%rax
    6d60:	48 85 c0             	test   %rax,%rax
    6d63:	74 08                	je     6d6d <fwp_owned_tape_release+0x1d>
    6d65:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6d69:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6d6d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6d71:	48 85 d2             	test   %rdx,%rdx
    6d74:	74 03                	je     6d79 <fwp_owned_tape_release+0x29>
    6d76:	48 89 02             	mov    %rax,(%rdx)
    6d79:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6d7d:	48 89 fb             	mov    %rdi,%rbx
    6d80:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6d84:	48 85 c0             	test   %rax,%rax
    6d87:	0f 84 89 00 00 00    	je     6e16 <fwp_owned_tape_release+0xc6>
    6d8d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6d91:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6d95:	7e 47                	jle    6dde <fwp_owned_tape_release+0x8e>
    6d97:	31 ed                	xor    %ebp,%ebp
    6d99:	eb 0d                	jmp    6da8 <fwp_owned_tape_release+0x58>
    6d9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6da0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6da4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6da8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6dac:	49 89 ec             	mov    %rbp,%r12
    6daf:	48 83 c5 01          	add    $0x1,%rbp
    6db3:	49 c1 e4 04          	shl    $0x4,%r12
    6db7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6dbb:	ff d0                	call   *%rax
    6dbd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6dc1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6dc6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6dca:	ff 50 68             	call   *0x68(%rax)
    6dcd:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6dd1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6dd5:	48 39 e8             	cmp    %rbp,%rax
    6dd8:	7f c6                	jg     6da0 <fwp_owned_tape_release+0x50>
    6dda:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6dde:	31 ed                	xor    %ebp,%ebp
    6de0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6de5:	7e 28                	jle    6e0f <fwp_owned_tape_release+0xbf>
    6de7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dee:	00 00 
    6df0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6df4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6df8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6dfc:	74 07                	je     6e05 <fwp_owned_tape_release+0xb5>
    6dfe:	ff 52 68             	call   *0x68(%rdx)
    6e01:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e05:	48 83 c5 01          	add    $0x1,%rbp
    6e09:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6e0d:	7f e1                	jg     6df0 <fwp_owned_tape_release+0xa0>
    6e0f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6e13:	ff 52 68             	call   *0x68(%rdx)
    6e16:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6e1a:	e8 f1 fd ff ff       	call   6c10 <fwp_closure_drop>
    6e1f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6e23:	e8 e8 fd ff ff       	call   6c10 <fwp_closure_drop>
    6e28:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6e2c:	e8 df fd ff ff       	call   6c10 <fwp_closure_drop>
    6e31:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6e35:	e8 d6 eb ff ff       	call   5a10 <fwp_mem_free>
    6e3a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6e3e:	e8 cd eb ff ff       	call   5a10 <fwp_mem_free>
    6e43:	48 89 df             	mov    %rbx,%rdi
    6e46:	5b                   	pop    %rbx
    6e47:	5d                   	pop    %rbp
    6e48:	41 5c                	pop    %r12
    6e4a:	e9 c1 eb ff ff       	jmp    5a10 <fwp_mem_free>
    6e4f:	90                   	nop
    6e50:	c3                   	ret
    6e51:	0f 1f 40 00          	nopl   0x0(%rax)
    6e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e5c:	00 00 00 00 

0000000000006e60 <fwp_tape_finish>:
    6e60:	f3 0f 1e fa          	endbr64
    6e64:	41 55                	push   %r13
    6e66:	41 54                	push   %r12
    6e68:	55                   	push   %rbp
    6e69:	53                   	push   %rbx
    6e6a:	48 83 ec 48          	sub    $0x48,%rsp
    6e6e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    6e75:	00 00 
    6e77:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    6e7c:	48 8d 3d 1d 92 01 00 	lea    0x1921d(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    6e83:	e8 b8 e2 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6e88:	48 83 3d 58 92 01 00 	cmpq   $0x0,0x19258(%rip)        # 200e8 <fwp_ntapes>
    6e8f:	00 
    6e90:	48 c7 05 ed 91 01 00 	movq   $0x0,0x191ed(%rip)        # 20088 <fwp_tape_cached_bytes>
    6e97:	00 00 00 00 
    6e9b:	7e 79                	jle    6f16 <fwp_tape_finish+0xb6>
    6e9d:	45 31 e4             	xor    %r12d,%r12d
    6ea0:	31 ed                	xor    %ebp,%ebp
    6ea2:	0f 1f 00             	nopl   (%rax)
    6ea5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6eac:	00 00 00 00 
    6eb0:	48 8b 1d 39 92 01 00 	mov    0x19239(%rip),%rbx        # 200f0 <fwp_tapes>
    6eb7:	48 83 c5 01          	add    $0x1,%rbp
    6ebb:	4c 01 e3             	add    %r12,%rbx
    6ebe:	49 83 c4 68          	add    $0x68,%r12
    6ec2:	48 89 df             	mov    %rbx,%rdi
    6ec5:	e8 c6 cd ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6eca:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    6ecf:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    6ed4:	48 89 e7             	mov    %rsp,%rdi
    6ed7:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6edb:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6edf:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6ee4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ee9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    6eee:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    6ef2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6ef7:	e8 44 e2 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6efc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6f00:	e8 4b fe ff ff       	call   6d50 <fwp_owned_tape_release>
    6f05:	48 39 2d dc 91 01 00 	cmp    %rbp,0x191dc(%rip)        # 200e8 <fwp_ntapes>
    6f0c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6f13:	00 
    6f14:	7f 9a                	jg     6eb0 <fwp_tape_finish+0x50>
    6f16:	48 8b 3d d3 91 01 00 	mov    0x191d3(%rip),%rdi        # 200f0 <fwp_tapes>
    6f1d:	48 85 ff             	test   %rdi,%rdi
    6f20:	74 05                	je     6f27 <fwp_tape_finish+0xc7>
    6f22:	e8 a9 e1 ff ff       	call   50d0 <ad_raw_free.part.0>
    6f27:	48 c7 05 be 91 01 00 	movq   $0x0,0x191be(%rip)        # 200f0 <fwp_tapes>
    6f2e:	00 00 00 00 
    6f32:	48 c7 05 a3 91 01 00 	movq   $0x0,0x191a3(%rip)        # 200e0 <fwp_tapes_cap>
    6f39:	00 00 00 00 
    6f3d:	48 c7 05 a0 91 01 00 	movq   $0x0,0x191a0(%rip)        # 200e8 <fwp_ntapes>
    6f44:	00 00 00 00 
    6f48:	48 c7 05 85 91 01 00 	movq   $0x0,0x19185(%rip)        # 200d8 <fwp_tape_next_slot>
    6f4f:	00 00 00 00 
    6f53:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6f58:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f5f:	00 00 
    6f61:	75 0b                	jne    6f6e <fwp_tape_finish+0x10e>
    6f63:	48 83 c4 48          	add    $0x48,%rsp
    6f67:	5b                   	pop    %rbx
    6f68:	5d                   	pop    %rbp
    6f69:	41 5c                	pop    %r12
    6f6b:	41 5d                	pop    %r13
    6f6d:	c3                   	ret
    6f6e:	e8 dd c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    6f73:	66 90                	xchg   %ax,%ax
    6f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f7c:	00 00 00 00 

0000000000006f80 <fwp_tape_scope_release>:
    6f80:	f3 0f 1e fa          	endbr64
    6f84:	41 55                	push   %r13
    6f86:	41 54                	push   %r12
    6f88:	55                   	push   %rbp
    6f89:	53                   	push   %rbx
    6f8a:	48 83 ec 48          	sub    $0x48,%rsp
    6f8e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f95:	00 00 
    6f97:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6f9c:	48 63 07             	movslq (%rdi),%rax
    6f9f:	85 c0                	test   %eax,%eax
    6fa1:	0f 88 e8 00 00 00    	js     708f <fwp_tape_scope_release+0x10f>
    6fa7:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    6fae:	ec c4 4e 
    6fb1:	48 89 fb             	mov    %rdi,%rbx
    6fb4:	48 89 e5             	mov    %rsp,%rbp
    6fb7:	eb 1f                	jmp    6fd8 <fwp_tape_scope_release+0x58>
    6fb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fc0:	e8 7b e1 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6fc5:	4c 89 ef             	mov    %r13,%rdi
    6fc8:	e8 83 fd ff ff       	call   6d50 <fwp_owned_tape_release>
    6fcd:	48 63 03             	movslq (%rbx),%rax
    6fd0:	85 c0                	test   %eax,%eax
    6fd2:	0f 88 b7 00 00 00    	js     708f <fwp_tape_scope_release+0x10f>
    6fd8:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6fdc:	48 8b 35 0d 91 01 00 	mov    0x1910d(%rip),%rsi        # 200f0 <fwp_tapes>
    6fe3:	4c 01 c6             	add    %r8,%rsi
    6fe6:	48 89 f7             	mov    %rsi,%rdi
    6fe9:	e8 a2 cc ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6fee:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6ff3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6ff8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6fff:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7003:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7007:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    700e:	00 
    700f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7014:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7019:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    701d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7022:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7026:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    702b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7032:	00 
    7033:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    703a:	00 
    703b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7042:	00 
    7043:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7047:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    704b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    704f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7053:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7059:	77 18                	ja     7073 <fwp_tape_scope_release+0xf3>
    705b:	49 c1 f8 03          	sar    $0x3,%r8
    705f:	4d 0f af c4          	imul   %r12,%r8
    7063:	4c 3b 05 6e 90 01 00 	cmp    0x1906e(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    706a:	7d 07                	jge    7073 <fwp_tape_scope_release+0xf3>
    706c:	4c 89 05 65 90 01 00 	mov    %r8,0x19065(%rip)        # 200d8 <fwp_tape_next_slot>
    7073:	48 89 ef             	mov    %rbp,%rdi
    7076:	4d 85 ed             	test   %r13,%r13
    7079:	0f 85 41 ff ff ff    	jne    6fc0 <fwp_tape_scope_release+0x40>
    707f:	e8 dc e1 ff ff       	call   5260 <fwp_tape_buffers_release>
    7084:	48 63 03             	movslq (%rbx),%rax
    7087:	85 c0                	test   %eax,%eax
    7089:	0f 89 49 ff ff ff    	jns    6fd8 <fwp_tape_scope_release+0x58>
    708f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7094:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    709b:	00 00 
    709d:	75 0b                	jne    70aa <fwp_tape_scope_release+0x12a>
    709f:	48 83 c4 48          	add    $0x48,%rsp
    70a3:	5b                   	pop    %rbx
    70a4:	5d                   	pop    %rbp
    70a5:	41 5c                	pop    %r12
    70a7:	41 5d                	pop    %r13
    70a9:	c3                   	ret
    70aa:	e8 a1 c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    70af:	90                   	nop

00000000000070b0 <fwp_drop4>:
    70b0:	48 8b 0d 41 2b 06 00 	mov    0x62b41(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    70b7:	48 89 f8             	mov    %rdi,%rax
    70ba:	48 2b 05 0f 2b 06 00 	sub    0x62b0f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    70c1:	48 c1 e1 10          	shl    $0x10,%rcx
    70c5:	48 39 c8             	cmp    %rcx,%rax
    70c8:	0f 83 42 01 00 00    	jae    7210 <fwp_drop4+0x160>
    70ce:	48 83 ec 18          	sub    $0x18,%rsp
    70d2:	48 89 fa             	mov    %rdi,%rdx
    70d5:	4c 8d 05 44 17 06 00 	lea    0x61744(%rip),%r8        # 68820 <fwp_heap>
    70dc:	48 89 c1             	mov    %rax,%rcx
    70df:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    70e6:	48 c1 e9 10          	shr    $0x10,%rcx
    70ea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    70ee:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    70f2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    70f6:	48 85 c9             	test   %rcx,%rcx
    70f9:	74 40                	je     713b <fwp_drop4+0x8b>
    70fb:	0f b6 3e             	movzbl (%rsi),%edi
    70fe:	40 80 ff 02          	cmp    $0x2,%dil
    7102:	74 3c                	je     7140 <fwp_drop4+0x90>
    7104:	40 80 ff 01          	cmp    $0x1,%dil
    7108:	75 31                	jne    713b <fwp_drop4+0x8b>
    710a:	8b 7e 18             	mov    0x18(%rsi),%edi
    710d:	0f b7 c0             	movzwl %ax,%eax
    7110:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7113:	48 0f af c7          	imul   %rdi,%rax
    7117:	48 c1 e8 20          	shr    $0x20,%rax
    711b:	48 39 f0             	cmp    %rsi,%rax
    711e:	73 1b                	jae    713b <fwp_drop4+0x8b>
    7120:	48 01 c1             	add    %rax,%rcx
    7123:	0f b6 01             	movzbl (%rcx),%eax
    7126:	84 c0                	test   %al,%al
    7128:	74 11                	je     713b <fwp_drop4+0x8b>
    712a:	3c 01                	cmp    $0x1,%al
    712c:	74 22                	je     7150 <fwp_drop4+0xa0>
    712e:	3c ff                	cmp    $0xff,%al
    7130:	0f 84 0a 01 00 00    	je     7240 <fwp_drop4+0x190>
    7136:	83 e8 01             	sub    $0x1,%eax
    7139:	88 01                	mov    %al,(%rcx)
    713b:	48 83 c4 18          	add    $0x18,%rsp
    713f:	c3                   	ret
    7140:	66 85 c0             	test   %ax,%ax
    7143:	74 de                	je     7123 <fwp_drop4+0x73>
    7145:	48 83 c4 18          	add    $0x18,%rsp
    7149:	c3                   	ret
    714a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7150:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7154:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    715b:	48 89 f8             	mov    %rdi,%rax
    715e:	48 c1 e1 10          	shl    $0x10,%rcx
    7162:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7169:	48 39 c8             	cmp    %rcx,%rax
    716c:	73 62                	jae    71d0 <fwp_drop4+0x120>
    716e:	48 89 c1             	mov    %rax,%rcx
    7171:	48 c1 e9 10          	shr    $0x10,%rcx
    7175:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7179:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    717d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7181:	48 85 c9             	test   %rcx,%rcx
    7184:	74 4a                	je     71d0 <fwp_drop4+0x120>
    7186:	44 0f b6 0e          	movzbl (%rsi),%r9d
    718a:	41 80 f9 02          	cmp    $0x2,%r9b
    718e:	0f 84 9c 00 00 00    	je     7230 <fwp_drop4+0x180>
    7194:	41 80 f9 01          	cmp    $0x1,%r9b
    7198:	75 36                	jne    71d0 <fwp_drop4+0x120>
    719a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    719e:	0f b7 c0             	movzwl %ax,%eax
    71a1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71a4:	49 0f af c1          	imul   %r9,%rax
    71a8:	48 c1 e8 20          	shr    $0x20,%rax
    71ac:	48 39 f0             	cmp    %rsi,%rax
    71af:	73 1f                	jae    71d0 <fwp_drop4+0x120>
    71b1:	48 01 c1             	add    %rax,%rcx
    71b4:	0f b6 01             	movzbl (%rcx),%eax
    71b7:	84 c0                	test   %al,%al
    71b9:	74 15                	je     71d0 <fwp_drop4+0x120>
    71bb:	3c 01                	cmp    $0x1,%al
    71bd:	74 59                	je     7218 <fwp_drop4+0x168>
    71bf:	3c ff                	cmp    $0xff,%al
    71c1:	0f 84 ff 00 00 00    	je     72c6 <fwp_drop4+0x216>
    71c7:	83 e8 01             	sub    $0x1,%eax
    71ca:	88 01                	mov    %al,(%rcx)
    71cc:	0f 1f 40 00          	nopl   0x0(%rax)
    71d0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    71d4:	48 89 d7             	mov    %rdx,%rdi
    71d7:	48 89 0c 24          	mov    %rcx,(%rsp)
    71db:	e8 00 f7 ff ff       	call   68e0 <fwp_rc_free_obj>
    71e0:	4c 8d 05 39 16 06 00 	lea    0x61639(%rip),%r8        # 68820 <fwp_heap>
    71e7:	48 8b 04 24          	mov    (%rsp),%rax
    71eb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    71f2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    71f9:	48 c1 e2 10          	shl    $0x10,%rdx
    71fd:	48 39 d0             	cmp    %rdx,%rax
    7200:	0f 83 35 ff ff ff    	jae    713b <fwp_drop4+0x8b>
    7206:	48 8b 14 24          	mov    (%rsp),%rdx
    720a:	e9 cd fe ff ff       	jmp    70dc <fwp_drop4+0x2c>
    720f:	90                   	nop
    7210:	c3                   	ret
    7211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7218:	48 89 14 24          	mov    %rdx,(%rsp)
    721c:	e8 bf f6 ff ff       	call   68e0 <fwp_rc_free_obj>
    7221:	48 8b 14 24          	mov    (%rsp),%rdx
    7225:	eb a9                	jmp    71d0 <fwp_drop4+0x120>
    7227:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    722e:	00 00 
    7230:	66 85 c0             	test   %ax,%ax
    7233:	75 9b                	jne    71d0 <fwp_drop4+0x120>
    7235:	e9 7a ff ff ff       	jmp    71b4 <fwp_drop4+0x104>
    723a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7240:	48 89 c8             	mov    %rcx,%rax
    7243:	48 c1 e8 11          	shr    $0x11,%rax
    7247:	48 31 c8             	xor    %rcx,%rax
    724a:	48 89 c2             	mov    %rax,%rdx
    724d:	48 c1 ea 09          	shr    $0x9,%rdx
    7251:	48 31 d0             	xor    %rdx,%rax
    7254:	0f b6 d0             	movzbl %al,%edx
    7257:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    725e:	00 
    725f:	48 85 c0             	test   %rax,%rax
    7262:	75 29                	jne    728d <fwp_drop4+0x1dd>
    7264:	e9 e3 00 00 00       	jmp    734c <fwp_drop4+0x29c>
    7269:	90                   	nop
    726a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7271:	00 00 00 00 
    7275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    727c:	00 00 00 00 
    7280:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7284:	48 85 c0             	test   %rax,%rax
    7287:	0f 84 bf 00 00 00    	je     734c <fwp_drop4+0x29c>
    728d:	48 89 c2             	mov    %rax,%rdx
    7290:	48 39 08             	cmp    %rcx,(%rax)
    7293:	75 eb                	jne    7280 <fwp_drop4+0x1d0>
    7295:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7299:	48 83 ea 01          	sub    $0x1,%rdx
    729d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    72a1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    72a8:	0f 85 8d fe ff ff    	jne    713b <fwp_drop4+0x8b>
    72ae:	48 89 cf             	mov    %rcx,%rdi
    72b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    72b5:	e8 16 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    72ba:	48 8b 0c 24          	mov    (%rsp),%rcx
    72be:	c6 01 fe             	movb   $0xfe,(%rcx)
    72c1:	e9 75 fe ff ff       	jmp    713b <fwp_drop4+0x8b>
    72c6:	48 89 ce             	mov    %rcx,%rsi
    72c9:	48 c1 ee 11          	shr    $0x11,%rsi
    72cd:	48 31 ce             	xor    %rcx,%rsi
    72d0:	48 89 f0             	mov    %rsi,%rax
    72d3:	48 c1 e8 09          	shr    $0x9,%rax
    72d7:	48 31 c6             	xor    %rax,%rsi
    72da:	40 0f b6 f6          	movzbl %sil,%esi
    72de:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    72e5:	00 
    72e6:	48 85 c0             	test   %rax,%rax
    72e9:	75 1e                	jne    7309 <fwp_drop4+0x259>
    72eb:	eb 5f                	jmp    734c <fwp_drop4+0x29c>
    72ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    72f4:	00 
    72f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72fc:	00 00 00 00 
    7300:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7304:	48 85 c0             	test   %rax,%rax
    7307:	74 43                	je     734c <fwp_drop4+0x29c>
    7309:	48 89 c6             	mov    %rax,%rsi
    730c:	48 39 08             	cmp    %rcx,(%rax)
    730f:	75 ef                	jne    7300 <fwp_drop4+0x250>
    7311:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7315:	48 83 ee 01          	sub    $0x1,%rsi
    7319:	48 89 70 08          	mov    %rsi,0x8(%rax)
    731d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7324:	0f 85 a6 fe ff ff    	jne    71d0 <fwp_drop4+0x120>
    732a:	48 89 cf             	mov    %rcx,%rdi
    732d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7332:	48 89 0c 24          	mov    %rcx,(%rsp)
    7336:	e8 95 e4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    733b:	48 8b 0c 24          	mov    (%rsp),%rcx
    733f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7344:	c6 01 fe             	movb   $0xfe,(%rcx)
    7347:	e9 84 fe ff ff       	jmp    71d0 <fwp_drop4+0x120>
    734c:	48 8d 3d 9d 56 00 00 	lea    0x569d(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    7353:	e8 f8 d0 ff ff       	call   4450 <fwp_trap>
    7358:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    735f:	00 

0000000000007360 <fwp_arg_drop37>:
    7360:	f3 0f 1e fa          	endbr64
    7364:	85 f6                	test   %esi,%esi
    7366:	75 04                	jne    736c <fwp_arg_drop37+0xc>
    7368:	85 d2                	test   %edx,%edx
    736a:	75 04                	jne    7370 <fwp_arg_drop37+0x10>
    736c:	c3                   	ret
    736d:	0f 1f 00             	nopl   (%rax)
    7370:	48 8b 3f             	mov    (%rdi),%rdi
    7373:	e9 38 fd ff ff       	jmp    70b0 <fwp_drop4>
    7378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    737f:	00 

0000000000007380 <fwp_task_dispose>:
    7380:	53                   	push   %rbx
    7381:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7385:	0f 84 bb c3 ff ff    	je     3746 <fwp_task_dispose.cold>
    738b:	48 89 fb             	mov    %rdi,%rbx
    738e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7393:	0f 85 ad c3 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7399:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    739d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    73a4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    73ab:	00 
    73ac:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    73b0:	48 85 ff             	test   %rdi,%rdi
    73b3:	74 07                	je     73bc <fwp_task_dispose+0x3c>
    73b5:	48 85 c0             	test   %rax,%rax
    73b8:	74 02                	je     73bc <fwp_task_dispose+0x3c>
    73ba:	ff d0                	call   *%rax
    73bc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    73c3:	e8 48 e6 ff ff       	call   5a10 <fwp_mem_free>
    73c8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    73cf:	00 00 00 00 
    73d3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    73d7:	74 6f                	je     7448 <fwp_task_dispose+0xc8>
    73d9:	48 8b 15 18 28 06 00 	mov    0x62818(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    73e0:	48 89 d8             	mov    %rbx,%rax
    73e3:	48 2b 05 e6 27 06 00 	sub    0x627e6(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    73ea:	48 c1 e2 10          	shl    $0x10,%rdx
    73ee:	48 39 d0             	cmp    %rdx,%rax
    73f1:	73 4c                	jae    743f <fwp_task_dispose+0xbf>
    73f3:	48 89 c2             	mov    %rax,%rdx
    73f6:	48 c1 ea 10          	shr    $0x10,%rdx
    73fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    73fe:	48 8b 15 13 28 06 00 	mov    0x62813(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    7405:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7409:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    740d:	48 85 c9             	test   %rcx,%rcx
    7410:	74 2d                	je     743f <fwp_task_dispose+0xbf>
    7412:	0f b6 32             	movzbl (%rdx),%esi
    7415:	40 80 fe 02          	cmp    $0x2,%sil
    7419:	74 3d                	je     7458 <fwp_task_dispose+0xd8>
    741b:	40 80 fe 01          	cmp    $0x1,%sil
    741f:	75 1e                	jne    743f <fwp_task_dispose+0xbf>
    7421:	8b 72 18             	mov    0x18(%rdx),%esi
    7424:	0f b7 c0             	movzwl %ax,%eax
    7427:	8b 52 1c             	mov    0x1c(%rdx),%edx
    742a:	48 0f af c6          	imul   %rsi,%rax
    742e:	48 c1 e8 20          	shr    $0x20,%rax
    7432:	48 39 d0             	cmp    %rdx,%rax
    7435:	73 08                	jae    743f <fwp_task_dispose+0xbf>
    7437:	48 01 c1             	add    %rax,%rcx
    743a:	80 39 01             	cmpb   $0x1,(%rcx)
    743d:	74 09                	je     7448 <fwp_task_dispose+0xc8>
    743f:	5b                   	pop    %rbx
    7440:	c3                   	ret
    7441:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7448:	48 89 df             	mov    %rbx,%rdi
    744b:	5b                   	pop    %rbx
    744c:	e9 bf e5 ff ff       	jmp    5a10 <fwp_mem_free>
    7451:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7458:	66 85 c0             	test   %ax,%ax
    745b:	74 dd                	je     743a <fwp_task_dispose+0xba>
    745d:	5b                   	pop    %rbx
    745e:	c3                   	ret
    745f:	90                   	nop

0000000000007460 <fwp_free_zombie>:
    7460:	48 8b 15 89 13 06 00 	mov    0x61389(%rip),%rdx        # 687f0 <fwp_zombie>
    7467:	48 85 d2             	test   %rdx,%rdx
    746a:	0f 84 98 00 00 00    	je     7508 <fwp_free_zombie+0xa8>
    7470:	48 3b 15 89 13 06 00 	cmp    0x61389(%rip),%rdx        # 68800 <fwp_cur>
    7477:	0f 84 8b 00 00 00    	je     7508 <fwp_free_zombie+0xa8>
    747d:	48 83 ec 18          	sub    $0x18,%rsp
    7481:	48 63 05 4c 0d 06 00 	movslq 0x60d4c(%rip),%rax        # 681d4 <fwp_stack_pool_n>
    7488:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    748c:	83 f8 3f             	cmp    $0x3f,%eax
    748f:	7f 7f                	jg     7510 <fwp_free_zombie+0xb0>
    7491:	8d 48 01             	lea    0x1(%rax),%ecx
    7494:	89 0d 3a 0d 06 00    	mov    %ecx,0x60d3a(%rip)        # 681d4 <fwp_stack_pool_n>
    749a:	48 8d 0d 3f 0d 06 00 	lea    0x60d3f(%rip),%rcx        # 681e0 <fwp_stack_pool>
    74a1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    74a5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    74ac:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74b0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    74b7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    74bb:	48 85 c9             	test   %rcx,%rcx
    74be:	0f 84 fc 00 00 00    	je     75c0 <fwp_free_zombie+0x160>
    74c4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    74cb:	48 85 c0             	test   %rax,%rax
    74ce:	74 07                	je     74d7 <fwp_free_zombie+0x77>
    74d0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    74d7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    74da:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74de:	48 c7 05 07 13 06 00 	movq   $0x0,0x61307(%rip)        # 687f0 <fwp_zombie>
    74e5:	00 00 00 00 
    74e9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    74f0:	85 c0                	test   %eax,%eax
    74f2:	74 34                	je     7528 <fwp_free_zombie+0xc8>
    74f4:	83 f8 01             	cmp    $0x1,%eax
    74f7:	0f 84 b3 00 00 00    	je     75b0 <fwp_free_zombie+0x150>
    74fd:	48 83 c4 18          	add    $0x18,%rsp
    7501:	c3                   	ret
    7502:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7508:	c3                   	ret
    7509:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7510:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7514:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7519:	e8 a2 c0 ff ff       	call   35c0 <munmap@plt>
    751e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7523:	eb 80                	jmp    74a5 <fwp_free_zombie+0x45>
    7525:	0f 1f 00             	nopl   (%rax)
    7528:	48 8b 0d c9 26 06 00 	mov    0x626c9(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    752f:	48 89 d0             	mov    %rdx,%rax
    7532:	48 2b 05 97 26 06 00 	sub    0x62697(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7539:	48 c1 e1 10          	shl    $0x10,%rcx
    753d:	48 39 c8             	cmp    %rcx,%rax
    7540:	73 bb                	jae    74fd <fwp_free_zombie+0x9d>
    7542:	48 89 c1             	mov    %rax,%rcx
    7545:	48 c1 e9 10          	shr    $0x10,%rcx
    7549:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    754d:	48 8b 0d c4 26 06 00 	mov    0x626c4(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    7554:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7558:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    755c:	48 85 c9             	test   %rcx,%rcx
    755f:	74 9c                	je     74fd <fwp_free_zombie+0x9d>
    7561:	0f b6 3e             	movzbl (%rsi),%edi
    7564:	40 80 ff 02          	cmp    $0x2,%dil
    7568:	74 66                	je     75d0 <fwp_free_zombie+0x170>
    756a:	40 80 ff 01          	cmp    $0x1,%dil
    756e:	75 8d                	jne    74fd <fwp_free_zombie+0x9d>
    7570:	8b 7e 18             	mov    0x18(%rsi),%edi
    7573:	0f b7 c0             	movzwl %ax,%eax
    7576:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7579:	48 0f af c7          	imul   %rdi,%rax
    757d:	48 c1 e8 20          	shr    $0x20,%rax
    7581:	48 39 f0             	cmp    %rsi,%rax
    7584:	0f 83 73 ff ff ff    	jae    74fd <fwp_free_zombie+0x9d>
    758a:	48 01 c1             	add    %rax,%rcx
    758d:	0f b6 01             	movzbl (%rcx),%eax
    7590:	84 c0                	test   %al,%al
    7592:	0f 84 65 ff ff ff    	je     74fd <fwp_free_zombie+0x9d>
    7598:	3c 01                	cmp    $0x1,%al
    759a:	74 14                	je     75b0 <fwp_free_zombie+0x150>
    759c:	3c ff                	cmp    $0xff,%al
    759e:	74 3b                	je     75db <fwp_free_zombie+0x17b>
    75a0:	83 e8 01             	sub    $0x1,%eax
    75a3:	88 01                	mov    %al,(%rcx)
    75a5:	e9 53 ff ff ff       	jmp    74fd <fwp_free_zombie+0x9d>
    75aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75b0:	48 89 d7             	mov    %rdx,%rdi
    75b3:	48 83 c4 18          	add    $0x18,%rsp
    75b7:	e9 c4 fd ff ff       	jmp    7380 <fwp_task_dispose>
    75bc:	0f 1f 40 00          	nopl   0x0(%rax)
    75c0:	48 89 05 01 12 06 00 	mov    %rax,0x61201(%rip)        # 687c8 <fwp_tasks_active>
    75c7:	e9 ff fe ff ff       	jmp    74cb <fwp_free_zombie+0x6b>
    75cc:	0f 1f 40 00          	nopl   0x0(%rax)
    75d0:	66 85 c0             	test   %ax,%ax
    75d3:	0f 85 24 ff ff ff    	jne    74fd <fwp_free_zombie+0x9d>
    75d9:	eb b2                	jmp    758d <fwp_free_zombie+0x12d>
    75db:	48 89 ca             	mov    %rcx,%rdx
    75de:	48 8d 35 3b 12 06 00 	lea    0x6123b(%rip),%rsi        # 68820 <fwp_heap>
    75e5:	48 c1 ea 11          	shr    $0x11,%rdx
    75e9:	48 31 ca             	xor    %rcx,%rdx
    75ec:	48 89 d0             	mov    %rdx,%rax
    75ef:	48 c1 e8 09          	shr    $0x9,%rax
    75f3:	48 31 c2             	xor    %rax,%rdx
    75f6:	0f b6 d2             	movzbl %dl,%edx
    75f9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7600:	00 
    7601:	48 85 c0             	test   %rax,%rax
    7604:	75 23                	jne    7629 <fwp_free_zombie+0x1c9>
    7606:	eb 5c                	jmp    7664 <fwp_free_zombie+0x204>
    7608:	66 90                	xchg   %ax,%ax
    760a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7611:	00 00 00 00 
    7615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    761c:	00 00 00 00 
    7620:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7624:	48 85 c0             	test   %rax,%rax
    7627:	74 3b                	je     7664 <fwp_free_zombie+0x204>
    7629:	48 89 c2             	mov    %rax,%rdx
    762c:	48 39 08             	cmp    %rcx,(%rax)
    762f:	75 ef                	jne    7620 <fwp_free_zombie+0x1c0>
    7631:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7635:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7639:	48 89 50 08          	mov    %rdx,0x8(%rax)
    763d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7644:	0f 85 b3 fe ff ff    	jne    74fd <fwp_free_zombie+0x9d>
    764a:	48 89 cf             	mov    %rcx,%rdi
    764d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7652:	e8 79 e1 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7657:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    765c:	c6 01 fe             	movb   $0xfe,(%rcx)
    765f:	e9 99 fe ff ff       	jmp    74fd <fwp_free_zombie+0x9d>
    7664:	48 8d 3d 85 53 00 00 	lea    0x5385(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    766b:	e8 e0 cd ff ff       	call   4450 <fwp_trap>

0000000000007670 <fwp_block>:
    7670:	48 83 ec 08          	sub    $0x8,%rsp
    7674:	48 8b 05 6d 11 06 00 	mov    0x6116d(%rip),%rax        # 687e8 <fwp_ready_head>
    767b:	48 85 c0             	test   %rax,%rax
    767e:	0f 84 1c 01 00 00    	je     77a0 <fwp_block+0x130>
    7684:	90                   	nop
    7685:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    768c:	00 00 00 00 
    7690:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7697:	48 89 15 4a 11 06 00 	mov    %rdx,0x6114a(%rip)        # 687e8 <fwp_ready_head>
    769e:	48 85 d2             	test   %rdx,%rdx
    76a1:	0f 84 19 01 00 00    	je     77c0 <fwp_block+0x150>
    76a7:	48 8b 15 52 11 06 00 	mov    0x61152(%rip),%rdx        # 68800 <fwp_cur>
    76ae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    76b2:	48 39 c2             	cmp    %rax,%rdx
    76b5:	0f 84 d5 00 00 00    	je     7790 <fwp_block+0x120>
    76bb:	48 8b 0d c6 2d 06 00 	mov    0x62dc6(%rip),%rcx        # 6a488 <fwp_state_owners>
    76c2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    76c6:	48 89 05 33 11 06 00 	mov    %rax,0x61133(%rip)        # 68800 <fwp_cur>
    76cd:	f3 0f 7e 05 db 2d 06 	movq   0x62ddb(%rip),%xmm0        # 6a4b0 <fwp_foreign_callbacks>
    76d4:	00 
    76d5:	0f 16 05 c4 2d 06 00 	movhps 0x62dc4(%rip),%xmm0        # 6a4a0 <fwp_state>
    76dc:	f3 0f 7e 0d c4 2d 06 	movq   0x62dc4(%rip),%xmm1        # 6a4a8 <fwp_handlers>
    76e3:	00 
    76e4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    76eb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    76f2:	0f 16 0d bf 2d 06 00 	movhps 0x62dbf(%rip),%xmm1        # 6a4b8 <fwp_cleanups>
    76f9:	f3 0f 7e 05 97 2d 06 	movq   0x62d97(%rip),%xmm0        # 6a498 <fwp_state_len>
    7700:	00 
    7701:	0f 16 05 88 2d 06 00 	movhps 0x62d88(%rip),%xmm0        # 6a490 <fwp_state_cap>
    7708:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    770f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7716:	48 8b 70 08          	mov    0x8(%rax),%rsi
    771a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7721:	48 89 0d 80 2d 06 00 	mov    %rcx,0x62d80(%rip)        # 6a4a8 <fwp_handlers>
    7728:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    772f:	48 89 0d 82 2d 06 00 	mov    %rcx,0x62d82(%rip)        # 6a4b8 <fwp_cleanups>
    7736:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    773d:	48 89 0d 6c 2d 06 00 	mov    %rcx,0x62d6c(%rip)        # 6a4b0 <fwp_foreign_callbacks>
    7744:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    774b:	48 89 0d 4e 2d 06 00 	mov    %rcx,0x62d4e(%rip)        # 6a4a0 <fwp_state>
    7752:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7759:	48 89 0d 38 2d 06 00 	mov    %rcx,0x62d38(%rip)        # 6a498 <fwp_state_len>
    7760:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7767:	48 89 0d 22 2d 06 00 	mov    %rcx,0x62d22(%rip)        # 6a490 <fwp_state_cap>
    776e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7775:	48 89 0d 0c 2d 06 00 	mov    %rcx,0x62d0c(%rip)        # 6a488 <fwp_state_owners>
    777c:	e8 ff bc ff ff       	call   3480 <swapcontext@plt>
    7781:	f3 0f 1e fa          	endbr64
    7785:	e8 d6 fc ff ff       	call   7460 <fwp_free_zombie>
    778a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7790:	8b 05 3a 0a 06 00    	mov    0x60a3a(%rip),%eax        # 681d0 <fwp_slice>
    7796:	85 c0                	test   %eax,%eax
    7798:	74 36                	je     77d0 <fwp_block+0x160>
    779a:	48 83 c4 08          	add    $0x8,%rsp
    779e:	c3                   	ret
    779f:	90                   	nop
    77a0:	e8 6b dc ff ff       	call   5410 <fwp_poll_events>
    77a5:	48 8b 05 3c 10 06 00 	mov    0x6103c(%rip),%rax        # 687e8 <fwp_ready_head>
    77ac:	48 85 c0             	test   %rax,%rax
    77af:	0f 85 db fe ff ff    	jne    7690 <fwp_block+0x20>
    77b5:	eb e9                	jmp    77a0 <fwp_block+0x130>
    77b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77be:	00 00 
    77c0:	48 c7 05 15 10 06 00 	movq   $0x0,0x61015(%rip)        # 687e0 <fwp_ready_tail>
    77c7:	00 00 00 00 
    77cb:	e9 d7 fe ff ff       	jmp    76a7 <fwp_block+0x37>
    77d0:	48 8d 3d 08 4a 00 00 	lea    0x4a08(%rip),%rdi        # c1df <_IO_stdin_used+0x1df>
    77d7:	e8 b4 bb ff ff       	call   3390 <getenv@plt>
    77dc:	ba 10 27 00 00       	mov    $0x2710,%edx
    77e1:	48 85 c0             	test   %rax,%rax
    77e4:	74 05                	je     77eb <fwp_block+0x17b>
    77e6:	80 38 00             	cmpb   $0x0,(%rax)
    77e9:	75 0b                	jne    77f6 <fwp_block+0x186>
    77eb:	89 15 df 09 06 00    	mov    %edx,0x609df(%rip)        # 681d0 <fwp_slice>
    77f1:	48 83 c4 08          	add    $0x8,%rsp
    77f5:	c3                   	ret
    77f6:	ba 0a 00 00 00       	mov    $0xa,%edx
    77fb:	31 f6                	xor    %esi,%esi
    77fd:	48 89 c7             	mov    %rax,%rdi
    7800:	e8 3b bd ff ff       	call   3540 <strtoll@plt>
    7805:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7809:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7810:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7815:	0f 46 d0             	cmovbe %eax,%edx
    7818:	eb d1                	jmp    77eb <fwp_block+0x17b>
    781a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007820 <fwp_caps173>:
    7820:	f3 0f 1e fa          	endbr64
    7824:	85 f6                	test   %esi,%esi
    7826:	74 08                	je     7830 <fwp_caps173+0x10>
    7828:	c3                   	ret
    7829:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7830:	48 8b 15 c1 23 06 00 	mov    0x623c1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7837:	48 89 f8             	mov    %rdi,%rax
    783a:	48 2b 05 8f 23 06 00 	sub    0x6238f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7841:	48 c1 e2 10          	shl    $0x10,%rdx
    7845:	48 39 d0             	cmp    %rdx,%rax
    7848:	73 de                	jae    7828 <fwp_caps173+0x8>
    784a:	48 89 c2             	mov    %rax,%rdx
    784d:	48 c1 ea 10          	shr    $0x10,%rdx
    7851:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7855:	48 8b 15 bc 23 06 00 	mov    0x623bc(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    785c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7860:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7864:	48 85 c9             	test   %rcx,%rcx
    7867:	74 bf                	je     7828 <fwp_caps173+0x8>
    7869:	0f b6 32             	movzbl (%rdx),%esi
    786c:	40 80 fe 02          	cmp    $0x2,%sil
    7870:	74 2e                	je     78a0 <fwp_caps173+0x80>
    7872:	40 80 fe 01          	cmp    $0x1,%sil
    7876:	75 b0                	jne    7828 <fwp_caps173+0x8>
    7878:	8b 72 18             	mov    0x18(%rdx),%esi
    787b:	0f b7 c0             	movzwl %ax,%eax
    787e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7881:	48 0f af c6          	imul   %rsi,%rax
    7885:	48 c1 e8 20          	shr    $0x20,%rax
    7889:	48 39 d0             	cmp    %rdx,%rax
    788c:	73 9a                	jae    7828 <fwp_caps173+0x8>
    788e:	48 01 c1             	add    %rax,%rcx
    7891:	80 39 01             	cmpb   $0x1,(%rcx)
    7894:	75 92                	jne    7828 <fwp_caps173+0x8>
    7896:	e9 75 e1 ff ff       	jmp    5a10 <fwp_mem_free>
    789b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    78a0:	66 85 c0             	test   %ax,%ax
    78a3:	74 ec                	je     7891 <fwp_caps173+0x71>
    78a5:	c3                   	ret
    78a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78ad:	00 00 00 

00000000000078b0 <fwp_args37>:
    78b0:	f3 0f 1e fa          	endbr64
    78b4:	85 d2                	test   %edx,%edx
    78b6:	74 04                	je     78bc <fwp_args37+0xc>
    78b8:	85 f6                	test   %esi,%esi
    78ba:	74 04                	je     78c0 <fwp_args37+0x10>
    78bc:	c3                   	ret
    78bd:	0f 1f 00             	nopl   (%rax)
    78c0:	48 8b 15 31 23 06 00 	mov    0x62331(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    78c7:	48 8b 07             	mov    (%rdi),%rax
    78ca:	48 2b 05 ff 22 06 00 	sub    0x622ff(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    78d1:	48 c1 e2 10          	shl    $0x10,%rdx
    78d5:	48 39 d0             	cmp    %rdx,%rax
    78d8:	73 e2                	jae    78bc <fwp_args37+0xc>
    78da:	48 89 c2             	mov    %rax,%rdx
    78dd:	48 c1 ea 10          	shr    $0x10,%rdx
    78e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    78e5:	48 8b 15 2c 23 06 00 	mov    0x6232c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    78ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    78f4:	48 85 ff             	test   %rdi,%rdi
    78f7:	74 c3                	je     78bc <fwp_args37+0xc>
    78f9:	0f b6 0a             	movzbl (%rdx),%ecx
    78fc:	80 f9 02             	cmp    $0x2,%cl
    78ff:	74 4f                	je     7950 <fwp_args37+0xa0>
    7901:	80 f9 01             	cmp    $0x1,%cl
    7904:	75 b6                	jne    78bc <fwp_args37+0xc>
    7906:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7909:	0f b7 c0             	movzwl %ax,%eax
    790c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    790f:	48 0f af c1          	imul   %rcx,%rax
    7913:	48 c1 e8 20          	shr    $0x20,%rax
    7917:	48 39 d0             	cmp    %rdx,%rax
    791a:	73 a0                	jae    78bc <fwp_args37+0xc>
    791c:	48 01 c7             	add    %rax,%rdi
    791f:	0f b6 07             	movzbl (%rdi),%eax
    7922:	84 c0                	test   %al,%al
    7924:	74 96                	je     78bc <fwp_args37+0xc>
    7926:	8b 15 bc 2b 06 00    	mov    0x62bbc(%rip),%edx        # 6a4e8 <iteration_active>
    792c:	85 d2                	test   %edx,%edx
    792e:	75 10                	jne    7940 <fwp_args37+0x90>
    7930:	3c fd                	cmp    $0xfd,%al
    7932:	77 22                	ja     7956 <fwp_args37+0xa6>
    7934:	83 c0 01             	add    $0x1,%eax
    7937:	88 07                	mov    %al,(%rdi)
    7939:	c3                   	ret
    793a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7940:	48 83 05 88 2b 06 00 	addq   $0x1,0x62b88(%rip)        # 6a4d0 <iteration_retains>
    7947:	01 
    7948:	eb e6                	jmp    7930 <fwp_args37+0x80>
    794a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7950:	66 85 c0             	test   %ax,%ax
    7953:	74 ca                	je     791f <fwp_args37+0x6f>
    7955:	c3                   	ret
    7956:	e9 55 dd ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    795b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007960 <fwp_caps37>:
    7960:	f3 0f 1e fa          	endbr64
    7964:	48 83 ec 18          	sub    $0x18,%rsp
    7968:	48 89 f8             	mov    %rdi,%rax
    796b:	8b 7f 04             	mov    0x4(%rdi),%edi
    796e:	85 ff                	test   %edi,%edi
    7970:	0f 84 9a 00 00 00    	je     7a10 <fwp_caps37+0xb0>
    7976:	48 8b 78 08          	mov    0x8(%rax),%rdi
    797a:	85 f6                	test   %esi,%esi
    797c:	0f 85 9e 00 00 00    	jne    7a20 <fwp_caps37+0xc0>
    7982:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7987:	e8 24 f7 ff ff       	call   70b0 <fwp_drop4>
    798c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7991:	48 8b 0d 60 22 06 00 	mov    0x62260(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    7998:	48 89 c2             	mov    %rax,%rdx
    799b:	48 2b 15 2e 22 06 00 	sub    0x6222e(%rip),%rdx        # 69bd0 <fwp_heap+0x13b0>
    79a2:	48 c1 e1 10          	shl    $0x10,%rcx
    79a6:	48 39 ca             	cmp    %rcx,%rdx
    79a9:	73 6d                	jae    7a18 <fwp_caps37+0xb8>
    79ab:	48 89 d1             	mov    %rdx,%rcx
    79ae:	48 c1 e9 10          	shr    $0x10,%rcx
    79b2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    79b6:	48 8b 0d 5b 22 06 00 	mov    0x6225b(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    79bd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    79c1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    79c5:	48 85 f6             	test   %rsi,%rsi
    79c8:	74 4e                	je     7a18 <fwp_caps37+0xb8>
    79ca:	0f b6 39             	movzbl (%rcx),%edi
    79cd:	40 80 ff 02          	cmp    $0x2,%dil
    79d1:	0f 84 c9 00 00 00    	je     7aa0 <fwp_caps37+0x140>
    79d7:	40 80 ff 01          	cmp    $0x1,%dil
    79db:	75 3b                	jne    7a18 <fwp_caps37+0xb8>
    79dd:	8b 79 18             	mov    0x18(%rcx),%edi
    79e0:	0f b7 d2             	movzwl %dx,%edx
    79e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    79e6:	48 0f af d7          	imul   %rdi,%rdx
    79ea:	48 c1 ea 20          	shr    $0x20,%rdx
    79ee:	48 39 ca             	cmp    %rcx,%rdx
    79f1:	73 25                	jae    7a18 <fwp_caps37+0xb8>
    79f3:	48 01 d6             	add    %rdx,%rsi
    79f6:	80 3e 01             	cmpb   $0x1,(%rsi)
    79f9:	75 1d                	jne    7a18 <fwp_caps37+0xb8>
    79fb:	48 89 c7             	mov    %rax,%rdi
    79fe:	48 83 c4 18          	add    $0x18,%rsp
    7a02:	e9 09 e0 ff ff       	jmp    5a10 <fwp_mem_free>
    7a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a0e:	00 00 
    7a10:	85 f6                	test   %esi,%esi
    7a12:	0f 84 79 ff ff ff    	je     7991 <fwp_caps37+0x31>
    7a18:	48 83 c4 18          	add    $0x18,%rsp
    7a1c:	c3                   	ret
    7a1d:	0f 1f 00             	nopl   (%rax)
    7a20:	48 8b 05 d1 21 06 00 	mov    0x621d1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    7a27:	48 2b 3d a2 21 06 00 	sub    0x621a2(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    7a2e:	48 c1 e0 10          	shl    $0x10,%rax
    7a32:	48 39 c7             	cmp    %rax,%rdi
    7a35:	73 e1                	jae    7a18 <fwp_caps37+0xb8>
    7a37:	48 89 f8             	mov    %rdi,%rax
    7a3a:	48 c1 e8 10          	shr    $0x10,%rax
    7a3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7a42:	48 8b 05 cf 21 06 00 	mov    0x621cf(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    7a49:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7a4d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7a51:	48 85 c0             	test   %rax,%rax
    7a54:	74 c2                	je     7a18 <fwp_caps37+0xb8>
    7a56:	0f b6 0a             	movzbl (%rdx),%ecx
    7a59:	80 f9 02             	cmp    $0x2,%cl
    7a5c:	74 52                	je     7ab0 <fwp_caps37+0x150>
    7a5e:	80 f9 01             	cmp    $0x1,%cl
    7a61:	75 b5                	jne    7a18 <fwp_caps37+0xb8>
    7a63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a66:	0f b7 ff             	movzwl %di,%edi
    7a69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a6c:	48 0f af f9          	imul   %rcx,%rdi
    7a70:	48 c1 ef 20          	shr    $0x20,%rdi
    7a74:	48 39 d7             	cmp    %rdx,%rdi
    7a77:	73 9f                	jae    7a18 <fwp_caps37+0xb8>
    7a79:	48 01 f8             	add    %rdi,%rax
    7a7c:	0f b6 10             	movzbl (%rax),%edx
    7a7f:	84 d2                	test   %dl,%dl
    7a81:	74 95                	je     7a18 <fwp_caps37+0xb8>
    7a83:	8b 0d 5f 2a 06 00    	mov    0x62a5f(%rip),%ecx        # 6a4e8 <iteration_active>
    7a89:	85 c9                	test   %ecx,%ecx
    7a8b:	75 33                	jne    7ac0 <fwp_caps37+0x160>
    7a8d:	80 fa fd             	cmp    $0xfd,%dl
    7a90:	77 38                	ja     7aca <fwp_caps37+0x16a>
    7a92:	83 c2 01             	add    $0x1,%edx
    7a95:	88 10                	mov    %dl,(%rax)
    7a97:	e9 7c ff ff ff       	jmp    7a18 <fwp_caps37+0xb8>
    7a9c:	0f 1f 40 00          	nopl   0x0(%rax)
    7aa0:	66 85 d2             	test   %dx,%dx
    7aa3:	0f 85 6f ff ff ff    	jne    7a18 <fwp_caps37+0xb8>
    7aa9:	e9 48 ff ff ff       	jmp    79f6 <fwp_caps37+0x96>
    7aae:	66 90                	xchg   %ax,%ax
    7ab0:	66 85 ff             	test   %di,%di
    7ab3:	0f 85 5f ff ff ff    	jne    7a18 <fwp_caps37+0xb8>
    7ab9:	eb c1                	jmp    7a7c <fwp_caps37+0x11c>
    7abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ac0:	48 83 05 08 2a 06 00 	addq   $0x1,0x62a08(%rip)        # 6a4d0 <iteration_retains>
    7ac7:	01 
    7ac8:	eb c3                	jmp    7a8d <fwp_caps37+0x12d>
    7aca:	48 89 c7             	mov    %rax,%rdi
    7acd:	48 83 c4 18          	add    $0x18,%rsp
    7ad1:	e9 da db ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7add:	00 00 00 

0000000000007ae0 <fwp_drop0>:
    7ae0:	f3 0f 1e fa          	endbr64
    7ae4:	48 8b 15 0d 21 06 00 	mov    0x6210d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7aeb:	48 89 f8             	mov    %rdi,%rax
    7aee:	48 2b 05 db 20 06 00 	sub    0x620db(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7af5:	48 c1 e2 10          	shl    $0x10,%rdx
    7af9:	48 39 d0             	cmp    %rdx,%rax
    7afc:	0f 83 36 01 00 00    	jae    7c38 <fwp_drop0+0x158>
    7b02:	48 83 ec 18          	sub    $0x18,%rsp
    7b06:	48 8d 35 13 0d 06 00 	lea    0x60d13(%rip),%rsi        # 68820 <fwp_heap>
    7b0d:	48 89 c2             	mov    %rax,%rdx
    7b10:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7b17:	48 c1 ea 10          	shr    $0x10,%rdx
    7b1b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b1f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7b23:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b27:	48 85 d2             	test   %rdx,%rdx
    7b2a:	74 42                	je     7b6e <fwp_drop0+0x8e>
    7b2c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7b30:	41 80 f8 02          	cmp    $0x2,%r8b
    7b34:	74 42                	je     7b78 <fwp_drop0+0x98>
    7b36:	41 80 f8 01          	cmp    $0x1,%r8b
    7b3a:	75 32                	jne    7b6e <fwp_drop0+0x8e>
    7b3c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7b40:	0f b7 c0             	movzwl %ax,%eax
    7b43:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b46:	49 0f af c0          	imul   %r8,%rax
    7b4a:	48 c1 e8 20          	shr    $0x20,%rax
    7b4e:	48 39 c8             	cmp    %rcx,%rax
    7b51:	73 1b                	jae    7b6e <fwp_drop0+0x8e>
    7b53:	48 01 c2             	add    %rax,%rdx
    7b56:	0f b6 02             	movzbl (%rdx),%eax
    7b59:	84 c0                	test   %al,%al
    7b5b:	74 11                	je     7b6e <fwp_drop0+0x8e>
    7b5d:	3c 01                	cmp    $0x1,%al
    7b5f:	74 27                	je     7b88 <fwp_drop0+0xa8>
    7b61:	3c ff                	cmp    $0xff,%al
    7b63:	0f 84 e7 00 00 00    	je     7c50 <fwp_drop0+0x170>
    7b69:	83 e8 01             	sub    $0x1,%eax
    7b6c:	88 02                	mov    %al,(%rdx)
    7b6e:	48 83 c4 18          	add    $0x18,%rsp
    7b72:	c3                   	ret
    7b73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b78:	66 85 c0             	test   %ax,%ax
    7b7b:	74 d9                	je     7b56 <fwp_drop0+0x76>
    7b7d:	48 83 c4 18          	add    $0x18,%rsp
    7b81:	c3                   	ret
    7b82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b88:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b8f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b96:	48 89 f8             	mov    %rdi,%rax
    7b99:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7b9d:	48 29 c8             	sub    %rcx,%rax
    7ba0:	48 c1 e2 10          	shl    $0x10,%rdx
    7ba4:	48 39 d0             	cmp    %rdx,%rax
    7ba7:	73 71                	jae    7c1a <fwp_drop0+0x13a>
    7ba9:	49 89 c2             	mov    %rax,%r10
    7bac:	49 c1 ea 10          	shr    $0x10,%r10
    7bb0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7bb4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7bb8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7bbc:	4d 85 d2             	test   %r10,%r10
    7bbf:	74 59                	je     7c1a <fwp_drop0+0x13a>
    7bc1:	45 0f b6 19          	movzbl (%r9),%r11d
    7bc5:	41 80 fb 02          	cmp    $0x2,%r11b
    7bc9:	74 75                	je     7c40 <fwp_drop0+0x160>
    7bcb:	41 80 fb 01          	cmp    $0x1,%r11b
    7bcf:	75 49                	jne    7c1a <fwp_drop0+0x13a>
    7bd1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7bd5:	0f b7 c0             	movzwl %ax,%eax
    7bd8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7bdc:	49 0f af c3          	imul   %r11,%rax
    7be0:	48 c1 e8 20          	shr    $0x20,%rax
    7be4:	4c 39 c8             	cmp    %r9,%rax
    7be7:	73 31                	jae    7c1a <fwp_drop0+0x13a>
    7be9:	49 01 c2             	add    %rax,%r10
    7bec:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7bf0:	75 28                	jne    7c1a <fwp_drop0+0x13a>
    7bf2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7bf7:	e8 14 de ff ff       	call   5a10 <fwp_mem_free>
    7bfc:	48 8d 35 1d 0c 06 00 	lea    0x60c1d(%rip),%rsi        # 68820 <fwp_heap>
    7c03:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7c08:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7c0f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c16:	48 c1 e2 10          	shl    $0x10,%rdx
    7c1a:	4c 89 c0             	mov    %r8,%rax
    7c1d:	48 29 c8             	sub    %rcx,%rax
    7c20:	48 39 d0             	cmp    %rdx,%rax
    7c23:	0f 83 45 ff ff ff    	jae    7b6e <fwp_drop0+0x8e>
    7c29:	4c 89 c7             	mov    %r8,%rdi
    7c2c:	e9 dc fe ff ff       	jmp    7b0d <fwp_drop0+0x2d>
    7c31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c38:	c3                   	ret
    7c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c40:	66 85 c0             	test   %ax,%ax
    7c43:	75 d5                	jne    7c1a <fwp_drop0+0x13a>
    7c45:	eb a5                	jmp    7bec <fwp_drop0+0x10c>
    7c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c4e:	00 00 
    7c50:	48 89 d0             	mov    %rdx,%rax
    7c53:	48 c1 e8 11          	shr    $0x11,%rax
    7c57:	48 31 d0             	xor    %rdx,%rax
    7c5a:	48 89 c1             	mov    %rax,%rcx
    7c5d:	48 c1 e9 09          	shr    $0x9,%rcx
    7c61:	48 31 c8             	xor    %rcx,%rax
    7c64:	0f b6 c8             	movzbl %al,%ecx
    7c67:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7c6e:	00 
    7c6f:	48 85 c0             	test   %rax,%rax
    7c72:	75 15                	jne    7c89 <fwp_drop0+0x1a9>
    7c74:	eb 4e                	jmp    7cc4 <fwp_drop0+0x1e4>
    7c76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c7d:	00 00 00 
    7c80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7c84:	48 85 c0             	test   %rax,%rax
    7c87:	74 3b                	je     7cc4 <fwp_drop0+0x1e4>
    7c89:	48 89 c1             	mov    %rax,%rcx
    7c8c:	48 39 10             	cmp    %rdx,(%rax)
    7c8f:	75 ef                	jne    7c80 <fwp_drop0+0x1a0>
    7c91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7c99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7c9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ca4:	0f 85 c4 fe ff ff    	jne    7b6e <fwp_drop0+0x8e>
    7caa:	48 89 d7             	mov    %rdx,%rdi
    7cad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7cb2:	e8 19 db ff ff       	call   57d0 <fwp_rc_forget_slot>
    7cb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7cbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7cbf:	e9 aa fe ff ff       	jmp    7b6e <fwp_drop0+0x8e>
    7cc4:	48 8d 3d 25 4d 00 00 	lea    0x4d25(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    7ccb:	e8 80 c7 ff ff       	call   4450 <fwp_trap>

0000000000007cd0 <fwp_drop1>:
    7cd0:	f3 0f 1e fa          	endbr64
    7cd4:	48 8b 15 1d 1f 06 00 	mov    0x61f1d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7cdb:	48 89 f8             	mov    %rdi,%rax
    7cde:	48 2b 05 eb 1e 06 00 	sub    0x61eeb(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7ce5:	48 c1 e2 10          	shl    $0x10,%rdx
    7ce9:	48 39 d0             	cmp    %rdx,%rax
    7cec:	0f 83 36 01 00 00    	jae    7e28 <fwp_drop1+0x158>
    7cf2:	48 83 ec 18          	sub    $0x18,%rsp
    7cf6:	48 8d 35 23 0b 06 00 	lea    0x60b23(%rip),%rsi        # 68820 <fwp_heap>
    7cfd:	48 89 c2             	mov    %rax,%rdx
    7d00:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7d07:	48 c1 ea 10          	shr    $0x10,%rdx
    7d0b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7d0f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7d13:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7d17:	48 85 d2             	test   %rdx,%rdx
    7d1a:	74 42                	je     7d5e <fwp_drop1+0x8e>
    7d1c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7d20:	41 80 f8 02          	cmp    $0x2,%r8b
    7d24:	74 42                	je     7d68 <fwp_drop1+0x98>
    7d26:	41 80 f8 01          	cmp    $0x1,%r8b
    7d2a:	75 32                	jne    7d5e <fwp_drop1+0x8e>
    7d2c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7d30:	0f b7 c0             	movzwl %ax,%eax
    7d33:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d36:	49 0f af c0          	imul   %r8,%rax
    7d3a:	48 c1 e8 20          	shr    $0x20,%rax
    7d3e:	48 39 c8             	cmp    %rcx,%rax
    7d41:	73 1b                	jae    7d5e <fwp_drop1+0x8e>
    7d43:	48 01 c2             	add    %rax,%rdx
    7d46:	0f b6 02             	movzbl (%rdx),%eax
    7d49:	84 c0                	test   %al,%al
    7d4b:	74 11                	je     7d5e <fwp_drop1+0x8e>
    7d4d:	3c 01                	cmp    $0x1,%al
    7d4f:	74 27                	je     7d78 <fwp_drop1+0xa8>
    7d51:	3c ff                	cmp    $0xff,%al
    7d53:	0f 84 e7 00 00 00    	je     7e40 <fwp_drop1+0x170>
    7d59:	83 e8 01             	sub    $0x1,%eax
    7d5c:	88 02                	mov    %al,(%rdx)
    7d5e:	48 83 c4 18          	add    $0x18,%rsp
    7d62:	c3                   	ret
    7d63:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d68:	66 85 c0             	test   %ax,%ax
    7d6b:	74 d9                	je     7d46 <fwp_drop1+0x76>
    7d6d:	48 83 c4 18          	add    $0x18,%rsp
    7d71:	c3                   	ret
    7d72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d78:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d7f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d86:	48 89 f8             	mov    %rdi,%rax
    7d89:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7d8d:	48 29 c8             	sub    %rcx,%rax
    7d90:	48 c1 e2 10          	shl    $0x10,%rdx
    7d94:	48 39 d0             	cmp    %rdx,%rax
    7d97:	73 71                	jae    7e0a <fwp_drop1+0x13a>
    7d99:	49 89 c2             	mov    %rax,%r10
    7d9c:	49 c1 ea 10          	shr    $0x10,%r10
    7da0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7da4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7da8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7dac:	4d 85 d2             	test   %r10,%r10
    7daf:	74 59                	je     7e0a <fwp_drop1+0x13a>
    7db1:	45 0f b6 19          	movzbl (%r9),%r11d
    7db5:	41 80 fb 02          	cmp    $0x2,%r11b
    7db9:	74 75                	je     7e30 <fwp_drop1+0x160>
    7dbb:	41 80 fb 01          	cmp    $0x1,%r11b
    7dbf:	75 49                	jne    7e0a <fwp_drop1+0x13a>
    7dc1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7dc5:	0f b7 c0             	movzwl %ax,%eax
    7dc8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7dcc:	49 0f af c3          	imul   %r11,%rax
    7dd0:	48 c1 e8 20          	shr    $0x20,%rax
    7dd4:	4c 39 c8             	cmp    %r9,%rax
    7dd7:	73 31                	jae    7e0a <fwp_drop1+0x13a>
    7dd9:	49 01 c2             	add    %rax,%r10
    7ddc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7de0:	75 28                	jne    7e0a <fwp_drop1+0x13a>
    7de2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7de7:	e8 24 dc ff ff       	call   5a10 <fwp_mem_free>
    7dec:	48 8d 35 2d 0a 06 00 	lea    0x60a2d(%rip),%rsi        # 68820 <fwp_heap>
    7df3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7df8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7dff:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e06:	48 c1 e2 10          	shl    $0x10,%rdx
    7e0a:	4c 89 c0             	mov    %r8,%rax
    7e0d:	48 29 c8             	sub    %rcx,%rax
    7e10:	48 39 d0             	cmp    %rdx,%rax
    7e13:	0f 83 45 ff ff ff    	jae    7d5e <fwp_drop1+0x8e>
    7e19:	4c 89 c7             	mov    %r8,%rdi
    7e1c:	e9 dc fe ff ff       	jmp    7cfd <fwp_drop1+0x2d>
    7e21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e28:	c3                   	ret
    7e29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e30:	66 85 c0             	test   %ax,%ax
    7e33:	75 d5                	jne    7e0a <fwp_drop1+0x13a>
    7e35:	eb a5                	jmp    7ddc <fwp_drop1+0x10c>
    7e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e3e:	00 00 
    7e40:	48 89 d0             	mov    %rdx,%rax
    7e43:	48 c1 e8 11          	shr    $0x11,%rax
    7e47:	48 31 d0             	xor    %rdx,%rax
    7e4a:	48 89 c1             	mov    %rax,%rcx
    7e4d:	48 c1 e9 09          	shr    $0x9,%rcx
    7e51:	48 31 c8             	xor    %rcx,%rax
    7e54:	0f b6 c8             	movzbl %al,%ecx
    7e57:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7e5e:	00 
    7e5f:	48 85 c0             	test   %rax,%rax
    7e62:	75 25                	jne    7e89 <fwp_drop1+0x1b9>
    7e64:	eb 5e                	jmp    7ec4 <fwp_drop1+0x1f4>
    7e66:	0f 1f 40 00          	nopl   0x0(%rax)
    7e6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e71:	00 00 00 00 
    7e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e7c:	00 00 00 00 
    7e80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7e84:	48 85 c0             	test   %rax,%rax
    7e87:	74 3b                	je     7ec4 <fwp_drop1+0x1f4>
    7e89:	48 89 c1             	mov    %rax,%rcx
    7e8c:	48 39 10             	cmp    %rdx,(%rax)
    7e8f:	75 ef                	jne    7e80 <fwp_drop1+0x1b0>
    7e91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7e99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7e9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ea4:	0f 85 b4 fe ff ff    	jne    7d5e <fwp_drop1+0x8e>
    7eaa:	48 89 d7             	mov    %rdx,%rdi
    7ead:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7eb2:	e8 19 d9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7eb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7ebc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7ebf:	e9 9a fe ff ff       	jmp    7d5e <fwp_drop1+0x8e>
    7ec4:	48 8d 3d 25 4b 00 00 	lea    0x4b25(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    7ecb:	e8 80 c5 ff ff       	call   4450 <fwp_trap>

0000000000007ed0 <fwp_drop10>:
    7ed0:	48 8b 0d 21 1d 06 00 	mov    0x61d21(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    7ed7:	48 89 f8             	mov    %rdi,%rax
    7eda:	48 2b 05 ef 1c 06 00 	sub    0x61cef(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7ee1:	48 c1 e1 10          	shl    $0x10,%rcx
    7ee5:	48 39 c8             	cmp    %rcx,%rax
    7ee8:	0f 83 c2 01 00 00    	jae    80b0 <fwp_drop10+0x1e0>
    7eee:	48 83 ec 18          	sub    $0x18,%rsp
    7ef2:	48 89 fa             	mov    %rdi,%rdx
    7ef5:	48 8d 35 24 09 06 00 	lea    0x60924(%rip),%rsi        # 68820 <fwp_heap>
    7efc:	48 89 c1             	mov    %rax,%rcx
    7eff:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7f06:	48 c1 e9 10          	shr    $0x10,%rcx
    7f0a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7f0e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7f12:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7f16:	48 85 c9             	test   %rcx,%rcx
    7f19:	74 46                	je     7f61 <fwp_drop10+0x91>
    7f1b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7f1f:	41 80 f9 02          	cmp    $0x2,%r9b
    7f23:	0f 84 d7 00 00 00    	je     8000 <fwp_drop10+0x130>
    7f29:	41 80 f9 01          	cmp    $0x1,%r9b
    7f2d:	75 32                	jne    7f61 <fwp_drop10+0x91>
    7f2f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7f33:	0f b7 c0             	movzwl %ax,%eax
    7f36:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7f39:	49 0f af c1          	imul   %r9,%rax
    7f3d:	48 c1 e8 20          	shr    $0x20,%rax
    7f41:	48 39 f8             	cmp    %rdi,%rax
    7f44:	73 1b                	jae    7f61 <fwp_drop10+0x91>
    7f46:	48 01 c1             	add    %rax,%rcx
    7f49:	0f b6 01             	movzbl (%rcx),%eax
    7f4c:	84 c0                	test   %al,%al
    7f4e:	74 11                	je     7f61 <fwp_drop10+0x91>
    7f50:	3c 01                	cmp    $0x1,%al
    7f52:	74 1c                	je     7f70 <fwp_drop10+0xa0>
    7f54:	3c ff                	cmp    $0xff,%al
    7f56:	0f 84 5c 01 00 00    	je     80b8 <fwp_drop10+0x1e8>
    7f5c:	83 e8 01             	sub    $0x1,%eax
    7f5f:	88 01                	mov    %al,(%rcx)
    7f61:	48 83 c4 18          	add    $0x18,%rsp
    7f65:	c3                   	ret
    7f66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f6d:	00 00 00 
    7f70:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7f77:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7f7e:	48 89 d0             	mov    %rdx,%rax
    7f81:	49 89 d1             	mov    %rdx,%r9
    7f84:	48 c1 e1 10          	shl    $0x10,%rcx
    7f88:	48 29 f8             	sub    %rdi,%rax
    7f8b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7f8f:	78 7f                	js     8010 <fwp_drop10+0x140>
    7f91:	48 39 c8             	cmp    %rcx,%rax
    7f94:	73 cb                	jae    7f61 <fwp_drop10+0x91>
    7f96:	48 89 c1             	mov    %rax,%rcx
    7f99:	48 c1 e9 10          	shr    $0x10,%rcx
    7f9d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7fa1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7fa5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7fa9:	48 85 f6             	test   %rsi,%rsi
    7fac:	74 b3                	je     7f61 <fwp_drop10+0x91>
    7fae:	0f b6 39             	movzbl (%rcx),%edi
    7fb1:	40 80 ff 02          	cmp    $0x2,%dil
    7fb5:	74 39                	je     7ff0 <fwp_drop10+0x120>
    7fb7:	40 80 ff 01          	cmp    $0x1,%dil
    7fbb:	75 a4                	jne    7f61 <fwp_drop10+0x91>
    7fbd:	8b 79 18             	mov    0x18(%rcx),%edi
    7fc0:	0f b7 c0             	movzwl %ax,%eax
    7fc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7fc6:	48 0f af c7          	imul   %rdi,%rax
    7fca:	48 c1 e8 20          	shr    $0x20,%rax
    7fce:	48 39 c8             	cmp    %rcx,%rax
    7fd1:	73 8e                	jae    7f61 <fwp_drop10+0x91>
    7fd3:	48 01 c6             	add    %rax,%rsi
    7fd6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7fd9:	75 86                	jne    7f61 <fwp_drop10+0x91>
    7fdb:	48 89 d7             	mov    %rdx,%rdi
    7fde:	48 83 c4 18          	add    $0x18,%rsp
    7fe2:	e9 29 da ff ff       	jmp    5a10 <fwp_mem_free>
    7fe7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fee:	00 00 
    7ff0:	66 85 c0             	test   %ax,%ax
    7ff3:	74 e1                	je     7fd6 <fwp_drop10+0x106>
    7ff5:	48 83 c4 18          	add    $0x18,%rsp
    7ff9:	c3                   	ret
    7ffa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8000:	66 85 c0             	test   %ax,%ax
    8003:	0f 84 40 ff ff ff    	je     7f49 <fwp_drop10+0x79>
    8009:	48 83 c4 18          	add    $0x18,%rsp
    800d:	c3                   	ret
    800e:	66 90                	xchg   %ax,%ax
    8010:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8014:	48 39 c8             	cmp    %rcx,%rax
    8017:	73 74                	jae    808d <fwp_drop10+0x1bd>
    8019:	49 89 c2             	mov    %rax,%r10
    801c:	49 c1 ea 10          	shr    $0x10,%r10
    8020:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8024:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8028:	4d 8b 50 20          	mov    0x20(%r8),%r10
    802c:	4d 85 d2             	test   %r10,%r10
    802f:	74 5c                	je     808d <fwp_drop10+0x1bd>
    8031:	45 0f b6 18          	movzbl (%r8),%r11d
    8035:	41 80 fb 02          	cmp    $0x2,%r11b
    8039:	74 6d                	je     80a8 <fwp_drop10+0x1d8>
    803b:	41 80 fb 01          	cmp    $0x1,%r11b
    803f:	75 4c                	jne    808d <fwp_drop10+0x1bd>
    8041:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8045:	0f b7 c0             	movzwl %ax,%eax
    8048:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    804c:	49 0f af c3          	imul   %r11,%rax
    8050:	48 c1 e8 20          	shr    $0x20,%rax
    8054:	4c 39 c0             	cmp    %r8,%rax
    8057:	73 34                	jae    808d <fwp_drop10+0x1bd>
    8059:	49 01 c2             	add    %rax,%r10
    805c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8060:	75 2b                	jne    808d <fwp_drop10+0x1bd>
    8062:	4c 89 cf             	mov    %r9,%rdi
    8065:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    806a:	e8 a1 d9 ff ff       	call   5a10 <fwp_mem_free>
    806f:	48 8d 35 aa 07 06 00 	lea    0x607aa(%rip),%rsi        # 68820 <fwp_heap>
    8076:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    807b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8082:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8089:	48 c1 e1 10          	shl    $0x10,%rcx
    808d:	48 89 d0             	mov    %rdx,%rax
    8090:	48 29 f8             	sub    %rdi,%rax
    8093:	48 39 c8             	cmp    %rcx,%rax
    8096:	0f 82 60 fe ff ff    	jb     7efc <fwp_drop10+0x2c>
    809c:	e9 c0 fe ff ff       	jmp    7f61 <fwp_drop10+0x91>
    80a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80a8:	66 85 c0             	test   %ax,%ax
    80ab:	75 e0                	jne    808d <fwp_drop10+0x1bd>
    80ad:	eb ad                	jmp    805c <fwp_drop10+0x18c>
    80af:	90                   	nop
    80b0:	c3                   	ret
    80b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80b8:	48 89 c8             	mov    %rcx,%rax
    80bb:	48 c1 e8 11          	shr    $0x11,%rax
    80bf:	48 31 c8             	xor    %rcx,%rax
    80c2:	48 89 c2             	mov    %rax,%rdx
    80c5:	48 c1 ea 09          	shr    $0x9,%rdx
    80c9:	48 31 d0             	xor    %rdx,%rax
    80cc:	0f b6 d0             	movzbl %al,%edx
    80cf:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    80d6:	00 
    80d7:	48 85 c0             	test   %rax,%rax
    80da:	75 0d                	jne    80e9 <fwp_drop10+0x219>
    80dc:	eb 46                	jmp    8124 <fwp_drop10+0x254>
    80de:	66 90                	xchg   %ax,%ax
    80e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    80e4:	48 85 c0             	test   %rax,%rax
    80e7:	74 3b                	je     8124 <fwp_drop10+0x254>
    80e9:	48 89 c2             	mov    %rax,%rdx
    80ec:	48 39 08             	cmp    %rcx,(%rax)
    80ef:	75 ef                	jne    80e0 <fwp_drop10+0x210>
    80f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    80f5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    80f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    80fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8104:	0f 85 57 fe ff ff    	jne    7f61 <fwp_drop10+0x91>
    810a:	48 89 cf             	mov    %rcx,%rdi
    810d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8112:	e8 b9 d6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8117:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    811c:	c6 01 fe             	movb   $0xfe,(%rcx)
    811f:	e9 3d fe ff ff       	jmp    7f61 <fwp_drop10+0x91>
    8124:	48 8d 3d c5 48 00 00 	lea    0x48c5(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    812b:	e8 20 c3 ff ff       	call   4450 <fwp_trap>

0000000000008130 <f37>:
    8130:	41 57                	push   %r15
    8132:	41 56                	push   %r14
    8134:	41 55                	push   %r13
    8136:	41 54                	push   %r12
    8138:	55                   	push   %rbp
    8139:	53                   	push   %rbx
    813a:	48 83 ec 38          	sub    $0x38,%rsp
    813e:	48 8b 15 b3 1a 06 00 	mov    0x61ab3(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    8145:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    814a:	48 c1 e2 10          	shl    $0x10,%rdx
    814e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8155:	00 00 
    8157:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    815c:	48 8b 0d 6d 1a 06 00 	mov    0x61a6d(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    8163:	48 85 ff             	test   %rdi,%rdi
    8166:	0f 84 1e 03 00 00    	je     848a <f37+0x35a>
    816c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8171:	4c 8b 68 10          	mov    0x10(%rax),%r13
    8175:	4c 89 e8             	mov    %r13,%rax
    8178:	48 29 c8             	sub    %rcx,%rax
    817b:	48 39 d0             	cmp    %rdx,%rax
    817e:	0f 83 ec 02 00 00    	jae    8470 <f37+0x340>
    8184:	48 89 c2             	mov    %rax,%rdx
    8187:	48 c1 ea 10          	shr    $0x10,%rdx
    818b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    818f:	48 8b 15 82 1a 06 00 	mov    0x61a82(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8196:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    819a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    819e:	48 85 ff             	test   %rdi,%rdi
    81a1:	0f 84 c9 02 00 00    	je     8470 <f37+0x340>
    81a7:	0f b6 0a             	movzbl (%rdx),%ecx
    81aa:	80 f9 02             	cmp    $0x2,%cl
    81ad:	0f 84 4d 02 00 00    	je     8400 <f37+0x2d0>
    81b3:	80 f9 01             	cmp    $0x1,%cl
    81b6:	75 24                	jne    81dc <f37+0xac>
    81b8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81bb:	0f b7 c0             	movzwl %ax,%eax
    81be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81c1:	48 0f af c1          	imul   %rcx,%rax
    81c5:	48 c1 e8 20          	shr    $0x20,%rax
    81c9:	48 39 d0             	cmp    %rdx,%rax
    81cc:	73 0e                	jae    81dc <f37+0xac>
    81ce:	48 01 c7             	add    %rax,%rdi
    81d1:	0f b6 07             	movzbl (%rdi),%eax
    81d4:	84 c0                	test   %al,%al
    81d6:	0f 85 44 02 00 00    	jne    8420 <f37+0x2f0>
    81dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    81e1:	48 8b 40 10          	mov    0x10(%rax),%rax
    81e5:	ba 01 00 00 00       	mov    $0x1,%edx
    81ea:	48 85 c0             	test   %rax,%rax
    81ed:	74 0e                	je     81fd <f37+0xcd>
    81ef:	90                   	nop
    81f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    81f4:	48 83 c2 01          	add    $0x1,%rdx
    81f8:	48 85 c0             	test   %rax,%rax
    81fb:	75 f3                	jne    81f0 <f37+0xc0>
    81fd:	4d 85 ed             	test   %r13,%r13
    8200:	0f 84 9a 02 00 00    	je     84a0 <f37+0x370>
    8206:	4c 89 e8             	mov    %r13,%rax
    8209:	31 db                	xor    %ebx,%ebx
    820b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8210:	48 8b 40 10          	mov    0x10(%rax),%rax
    8214:	48 83 c3 01          	add    $0x1,%rbx
    8218:	48 85 c0             	test   %rax,%rax
    821b:	75 f3                	jne    8210 <f37+0xe0>
    821d:	48 39 d3             	cmp    %rdx,%rbx
    8220:	48 0f 47 da          	cmova  %rdx,%rbx
    8224:	48 89 d8             	mov    %rbx,%rax
    8227:	48 c1 e8 3c          	shr    $0x3c,%rax
    822b:	0f 85 7d 03 00 00    	jne    85ae <f37+0x47e>
    8231:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8235:	be 02 00 00 00       	mov    $0x2,%esi
    823a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8241:	00 
    8242:	e8 c9 dc ff ff       	call   5f10 <fwp_heap_alloc>
    8247:	48 89 28             	mov    %rbp,(%rax)
    824a:	48 8b 15 a7 19 06 00 	mov    0x619a7(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    8251:	49 89 c4             	mov    %rax,%r12
    8254:	48 2b 05 75 19 06 00 	sub    0x61975(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    825b:	48 c1 e2 10          	shl    $0x10,%rdx
    825f:	48 39 d0             	cmp    %rdx,%rax
    8262:	73 57                	jae    82bb <f37+0x18b>
    8264:	48 89 c2             	mov    %rax,%rdx
    8267:	48 c1 ea 10          	shr    $0x10,%rdx
    826b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    826f:	48 8b 15 a2 19 06 00 	mov    0x619a2(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8276:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    827a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    827e:	48 85 ed             	test   %rbp,%rbp
    8281:	74 38                	je     82bb <f37+0x18b>
    8283:	0f b6 0a             	movzbl (%rdx),%ecx
    8286:	80 f9 02             	cmp    $0x2,%cl
    8289:	0f 84 d1 01 00 00    	je     8460 <f37+0x330>
    828f:	80 f9 01             	cmp    $0x1,%cl
    8292:	75 27                	jne    82bb <f37+0x18b>
    8294:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8297:	0f b7 c0             	movzwl %ax,%eax
    829a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    829d:	48 0f af c1          	imul   %rcx,%rax
    82a1:	48 c1 e8 20          	shr    $0x20,%rax
    82a5:	48 39 d0             	cmp    %rdx,%rax
    82a8:	73 11                	jae    82bb <f37+0x18b>
    82aa:	48 01 c5             	add    %rax,%rbp
    82ad:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    82b1:	0f 84 57 02 00 00    	je     850e <f37+0x3de>
    82b7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    82bb:	48 85 db             	test   %rbx,%rbx
    82be:	74 5d                	je     831d <f37+0x1ed>
    82c0:	48 c1 e3 04          	shl    $0x4,%rbx
    82c4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    82c9:	4c 89 e5             	mov    %r12,%rbp
    82cc:	4d 89 ef             	mov    %r13,%r15
    82cf:	4c 01 e3             	add    %r12,%rbx
    82d2:	0f 1f 00             	nopl   (%rax)
    82d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82dc:	00 00 00 00 
    82e0:	49 8b 46 08          	mov    0x8(%r14),%rax
    82e4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    82e8:	48 83 c5 10          	add    $0x10,%rbp
    82ec:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    82f1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    82f5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    82f9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    82fe:	e8 6d e3 ff ff       	call   6670 <w120>
    8303:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8308:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    830c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8310:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8314:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8318:	48 39 dd             	cmp    %rbx,%rbp
    831b:	75 c3                	jne    82e0 <f37+0x1b0>
    831d:	4c 89 ef             	mov    %r13,%rdi
    8320:	e8 8b ed ff ff       	call   70b0 <fwp_drop4>
    8325:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    832a:	e8 81 ed ff ff       	call   70b0 <fwp_drop4>
    832f:	4c 89 e7             	mov    %r12,%rdi
    8332:	e8 a9 e4 ff ff       	call   67e0 <w176.constprop.0>
    8337:	4c 89 e7             	mov    %r12,%rdi
    833a:	48 89 c3             	mov    %rax,%rbx
    833d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8343:	e8 88 fb ff ff       	call   7ed0 <fwp_drop10>
    8348:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    834e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8353:	31 ff                	xor    %edi,%edi
    8355:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    835a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    835e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8363:	e8 98 dd ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    8368:	48 8b 15 89 18 06 00 	mov    0x61889(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    836f:	48 89 c5             	mov    %rax,%rbp
    8372:	48 2b 05 57 18 06 00 	sub    0x61857(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    8379:	48 c1 e2 10          	shl    $0x10,%rdx
    837d:	48 39 d0             	cmp    %rdx,%rax
    8380:	73 55                	jae    83d7 <f37+0x2a7>
    8382:	48 89 c2             	mov    %rax,%rdx
    8385:	48 c1 ea 10          	shr    $0x10,%rdx
    8389:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    838d:	48 8b 15 84 18 06 00 	mov    0x61884(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8394:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8398:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    839c:	48 85 db             	test   %rbx,%rbx
    839f:	74 36                	je     83d7 <f37+0x2a7>
    83a1:	0f b6 0a             	movzbl (%rdx),%ecx
    83a4:	80 f9 02             	cmp    $0x2,%cl
    83a7:	0f 84 a3 00 00 00    	je     8450 <f37+0x320>
    83ad:	80 f9 01             	cmp    $0x1,%cl
    83b0:	75 25                	jne    83d7 <f37+0x2a7>
    83b2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83b5:	0f b7 c0             	movzwl %ax,%eax
    83b8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83bb:	48 0f af c1          	imul   %rcx,%rax
    83bf:	48 c1 e8 20          	shr    $0x20,%rax
    83c3:	48 39 d0             	cmp    %rdx,%rax
    83c6:	73 0f                	jae    83d7 <f37+0x2a7>
    83c8:	48 01 c3             	add    %rax,%rbx
    83cb:	80 3b ff             	cmpb   $0xff,(%rbx)
    83ce:	0f 84 2d 01 00 00    	je     8501 <f37+0x3d1>
    83d4:	c6 03 01             	movb   $0x1,(%rbx)
    83d7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    83dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    83e3:	00 00 
    83e5:	0f 85 cf 01 00 00    	jne    85ba <f37+0x48a>
    83eb:	48 83 c4 38          	add    $0x38,%rsp
    83ef:	48 89 e8             	mov    %rbp,%rax
    83f2:	5b                   	pop    %rbx
    83f3:	5d                   	pop    %rbp
    83f4:	41 5c                	pop    %r12
    83f6:	41 5d                	pop    %r13
    83f8:	41 5e                	pop    %r14
    83fa:	41 5f                	pop    %r15
    83fc:	c3                   	ret
    83fd:	0f 1f 00             	nopl   (%rax)
    8400:	66 85 c0             	test   %ax,%ax
    8403:	0f 85 d3 fd ff ff    	jne    81dc <f37+0xac>
    8409:	0f b6 07             	movzbl (%rdi),%eax
    840c:	84 c0                	test   %al,%al
    840e:	0f 84 c8 fd ff ff    	je     81dc <f37+0xac>
    8414:	90                   	nop
    8415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    841c:	00 00 00 00 
    8420:	8b 15 c2 20 06 00    	mov    0x620c2(%rip),%edx        # 6a4e8 <iteration_active>
    8426:	85 d2                	test   %edx,%edx
    8428:	75 56                	jne    8480 <f37+0x350>
    842a:	3c fd                	cmp    $0xfd,%al
    842c:	0f 87 4b 01 00 00    	ja     857d <f37+0x44d>
    8432:	83 c0 01             	add    $0x1,%eax
    8435:	88 07                	mov    %al,(%rdi)
    8437:	31 d2                	xor    %edx,%edx
    8439:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    843f:	0f 85 97 fd ff ff    	jne    81dc <f37+0xac>
    8445:	e9 b3 fd ff ff       	jmp    81fd <f37+0xcd>
    844a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8450:	66 85 c0             	test   %ax,%ax
    8453:	0f 85 7e ff ff ff    	jne    83d7 <f37+0x2a7>
    8459:	e9 6d ff ff ff       	jmp    83cb <f37+0x29b>
    845e:	66 90                	xchg   %ax,%ax
    8460:	66 85 c0             	test   %ax,%ax
    8463:	0f 85 52 fe ff ff    	jne    82bb <f37+0x18b>
    8469:	e9 3f fe ff ff       	jmp    82ad <f37+0x17d>
    846e:	66 90                	xchg   %ax,%ax
    8470:	4c 89 e8             	mov    %r13,%rax
    8473:	e9 6d fd ff ff       	jmp    81e5 <f37+0xb5>
    8478:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    847f:	00 
    8480:	48 83 05 48 20 06 00 	addq   $0x1,0x62048(%rip)        # 6a4d0 <iteration_retains>
    8487:	01 
    8488:	eb a0                	jmp    842a <f37+0x2fa>
    848a:	48 f7 d9             	neg    %rcx
    848d:	48 39 d1             	cmp    %rdx,%rcx
    8490:	0f 82 85 00 00 00    	jb     851b <f37+0x3eb>
    8496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    849d:	00 00 00 
    84a0:	be 02 00 00 00       	mov    $0x2,%esi
    84a5:	bf 08 00 00 00       	mov    $0x8,%edi
    84aa:	e8 61 da ff ff       	call   5f10 <fwp_heap_alloc>
    84af:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    84b6:	48 8b 15 3b 17 06 00 	mov    0x6173b(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    84bd:	49 89 c4             	mov    %rax,%r12
    84c0:	48 2b 05 09 17 06 00 	sub    0x61709(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    84c7:	48 c1 e2 10          	shl    $0x10,%rdx
    84cb:	48 39 d0             	cmp    %rdx,%rax
    84ce:	0f 83 b3 00 00 00    	jae    8587 <f37+0x457>
    84d4:	48 89 c2             	mov    %rax,%rdx
    84d7:	48 c1 ea 10          	shr    $0x10,%rdx
    84db:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84df:	48 8b 15 32 17 06 00 	mov    0x61732(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    84e6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84ea:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    84ee:	48 85 ed             	test   %rbp,%rbp
    84f1:	0f 84 90 00 00 00    	je     8587 <f37+0x457>
    84f7:	31 db                	xor    %ebx,%ebx
    84f9:	45 31 ed             	xor    %r13d,%r13d
    84fc:	e9 82 fd ff ff       	jmp    8283 <f37+0x153>
    8501:	48 89 df             	mov    %rbx,%rdi
    8504:	e8 c7 d2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8509:	e9 c6 fe ff ff       	jmp    83d4 <f37+0x2a4>
    850e:	48 89 ef             	mov    %rbp,%rdi
    8511:	e8 ba d2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8516:	e9 9c fd ff ff       	jmp    82b7 <f37+0x187>
    851b:	48 89 c8             	mov    %rcx,%rax
    851e:	48 c1 e8 10          	shr    $0x10,%rax
    8522:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8526:	48 8b 05 eb 16 06 00 	mov    0x616eb(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    852d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8531:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8535:	48 85 ff             	test   %rdi,%rdi
    8538:	0f 84 62 ff ff ff    	je     84a0 <f37+0x370>
    853e:	0f b6 02             	movzbl (%rdx),%eax
    8541:	3c 02                	cmp    $0x2,%al
    8543:	74 4a                	je     858f <f37+0x45f>
    8545:	3c 01                	cmp    $0x1,%al
    8547:	0f 85 53 ff ff ff    	jne    84a0 <f37+0x370>
    854d:	0f b7 c1             	movzwl %cx,%eax
    8550:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8553:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8556:	48 0f af c1          	imul   %rcx,%rax
    855a:	48 c1 e8 20          	shr    $0x20,%rax
    855e:	48 39 d0             	cmp    %rdx,%rax
    8561:	0f 83 39 ff ff ff    	jae    84a0 <f37+0x370>
    8567:	48 01 c7             	add    %rax,%rdi
    856a:	0f b6 07             	movzbl (%rdi),%eax
    856d:	84 c0                	test   %al,%al
    856f:	0f 84 2b ff ff ff    	je     84a0 <f37+0x370>
    8575:	45 31 ed             	xor    %r13d,%r13d
    8578:	e9 a3 fe ff ff       	jmp    8420 <f37+0x2f0>
    857d:	e8 2e d1 ff ff       	call   56b0 <fwp_rc_wide_dup>
    8582:	e9 b0 fe ff ff       	jmp    8437 <f37+0x307>
    8587:	45 31 ed             	xor    %r13d,%r13d
    858a:	e9 8e fd ff ff       	jmp    831d <f37+0x1ed>
    858f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8595:	49 89 cd             	mov    %rcx,%r13
    8598:	0f 85 02 ff ff ff    	jne    84a0 <f37+0x370>
    859e:	0f b6 07             	movzbl (%rdi),%eax
    85a1:	84 c0                	test   %al,%al
    85a3:	0f 85 77 fe ff ff    	jne    8420 <f37+0x2f0>
    85a9:	e9 f2 fe ff ff       	jmp    84a0 <f37+0x370>
    85ae:	48 8d 3d 36 3c 00 00 	lea    0x3c36(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    85b5:	e8 96 be ff ff       	call   4450 <fwp_trap>
    85ba:	e8 91 ae ff ff       	call   3450 <__stack_chk_fail@plt>
    85bf:	90                   	nop

00000000000085c0 <fwp_owned_entry37>:
    85c0:	f3 0f 1e fa          	endbr64
    85c4:	48 8b 3f             	mov    (%rdi),%rdi
    85c7:	e9 64 fb ff ff       	jmp    8130 <f37>
    85cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000085d0 <e37>:
    85d0:	f3 0f 1e fa          	endbr64
    85d4:	53                   	push   %rbx
    85d5:	48 8b 1f             	mov    (%rdi),%rbx
    85d8:	48 89 df             	mov    %rbx,%rdi
    85db:	e8 80 e2 ff ff       	call   6860 <fwp_rc_share>
    85e0:	48 89 df             	mov    %rbx,%rdi
    85e3:	e8 48 fb ff ff       	call   8130 <f37>
    85e8:	48 89 c3             	mov    %rax,%rbx
    85eb:	48 89 c7             	mov    %rax,%rdi
    85ee:	e8 6d e2 ff ff       	call   6860 <fwp_rc_share>
    85f3:	48 89 d8             	mov    %rbx,%rax
    85f6:	5b                   	pop    %rbx
    85f7:	c3                   	ret
    85f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    85ff:	00 

0000000000008600 <fwp_write>:
    8600:	41 57                	push   %r15
    8602:	41 56                	push   %r14
    8604:	41 55                	push   %r13
    8606:	41 54                	push   %r12
    8608:	55                   	push   %rbp
    8609:	53                   	push   %rbx
    860a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8611:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8618:	00 00 
    861a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8621:	00 
    8622:	49 89 d4             	mov    %rdx,%r12
    8625:	8b 12                	mov    (%rdx),%edx
    8627:	83 fa 19             	cmp    $0x19,%edx
    862a:	77 6a                	ja     8696 <fwp_write+0x96>
    862c:	48 89 f5             	mov    %rsi,%rbp
    862f:	89 d0                	mov    %edx,%eax
    8631:	89 ce                	mov    %ecx,%esi
    8633:	48 89 fb             	mov    %rdi,%rbx
    8636:	48 8d 0d 93 46 00 00 	lea    0x4693(%rip),%rcx        # ccd0 <_IO_stdin_used+0xcd0>
    863d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8641:	48 01 c8             	add    %rcx,%rax
    8644:	3e ff e0             	notrack jmp *%rax
    8647:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    864e:	00 00 
    8650:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8654:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8658:	48 89 ca             	mov    %rcx,%rdx
    865b:	48 85 c9             	test   %rcx,%rcx
    865e:	0f 88 9c 0c 00 00    	js     9300 <fwp_write+0xd00>
    8664:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    866b:	00 
    866c:	48 89 c6             	mov    %rax,%rsi
    866f:	4c 89 e7             	mov    %r12,%rdi
    8672:	e8 c9 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    8677:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    867e:	00 00 
    8680:	4c 89 e7             	mov    %r12,%rdi
    8683:	e8 b8 ad ff ff       	call   3440 <strlen@plt>
    8688:	4c 89 e6             	mov    %r12,%rsi
    868b:	48 89 df             	mov    %rbx,%rdi
    868e:	48 89 c2             	mov    %rax,%rdx
    8691:	e8 5a ba ff ff       	call   40f0 <buf_put>
    8696:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    869d:	00 
    869e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    86a5:	00 00 
    86a7:	0f 85 28 04 00 00    	jne    8ad5 <fwp_write+0x4d5>
    86ad:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    86b4:	5b                   	pop    %rbx
    86b5:	5d                   	pop    %rbp
    86b6:	41 5c                	pop    %r12
    86b8:	41 5d                	pop    %r13
    86ba:	41 5e                	pop    %r14
    86bc:	41 5f                	pop    %r15
    86be:	c3                   	ret
    86bf:	90                   	nop
    86c0:	49 89 e9             	mov    %rbp,%r9
    86c3:	4c 8d 05 4b 3b 00 00 	lea    0x3b4b(%rip),%r8        # c215 <_IO_stdin_used+0x215>
    86ca:	b9 00 02 00 00       	mov    $0x200,%ecx
    86cf:	ba 02 00 00 00       	mov    $0x2,%edx
    86d4:	be 00 02 00 00       	mov    $0x200,%esi
    86d9:	31 c0                	xor    %eax,%eax
    86db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    86e2:	00 
    86e3:	e8 b8 ac ff ff       	call   33a0 <__snprintf_chk@plt>
    86e8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    86ef:	00 
    86f0:	e8 4b ad ff ff       	call   3440 <strlen@plt>
    86f5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    86fc:	00 
    86fd:	48 89 df             	mov    %rbx,%rdi
    8700:	48 89 c2             	mov    %rax,%rdx
    8703:	e8 e8 b9 ff ff       	call   40f0 <buf_put>
    8708:	eb 8c                	jmp    8696 <fwp_write+0x96>
    870a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8710:	49 89 e9             	mov    %rbp,%r9
    8713:	4c 8d 05 f6 3a 00 00 	lea    0x3af6(%rip),%r8        # c210 <_IO_stdin_used+0x210>
    871a:	eb ae                	jmp    86ca <fwp_write+0xca>
    871c:	0f 1f 40 00          	nopl   0x0(%rax)
    8720:	83 fa 13             	cmp    $0x13,%edx
    8723:	48 8d 05 dc 3a 00 00 	lea    0x3adc(%rip),%rax        # c206 <_IO_stdin_used+0x206>
    872a:	48 8d 35 da 3a 00 00 	lea    0x3ada(%rip),%rsi        # c20b <_IO_stdin_used+0x20b>
    8731:	ba 04 00 00 00       	mov    $0x4,%edx
    8736:	48 0f 44 f0          	cmove  %rax,%rsi
    873a:	45 31 ed             	xor    %r13d,%r13d
    873d:	e8 ae b9 ff ff       	call   40f0 <buf_put>
    8742:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8747:	0f 84 a3 08 00 00    	je     8ff0 <fwp_write+0x9f0>
    874d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8752:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8757:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    875c:	48 89 df             	mov    %rbx,%rdi
    875f:	49 0f 44 c5          	cmove  %r13,%rax
    8763:	31 c9                	xor    %ecx,%ecx
    8765:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    876a:	e8 91 fe ff ff       	call   8600 <fwp_write>
    876f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8774:	0f 84 6e 09 00 00    	je     90e8 <fwp_write+0xae8>
    877a:	49 83 c5 01          	add    $0x1,%r13
    877e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8782:	0f 83 68 08 00 00    	jae    8ff0 <fwp_write+0x9f0>
    8788:	ba 02 00 00 00       	mov    $0x2,%edx
    878d:	48 8d 35 c1 3a 00 00 	lea    0x3ac1(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8794:	48 89 df             	mov    %rbx,%rdi
    8797:	e8 54 b9 ff ff       	call   40f0 <buf_put>
    879c:	eb af                	jmp    874d <fwp_write+0x14d>
    879e:	66 90                	xchg   %ax,%ax
    87a0:	ba 06 00 00 00       	mov    $0x6,%edx
    87a5:	48 8d 35 82 3a 00 00 	lea    0x3a82(%rip),%rsi        # c22e <_IO_stdin_used+0x22e>
    87ac:	48 83 c5 10          	add    $0x10,%rbp
    87b0:	e8 3b b9 ff ff       	call   40f0 <buf_put>
    87b5:	48 89 ef             	mov    %rbp,%rdi
    87b8:	e8 83 ac ff ff       	call   3440 <strlen@plt>
    87bd:	48 89 ee             	mov    %rbp,%rsi
    87c0:	48 89 df             	mov    %rbx,%rdi
    87c3:	48 89 c2             	mov    %rax,%rdx
    87c6:	e8 25 b9 ff ff       	call   40f0 <buf_put>
    87cb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    87d0:	ba 01 00 00 00       	mov    $0x1,%edx
    87d5:	48 89 df             	mov    %rbx,%rdi
    87d8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    87dd:	e8 0e b9 ff ff       	call   40f0 <buf_put>
    87e2:	e9 af fe ff ff       	jmp    8696 <fwp_write+0x96>
    87e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    87ee:	00 00 
    87f0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    87f7:	00 
    87f8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87ff:	00 00 
    8801:	0f 85 ce 02 00 00    	jne    8ad5 <fwp_write+0x4d5>
    8807:	ba 0a 00 00 00       	mov    $0xa,%edx
    880c:	48 8d 35 07 3a 00 00 	lea    0x3a07(%rip),%rsi        # c21a <_IO_stdin_used+0x21a>
    8813:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    881a:	48 89 df             	mov    %rbx,%rdi
    881d:	5b                   	pop    %rbx
    881e:	5d                   	pop    %rbp
    881f:	41 5c                	pop    %r12
    8821:	41 5d                	pop    %r13
    8823:	41 5e                	pop    %r14
    8825:	41 5f                	pop    %r15
    8827:	e9 c4 b8 ff ff       	jmp    40f0 <buf_put>
    882c:	0f 1f 40 00          	nopl   0x0(%rax)
    8830:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8835:	4d 85 ed             	test   %r13,%r13
    8838:	0f 84 02 0c 00 00    	je     9440 <fwp_write+0xe40>
    883e:	48 8d 35 1d 3a 00 00 	lea    0x3a1d(%rip),%rsi        # c262 <_IO_stdin_used+0x262>
    8845:	4c 89 ef             	mov    %r13,%rdi
    8848:	e8 d3 ac ff ff       	call   3520 <strcmp@plt>
    884d:	41 89 c1             	mov    %eax,%r9d
    8850:	85 c0                	test   %eax,%eax
    8852:	0f 84 6c 0c 00 00    	je     94c4 <fwp_write+0xec4>
    8858:	4c 89 ef             	mov    %r13,%rdi
    885b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8860:	e8 db ab ff ff       	call   3440 <strlen@plt>
    8865:	4c 89 ee             	mov    %r13,%rsi
    8868:	48 89 df             	mov    %rbx,%rdi
    886b:	48 89 c2             	mov    %rax,%rdx
    886e:	e8 7d b8 ff ff       	call   40f0 <buf_put>
    8873:	ba 01 00 00 00       	mov    $0x1,%edx
    8878:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    887d:	48 89 df             	mov    %rbx,%rdi
    8880:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8885:	e8 66 b8 ff ff       	call   40f0 <buf_put>
    888a:	ba 01 00 00 00       	mov    $0x1,%edx
    888f:	4c 89 fe             	mov    %r15,%rsi
    8892:	48 89 df             	mov    %rbx,%rdi
    8895:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    889a:	e8 51 b8 ff ff       	call   40f0 <buf_put>
    889f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    88a4:	45 31 f6             	xor    %r14d,%r14d
    88a7:	85 d2                	test   %edx,%edx
    88a9:	0f 8e 81 0a 00 00    	jle    9330 <fwp_write+0xd30>
    88af:	45 31 ed             	xor    %r13d,%r13d
    88b2:	4d 85 ed             	test   %r13,%r13
    88b5:	0f 85 75 07 00 00    	jne    9030 <fwp_write+0xa30>
    88bb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    88c2:	00 
    88c3:	45 85 f6             	test   %r14d,%r14d
    88c6:	0f 84 84 07 00 00    	je     9050 <fwp_write+0xa50>
    88cc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    88d1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    88d6:	48 89 df             	mov    %rbx,%rdi
    88d9:	49 83 c5 01          	add    $0x1,%r13
    88dd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    88e1:	31 c9                	xor    %ecx,%ecx
    88e3:	e8 18 fd ff ff       	call   8600 <fwp_write>
    88e8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    88ed:	7f c3                	jg     88b2 <fwp_write+0x2b2>
    88ef:	45 85 f6             	test   %r14d,%r14d
    88f2:	0f 84 38 0a 00 00    	je     9330 <fwp_write+0xd30>
    88f8:	b8 29 00 00 00       	mov    $0x29,%eax
    88fd:	ba 01 00 00 00       	mov    $0x1,%edx
    8902:	4c 89 fe             	mov    %r15,%rsi
    8905:	48 89 df             	mov    %rbx,%rdi
    8908:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    890c:	e8 df b7 ff ff       	call   40f0 <buf_put>
    8911:	e9 80 fd ff ff       	jmp    8696 <fwp_write+0x96>
    8916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    891d:	00 00 00 
    8920:	ba 01 00 00 00       	mov    $0x1,%edx
    8925:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    892a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    892f:	e8 bc b7 ff ff       	call   40f0 <buf_put>
    8934:	48 85 ed             	test   %rbp,%rbp
    8937:	0f 84 93 06 00 00    	je     8fd0 <fwp_write+0x9d0>
    893d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8941:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8946:	31 c9                	xor    %ecx,%ecx
    8948:	48 89 df             	mov    %rbx,%rdi
    894b:	e8 b0 fc ff ff       	call   8600 <fwp_write>
    8950:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8954:	48 85 ed             	test   %rbp,%rbp
    8957:	0f 84 73 06 00 00    	je     8fd0 <fwp_write+0x9d0>
    895d:	ba 02 00 00 00       	mov    $0x2,%edx
    8962:	48 8d 35 ec 38 00 00 	lea    0x38ec(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8969:	48 89 df             	mov    %rbx,%rdi
    896c:	e8 7f b7 ff ff       	call   40f0 <buf_put>
    8971:	eb ca                	jmp    893d <fwp_write+0x33d>
    8973:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8978:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    897c:	85 f6                	test   %esi,%esi
    897e:	0f 84 fc 07 00 00    	je     9180 <fwp_write+0xb80>
    8984:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    898b:	00 
    898c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8993:	00 00 
    8995:	0f 85 3a 01 00 00    	jne    8ad5 <fwp_write+0x4d5>
    899b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    899f:	4c 89 ea             	mov    %r13,%rdx
    89a2:	e9 6c fe ff ff       	jmp    8813 <fwp_write+0x213>
    89a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    89ae:	00 00 
    89b0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    89b5:	ba 01 00 00 00       	mov    $0x1,%edx
    89ba:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    89bf:	48 89 ee             	mov    %rbp,%rsi
    89c2:	e8 29 b7 ff ff       	call   40f0 <buf_put>
    89c7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    89cc:	4c 89 e7             	mov    %r12,%rdi
    89cf:	e8 6c aa ff ff       	call   3440 <strlen@plt>
    89d4:	4c 89 e6             	mov    %r12,%rsi
    89d7:	48 89 df             	mov    %rbx,%rdi
    89da:	48 89 c2             	mov    %rax,%rdx
    89dd:	e8 0e b7 ff ff       	call   40f0 <buf_put>
    89e2:	ba 01 00 00 00       	mov    $0x1,%edx
    89e7:	48 89 ee             	mov    %rbp,%rsi
    89ea:	48 89 df             	mov    %rbx,%rdi
    89ed:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    89f2:	e8 f9 b6 ff ff       	call   40f0 <buf_put>
    89f7:	e9 9a fc ff ff       	jmp    8696 <fwp_write+0x96>
    89fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8a00:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8a05:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8a09:	0f 8a 8e 0b 00 00    	jp     959d <fwp_write+0xf9d>
    8a0f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a13:	66 0f 54 05 e5 43 00 	andpd  0x43e5(%rip),%xmm0        # ce00 <msg.4+0xc0>
    8a1a:	00 
    8a1b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8a20:	66 0f 2e 05 50 43 00 	ucomisd 0x4350(%rip),%xmm0        # cd78 <msg.4+0x38>
    8a27:	00 
    8a28:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8a2f:	00 
    8a30:	0f 87 b2 09 00 00    	ja     93e8 <fwp_write+0xde8>
    8a36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a3d:	00 00 00 
    8a40:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a44:	89 ee                	mov    %ebp,%esi
    8a46:	4c 89 e7             	mov    %r12,%rdi
    8a49:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8a4e:	e8 1d bd ff ff       	call   4770 <fwp_format_g.constprop.0>
    8a53:	31 f6                	xor    %esi,%esi
    8a55:	4c 89 e7             	mov    %r12,%rdi
    8a58:	e8 a3 a9 ff ff       	call   3400 <strtod@plt>
    8a5d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8a62:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8a66:	7a 06                	jp     8a6e <fwp_write+0x46e>
    8a68:	0f 84 e9 01 00 00    	je     8c57 <fwp_write+0x657>
    8a6e:	83 c5 01             	add    $0x1,%ebp
    8a71:	83 fd 12             	cmp    $0x12,%ebp
    8a74:	75 ca                	jne    8a40 <fwp_write+0x440>
    8a76:	be 11 00 00 00       	mov    $0x11,%esi
    8a7b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a7f:	4c 89 e7             	mov    %r12,%rdi
    8a82:	e8 e9 bc ff ff       	call   4770 <fwp_format_g.constprop.0>
    8a87:	e9 cb 01 00 00       	jmp    8c57 <fwp_write+0x657>
    8a8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a90:	48 83 fd 01          	cmp    $0x1,%rbp
    8a94:	0f 84 e6 08 00 00    	je     9380 <fwp_write+0xd80>
    8a9a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8a9e:	b8 02 00 00 00       	mov    $0x2,%eax
    8aa3:	ba 01 00 00 00       	mov    $0x1,%edx
    8aa8:	48 0f 44 d0          	cmove  %rax,%rdx
    8aac:	48 8d 35 4b 37 00 00 	lea    0x374b(%rip),%rsi        # c1fe <_IO_stdin_used+0x1fe>
    8ab3:	48 8d 05 49 37 00 00 	lea    0x3749(%rip),%rax        # c203 <_IO_stdin_used+0x203>
    8aba:	48 0f 44 f0          	cmove  %rax,%rsi
    8abe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8ac5:	00 
    8ac6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8acd:	00 00 
    8acf:	0f 84 3e fd ff ff    	je     8813 <fwp_write+0x213>
    8ad5:	e8 76 a9 ff ff       	call   3450 <__stack_chk_fail@plt>
    8ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ae0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8ae5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8aea:	e8 41 b5 ff ff       	call   4030 <buf_grow>
    8aef:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8af3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8af9:	4c 03 0b             	add    (%rbx),%r9
    8afc:	66 45 89 11          	mov    %r10w,(%r9)
    8b00:	45 85 e4             	test   %r12d,%r12d
    8b03:	0f 8e 07 05 00 00    	jle    9010 <fwp_write+0xa10>
    8b09:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8b10:	55 55 55 
    8b13:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8b18:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8b1f:	aa aa aa 
    8b22:	49 83 c1 01          	add    $0x1,%r9
    8b26:	eb 45                	jmp    8b6d <fwp_write+0x56d>
    8b28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b2f:	00 
    8b30:	be 01 00 00 00       	mov    $0x1,%esi
    8b35:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8b3a:	88 07                	mov    %al,(%rdi)
    8b3c:	48 89 e8             	mov    %rbp,%rax
    8b3f:	49 f7 e8             	imul   %r8
    8b42:	48 89 e8             	mov    %rbp,%rax
    8b45:	48 c1 f8 3f          	sar    $0x3f,%rax
    8b49:	48 29 c2             	sub    %rax,%rdx
    8b4c:	48 85 c9             	test   %rcx,%rcx
    8b4f:	0f 95 c0             	setne  %al
    8b52:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8b56:	48 83 ef 01          	sub    $0x1,%rdi
    8b5a:	48 21 c5             	and    %rax,%rbp
    8b5d:	48 29 ea             	sub    %rbp,%rdx
    8b60:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8b64:	49 39 f9             	cmp    %rdi,%r9
    8b67:	0f 84 a3 04 00 00    	je     9010 <fwp_write+0xa10>
    8b6d:	48 89 e8             	mov    %rbp,%rax
    8b70:	49 f7 e8             	imul   %r8
    8b73:	48 89 e8             	mov    %rbp,%rax
    8b76:	48 c1 f8 3f          	sar    $0x3f,%rax
    8b7a:	48 89 d1             	mov    %rdx,%rcx
    8b7d:	48 29 c1             	sub    %rax,%rcx
    8b80:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8b84:	48 89 e9             	mov    %rbp,%rcx
    8b87:	48 29 c1             	sub    %rax,%rcx
    8b8a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8b8e:	49 f7 e2             	mul    %r10
    8b91:	b8 30 00 00 00       	mov    $0x30,%eax
    8b96:	48 89 d6             	mov    %rdx,%rsi
    8b99:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8b9d:	48 d1 ee             	shr    $1,%rsi
    8ba0:	48 01 f2             	add    %rsi,%rdx
    8ba3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8ba7:	48 29 d6             	sub    %rdx,%rsi
    8baa:	74 8e                	je     8b3a <fwp_write+0x53a>
    8bac:	48 83 fe 01          	cmp    $0x1,%rsi
    8bb0:	0f 85 7a ff ff ff    	jne    8b30 <fwp_write+0x530>
    8bb6:	31 f6                	xor    %esi,%esi
    8bb8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8bbd:	e9 78 ff ff ff       	jmp    8b3a <fwp_write+0x53a>
    8bc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8bc8:	66 0f 6e cd          	movd   %ebp,%xmm1
    8bcc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8bcf:	0f 8a c8 09 00 00    	jp     959d <fwp_write+0xf9d>
    8bd5:	0f 28 c1             	movaps %xmm1,%xmm0
    8bd8:	0f 54 05 11 42 00 00 	andps  0x4211(%rip),%xmm0        # cdf0 <msg.4+0xb0>
    8bdf:	0f 2e 05 1e 34 00 00 	ucomiss 0x341e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8be6:	0f 87 24 08 00 00    	ja     9410 <fwp_write+0xe10>
    8bec:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8bf0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8bf6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8bfd:	00 
    8bfe:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8c02:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8c07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c0e:	00 00 
    8c10:	44 89 ee             	mov    %r13d,%esi
    8c13:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8c18:	4c 89 e7             	mov    %r12,%rdi
    8c1b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8c20:	e8 4b bb ff ff       	call   4770 <fwp_format_g.constprop.0>
    8c25:	31 f6                	xor    %esi,%esi
    8c27:	4c 89 e7             	mov    %r12,%rdi
    8c2a:	e8 71 a8 ff ff       	call   34a0 <strtof@plt>
    8c2f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8c34:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8c37:	7a 02                	jp     8c3b <fwp_write+0x63b>
    8c39:	74 1c                	je     8c57 <fwp_write+0x657>
    8c3b:	41 83 c5 01          	add    $0x1,%r13d
    8c3f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8c43:	75 cb                	jne    8c10 <fwp_write+0x610>
    8c45:	be 09 00 00 00       	mov    $0x9,%esi
    8c4a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8c4f:	4c 89 e7             	mov    %r12,%rdi
    8c52:	e8 19 bb ff ff       	call   4770 <fwp_format_g.constprop.0>
    8c57:	4c 89 e7             	mov    %r12,%rdi
    8c5a:	e8 51 b5 ff ff       	call   41b0 <fwp_finish_float>
    8c5f:	e9 1c fa ff ff       	jmp    8680 <fwp_write+0x80>
    8c64:	0f 1f 40 00          	nopl   0x0(%rax)
    8c68:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8c6c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8c70:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8c77:	00 
    8c78:	48 89 ef             	mov    %rbp,%rdi
    8c7b:	e8 c0 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8c80:	48 89 ef             	mov    %rbp,%rdi
    8c83:	e8 b8 a7 ff ff       	call   3440 <strlen@plt>
    8c88:	48 89 ee             	mov    %rbp,%rsi
    8c8b:	48 89 df             	mov    %rbx,%rdi
    8c8e:	48 89 c2             	mov    %rax,%rdx
    8c91:	e8 5a b4 ff ff       	call   40f0 <buf_put>
    8c96:	e9 fb f9 ff ff       	jmp    8696 <fwp_write+0x96>
    8c9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ca0:	ba 06 00 00 00       	mov    $0x6,%edx
    8ca5:	48 8d 35 ac 35 00 00 	lea    0x35ac(%rip),%rsi        # c258 <_IO_stdin_used+0x258>
    8cac:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8cb2:	e8 39 b4 ff ff       	call   40f0 <buf_put>
    8cb7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8cbe:	ff ff 7f 
    8cc1:	48 23 55 00          	and    0x0(%rbp),%rdx
    8cc5:	0f 84 86 02 00 00    	je     8f51 <fwp_write+0x951>
    8ccb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8cd0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8cd4:	48 85 d2             	test   %rdx,%rdx
    8cd7:	0f 84 ae 00 00 00    	je     8d8b <fwp_write+0x78b>
    8cdd:	8b 0a                	mov    (%rdx),%ecx
    8cdf:	83 f9 1c             	cmp    $0x1c,%ecx
    8ce2:	0f 84 58 06 00 00    	je     9340 <fwp_write+0xd40>
    8ce8:	83 f9 1b             	cmp    $0x1b,%ecx
    8ceb:	0f 87 9a 00 00 00    	ja     8d8b <fwp_write+0x78b>
    8cf1:	be 01 00 00 00       	mov    $0x1,%esi
    8cf6:	48 d3 e6             	shl    %cl,%rsi
    8cf9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8cff:	0f 85 4b 04 00 00    	jne    9150 <fwp_write+0xb50>
    8d05:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8d0b:	0f 85 0f 04 00 00    	jne    9120 <fwp_write+0xb20>
    8d11:	83 e6 21             	and    $0x21,%esi
    8d14:	74 75                	je     8d8b <fwp_write+0x78b>
    8d16:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8d1b:	48 85 ff             	test   %rdi,%rdi
    8d1e:	79 07                	jns    8d27 <fwp_write+0x727>
    8d20:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8d24:	4c 01 ee             	add    %r13,%rsi
    8d27:	48 0f be 3e          	movsbq (%rsi),%rdi
    8d2b:	85 c9                	test   %ecx,%ecx
    8d2d:	40 0f b6 f7          	movzbl %dil,%esi
    8d31:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d3c:	00 00 00 00 
    8d40:	31 c9                	xor    %ecx,%ecx
    8d42:	48 89 df             	mov    %rbx,%rdi
    8d45:	49 83 c5 01          	add    $0x1,%r13
    8d49:	e8 b2 f8 ff ff       	call   8600 <fwp_write>
    8d4e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d55:	ff ff 7f 
    8d58:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d5c:	49 39 d5             	cmp    %rdx,%r13
    8d5f:	0f 83 ec 01 00 00    	jae    8f51 <fwp_write+0x951>
    8d65:	ba 02 00 00 00       	mov    $0x2,%edx
    8d6a:	48 89 df             	mov    %rbx,%rdi
    8d6d:	48 8d 35 e1 34 00 00 	lea    0x34e1(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8d74:	e8 77 b3 ff ff       	call   40f0 <buf_put>
    8d79:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d7e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d82:	48 85 d2             	test   %rdx,%rdx
    8d85:	0f 85 52 ff ff ff    	jne    8cdd <fwp_write+0x6dd>
    8d8b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8d90:	48 85 ff             	test   %rdi,%rdi
    8d93:	0f 88 cf 05 00 00    	js     9368 <fwp_write+0xd68>
    8d99:	48 8b 31             	mov    (%rcx),%rsi
    8d9c:	eb a2                	jmp    8d40 <fwp_write+0x740>
    8d9e:	66 90                	xchg   %ax,%ax
    8da0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8da7:	00 
    8da8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8daf:	00 00 
    8db1:	0f 85 1e fd ff ff    	jne    8ad5 <fwp_write+0x4d5>
    8db7:	ba 08 00 00 00       	mov    $0x8,%edx
    8dbc:	48 8d 35 62 34 00 00 	lea    0x3462(%rip),%rsi        # c225 <_IO_stdin_used+0x225>
    8dc3:	e9 4b fa ff ff       	jmp    8813 <fwp_write+0x213>
    8dc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8dcf:	00 
    8dd0:	89 e8                	mov    %ebp,%eax
    8dd2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8dd9:	76 03                	jbe    8dde <fwp_write+0x7de>
    8ddb:	8b 45 00             	mov    0x0(%rbp),%eax
    8dde:	41 89 c6             	mov    %eax,%r14d
    8de1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8de6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8deb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8def:	4c 89 ef             	mov    %r13,%rdi
    8df2:	e8 49 a6 ff ff       	call   3440 <strlen@plt>
    8df7:	4c 89 ee             	mov    %r13,%rsi
    8dfa:	48 89 df             	mov    %rbx,%rdi
    8dfd:	48 89 c2             	mov    %rax,%rdx
    8e00:	e8 eb b2 ff ff       	call   40f0 <buf_put>
    8e05:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8e0a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8e0e:	85 f6                	test   %esi,%esi
    8e10:	0f 8e 80 f8 ff ff    	jle    8696 <fwp_write+0x96>
    8e16:	45 31 ed             	xor    %r13d,%r13d
    8e19:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e1e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8e23:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8e28:	ba 01 00 00 00       	mov    $0x1,%edx
    8e2d:	4c 89 fe             	mov    %r15,%rsi
    8e30:	48 89 04 24          	mov    %rax,(%rsp)
    8e34:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8e39:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8e3d:	48 89 df             	mov    %rbx,%rdi
    8e40:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8e44:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8e49:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8e4e:	e8 9d b2 ff ff       	call   40f0 <buf_put>
    8e53:	41 8b 06             	mov    (%r14),%eax
    8e56:	83 f8 0e             	cmp    $0xe,%eax
    8e59:	0f 84 71 02 00 00    	je     90d0 <fwp_write+0xad0>
    8e5f:	83 f8 10             	cmp    $0x10,%eax
    8e62:	0f 84 38 02 00 00    	je     90a0 <fwp_write+0xaa0>
    8e68:	83 f8 0a             	cmp    $0xa,%eax
    8e6b:	0f 84 7f 04 00 00    	je     92f0 <fwp_write+0xcf0>
    8e71:	0f 8f f9 00 00 00    	jg     8f70 <fwp_write+0x970>
    8e77:	83 f8 03             	cmp    $0x3,%eax
    8e7a:	0f 8f 50 04 00 00    	jg     92d0 <fwp_write+0xcd0>
    8e80:	85 c0                	test   %eax,%eax
    8e82:	78 10                	js     8e94 <fwp_write+0x894>
    8e84:	48 8b 04 24          	mov    (%rsp),%rax
    8e88:	48 c1 e8 3f          	shr    $0x3f,%rax
    8e8c:	85 c0                	test   %eax,%eax
    8e8e:	0f 85 f9 00 00 00    	jne    8f8d <fwp_write+0x98d>
    8e94:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8e99:	48 8b 34 24          	mov    (%rsp),%rsi
    8e9d:	31 c9                	xor    %ecx,%ecx
    8e9f:	48 89 df             	mov    %rbx,%rdi
    8ea2:	e8 59 f7 ff ff       	call   8600 <fwp_write>
    8ea7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8eac:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8eb1:	49 83 c5 01          	add    $0x1,%r13
    8eb5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8eb9:	0f 8f 5f ff ff ff    	jg     8e1e <fwp_write+0x81e>
    8ebf:	e9 d2 f7 ff ff       	jmp    8696 <fwp_write+0x96>
    8ec4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ec8:	ba 06 00 00 00       	mov    $0x6,%edx
    8ecd:	48 8d 35 77 33 00 00 	lea    0x3377(%rip),%rsi        # c24b <_IO_stdin_used+0x24b>
    8ed4:	45 31 ed             	xor    %r13d,%r13d
    8ed7:	e8 14 b2 ff ff       	call   40f0 <buf_put>
    8edc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8ee1:	75 19                	jne    8efc <fwp_write+0x8fc>
    8ee3:	eb 6c                	jmp    8f51 <fwp_write+0x951>
    8ee5:	0f 1f 00             	nopl   (%rax)
    8ee8:	ba 02 00 00 00       	mov    $0x2,%edx
    8eed:	48 8d 35 61 33 00 00 	lea    0x3361(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8ef4:	48 89 df             	mov    %rbx,%rdi
    8ef7:	e8 f4 b1 ff ff       	call   40f0 <buf_put>
    8efc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8f02:	b9 00 02 00 00       	mov    $0x200,%ecx
    8f07:	31 c0                	xor    %eax,%eax
    8f09:	49 83 c5 01          	add    $0x1,%r13
    8f0d:	4c 8d 05 3e 33 00 00 	lea    0x333e(%rip),%r8        # c252 <_IO_stdin_used+0x252>
    8f14:	ba 02 00 00 00       	mov    $0x2,%edx
    8f19:	be 00 02 00 00       	mov    $0x200,%esi
    8f1e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f25:	00 
    8f26:	e8 75 a4 ff ff       	call   33a0 <__snprintf_chk@plt>
    8f2b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f32:	00 
    8f33:	e8 08 a5 ff ff       	call   3440 <strlen@plt>
    8f38:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8f3f:	00 
    8f40:	48 89 df             	mov    %rbx,%rdi
    8f43:	48 89 c2             	mov    %rax,%rdx
    8f46:	e8 a5 b1 ff ff       	call   40f0 <buf_put>
    8f4b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8f4f:	72 97                	jb     8ee8 <fwp_write+0x8e8>
    8f51:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f56:	ba 01 00 00 00       	mov    $0x1,%edx
    8f5b:	48 89 df             	mov    %rbx,%rdi
    8f5e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8f63:	e8 88 b1 ff ff       	call   40f0 <buf_put>
    8f68:	e9 29 f7 ff ff       	jmp    8696 <fwp_write+0x96>
    8f6d:	0f 1f 00             	nopl   (%rax)
    8f70:	83 f8 0b             	cmp    $0xb,%eax
    8f73:	0f 85 1b ff ff ff    	jne    8e94 <fwp_write+0x894>
    8f79:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8f7e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8f82:	83 e0 01             	and    $0x1,%eax
    8f85:	85 c0                	test   %eax,%eax
    8f87:	0f 84 07 ff ff ff    	je     8e94 <fwp_write+0x894>
    8f8d:	4c 89 fe             	mov    %r15,%rsi
    8f90:	48 89 df             	mov    %rbx,%rdi
    8f93:	ba 01 00 00 00       	mov    $0x1,%edx
    8f98:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8f9d:	e8 4e b1 ff ff       	call   40f0 <buf_put>
    8fa2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8fa7:	48 8b 34 24          	mov    (%rsp),%rsi
    8fab:	31 c9                	xor    %ecx,%ecx
    8fad:	48 89 df             	mov    %rbx,%rdi
    8fb0:	e8 4b f6 ff ff       	call   8600 <fwp_write>
    8fb5:	ba 01 00 00 00       	mov    $0x1,%edx
    8fba:	4c 89 fe             	mov    %r15,%rsi
    8fbd:	48 89 df             	mov    %rbx,%rdi
    8fc0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8fc5:	e8 26 b1 ff ff       	call   40f0 <buf_put>
    8fca:	e9 d8 fe ff ff       	jmp    8ea7 <fwp_write+0x8a7>
    8fcf:	90                   	nop
    8fd0:	ba 01 00 00 00       	mov    $0x1,%edx
    8fd5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8fda:	48 89 df             	mov    %rbx,%rdi
    8fdd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8fe2:	e8 09 b1 ff ff       	call   40f0 <buf_put>
    8fe7:	e9 aa f6 ff ff       	jmp    8696 <fwp_write+0x96>
    8fec:	0f 1f 40 00          	nopl   0x0(%rax)
    8ff0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8ff5:	ba 01 00 00 00       	mov    $0x1,%edx
    8ffa:	48 89 df             	mov    %rbx,%rdi
    8ffd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9002:	e8 e9 b0 ff ff       	call   40f0 <buf_put>
    9007:	e9 8a f6 ff ff       	jmp    8696 <fwp_write+0x96>
    900c:	0f 1f 40 00          	nopl   0x0(%rax)
    9010:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9014:	48 8b 13             	mov    (%rbx),%rdx
    9017:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    901c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9020:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9024:	e9 6d f6 ff ff       	jmp    8696 <fwp_write+0x96>
    9029:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9030:	ba 02 00 00 00       	mov    $0x2,%edx
    9035:	48 8d 35 19 32 00 00 	lea    0x3219(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    903c:	48 89 df             	mov    %rbx,%rdi
    903f:	e8 ac b0 ff ff       	call   40f0 <buf_put>
    9044:	e9 72 f8 ff ff       	jmp    88bb <fwp_write+0x2bb>
    9049:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9050:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9055:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    905a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    905e:	48 89 f7             	mov    %rsi,%rdi
    9061:	48 89 34 24          	mov    %rsi,(%rsp)
    9065:	e8 d6 a3 ff ff       	call   3440 <strlen@plt>
    906a:	48 8b 34 24          	mov    (%rsp),%rsi
    906e:	48 89 df             	mov    %rbx,%rdi
    9071:	48 89 c2             	mov    %rax,%rdx
    9074:	e8 77 b0 ff ff       	call   40f0 <buf_put>
    9079:	ba 03 00 00 00       	mov    $0x3,%edx
    907e:	48 8d 35 f3 31 00 00 	lea    0x31f3(%rip),%rsi        # c278 <_IO_stdin_used+0x278>
    9085:	48 89 df             	mov    %rbx,%rdi
    9088:	e8 63 b0 ff ff       	call   40f0 <buf_put>
    908d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9092:	e9 35 f8 ff ff       	jmp    88cc <fwp_write+0x2cc>
    9097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    909e:	00 00 
    90a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    90a5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    90a9:	48 85 ff             	test   %rdi,%rdi
    90ac:	0f 84 e2 fd ff ff    	je     8e94 <fwp_write+0x894>
    90b2:	48 8d 35 a9 31 00 00 	lea    0x31a9(%rip),%rsi        # c262 <_IO_stdin_used+0x262>
    90b9:	e8 62 a4 ff ff       	call   3520 <strcmp@plt>
    90be:	85 c0                	test   %eax,%eax
    90c0:	0f 95 c0             	setne  %al
    90c3:	0f b6 c0             	movzbl %al,%eax
    90c6:	e9 c1 fd ff ff       	jmp    8e8c <fwp_write+0x88c>
    90cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    90d0:	31 c0                	xor    %eax,%eax
    90d2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    90d9:	00 
    90da:	0f 97 c0             	seta   %al
    90dd:	e9 aa fd ff ff       	jmp    8e8c <fwp_write+0x88c>
    90e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90e8:	48 89 df             	mov    %rbx,%rdi
    90eb:	ba 02 00 00 00       	mov    $0x2,%edx
    90f0:	48 8d 35 68 31 00 00 	lea    0x3168(%rip),%rsi        # c25f <_IO_stdin_used+0x25f>
    90f7:	e8 f4 af ff ff       	call   40f0 <buf_put>
    90fc:	4c 89 e8             	mov    %r13,%rax
    90ff:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9104:	31 c9                	xor    %ecx,%ecx
    9106:	48 c1 e0 04          	shl    $0x4,%rax
    910a:	48 89 df             	mov    %rbx,%rdi
    910d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9112:	e8 e9 f4 ff ff       	call   8600 <fwp_write>
    9117:	e9 5e f6 ff ff       	jmp    877a <fwp_write+0x17a>
    911c:	0f 1f 40 00          	nopl   0x0(%rax)
    9120:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9125:	48 85 ff             	test   %rdi,%rdi
    9128:	79 0c                	jns    9136 <fwp_write+0xb36>
    912a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9131:	00 
    9132:	48 03 75 10          	add    0x10(%rbp),%rsi
    9136:	48 63 3e             	movslq (%rsi),%rdi
    9139:	83 f9 02             	cmp    $0x2,%ecx
    913c:	89 fe                	mov    %edi,%esi
    913e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9142:	e9 f9 fb ff ff       	jmp    8d40 <fwp_write+0x740>
    9147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    914e:	00 00 
    9150:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9155:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    915a:	48 85 ff             	test   %rdi,%rdi
    915d:	0f 88 0f 03 00 00    	js     9472 <fwp_write+0xe72>
    9163:	49 0f bf 38          	movswq (%r8),%rdi
    9167:	83 f9 01             	cmp    $0x1,%ecx
    916a:	0f b7 f7             	movzwl %di,%esi
    916d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9171:	e9 ca fb ff ff       	jmp    8d40 <fwp_write+0x740>
    9176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    917d:	00 00 00 
    9180:	ba 01 00 00 00       	mov    $0x1,%edx
    9185:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    918a:	48 83 c5 08          	add    $0x8,%rbp
    918e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9193:	e8 58 af ff ff       	call   40f0 <buf_put>
    9198:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    919d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    91a2:	4d 85 ed             	test   %r13,%r13
    91a5:	75 46                	jne    91ed <fwp_write+0xbed>
    91a7:	e9 04 01 00 00       	jmp    92b0 <fwp_write+0xcb0>
    91ac:	0f 1f 40 00          	nopl   0x0(%rax)
    91b0:	41 80 f9 09          	cmp    $0x9,%r9b
    91b4:	0f 84 d6 00 00 00    	je     9290 <fwp_write+0xc90>
    91ba:	41 80 f9 0a          	cmp    $0xa,%r9b
    91be:	0f 85 9c 00 00 00    	jne    9260 <fwp_write+0xc60>
    91c4:	ba 02 00 00 00       	mov    $0x2,%edx
    91c9:	48 8d 35 6b 30 00 00 	lea    0x306b(%rip),%rsi        # c23b <_IO_stdin_used+0x23b>
    91d0:	48 89 df             	mov    %rbx,%rdi
    91d3:	e8 18 af ff ff       	call   40f0 <buf_put>
    91d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    91df:	00 
    91e0:	48 83 c5 01          	add    $0x1,%rbp
    91e4:	49 39 ec             	cmp    %rbp,%r12
    91e7:	0f 84 c3 00 00 00    	je     92b0 <fwp_write+0xcb0>
    91ed:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    91f2:	41 80 f9 0d          	cmp    $0xd,%r9b
    91f6:	74 28                	je     9220 <fwp_write+0xc20>
    91f8:	7e b6                	jle    91b0 <fwp_write+0xbb0>
    91fa:	41 80 f9 22          	cmp    $0x22,%r9b
    91fe:	74 40                	je     9240 <fwp_write+0xc40>
    9200:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9204:	75 5a                	jne    9260 <fwp_write+0xc60>
    9206:	ba 02 00 00 00       	mov    $0x2,%edx
    920b:	48 8d 35 26 30 00 00 	lea    0x3026(%rip),%rsi        # c238 <_IO_stdin_used+0x238>
    9212:	48 89 df             	mov    %rbx,%rdi
    9215:	e8 d6 ae ff ff       	call   40f0 <buf_put>
    921a:	eb c4                	jmp    91e0 <fwp_write+0xbe0>
    921c:	0f 1f 40 00          	nopl   0x0(%rax)
    9220:	ba 02 00 00 00       	mov    $0x2,%edx
    9225:	48 8d 35 15 30 00 00 	lea    0x3015(%rip),%rsi        # c241 <_IO_stdin_used+0x241>
    922c:	48 89 df             	mov    %rbx,%rdi
    922f:	e8 bc ae ff ff       	call   40f0 <buf_put>
    9234:	eb aa                	jmp    91e0 <fwp_write+0xbe0>
    9236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    923d:	00 00 00 
    9240:	ba 02 00 00 00       	mov    $0x2,%edx
    9245:	48 8d 35 e9 2f 00 00 	lea    0x2fe9(%rip),%rsi        # c235 <_IO_stdin_used+0x235>
    924c:	48 89 df             	mov    %rbx,%rdi
    924f:	e8 9c ae ff ff       	call   40f0 <buf_put>
    9254:	eb 8a                	jmp    91e0 <fwp_write+0xbe0>
    9256:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    925d:	00 00 00 
    9260:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9264:	0f 86 2e 01 00 00    	jbe    9398 <fwp_write+0xd98>
    926a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    926e:	0f 84 24 01 00 00    	je     9398 <fwp_write+0xd98>
    9274:	ba 01 00 00 00       	mov    $0x1,%edx
    9279:	4c 89 fe             	mov    %r15,%rsi
    927c:	48 89 df             	mov    %rbx,%rdi
    927f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9284:	e8 67 ae ff ff       	call   40f0 <buf_put>
    9289:	e9 52 ff ff ff       	jmp    91e0 <fwp_write+0xbe0>
    928e:	66 90                	xchg   %ax,%ax
    9290:	ba 02 00 00 00       	mov    $0x2,%edx
    9295:	48 8d 35 a2 2f 00 00 	lea    0x2fa2(%rip),%rsi        # c23e <_IO_stdin_used+0x23e>
    929c:	48 89 df             	mov    %rbx,%rdi
    929f:	e8 4c ae ff ff       	call   40f0 <buf_put>
    92a4:	e9 37 ff ff ff       	jmp    91e0 <fwp_write+0xbe0>
    92a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    92b0:	ba 01 00 00 00       	mov    $0x1,%edx
    92b5:	4c 89 fe             	mov    %r15,%rsi
    92b8:	48 89 df             	mov    %rbx,%rdi
    92bb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    92c0:	e8 2b ae ff ff       	call   40f0 <buf_put>
    92c5:	e9 cc f3 ff ff       	jmp    8696 <fwp_write+0x96>
    92ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92d0:	83 f8 04             	cmp    $0x4,%eax
    92d3:	0f 85 bb fb ff ff    	jne    8e94 <fwp_write+0x894>
    92d9:	48 8b 04 24          	mov    (%rsp),%rax
    92dd:	48 8b 40 08          	mov    0x8(%rax),%rax
    92e1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    92e6:	48 c1 e8 3f          	shr    $0x3f,%rax
    92ea:	e9 96 fc ff ff       	jmp    8f85 <fwp_write+0x985>
    92ef:	90                   	nop
    92f0:	8b 0c 24             	mov    (%rsp),%ecx
    92f3:	31 c0                	xor    %eax,%eax
    92f5:	85 c9                	test   %ecx,%ecx
    92f7:	0f 98 c0             	sets   %al
    92fa:	e9 86 fc ff ff       	jmp    8f85 <fwp_write+0x985>
    92ff:	90                   	nop
    9300:	48 f7 d8             	neg    %rax
    9303:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    930a:	00 
    930b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9312:	2d 
    9313:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    931a:	00 
    931b:	48 83 d2 00          	adc    $0x0,%rdx
    931f:	48 89 c6             	mov    %rax,%rsi
    9322:	48 f7 da             	neg    %rdx
    9325:	e8 16 a7 ff ff       	call   3a40 <fwp_fmt_u128>
    932a:	e9 51 f3 ff ff       	jmp    8680 <fwp_write+0x80>
    932f:	90                   	nop
    9330:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9335:	e9 c3 f5 ff ff       	jmp    88fd <fwp_write+0x2fd>
    933a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9340:	4c 89 e9             	mov    %r13,%rcx
    9343:	48 c1 e1 04          	shl    $0x4,%rcx
    9347:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    934c:	48 85 ff             	test   %rdi,%rdi
    934f:	0f 89 eb f9 ff ff    	jns    8d40 <fwp_write+0x740>
    9355:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9359:	48 89 ce             	mov    %rcx,%rsi
    935c:	e9 df f9 ff ff       	jmp    8d40 <fwp_write+0x740>
    9361:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9368:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    936f:	00 
    9370:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9374:	e9 20 fa ff ff       	jmp    8d99 <fwp_write+0x799>
    9379:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9380:	ba 02 00 00 00       	mov    $0x2,%edx
    9385:	48 8d 35 74 2e 00 00 	lea    0x2e74(%rip),%rsi        # c200 <_IO_stdin_used+0x200>
    938c:	e9 2d f7 ff ff       	jmp    8abe <fwp_write+0x4be>
    9391:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9398:	4c 8d 05 a5 2e 00 00 	lea    0x2ea5(%rip),%r8        # c244 <_IO_stdin_used+0x244>
    939f:	b9 10 00 00 00       	mov    $0x10,%ecx
    93a4:	31 c0                	xor    %eax,%eax
    93a6:	ba 02 00 00 00       	mov    $0x2,%edx
    93ab:	be 10 00 00 00       	mov    $0x10,%esi
    93b0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    93b7:	00 
    93b8:	e8 e3 9f ff ff       	call   33a0 <__snprintf_chk@plt>
    93bd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    93c4:	00 
    93c5:	e8 76 a0 ff ff       	call   3440 <strlen@plt>
    93ca:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    93d1:	00 
    93d2:	48 89 df             	mov    %rbx,%rdi
    93d5:	48 89 c2             	mov    %rax,%rdx
    93d8:	e8 13 ad ff ff       	call   40f0 <buf_put>
    93dd:	e9 fe fd ff ff       	jmp    91e0 <fwp_write+0xbe0>
    93e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93e8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    93ec:	48 8d 35 07 2e 00 00 	lea    0x2e07(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    93f3:	48 8d 05 ff 2d 00 00 	lea    0x2dff(%rip),%rax        # c1f9 <_IO_stdin_used+0x1f9>
    93fa:	4c 89 e7             	mov    %r12,%rdi
    93fd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9401:	48 0f 46 f0          	cmovbe %rax,%rsi
    9405:	e8 d6 9f ff ff       	call   33e0 <strcpy@plt>
    940a:	e9 71 f2 ff ff       	jmp    8680 <fwp_write+0x80>
    940f:	90                   	nop
    9410:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9414:	48 8d 35 df 2d 00 00 	lea    0x2ddf(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    941b:	48 8d 05 d7 2d 00 00 	lea    0x2dd7(%rip),%rax        # c1f9 <_IO_stdin_used+0x1f9>
    9422:	0f 2f c8             	comiss %xmm0,%xmm1
    9425:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    942c:	00 
    942d:	4c 89 e7             	mov    %r12,%rdi
    9430:	48 0f 46 f0          	cmovbe %rax,%rsi
    9434:	e8 a7 9f ff ff       	call   33e0 <strcpy@plt>
    9439:	e9 42 f2 ff ff       	jmp    8680 <fwp_write+0x80>
    943e:	66 90                	xchg   %ax,%ax
    9440:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9445:	45 85 c0             	test   %r8d,%r8d
    9448:	75 34                	jne    947e <fwp_write+0xe7e>
    944a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9451:	00 
    9452:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9459:	00 00 
    945b:	0f 85 74 f6 ff ff    	jne    8ad5 <fwp_write+0x4d5>
    9461:	ba 02 00 00 00       	mov    $0x2,%edx
    9466:	48 8d 35 08 2e 00 00 	lea    0x2e08(%rip),%rsi        # c275 <_IO_stdin_used+0x275>
    946d:	e9 a1 f3 ff ff       	jmp    8813 <fwp_write+0x213>
    9472:	48 03 75 10          	add    0x10(%rbp),%rsi
    9476:	49 89 f0             	mov    %rsi,%r8
    9479:	e9 e5 fc ff ff       	jmp    9163 <fwp_write+0xb63>
    947e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9483:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9488:	85 ff                	test   %edi,%edi
    948a:	0f 84 fa f3 ff ff    	je     888a <fwp_write+0x28a>
    9490:	ba 01 00 00 00       	mov    $0x1,%edx
    9495:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    949a:	48 89 df             	mov    %rbx,%rdi
    949d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    94a2:	e8 49 ac ff ff       	call   40f0 <buf_put>
    94a7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    94ac:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    94b1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    94b7:	85 c0                	test   %eax,%eax
    94b9:	0f 8f f0 f3 ff ff    	jg     88af <fwp_write+0x2af>
    94bf:	e9 34 f4 ff ff       	jmp    88f8 <fwp_write+0x2f8>
    94c4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    94c8:	49 89 c5             	mov    %rax,%r13
    94cb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    94d0:	49 89 c4             	mov    %rax,%r12
    94d3:	49 c1 fd 3f          	sar    $0x3f,%r13
    94d7:	4c 09 e8             	or     %r13,%rax
    94da:	0f 84 a7 00 00 00    	je     9587 <fwp_write+0xf87>
    94e0:	48 8d 2d d9 4d 00 00 	lea    0x4dd9(%rip),%rbp        # e2c0 <units.0>
    94e7:	4d 89 e7             	mov    %r12,%r15
    94ea:	48 8b 45 08          	mov    0x8(%rbp),%rax
    94ee:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    94f3:	4c 89 ff             	mov    %r15,%rdi
    94f6:	4c 89 ee             	mov    %r13,%rsi
    94f9:	44 89 0c 24          	mov    %r9d,(%rsp)
    94fd:	48 99                	cqto
    94ff:	48 89 d1             	mov    %rdx,%rcx
    9502:	48 89 c2             	mov    %rax,%rdx
    9505:	e8 d6 24 00 00       	call   b9e0 <__divmodti4>
    950a:	44 8b 0c 24          	mov    (%rsp),%r9d
    950e:	48 89 c1             	mov    %rax,%rcx
    9511:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9516:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    951b:	0f 84 94 00 00 00    	je     95b5 <fwp_write+0xfb5>
    9521:	41 83 c1 01          	add    $0x1,%r9d
    9525:	48 83 c5 10          	add    $0x10,%rbp
    9529:	41 83 f9 05          	cmp    $0x5,%r9d
    952d:	75 bb                	jne    94ea <fwp_write+0xeea>
    952f:	4d 85 ed             	test   %r13,%r13
    9532:	79 53                	jns    9587 <fwp_write+0xf87>
    9534:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9539:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    953e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9543:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9548:	48 99                	cqto
    954a:	48 f7 d8             	neg    %rax
    954d:	48 83 d2 00          	adc    $0x0,%rdx
    9551:	48 89 c6             	mov    %rax,%rsi
    9554:	48 f7 da             	neg    %rdx
    9557:	e8 e4 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    955c:	49 89 e8             	mov    %rbp,%r8
    955f:	ba 00 02 00 00       	mov    $0x200,%edx
    9564:	be 02 00 00 00       	mov    $0x2,%esi
    9569:	31 c0                	xor    %eax,%eax
    956b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9572:	00 
    9573:	48 8d 0d f6 2c 00 00 	lea    0x2cf6(%rip),%rcx        # c270 <_IO_stdin_used+0x270>
    957a:	4c 89 e7             	mov    %r12,%rdi
    957d:	e8 3e a1 ff ff       	call   36c0 <__sprintf_chk@plt>
    9582:	e9 f9 f0 ff ff       	jmp    8680 <fwp_write+0x80>
    9587:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    958c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9591:	31 d2                	xor    %edx,%edx
    9593:	48 89 ef             	mov    %rbp,%rdi
    9596:	e8 a5 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    959b:	eb bf                	jmp    955c <fwp_write+0xf5c>
    959d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    95a4:	4e 61 4e 00 
    95a8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95af:	00 
    95b0:	e9 cb f0 ff ff       	jmp    8680 <fwp_write+0x80>
    95b5:	44 89 0c 24          	mov    %r9d,(%rsp)
    95b9:	48 89 c8             	mov    %rcx,%rax
    95bc:	48 85 d2             	test   %rdx,%rdx
    95bf:	78 51                	js     9612 <fwp_write+0x1012>
    95c1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95c6:	48 89 c6             	mov    %rax,%rsi
    95c9:	48 89 ef             	mov    %rbp,%rdi
    95cc:	e8 6f a4 ff ff       	call   3a40 <fwp_fmt_u128>
    95d1:	44 8b 0c 24          	mov    (%rsp),%r9d
    95d5:	49 63 c1             	movslq %r9d,%rax
    95d8:	49 89 e8             	mov    %rbp,%r8
    95db:	ba 00 02 00 00       	mov    $0x200,%edx
    95e0:	be 02 00 00 00       	mov    $0x2,%esi
    95e5:	48 c1 e0 04          	shl    $0x4,%rax
    95e9:	48 8d 3d d0 4c 00 00 	lea    0x4cd0(%rip),%rdi        # e2c0 <units.0>
    95f0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95f7:	00 
    95f8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    95fc:	48 8d 0d 68 2c 00 00 	lea    0x2c68(%rip),%rcx        # c26b <_IO_stdin_used+0x26b>
    9603:	4c 89 e7             	mov    %r12,%rdi
    9606:	31 c0                	xor    %eax,%eax
    9608:	e8 b3 a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    960d:	e9 6e f0 ff ff       	jmp    8680 <fwp_write+0x80>
    9612:	48 f7 d8             	neg    %rax
    9615:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    961a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    961f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9624:	48 83 d2 00          	adc    $0x0,%rdx
    9628:	48 89 c6             	mov    %rax,%rsi
    962b:	48 f7 da             	neg    %rdx
    962e:	e8 0d a4 ff ff       	call   3a40 <fwp_fmt_u128>
    9633:	44 8b 0c 24          	mov    (%rsp),%r9d
    9637:	eb 9c                	jmp    95d5 <fwp_write+0xfd5>
    9639:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009640 <fwp_main_thread>:
    9640:	f3 0f 1e fa          	endbr64
    9644:	41 57                	push   %r15
    9646:	41 56                	push   %r14
    9648:	41 55                	push   %r13
    964a:	41 54                	push   %r12
    964c:	55                   	push   %rbp
    964d:	53                   	push   %rbx
    964e:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    9655:	44 8b 1d 68 05 06 00 	mov    0x60568(%rip),%r11d        # 69bc4 <fwp_heap+0x13a4>
    965c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9663:	00 00 
    9665:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    966c:	00 
    966d:	31 c0                	xor    %eax,%eax
    966f:	45 85 db             	test   %r11d,%r11d
    9672:	0f 84 02 14 00 00    	je     aa7a <fwp_main_thread+0x143a>
    9678:	44 8b 15 49 05 06 00 	mov    0x60549(%rip),%r10d        # 69bc8 <fwp_heap+0x13a8>
    967f:	45 85 d2             	test   %r10d,%r10d
    9682:	0f 85 e1 13 00 00    	jne    aa69 <fwp_main_thread+0x1429>
    9688:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    968f:	00 
    9690:	31 f6                	xor    %esi,%esi
    9692:	48 c7 05 23 eb 05 00 	movq   $0x40000000,0x5eb23(%rip)        # 681c0 <fwp_main_stack_size>
    9699:	00 00 00 40 
    969d:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    96a2:	48 89 05 1f eb 05 00 	mov    %rax,0x5eb1f(%rip)        # 681c8 <fwp_main_stack_top>
    96a9:	48 8d 05 d0 69 00 00 	lea    0x69d0(%rip),%rax        # 10080 <alt.5>
    96b0:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    96b7:	00 
    96b8:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    96bf:	00 
    96c0:	48 89 c7             	mov    %rax,%rdi
    96c3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    96c8:	48 c7 84 24 e0 00 00 	movq   $0x10000,0xe0(%rsp)
    96cf:	00 00 00 01 00 
    96d4:	c7 84 24 d8 00 00 00 	movl   $0x0,0xd8(%rsp)
    96db:	00 00 00 00 
    96df:	e8 bc 9f ff ff       	call   36a0 <sigaltstack@plt>
    96e4:	85 c0                	test   %eax,%eax
    96e6:	0f 85 89 22 00 00    	jne    b975 <fwp_main_thread+0x2335>
    96ec:	31 c0                	xor    %eax,%eax
    96ee:	b9 12 00 00 00       	mov    $0x12,%ecx
    96f3:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    96fa:	00 
    96fb:	f3 48 ab             	rep stos %rax,(%rdi)
    96fe:	48 8d 9c 24 40 01 00 	lea    0x140(%rsp),%rbx
    9705:	00 
    9706:	48 8d 05 33 a6 ff ff 	lea    -0x59cd(%rip),%rax        # 3d40 <fwp_segv>
    970d:	c7 84 24 c8 01 00 00 	movl   $0x8000004,0x1c8(%rsp)
    9714:	04 00 00 08 
    9718:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    971f:	00 
    9720:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9725:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
    972c:	00 
    972d:	e8 2e 9e ff ff       	call   3560 <sigemptyset@plt>
    9732:	85 c0                	test   %eax,%eax
    9734:	0f 85 3b 22 00 00    	jne    b975 <fwp_main_thread+0x2335>
    973a:	31 d2                	xor    %edx,%edx
    973c:	48 89 de             	mov    %rbx,%rsi
    973f:	bf 0b 00 00 00       	mov    $0xb,%edi
    9744:	e8 a7 9c ff ff       	call   33f0 <sigaction@plt>
    9749:	85 c0                	test   %eax,%eax
    974b:	0f 85 24 22 00 00    	jne    b975 <fwp_main_thread+0x2335>
    9751:	31 d2                	xor    %edx,%edx
    9753:	48 89 de             	mov    %rbx,%rsi
    9756:	bf 07 00 00 00       	mov    $0x7,%edi
    975b:	e8 90 9c ff ff       	call   33f0 <sigaction@plt>
    9760:	85 c0                	test   %eax,%eax
    9762:	0f 85 0d 22 00 00    	jne    b975 <fwp_main_thread+0x2335>
    9768:	48 8b 05 d1 04 06 00 	mov    0x604d1(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    976f:	48 85 c0             	test   %rax,%rax
    9772:	0f 88 08 06 00 00    	js     9d80 <fwp_main_thread+0x740>
    9778:	66 0f ef c0          	pxor   %xmm0,%xmm0
    977c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9781:	48 8d 3d 98 aa ff ff 	lea    -0x5568(%rip),%rdi        # 4220 <ad_raw_report>
    9788:	f2 0f 11 05 38 0d 06 	movsd  %xmm0,0x60d38(%rip)        # 6a4c8 <iteration_start_charge>
    978f:	00 
    9790:	c7 05 4e 0d 06 00 01 	movl   $0x1,0x60d4e(%rip)        # 6a4e8 <iteration_active>
    9797:	00 00 00 
    979a:	e8 51 24 00 00       	call   bbf0 <atexit>
    979f:	85 c0                	test   %eax,%eax
    97a1:	0f 85 fd 21 00 00    	jne    b9a4 <fwp_main_thread+0x2364>
    97a7:	44 8b 0d c2 68 00 00 	mov    0x68c2(%rip),%r9d        # 10070 <st.3>
    97ae:	45 85 c9             	test   %r9d,%r9d
    97b1:	0f 84 07 06 00 00    	je     9dbe <fwp_main_thread+0x77e>
    97b7:	48 8b 2d 42 f0 05 00 	mov    0x5f042(%rip),%rbp        # 68800 <fwp_cur>
    97be:	48 85 ed             	test   %rbp,%rbp
    97c1:	0f 84 5f 01 00 00    	je     9926 <fwp_main_thread+0x2e6>
    97c7:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    97cc:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    97d0:	48 89 eb             	mov    %rbp,%rbx
    97d3:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    97d8:	0f 84 41 01 00 00    	je     991f <fwp_main_thread+0x2df>
    97de:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    97e3:	0f 84 b7 04 00 00    	je     9ca0 <fwp_main_thread+0x660>
    97e9:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    97ed:	0f 84 8d 04 00 00    	je     9c80 <fwp_main_thread+0x640>
    97f3:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    97f7:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    97fb:	0f 85 1f 05 00 00    	jne    9d20 <fwp_main_thread+0x6e0>
    9801:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9805:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    980c:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9810:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9817:	00 00 00 00 
    981b:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9822:	48 85 d2             	test   %rdx,%rdx
    9825:	74 07                	je     982e <fwp_main_thread+0x1ee>
    9827:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    982e:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9832:	48 85 c0             	test   %rax,%rax
    9835:	74 34                	je     986b <fwp_main_thread+0x22b>
    9837:	48 89 43 68          	mov    %rax,0x68(%rbx)
    983b:	48 8b 05 96 ef 05 00 	mov    0x5ef96(%rip),%rax        # 687d8 <fwp_timers>
    9842:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9846:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    984d:	00 00 00 00 
    9851:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9858:	48 85 c0             	test   %rax,%rax
    985b:	74 07                	je     9864 <fwp_main_thread+0x224>
    985d:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9864:	48 89 1d 6d ef 05 00 	mov    %rbx,0x5ef6d(%rip)        # 687d8 <fwp_timers>
    986b:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    986f:	e8 fc dd ff ff       	call   7670 <fwp_block>
    9874:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    987b:	48 85 c9             	test   %rcx,%rcx
    987e:	74 47                	je     98c7 <fwp_main_thread+0x287>
    9880:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9887:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    988e:	48 85 d2             	test   %rdx,%rdx
    9891:	0f 84 c9 04 00 00    	je     9d60 <fwp_main_thread+0x720>
    9897:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    989e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    98a5:	48 85 c0             	test   %rax,%rax
    98a8:	74 07                	je     98b1 <fwp_main_thread+0x271>
    98aa:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    98b1:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    98b8:	00 00 00 00 
    98bc:	66 0f ef ff          	pxor   %xmm7,%xmm7
    98c0:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    98c7:	48 8b 0d 32 ef 05 00 	mov    0x5ef32(%rip),%rcx        # 68800 <fwp_cur>
    98ce:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    98d2:	0f 84 38 04 00 00    	je     9d10 <fwp_main_thread+0x6d0>
    98d8:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    98df:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    98e6:	48 85 d2             	test   %rdx,%rdx
    98e9:	0f 84 81 04 00 00    	je     9d70 <fwp_main_thread+0x730>
    98ef:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    98f6:	48 85 c0             	test   %rax,%rax
    98f9:	74 07                	je     9902 <fwp_main_thread+0x2c2>
    98fb:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9902:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9906:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    990a:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    9911:	48 89 cb             	mov    %rcx,%rbx
    9914:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9919:	0f 85 bf fe ff ff    	jne    97de <fwp_main_thread+0x19e>
    991f:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9923:	48 89 dd             	mov    %rbx,%rbp
    9926:	48 83 3d 6a 0b 06 00 	cmpq   $0x0,0x60b6a(%rip)        # 6a498 <fwp_state_len>
    992d:	00 
    992e:	0f 84 dc 02 00 00    	je     9c10 <fwp_main_thread+0x5d0>
    9934:	48 8b 15 bd ee 05 00 	mov    0x5eebd(%rip),%rdx        # 687f8 <fwp_root>
    993b:	c7 05 3b 67 01 00 00 	movl   $0x0,0x1673b(%rip)        # 20080 <fwp_exit_code>
    9942:	00 00 00 
    9945:	48 39 d5             	cmp    %rdx,%rbp
    9948:	0f 85 86 20 00 00    	jne    b9d4 <fwp_main_thread+0x2394>
    994e:	48 85 d2             	test   %rdx,%rdx
    9951:	0f 84 99 00 00 00    	je     99f0 <fwp_main_thread+0x3b0>
    9957:	48 8b 0d 6a ee 05 00 	mov    0x5ee6a(%rip),%rcx        # 687c8 <fwp_tasks_active>
    995e:	c6 42 52 01          	movb   $0x1,0x52(%rdx)
    9962:	48 85 c9             	test   %rcx,%rcx
    9965:	0f 84 85 00 00 00    	je     99f0 <fwp_main_thread+0x3b0>
    996b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9970:	80 79 50 00          	cmpb   $0x0,0x50(%rcx)
    9974:	75 08                	jne    997e <fwp_main_thread+0x33e>
    9976:	48 89 cf             	mov    %rcx,%rdi
    9979:	e8 b2 a7 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    997e:	48 8b 89 38 01 00 00 	mov    0x138(%rcx),%rcx
    9985:	48 85 c9             	test   %rcx,%rcx
    9988:	75 e6                	jne    9970 <fwp_main_thread+0x330>
    998a:	eb 2d                	jmp    99b9 <fwp_main_thread+0x379>
    998c:	0f 1f 40 00          	nopl   0x0(%rax)
    9990:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    9997:	48 89 15 42 ee 05 00 	mov    %rdx,0x5ee42(%rip)        # 687e0 <fwp_ready_tail>
    999e:	e8 cd dc ff ff       	call   7670 <fwp_block>
    99a3:	e8 b8 da ff ff       	call   7460 <fwp_free_zombie>
    99a8:	48 83 3d 18 ee 05 00 	cmpq   $0x0,0x5ee18(%rip)        # 687c8 <fwp_tasks_active>
    99af:	00 
    99b0:	74 3e                	je     99f0 <fwp_main_thread+0x3b0>
    99b2:	48 8b 15 3f ee 05 00 	mov    0x5ee3f(%rip),%rdx        # 687f8 <fwp_root>
    99b9:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    99bd:	75 df                	jne    999e <fwp_main_thread+0x35e>
    99bf:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    99c3:	75 d9                	jne    999e <fwp_main_thread+0x35e>
    99c5:	48 8b 05 14 ee 05 00 	mov    0x5ee14(%rip),%rax        # 687e0 <fwp_ready_tail>
    99cc:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    99d0:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    99d7:	00 00 00 00 
    99db:	48 85 c0             	test   %rax,%rax
    99de:	75 b0                	jne    9990 <fwp_main_thread+0x350>
    99e0:	48 89 15 01 ee 05 00 	mov    %rdx,0x5ee01(%rip)        # 687e8 <fwp_ready_head>
    99e7:	eb ae                	jmp    9997 <fwp_main_thread+0x357>
    99e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    99f0:	e8 6b da ff ff       	call   7460 <fwp_free_zombie>
    99f5:	48 83 3d eb ed 05 00 	cmpq   $0x0,0x5edeb(%rip)        # 687e8 <fwp_ready_head>
    99fc:	00 
    99fd:	0f 85 48 9d ff ff    	jne    374b <fwp_main_thread.cold>
    9a03:	48 83 3d cd ed 05 00 	cmpq   $0x0,0x5edcd(%rip)        # 687d8 <fwp_timers>
    9a0a:	00 
    9a0b:	0f 85 3a 9d ff ff    	jne    374b <fwp_main_thread.cold>
    9a11:	8b 05 bd e7 05 00    	mov    0x5e7bd(%rip),%eax        # 681d4 <fwp_stack_pool_n>
    9a17:	85 c0                	test   %eax,%eax
    9a19:	74 42                	je     9a5d <fwp_main_thread+0x41d>
    9a1b:	83 e8 01             	sub    $0x1,%eax
    9a1e:	4c 8d 25 bb e7 05 00 	lea    0x5e7bb(%rip),%r12        # 681e0 <fwp_stack_pool>
    9a25:	48 63 d8             	movslq %eax,%rbx
    9a28:	89 c0                	mov    %eax,%eax
    9a2a:	48 89 da             	mov    %rbx,%rdx
    9a2d:	48 29 c2             	sub    %rax,%rdx
    9a30:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9a34:	90                   	nop
    9a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9a3c:	00 00 00 00 
    9a40:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9a44:	89 1d 8a e7 05 00    	mov    %ebx,0x5e78a(%rip)        # 681d4 <fwp_stack_pool_n>
    9a4a:	be 00 00 00 10       	mov    $0x10000000,%esi
    9a4f:	48 83 eb 01          	sub    $0x1,%rbx
    9a53:	e8 68 9b ff ff       	call   35c0 <munmap@plt>
    9a58:	48 39 eb             	cmp    %rbp,%rbx
    9a5b:	75 e3                	jne    9a40 <fwp_main_thread+0x400>
    9a5d:	8b 3d b5 65 00 00    	mov    0x65b5(%rip),%edi        # 10018 <fwp_epfd>
    9a63:	85 ff                	test   %edi,%edi
    9a65:	78 05                	js     9a6c <fwp_main_thread+0x42c>
    9a67:	e8 54 9a ff ff       	call   34c0 <close@plt>
    9a6c:	4c 8b 25 6d e9 05 00 	mov    0x5e96d(%rip),%r12        # 683e0 <fwp_nfdws>
    9a73:	48 8b 2d 6e e9 05 00 	mov    0x5e96e(%rip),%rbp        # 683e8 <fwp_fdws>
    9a7a:	31 db                	xor    %ebx,%ebx
    9a7c:	c7 05 92 65 00 00 ff 	movl   $0xffffffff,0x6592(%rip)        # 10018 <fwp_epfd>
    9a83:	ff ff ff 
    9a86:	4d 85 e4             	test   %r12,%r12
    9a89:	74 32                	je     9abd <fwp_main_thread+0x47d>
    9a8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9a90:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9a95:	48 85 ff             	test   %rdi,%rdi
    9a98:	74 1a                	je     9ab4 <fwp_main_thread+0x474>
    9a9a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9a9e:	0f 85 a7 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9aa4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9aa9:	0f 85 9c 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9aaf:	e8 5c bf ff ff       	call   5a10 <fwp_mem_free>
    9ab4:	48 83 c3 01          	add    $0x1,%rbx
    9ab8:	4c 39 e3             	cmp    %r12,%rbx
    9abb:	75 d3                	jne    9a90 <fwp_main_thread+0x450>
    9abd:	48 89 ef             	mov    %rbp,%rdi
    9ac0:	e8 4b bf ff ff       	call   5a10 <fwp_mem_free>
    9ac5:	48 8b 15 2c ed 05 00 	mov    0x5ed2c(%rip),%rdx        # 687f8 <fwp_root>
    9acc:	48 c7 05 11 e9 05 00 	movq   $0x0,0x5e911(%rip)        # 683e8 <fwp_fdws>
    9ad3:	00 00 00 00 
    9ad7:	48 c7 05 fe e8 05 00 	movq   $0x0,0x5e8fe(%rip)        # 683e0 <fwp_nfdws>
    9ade:	00 00 00 00 
    9ae2:	48 85 d2             	test   %rdx,%rdx
    9ae5:	74 4e                	je     9b35 <fwp_main_thread+0x4f5>
    9ae7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9aec:	0f 85 59 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9af2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9af9:	00 
    9afa:	0f 85 4b 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9b00:	48 83 3d 90 09 06 00 	cmpq   $0x0,0x60990(%rip)        # 6a498 <fwp_state_len>
    9b07:	00 
    9b08:	0f 85 3d 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9b0e:	48 83 3d 72 09 06 00 	cmpq   $0x0,0x60972(%rip)        # 6a488 <fwp_state_owners>
    9b15:	00 
    9b16:	0f 85 2f 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9b1c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9b21:	31 c0                	xor    %eax,%eax
    9b23:	48 8d 3d d6 e8 05 00 	lea    0x5e8d6(%rip),%rdi        # 68400 <fwp_root_context>
    9b2a:	f3 48 ab             	rep stos %rax,(%rdi)
    9b2d:	48 89 d7             	mov    %rdx,%rdi
    9b30:	e8 db be ff ff       	call   5a10 <fwp_mem_free>
    9b35:	66 0f 6f 05 73 66 04 	movdqa 0x46673(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    9b3c:	00 
    9b3d:	66 0f d4 05 5b 66 04 	paddq  0x4665b(%rip),%xmm0        # 501a0 <ad_raw_live>
    9b44:	00 
    9b45:	48 c7 05 b0 ec 05 00 	movq   $0x0,0x5ecb0(%rip)        # 68800 <fwp_cur>
    9b4c:	00 00 00 00 
    9b50:	48 8b 05 e9 00 06 00 	mov    0x600e9(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    9b57:	48 c7 05 96 ec 05 00 	movq   $0x0,0x5ec96(%rip)        # 687f8 <fwp_root>
    9b5e:	00 00 00 00 
    9b62:	c7 05 7c 09 06 00 00 	movl   $0x0,0x6097c(%rip)        # 6a4e8 <iteration_active>
    9b69:	00 00 00 
    9b6c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    9b70:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    9b75:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    9b79:	66 0f d6 05 77 65 01 	movq   %xmm0,0x16577(%rip)        # 200f8 <ad_raw_before_shutdown>
    9b80:	00 
    9b81:	48 85 c0             	test   %rax,%rax
    9b84:	0f 88 16 02 00 00    	js     9da0 <fwp_main_thread+0x760>
    9b8a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9b8e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    9b93:	f2 0f 5c 0d 2d 09 06 	subsd  0x6092d(%rip),%xmm1        # 6a4c8 <iteration_start_charge>
    9b9a:	00 
    9b9b:	48 8b 3d 9e 64 00 00 	mov    0x649e(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    9ba2:	48 8d 15 97 2f 00 00 	lea    0x2f97(%rip),%rdx        # cb40 <_IO_stdin_used+0xb40>
    9ba9:	be 02 00 00 00       	mov    $0x2,%esi
    9bae:	f2 0f 10 05 0a 09 06 	movsd  0x6090a(%rip),%xmm0        # 6a4c0 <iteration_peak>
    9bb5:	00 
    9bb6:	4c 8b 0d 13 09 06 00 	mov    0x60913(%rip),%r9        # 6a4d0 <iteration_retains>
    9bbd:	b8 02 00 00 00       	mov    $0x2,%eax
    9bc2:	4c 8b 05 0f 09 06 00 	mov    0x6090f(%rip),%r8        # 6a4d8 <iteration_bytes>
    9bc9:	48 8b 0d 10 09 06 00 	mov    0x60910(%rip),%rcx        # 6a4e0 <iteration_requests>
    9bd0:	e8 9b 9a ff ff       	call   3670 <__fprintf_chk@plt>
    9bd5:	48 8b 3d 44 64 00 00 	mov    0x6444(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    9bdc:	e8 bf 99 ff ff       	call   35a0 <fflush@plt>
    9be1:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
    9be8:	00 
    9be9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9bf0:	00 00 
    9bf2:	0f 85 89 1d 00 00    	jne    b981 <fwp_main_thread+0x2341>
    9bf8:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    9bff:	31 c0                	xor    %eax,%eax
    9c01:	5b                   	pop    %rbx
    9c02:	5d                   	pop    %rbp
    9c03:	41 5c                	pop    %r12
    9c05:	41 5d                	pop    %r13
    9c07:	41 5e                	pop    %r14
    9c09:	41 5f                	pop    %r15
    9c0b:	c3                   	ret
    9c0c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c10:	48 83 3d 70 08 06 00 	cmpq   $0x0,0x60870(%rip)        # 6a488 <fwp_state_owners>
    9c17:	00 
    9c18:	0f 85 16 fd ff ff    	jne    9934 <fwp_main_thread+0x2f4>
    9c1e:	48 8b 3d 7b 08 06 00 	mov    0x6087b(%rip),%rdi        # 6a4a0 <fwp_state>
    9c25:	e8 e6 bd ff ff       	call   5a10 <fwp_mem_free>
    9c2a:	48 c7 05 6b 08 06 00 	movq   $0x0,0x6086b(%rip)        # 6a4a0 <fwp_state>
    9c31:	00 00 00 00 
    9c35:	48 c7 05 50 08 06 00 	movq   $0x0,0x60850(%rip)        # 6a490 <fwp_state_cap>
    9c3c:	00 00 00 00 
    9c40:	48 85 ed             	test   %rbp,%rbp
    9c43:	0f 84 eb fc ff ff    	je     9934 <fwp_main_thread+0x2f4>
    9c49:	48 8b 15 a8 eb 05 00 	mov    0x5eba8(%rip),%rdx        # 687f8 <fwp_root>
    9c50:	48 c7 85 a8 00 00 00 	movq   $0x0,0xa8(%rbp)
    9c57:	00 00 00 00 
    9c5b:	48 c7 85 b8 00 00 00 	movq   $0x0,0xb8(%rbp)
    9c62:	00 00 00 00 
    9c66:	c7 05 10 64 01 00 00 	movl   $0x0,0x16410(%rip)        # 20080 <fwp_exit_code>
    9c6d:	00 00 00 
    9c70:	48 39 d5             	cmp    %rdx,%rbp
    9c73:	0f 84 de fc ff ff    	je     9957 <fwp_main_thread+0x317>
    9c79:	e9 cd 9a ff ff       	jmp    374b <fwp_main_thread.cold>
    9c7e:	66 90                	xchg   %ax,%ax
    9c80:	e8 3b a9 ff ff       	call   45c0 <fwp_now_ns>
    9c85:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9c89:	7c 15                	jl     9ca0 <fwp_main_thread+0x660>
    9c8b:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9c8f:	75 0f                	jne    9ca0 <fwp_main_thread+0x660>
    9c91:	48 89 ef             	mov    %rbp,%rdi
    9c94:	e8 97 a4 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    9c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9ca0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9ca4:	0f 85 49 fb ff ff    	jne    97f3 <fwp_main_thread+0x1b3>
    9caa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9cae:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9cb2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9cb6:	0f 85 49 fb ff ff    	jne    9805 <fwp_main_thread+0x1c5>
    9cbc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9cc0:	48 85 c9             	test   %rcx,%rcx
    9cc3:	0f 84 3c fb ff ff    	je     9805 <fwp_main_thread+0x1c5>
    9cc9:	48 39 c8             	cmp    %rcx,%rax
    9ccc:	48 89 ce             	mov    %rcx,%rsi
    9ccf:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9cd6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9cda:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9ce1:	00 00 00 00 
    9ce5:	48 0f 4e f0          	cmovle %rax,%rsi
    9ce9:	48 85 c0             	test   %rax,%rax
    9cec:	48 89 c8             	mov    %rcx,%rax
    9cef:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9cf6:	48 0f 45 c6          	cmovne %rsi,%rax
    9cfa:	48 85 d2             	test   %rdx,%rdx
    9cfd:	74 07                	je     9d06 <fwp_main_thread+0x6c6>
    9cff:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9d06:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9d0a:	e9 28 fb ff ff       	jmp    9837 <fwp_main_thread+0x1f7>
    9d0f:	90                   	nop
    9d10:	48 89 cb             	mov    %rcx,%rbx
    9d13:	e9 bb fa ff ff       	jmp    97d3 <fwp_main_thread+0x193>
    9d18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d1f:	00 
    9d20:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9d24:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9d2b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9d32:	00 00 00 00 
    9d36:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9d3d:	48 85 c0             	test   %rax,%rax
    9d40:	0f 84 4b 19 00 00    	je     b691 <fwp_main_thread+0x2051>
    9d46:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9d4d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9d51:	e9 15 fb ff ff       	jmp    986b <fwp_main_thread+0x22b>
    9d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9d5d:	00 00 00 
    9d60:	48 89 01             	mov    %rax,(%rcx)
    9d63:	e9 3d fb ff ff       	jmp    98a5 <fwp_main_thread+0x265>
    9d68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d6f:	00 
    9d70:	48 89 05 61 ea 05 00 	mov    %rax,0x5ea61(%rip)        # 687d8 <fwp_timers>
    9d77:	e9 7a fb ff ff       	jmp    98f6 <fwp_main_thread+0x2b6>
    9d7c:	0f 1f 40 00          	nopl   0x0(%rax)
    9d80:	48 89 c2             	mov    %rax,%rdx
    9d83:	83 e0 01             	and    $0x1,%eax
    9d86:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9d8a:	48 d1 ea             	shr    $1,%rdx
    9d8d:	48 09 c2             	or     %rax,%rdx
    9d90:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    9d95:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    9d99:	e9 e3 f9 ff ff       	jmp    9781 <fwp_main_thread+0x141>
    9d9e:	66 90                	xchg   %ax,%ax
    9da0:	48 89 c2             	mov    %rax,%rdx
    9da3:	83 e0 01             	and    $0x1,%eax
    9da6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9daa:	48 d1 ea             	shr    $1,%rdx
    9dad:	48 09 c2             	or     %rax,%rdx
    9db0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    9db5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    9db9:	e9 d5 fd ff ff       	jmp    9b93 <fwp_main_thread+0x553>
    9dbe:	48 8d 05 0b df ff ff 	lea    -0x20f5(%rip),%rax        # 7cd0 <fwp_drop1>
    9dc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9dc9:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    9dce:	45 31 f6             	xor    %r14d,%r14d
    9dd1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    9dd6:	48 8b 05 db 06 06 00 	mov    0x606db(%rip),%rax        # 6a4b8 <fwp_cleanups>
    9ddd:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    9de4:	00 00 00 00 00 
    9de9:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    9dee:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9df2:	48 8d 2d 27 ea 05 00 	lea    0x5ea27(%rip),%rbp        # 68820 <fwp_heap>
    9df9:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9e00:	00 
    9e01:	48 8d 05 c8 9d ff ff 	lea    -0x6238(%rip),%rax        # 3bd0 <fwp_range_release>
    9e08:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    9e0f:	00 
    9e10:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9e15:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9e1c:	00 
    9e1d:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9e24:	00 
    9e25:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    9e2a:	48 89 05 87 06 06 00 	mov    %rax,0x60687(%rip)        # 6a4b8 <fwp_cleanups>
    9e31:	eb 45                	jmp    9e78 <fwp_main_thread+0x838>
    9e33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9e38:	80 f9 01             	cmp    $0x1,%cl
    9e3b:	75 29                	jne    9e66 <fwp_main_thread+0x826>
    9e3d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e40:	0f b7 c0             	movzwl %ax,%eax
    9e43:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e46:	48 0f af c1          	imul   %rcx,%rax
    9e4a:	48 c1 e8 20          	shr    $0x20,%rax
    9e4e:	48 39 d0             	cmp    %rdx,%rax
    9e51:	73 13                	jae    9e66 <fwp_main_thread+0x826>
    9e53:	49 01 c5             	add    %rax,%r13
    9e56:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9e5b:	0f 84 d9 18 00 00    	je     b73a <fwp_main_thread+0x20fa>
    9e61:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9e66:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    9e6d:	00 
    9e6e:	48 83 eb 01          	sub    $0x1,%rbx
    9e72:	0f 82 85 00 00 00    	jb     9efd <fwp_main_thread+0x8bd>
    9e78:	4c 89 e6             	mov    %r12,%rsi
    9e7b:	bf 01 00 00 00       	mov    $0x1,%edi
    9e80:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
    9e87:	00 
    9e88:	48 89 9c 24 d8 00 00 	mov    %rbx,0xd8(%rsp)
    9e8f:	00 
    9e90:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
    9e97:	00 
    9e98:	e8 63 c2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    9e9d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9ea4:	49 89 c6             	mov    %rax,%r14
    9ea7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9eae:	48 c1 e2 10          	shl    $0x10,%rdx
    9eb2:	48 39 d0             	cmp    %rdx,%rax
    9eb5:	73 af                	jae    9e66 <fwp_main_thread+0x826>
    9eb7:	48 89 c2             	mov    %rax,%rdx
    9eba:	48 c1 ea 10          	shr    $0x10,%rdx
    9ebe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ec2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9ec9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ecd:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9ed1:	4d 85 ed             	test   %r13,%r13
    9ed4:	74 90                	je     9e66 <fwp_main_thread+0x826>
    9ed6:	0f b6 0a             	movzbl (%rdx),%ecx
    9ed9:	80 f9 02             	cmp    $0x2,%cl
    9edc:	0f 85 56 ff ff ff    	jne    9e38 <fwp_main_thread+0x7f8>
    9ee2:	66 85 c0             	test   %ax,%ax
    9ee5:	0f 84 6b ff ff ff    	je     9e56 <fwp_main_thread+0x816>
    9eeb:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    9ef2:	00 
    9ef3:	48 83 eb 01          	sub    $0x1,%rbx
    9ef7:	0f 83 7b ff ff ff    	jae    9e78 <fwp_main_thread+0x838>
    9efd:	48 8b 9c 24 b0 00 00 	mov    0xb0(%rsp),%rbx
    9f04:	00 
    9f05:	66 0f 6f 05 03 2f 00 	movdqa 0x2f03(%rip),%xmm0        # ce10 <msg.4+0xd0>
    9f0c:	00 
    9f0d:	bf 01 00 00 00       	mov    $0x1,%edi
    9f12:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    9f19:	00 
    9f1a:	48 89 1d 97 05 06 00 	mov    %rbx,0x60597(%rip)        # 6a4b8 <fwp_cleanups>
    9f21:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
    9f28:	00 
    9f29:	e8 d2 c1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    9f2e:	48 8b 15 c3 fc 05 00 	mov    0x5fcc3(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9f35:	49 89 c5             	mov    %rax,%r13
    9f38:	48 2b 05 91 fc 05 00 	sub    0x5fc91(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9f3f:	48 c1 e2 10          	shl    $0x10,%rdx
    9f43:	48 39 d0             	cmp    %rdx,%rax
    9f46:	73 59                	jae    9fa1 <fwp_main_thread+0x961>
    9f48:	48 89 c2             	mov    %rax,%rdx
    9f4b:	48 c1 ea 10          	shr    $0x10,%rdx
    9f4f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f53:	48 8b 15 be fc 05 00 	mov    0x5fcbe(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9f5a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f5e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9f62:	4d 85 e4             	test   %r12,%r12
    9f65:	74 3a                	je     9fa1 <fwp_main_thread+0x961>
    9f67:	0f b6 0a             	movzbl (%rdx),%ecx
    9f6a:	80 f9 02             	cmp    $0x2,%cl
    9f6d:	0f 84 9b 17 00 00    	je     b70e <fwp_main_thread+0x20ce>
    9f73:	80 f9 01             	cmp    $0x1,%cl
    9f76:	75 29                	jne    9fa1 <fwp_main_thread+0x961>
    9f78:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f7b:	0f b7 c0             	movzwl %ax,%eax
    9f7e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f81:	48 0f af c1          	imul   %rcx,%rax
    9f85:	48 c1 e8 20          	shr    $0x20,%rax
    9f89:	48 39 d0             	cmp    %rdx,%rax
    9f8c:	73 13                	jae    9fa1 <fwp_main_thread+0x961>
    9f8e:	49 01 c4             	add    %rax,%r12
    9f91:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9f96:	0f 84 43 19 00 00    	je     b8df <fwp_main_thread+0x229f>
    9f9c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9fa1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9fa8:	00 f0 3f 
    9fab:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    9fb2:	00 
    9fb3:	bf 01 00 00 00       	mov    $0x1,%edi
    9fb8:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
    9fbf:	00 
    9fc0:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    9fc7:	00 
    9fc8:	e8 33 c1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    9fcd:	48 8b 15 24 fc 05 00 	mov    0x5fc24(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9fd4:	49 89 c5             	mov    %rax,%r13
    9fd7:	48 2b 05 f2 fb 05 00 	sub    0x5fbf2(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9fde:	48 c1 e2 10          	shl    $0x10,%rdx
    9fe2:	48 39 d0             	cmp    %rdx,%rax
    9fe5:	73 59                	jae    a040 <fwp_main_thread+0xa00>
    9fe7:	48 89 c2             	mov    %rax,%rdx
    9fea:	48 c1 ea 10          	shr    $0x10,%rdx
    9fee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ff2:	48 8b 15 1f fc 05 00 	mov    0x5fc1f(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9ff9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ffd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a001:	4d 85 e4             	test   %r12,%r12
    a004:	74 3a                	je     a040 <fwp_main_thread+0xa00>
    a006:	0f b6 0a             	movzbl (%rdx),%ecx
    a009:	80 f9 02             	cmp    $0x2,%cl
    a00c:	0f 84 0a 17 00 00    	je     b71c <fwp_main_thread+0x20dc>
    a012:	80 f9 01             	cmp    $0x1,%cl
    a015:	75 29                	jne    a040 <fwp_main_thread+0xa00>
    a017:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a01a:	0f b7 c0             	movzwl %ax,%eax
    a01d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a020:	48 0f af c1          	imul   %rcx,%rax
    a024:	48 c1 e8 20          	shr    $0x20,%rax
    a028:	48 39 d0             	cmp    %rdx,%rax
    a02b:	73 13                	jae    a040 <fwp_main_thread+0xa00>
    a02d:	49 01 c4             	add    %rax,%r12
    a030:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a035:	0f 84 b1 18 00 00    	je     b8ec <fwp_main_thread+0x22ac>
    a03b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a040:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a047:	33 f3 bf 
    a04a:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    a051:	00 
    a052:	bf 01 00 00 00       	mov    $0x1,%edi
    a057:	4c 89 ac 24 18 01 00 	mov    %r13,0x118(%rsp)
    a05e:	00 
    a05f:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
    a066:	00 
    a067:	e8 94 c0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a06c:	48 8b 15 85 fb 05 00 	mov    0x5fb85(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    a073:	48 8b 0d 56 fb 05 00 	mov    0x5fb56(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    a07a:	48 89 04 24          	mov    %rax,(%rsp)
    a07e:	48 89 d6             	mov    %rdx,%rsi
    a081:	48 29 c8             	sub    %rcx,%rax
    a084:	48 c1 e6 10          	shl    $0x10,%rsi
    a088:	48 39 f0             	cmp    %rsi,%rax
    a08b:	73 69                	jae    a0f6 <fwp_main_thread+0xab6>
    a08d:	48 89 c6             	mov    %rax,%rsi
    a090:	48 c1 ee 10          	shr    $0x10,%rsi
    a094:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a098:	48 8b 35 79 fb 05 00 	mov    0x5fb79(%rip),%rsi        # 69c18 <fwp_heap+0x13f8>
    a09f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a0a3:	4c 8b 66 20          	mov    0x20(%rsi),%r12
    a0a7:	4d 85 e4             	test   %r12,%r12
    a0aa:	74 4a                	je     a0f6 <fwp_main_thread+0xab6>
    a0ac:	0f b6 3e             	movzbl (%rsi),%edi
    a0af:	40 80 ff 02          	cmp    $0x2,%dil
    a0b3:	0f 84 47 16 00 00    	je     b700 <fwp_main_thread+0x20c0>
    a0b9:	40 80 ff 01          	cmp    $0x1,%dil
    a0bd:	75 37                	jne    a0f6 <fwp_main_thread+0xab6>
    a0bf:	8b 7e 18             	mov    0x18(%rsi),%edi
    a0c2:	0f b7 c0             	movzwl %ax,%eax
    a0c5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a0c8:	48 0f af c7          	imul   %rdi,%rax
    a0cc:	48 c1 e8 20          	shr    $0x20,%rax
    a0d0:	48 39 f0             	cmp    %rsi,%rax
    a0d3:	73 21                	jae    a0f6 <fwp_main_thread+0xab6>
    a0d5:	49 01 c4             	add    %rax,%r12
    a0d8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a0dd:	0f 84 ef 17 00 00    	je     b8d2 <fwp_main_thread+0x2292>
    a0e3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a0e8:	48 8b 0d e1 fa 05 00 	mov    0x5fae1(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    a0ef:	48 8b 15 02 fb 05 00 	mov    0x5fb02(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    a0f6:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    a0fd:	00 
    a0fe:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
    a103:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a108:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    a10f:	00 
    a110:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a115:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    a11a:	48 8b 04 24          	mov    (%rsp),%rax
    a11e:	48 c1 e2 10          	shl    $0x10,%rdx
    a122:	48 29 c8             	sub    %rcx,%rax
    a125:	48 39 d0             	cmp    %rdx,%rax
    a128:	0f 83 87 00 00 00    	jae    a1b5 <fwp_main_thread+0xb75>
    a12e:	48 89 c6             	mov    %rax,%rsi
    a131:	48 c1 ee 10          	shr    $0x10,%rsi
    a135:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a139:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a140:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a144:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a148:	48 85 ff             	test   %rdi,%rdi
    a14b:	74 68                	je     a1b5 <fwp_main_thread+0xb75>
    a14d:	44 0f b6 06          	movzbl (%rsi),%r8d
    a151:	41 80 f8 02          	cmp    $0x2,%r8b
    a155:	0f 84 d5 14 00 00    	je     b630 <fwp_main_thread+0x1ff0>
    a15b:	41 80 f8 01          	cmp    $0x1,%r8b
    a15f:	75 54                	jne    a1b5 <fwp_main_thread+0xb75>
    a161:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a165:	0f b7 c0             	movzwl %ax,%eax
    a168:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a16b:	49 0f af c0          	imul   %r8,%rax
    a16f:	48 c1 e8 20          	shr    $0x20,%rax
    a173:	48 39 f0             	cmp    %rsi,%rax
    a176:	73 3d                	jae    a1b5 <fwp_main_thread+0xb75>
    a178:	48 01 c7             	add    %rax,%rdi
    a17b:	0f b6 07             	movzbl (%rdi),%eax
    a17e:	84 c0                	test   %al,%al
    a180:	74 33                	je     a1b5 <fwp_main_thread+0xb75>
    a182:	44 8b 05 5f 03 06 00 	mov    0x6035f(%rip),%r8d        # 6a4e8 <iteration_active>
    a189:	45 85 c0             	test   %r8d,%r8d
    a18c:	74 08                	je     a196 <fwp_main_thread+0xb56>
    a18e:	48 83 05 3a 03 06 00 	addq   $0x1,0x6033a(%rip)        # 6a4d0 <iteration_retains>
    a195:	01 
    a196:	3c fd                	cmp    $0xfd,%al
    a198:	0f 87 af 16 00 00    	ja     b84d <fwp_main_thread+0x220d>
    a19e:	83 c0 01             	add    $0x1,%eax
    a1a1:	88 07                	mov    %al,(%rdi)
    a1a3:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a1aa:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    a1b1:	48 c1 e2 10          	shl    $0x10,%rdx
    a1b5:	48 8d 05 c4 cd ff ff 	lea    -0x323c(%rip),%rax        # 6f80 <fwp_tape_scope_release>
    a1bc:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
    a1c3:	00 
    a1c4:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    a1cb:	00 
    a1cc:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a1d1:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    a1d8:	ff ff ff ff 
    a1dc:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    a1e3:	00 
    a1e4:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a1e9:	48 89 05 c8 02 06 00 	mov    %rax,0x602c8(%rip)        # 6a4b8 <fwp_cleanups>
    a1f0:	48 8d 05 19 5e 00 00 	lea    0x5e19(%rip),%rax        # 10010 <fc37>
    a1f7:	48 29 c8             	sub    %rcx,%rax
    a1fa:	48 39 d0             	cmp    %rdx,%rax
    a1fd:	73 6f                	jae    a26e <fwp_main_thread+0xc2e>
    a1ff:	48 89 c2             	mov    %rax,%rdx
    a202:	48 c1 ea 10          	shr    $0x10,%rdx
    a206:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a20a:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a211:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a215:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a219:	48 85 ff             	test   %rdi,%rdi
    a21c:	74 50                	je     a26e <fwp_main_thread+0xc2e>
    a21e:	0f b6 0a             	movzbl (%rdx),%ecx
    a221:	80 f9 02             	cmp    $0x2,%cl
    a224:	0f 84 06 12 00 00    	je     b430 <fwp_main_thread+0x1df0>
    a22a:	80 f9 01             	cmp    $0x1,%cl
    a22d:	75 3f                	jne    a26e <fwp_main_thread+0xc2e>
    a22f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a232:	0f b7 c0             	movzwl %ax,%eax
    a235:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a238:	48 0f af c1          	imul   %rcx,%rax
    a23c:	48 c1 e8 20          	shr    $0x20,%rax
    a240:	48 39 d0             	cmp    %rdx,%rax
    a243:	73 29                	jae    a26e <fwp_main_thread+0xc2e>
    a245:	48 01 c7             	add    %rax,%rdi
    a248:	0f b6 07             	movzbl (%rdi),%eax
    a24b:	84 c0                	test   %al,%al
    a24d:	74 1f                	je     a26e <fwp_main_thread+0xc2e>
    a24f:	8b 35 93 02 06 00    	mov    0x60293(%rip),%esi        # 6a4e8 <iteration_active>
    a255:	85 f6                	test   %esi,%esi
    a257:	74 08                	je     a261 <fwp_main_thread+0xc21>
    a259:	48 83 05 6f 02 06 00 	addq   $0x1,0x6026f(%rip)        # 6a4d0 <iteration_retains>
    a260:	01 
    a261:	3c fd                	cmp    $0xfd,%al
    a263:	0f 87 9e 15 00 00    	ja     b807 <fwp_main_thread+0x21c7>
    a269:	83 c0 01             	add    $0x1,%eax
    a26c:	88 07                	mov    %al,(%rdi)
    a26e:	48 8d 3d 9b 5d 00 00 	lea    0x5d9b(%rip),%rdi        # 10010 <fc37>
    a275:	31 db                	xor    %ebx,%ebx
    a277:	e8 94 c9 ff ff       	call   6c10 <fwp_closure_drop>
    a27c:	4c 8b 24 24          	mov    (%rsp),%r12
    a280:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    a285:	48 83 c3 01          	add    $0x1,%rbx
    a289:	4d 85 e4             	test   %r12,%r12
    a28c:	75 f2                	jne    a280 <fwp_main_thread+0xc40>
    a28e:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    a295:	0f 87 6f 16 00 00    	ja     b90a <fwp_main_thread+0x22ca>
    a29b:	8b 0d bf 5d 00 00    	mov    0x5dbf(%rip),%ecx        # 10060 <registered_finish.1>
    a2a1:	85 c9                	test   %ecx,%ecx
    a2a3:	0f 84 4f 11 00 00    	je     b3f8 <fwp_main_thread+0x1db8>
    a2a9:	4c 8b 2d 28 5e 01 00 	mov    0x15e28(%rip),%r13        # 200d8 <fwp_tape_next_slot>
    a2b0:	4c 8b 35 31 5e 01 00 	mov    0x15e31(%rip),%r14        # 200e8 <fwp_ntapes>
    a2b7:	4d 39 f5             	cmp    %r14,%r13
    a2ba:	0f 8d 18 0e 00 00    	jge    b0d8 <fwp_main_thread+0x1a98>
    a2c0:	49 6b c5 68          	imul   $0x68,%r13,%rax
    a2c4:	48 03 05 25 5e 01 00 	add    0x15e25(%rip),%rax        # 200f0 <fwp_tapes>
    a2cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a2d0:	8b 50 04             	mov    0x4(%rax),%edx
    a2d3:	85 d2                	test   %edx,%edx
    a2d5:	75 0c                	jne    a2e3 <fwp_main_thread+0xca3>
    a2d7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    a2dd:	0f 86 f5 0d 00 00    	jbe    b0d8 <fwp_main_thread+0x1a98>
    a2e3:	49 83 c5 01          	add    $0x1,%r13
    a2e7:	48 83 c0 68          	add    $0x68,%rax
    a2eb:	4d 39 f5             	cmp    %r14,%r13
    a2ee:	75 e0                	jne    a2d0 <fwp_main_thread+0xc90>
    a2f0:	49 81 fe fe ff 00 00 	cmp    $0xfffe,%r14
    a2f7:	0f 8f 89 16 00 00    	jg     b986 <fwp_main_thread+0x2346>
    a2fd:	4c 39 35 dc 5d 01 00 	cmp    %r14,0x15ddc(%rip)        # 200e0 <fwp_tapes_cap>
    a304:	4c 8b 3d e5 5d 01 00 	mov    0x15de5(%rip),%r15        # 200f0 <fwp_tapes>
    a30b:	75 4b                	jne    a358 <fwp_main_thread+0xd18>
    a30d:	4d 85 f6             	test   %r14,%r14
    a310:	0f 84 84 13 00 00    	je     b69a <fwp_main_thread+0x205a>
    a316:	4b 8d 0c 36          	lea    (%r14,%r14,1),%rcx
    a31a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    a31f:	48 39 c1             	cmp    %rax,%rcx
    a322:	48 0f 4f c8          	cmovg  %rax,%rcx
    a326:	48 6b f1 68          	imul   $0x68,%rcx,%rsi
    a32a:	31 d2                	xor    %edx,%edx
    a32c:	4c 89 ff             	mov    %r15,%rdi
    a32f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a334:	e8 57 ae ff ff       	call   5190 <ad_raw_realloc>
    a339:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a33e:	48 85 c0             	test   %rax,%rax
    a341:	49 89 c7             	mov    %rax,%r15
    a344:	0f 84 fd 15 00 00    	je     b947 <fwp_main_thread+0x2307>
    a34a:	48 89 05 9f 5d 01 00 	mov    %rax,0x15d9f(%rip)        # 200f0 <fwp_tapes>
    a351:	48 89 0d 88 5d 01 00 	mov    %rcx,0x15d88(%rip)        # 200e0 <fwp_tapes_cap>
    a358:	49 6b c6 68          	imul   $0x68,%r14,%rax
    a35c:	49 83 c6 01          	add    $0x1,%r14
    a360:	4c 01 f8             	add    %r15,%rax
    a363:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a367:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a36e:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    a372:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    a379:	00 
    a37a:	48 29 f8             	sub    %rdi,%rax
    a37d:	8d 48 68             	lea    0x68(%rax),%ecx
    a380:	31 c0                	xor    %eax,%eax
    a382:	c1 e9 03             	shr    $0x3,%ecx
    a385:	f3 48 ab             	rep stos %rax,(%rdi)
    a388:	4c 89 35 59 5d 01 00 	mov    %r14,0x15d59(%rip)        # 200e8 <fwp_ntapes>
    a38f:	4d 6b f5 68          	imul   $0x68,%r13,%r14
    a393:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    a398:	48 8d 3d c1 1d 00 00 	lea    0x1dc1(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    a39f:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    a3a3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    a3a8:	4d 01 fe             	add    %r15,%r14
    a3ab:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    a3b2:	00 
    a3b3:	e8 d8 8f ff ff       	call   3390 <getenv@plt>
    a3b8:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    a3be:	48 85 c0             	test   %rax,%rax
    a3c1:	0f 84 29 0d 00 00    	je     b0f0 <fwp_main_thread+0x1ab0>
    a3c7:	80 38 30             	cmpb   $0x30,(%rax)
    a3ca:	0f 85 20 0d 00 00    	jne    b0f0 <fwp_main_thread+0x1ab0>
    a3d0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    a3d4:	0f 85 16 0d 00 00    	jne    b0f0 <fwp_main_thread+0x1ab0>
    a3da:	41 8b 06             	mov    (%r14),%eax
    a3dd:	49 8d 5d 01          	lea    0x1(%r13),%rbx
    a3e1:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    a3e8:	00 
    a3e9:	48 89 1d e8 5c 01 00 	mov    %rbx,0x15ce8(%rip)        # 200d8 <fwp_tape_next_slot>
    a3f0:	8d 50 01             	lea    0x1(%rax),%edx
    a3f3:	48 8b 05 66 29 00 00 	mov    0x2966(%rip),%rax        # cd60 <msg.4+0x20>
    a3fa:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    a3ff:	41 89 16             	mov    %edx,(%r14)
    a402:	49 89 46 58          	mov    %rax,0x58(%r14)
    a406:	48 8b 05 ab 00 06 00 	mov    0x600ab(%rip),%rax        # 6a4b8 <fwp_cleanups>
    a40d:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    a414:	00 
    a415:	48 85 c0             	test   %rax,%rax
    a418:	75 12                	jne    a42c <fwp_main_thread+0xdec>
    a41a:	e9 79 15 00 00       	jmp    b998 <fwp_main_thread+0x2358>
    a41f:	90                   	nop
    a420:	48 8b 00             	mov    (%rax),%rax
    a423:	48 85 c0             	test   %rax,%rax
    a426:	0f 84 6c 15 00 00    	je     b998 <fwp_main_thread+0x2358>
    a42c:	48 8d 3d 4d cb ff ff 	lea    -0x34b3(%rip),%rdi        # 6f80 <fwp_tape_scope_release>
    a433:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    a437:	75 e7                	jne    a420 <fwp_main_thread+0xde0>
    a439:	48 8b 70 10          	mov    0x10(%rax),%rsi
    a43d:	44 89 e9             	mov    %r13d,%ecx
    a440:	48 63 06             	movslq (%rsi),%rax
    a443:	49 89 76 50          	mov    %rsi,0x50(%r14)
    a447:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    a44b:	85 c0                	test   %eax,%eax
    a44d:	78 09                	js     a458 <fwp_main_thread+0xe18>
    a44f:	48 6b c0 68          	imul   $0x68,%rax,%rax
    a453:	45 89 6c 07 58       	mov    %r13d,0x58(%r15,%rax,1)
    a458:	89 0e                	mov    %ecx,(%rsi)
    a45a:	48 8b 04 24          	mov    (%rsp),%rax
    a45e:	66 90                	xchg   %ax,%ax
    a460:	48 8b 40 10          	mov    0x10(%rax),%rax
    a464:	49 83 c4 01          	add    $0x1,%r12
    a468:	48 85 c0             	test   %rax,%rax
    a46b:	75 f3                	jne    a460 <fwp_main_thread+0xe20>
    a46d:	4c 8b 3c 24          	mov    (%rsp),%r15
    a471:	0f 1f 40 00          	nopl   0x0(%rax)
    a475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a47c:	00 00 00 00 
    a480:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    a484:	48 83 c0 01          	add    $0x1,%rax
    a488:	4d 85 ff             	test   %r15,%r15
    a48b:	75 f3                	jne    a480 <fwp_main_thread+0xe40>
    a48d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    a494:	ff ff 1f 
    a497:	48 39 c1             	cmp    %rax,%rcx
    a49a:	0f 82 76 14 00 00    	jb     b916 <fwp_main_thread+0x22d6>
    a4a0:	4d 85 e4             	test   %r12,%r12
    a4a3:	0f 8e c7 0d 00 00    	jle    b270 <fwp_main_thread+0x1c30>
    a4a9:	49 39 c4             	cmp    %rax,%r12
    a4ac:	4c 0f 47 e0          	cmova  %rax,%r12
    a4b0:	4c 89 e0             	mov    %r12,%rax
    a4b3:	48 c1 e8 3c          	shr    $0x3c,%rax
    a4b7:	0f 85 59 14 00 00    	jne    b916 <fwp_main_thread+0x22d6>
    a4bd:	4f 8d 2c 24          	lea    (%r12,%r12,1),%r13
    a4c1:	48 c1 e2 10          	shl    $0x10,%rdx
    a4c5:	be 02 00 00 00       	mov    $0x2,%esi
    a4ca:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    a4d1:	00 
    a4d2:	48 09 d3             	or     %rdx,%rbx
    a4d5:	e8 36 ba ff ff       	call   5f10 <fwp_heap_alloc>
    a4da:	4c 89 28             	mov    %r13,(%rax)
    a4dd:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a4e4:	49 89 c6             	mov    %rax,%r14
    a4e7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a4ee:	48 c1 e2 10          	shl    $0x10,%rdx
    a4f2:	48 39 d0             	cmp    %rdx,%rax
    a4f5:	0f 83 55 0d 00 00    	jae    b250 <fwp_main_thread+0x1c10>
    a4fb:	48 89 c2             	mov    %rax,%rdx
    a4fe:	48 c1 ea 10          	shr    $0x10,%rdx
    a502:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a506:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a50d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a511:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a515:	4d 85 ed             	test   %r13,%r13
    a518:	74 3a                	je     a554 <fwp_main_thread+0xf14>
    a51a:	0f b6 0a             	movzbl (%rdx),%ecx
    a51d:	80 f9 02             	cmp    $0x2,%cl
    a520:	0f 84 b3 0d 00 00    	je     b2d9 <fwp_main_thread+0x1c99>
    a526:	80 f9 01             	cmp    $0x1,%cl
    a529:	75 29                	jne    a554 <fwp_main_thread+0xf14>
    a52b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a52e:	0f b7 c0             	movzwl %ax,%eax
    a531:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a534:	48 0f af c1          	imul   %rcx,%rax
    a538:	48 c1 e8 20          	shr    $0x20,%rax
    a53c:	48 39 d0             	cmp    %rdx,%rax
    a53f:	73 13                	jae    a554 <fwp_main_thread+0xf14>
    a541:	49 01 c5             	add    %rax,%r13
    a544:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a549:	0f 84 9e 0d 00 00    	je     b2ed <fwp_main_thread+0x1cad>
    a54f:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a554:	4d 85 e4             	test   %r12,%r12
    a557:	74 5b                	je     a5b4 <fwp_main_thread+0xf74>
    a559:	48 89 d9             	mov    %rbx,%rcx
    a55c:	48 8b 14 24          	mov    (%rsp),%rdx
    a560:	31 c0                	xor    %eax,%eax
    a562:	48 c1 e1 20          	shl    $0x20,%rcx
    a566:	0f 1f 40 00          	nopl   0x0(%rax)
    a56a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a571:	00 00 00 00 
    a575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a57c:	00 00 00 00 
    a580:	48 89 c6             	mov    %rax,%rsi
    a583:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a588:	48 01 ce             	add    %rcx,%rsi
    a58b:	0f 80 68 13 00 00    	jo     b8f9 <fwp_main_thread+0x22b9>
    a591:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    a596:	48 89 c6             	mov    %rax,%rsi
    a599:	48 83 c0 01          	add    $0x1,%rax
    a59d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a5a1:	48 c1 e6 04          	shl    $0x4,%rsi
    a5a5:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    a5ab:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a5af:	4c 39 e0             	cmp    %r12,%rax
    a5b2:	72 cc                	jb     a580 <fwp_main_thread+0xf40>
    a5b4:	49 8b 06             	mov    (%r14),%rax
    a5b7:	48 d1 e8             	shr    $1,%rax
    a5ba:	0f 84 a0 0c 00 00    	je     b260 <fwp_main_thread+0x1c20>
    a5c0:	48 8d 48 ff          	lea    -0x1(%rax),%rcx
    a5c4:	48 89 cf             	mov    %rcx,%rdi
    a5c7:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a5cb:	0f 85 45 13 00 00    	jne    b916 <fwp_main_thread+0x22d6>
    a5d1:	48 8d 14 09          	lea    (%rcx,%rcx,1),%rdx
    a5d5:	48 85 c9             	test   %rcx,%rcx
    a5d8:	74 49                	je     a623 <fwp_main_thread+0xfe3>
    a5da:	48 c1 e0 04          	shl    $0x4,%rax
    a5de:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    a5e3:	49 89 d5             	mov    %rdx,%r13
    a5e6:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    a5ea:	4d 8d 64 06 f8       	lea    -0x8(%r14,%rax,1),%r12
    a5ef:	90                   	nop
    a5f0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    a5f4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    a5f8:	48 83 c3 10          	add    $0x10,%rbx
    a5fc:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    a600:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    a604:	e8 67 c0 ff ff       	call   6670 <w120>
    a609:	66 48 0f 6e e8       	movq   %rax,%xmm5
    a60e:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a612:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    a616:	49 39 dc             	cmp    %rbx,%r12
    a619:	75 d5                	jne    a5f0 <fwp_main_thread+0xfb0>
    a61b:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    a620:	4c 89 ea             	mov    %r13,%rdx
    a623:	49 89 16             	mov    %rdx,(%r14)
    a626:	4c 89 f7             	mov    %r14,%rdi
    a629:	4c 63 eb             	movslq %ebx,%r13
    a62c:	e8 af c1 ff ff       	call   67e0 <w176.constprop.0>
    a631:	4c 89 f7             	mov    %r14,%rdi
    a634:	49 89 c4             	mov    %rax,%r12
    a637:	e8 94 d8 ff ff       	call   7ed0 <fwp_drop10>
    a63c:	4c 89 ef             	mov    %r13,%rdi
    a63f:	e8 ec a0 ff ff       	call   4730 <fwp_tape_of>
    a644:	48 89 c6             	mov    %rax,%rsi
    a647:	48 8b 40 60          	mov    0x60(%rax),%rax
    a64b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a650:	48 85 c0             	test   %rax,%rax
    a653:	0f 85 6f 13 00 00    	jne    b9c8 <fwp_main_thread+0x2388>
    a659:	48 89 f7             	mov    %rsi,%rdi
    a65c:	e8 2f 96 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    a661:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    a665:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a66a:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a671:	4c 8b 4e 08          	mov    0x8(%rsi),%r9
    a675:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a679:	66 49 0f 6e fe       	movq   %r14,%xmm7
    a67e:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    a683:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    a688:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    a68c:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    a690:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a696:	77 18                	ja     a6b0 <fwp_main_thread+0x1070>
    a698:	0f b7 c3             	movzwl %bx,%eax
    a69b:	83 e8 01             	sub    $0x1,%eax
    a69e:	48 98                	cltq
    a6a0:	48 3b 05 31 5a 01 00 	cmp    0x15a31(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    a6a7:	7d 07                	jge    a6b0 <fwp_main_thread+0x1070>
    a6a9:	48 89 05 28 5a 01 00 	mov    %rax,0x15a28(%rip)        # 200d8 <fwp_tape_next_slot>
    a6b0:	48 8b 05 01 fe 05 00 	mov    0x5fe01(%rip),%rax        # 6a4b8 <fwp_cleanups>
    a6b7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a6bb:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    a6c2:	00 
    a6c3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    a6ca:	00 
    a6cb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a6d2:	00 
    a6d3:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a6d7:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    a6db:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a6df:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a6e6:	00 
    a6e7:	48 8d 05 72 ab ff ff 	lea    -0x548e(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    a6ee:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    a6f5:	00 
    a6f6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    a6fb:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    a702:	00 
    a703:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a70a:	00 
    a70b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    a710:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
    a717:	00 
    a718:	48 89 05 99 fd 05 00 	mov    %rax,0x5fd99(%rip)        # 6a4b8 <fwp_cleanups>
    a71f:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
    a726:	00 
    a727:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    a72e:	00 
    a72f:	4d 85 e4             	test   %r12,%r12
    a732:	0f 88 08 0d 00 00    	js     b440 <fwp_main_thread+0x1e00>
    a738:	4c 89 e0             	mov    %r12,%rax
    a73b:	48 c1 f8 20          	sar    $0x20,%rax
    a73f:	49 39 c5             	cmp    %rax,%r13
    a742:	0f 85 72 11 00 00    	jne    b8ba <fwp_main_thread+0x227a>
    a748:	44 89 e1             	mov    %r12d,%ecx
    a74b:	49 89 cd             	mov    %rcx,%r13
    a74e:	48 39 ca             	cmp    %rcx,%rdx
    a751:	0f 8e 6f 11 00 00    	jle    b8c6 <fwp_main_thread+0x2286>
    a757:	49 39 c9             	cmp    %rcx,%r9
    a75a:	0f 8e a0 0b 00 00    	jle    b300 <fwp_main_thread+0x1cc0>
    a760:	4d 39 f1             	cmp    %r14,%r9
    a763:	0f 8f d7 0b 00 00    	jg     b340 <fwp_main_thread+0x1d00>
    a769:	4d 85 c0             	test   %r8,%r8
    a76c:	0f 84 bc 11 00 00    	je     b92e <fwp_main_thread+0x22ee>
    a772:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    a777:	4d 8d 69 ff          	lea    -0x1(%r9),%r13
    a77b:	31 f6                	xor    %esi,%esi
    a77d:	4c 89 c7             	mov    %r8,%rdi
    a780:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    a785:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    a78c:	00 
    a78d:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    a792:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    a797:	e8 14 8d ff ff       	call   34b0 <memset@plt>
    a79c:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a7a1:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    a7a7:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    a7ad:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
    a7b2:	49 89 c0             	mov    %rax,%r8
    a7b5:	f2 0f 10 05 ab 25 00 	movsd  0x25ab(%rip),%xmm0        # cd68 <msg.4+0x28>
    a7bc:	00 
    a7bd:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    a7c3:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    a7c9:	4d 39 e9             	cmp    %r13,%r9
    a7cc:	0f 8f 8f 00 00 00    	jg     a861 <fwp_main_thread+0x1221>
    a7d2:	0f 12 fb             	movhlps %xmm3,%xmm7
    a7d5:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    a7da:	0f 12 da             	movhlps %xmm2,%xmm3
    a7dd:	4d 29 cd             	sub    %r9,%r13
    a7e0:	66 49 0f 7e da       	movq   %xmm3,%r10
    a7e5:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    a7ea:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    a7ef:	4f 8d 1c c8          	lea    (%r8,%r9,8),%r11
    a7f3:	4b 8d 14 ea          	lea    (%r10,%r13,8),%rdx
    a7f7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a7fb:	48 29 f1             	sub    %rsi,%rcx
    a7fe:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    a802:	4d 29 d3             	sub    %r10,%r11
    a805:	4c 29 d7             	sub    %r10,%rdi
    a808:	eb 0a                	jmp    a814 <fwp_main_thread+0x11d4>
    a80a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a810:	48 83 e8 04          	sub    $0x4,%rax
    a814:	f2 41 0f 10 04 13    	movsd  (%r11,%rdx,1),%xmm0
    a81a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a81e:	7a 02                	jp     a822 <fwp_main_thread+0x11e2>
    a820:	74 36                	je     a858 <fwp_main_thread+0x1218>
    a822:	4c 63 14 01          	movslq (%rcx,%rax,1),%r10
    a826:	45 85 d2             	test   %r10d,%r10d
    a829:	78 15                	js     a840 <fwp_main_thread+0x1200>
    a82b:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    a830:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a834:	f2 43 0f 58 0c d0    	addsd  (%r8,%r10,8),%xmm1
    a83a:	f2 43 0f 11 0c d0    	movsd  %xmm1,(%r8,%r10,8)
    a840:	4c 63 10             	movslq (%rax),%r10
    a843:	45 85 d2             	test   %r10d,%r10d
    a846:	78 10                	js     a858 <fwp_main_thread+0x1218>
    a848:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    a84c:	f2 43 0f 58 04 d0    	addsd  (%r8,%r10,8),%xmm0
    a852:	f2 43 0f 11 04 d0    	movsd  %xmm0,(%r8,%r10,8)
    a858:	48 83 ea 08          	sub    $0x8,%rdx
    a85c:	48 39 f0             	cmp    %rsi,%rax
    a85f:	75 af                	jne    a810 <fwp_main_thread+0x11d0>
    a861:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a868:	ff ff 1f 
    a86b:	4c 39 c8             	cmp    %r9,%rax
    a86e:	0f 82 ae 10 00 00    	jb     b922 <fwp_main_thread+0x22e2>
    a874:	4a 8d 3c cd 08 00 00 	lea    0x8(,%r9,8),%rdi
    a87b:	00 
    a87c:	be 02 00 00 00       	mov    $0x2,%esi
    a881:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
    a886:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    a88b:	e8 80 b6 ff ff       	call   5f10 <fwp_heap_alloc>
    a890:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a895:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
    a89a:	48 89 c3             	mov    %rax,%rbx
    a89d:	4c 89 08             	mov    %r9,(%rax)
    a8a0:	31 c0                	xor    %eax,%eax
    a8a2:	4d 85 c9             	test   %r9,%r9
    a8a5:	74 2b                	je     a8d2 <fwp_main_thread+0x1292>
    a8a7:	0f 1f 00             	nopl   (%rax)
    a8aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8b1:	00 00 00 00 
    a8b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8bc:	00 00 00 00 
    a8c0:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    a8c4:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    a8c9:	48 83 c0 01          	add    $0x1,%rax
    a8cd:	49 39 c1             	cmp    %rax,%r9
    a8d0:	75 ee                	jne    a8c0 <fwp_main_thread+0x1280>
    a8d2:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
    a8d9:	00 
    a8da:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    a8df:	4c 89 25 d2 fb 05 00 	mov    %r12,0x5fbd2(%rip)        # 6a4b8 <fwp_cleanups>
    a8e6:	e8 75 a9 ff ff       	call   5260 <fwp_tape_buffers_release>
    a8eb:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a8f2:	48 89 d8             	mov    %rbx,%rax
    a8f5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a8fc:	48 c1 e2 10          	shl    $0x10,%rdx
    a900:	48 39 d0             	cmp    %rdx,%rax
    a903:	73 59                	jae    a95e <fwp_main_thread+0x131e>
    a905:	48 89 c2             	mov    %rax,%rdx
    a908:	48 c1 ea 10          	shr    $0x10,%rdx
    a90c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a910:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a917:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a91b:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a91f:	4d 85 ed             	test   %r13,%r13
    a922:	74 3a                	je     a95e <fwp_main_thread+0x131e>
    a924:	0f b6 0a             	movzbl (%rdx),%ecx
    a927:	80 f9 02             	cmp    $0x2,%cl
    a92a:	0f 84 40 0b 00 00    	je     b470 <fwp_main_thread+0x1e30>
    a930:	80 f9 01             	cmp    $0x1,%cl
    a933:	75 29                	jne    a95e <fwp_main_thread+0x131e>
    a935:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a938:	0f b7 c0             	movzwl %ax,%eax
    a93b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a93e:	48 0f af c1          	imul   %rcx,%rax
    a942:	48 c1 e8 20          	shr    $0x20,%rax
    a946:	48 39 d0             	cmp    %rdx,%rax
    a949:	73 13                	jae    a95e <fwp_main_thread+0x131e>
    a94b:	49 01 c5             	add    %rax,%r13
    a94e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a953:	0f 84 2b 0b 00 00    	je     b484 <fwp_main_thread+0x1e44>
    a959:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a95e:	4c 3b 64 24 48       	cmp    0x48(%rsp),%r12
    a963:	0f 85 e2 8d ff ff    	jne    374b <fwp_main_thread.cold>
    a969:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    a970:	00 
    a971:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a976:	48 89 05 3b fb 05 00 	mov    %rax,0x5fb3b(%rip)        # 6a4b8 <fwp_cleanups>
    a97d:	e8 fe c5 ff ff       	call   6f80 <fwp_tape_scope_release>
    a982:	48 8b 03             	mov    (%rbx),%rax
    a985:	49 89 c5             	mov    %rax,%r13
    a988:	49 0f ba f5 3f       	btr    $0x3f,%r13
    a98d:	48 85 c0             	test   %rax,%rax
    a990:	0f 88 ea 07 00 00    	js     b180 <fwp_main_thread+0x1b40>
    a996:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a99d:	48 89 d8             	mov    %rbx,%rax
    a9a0:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a9a7:	48 c1 e2 10          	shl    $0x10,%rdx
    a9ab:	48 39 d0             	cmp    %rdx,%rax
    a9ae:	0f 83 cc 07 00 00    	jae    b180 <fwp_main_thread+0x1b40>
    a9b4:	48 89 c2             	mov    %rax,%rdx
    a9b7:	48 c1 ea 10          	shr    $0x10,%rdx
    a9bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a9bf:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a9c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a9ca:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a9ce:	48 85 c9             	test   %rcx,%rcx
    a9d1:	0f 84 a9 07 00 00    	je     b180 <fwp_main_thread+0x1b40>
    a9d7:	0f b6 32             	movzbl (%rdx),%esi
    a9da:	40 80 fe 02          	cmp    $0x2,%sil
    a9de:	0f 84 8c 07 00 00    	je     b170 <fwp_main_thread+0x1b30>
    a9e4:	40 80 fe 01          	cmp    $0x1,%sil
    a9e8:	0f 85 92 07 00 00    	jne    b180 <fwp_main_thread+0x1b40>
    a9ee:	8b 72 18             	mov    0x18(%rdx),%esi
    a9f1:	0f b7 c0             	movzwl %ax,%eax
    a9f4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a9f7:	48 0f af c6          	imul   %rsi,%rax
    a9fb:	48 c1 e8 20          	shr    $0x20,%rax
    a9ff:	48 39 d0             	cmp    %rdx,%rax
    aa02:	0f 83 78 07 00 00    	jae    b180 <fwp_main_thread+0x1b40>
    aa08:	48 01 c1             	add    %rax,%rcx
    aa0b:	80 39 01             	cmpb   $0x1,(%rcx)
    aa0e:	0f 85 6c 07 00 00    	jne    b180 <fwp_main_thread+0x1b40>
    aa14:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    aa19:	48 89 da             	mov    %rbx,%rdx
    aa1c:	31 ff                	xor    %edi,%edi
    aa1e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    aa23:	48 8d 48 08          	lea    0x8(%rax),%rcx
    aa27:	31 c0                	xor    %eax,%eax
    aa29:	4d 85 ed             	test   %r13,%r13
    aa2c:	75 2b                	jne    aa59 <fwp_main_thread+0x1419>
    aa2e:	eb 58                	jmp    aa88 <fwp_main_thread+0x1448>
    aa30:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    aa34:	0f 88 c4 0e 00 00    	js     b8fe <fwp_main_thread+0x22be>
    aa3a:	f2 0f 10 05 3e 23 00 	movsd  0x233e(%rip),%xmm0        # cd80 <msg.4+0x40>
    aa41:	00 
    aa42:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    aa47:	48 83 c0 01          	add    $0x1,%rax
    aa4b:	48 83 c1 08          	add    $0x8,%rcx
    aa4f:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    aa54:	49 39 c5             	cmp    %rax,%r13
    aa57:	74 2f                	je     aa88 <fwp_main_thread+0x1448>
    aa59:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    aa5d:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    aa61:	79 cd                	jns    aa30 <fwp_main_thread+0x13f0>
    aa63:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    aa67:	eb c7                	jmp    aa30 <fwp_main_thread+0x13f0>
    aa69:	48 8d 3d 50 a2 ff ff 	lea    -0x5db0(%rip),%rdi        # 4cc0 <fwp_heap_report>
    aa70:	e8 7b 11 00 00       	call   bbf0 <atexit>
    aa75:	e9 0e ec ff ff       	jmp    9688 <fwp_main_thread+0x48>
    aa7a:	e8 51 a3 ff ff       	call   4dd0 <fwp_heap_init>
    aa7f:	e9 f4 eb ff ff       	jmp    9678 <fwp_main_thread+0x38>
    aa84:	0f 1f 40 00          	nopl   0x0(%rax)
    aa88:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    aa8d:	e8 3e d4 ff ff       	call   7ed0 <fwp_drop10>
    aa92:	48 8b 1c 24          	mov    (%rsp),%rbx
    aa96:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    aa9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aaa0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    aaa4:	49 83 c7 01          	add    $0x1,%r15
    aaa8:	48 85 db             	test   %rbx,%rbx
    aaab:	75 f3                	jne    aaa0 <fwp_main_thread+0x1460>
    aaad:	4c 8b 32             	mov    (%rdx),%r14
    aab0:	4d 85 f6             	test   %r14,%r14
    aab3:	0f 88 07 01 00 00    	js     abc0 <fwp_main_thread+0x1580>
    aab9:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    aac0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    aac5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aacc:	48 c1 e1 10          	shl    $0x10,%rcx
    aad0:	48 39 c8             	cmp    %rcx,%rax
    aad3:	0f 83 e7 00 00 00    	jae    abc0 <fwp_main_thread+0x1580>
    aad9:	48 89 c1             	mov    %rax,%rcx
    aadc:	48 c1 e9 10          	shr    $0x10,%rcx
    aae0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    aae4:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    aaeb:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    aaef:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    aaf3:	48 85 f6             	test   %rsi,%rsi
    aaf6:	0f 84 c4 00 00 00    	je     abc0 <fwp_main_thread+0x1580>
    aafc:	0f b6 39             	movzbl (%rcx),%edi
    aaff:	40 80 ff 02          	cmp    $0x2,%dil
    ab03:	0f 84 a7 00 00 00    	je     abb0 <fwp_main_thread+0x1570>
    ab09:	40 80 ff 01          	cmp    $0x1,%dil
    ab0d:	0f 85 ad 00 00 00    	jne    abc0 <fwp_main_thread+0x1580>
    ab13:	8b 79 18             	mov    0x18(%rcx),%edi
    ab16:	0f b7 c0             	movzwl %ax,%eax
    ab19:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ab1c:	48 0f af c7          	imul   %rdi,%rax
    ab20:	48 c1 e8 20          	shr    $0x20,%rax
    ab24:	48 39 c8             	cmp    %rcx,%rax
    ab27:	0f 83 93 00 00 00    	jae    abc0 <fwp_main_thread+0x1580>
    ab2d:	48 01 c6             	add    %rax,%rsi
    ab30:	80 3e 01             	cmpb   $0x1,(%rsi)
    ab33:	0f 85 87 00 00 00    	jne    abc0 <fwp_main_thread+0x1580>
    ab39:	4d 39 f7             	cmp    %r14,%r15
    ab3c:	4d 0f 46 f7          	cmovbe %r15,%r14
    ab40:	4d 85 f6             	test   %r14,%r14
    ab43:	0f 84 b3 0c 00 00    	je     b7fc <fwp_main_thread+0x21bc>
    ab49:	4c 8d 62 08          	lea    0x8(%rdx),%r12
    ab4d:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    ab53:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    ab58:	48 8b 34 24          	mov    (%rsp),%rsi
    ab5c:	4e 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%r8
    ab63:	00 
    ab64:	31 c0                	xor    %eax,%eax
    ab66:	49 8d 79 08          	lea    0x8(%r9),%rdi
    ab6a:	eb 35                	jmp    aba1 <fwp_main_thread+0x1561>
    ab6c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ab73:	00 00 
    ab75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab7c:	00 00 00 00 
    ab80:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    ab85:	f2 0f 5c 04 01       	subsd  (%rcx,%rax,1),%xmm0
    ab8a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    ab90:	48 83 c0 08          	add    $0x8,%rax
    ab94:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    ab98:	49 39 c0             	cmp    %rax,%r8
    ab9b:	0f 84 b7 00 00 00    	je     ac58 <fwp_main_thread+0x1618>
    aba1:	48 89 f9             	mov    %rdi,%rcx
    aba4:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    aba8:	79 d6                	jns    ab80 <fwp_main_thread+0x1540>
    abaa:	49 8b 49 10          	mov    0x10(%r9),%rcx
    abae:	eb d0                	jmp    ab80 <fwp_main_thread+0x1540>
    abb0:	66 85 c0             	test   %ax,%ax
    abb3:	0f 84 77 ff ff ff    	je     ab30 <fwp_main_thread+0x14f0>
    abb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abc0:	48 8b 04 24          	mov    (%rsp),%rax
    abc4:	45 31 ed             	xor    %r13d,%r13d
    abc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    abce:	00 00 
    abd0:	48 8b 40 10          	mov    0x10(%rax),%rax
    abd4:	4c 89 e9             	mov    %r13,%rcx
    abd7:	49 83 c5 01          	add    $0x1,%r13
    abdb:	48 85 c0             	test   %rax,%rax
    abde:	75 f0                	jne    abd0 <fwp_main_thread+0x1590>
    abe0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    abe7:	ff ff 1f 
    abea:	4c 39 e8             	cmp    %r13,%rax
    abed:	0f 82 23 0d 00 00    	jb     b916 <fwp_main_thread+0x22d6>
    abf3:	be 02 00 00 00       	mov    $0x2,%esi
    abf8:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    abff:	00 
    ac00:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    ac05:	e8 06 b3 ff ff       	call   5f10 <fwp_heap_alloc>
    ac0a:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    ac0f:	49 89 c4             	mov    %rax,%r12
    ac12:	48 89 c6             	mov    %rax,%rsi
    ac15:	48 8b 04 24          	mov    (%rsp),%rax
    ac19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    ac24:	48 83 c6 08          	add    $0x8,%rsi
    ac28:	48 89 4e f8          	mov    %rcx,-0x8(%rsi)
    ac2c:	48 8b 40 10          	mov    0x10(%rax),%rax
    ac30:	48 85 c0             	test   %rax,%rax
    ac33:	75 eb                	jne    ac20 <fwp_main_thread+0x15e0>
    ac35:	49 0f ba f6 3f       	btr    $0x3f,%r14
    ac3a:	4d 39 ee             	cmp    %r13,%r14
    ac3d:	4d 0f 47 f5          	cmova  %r13,%r14
    ac41:	4d 85 f6             	test   %r14,%r14
    ac44:	0f 84 e0 0a 00 00    	je     b72a <fwp_main_thread+0x20ea>
    ac4a:	45 31 ed             	xor    %r13d,%r13d
    ac4d:	e9 01 ff ff ff       	jmp    ab53 <fwp_main_thread+0x1513>
    ac52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac58:	48 8b bd d8 13 00 00 	mov    0x13d8(%rbp),%rdi
    ac5f:	4c 8b 85 b0 13 00 00 	mov    0x13b0(%rbp),%r8
    ac66:	45 31 ff             	xor    %r15d,%r15d
    ac69:	4c 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%r9
    ac70:	48 8b 14 24          	mov    (%rsp),%rdx
    ac74:	48 c1 e7 10          	shl    $0x10,%rdi
    ac78:	eb 1c                	jmp    ac96 <fwp_main_thread+0x1656>
    ac7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac80:	49 83 c7 01          	add    $0x1,%r15
    ac84:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    ac88:	4d 39 f7             	cmp    %r14,%r15
    ac8b:	0f 83 ff 03 00 00    	jae    b090 <fwp_main_thread+0x1a50>
    ac91:	48 85 d2             	test   %rdx,%rdx
    ac94:	74 56                	je     acec <fwp_main_thread+0x16ac>
    ac96:	48 89 d0             	mov    %rdx,%rax
    ac99:	4c 29 c0             	sub    %r8,%rax
    ac9c:	48 39 f8             	cmp    %rdi,%rax
    ac9f:	73 4b                	jae    acec <fwp_main_thread+0x16ac>
    aca1:	48 89 c1             	mov    %rax,%rcx
    aca4:	48 c1 e9 10          	shr    $0x10,%rcx
    aca8:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    acac:	49 8d 0c c9          	lea    (%r9,%rcx,8),%rcx
    acb0:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    acb4:	48 85 f6             	test   %rsi,%rsi
    acb7:	74 33                	je     acec <fwp_main_thread+0x16ac>
    acb9:	44 0f b6 11          	movzbl (%rcx),%r10d
    acbd:	41 80 fa 02          	cmp    $0x2,%r10b
    acc1:	0f 84 b1 03 00 00    	je     b078 <fwp_main_thread+0x1a38>
    acc7:	41 80 fa 01          	cmp    $0x1,%r10b
    accb:	75 1f                	jne    acec <fwp_main_thread+0x16ac>
    accd:	44 8b 51 18          	mov    0x18(%rcx),%r10d
    acd1:	0f b7 c0             	movzwl %ax,%eax
    acd4:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    acd7:	49 0f af c2          	imul   %r10,%rax
    acdb:	48 c1 e8 20          	shr    $0x20,%rax
    acdf:	48 39 c8             	cmp    %rcx,%rax
    ace2:	73 08                	jae    acec <fwp_main_thread+0x16ac>
    ace4:	48 01 c6             	add    %rax,%rsi
    ace7:	80 3e 01             	cmpb   $0x1,(%rsi)
    acea:	74 94                	je     ac80 <fwp_main_thread+0x1640>
    acec:	4d 39 f7             	cmp    %r14,%r15
    acef:	72 43                	jb     ad34 <fwp_main_thread+0x16f4>
    acf1:	e9 9a 03 00 00       	jmp    b090 <fwp_main_thread+0x1a50>
    acf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    acfd:	00 00 00 
    ad00:	40 80 fe 01          	cmp    $0x1,%sil
    ad04:	75 25                	jne    ad2b <fwp_main_thread+0x16eb>
    ad06:	8b 71 18             	mov    0x18(%rcx),%esi
    ad09:	0f b7 c0             	movzwl %ax,%eax
    ad0c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ad0f:	48 0f af c6          	imul   %rsi,%rax
    ad13:	48 c1 e8 20          	shr    $0x20,%rax
    ad17:	48 39 c8             	cmp    %rcx,%rax
    ad1a:	73 0f                	jae    ad2b <fwp_main_thread+0x16eb>
    ad1c:	48 01 c2             	add    %rax,%rdx
    ad1f:	80 3a ff             	cmpb   $0xff,(%rdx)
    ad22:	0f 84 08 05 00 00    	je     b230 <fwp_main_thread+0x1bf0>
    ad28:	c6 02 01             	movb   $0x1,(%rdx)
    ad2b:	4d 39 fe             	cmp    %r15,%r14
    ad2e:	0f 84 8c 00 00 00    	je     adc0 <fwp_main_thread+0x1780>
    ad34:	49 83 ee 01          	sub    $0x1,%r14
    ad38:	66 48 0f 6e f3       	movq   %rbx,%xmm6
    ad3d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ad42:	bf 01 00 00 00       	mov    $0x1,%edi
    ad47:	f3 43 0f 7e 04 f4    	movq   (%r12,%r14,8),%xmm0
    ad4d:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    ad51:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    ad58:	00 
    ad59:	e8 a2 b3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ad5e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ad65:	48 89 c3             	mov    %rax,%rbx
    ad68:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ad6f:	48 c1 e2 10          	shl    $0x10,%rdx
    ad73:	48 39 d0             	cmp    %rdx,%rax
    ad76:	73 b3                	jae    ad2b <fwp_main_thread+0x16eb>
    ad78:	48 89 c2             	mov    %rax,%rdx
    ad7b:	48 c1 ea 10          	shr    $0x10,%rdx
    ad7f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad83:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    ad8a:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    ad8e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    ad92:	48 85 d2             	test   %rdx,%rdx
    ad95:	74 94                	je     ad2b <fwp_main_thread+0x16eb>
    ad97:	0f b6 31             	movzbl (%rcx),%esi
    ad9a:	40 80 fe 02          	cmp    $0x2,%sil
    ad9e:	0f 85 5c ff ff ff    	jne    ad00 <fwp_main_thread+0x16c0>
    ada4:	66 85 c0             	test   %ax,%ax
    ada7:	0f 84 72 ff ff ff    	je     ad1f <fwp_main_thread+0x16df>
    adad:	4d 39 fe             	cmp    %r15,%r14
    adb0:	75 82                	jne    ad34 <fwp_main_thread+0x16f4>
    adb2:	0f 1f 00             	nopl   (%rax)
    adb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    adbc:	00 00 00 00 
    adc0:	4d 85 f6             	test   %r14,%r14
    adc3:	0f 85 c7 02 00 00    	jne    b090 <fwp_main_thread+0x1a50>
    adc9:	45 85 ed             	test   %r13d,%r13d
    adcc:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    add2:	4c 8b 34 24          	mov    (%rsp),%r14
    add6:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    addb:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    ade0:	e8 2b ac ff ff       	call   5a10 <fwp_mem_free>
    ade5:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    adea:	e8 e1 d0 ff ff       	call   7ed0 <fwp_drop10>
    adef:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    adf6:	4c 89 f0             	mov    %r14,%rax
    adf9:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ae00:	48 c1 e2 10          	shl    $0x10,%rdx
    ae04:	48 39 d0             	cmp    %rdx,%rax
    ae07:	73 77                	jae    ae80 <fwp_main_thread+0x1840>
    ae09:	48 89 c2             	mov    %rax,%rdx
    ae0c:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    ae13:	48 c1 ea 10          	shr    $0x10,%rdx
    ae17:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    ae1b:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    ae1f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ae23:	4d 85 e4             	test   %r12,%r12
    ae26:	74 58                	je     ae80 <fwp_main_thread+0x1840>
    ae28:	0f b6 0a             	movzbl (%rdx),%ecx
    ae2b:	80 f9 02             	cmp    $0x2,%cl
    ae2e:	0f 84 ec 05 00 00    	je     b420 <fwp_main_thread+0x1de0>
    ae34:	80 f9 01             	cmp    $0x1,%cl
    ae37:	75 47                	jne    ae80 <fwp_main_thread+0x1840>
    ae39:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae3c:	0f b7 c0             	movzwl %ax,%eax
    ae3f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae42:	48 0f af c1          	imul   %rcx,%rax
    ae46:	48 c1 e8 20          	shr    $0x20,%rax
    ae4a:	48 39 d0             	cmp    %rdx,%rax
    ae4d:	73 31                	jae    ae80 <fwp_main_thread+0x1840>
    ae4f:	49 01 c4             	add    %rax,%r12
    ae52:	41 0f b6 04 24       	movzbl (%r12),%eax
    ae57:	84 c0                	test   %al,%al
    ae59:	74 25                	je     ae80 <fwp_main_thread+0x1840>
    ae5b:	3c 01                	cmp    $0x1,%al
    ae5d:	0f 84 35 06 00 00    	je     b498 <fwp_main_thread+0x1e58>
    ae63:	3c ff                	cmp    $0xff,%al
    ae65:	0f 84 1a 09 00 00    	je     b785 <fwp_main_thread+0x2145>
    ae6b:	83 e8 01             	sub    $0x1,%eax
    ae6e:	41 88 04 24          	mov    %al,(%r12)
    ae72:	0f 1f 00             	nopl   (%rax)
    ae75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ae7c:	00 00 00 00 
    ae80:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    ae85:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ae89:	b9 01 00 00 00       	mov    $0x1,%ecx
    ae8e:	48 89 de             	mov    %rbx,%rsi
    ae91:	48 8d 15 08 4d 00 00 	lea    0x4d08(%rip),%rdx        # fba0 <d0>
    ae98:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    ae9f:	00 
    aea0:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    aea7:	00 00 00 00 00 
    aeac:	e8 4f d7 ff ff       	call   8600 <fwp_write>
    aeb1:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
    aeb8:	00 
    aeb9:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    aec0:	00 
    aec1:	48 8d 05 a4 11 00 00 	lea    0x11a4(%rip),%rax        # c06c <_IO_stdin_used+0x6c>
    aec8:	4d 85 f6             	test   %r14,%r14
    aecb:	4c 0f 44 f0          	cmove  %rax,%r14
    aecf:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    aed3:	0f 87 e3 0a 00 00    	ja     b9bc <fwp_main_thread+0x237c>
    aed9:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    aedd:	be 01 00 00 00       	mov    $0x1,%esi
    aee2:	e8 29 b0 ff ff       	call   5f10 <fwp_heap_alloc>
    aee7:	4c 89 fa             	mov    %r15,%rdx
    aeea:	4c 89 f6             	mov    %r14,%rsi
    aeed:	4c 89 38             	mov    %r15,(%rax)
    aef0:	4c 8d 68 08          	lea    0x8(%rax),%r13
    aef4:	49 89 c4             	mov    %rax,%r12
    aef7:	4c 89 ef             	mov    %r13,%rdi
    aefa:	e8 81 86 ff ff       	call   3580 <memcpy@plt>
    aeff:	43 c6 44 3c 08 00    	movb   $0x0,0x8(%r12,%r15,1)
    af05:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    af0c:	00 
    af0d:	e8 9e 84 ff ff       	call   33b0 <free@plt>
    af12:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    af19:	4c 89 e0             	mov    %r12,%rax
    af1c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    af23:	48 c1 e2 10          	shl    $0x10,%rdx
    af27:	48 39 d0             	cmp    %rdx,%rax
    af2a:	73 57                	jae    af83 <fwp_main_thread+0x1943>
    af2c:	48 89 c2             	mov    %rax,%rdx
    af2f:	48 c1 ea 10          	shr    $0x10,%rdx
    af33:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af37:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    af3e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af42:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    af46:	4d 85 f6             	test   %r14,%r14
    af49:	74 38                	je     af83 <fwp_main_thread+0x1943>
    af4b:	0f b6 0a             	movzbl (%rdx),%ecx
    af4e:	80 f9 02             	cmp    $0x2,%cl
    af51:	0f 84 09 07 00 00    	je     b660 <fwp_main_thread+0x2020>
    af57:	80 f9 01             	cmp    $0x1,%cl
    af5a:	75 27                	jne    af83 <fwp_main_thread+0x1943>
    af5c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af5f:	0f b7 c0             	movzwl %ax,%eax
    af62:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af65:	48 0f af c1          	imul   %rcx,%rax
    af69:	48 c1 e8 20          	shr    $0x20,%rax
    af6d:	48 39 d0             	cmp    %rdx,%rax
    af70:	73 11                	jae    af83 <fwp_main_thread+0x1943>
    af72:	49 01 c6             	add    %rax,%r14
    af75:	41 80 3e ff          	cmpb   $0xff,(%r14)
    af79:	0f 84 f4 06 00 00    	je     b673 <fwp_main_thread+0x2033>
    af7f:	41 c6 06 01          	movb   $0x1,(%r14)
    af83:	48 89 df             	mov    %rbx,%rdi
    af86:	e8 55 cb ff ff       	call   7ae0 <fwp_drop0>
    af8b:	49 8b 14 24          	mov    (%r12),%rdx
    af8f:	be 01 00 00 00       	mov    $0x1,%esi
    af94:	4c 89 ef             	mov    %r13,%rdi
    af97:	48 8b 0d e2 f4 05 00 	mov    0x5f4e2(%rip),%rcx        # 6a480 <fwp_prog_out>
    af9e:	e8 bd 86 ff ff       	call   3660 <fwrite@plt>
    afa3:	48 8b 35 d6 f4 05 00 	mov    0x5f4d6(%rip),%rsi        # 6a480 <fwp_prog_out>
    afaa:	bf 0a 00 00 00       	mov    $0xa,%edi
    afaf:	e8 1c 85 ff ff       	call   34d0 <fputc@plt>
    afb4:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    afbb:	4c 89 e0             	mov    %r12,%rax
    afbe:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    afc5:	48 c1 e2 10          	shl    $0x10,%rdx
    afc9:	48 39 d0             	cmp    %rdx,%rax
    afcc:	73 72                	jae    b040 <fwp_main_thread+0x1a00>
    afce:	48 89 c2             	mov    %rax,%rdx
    afd1:	48 c1 ea 10          	shr    $0x10,%rdx
    afd5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    afd9:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    afe0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    afe4:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    afe8:	48 85 db             	test   %rbx,%rbx
    afeb:	74 53                	je     b040 <fwp_main_thread+0x1a00>
    afed:	0f b6 0a             	movzbl (%rdx),%ecx
    aff0:	80 f9 02             	cmp    $0x2,%cl
    aff3:	0f 84 47 06 00 00    	je     b640 <fwp_main_thread+0x2000>
    aff9:	80 f9 01             	cmp    $0x1,%cl
    affc:	75 42                	jne    b040 <fwp_main_thread+0x1a00>
    affe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b001:	0f b7 c0             	movzwl %ax,%eax
    b004:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b007:	48 0f af c1          	imul   %rcx,%rax
    b00b:	48 c1 e8 20          	shr    $0x20,%rax
    b00f:	48 39 d0             	cmp    %rdx,%rax
    b012:	73 2c                	jae    b040 <fwp_main_thread+0x1a00>
    b014:	48 01 c3             	add    %rax,%rbx
    b017:	0f b6 03             	movzbl (%rbx),%eax
    b01a:	84 c0                	test   %al,%al
    b01c:	74 22                	je     b040 <fwp_main_thread+0x1a00>
    b01e:	3c 01                	cmp    $0x1,%al
    b020:	0f 84 83 06 00 00    	je     b6a9 <fwp_main_thread+0x2069>
    b026:	3c ff                	cmp    $0xff,%al
    b028:	0f 84 e3 07 00 00    	je     b811 <fwp_main_thread+0x21d1>
    b02e:	83 e8 01             	sub    $0x1,%eax
    b031:	88 03                	mov    %al,(%rbx)
    b033:	66 90                	xchg   %ax,%ax
    b035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b03c:	00 00 00 00 
    b040:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    b045:	48 8b 40 10          	mov    0x10(%rax),%rax
    b049:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    b04e:	48 85 c0             	test   %rax,%rax
    b051:	0f 84 fe 06 00 00    	je     b755 <fwp_main_thread+0x2115>
    b057:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b05e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b065:	48 8b 1d 4c f4 05 00 	mov    0x5f44c(%rip),%rbx        # 6a4b8 <fwp_cleanups>
    b06c:	e9 a9 f0 ff ff       	jmp    a11a <fwp_main_thread+0xada>
    b071:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b078:	66 85 c0             	test   %ax,%ax
    b07b:	0f 84 66 fc ff ff    	je     ace7 <fwp_main_thread+0x16a7>
    b081:	4d 39 f7             	cmp    %r14,%r15
    b084:	0f 82 aa fc ff ff    	jb     ad34 <fwp_main_thread+0x16f4>
    b08a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b090:	4c 8b 34 24          	mov    (%rsp),%r14
    b094:	4c 89 e0             	mov    %r12,%rax
    b097:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    b09b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b0a0:	48 8b 10             	mov    (%rax),%rdx
    b0a3:	48 83 c0 08          	add    $0x8,%rax
    b0a7:	4c 89 f6             	mov    %r14,%rsi
    b0aa:	49 89 56 08          	mov    %rdx,0x8(%r14)
    b0ae:	4d 8b 76 10          	mov    0x10(%r14),%r14
    b0b2:	48 39 f8             	cmp    %rdi,%rax
    b0b5:	75 e9                	jne    b0a0 <fwp_main_thread+0x1a60>
    b0b7:	45 85 ed             	test   %r13d,%r13d
    b0ba:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    b0c0:	48 89 5e 10          	mov    %rbx,0x10(%rsi)
    b0c4:	48 8b 1c 24          	mov    (%rsp),%rbx
    b0c8:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    b0cd:	e9 09 fd ff ff       	jmp    addb <fwp_main_thread+0x179b>
    b0d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b0d8:	4d 39 f5             	cmp    %r14,%r13
    b0db:	0f 84 0f f2 ff ff    	je     a2f0 <fwp_main_thread+0xcb0>
    b0e1:	4c 8b 3d 08 50 01 00 	mov    0x15008(%rip),%r15        # 200f0 <fwp_tapes>
    b0e8:	e9 a2 f2 ff ff       	jmp    a38f <fwp_main_thread+0xd4f>
    b0ed:	0f 1f 00             	nopl   (%rax)
    b0f0:	48 83 3d 90 4f 01 00 	cmpq   $0x0,0x14f90(%rip)        # 20088 <fwp_tape_cached_bytes>
    b0f7:	00 
    b0f8:	0f 84 dc f2 ff ff    	je     a3da <fwp_main_thread+0xd9a>
    b0fe:	66 0f 6f 0d 9a 4f 01 	movdqa 0x14f9a(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    b105:	00 
    b106:	48 c7 05 77 4f 01 00 	movq   $0x0,0x14f77(%rip)        # 20088 <fwp_tape_cached_bytes>
    b10d:	00 00 00 00 
    b111:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    b116:	48 8b 05 a3 4f 01 00 	mov    0x14fa3(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    b11d:	66 0f 6f 0d 8b 4f 01 	movdqa 0x14f8b(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    b124:	00 
    b125:	49 89 46 40          	mov    %rax,0x40(%r14)
    b129:	48 8b 05 98 4f 01 00 	mov    0x14f98(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    b130:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    b135:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b139:	49 89 46 18          	mov    %rax,0x18(%r14)
    b13d:	48 8b 05 8c 4f 01 00 	mov    0x14f8c(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    b144:	0f 29 0d 55 4f 01 00 	movaps %xmm1,0x14f55(%rip)        # 200a0 <fwp_tape_workspace>
    b14b:	49 89 46 48          	mov    %rax,0x48(%r14)
    b14f:	0f 29 0d 5a 4f 01 00 	movaps %xmm1,0x14f5a(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    b156:	48 c7 05 6f 4f 01 00 	movq   $0x0,0x14f6f(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    b15d:	00 00 00 00 
    b161:	0f 29 0d 58 4f 01 00 	movaps %xmm1,0x14f58(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    b168:	e9 6d f2 ff ff       	jmp    a3da <fwp_main_thread+0xd9a>
    b16d:	0f 1f 00             	nopl   (%rax)
    b170:	66 85 c0             	test   %ax,%ax
    b173:	0f 84 92 f8 ff ff    	je     aa0b <fwp_main_thread+0x13cb>
    b179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b180:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    b187:	ff ff 1f 
    b18a:	4c 39 e8             	cmp    %r13,%rax
    b18d:	0f 82 8f 07 00 00    	jb     b922 <fwp_main_thread+0x22e2>
    b193:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    b19a:	00 
    b19b:	be 01 00 00 00       	mov    $0x1,%esi
    b1a0:	e8 6b ad ff ff       	call   5f10 <fwp_heap_alloc>
    b1a5:	4c 89 28             	mov    %r13,(%rax)
    b1a8:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    b1af:	48 89 c2             	mov    %rax,%rdx
    b1b2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b1b7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b1be:	48 c1 e1 10          	shl    $0x10,%rcx
    b1c2:	48 39 c8             	cmp    %rcx,%rax
    b1c5:	73 59                	jae    b220 <fwp_main_thread+0x1be0>
    b1c7:	48 89 c1             	mov    %rax,%rcx
    b1ca:	48 c1 e9 10          	shr    $0x10,%rcx
    b1ce:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b1d2:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    b1d9:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b1dd:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    b1e1:	4d 85 f6             	test   %r14,%r14
    b1e4:	74 3a                	je     b220 <fwp_main_thread+0x1be0>
    b1e6:	0f b6 31             	movzbl (%rcx),%esi
    b1e9:	40 80 fe 02          	cmp    $0x2,%sil
    b1ed:	0f 84 45 03 00 00    	je     b538 <fwp_main_thread+0x1ef8>
    b1f3:	40 80 fe 01          	cmp    $0x1,%sil
    b1f7:	75 27                	jne    b220 <fwp_main_thread+0x1be0>
    b1f9:	8b 71 18             	mov    0x18(%rcx),%esi
    b1fc:	0f b7 c0             	movzwl %ax,%eax
    b1ff:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b202:	48 0f af c6          	imul   %rsi,%rax
    b206:	48 c1 e8 20          	shr    $0x20,%rax
    b20a:	48 39 c8             	cmp    %rcx,%rax
    b20d:	73 11                	jae    b220 <fwp_main_thread+0x1be0>
    b20f:	49 01 c6             	add    %rax,%r14
    b212:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b216:	0f 84 2f 03 00 00    	je     b54b <fwp_main_thread+0x1f0b>
    b21c:	41 c6 06 01          	movb   $0x1,(%r14)
    b220:	48 89 df             	mov    %rbx,%rdi
    b223:	e9 f6 f7 ff ff       	jmp    aa1e <fwp_main_thread+0x13de>
    b228:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b22f:	00 
    b230:	48 89 d7             	mov    %rdx,%rdi
    b233:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    b238:	e8 93 a5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b23d:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    b242:	e9 e1 fa ff ff       	jmp    ad28 <fwp_main_thread+0x16e8>
    b247:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b24e:	00 00 
    b250:	4d 85 e4             	test   %r12,%r12
    b253:	0f 85 00 f3 ff ff    	jne    a559 <fwp_main_thread+0xf19>
    b259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b260:	31 d2                	xor    %edx,%edx
    b262:	e9 bc f3 ff ff       	jmp    a623 <fwp_main_thread+0xfe3>
    b267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b26e:	00 00 
    b270:	48 c1 e2 10          	shl    $0x10,%rdx
    b274:	be 02 00 00 00       	mov    $0x2,%esi
    b279:	bf 08 00 00 00       	mov    $0x8,%edi
    b27e:	48 09 d3             	or     %rdx,%rbx
    b281:	e8 8a ac ff ff       	call   5f10 <fwp_heap_alloc>
    b286:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    b28d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b294:	49 89 c6             	mov    %rax,%r14
    b297:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b29e:	48 c1 e2 10          	shl    $0x10,%rdx
    b2a2:	48 39 d0             	cmp    %rdx,%rax
    b2a5:	73 b9                	jae    b260 <fwp_main_thread+0x1c20>
    b2a7:	48 89 c2             	mov    %rax,%rdx
    b2aa:	48 c1 ea 10          	shr    $0x10,%rdx
    b2ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2b2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    b2b9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2bd:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b2c1:	4d 85 ed             	test   %r13,%r13
    b2c4:	0f 84 ea f2 ff ff    	je     a5b4 <fwp_main_thread+0xf74>
    b2ca:	0f b6 0a             	movzbl (%rdx),%ecx
    b2cd:	45 31 e4             	xor    %r12d,%r12d
    b2d0:	80 f9 02             	cmp    $0x2,%cl
    b2d3:	0f 85 4d f2 ff ff    	jne    a526 <fwp_main_thread+0xee6>
    b2d9:	66 85 c0             	test   %ax,%ax
    b2dc:	0f 85 72 f2 ff ff    	jne    a554 <fwp_main_thread+0xf14>
    b2e2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b2e7:	0f 85 62 f2 ff ff    	jne    a54f <fwp_main_thread+0xf0f>
    b2ed:	4c 89 ef             	mov    %r13,%rdi
    b2f0:	e8 db a4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b2f5:	e9 55 f2 ff ff       	jmp    a54f <fwp_main_thread+0xf0f>
    b2fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b300:	48 8d 59 01          	lea    0x1(%rcx),%rbx
    b304:	49 39 de             	cmp    %rbx,%r14
    b307:	7c 3a                	jl     b343 <fwp_main_thread+0x1d03>
    b309:	4d 85 c0             	test   %r8,%r8
    b30c:	0f 84 1c 06 00 00    	je     b92e <fwp_main_thread+0x22ee>
    b312:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b317:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b31e:	00 
    b31f:	31 f6                	xor    %esi,%esi
    b321:	4c 89 c7             	mov    %r8,%rdi
    b324:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    b329:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b32e:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b333:	e9 5f f4 ff ff       	jmp    a797 <fwp_main_thread+0x1157>
    b338:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b33f:	00 
    b340:	4c 89 cb             	mov    %r9,%rbx
    b343:	4d 85 f6             	test   %r14,%r14
    b346:	4c 0f 44 f3          	cmove  %rbx,%r14
    b34a:	eb 29                	jmp    b375 <fwp_main_thread+0x1d35>
    b34c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b353:	00 00 
    b355:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b35c:	00 00 00 00 
    b360:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    b364:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    b36b:	48 89 d8             	mov    %rbx,%rax
    b36e:	48 0f 4c c2          	cmovl  %rdx,%rax
    b372:	49 89 c6             	mov    %rax,%r14
    b375:	49 39 de             	cmp    %rbx,%r14
    b378:	7c e6                	jl     b360 <fwp_main_thread+0x1d20>
    b37a:	4d 85 c0             	test   %r8,%r8
    b37d:	0f 84 e5 01 00 00    	je     b568 <fwp_main_thread+0x1f28>
    b383:	4c 89 c7             	mov    %r8,%rdi
    b386:	ba 03 00 00 00       	mov    $0x3,%edx
    b38b:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b390:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    b397:	00 
    b398:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b39d:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b3a2:	e8 e9 9d ff ff       	call   5190 <ad_raw_realloc>
    b3a7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b3ac:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b3b2:	48 85 c0             	test   %rax,%rax
    b3b5:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b3bb:	49 89 c0             	mov    %rax,%r8
    b3be:	0f 84 bc 02 00 00    	je     b680 <fwp_main_thread+0x2040>
    b3c4:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    b3cb:	00 
    b3cc:	4c 89 b4 24 00 01 00 	mov    %r14,0x100(%rsp)
    b3d3:	00 
    b3d4:	48 85 db             	test   %rbx,%rbx
    b3d7:	0f 85 e5 02 00 00    	jne    b6c2 <fwp_main_thread+0x2082>
    b3dd:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b3e4:	4d 85 e4             	test   %r12,%r12
    b3e7:	0f 88 dc f3 ff ff    	js     a7c9 <fwp_main_thread+0x1189>
    b3ed:	44 89 e1             	mov    %r12d,%ecx
    b3f0:	e9 c0 f3 ff ff       	jmp    a7b5 <fwp_main_thread+0x1175>
    b3f5:	0f 1f 00             	nopl   (%rax)
    b3f8:	48 8d 3d 61 ba ff ff 	lea    -0x459f(%rip),%rdi        # 6e60 <fwp_tape_finish>
    b3ff:	e8 ec 07 00 00       	call   bbf0 <atexit>
    b404:	85 c0                	test   %eax,%eax
    b406:	0f 85 3b 05 00 00    	jne    b947 <fwp_main_thread+0x2307>
    b40c:	c7 05 4a 4c 00 00 01 	movl   $0x1,0x4c4a(%rip)        # 10060 <registered_finish.1>
    b413:	00 00 00 
    b416:	e9 8e ee ff ff       	jmp    a2a9 <fwp_main_thread+0xc69>
    b41b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b420:	66 85 c0             	test   %ax,%ax
    b423:	0f 85 57 fa ff ff    	jne    ae80 <fwp_main_thread+0x1840>
    b429:	e9 24 fa ff ff       	jmp    ae52 <fwp_main_thread+0x1812>
    b42e:	66 90                	xchg   %ax,%ax
    b430:	66 85 c0             	test   %ax,%ax
    b433:	0f 85 35 ee ff ff    	jne    a26e <fwp_main_thread+0xc2e>
    b439:	e9 0a ee ff ff       	jmp    a248 <fwp_main_thread+0xc08>
    b43e:	66 90                	xchg   %ax,%ax
    b440:	4d 39 f1             	cmp    %r14,%r9
    b443:	0f 8f f7 fe ff ff    	jg     b340 <fwp_main_thread+0x1d00>
    b449:	4d 85 c0             	test   %r8,%r8
    b44c:	0f 85 64 02 00 00    	jne    b6b6 <fwp_main_thread+0x2076>
    b452:	4d 85 c9             	test   %r9,%r9
    b455:	0f 85 d3 04 00 00    	jne    b92e <fwp_main_thread+0x22ee>
    b45b:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b462:	e9 62 f3 ff ff       	jmp    a7c9 <fwp_main_thread+0x1189>
    b467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b46e:	00 00 
    b470:	66 85 c0             	test   %ax,%ax
    b473:	0f 85 e5 f4 ff ff    	jne    a95e <fwp_main_thread+0x131e>
    b479:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b47e:	0f 85 d5 f4 ff ff    	jne    a959 <fwp_main_thread+0x1319>
    b484:	4c 89 ef             	mov    %r13,%rdi
    b487:	e8 44 a3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b48c:	e9 c8 f4 ff ff       	jmp    a959 <fwp_main_thread+0x1319>
    b491:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b498:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b49f:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b4a6:	4c 89 f0             	mov    %r14,%rax
    b4a9:	4d 8b 66 10          	mov    0x10(%r14),%r12
    b4ad:	48 29 c8             	sub    %rcx,%rax
    b4b0:	48 c1 e2 10          	shl    $0x10,%rdx
    b4b4:	48 39 d0             	cmp    %rdx,%rax
    b4b7:	73 65                	jae    b51e <fwp_main_thread+0x1ede>
    b4b9:	48 89 c7             	mov    %rax,%rdi
    b4bc:	48 c1 ef 10          	shr    $0x10,%rdi
    b4c0:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    b4c4:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b4c8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b4cc:	48 85 ff             	test   %rdi,%rdi
    b4cf:	74 4d                	je     b51e <fwp_main_thread+0x1ede>
    b4d1:	44 0f b6 06          	movzbl (%rsi),%r8d
    b4d5:	41 80 f8 02          	cmp    $0x2,%r8b
    b4d9:	0f 84 68 02 00 00    	je     b747 <fwp_main_thread+0x2107>
    b4df:	41 80 f8 01          	cmp    $0x1,%r8b
    b4e3:	75 39                	jne    b51e <fwp_main_thread+0x1ede>
    b4e5:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    b4e9:	0f b7 c0             	movzwl %ax,%eax
    b4ec:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b4ef:	49 0f af c0          	imul   %r8,%rax
    b4f3:	48 c1 e8 20          	shr    $0x20,%rax
    b4f7:	48 39 f0             	cmp    %rsi,%rax
    b4fa:	73 22                	jae    b51e <fwp_main_thread+0x1ede>
    b4fc:	48 01 c7             	add    %rax,%rdi
    b4ff:	80 3f 01             	cmpb   $0x1,(%rdi)
    b502:	75 1a                	jne    b51e <fwp_main_thread+0x1ede>
    b504:	4c 89 f7             	mov    %r14,%rdi
    b507:	e8 04 a5 ff ff       	call   5a10 <fwp_mem_free>
    b50c:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b513:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b51a:	48 c1 e2 10          	shl    $0x10,%rdx
    b51e:	4c 89 e0             	mov    %r12,%rax
    b521:	48 29 c8             	sub    %rcx,%rax
    b524:	48 39 d0             	cmp    %rdx,%rax
    b527:	0f 83 53 f9 ff ff    	jae    ae80 <fwp_main_thread+0x1840>
    b52d:	4d 89 e6             	mov    %r12,%r14
    b530:	e9 d4 f8 ff ff       	jmp    ae09 <fwp_main_thread+0x17c9>
    b535:	0f 1f 00             	nopl   (%rax)
    b538:	66 85 c0             	test   %ax,%ax
    b53b:	0f 85 df fc ff ff    	jne    b220 <fwp_main_thread+0x1be0>
    b541:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b545:	0f 85 d1 fc ff ff    	jne    b21c <fwp_main_thread+0x1bdc>
    b54b:	4c 89 f7             	mov    %r14,%rdi
    b54e:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    b553:	e8 78 a2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b558:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    b55d:	e9 ba fc ff ff       	jmp    b21c <fwp_main_thread+0x1bdc>
    b562:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b568:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    b56f:	ff ff 1f 
    b572:	49 8d 46 ff          	lea    -0x1(%r14),%rax
    b576:	48 39 c2             	cmp    %rax,%rdx
    b579:	0f 82 31 04 00 00    	jb     b9b0 <fwp_main_thread+0x2370>
    b57f:	48 8d 05 3a 4c 04 00 	lea    0x44c3a(%rip),%rax        # 501c0 <ad_raw_blocks>
    b586:	45 31 ed             	xor    %r13d,%r13d
    b589:	eb 2a                	jmp    b5b5 <fwp_main_thread+0x1f75>
    b58b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b592:	00 00 00 
    b595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b59c:	00 00 00 00 
    b5a0:	49 83 c5 01          	add    $0x1,%r13
    b5a4:	48 83 c0 18          	add    $0x18,%rax
    b5a8:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    b5af:	0f 84 8c 02 00 00    	je     b841 <fwp_main_thread+0x2201>
    b5b5:	48 83 38 00          	cmpq   $0x0,(%rax)
    b5b9:	75 e5                	jne    b5a0 <fwp_main_thread+0x1f60>
    b5bb:	be 08 00 00 00       	mov    $0x8,%esi
    b5c0:	4c 89 f7             	mov    %r14,%rdi
    b5c3:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b5c8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b5cd:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b5d2:	e8 39 7f ff ff       	call   3510 <calloc@plt>
    b5d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b5dc:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b5e2:	48 8d 15 d7 4b 04 00 	lea    0x44bd7(%rip),%rdx        # 501c0 <ad_raw_blocks>
    b5e9:	48 85 c0             	test   %rax,%rax
    b5ec:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b5f2:	0f 84 88 00 00 00    	je     b680 <fwp_main_thread+0x2040>
    b5f8:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    b5fd:	48 89 c6             	mov    %rax,%rsi
    b600:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
    b605:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    b609:	b9 03 00 00 00       	mov    $0x3,%ecx
    b60e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b613:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    b61a:	00 
    b61b:	e8 e0 85 ff ff       	call   3c00 <ad_raw_record>
    b620:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
    b625:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    b62a:	e9 95 fd ff ff       	jmp    b3c4 <fwp_main_thread+0x1d84>
    b62f:	90                   	nop
    b630:	66 85 c0             	test   %ax,%ax
    b633:	0f 85 7c eb ff ff    	jne    a1b5 <fwp_main_thread+0xb75>
    b639:	e9 3d eb ff ff       	jmp    a17b <fwp_main_thread+0xb3b>
    b63e:	66 90                	xchg   %ax,%ax
    b640:	66 85 c0             	test   %ax,%ax
    b643:	0f 85 f7 f9 ff ff    	jne    b040 <fwp_main_thread+0x1a00>
    b649:	0f b6 03             	movzbl (%rbx),%eax
    b64c:	84 c0                	test   %al,%al
    b64e:	0f 85 ca f9 ff ff    	jne    b01e <fwp_main_thread+0x19de>
    b654:	e9 e7 f9 ff ff       	jmp    b040 <fwp_main_thread+0x1a00>
    b659:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b660:	66 85 c0             	test   %ax,%ax
    b663:	0f 85 1a f9 ff ff    	jne    af83 <fwp_main_thread+0x1943>
    b669:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b66d:	0f 85 0c f9 ff ff    	jne    af7f <fwp_main_thread+0x193f>
    b673:	4c 89 f7             	mov    %r14,%rdi
    b676:	e8 55 a1 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b67b:	e9 ff f8 ff ff       	jmp    af7f <fwp_main_thread+0x193f>
    b680:	48 85 db             	test   %rbx,%rbx
    b683:	0f 85 a5 02 00 00    	jne    b92e <fwp_main_thread+0x22ee>
    b689:	45 31 c0             	xor    %r8d,%r8d
    b68c:	e9 4c fd ff ff       	jmp    b3dd <fwp_main_thread+0x1d9d>
    b691:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b695:	e9 d1 e1 ff ff       	jmp    986b <fwp_main_thread+0x22b>
    b69a:	be 68 00 00 00       	mov    $0x68,%esi
    b69f:	b9 01 00 00 00       	mov    $0x1,%ecx
    b6a4:	e9 81 ec ff ff       	jmp    a32a <fwp_main_thread+0xcea>
    b6a9:	4c 89 e7             	mov    %r12,%rdi
    b6ac:	e8 5f a3 ff ff       	call   5a10 <fwp_mem_free>
    b6b1:	e9 8a f9 ff ff       	jmp    b040 <fwp_main_thread+0x1a00>
    b6b6:	4d 85 c9             	test   %r9,%r9
    b6b9:	0f 84 9c fd ff ff    	je     b45b <fwp_main_thread+0x1e1b>
    b6bf:	4c 89 cb             	mov    %r9,%rbx
    b6c2:	4c 89 c7             	mov    %r8,%rdi
    b6c5:	31 f6                	xor    %esi,%esi
    b6c7:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b6cc:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    b6d0:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b6d7:	00 
    b6d8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b6dd:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b6e2:	e8 c9 7d ff ff       	call   34b0 <memset@plt>
    b6e7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b6ec:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b6f2:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b6f8:	49 89 c0             	mov    %rax,%r8
    b6fb:	e9 e4 fc ff ff       	jmp    b3e4 <fwp_main_thread+0x1da4>
    b700:	66 85 c0             	test   %ax,%ax
    b703:	0f 85 ed e9 ff ff    	jne    a0f6 <fwp_main_thread+0xab6>
    b709:	e9 ca e9 ff ff       	jmp    a0d8 <fwp_main_thread+0xa98>
    b70e:	66 85 c0             	test   %ax,%ax
    b711:	0f 85 8a e8 ff ff    	jne    9fa1 <fwp_main_thread+0x961>
    b717:	e9 75 e8 ff ff       	jmp    9f91 <fwp_main_thread+0x951>
    b71c:	66 85 c0             	test   %ax,%ax
    b71f:	0f 85 1b e9 ff ff    	jne    a040 <fwp_main_thread+0xa00>
    b725:	e9 06 e9 ff ff       	jmp    a030 <fwp_main_thread+0x9f0>
    b72a:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    b72f:	4c 8b 34 24          	mov    (%rsp),%r14
    b733:	31 db                	xor    %ebx,%ebx
    b735:	e9 a1 f6 ff ff       	jmp    addb <fwp_main_thread+0x179b>
    b73a:	4c 89 ef             	mov    %r13,%rdi
    b73d:	e8 8e a0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b742:	e9 1a e7 ff ff       	jmp    9e61 <fwp_main_thread+0x821>
    b747:	66 85 c0             	test   %ax,%ax
    b74a:	0f 85 ce fd ff ff    	jne    b51e <fwp_main_thread+0x1ede>
    b750:	e9 aa fd ff ff       	jmp    b4ff <fwp_main_thread+0x1ebf>
    b755:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    b75a:	48 8b 3c 24          	mov    (%rsp),%rdi
    b75e:	e8 7d c3 ff ff       	call   7ae0 <fwp_drop0>
    b763:	4c 89 f7             	mov    %r14,%rdi
    b766:	e8 75 c3 ff ff       	call   7ae0 <fwp_drop0>
    b76b:	48 c7 05 f2 48 00 00 	movq   $0x0,0x48f2(%rip)        # 10068 <v.2>
    b772:	00 00 00 00 
    b776:	c7 05 f0 48 00 00 01 	movl   $0x1,0x48f0(%rip)        # 10070 <st.3>
    b77d:	00 00 00 
    b780:	e9 32 e0 ff ff       	jmp    97b7 <fwp_main_thread+0x177>
    b785:	4c 89 e2             	mov    %r12,%rdx
    b788:	48 c1 ea 11          	shr    $0x11,%rdx
    b78c:	4c 31 e2             	xor    %r12,%rdx
    b78f:	48 89 d0             	mov    %rdx,%rax
    b792:	48 c1 e8 09          	shr    $0x9,%rax
    b796:	48 31 c2             	xor    %rax,%rdx
    b799:	0f b6 d2             	movzbl %dl,%edx
    b79c:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b7a3:	00 
    b7a4:	48 85 c0             	test   %rax,%rax
    b7a7:	75 20                	jne    b7c9 <fwp_main_thread+0x2189>
    b7a9:	e9 87 00 00 00       	jmp    b835 <fwp_main_thread+0x21f5>
    b7ae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b7b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b7bc:	00 00 00 00 
    b7c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b7c4:	48 85 c0             	test   %rax,%rax
    b7c7:	74 6c                	je     b835 <fwp_main_thread+0x21f5>
    b7c9:	48 89 c2             	mov    %rax,%rdx
    b7cc:	4c 39 20             	cmp    %r12,(%rax)
    b7cf:	75 ef                	jne    b7c0 <fwp_main_thread+0x2180>
    b7d1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b7d5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b7d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b7dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b7e4:	0f 85 96 f6 ff ff    	jne    ae80 <fwp_main_thread+0x1840>
    b7ea:	4c 89 e7             	mov    %r12,%rdi
    b7ed:	e8 de 9f ff ff       	call   57d0 <fwp_rc_forget_slot>
    b7f2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b7f7:	e9 84 f6 ff ff       	jmp    ae80 <fwp_main_thread+0x1840>
    b7fc:	4c 8b 34 24          	mov    (%rsp),%r14
    b800:	31 db                	xor    %ebx,%ebx
    b802:	e9 d4 f5 ff ff       	jmp    addb <fwp_main_thread+0x179b>
    b807:	e8 a4 9e ff ff       	call   56b0 <fwp_rc_wide_dup>
    b80c:	e9 5d ea ff ff       	jmp    a26e <fwp_main_thread+0xc2e>
    b811:	48 89 d8             	mov    %rbx,%rax
    b814:	48 c1 e8 11          	shr    $0x11,%rax
    b818:	48 31 d8             	xor    %rbx,%rax
    b81b:	48 89 c2             	mov    %rax,%rdx
    b81e:	48 c1 ea 09          	shr    $0x9,%rdx
    b822:	48 31 d0             	xor    %rdx,%rax
    b825:	0f b6 d0             	movzbl %al,%edx
    b828:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b82f:	00 
    b830:	48 85 c0             	test   %rax,%rax
    b833:	75 54                	jne    b889 <fwp_main_thread+0x2249>
    b835:	48 8d 3d b4 11 00 00 	lea    0x11b4(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    b83c:	e8 0f 8c ff ff       	call   4450 <fwp_trap>
    b841:	48 8d 3d ca 08 00 00 	lea    0x8ca(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    b848:	e8 b3 87 ff ff       	call   4000 <ad_raw_fail>
    b84d:	e8 5e 9e ff ff       	call   56b0 <fwp_rc_wide_dup>
    b852:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b859:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b860:	48 c1 e2 10          	shl    $0x10,%rdx
    b864:	e9 4c e9 ff ff       	jmp    a1b5 <fwp_main_thread+0xb75>
    b869:	90                   	nop
    b86a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b871:	00 00 00 00 
    b875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b87c:	00 00 00 00 
    b880:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b884:	48 85 c0             	test   %rax,%rax
    b887:	74 ac                	je     b835 <fwp_main_thread+0x21f5>
    b889:	48 89 c2             	mov    %rax,%rdx
    b88c:	48 3b 18             	cmp    (%rax),%rbx
    b88f:	75 ef                	jne    b880 <fwp_main_thread+0x2240>
    b891:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b895:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b899:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b89d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b8a4:	0f 85 96 f7 ff ff    	jne    b040 <fwp_main_thread+0x1a00>
    b8aa:	48 89 df             	mov    %rbx,%rdi
    b8ad:	e8 1e 9f ff ff       	call   57d0 <fwp_rc_forget_slot>
    b8b2:	c6 03 fe             	movb   $0xfe,(%rbx)
    b8b5:	e9 86 f7 ff ff       	jmp    b040 <fwp_main_thread+0x1a00>
    b8ba:	48 8d 3d 57 11 00 00 	lea    0x1157(%rip),%rdi        # ca18 <_IO_stdin_used+0xa18>
    b8c1:	e8 8a 8b ff ff       	call   4450 <fwp_trap>
    b8c6:	48 8d 3d f5 08 00 00 	lea    0x8f5(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    b8cd:	e8 7e 8b ff ff       	call   4450 <fwp_trap>
    b8d2:	4c 89 e7             	mov    %r12,%rdi
    b8d5:	e8 f6 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b8da:	e9 04 e8 ff ff       	jmp    a0e3 <fwp_main_thread+0xaa3>
    b8df:	4c 89 e7             	mov    %r12,%rdi
    b8e2:	e8 e9 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b8e7:	e9 b0 e6 ff ff       	jmp    9f9c <fwp_main_thread+0x95c>
    b8ec:	4c 89 e7             	mov    %r12,%rdi
    b8ef:	e8 dc 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b8f4:	e9 42 e7 ff ff       	jmp    a03b <fwp_main_thread+0x9fb>
    b8f9:	e8 02 7e ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    b8fe:	48 8d 3d 13 12 00 00 	lea    0x1213(%rip),%rdi        # cb18 <_IO_stdin_used+0xb18>
    b905:	e8 46 8b ff ff       	call   4450 <fwp_trap>
    b90a:	48 8d 3d 86 09 00 00 	lea    0x986(%rip),%rdi        # c297 <_IO_stdin_used+0x297>
    b911:	e8 3a 8b ff ff       	call   4450 <fwp_trap>
    b916:	48 8d 3d ce 08 00 00 	lea    0x8ce(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    b91d:	e8 2e 8b ff ff       	call   4450 <fwp_trap>
    b922:	48 8d 3d a4 09 00 00 	lea    0x9a4(%rip),%rdi        # c2cd <_IO_stdin_used+0x2cd>
    b929:	e8 22 8b ff ff       	call   4450 <fwp_trap>
    b92e:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    b935:	00 
    b936:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    b93b:	48 89 05 76 eb 05 00 	mov    %rax,0x5eb76(%rip)        # 6a4b8 <fwp_cleanups>
    b942:	e8 19 99 ff ff       	call   5260 <fwp_tape_buffers_release>
    b947:	48 8b 0d f2 46 00 00 	mov    0x46f2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    b94e:	ba 13 00 00 00       	mov    $0x13,%edx
    b953:	be 01 00 00 00       	mov    $0x1,%esi
    b958:	48 8d 3d a9 06 00 00 	lea    0x6a9(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    b95f:	e8 fc 7c ff ff       	call   3660 <fwrite@plt>
    b964:	31 ff                	xor    %edi,%edi
    b966:	e8 35 7c ff ff       	call   35a0 <fflush@plt>
    b96b:	bf 66 00 00 00       	mov    $0x66,%edi
    b970:	e8 0b 7d ff ff       	call   3680 <_Exit@plt>
    b975:	48 8d 3d 44 11 00 00 	lea    0x1144(%rip),%rdi        # cac0 <_IO_stdin_used+0xac0>
    b97c:	e8 cf 8a ff ff       	call   4450 <fwp_trap>
    b981:	e8 ca 7a ff ff       	call   3450 <__stack_chk_fail@plt>
    b986:	48 8d 3d 5b 11 00 00 	lea    0x115b(%rip),%rdi        # cae8 <_IO_stdin_used+0xae8>
    b98d:	e8 be 8a ff ff       	call   4450 <fwp_trap>
    b992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b998:	48 8d 3d 11 12 00 00 	lea    0x1211(%rip),%rdi        # cbb0 <_IO_stdin_used+0xbb0>
    b99f:	e8 ac 8a ff ff       	call   4450 <fwp_trap>
    b9a4:	48 8d 3d d1 08 00 00 	lea    0x8d1(%rip),%rdi        # c27c <_IO_stdin_used+0x27c>
    b9ab:	e8 50 86 ff ff       	call   4000 <ad_raw_fail>
    b9b0:	48 8d 3d fa 08 00 00 	lea    0x8fa(%rip),%rdi        # c2b1 <_IO_stdin_used+0x2b1>
    b9b7:	e8 44 86 ff ff       	call   4000 <ad_raw_fail>
    b9bc:	48 8d 3d 1a 09 00 00 	lea    0x91a(%rip),%rdi        # c2dd <_IO_stdin_used+0x2dd>
    b9c3:	e8 88 8a ff ff       	call   4450 <fwp_trap>
    b9c8:	48 8d 3d 91 10 00 00 	lea    0x1091(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    b9cf:	e8 7c 8a ff ff       	call   4450 <fwp_trap>
    b9d4:	e9 72 7d ff ff       	jmp    374b <fwp_main_thread.cold>
    b9d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000b9e0 <__divmodti4>:
    b9e0:	f3 0f 1e fa          	endbr64
    b9e4:	55                   	push   %rbp
    b9e5:	49 89 f1             	mov    %rsi,%r9
    b9e8:	49 89 d2             	mov    %rdx,%r10
    b9eb:	48 89 fe             	mov    %rdi,%rsi
    b9ee:	49 89 cb             	mov    %rcx,%r11
    b9f1:	48 89 e5             	mov    %rsp,%rbp
    b9f4:	41 57                	push   %r15
    b9f6:	41 56                	push   %r14
    b9f8:	41 55                	push   %r13
    b9fa:	41 54                	push   %r12
    b9fc:	53                   	push   %rbx
    b9fd:	4c 89 c3             	mov    %r8,%rbx
    ba00:	45 31 c0             	xor    %r8d,%r8d
    ba03:	4d 85 c9             	test   %r9,%r9
    ba06:	79 12                	jns    ba1a <__divmodti4+0x3a>
    ba08:	31 ff                	xor    %edi,%edi
    ba0a:	48 f7 de             	neg    %rsi
    ba0d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    ba14:	4c 19 cf             	sbb    %r9,%rdi
    ba17:	49 89 f9             	mov    %rdi,%r9
    ba1a:	4c 89 d8             	mov    %r11,%rax
    ba1d:	4d 85 db             	test   %r11,%r11
    ba20:	0f 88 1a 01 00 00    	js     bb40 <__divmodti4+0x160>
    ba26:	4c 89 d9             	mov    %r11,%rcx
    ba29:	49 89 f3             	mov    %rsi,%r11
    ba2c:	75 62                	jne    ba90 <__divmodti4+0xb0>
    ba2e:	4d 89 c4             	mov    %r8,%r12
    ba31:	4d 39 d1             	cmp    %r10,%r9
    ba34:	0f 83 46 01 00 00    	jae    bb80 <__divmodti4+0x1a0>
    ba3a:	4c 89 d8             	mov    %r11,%rax
    ba3d:	4c 89 ca             	mov    %r9,%rdx
    ba40:	49 f7 f2             	div    %r10
    ba43:	49 89 c3             	mov    %rax,%r11
    ba46:	31 c0                	xor    %eax,%eax
    ba48:	48 89 d6             	mov    %rdx,%rsi
    ba4b:	31 ff                	xor    %edi,%edi
    ba4d:	4c 89 d9             	mov    %r11,%rcx
    ba50:	48 89 c2             	mov    %rax,%rdx
    ba53:	48 89 c8             	mov    %rcx,%rax
    ba56:	4d 85 e4             	test   %r12,%r12
    ba59:	74 0a                	je     ba65 <__divmodti4+0x85>
    ba5b:	48 f7 d8             	neg    %rax
    ba5e:	48 83 d2 00          	adc    $0x0,%rdx
    ba62:	48 f7 da             	neg    %rdx
    ba65:	4d 85 c0             	test   %r8,%r8
    ba68:	74 0a                	je     ba74 <__divmodti4+0x94>
    ba6a:	48 f7 de             	neg    %rsi
    ba6d:	48 83 d7 00          	adc    $0x0,%rdi
    ba71:	48 f7 df             	neg    %rdi
    ba74:	48 89 33             	mov    %rsi,(%rbx)
    ba77:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    ba7b:	5b                   	pop    %rbx
    ba7c:	41 5c                	pop    %r12
    ba7e:	41 5d                	pop    %r13
    ba80:	41 5e                	pop    %r14
    ba82:	41 5f                	pop    %r15
    ba84:	5d                   	pop    %rbp
    ba85:	c3                   	ret
    ba86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ba8d:	00 00 00 
    ba90:	4d 89 c4             	mov    %r8,%r12
    ba93:	49 39 c1             	cmp    %rax,%r9
    ba96:	0f 82 ce 00 00 00    	jb     bb6a <__divmodti4+0x18a>
    ba9c:	31 ff                	xor    %edi,%edi
    ba9e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    baa3:	48 63 c7             	movslq %edi,%rax
    baa6:	be 40 00 00 00       	mov    $0x40,%esi
    baab:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bab0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bab5:	48 29 c6             	sub    %rax,%rsi
    bab8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    babd:	48 09 c8             	or     %rcx,%rax
    bac0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bac5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    baca:	49 89 c6             	mov    %rax,%r14
    bacd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bad1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bad6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    badb:	49 09 c1             	or     %rax,%r9
    bade:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bae2:	4c 89 c8             	mov    %r9,%rax
    bae5:	49 f7 f6             	div    %r14
    bae8:	48 89 d1             	mov    %rdx,%rcx
    baeb:	49 89 c3             	mov    %rax,%r11
    baee:	49 89 c1             	mov    %rax,%r9
    baf1:	49 f7 e2             	mul    %r10
    baf4:	49 89 c6             	mov    %rax,%r14
    baf7:	49 89 d2             	mov    %rdx,%r10
    bafa:	48 39 d1             	cmp    %rdx,%rcx
    bafd:	72 07                	jb     bb06 <__divmodti4+0x126>
    baff:	75 17                	jne    bb18 <__divmodti4+0x138>
    bb01:	49 39 c7             	cmp    %rax,%r15
    bb04:	73 12                	jae    bb18 <__divmodti4+0x138>
    bb06:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bb0a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bb0e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bb12:	49 89 d2             	mov    %rdx,%r10
    bb15:	49 89 c6             	mov    %rax,%r14
    bb18:	4c 89 f8             	mov    %r15,%rax
    bb1b:	4c 29 f0             	sub    %r14,%rax
    bb1e:	4c 19 d1             	sbb    %r10,%rcx
    bb21:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bb26:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bb2b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bb30:	48 09 c6             	or     %rax,%rsi
    bb33:	48 89 cf             	mov    %rcx,%rdi
    bb36:	31 c0                	xor    %eax,%eax
    bb38:	4c 89 c9             	mov    %r9,%rcx
    bb3b:	e9 10 ff ff ff       	jmp    ba50 <__divmodti4+0x70>
    bb40:	4c 89 d0             	mov    %r10,%rax
    bb43:	4c 89 da             	mov    %r11,%rdx
    bb46:	4d 89 c4             	mov    %r8,%r12
    bb49:	49 89 f3             	mov    %rsi,%r11
    bb4c:	48 f7 d8             	neg    %rax
    bb4f:	49 f7 d4             	not    %r12
    bb52:	48 83 d2 00          	adc    $0x0,%rdx
    bb56:	49 89 c2             	mov    %rax,%r10
    bb59:	48 f7 da             	neg    %rdx
    bb5c:	48 89 d1             	mov    %rdx,%rcx
    bb5f:	0f 84 cc fe ff ff    	je     ba31 <__divmodti4+0x51>
    bb65:	49 39 d1             	cmp    %rdx,%r9
    bb68:	73 46                	jae    bbb0 <__divmodti4+0x1d0>
    bb6a:	4c 89 cf             	mov    %r9,%rdi
    bb6d:	31 c0                	xor    %eax,%eax
    bb6f:	31 c9                	xor    %ecx,%ecx
    bb71:	e9 da fe ff ff       	jmp    ba50 <__divmodti4+0x70>
    bb76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bb7d:	00 00 00 
    bb80:	4d 85 d2             	test   %r10,%r10
    bb83:	75 0d                	jne    bb92 <__divmodti4+0x1b2>
    bb85:	b8 01 00 00 00       	mov    $0x1,%eax
    bb8a:	31 d2                	xor    %edx,%edx
    bb8c:	49 f7 f2             	div    %r10
    bb8f:	49 89 c2             	mov    %rax,%r10
    bb92:	4c 89 c8             	mov    %r9,%rax
    bb95:	31 d2                	xor    %edx,%edx
    bb97:	49 f7 f2             	div    %r10
    bb9a:	49 89 c1             	mov    %rax,%r9
    bb9d:	4c 89 d8             	mov    %r11,%rax
    bba0:	49 f7 f2             	div    %r10
    bba3:	49 89 c3             	mov    %rax,%r11
    bba6:	4c 89 c8             	mov    %r9,%rax
    bba9:	e9 9a fe ff ff       	jmp    ba48 <__divmodti4+0x68>
    bbae:	66 90                	xchg   %ax,%ax
    bbb0:	45 31 f6             	xor    %r14d,%r14d
    bbb3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bbb8:	44 89 f7             	mov    %r14d,%edi
    bbbb:	45 85 f6             	test   %r14d,%r14d
    bbbe:	0f 85 df fe ff ff    	jne    baa3 <__divmodti4+0xc3>
    bbc4:	4c 39 ca             	cmp    %r9,%rdx
    bbc7:	72 17                	jb     bbe0 <__divmodti4+0x200>
    bbc9:	31 c9                	xor    %ecx,%ecx
    bbcb:	48 39 c6             	cmp    %rax,%rsi
    bbce:	73 10                	jae    bbe0 <__divmodti4+0x200>
    bbd0:	4c 89 cf             	mov    %r9,%rdi
    bbd3:	31 c0                	xor    %eax,%eax
    bbd5:	e9 76 fe ff ff       	jmp    ba50 <__divmodti4+0x70>
    bbda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bbe0:	4c 89 de             	mov    %r11,%rsi
    bbe3:	b9 01 00 00 00       	mov    $0x1,%ecx
    bbe8:	48 29 c6             	sub    %rax,%rsi
    bbeb:	49 19 d1             	sbb    %rdx,%r9
    bbee:	eb e0                	jmp    bbd0 <__divmodti4+0x1f0>

000000000000bbf0 <atexit>:
    bbf0:	f3 0f 1e fa          	endbr64
    bbf4:	48 8b 15 0d 44 00 00 	mov    0x440d(%rip),%rdx        # 10008 <__dso_handle>
    bbfb:	31 f6                	xor    %esi,%esi
    bbfd:	e9 3e 7a ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bc04 <_fini>:
    bc04:	f3 0f 1e fa          	endbr64
    bc08:	48 83 ec 08          	sub    $0x8,%rsp
    bc0c:	48 83 c4 08          	add    $0x8,%rsp
    bc10:	c3                   	ret
