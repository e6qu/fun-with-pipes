
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 cf 00 00 	mov    0xcfd1(%rip),%rax        # ffe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 cd 00 00    	push   0xcdf2(%rip)        # fe18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 cd 00 00    	jmp    *0xcdf4(%rip)        # fe20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 cc 00 00    	jmp    *0xcc66(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # fe28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # fe30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # fe38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # fe40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # feb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # feb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ff00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ff08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ff10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ff18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ff20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ff28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ffa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ffa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ffb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ffb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ffc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ffc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 89 00 00 	lea    0x89b8(%rip),%r9        # c0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 89 00 00 	lea    0x89b5(%rip),%r8        # c0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 ab 00 00 	lea    0xaba1(%rip),%rax        # e320 <fwp_fn_table>
    377f:	48 89 05 f2 6c 06 00 	mov    %rax,0x66cf2(%rip)        # 6a478 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 6c 06 00 	mov    %rax,0x66cec(%rip)        # 6a480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 8b 00 00 	lea    0x8b4e(%rip),%rdi        # c2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 bf 5f 00 00 	lea    0x5fbf(%rip),%rdx        # 9820 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 89 00 00 	lea    0x89fe(%rip),%rdi        # c2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 93 00 00 	lea    0x9356(%rip),%rdi        # cc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 10 93 00 00 	lea    0x9310(%rip),%rdi        # cc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 92 00 00 	lea    0x92d4(%rip),%rdi        # cc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 92 00 00 	lea    0x92a0(%rip),%rdi        # cbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b c6 00 00    	call   *0xc65b(%rip)        # ffd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e c6 00 00 	mov    0xc63e(%rip),%rax        # ffd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d c6 00 00 	mov    0xc60d(%rip),%rax        # ffe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea c5 00 00 	cmpq   $0x0,0xc5ea(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 c5 04 00 	lea    0x4c597(%rip),%r8        # 501a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b c5 04 00 	lea    0x4c53b(%rip),%rcx        # 50160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f c5 04 00 	lea    0x4c50f(%rip),%rcx        # 50140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 c5 04 00 	lea    0x4c541(%rip),%rcx        # 50180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 c5 04 	movdqa 0x4c550(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 c5 04 	paddq  0x4c538(%rip),%xmm0        # 501a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f c4 04 00 	cmp    %rax,0x4c49f(%rip)        # 50120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 c4 04 	movq   %xmm0,0x4c495(%rip)        # 50120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e c4 01 00 	add    0x1c43e(%rip),%rdx        # 200f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c c4 01 00 	add    0x1c42c(%rip),%rax        # 200f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 67 06 00 	mov    0x66779(%rip),%rdi        # 6a480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 c3 00 00 	mov    0xc304(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 c2 00 00 	mov    0xc2f1(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 4a 06 00 	mov    0x64ab1(%rip),%rax        # 68800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 43 06 00 	mov    0x643f9(%rip),%rax        # 681c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 43 06 00 	sub    0x643e5(%rip),%rax        # 681c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d 8f 00 00 	lea    0x8f2d(%rip),%rsi        # cd40 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 81 00 00 	lea    0x81c5(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 c1 00 00 	mov    0xc1f2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 5d 06 00 	mov    0x65d8b(%rip),%rax        # 69c10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 5d 06 00 	lea    0x65d84(%rip),%r8        # 69c10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 5d 06 00 	mov    0x65d65(%rip),%rbx        # 69bf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 5d 06 00 	mov    0x65d75(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 5d 06 00 	mov    0x65d11(%rip),%rdi        # 69c00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 5d 06 00 	sub    %rsi,0x65d5a(%rip)        # 69c50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 5c 06 00 	mov    0x65cea(%rip),%rax        # 69bf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 5c 06 00 	add    0x65ca0(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 5c 06 00 	mov    0x65cae(%rip),%rsi        # 69c00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 5c 06 00 	mov    0x65cbc(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 5c 06 00 	mov    %r12,0x65c6b(%rip)        # 69c00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 5c 06 00 	mov    %rbp,0x65c59(%rip)        # 69bf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 5c 06 00 	cmp    %rdi,0x65c3e(%rip)        # 69be8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 5c 06 00 	mov    %rdi,0x65c35(%rip)        # 69be8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 5c 06 00 	sub    %rdi,0x65c79(%rip)        # 69c50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 5c 06 00 	mov    0x65c21(%rip),%rax        # 69c08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 5c 06 00 	lea    0x65c1a(%rip),%r8        # 69c08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff 86 00 00 	lea    0x86ff(%rip),%rdx        # c708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 c0 00 00 	mov    0xc022(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d bf 00 00 	mov    0xbf7d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 7f 00 00 	lea    0x7f34(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 46 06 00 	cmp    0x646c9(%rip),%rdi        # 68800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 46 06 00 	mov    0x6468f(%rip),%rax        # 687e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 46 06 00 	mov    %rdi,0x6466d(%rip)        # 687e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 46 06 00 	mov    %rdi,0x64649(%rip)        # 687e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 80 00 00 	lea    0x8019(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 7e 00 00 	lea    0x7e27(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 bf 04 	movdqa 0x4bf76(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e bf 04 	paddq  0x4bf5e(%rip),%xmm0        # 501a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 be 01 00 	mov    0x1be84(%rip),%r8        # 200f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e be 04 00 	mov    0x4be9e(%rip),%rcx        # 50120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 bd 00 00 	mov    0xbdb7(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 84 00 00 	lea    0x84c5(%rip),%rdx        # c758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 be 04 00 	lea    0x4bee1(%rip),%r15        # 50180 <ad_raw_peak>
    429f:	4c 8d 35 9a be 04 00 	lea    0x4be9a(%rip),%r14        # 50140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 7d 00 00 	lea    0x7d79(%rip),%rax        # c02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 b9 00 	movq   0xb956(%rip),%xmm0        # fc10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f be 04 00 	lea    0x4be9f(%rip),%r13        # 50160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 7d 00 00 	lea    0x7d6f(%rip),%rax        # c03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 b9 00 	movq   0xb936(%rip),%xmm0        # fc18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 bd 00 00 	mov    0xbd33(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 7d 00 00 	lea    0x7d0c(%rip),%rcx        # c020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d 84 00 00 	lea    0x849d(%rip),%rdx        # c7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 bd 00 00 	mov    0xbd04(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 7c 00 00 	lea    0x7cf8(%rip),%rdi        # c045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 bd 01 00 	cmpq   $0x0,0x1bda6(%rip)        # 20100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd bd 01 00 	mov    0x1bdbd(%rip),%r8        # 20120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be bd 01 00 	mov    0x1bdbe(%rip),%r9        # 20128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af bd 01 00 	lea    0x1bdaf(%rip),%rbx        # 20120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 7c 00 00 	lea    0x7cf4(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 bd 01 00 	mov    0x1bdb1(%rip),%rax        # 20130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 7c 00 00 	lea    0x7c9a(%rip),%r12        # c020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 bc 00 00 	mov    0xbc89(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 84 00 00 	lea    0x8439(%rip),%rdx        # c7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 bd 01 00 	cmp    0x1bd33(%rip),%rbp        # 20100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 bc 00 00 	mov    0xbc58(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 7c 00 00 	lea    0x7c5b(%rip),%rdi        # c059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 bc 00 00 	mov    0xbc23(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 83 00 00 	lea    0x8394(%rip),%rdx        # c7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 7c 00 00 	lea    0x7c40(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea 82 00 00 	lea    0x82ea(%rip),%rdi        # c730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 bb 00 00 	mov    0xbbc8(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 7b 00 00 	lea    0x7bdf(%rip),%rdx        # c05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 bb 00 00 	mov    0xbbb0(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ba 00 00 	mov    0xbac1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 7a 00 00 	lea    0x7a78(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 7a 00 00 	lea    0x7ac0(%rip),%rdi        # c06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 7a 00 00 	lea    0x7a48(%rip),%rdi        # c087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 81 00 00 	lea    0x81e8(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 87 00 	movdqa 0x8720(%rip),%xmm0        # cd90 <msg.4+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 5d 06 00 	add    0x65daa(%rip),%rax        # 6a478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c 81 00 00 	lea    0x813c(%rip),%rdi        # c860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 b9 01 00 	cmp    %rax,0x1b9a5(%rip)        # 200e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 b9 01 00 	add    0x1b9a0(%rip),%rax        # 200f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 81 00 00 	lea    0x8125(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 79 00 00 	lea    0x7920(%rip),%r8        # c0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 77 00 00 	lea    0x7775(%rip),%r8        # c0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 76 00 00 	lea    0x7612(%rip),%r8        # c0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 73 00 00 	lea    0x73ea(%rip),%rdi        # c0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 75 00 00 	lea    0x7554(%rip),%rsi        # c242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 4e 06 00 	mov    0x64e85(%rip),%r9        # 69be8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 4e 06 00 	mov    0x64ede(%rip),%r8        # 69c48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f 7b 00 00 	lea    0x7b6f(%rip),%rdx        # c8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 4e 06 00 	mov    0x64ec6(%rip),%rcx        # 69c40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 4e 06 	movsd  0x64ed4(%rip),%xmm1        # 69c60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 4e 06 	movsd  0x64ec4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 b2 00 00 	mov    0xb2a5(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 7f 00 	movdqa 0x7fc8(%rip),%xmm0        # cda0 <msg.4+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 49 06 00 	lea    0x6497f(%rip),%rax        # 69760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 7f 00 	movdqa 0x7ff1(%rip),%xmm2        # cde0 <msg.4+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 49 06 00 	movaps %xmm0,0x64925(%rip)        # 69720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad 7f 00 	movdqa 0x7fad(%rip),%xmm0        # cdb0 <msg.4+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 4d 06 00 01 	movl   $0x1,0x64db3(%rip)        # 69bc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 49 06 00 	movaps %xmm0,0x64913(%rip)        # 69730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b 7f 00 	movdqa 0x7f9b(%rip),%xmm0        # cdc0 <msg.4+0x80>
    4e24:	00 
    4e25:	0f 29 05 14 49 06 00 	movaps %xmm0,0x64914(%rip)        # 69740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c 7f 00 	movdqa 0x7f9c(%rip),%xmm0        # cdd0 <msg.4+0x90>
    4e33:	00 
    4e34:	0f 29 05 15 49 06 00 	movaps %xmm0,0x64915(%rip)        # 69750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 39 06 00 	lea    0x63995(%rip),%r8        # 68820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 4c 06 00 	mov    %rax,0x64cb0(%rip)        # 69bd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 4c 06 00 	mov    %r12,0x64c8e(%rip)        # 69be0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 4c 06 00 	mov    %rax,0x64c77(%rip)        # 69bd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 4c 06 00 	mov    %rbx,0x64c90(%rip)        # 69bf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 4c 06 00 	mov    %rsi,0x64cb9(%rip)        # 69c20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 71 00 00 	lea    0x7174(%rip),%rdi        # c0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 4c 06 00 	mov    %rax,0x64c98(%rip)        # 69c18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 4c 06 00    	mov    %eax,0x64c1c(%rip)        # 69bc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 38 06 00 	mov    0x6380c(%rip),%r8        # 687e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 37 06 00 	mov    %rbx,0x6373c(%rip)        # 687e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 37 06 00 	mov    %r8,0x63728(%rip)        # 687e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 b0 04 00 	lea    0x4b0e9(%rip),%rcx        # 501c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 b0 04 00 	lea    0x4b098(%rip),%rcx        # 501a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 6f 00 00 	lea    0x6fc2(%rip),%rdi        # c0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 b0 04 00 	lea    0x4b016(%rip),%r12        # 501c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 6e 00 00 	lea    0x6ee8(%rip),%rax        # c112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 6e 00 00 	lea    0x6ecc(%rip),%rdx        # c0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 6f 00 00 	lea    0x6f04(%rip),%rdi        # c148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 6e 00 00 	lea    0x6edd(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 6e 00 00 	lea    0x6eaa(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae ad 01 00 	lea    0x1adae(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 ad 01 00 	movaps %xmm0,0x1ad96(%rip)        # 200a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 ad 01 00 	mov    %rsi,0x1ad72(%rip)        # 20088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 ad 01 00 	movaps %xmm0,0x1ad93(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 ad 01 00 	movaps %xmm0,0x1ad97(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 ad 01 00 	mov    %rax,0x1ad98(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 6e 00 00 	lea    0x6e09(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d ad 01 00 	mov    0x1ad1d(%rip),%rsi        # 20088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d ad 01 00 	imul   $0x68,0x1ad6d(%rip),%rdx        # 200e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 ae 04 00 	cmp    0x4ae26(%rip),%rdx        # 501a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 ae 04 00 	mov    0x4ae25(%rip),%rax        # 501a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f ae 04 00 	add    0x4ae1f(%rip),%rax        # 501b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 ae 04 00 	add    0x4ae20(%rip),%rax        # 501b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c ad 01 00 	mov    0x1ad5c(%rip),%rcx        # 20100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 ad 01 00 	mov    %rdi,0x1ad45(%rip)        # 20100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 ad 01 00 	lea    0x1ad57(%rip),%rcx        # 20120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 72 75 00 00 	lea    0x7572(%rip),%rdi        # c968 <_IO_stdin_used+0x968>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 6d 00 00 	lea    0x6d6f(%rip),%rdi        # c171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 33 06 00 	mov    0x633a7(%rip),%rbx        # 687d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a ab 00 00 	mov    0xab0a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 5b 74 00 00 	lea    0x745b(%rip),%rdi        # c998 <_IO_stdin_used+0x998>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 32 06 00 	mov    0x6326d(%rip),%rax        # 687e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 32 06 00 	mov    %rdx,0x63247(%rip)        # 687e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 31 06 00 	mov    0x63194(%rip),%rbx        # 687d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 31 06 00 	mov    %rbx,0x63151(%rip)        # 687d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 31 06 00 	mov    %rdx,0x63151(%rip)        # 687e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 31 06 00 	lea    0x63166(%rip),%rsi        # 68820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 4c 06 00 	addq   $0x1,0x64ce5(%rip)        # 6a468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 2f 72 00 00 	lea    0x722f(%rip),%rdi        # c9c8 <_IO_stdin_used+0x9c8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 40 72 00 00 	lea    0x7240(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 69 00 00 	lea    0x69d2(%rip),%rdi        # c18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 30 06 00 	lea    0x6301e(%rip),%rcx        # 68820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 4c 06 00 	subq   $0x1,0x64c1f(%rip)        # 6a468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 9b 71 00 00 	lea    0x719b(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 4c 06 00 	cmpq   $0x0,0x64c00(%rip)        # 6a468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 4b 06 00 	sub    %rax,0x64b55(%rip)        # 6a470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 4b 06 00 	add    %r12,0x64b33(%rip)        # 6a470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 42 06 00 	mov    0x6428f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 2e 06 00 	lea    0x62e8c(%rip),%rax        # 68820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 41 06 00 	add    0x641e3(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 41 06 00 	mov    0x641b0(%rip),%rsi        # 69bd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 41 06 00 	mov    0x641d1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 41 06 00 	add    0x641c5(%rip),%r8        # 69c18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 41 06 	addsd  0x6418d(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 2d 06 00 	lea    0x62d42(%rip),%rax        # 68820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 41 06 00 	sub    %rdi,0x6414c(%rip)        # 69c40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 41 06 	movsd  %xmm0,0x64164(%rip)        # 69c60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 41 06 00 	sub    %rdx,0x6411e(%rip)        # 69c40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 41 06 	addsd  0x64124(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 41 06 	movsd  %xmm0,0x64118(%rip)        # 69c60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 40 06 00 	mov    0x640af(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 40 06 00 	add    %rcx,0x640a9(%rip)        # 69c50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 40 06 00 	cmp    0x64062(%rip),%r9        # 69c10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 40 06 00 	mov    %r9,0x64059(%rip)        # 69c10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 40 06 00 	cmp    0x6404a(%rip),%r9        # 69c08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 40 06 00 	mov    %r9,0x6403d(%rip)        # 69c08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 3f 06 00 	add    0x63f53(%rip),%rdi        # 69c18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 2b 06 00 	lea    0x62b30(%rip),%r15        # 68820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 3e 06 00 	add    0x63ea0(%rip),%r12        # 69bd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 3e 06 00 	add    0x63ef9(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 3e 06 00 	cmp    %rax,0x63ef8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 3e 06 00 	mov    %rax,0x63ee9(%rip)        # 69c40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 3e 06 00 	mov    %rax,0x63ee8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 3e 06 	addsd  0x63ee4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 3e 06 	movsd  %xmm0,0x63edc(%rip)        # 69c58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 3e 06 00    	mov    0x63e23(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 2a 06 00 	lea    0x62a5f(%rip),%rdi        # 68820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 3e 06 00 	add    0x63e18(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 3e 06 00 	cmp    %rax,0x63e13(%rip)        # 69c48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 3e 06 00 	mov    %rax,0x63e04(%rip)        # 69c40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 3e 06 00 	mov    %rax,0x63e03(%rip)        # 69c48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 3d 06 	addsd  0x63dff(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 3d 06 	movsd  %xmm0,0x63df7(%rip)        # 69c58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 45 06 00    	mov    0x645ca(%rip),%ebx        # 6a4e8 <iteration_active>
    5f1e:	8b 05 a0 3c 06 00    	mov    0x63ca0(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 28 06 00 	lea    0x628d4(%rip),%rax        # 68820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 3c 06 00 	add    0x63c8e(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 3c 06 00 	cmp    %rax,0x63c89(%rip)        # 69c48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 3c 06 00 	mov    %rax,0x63c7a(%rip)        # 69c40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 3c 06 00 	mov    %rax,0x63c79(%rip)        # 69c48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 3c 06 	addsd  0x63c78(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 3c 06 	movsd  %xmm0,0x63c70(%rip)        # 69c58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 3c 06 00 	mov    0x63c4d(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 44 06 	subsd  0x644bb(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 44 06 	comisd 0x644ab(%rip),%xmm0        # 6a4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 44 06 	movsd  %xmm0,0x644a1(%rip)        # 6a4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 44 06 00 	addq   $0x1,0x644a4(%rip)        # 6a4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 44 06 00 	add    %rdi,0x64495(%rip)        # 6a4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_data.part.0.constprop.0>:
    6100:	41 56                	push   %r14
    6102:	8b 05 bc 3a 06 00    	mov    0x63abc(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    6108:	41 89 fe             	mov    %edi,%r14d
    610b:	41 55                	push   %r13
    610d:	44 8b 2d d4 43 06 00 	mov    0x643d4(%rip),%r13d        # 6a4e8 <iteration_active>
    6114:	41 54                	push   %r12
    6116:	49 89 f4             	mov    %rsi,%r12
    6119:	55                   	push   %rbp
    611a:	53                   	push   %rbx
    611b:	45 85 ed             	test   %r13d,%r13d
    611e:	0f 84 1c 01 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x140>
    6124:	48 83 05 b4 43 06 00 	addq   $0x1,0x643b4(%rip)        # 6a4e0 <iteration_requests>
    612b:	01 
    612c:	48 83 05 a4 43 06 00 	addq   $0x18,0x643a4(%rip)        # 6a4d8 <iteration_bytes>
    6133:	18 
    6134:	85 c0                	test   %eax,%eax
    6136:	0f 84 8c 01 00 00    	je     62c8 <fwp_data.part.0.constprop.0+0x1c8>
    613c:	0f b6 05 7f 36 06 00 	movzbl 0x6367f(%rip),%eax        # 697c2 <fwp_heap+0xfa2>
    6143:	48 8d 15 d6 26 06 00 	lea    0x626d6(%rip),%rdx        # 68820 <fwp_heap>
    614a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6151:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6155:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6159:	48 8b 18             	mov    (%rax),%rbx
    615c:	48 85 db             	test   %rbx,%rbx
    615f:	0f 84 fb 00 00 00    	je     6260 <fwp_data.part.0.constprop.0+0x160>
    6165:	48 8b 13             	mov    (%rbx),%rdx
    6168:	48 f7 d2             	not    %rdx
    616b:	48 89 10             	mov    %rdx,(%rax)
    616e:	48 83 fd 18          	cmp    $0x18,%rbp
    6172:	76 1b                	jbe    618f <fwp_data.part.0.constprop.0+0x8f>
    6174:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6178:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    617c:	31 f6                	xor    %esi,%esi
    617e:	48 c1 e8 03          	shr    $0x3,%rax
    6182:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6189:	00 
    618a:	e8 21 d3 ff ff       	call   34b0 <memset@plt>
    618f:	48 89 e8             	mov    %rbp,%rax
    6192:	48 03 05 a7 3a 06 00 	add    0x63aa7(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    6199:	0f 82 3d 01 00 00    	jb     62dc <fwp_data.part.0.constprop.0+0x1dc>
    619f:	48 39 05 a2 3a 06 00 	cmp    %rax,0x63aa2(%rip)        # 69c48 <fwp_heap+0x1428>
    61a6:	48 89 05 93 3a 06 00 	mov    %rax,0x63a93(%rip)        # 69c40 <fwp_heap+0x1420>
    61ad:	73 07                	jae    61b6 <fwp_data.part.0.constprop.0+0xb6>
    61af:	48 89 05 92 3a 06 00 	mov    %rax,0x63a92(%rip)        # 69c48 <fwp_heap+0x1428>
    61b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61ba:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    61bf:	f2 0f 58 05 91 3a 06 	addsd  0x63a91(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    61c6:	00 
    61c7:	f2 0f 11 05 89 3a 06 	movsd  %xmm0,0x63a89(%rip)        # 69c58 <fwp_heap+0x1438>
    61ce:	00 
    61cf:	45 85 ed             	test   %r13d,%r13d
    61d2:	74 33                	je     6207 <fwp_data.part.0.constprop.0+0x107>
    61d4:	48 8b 05 65 3a 06 00 	mov    0x63a65(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    61db:	48 85 c0             	test   %rax,%rax
    61de:	0f 88 a4 00 00 00    	js     6288 <fwp_data.part.0.constprop.0+0x188>
    61e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61e8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61ed:	f2 0f 5c 05 d3 42 06 	subsd  0x642d3(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    61f4:	00 
    61f5:	66 0f 2f 05 c3 42 06 	comisd 0x642c3(%rip),%xmm0        # 6a4c0 <iteration_peak>
    61fc:	00 
    61fd:	76 08                	jbe    6207 <fwp_data.part.0.constprop.0+0x107>
    61ff:	f2 0f 11 05 b9 42 06 	movsd  %xmm0,0x642b9(%rip)        # 6a4c0 <iteration_peak>
    6206:	00 
    6207:	b8 02 00 00 00       	mov    $0x2,%eax
    620c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6211:	66 0f 6e c8          	movd   %eax,%xmm1
    6215:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6219:	66 0f d6 03          	movq   %xmm0,(%rbx)
    621d:	49 8b 04 24          	mov    (%r12),%rax
    6221:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6225:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    622a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    622e:	48 89 d8             	mov    %rbx,%rax
    6231:	5b                   	pop    %rbx
    6232:	5d                   	pop    %rbp
    6233:	41 5c                	pop    %r12
    6235:	41 5d                	pop    %r13
    6237:	41 5e                	pop    %r14
    6239:	c3                   	ret
    623a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6240:	85 c0                	test   %eax,%eax
    6242:	0f 85 f4 fe ff ff    	jne    613c <fwp_data.part.0.constprop.0+0x3c>
    6248:	31 f6                	xor    %esi,%esi
    624a:	bf 18 00 00 00       	mov    $0x18,%edi
    624f:	e8 bc fc ff ff       	call   5f10 <fwp_heap_alloc>
    6254:	48 89 c3             	mov    %rax,%rbx
    6257:	eb ae                	jmp    6207 <fwp_data.part.0.constprop.0+0x107>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6260:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6264:	48 85 db             	test   %rbx,%rbx
    6267:	74 47                	je     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6269:	48 8b 50 10          	mov    0x10(%rax),%rdx
    626d:	48 29 da             	sub    %rbx,%rdx
    6270:	48 39 ea             	cmp    %rbp,%rdx
    6273:	72 3b                	jb     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6275:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    627d:	e9 ec fe ff ff       	jmp    616e <fwp_data.part.0.constprop.0+0x6e>
    6282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6288:	48 89 c2             	mov    %rax,%rdx
    628b:	83 e0 01             	and    $0x1,%eax
    628e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6292:	48 d1 ea             	shr    $1,%rdx
    6295:	48 09 c2             	or     %rax,%rdx
    6298:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    629d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    62a1:	e9 47 ff ff ff       	jmp    61ed <fwp_data.part.0.constprop.0+0xed>
    62a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ad:	00 00 00 
    62b0:	31 f6                	xor    %esi,%esi
    62b2:	bf 18 00 00 00       	mov    $0x18,%edi
    62b7:	e8 54 fc ff ff       	call   5f10 <fwp_heap_alloc>
    62bc:	48 89 c3             	mov    %rax,%rbx
    62bf:	e9 0b ff ff ff       	jmp    61cf <fwp_data.part.0.constprop.0+0xcf>
    62c4:	0f 1f 40 00          	nopl   0x0(%rax)
    62c8:	31 f6                	xor    %esi,%esi
    62ca:	bf 18 00 00 00       	mov    $0x18,%edi
    62cf:	e8 3c fc ff ff       	call   5f10 <fwp_heap_alloc>
    62d4:	48 89 c3             	mov    %rax,%rbx
    62d7:	e9 f8 fe ff ff       	jmp    61d4 <fwp_data.part.0.constprop.0+0xd4>
    62dc:	e8 4f db ff ff       	call   3e30 <fwp_heap_oom>
    62e1:	0f 1f 40 00          	nopl   0x0(%rax)
    62e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62ec:	00 00 00 00 

00000000000062f0 <fwp_p_ad_push>:
    62f0:	41 57                	push   %r15
    62f2:	41 56                	push   %r14
    62f4:	41 55                	push   %r13
    62f6:	49 89 d5             	mov    %rdx,%r13
    62f9:	41 54                	push   %r12
    62fb:	49 89 fc             	mov    %rdi,%r12
    62fe:	55                   	push   %rbp
    62ff:	53                   	push   %rbx
    6300:	48 83 ec 48          	sub    $0x48,%rsp
    6304:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6309:	48 85 ff             	test   %rdi,%rdi
    630c:	79 09                	jns    6317 <fwp_p_ad_push+0x27>
    630e:	48 85 d2             	test   %rdx,%rdx
    6311:	0f 88 b9 02 00 00    	js     65d0 <fwp_p_ad_push+0x2e0>
    6317:	48 89 f8             	mov    %rdi,%rax
    631a:	48 89 0c 24          	mov    %rcx,(%rsp)
    631e:	4c 89 c5             	mov    %r8,%rbp
    6321:	48 09 d0             	or     %rdx,%rax
    6324:	0f 89 86 02 00 00    	jns    65b0 <fwp_p_ad_push+0x2c0>
    632a:	48 85 ff             	test   %rdi,%rdi
    632d:	0f 89 df 03 00 00    	jns    6712 <fwp_p_ad_push+0x422>
    6333:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6338:	49 89 d6             	mov    %rdx,%r14
    633b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6342:	00 
    6343:	49 89 d4             	mov    %rdx,%r12
    6346:	49 c1 fe 20          	sar    $0x20,%r14
    634a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6351:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6357:	48 85 ed             	test   %rbp,%rbp
    635a:	0f 84 40 03 00 00    	je     66a0 <fwp_p_ad_push+0x3b0>
    6360:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    6364:	0f 84 be 02 00 00    	je     6628 <fwp_p_ad_push+0x338>
    636a:	4c 89 f7             	mov    %r14,%rdi
    636d:	e8 be e3 ff ff       	call   4730 <fwp_tape_of>
    6372:	48 89 c3             	mov    %rax,%rbx
    6375:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    637a:	0f 85 36 03 00 00    	jne    66b6 <fwp_p_ad_push+0x3c6>
    6380:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    6384:	48 89 45 08          	mov    %rax,0x8(%rbp)
    6388:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    638c:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6393:	0f 8f bc 03 00 00    	jg     6755 <fwp_p_ad_push+0x465>
    6399:	44 89 e0             	mov    %r12d,%eax
    639c:	4c 39 f8             	cmp    %r15,%rax
    639f:	0f 8d a4 03 00 00    	jge    6749 <fwp_p_ad_push+0x459>
    63a5:	4d 85 ed             	test   %r13,%r13
    63a8:	78 0c                	js     63b6 <fwp_p_ad_push+0xc6>
    63aa:	44 89 e8             	mov    %r13d,%eax
    63ad:	4c 39 f8             	cmp    %r15,%rax
    63b0:	0f 8d 93 03 00 00    	jge    6749 <fwp_p_ad_push+0x459>
    63b6:	4d 89 fe             	mov    %r15,%r14
    63b9:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    63bd:	49 8d 46 01          	lea    0x1(%r14),%rax
    63c1:	4c 89 f1             	mov    %r14,%rcx
    63c4:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    63ca:	0f 87 85 03 00 00    	ja     6755 <fwp_p_ad_push+0x465>
    63d0:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    63d4:	48 39 e8             	cmp    %rbp,%rax
    63d7:	0f 8e 23 02 00 00    	jle    6600 <fwp_p_ad_push+0x310>
    63dd:	48 85 ed             	test   %rbp,%rbp
    63e0:	ba 40 00 00 00       	mov    $0x40,%edx
    63e5:	48 0f 44 ea          	cmove  %rdx,%rbp
    63e9:	48 39 e8             	cmp    %rbp,%rax
    63ec:	7e 22                	jle    6410 <fwp_p_ad_push+0x120>
    63ee:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    63f5:	0f 8f f5 01 00 00    	jg     65f0 <fwp_p_ad_push+0x300>
    63fb:	48 01 ed             	add    %rbp,%rbp
    63fe:	48 39 e8             	cmp    %rbp,%rax
    6401:	7f eb                	jg     63ee <fwp_p_ad_push+0xfe>
    6403:	66 90                	xchg   %ax,%ax
    6405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    640c:	00 00 00 00 
    6410:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6417:	00 
    6418:	4c 8b 43 60          	mov    0x60(%rbx),%r8
    641c:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6420:	ba 01 00 00 00       	mov    $0x1,%edx
    6425:	48 89 c6             	mov    %rax,%rsi
    6428:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    642d:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6432:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6437:	e8 54 ed ff ff       	call   5190 <ad_raw_realloc>
    643c:	48 85 c0             	test   %rax,%rax
    643f:	0f 84 1c 03 00 00    	je     6761 <fwp_p_ad_push+0x471>
    6445:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6449:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    644e:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6452:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6457:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    645b:	4d 85 c0             	test   %r8,%r8
    645e:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    6462:	0f 84 d0 01 00 00    	je     6638 <fwp_p_ad_push+0x348>
    6468:	49 8b 50 60          	mov    0x60(%r8),%rdx
    646c:	48 39 ea             	cmp    %rbp,%rdx
    646f:	0f 8d bb 00 00 00    	jge    6530 <fwp_p_ad_push+0x240>
    6475:	49 8b 70 40          	mov    0x40(%r8),%rsi
    6479:	48 89 ef             	mov    %rbp,%rdi
    647c:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6481:	48 c1 e7 04          	shl    $0x4,%rdi
    6485:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    648a:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    648f:	be 02 00 00 00       	mov    $0x2,%esi
    6494:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    6499:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    649e:	e8 6d fa ff ff       	call   5f10 <fwp_heap_alloc>
    64a3:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    64a8:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    64ad:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    64b2:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    64b7:	48 85 f6             	test   %rsi,%rsi
    64ba:	74 31                	je     64ed <fwp_p_ad_push+0x1fd>
    64bc:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    64c1:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    64c6:	48 c1 e2 04          	shl    $0x4,%rdx
    64ca:	48 39 fa             	cmp    %rdi,%rdx
    64cd:	48 0f 47 d7          	cmova  %rdi,%rdx
    64d1:	48 89 c7             	mov    %rax,%rdi
    64d4:	e8 a7 d0 ff ff       	call   3580 <memcpy@plt>
    64d9:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    64de:	e8 2d f5 ff ff       	call   5a10 <fwp_mem_free>
    64e3:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    64e8:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    64ed:	49 8b 78 60          	mov    0x60(%r8),%rdi
    64f1:	48 89 ea             	mov    %rbp,%rdx
    64f4:	31 f6                	xor    %esi,%esi
    64f6:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    64fb:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6500:	48 29 fa             	sub    %rdi,%rdx
    6503:	48 c1 e7 04          	shl    $0x4,%rdi
    6507:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    650c:	48 c1 e2 04          	shl    $0x4,%rdx
    6510:	e8 9b cf ff ff       	call   34b0 <memset@plt>
    6515:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    651a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    651f:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6524:	49 89 68 60          	mov    %rbp,0x60(%r8)
    6528:	49 89 40 40          	mov    %rax,0x40(%r8)
    652c:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6530:	4d 85 f6             	test   %r14,%r14
    6533:	0f 85 8f 01 00 00    	jne    66c8 <fwp_p_ad_push+0x3d8>
    6539:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    653d:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6541:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6548:	00 
    6549:	31 d2                	xor    %edx,%edx
    654b:	49 01 c6             	add    %rax,%r14
    654e:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    6552:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    6556:	44 89 24 10          	mov    %r12d,(%rax,%rdx,1)
    655a:	4d 85 ed             	test   %r13,%r13
    655d:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6563:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    656a:	4c 0f 48 e8          	cmovs  %rax,%r13
    656e:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6573:	49 8d 47 01          	lea    0x1(%r15),%rax
    6577:	f2 0f 11 0c 0e       	movsd  %xmm1,(%rsi,%rcx,1)
    657c:	45 89 2c 16          	mov    %r13d,(%r14,%rdx,1)
    6580:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    6585:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6589:	48 83 c4 48          	add    $0x48,%rsp
    658d:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6594:	ff ff ff 
    6597:	4c 21 e0             	and    %r12,%rax
    659a:	5b                   	pop    %rbx
    659b:	5d                   	pop    %rbp
    659c:	4c 09 f8             	or     %r15,%rax
    659f:	41 5c                	pop    %r12
    65a1:	41 5d                	pop    %r13
    65a3:	41 5e                	pop    %r14
    65a5:	41 5f                	pop    %r15
    65a7:	c3                   	ret
    65a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    65af:	00 
    65b0:	48 c1 fa 20          	sar    $0x20,%rdx
    65b4:	48 c1 ff 20          	sar    $0x20,%rdi
    65b8:	49 89 d6             	mov    %rdx,%r14
    65bb:	48 39 d7             	cmp    %rdx,%rdi
    65be:	0f 84 93 fd ff ff    	je     6357 <fwp_p_ad_push+0x67>
    65c4:	48 8d 3d 4d 64 00 00 	lea    0x644d(%rip),%rdi        # ca18 <_IO_stdin_used+0xa18>
    65cb:	e8 80 de ff ff       	call   4450 <fwp_trap>
    65d0:	48 83 c4 48          	add    $0x48,%rsp
    65d4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    65db:	5b                   	pop    %rbx
    65dc:	5d                   	pop    %rbp
    65dd:	41 5c                	pop    %r12
    65df:	41 5d                	pop    %r13
    65e1:	41 5e                	pop    %r14
    65e3:	41 5f                	pop    %r15
    65e5:	c3                   	ret
    65e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65ed:	00 00 00 
    65f0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    65f5:	e9 16 fe ff ff       	jmp    6410 <fwp_p_ad_push+0x120>
    65fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6600:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    6607:	00 
    6608:	48 8b 43 20          	mov    0x20(%rbx),%rax
    660c:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    6610:	48 c1 e1 03          	shl    $0x3,%rcx
    6614:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6618:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    661c:	e9 35 ff ff ff       	jmp    6556 <fwp_p_ad_push+0x266>
    6621:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6628:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    662c:	e9 57 fd ff ff       	jmp    6388 <fwp_p_ad_push+0x98>
    6631:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6638:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    663c:	48 89 ee             	mov    %rbp,%rsi
    663f:	ba 02 00 00 00       	mov    $0x2,%edx
    6644:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6649:	48 c1 e6 04          	shl    $0x4,%rsi
    664d:	e8 3e eb ff ff       	call   5190 <ad_raw_realloc>
    6652:	48 89 c6             	mov    %rax,%rsi
    6655:	48 85 c0             	test   %rax,%rax
    6658:	0f 84 03 01 00 00    	je     6761 <fwp_p_ad_push+0x471>
    665e:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6662:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6666:	4d 85 f6             	test   %r14,%r14
    6669:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    666e:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    6672:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    6676:	48 89 43 38          	mov    %rax,0x38(%rbx)
    667a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    667f:	0f 85 99 00 00 00    	jne    671e <fwp_p_ad_push+0x42e>
    6685:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6689:	48 8b 43 20          	mov    0x20(%rbx),%rax
    668d:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6694:	00 
    6695:	31 d2                	xor    %edx,%edx
    6697:	e9 af fe ff ff       	jmp    654b <fwp_p_ad_push+0x25b>
    669c:	0f 1f 40 00          	nopl   0x0(%rax)
    66a0:	4c 89 f7             	mov    %r14,%rdi
    66a3:	e8 88 e0 ff ff       	call   4730 <fwp_tape_of>
    66a8:	48 89 c3             	mov    %rax,%rbx
    66ab:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    66b0:	0f 84 d2 fc ff ff    	je     6388 <fwp_p_ad_push+0x98>
    66b6:	48 8d 3d a3 63 00 00 	lea    0x63a3(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    66bd:	e8 8e dd ff ff       	call   4450 <fwp_trap>
    66c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66c8:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    66cf:	00 
    66d0:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    66d5:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    66dc:	00 
    66dd:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    66e1:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    66e8:	00 
    66e9:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    66ed:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    66f2:	e8 f9 ce ff ff       	call   35f0 <memmove@plt>
    66f7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    66fb:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    66ff:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6703:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6708:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    670d:	e9 39 fe ff ff       	jmp    654b <fwp_p_ad_push+0x25b>
    6712:	48 c1 ff 20          	sar    $0x20,%rdi
    6716:	49 89 fe             	mov    %rdi,%r14
    6719:	e9 39 fc ff ff       	jmp    6357 <fwp_p_ad_push+0x67>
    671e:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    6725:	00 
    6726:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    672b:	48 89 f2             	mov    %rsi,%rdx
    672e:	48 89 c6             	mov    %rax,%rsi
    6731:	e8 ba ce ff ff       	call   35f0 <memmove@plt>
    6736:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    673b:	48 03 43 30          	add    0x30(%rbx),%rax
    673f:	48 89 43 38          	mov    %rax,0x38(%rbx)
    6743:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6747:	eb 8c                	jmp    66d5 <fwp_p_ad_push+0x3e5>
    6749:	48 8d 3d 72 5a 00 00 	lea    0x5a72(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    6750:	e8 fb dc ff ff       	call   4450 <fwp_trap>
    6755:	48 8d 3d 4b 5a 00 00 	lea    0x5a4b(%rip),%rdi        # c1a7 <_IO_stdin_used+0x1a7>
    675c:	e8 ef dc ff ff       	call   4450 <fwp_trap>
    6761:	48 89 df             	mov    %rbx,%rdi
    6764:	e8 27 d5 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6769:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    676d:	48 85 ff             	test   %rdi,%rdi
    6770:	74 05                	je     6777 <fwp_p_ad_push+0x487>
    6772:	e8 59 e9 ff ff       	call   50d0 <ad_raw_free.part.0>
    6777:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    677b:	48 85 ff             	test   %rdi,%rdi
    677e:	74 05                	je     6785 <fwp_p_ad_push+0x495>
    6780:	e8 4b e9 ff ff       	call   50d0 <ad_raw_free.part.0>
    6785:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6789:	48 85 ff             	test   %rdi,%rdi
    678c:	74 05                	je     6793 <fwp_p_ad_push+0x4a3>
    678e:	e8 3d e9 ff ff       	call   50d0 <ad_raw_free.part.0>
    6793:	31 c9                	xor    %ecx,%ecx
    6795:	31 c0                	xor    %eax,%eax
    6797:	31 d2                	xor    %edx,%edx
    6799:	be 01 00 00 00       	mov    $0x1,%esi
    679e:	89 53 04             	mov    %edx,0x4(%rbx)
    67a1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67a5:	ba 13 00 00 00       	mov    $0x13,%edx
    67aa:	48 8d 3d 57 58 00 00 	lea    0x5857(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    67b1:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    67b5:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    67b9:	48 8b 0d 80 98 00 00 	mov    0x9880(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    67c0:	48 89 43 40          	mov    %rax,0x40(%rbx)
    67c4:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    67c8:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    67cc:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    67d0:	e8 8b ce ff ff       	call   3660 <fwrite@plt>
    67d5:	31 ff                	xor    %edi,%edi
    67d7:	e8 c4 cd ff ff       	call   35a0 <fflush@plt>
    67dc:	bf 66 00 00 00       	mov    $0x66,%edi
    67e1:	e8 9a ce ff ff       	call   3680 <_Exit@plt>
    67e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67ed:	00 00 00 

00000000000067f0 <w120>:
    67f0:	41 56                	push   %r14
    67f2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    67f6:	48 89 fa             	mov    %rdi,%rdx
    67f9:	41 55                	push   %r13
    67fb:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    67ff:	49 89 fd             	mov    %rdi,%r13
    6802:	41 54                	push   %r12
    6804:	55                   	push   %rbp
    6805:	53                   	push   %rbx
    6806:	48 83 ec 40          	sub    $0x40,%rsp
    680a:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6810:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6815:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    681c:	00 00 
    681e:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    6823:	48 89 f5             	mov    %rsi,%rbp
    6826:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    682b:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6831:	48 89 f1             	mov    %rsi,%rcx
    6834:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    683a:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    6841:	ff ff 
    6843:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    684a:	00 00 
    684c:	e8 9f fa ff ff       	call   62f0 <fwp_p_ad_push>
    6851:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6857:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    685c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6862:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6869:	00 f0 3f 
    686c:	48 89 c7             	mov    %rax,%rdi
    686f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6876:	00 f0 bf 
    6879:	48 89 ea             	mov    %rbp,%rdx
    687c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6881:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6887:	e8 64 fa ff ff       	call   62f0 <fwp_p_ad_push>
    688c:	f2 0f 10 05 d4 64 00 	movsd  0x64d4(%rip),%xmm0        # cd68 <msg.4+0x28>
    6893:	00 
    6894:	4c 89 ef             	mov    %r13,%rdi
    6897:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    689d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    68a2:	49 89 c6             	mov    %rax,%r14
    68a5:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    68ac:	00 f0 3f 
    68af:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    68b6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    68bd:	00 f0 bf 
    68c0:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    68c5:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    68cb:	e8 20 fa ff ff       	call   62f0 <fwp_p_ad_push>
    68d0:	4c 89 e1             	mov    %r12,%rcx
    68d3:	4c 89 e6             	mov    %r12,%rsi
    68d6:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    68db:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    68e1:	4c 89 f2             	mov    %r14,%rdx
    68e4:	4c 89 f7             	mov    %r14,%rdi
    68e7:	49 89 c5             	mov    %rax,%r13
    68ea:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    68ee:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    68f4:	e8 f7 f9 ff ff       	call   62f0 <fwp_p_ad_push>
    68f9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    68ff:	f2 0f 59 1d 69 64 00 	mulsd  0x6469(%rip),%xmm3        # cd70 <msg.4+0x30>
    6906:	00 
    6907:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    690c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6911:	48 89 c2             	mov    %rax,%rdx
    6914:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    691b:	00 59 40 
    691e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6925:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    692b:	e8 c0 f9 ff ff       	call   62f0 <fwp_p_ad_push>
    6930:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6935:	48 89 e9             	mov    %rbp,%rcx
    6938:	4c 89 ea             	mov    %r13,%rdx
    693b:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6941:	48 89 ee             	mov    %rbp,%rsi
    6944:	4c 89 ef             	mov    %r13,%rdi
    6947:	49 89 c4             	mov    %rax,%r12
    694a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    694e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6954:	e8 97 f9 ff ff       	call   62f0 <fwp_p_ad_push>
    6959:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    695f:	45 31 c0             	xor    %r8d,%r8d
    6962:	4c 89 e2             	mov    %r12,%rdx
    6965:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    696b:	48 89 c7             	mov    %rax,%rdi
    696e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6975:	00 f0 3f 
    6978:	48 89 ce             	mov    %rcx,%rsi
    697b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6980:	e8 6b f9 ff ff       	call   62f0 <fwp_p_ad_push>
    6985:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    698a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6991:	00 00 
    6993:	75 12                	jne    69a7 <w120+0x1b7>
    6995:	48 83 c4 40          	add    $0x40,%rsp
    6999:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    699e:	5b                   	pop    %rbx
    699f:	5d                   	pop    %rbp
    69a0:	41 5c                	pop    %r12
    69a2:	41 5d                	pop    %r13
    69a4:	41 5e                	pop    %r14
    69a6:	c3                   	ret
    69a7:	e8 a4 ca ff ff       	call   3450 <__stack_chk_fail@plt>
    69ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000069b0 <w176.constprop.0>:
    69b0:	41 54                	push   %r12
    69b2:	55                   	push   %rbp
    69b3:	53                   	push   %rbx
    69b4:	48 83 ec 10          	sub    $0x10,%rsp
    69b8:	4c 8b 27             	mov    (%rdi),%r12
    69bb:	4d 85 e4             	test   %r12,%r12
    69be:	74 58                	je     6a18 <w176.constprop.0+0x68>
    69c0:	48 89 fd             	mov    %rdi,%rbp
    69c3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69c7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    69ce:	31 db                	xor    %ebx,%ebx
    69d0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    69d6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    69db:	45 31 c0             	xor    %r8d,%r8d
    69de:	48 83 c3 02          	add    $0x2,%rbx
    69e2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    69e9:	00 f0 3f 
    69ec:	48 89 ce             	mov    %rcx,%rsi
    69ef:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    69f5:	e8 f6 f8 ff ff       	call   62f0 <fwp_p_ad_push>
    69fa:	4c 39 e3             	cmp    %r12,%rbx
    69fd:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6a03:	48 89 c7             	mov    %rax,%rdi
    6a06:	72 c8                	jb     69d0 <w176.constprop.0+0x20>
    6a08:	48 83 c4 10          	add    $0x10,%rsp
    6a0c:	48 89 f8             	mov    %rdi,%rax
    6a0f:	5b                   	pop    %rbx
    6a10:	5d                   	pop    %rbp
    6a11:	41 5c                	pop    %r12
    6a13:	c3                   	ret
    6a14:	0f 1f 40 00          	nopl   0x0(%rax)
    6a18:	48 83 c4 10          	add    $0x10,%rsp
    6a1c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6a23:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a27:	5b                   	pop    %rbx
    6a28:	48 89 f8             	mov    %rdi,%rax
    6a2b:	5d                   	pop    %rbp
    6a2c:	41 5c                	pop    %r12
    6a2e:	c3                   	ret
    6a2f:	90                   	nop

0000000000006a30 <fwp_rc_share>:
    6a30:	48 8b 05 c1 31 06 00 	mov    0x631c1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    6a37:	48 2b 3d 92 31 06 00 	sub    0x63192(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    6a3e:	48 c1 e0 10          	shl    $0x10,%rax
    6a42:	48 39 c7             	cmp    %rax,%rdi
    6a45:	73 4a                	jae    6a91 <fwp_rc_share+0x61>
    6a47:	48 89 f8             	mov    %rdi,%rax
    6a4a:	48 c1 e8 10          	shr    $0x10,%rax
    6a4e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a52:	48 8b 05 bf 31 06 00 	mov    0x631bf(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    6a59:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6a5d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6a61:	48 85 d2             	test   %rdx,%rdx
    6a64:	74 2b                	je     6a91 <fwp_rc_share+0x61>
    6a66:	0f b6 08             	movzbl (%rax),%ecx
    6a69:	80 f9 02             	cmp    $0x2,%cl
    6a6c:	74 2a                	je     6a98 <fwp_rc_share+0x68>
    6a6e:	80 f9 01             	cmp    $0x1,%cl
    6a71:	75 1e                	jne    6a91 <fwp_rc_share+0x61>
    6a73:	8b 48 18             	mov    0x18(%rax),%ecx
    6a76:	0f b7 ff             	movzwl %di,%edi
    6a79:	8b 40 1c             	mov    0x1c(%rax),%eax
    6a7c:	48 0f af f9          	imul   %rcx,%rdi
    6a80:	48 c1 ef 20          	shr    $0x20,%rdi
    6a84:	48 39 c7             	cmp    %rax,%rdi
    6a87:	73 08                	jae    6a91 <fwp_rc_share+0x61>
    6a89:	48 01 fa             	add    %rdi,%rdx
    6a8c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6a8f:	75 0d                	jne    6a9e <fwp_rc_share+0x6e>
    6a91:	c3                   	ret
    6a92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a98:	66 85 ff             	test   %di,%di
    6a9b:	74 ef                	je     6a8c <fwp_rc_share+0x5c>
    6a9d:	c3                   	ret
    6a9e:	50                   	push   %rax
    6a9f:	48 8d 3d ea 5f 00 00 	lea    0x5fea(%rip),%rdi        # ca90 <_IO_stdin_used+0xa90>
    6aa6:	e8 a5 d9 ff ff       	call   4450 <fwp_trap>
    6aab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006ab0 <fwp_rc_free_obj>:
    6ab0:	48 8b 15 41 31 06 00 	mov    0x63141(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6ab7:	48 89 f8             	mov    %rdi,%rax
    6aba:	48 2b 05 0f 31 06 00 	sub    0x6310f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6ac1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ac5:	48 39 d0             	cmp    %rdx,%rax
    6ac8:	73 5b                	jae    6b25 <fwp_rc_free_obj+0x75>
    6aca:	48 89 c2             	mov    %rax,%rdx
    6acd:	48 c1 ea 10          	shr    $0x10,%rdx
    6ad1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ad5:	48 8b 15 3c 31 06 00 	mov    0x6313c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6adc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6ae0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6ae4:	48 85 c9             	test   %rcx,%rcx
    6ae7:	74 3c                	je     6b25 <fwp_rc_free_obj+0x75>
    6ae9:	0f b6 32             	movzbl (%rdx),%esi
    6aec:	40 80 fe 02          	cmp    $0x2,%sil
    6af0:	74 2e                	je     6b20 <fwp_rc_free_obj+0x70>
    6af2:	40 80 fe 01          	cmp    $0x1,%sil
    6af6:	75 2d                	jne    6b25 <fwp_rc_free_obj+0x75>
    6af8:	8b 72 18             	mov    0x18(%rdx),%esi
    6afb:	0f b7 c0             	movzwl %ax,%eax
    6afe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b01:	48 0f af c6          	imul   %rsi,%rax
    6b05:	48 c1 e8 20          	shr    $0x20,%rax
    6b09:	48 39 d0             	cmp    %rdx,%rax
    6b0c:	73 17                	jae    6b25 <fwp_rc_free_obj+0x75>
    6b0e:	48 01 c1             	add    %rax,%rcx
    6b11:	80 39 01             	cmpb   $0x1,(%rcx)
    6b14:	75 0f                	jne    6b25 <fwp_rc_free_obj+0x75>
    6b16:	e9 f5 ee ff ff       	jmp    5a10 <fwp_mem_free>
    6b1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b20:	66 85 c0             	test   %ax,%ax
    6b23:	74 ec                	je     6b11 <fwp_rc_free_obj+0x61>
    6b25:	c3                   	ret
    6b26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b2d:	00 00 00 

0000000000006b30 <fwp_rc_dup>:
    6b30:	f3 0f 1e fa          	endbr64
    6b34:	48 8b 05 bd 30 06 00 	mov    0x630bd(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    6b3b:	48 2b 3d 8e 30 06 00 	sub    0x6308e(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    6b42:	48 c1 e0 10          	shl    $0x10,%rax
    6b46:	48 39 c7             	cmp    %rax,%rdi
    6b49:	73 60                	jae    6bab <fwp_rc_dup+0x7b>
    6b4b:	48 89 f8             	mov    %rdi,%rax
    6b4e:	48 c1 e8 10          	shr    $0x10,%rax
    6b52:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6b56:	48 8b 05 bb 30 06 00 	mov    0x630bb(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    6b5d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6b61:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6b65:	48 85 c0             	test   %rax,%rax
    6b68:	74 41                	je     6bab <fwp_rc_dup+0x7b>
    6b6a:	0f b6 0a             	movzbl (%rdx),%ecx
    6b6d:	80 f9 02             	cmp    $0x2,%cl
    6b70:	74 3e                	je     6bb0 <fwp_rc_dup+0x80>
    6b72:	80 f9 01             	cmp    $0x1,%cl
    6b75:	75 34                	jne    6bab <fwp_rc_dup+0x7b>
    6b77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6b7a:	0f b7 ff             	movzwl %di,%edi
    6b7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b80:	48 0f af f9          	imul   %rcx,%rdi
    6b84:	48 c1 ef 20          	shr    $0x20,%rdi
    6b88:	48 39 d7             	cmp    %rdx,%rdi
    6b8b:	73 1e                	jae    6bab <fwp_rc_dup+0x7b>
    6b8d:	48 01 f8             	add    %rdi,%rax
    6b90:	0f b6 10             	movzbl (%rax),%edx
    6b93:	84 d2                	test   %dl,%dl
    6b95:	74 14                	je     6bab <fwp_rc_dup+0x7b>
    6b97:	8b 0d 4b 39 06 00    	mov    0x6394b(%rip),%ecx        # 6a4e8 <iteration_active>
    6b9d:	85 c9                	test   %ecx,%ecx
    6b9f:	75 1f                	jne    6bc0 <fwp_rc_dup+0x90>
    6ba1:	80 fa fd             	cmp    $0xfd,%dl
    6ba4:	77 2a                	ja     6bd0 <fwp_rc_dup+0xa0>
    6ba6:	83 c2 01             	add    $0x1,%edx
    6ba9:	88 10                	mov    %dl,(%rax)
    6bab:	c3                   	ret
    6bac:	0f 1f 40 00          	nopl   0x0(%rax)
    6bb0:	66 85 ff             	test   %di,%di
    6bb3:	74 db                	je     6b90 <fwp_rc_dup+0x60>
    6bb5:	c3                   	ret
    6bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bbd:	00 00 00 
    6bc0:	48 83 05 08 39 06 00 	addq   $0x1,0x63908(%rip)        # 6a4d0 <iteration_retains>
    6bc7:	01 
    6bc8:	eb d7                	jmp    6ba1 <fwp_rc_dup+0x71>
    6bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bd0:	48 89 c7             	mov    %rax,%rdi
    6bd3:	e9 d8 ea ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bdf:	00 

0000000000006be0 <fwp_owned_entry173>:
    6be0:	f3 0f 1e fa          	endbr64
    6be4:	48 83 ec 38          	sub    $0x38,%rsp
    6be8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6bed:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bf4:	00 00 
    6bf6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6bfb:	31 c0                	xor    %eax,%eax
    6bfd:	48 8b 07             	mov    (%rdi),%rax
    6c00:	48 03 47 10          	add    0x10(%rdi),%rax
    6c04:	0f 80 c2 00 00 00    	jo     6ccc <fwp_owned_entry173+0xec>
    6c0a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6c0f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6c14:	31 ff                	xor    %edi,%edi
    6c16:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6c1a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c1f:	e8 dc f4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6c24:	48 8b 15 cd 2f 06 00 	mov    0x62fcd(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6c2b:	48 89 c6             	mov    %rax,%rsi
    6c2e:	48 2b 05 9b 2f 06 00 	sub    0x62f9b(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6c35:	48 c1 e2 10          	shl    $0x10,%rdx
    6c39:	48 39 d0             	cmp    %rdx,%rax
    6c3c:	73 4f                	jae    6c8d <fwp_owned_entry173+0xad>
    6c3e:	48 89 c2             	mov    %rax,%rdx
    6c41:	48 c1 ea 10          	shr    $0x10,%rdx
    6c45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c49:	48 8b 15 c8 2f 06 00 	mov    0x62fc8(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6c50:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c54:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c58:	48 85 d2             	test   %rdx,%rdx
    6c5b:	74 30                	je     6c8d <fwp_owned_entry173+0xad>
    6c5d:	0f b6 39             	movzbl (%rcx),%edi
    6c60:	40 80 ff 02          	cmp    $0x2,%dil
    6c64:	74 42                	je     6ca8 <fwp_owned_entry173+0xc8>
    6c66:	40 80 ff 01          	cmp    $0x1,%dil
    6c6a:	75 21                	jne    6c8d <fwp_owned_entry173+0xad>
    6c6c:	8b 79 18             	mov    0x18(%rcx),%edi
    6c6f:	0f b7 c0             	movzwl %ax,%eax
    6c72:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c75:	48 0f af c7          	imul   %rdi,%rax
    6c79:	48 c1 e8 20          	shr    $0x20,%rax
    6c7d:	48 39 c8             	cmp    %rcx,%rax
    6c80:	73 0b                	jae    6c8d <fwp_owned_entry173+0xad>
    6c82:	48 01 c2             	add    %rax,%rdx
    6c85:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c88:	74 26                	je     6cb0 <fwp_owned_entry173+0xd0>
    6c8a:	c6 02 01             	movb   $0x1,(%rdx)
    6c8d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c92:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c99:	00 00 
    6c9b:	75 34                	jne    6cd1 <fwp_owned_entry173+0xf1>
    6c9d:	48 89 f0             	mov    %rsi,%rax
    6ca0:	48 83 c4 38          	add    $0x38,%rsp
    6ca4:	c3                   	ret
    6ca5:	0f 1f 00             	nopl   (%rax)
    6ca8:	66 85 c0             	test   %ax,%ax
    6cab:	75 e0                	jne    6c8d <fwp_owned_entry173+0xad>
    6cad:	eb d6                	jmp    6c85 <fwp_owned_entry173+0xa5>
    6caf:	90                   	nop
    6cb0:	48 89 d7             	mov    %rdx,%rdi
    6cb3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6cb8:	48 89 14 24          	mov    %rdx,(%rsp)
    6cbc:	e8 0f eb ff ff       	call   57d0 <fwp_rc_forget_slot>
    6cc1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6cc6:	48 8b 14 24          	mov    (%rsp),%rdx
    6cca:	eb be                	jmp    6c8a <fwp_owned_entry173+0xaa>
    6ccc:	e8 2f ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6cd1:	e8 7a c7 ff ff       	call   3450 <__stack_chk_fail@plt>
    6cd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cdd:	00 00 00 

0000000000006ce0 <e173>:
    6ce0:	f3 0f 1e fa          	endbr64
    6ce4:	53                   	push   %rbx
    6ce5:	48 83 ec 30          	sub    $0x30,%rsp
    6ce9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6cee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6cf5:	00 00 
    6cf7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6cfc:	31 c0                	xor    %eax,%eax
    6cfe:	48 8b 07             	mov    (%rdi),%rax
    6d01:	48 03 47 10          	add    0x10(%rdi),%rax
    6d05:	0f 80 c9 00 00 00    	jo     6dd4 <e173+0xf4>
    6d0b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6d10:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6d15:	31 ff                	xor    %edi,%edi
    6d17:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6d1b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6d20:	e8 db f3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6d25:	48 8b 15 cc 2e 06 00 	mov    0x62ecc(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6d2c:	48 89 c3             	mov    %rax,%rbx
    6d2f:	48 2b 05 9a 2e 06 00 	sub    0x62e9a(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6d36:	48 c1 e2 10          	shl    $0x10,%rdx
    6d3a:	48 39 d0             	cmp    %rdx,%rax
    6d3d:	73 4f                	jae    6d8e <e173+0xae>
    6d3f:	48 89 c2             	mov    %rax,%rdx
    6d42:	48 c1 ea 10          	shr    $0x10,%rdx
    6d46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d4a:	48 8b 15 c7 2e 06 00 	mov    0x62ec7(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6d51:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d55:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d59:	48 85 d2             	test   %rdx,%rdx
    6d5c:	74 30                	je     6d8e <e173+0xae>
    6d5e:	0f b6 31             	movzbl (%rcx),%esi
    6d61:	40 80 fe 02          	cmp    $0x2,%sil
    6d65:	74 49                	je     6db0 <e173+0xd0>
    6d67:	40 80 fe 01          	cmp    $0x1,%sil
    6d6b:	75 21                	jne    6d8e <e173+0xae>
    6d6d:	8b 71 18             	mov    0x18(%rcx),%esi
    6d70:	0f b7 c0             	movzwl %ax,%eax
    6d73:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d76:	48 0f af c6          	imul   %rsi,%rax
    6d7a:	48 c1 e8 20          	shr    $0x20,%rax
    6d7e:	48 39 c8             	cmp    %rcx,%rax
    6d81:	73 0b                	jae    6d8e <e173+0xae>
    6d83:	48 01 c2             	add    %rax,%rdx
    6d86:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d89:	74 35                	je     6dc0 <e173+0xe0>
    6d8b:	c6 02 01             	movb   $0x1,(%rdx)
    6d8e:	48 89 df             	mov    %rbx,%rdi
    6d91:	e8 9a fc ff ff       	call   6a30 <fwp_rc_share>
    6d96:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6d9b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6da2:	00 00 
    6da4:	75 33                	jne    6dd9 <e173+0xf9>
    6da6:	48 83 c4 30          	add    $0x30,%rsp
    6daa:	48 89 d8             	mov    %rbx,%rax
    6dad:	5b                   	pop    %rbx
    6dae:	c3                   	ret
    6daf:	90                   	nop
    6db0:	66 85 c0             	test   %ax,%ax
    6db3:	75 d9                	jne    6d8e <e173+0xae>
    6db5:	eb cf                	jmp    6d86 <e173+0xa6>
    6db7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dbe:	00 00 
    6dc0:	48 89 d7             	mov    %rdx,%rdi
    6dc3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6dc8:	e8 03 ea ff ff       	call   57d0 <fwp_rc_forget_slot>
    6dcd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6dd2:	eb b7                	jmp    6d8b <e173+0xab>
    6dd4:	e8 27 c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6dd9:	e8 72 c6 ff ff       	call   3450 <__stack_chk_fail@plt>
    6dde:	66 90                	xchg   %ax,%ax

0000000000006de0 <fwp_closure_drop>:
    6de0:	48 8b 15 11 2e 06 00 	mov    0x62e11(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6de7:	48 89 f8             	mov    %rdi,%rax
    6dea:	48 2b 05 df 2d 06 00 	sub    0x62ddf(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6df1:	48 c1 e2 10          	shl    $0x10,%rdx
    6df5:	48 39 d0             	cmp    %rdx,%rax
    6df8:	73 6b                	jae    6e65 <fwp_closure_drop+0x85>
    6dfa:	48 89 c2             	mov    %rax,%rdx
    6dfd:	48 c1 ea 10          	shr    $0x10,%rdx
    6e01:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e05:	48 8b 15 0c 2e 06 00 	mov    0x62e0c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6e0c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e10:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e14:	48 85 d2             	test   %rdx,%rdx
    6e17:	74 4c                	je     6e65 <fwp_closure_drop+0x85>
    6e19:	0f b6 31             	movzbl (%rcx),%esi
    6e1c:	40 80 fe 02          	cmp    $0x2,%sil
    6e20:	74 3e                	je     6e60 <fwp_closure_drop+0x80>
    6e22:	40 80 fe 01          	cmp    $0x1,%sil
    6e26:	75 3d                	jne    6e65 <fwp_closure_drop+0x85>
    6e28:	8b 71 18             	mov    0x18(%rcx),%esi
    6e2b:	0f b7 c0             	movzwl %ax,%eax
    6e2e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e31:	48 0f af c6          	imul   %rsi,%rax
    6e35:	48 c1 e8 20          	shr    $0x20,%rax
    6e39:	48 39 c8             	cmp    %rcx,%rax
    6e3c:	73 27                	jae    6e65 <fwp_closure_drop+0x85>
    6e3e:	48 01 c2             	add    %rax,%rdx
    6e41:	0f b6 02             	movzbl (%rdx),%eax
    6e44:	84 c0                	test   %al,%al
    6e46:	74 1d                	je     6e65 <fwp_closure_drop+0x85>
    6e48:	3c 01                	cmp    $0x1,%al
    6e4a:	74 24                	je     6e70 <fwp_closure_drop+0x90>
    6e4c:	3c ff                	cmp    $0xff,%al
    6e4e:	74 48                	je     6e98 <fwp_closure_drop+0xb8>
    6e50:	83 e8 01             	sub    $0x1,%eax
    6e53:	88 02                	mov    %al,(%rdx)
    6e55:	c3                   	ret
    6e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e5d:	00 00 00 
    6e60:	66 85 c0             	test   %ax,%ax
    6e63:	74 dc                	je     6e41 <fwp_closure_drop+0x61>
    6e65:	c3                   	ret
    6e66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e6d:	00 00 00 
    6e70:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6e77:	ff ff 
    6e79:	48 85 c0             	test   %rax,%rax
    6e7c:	74 12                	je     6e90 <fwp_closure_drop+0xb0>
    6e7e:	48 89 fe             	mov    %rdi,%rsi
    6e81:	48 89 c7             	mov    %rax,%rdi
    6e84:	e9 27 d6 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    6e89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e90:	e9 cb d7 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    6e95:	0f 1f 00             	nopl   (%rax)
    6e98:	48 89 d0             	mov    %rdx,%rax
    6e9b:	48 8d 35 7e 19 06 00 	lea    0x6197e(%rip),%rsi        # 68820 <fwp_heap>
    6ea2:	48 83 ec 18          	sub    $0x18,%rsp
    6ea6:	48 c1 e8 11          	shr    $0x11,%rax
    6eaa:	48 31 d0             	xor    %rdx,%rax
    6ead:	48 89 c1             	mov    %rax,%rcx
    6eb0:	48 c1 e9 09          	shr    $0x9,%rcx
    6eb4:	48 31 c8             	xor    %rcx,%rax
    6eb7:	0f b6 c8             	movzbl %al,%ecx
    6eba:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6ec1:	00 
    6ec2:	48 85 c0             	test   %rax,%rax
    6ec5:	75 22                	jne    6ee9 <fwp_closure_drop+0x109>
    6ec7:	eb 59                	jmp    6f22 <fwp_closure_drop+0x142>
    6ec9:	90                   	nop
    6eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ed1:	00 00 00 00 
    6ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6edc:	00 00 00 00 
    6ee0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6ee4:	48 85 c0             	test   %rax,%rax
    6ee7:	74 39                	je     6f22 <fwp_closure_drop+0x142>
    6ee9:	48 89 c1             	mov    %rax,%rcx
    6eec:	48 39 10             	cmp    %rdx,(%rax)
    6eef:	75 ef                	jne    6ee0 <fwp_closure_drop+0x100>
    6ef1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6ef5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6ef9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6efd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6f04:	74 05                	je     6f0b <fwp_closure_drop+0x12b>
    6f06:	48 83 c4 18          	add    $0x18,%rsp
    6f0a:	c3                   	ret
    6f0b:	48 89 d7             	mov    %rdx,%rdi
    6f0e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f13:	e8 b8 e8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6f18:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f1d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6f20:	eb e4                	jmp    6f06 <fwp_closure_drop+0x126>
    6f22:	48 8d 3d c7 5a 00 00 	lea    0x5ac7(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    6f29:	e8 22 d5 ff ff       	call   4450 <fwp_trap>
    6f2e:	66 90                	xchg   %ax,%ax

0000000000006f30 <fwp_owned_tape_release>:
    6f30:	48 85 ff             	test   %rdi,%rdi
    6f33:	0f 84 f7 00 00 00    	je     7030 <fwp_owned_tape_release+0x100>
    6f39:	41 54                	push   %r12
    6f3b:	55                   	push   %rbp
    6f3c:	53                   	push   %rbx
    6f3d:	48 8b 07             	mov    (%rdi),%rax
    6f40:	48 85 c0             	test   %rax,%rax
    6f43:	74 08                	je     6f4d <fwp_owned_tape_release+0x1d>
    6f45:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6f49:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6f4d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6f51:	48 85 d2             	test   %rdx,%rdx
    6f54:	74 03                	je     6f59 <fwp_owned_tape_release+0x29>
    6f56:	48 89 02             	mov    %rax,(%rdx)
    6f59:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6f5d:	48 89 fb             	mov    %rdi,%rbx
    6f60:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6f64:	48 85 c0             	test   %rax,%rax
    6f67:	0f 84 89 00 00 00    	je     6ff6 <fwp_owned_tape_release+0xc6>
    6f6d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6f71:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6f75:	7e 47                	jle    6fbe <fwp_owned_tape_release+0x8e>
    6f77:	31 ed                	xor    %ebp,%ebp
    6f79:	eb 0d                	jmp    6f88 <fwp_owned_tape_release+0x58>
    6f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f80:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6f84:	48 8b 40 68          	mov    0x68(%rax),%rax
    6f88:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6f8c:	49 89 ec             	mov    %rbp,%r12
    6f8f:	48 83 c5 01          	add    $0x1,%rbp
    6f93:	49 c1 e4 04          	shl    $0x4,%r12
    6f97:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6f9b:	ff d0                	call   *%rax
    6f9d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6fa1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6fa6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6faa:	ff 50 68             	call   *0x68(%rax)
    6fad:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6fb1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6fb5:	48 39 e8             	cmp    %rbp,%rax
    6fb8:	7f c6                	jg     6f80 <fwp_owned_tape_release+0x50>
    6fba:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6fbe:	31 ed                	xor    %ebp,%ebp
    6fc0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6fc5:	7e 28                	jle    6fef <fwp_owned_tape_release+0xbf>
    6fc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6fce:	00 00 
    6fd0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6fd4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6fd8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6fdc:	74 07                	je     6fe5 <fwp_owned_tape_release+0xb5>
    6fde:	ff 52 68             	call   *0x68(%rdx)
    6fe1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6fe5:	48 83 c5 01          	add    $0x1,%rbp
    6fe9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6fed:	7f e1                	jg     6fd0 <fwp_owned_tape_release+0xa0>
    6fef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6ff3:	ff 52 68             	call   *0x68(%rdx)
    6ff6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6ffa:	e8 e1 fd ff ff       	call   6de0 <fwp_closure_drop>
    6fff:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7003:	e8 d8 fd ff ff       	call   6de0 <fwp_closure_drop>
    7008:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    700c:	e8 cf fd ff ff       	call   6de0 <fwp_closure_drop>
    7011:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7015:	e8 f6 e9 ff ff       	call   5a10 <fwp_mem_free>
    701a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    701e:	e8 ed e9 ff ff       	call   5a10 <fwp_mem_free>
    7023:	48 89 df             	mov    %rbx,%rdi
    7026:	5b                   	pop    %rbx
    7027:	5d                   	pop    %rbp
    7028:	41 5c                	pop    %r12
    702a:	e9 e1 e9 ff ff       	jmp    5a10 <fwp_mem_free>
    702f:	90                   	nop
    7030:	c3                   	ret
    7031:	0f 1f 40 00          	nopl   0x0(%rax)
    7035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    703c:	00 00 00 00 

0000000000007040 <fwp_tape_finish>:
    7040:	f3 0f 1e fa          	endbr64
    7044:	41 55                	push   %r13
    7046:	41 54                	push   %r12
    7048:	55                   	push   %rbp
    7049:	53                   	push   %rbx
    704a:	48 83 ec 48          	sub    $0x48,%rsp
    704e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7055:	00 00 
    7057:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    705c:	48 8d 3d 3d 90 01 00 	lea    0x1903d(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    7063:	e8 d8 e0 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7068:	48 83 3d 78 90 01 00 	cmpq   $0x0,0x19078(%rip)        # 200e8 <fwp_ntapes>
    706f:	00 
    7070:	48 c7 05 0d 90 01 00 	movq   $0x0,0x1900d(%rip)        # 20088 <fwp_tape_cached_bytes>
    7077:	00 00 00 00 
    707b:	7e 79                	jle    70f6 <fwp_tape_finish+0xb6>
    707d:	45 31 e4             	xor    %r12d,%r12d
    7080:	31 ed                	xor    %ebp,%ebp
    7082:	0f 1f 00             	nopl   (%rax)
    7085:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    708c:	00 00 00 00 
    7090:	48 8b 1d 59 90 01 00 	mov    0x19059(%rip),%rbx        # 200f0 <fwp_tapes>
    7097:	48 83 c5 01          	add    $0x1,%rbp
    709b:	4c 01 e3             	add    %r12,%rbx
    709e:	49 83 c4 68          	add    $0x68,%r12
    70a2:	48 89 df             	mov    %rbx,%rdi
    70a5:	e8 e6 cb ff ff       	call   3c90 <fwp_tape_unlink_scope>
    70aa:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    70af:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    70b4:	48 89 e7             	mov    %rsp,%rdi
    70b7:	48 8b 43 40          	mov    0x40(%rbx),%rax
    70bb:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    70bf:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    70c4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    70c9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    70ce:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    70d2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    70d7:	e8 64 e0 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    70dc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    70e0:	e8 4b fe ff ff       	call   6f30 <fwp_owned_tape_release>
    70e5:	48 39 2d fc 8f 01 00 	cmp    %rbp,0x18ffc(%rip)        # 200e8 <fwp_ntapes>
    70ec:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    70f3:	00 
    70f4:	7f 9a                	jg     7090 <fwp_tape_finish+0x50>
    70f6:	48 8b 3d f3 8f 01 00 	mov    0x18ff3(%rip),%rdi        # 200f0 <fwp_tapes>
    70fd:	48 85 ff             	test   %rdi,%rdi
    7100:	74 05                	je     7107 <fwp_tape_finish+0xc7>
    7102:	e8 c9 df ff ff       	call   50d0 <ad_raw_free.part.0>
    7107:	48 c7 05 de 8f 01 00 	movq   $0x0,0x18fde(%rip)        # 200f0 <fwp_tapes>
    710e:	00 00 00 00 
    7112:	48 c7 05 c3 8f 01 00 	movq   $0x0,0x18fc3(%rip)        # 200e0 <fwp_tapes_cap>
    7119:	00 00 00 00 
    711d:	48 c7 05 c0 8f 01 00 	movq   $0x0,0x18fc0(%rip)        # 200e8 <fwp_ntapes>
    7124:	00 00 00 00 
    7128:	48 c7 05 a5 8f 01 00 	movq   $0x0,0x18fa5(%rip)        # 200d8 <fwp_tape_next_slot>
    712f:	00 00 00 00 
    7133:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7138:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    713f:	00 00 
    7141:	75 0b                	jne    714e <fwp_tape_finish+0x10e>
    7143:	48 83 c4 48          	add    $0x48,%rsp
    7147:	5b                   	pop    %rbx
    7148:	5d                   	pop    %rbp
    7149:	41 5c                	pop    %r12
    714b:	41 5d                	pop    %r13
    714d:	c3                   	ret
    714e:	e8 fd c2 ff ff       	call   3450 <__stack_chk_fail@plt>
    7153:	66 90                	xchg   %ax,%ax
    7155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    715c:	00 00 00 00 

0000000000007160 <fwp_tape_scope_release>:
    7160:	f3 0f 1e fa          	endbr64
    7164:	41 55                	push   %r13
    7166:	41 54                	push   %r12
    7168:	55                   	push   %rbp
    7169:	53                   	push   %rbx
    716a:	48 83 ec 48          	sub    $0x48,%rsp
    716e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7175:	00 00 
    7177:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    717c:	48 63 07             	movslq (%rdi),%rax
    717f:	85 c0                	test   %eax,%eax
    7181:	0f 88 e8 00 00 00    	js     726f <fwp_tape_scope_release+0x10f>
    7187:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    718e:	ec c4 4e 
    7191:	48 89 fb             	mov    %rdi,%rbx
    7194:	48 89 e5             	mov    %rsp,%rbp
    7197:	eb 1f                	jmp    71b8 <fwp_tape_scope_release+0x58>
    7199:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71a0:	e8 9b df ff ff       	call   5140 <fwp_tape_buffers_dispose>
    71a5:	4c 89 ef             	mov    %r13,%rdi
    71a8:	e8 83 fd ff ff       	call   6f30 <fwp_owned_tape_release>
    71ad:	48 63 03             	movslq (%rbx),%rax
    71b0:	85 c0                	test   %eax,%eax
    71b2:	0f 88 b7 00 00 00    	js     726f <fwp_tape_scope_release+0x10f>
    71b8:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    71bc:	48 8b 35 2d 8f 01 00 	mov    0x18f2d(%rip),%rsi        # 200f0 <fwp_tapes>
    71c3:	4c 01 c6             	add    %r8,%rsi
    71c6:	48 89 f7             	mov    %rsi,%rdi
    71c9:	e8 c2 ca ff ff       	call   3c90 <fwp_tape_unlink_scope>
    71ce:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    71d3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    71d8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    71df:	48 8b 46 40          	mov    0x40(%rsi),%rax
    71e3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    71e7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    71ee:	00 
    71ef:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    71f4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    71f9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    71fd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7202:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7206:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    720b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7212:	00 
    7213:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    721a:	00 
    721b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7222:	00 
    7223:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7227:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    722b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    722f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7233:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7239:	77 18                	ja     7253 <fwp_tape_scope_release+0xf3>
    723b:	49 c1 f8 03          	sar    $0x3,%r8
    723f:	4d 0f af c4          	imul   %r12,%r8
    7243:	4c 3b 05 8e 8e 01 00 	cmp    0x18e8e(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    724a:	7d 07                	jge    7253 <fwp_tape_scope_release+0xf3>
    724c:	4c 89 05 85 8e 01 00 	mov    %r8,0x18e85(%rip)        # 200d8 <fwp_tape_next_slot>
    7253:	48 89 ef             	mov    %rbp,%rdi
    7256:	4d 85 ed             	test   %r13,%r13
    7259:	0f 85 41 ff ff ff    	jne    71a0 <fwp_tape_scope_release+0x40>
    725f:	e8 fc df ff ff       	call   5260 <fwp_tape_buffers_release>
    7264:	48 63 03             	movslq (%rbx),%rax
    7267:	85 c0                	test   %eax,%eax
    7269:	0f 89 49 ff ff ff    	jns    71b8 <fwp_tape_scope_release+0x58>
    726f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7274:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    727b:	00 00 
    727d:	75 0b                	jne    728a <fwp_tape_scope_release+0x12a>
    727f:	48 83 c4 48          	add    $0x48,%rsp
    7283:	5b                   	pop    %rbx
    7284:	5d                   	pop    %rbp
    7285:	41 5c                	pop    %r12
    7287:	41 5d                	pop    %r13
    7289:	c3                   	ret
    728a:	e8 c1 c1 ff ff       	call   3450 <__stack_chk_fail@plt>
    728f:	90                   	nop

0000000000007290 <fwp_drop4>:
    7290:	48 8b 0d 61 29 06 00 	mov    0x62961(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    7297:	48 89 f8             	mov    %rdi,%rax
    729a:	48 2b 05 2f 29 06 00 	sub    0x6292f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    72a1:	48 c1 e1 10          	shl    $0x10,%rcx
    72a5:	48 39 c8             	cmp    %rcx,%rax
    72a8:	0f 83 42 01 00 00    	jae    73f0 <fwp_drop4+0x160>
    72ae:	48 83 ec 18          	sub    $0x18,%rsp
    72b2:	48 89 fa             	mov    %rdi,%rdx
    72b5:	4c 8d 05 64 15 06 00 	lea    0x61564(%rip),%r8        # 68820 <fwp_heap>
    72bc:	48 89 c1             	mov    %rax,%rcx
    72bf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    72c6:	48 c1 e9 10          	shr    $0x10,%rcx
    72ca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    72ce:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    72d2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    72d6:	48 85 c9             	test   %rcx,%rcx
    72d9:	74 40                	je     731b <fwp_drop4+0x8b>
    72db:	0f b6 3e             	movzbl (%rsi),%edi
    72de:	40 80 ff 02          	cmp    $0x2,%dil
    72e2:	74 3c                	je     7320 <fwp_drop4+0x90>
    72e4:	40 80 ff 01          	cmp    $0x1,%dil
    72e8:	75 31                	jne    731b <fwp_drop4+0x8b>
    72ea:	8b 7e 18             	mov    0x18(%rsi),%edi
    72ed:	0f b7 c0             	movzwl %ax,%eax
    72f0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    72f3:	48 0f af c7          	imul   %rdi,%rax
    72f7:	48 c1 e8 20          	shr    $0x20,%rax
    72fb:	48 39 f0             	cmp    %rsi,%rax
    72fe:	73 1b                	jae    731b <fwp_drop4+0x8b>
    7300:	48 01 c1             	add    %rax,%rcx
    7303:	0f b6 01             	movzbl (%rcx),%eax
    7306:	84 c0                	test   %al,%al
    7308:	74 11                	je     731b <fwp_drop4+0x8b>
    730a:	3c 01                	cmp    $0x1,%al
    730c:	74 22                	je     7330 <fwp_drop4+0xa0>
    730e:	3c ff                	cmp    $0xff,%al
    7310:	0f 84 0a 01 00 00    	je     7420 <fwp_drop4+0x190>
    7316:	83 e8 01             	sub    $0x1,%eax
    7319:	88 01                	mov    %al,(%rcx)
    731b:	48 83 c4 18          	add    $0x18,%rsp
    731f:	c3                   	ret
    7320:	66 85 c0             	test   %ax,%ax
    7323:	74 de                	je     7303 <fwp_drop4+0x73>
    7325:	48 83 c4 18          	add    $0x18,%rsp
    7329:	c3                   	ret
    732a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7330:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7334:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    733b:	48 89 f8             	mov    %rdi,%rax
    733e:	48 c1 e1 10          	shl    $0x10,%rcx
    7342:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7349:	48 39 c8             	cmp    %rcx,%rax
    734c:	73 62                	jae    73b0 <fwp_drop4+0x120>
    734e:	48 89 c1             	mov    %rax,%rcx
    7351:	48 c1 e9 10          	shr    $0x10,%rcx
    7355:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7359:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    735d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7361:	48 85 c9             	test   %rcx,%rcx
    7364:	74 4a                	je     73b0 <fwp_drop4+0x120>
    7366:	44 0f b6 0e          	movzbl (%rsi),%r9d
    736a:	41 80 f9 02          	cmp    $0x2,%r9b
    736e:	0f 84 9c 00 00 00    	je     7410 <fwp_drop4+0x180>
    7374:	41 80 f9 01          	cmp    $0x1,%r9b
    7378:	75 36                	jne    73b0 <fwp_drop4+0x120>
    737a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    737e:	0f b7 c0             	movzwl %ax,%eax
    7381:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7384:	49 0f af c1          	imul   %r9,%rax
    7388:	48 c1 e8 20          	shr    $0x20,%rax
    738c:	48 39 f0             	cmp    %rsi,%rax
    738f:	73 1f                	jae    73b0 <fwp_drop4+0x120>
    7391:	48 01 c1             	add    %rax,%rcx
    7394:	0f b6 01             	movzbl (%rcx),%eax
    7397:	84 c0                	test   %al,%al
    7399:	74 15                	je     73b0 <fwp_drop4+0x120>
    739b:	3c 01                	cmp    $0x1,%al
    739d:	74 59                	je     73f8 <fwp_drop4+0x168>
    739f:	3c ff                	cmp    $0xff,%al
    73a1:	0f 84 ff 00 00 00    	je     74a6 <fwp_drop4+0x216>
    73a7:	83 e8 01             	sub    $0x1,%eax
    73aa:	88 01                	mov    %al,(%rcx)
    73ac:	0f 1f 40 00          	nopl   0x0(%rax)
    73b0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    73b4:	48 89 d7             	mov    %rdx,%rdi
    73b7:	48 89 0c 24          	mov    %rcx,(%rsp)
    73bb:	e8 f0 f6 ff ff       	call   6ab0 <fwp_rc_free_obj>
    73c0:	4c 8d 05 59 14 06 00 	lea    0x61459(%rip),%r8        # 68820 <fwp_heap>
    73c7:	48 8b 04 24          	mov    (%rsp),%rax
    73cb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    73d2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    73d9:	48 c1 e2 10          	shl    $0x10,%rdx
    73dd:	48 39 d0             	cmp    %rdx,%rax
    73e0:	0f 83 35 ff ff ff    	jae    731b <fwp_drop4+0x8b>
    73e6:	48 8b 14 24          	mov    (%rsp),%rdx
    73ea:	e9 cd fe ff ff       	jmp    72bc <fwp_drop4+0x2c>
    73ef:	90                   	nop
    73f0:	c3                   	ret
    73f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73f8:	48 89 14 24          	mov    %rdx,(%rsp)
    73fc:	e8 af f6 ff ff       	call   6ab0 <fwp_rc_free_obj>
    7401:	48 8b 14 24          	mov    (%rsp),%rdx
    7405:	eb a9                	jmp    73b0 <fwp_drop4+0x120>
    7407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    740e:	00 00 
    7410:	66 85 c0             	test   %ax,%ax
    7413:	75 9b                	jne    73b0 <fwp_drop4+0x120>
    7415:	e9 7a ff ff ff       	jmp    7394 <fwp_drop4+0x104>
    741a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7420:	48 89 c8             	mov    %rcx,%rax
    7423:	48 c1 e8 11          	shr    $0x11,%rax
    7427:	48 31 c8             	xor    %rcx,%rax
    742a:	48 89 c2             	mov    %rax,%rdx
    742d:	48 c1 ea 09          	shr    $0x9,%rdx
    7431:	48 31 d0             	xor    %rdx,%rax
    7434:	0f b6 d0             	movzbl %al,%edx
    7437:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    743e:	00 
    743f:	48 85 c0             	test   %rax,%rax
    7442:	75 29                	jne    746d <fwp_drop4+0x1dd>
    7444:	e9 e3 00 00 00       	jmp    752c <fwp_drop4+0x29c>
    7449:	90                   	nop
    744a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7451:	00 00 00 00 
    7455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    745c:	00 00 00 00 
    7460:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7464:	48 85 c0             	test   %rax,%rax
    7467:	0f 84 bf 00 00 00    	je     752c <fwp_drop4+0x29c>
    746d:	48 89 c2             	mov    %rax,%rdx
    7470:	48 39 08             	cmp    %rcx,(%rax)
    7473:	75 eb                	jne    7460 <fwp_drop4+0x1d0>
    7475:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7479:	48 83 ea 01          	sub    $0x1,%rdx
    747d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7481:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7488:	0f 85 8d fe ff ff    	jne    731b <fwp_drop4+0x8b>
    748e:	48 89 cf             	mov    %rcx,%rdi
    7491:	48 89 0c 24          	mov    %rcx,(%rsp)
    7495:	e8 36 e3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    749a:	48 8b 0c 24          	mov    (%rsp),%rcx
    749e:	c6 01 fe             	movb   $0xfe,(%rcx)
    74a1:	e9 75 fe ff ff       	jmp    731b <fwp_drop4+0x8b>
    74a6:	48 89 ce             	mov    %rcx,%rsi
    74a9:	48 c1 ee 11          	shr    $0x11,%rsi
    74ad:	48 31 ce             	xor    %rcx,%rsi
    74b0:	48 89 f0             	mov    %rsi,%rax
    74b3:	48 c1 e8 09          	shr    $0x9,%rax
    74b7:	48 31 c6             	xor    %rax,%rsi
    74ba:	40 0f b6 f6          	movzbl %sil,%esi
    74be:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    74c5:	00 
    74c6:	48 85 c0             	test   %rax,%rax
    74c9:	75 1e                	jne    74e9 <fwp_drop4+0x259>
    74cb:	eb 5f                	jmp    752c <fwp_drop4+0x29c>
    74cd:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    74d4:	00 
    74d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74dc:	00 00 00 00 
    74e0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    74e4:	48 85 c0             	test   %rax,%rax
    74e7:	74 43                	je     752c <fwp_drop4+0x29c>
    74e9:	48 89 c6             	mov    %rax,%rsi
    74ec:	48 39 08             	cmp    %rcx,(%rax)
    74ef:	75 ef                	jne    74e0 <fwp_drop4+0x250>
    74f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    74f5:	48 83 ee 01          	sub    $0x1,%rsi
    74f9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    74fd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7504:	0f 85 a6 fe ff ff    	jne    73b0 <fwp_drop4+0x120>
    750a:	48 89 cf             	mov    %rcx,%rdi
    750d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7512:	48 89 0c 24          	mov    %rcx,(%rsp)
    7516:	e8 b5 e2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    751b:	48 8b 0c 24          	mov    (%rsp),%rcx
    751f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7524:	c6 01 fe             	movb   $0xfe,(%rcx)
    7527:	e9 84 fe ff ff       	jmp    73b0 <fwp_drop4+0x120>
    752c:	48 8d 3d bd 54 00 00 	lea    0x54bd(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    7533:	e8 18 cf ff ff       	call   4450 <fwp_trap>
    7538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    753f:	00 

0000000000007540 <fwp_arg_drop37>:
    7540:	f3 0f 1e fa          	endbr64
    7544:	85 f6                	test   %esi,%esi
    7546:	75 04                	jne    754c <fwp_arg_drop37+0xc>
    7548:	85 d2                	test   %edx,%edx
    754a:	75 04                	jne    7550 <fwp_arg_drop37+0x10>
    754c:	c3                   	ret
    754d:	0f 1f 00             	nopl   (%rax)
    7550:	48 8b 3f             	mov    (%rdi),%rdi
    7553:	e9 38 fd ff ff       	jmp    7290 <fwp_drop4>
    7558:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    755f:	00 

0000000000007560 <fwp_task_dispose>:
    7560:	53                   	push   %rbx
    7561:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7565:	0f 84 db c1 ff ff    	je     3746 <fwp_task_dispose.cold>
    756b:	48 89 fb             	mov    %rdi,%rbx
    756e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7573:	0f 85 cd c1 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7579:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    757d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7584:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    758b:	00 
    758c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7590:	48 85 ff             	test   %rdi,%rdi
    7593:	74 07                	je     759c <fwp_task_dispose+0x3c>
    7595:	48 85 c0             	test   %rax,%rax
    7598:	74 02                	je     759c <fwp_task_dispose+0x3c>
    759a:	ff d0                	call   *%rax
    759c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    75a3:	e8 68 e4 ff ff       	call   5a10 <fwp_mem_free>
    75a8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    75af:	00 00 00 00 
    75b3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    75b7:	74 6f                	je     7628 <fwp_task_dispose+0xc8>
    75b9:	48 8b 15 38 26 06 00 	mov    0x62638(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    75c0:	48 89 d8             	mov    %rbx,%rax
    75c3:	48 2b 05 06 26 06 00 	sub    0x62606(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    75ca:	48 c1 e2 10          	shl    $0x10,%rdx
    75ce:	48 39 d0             	cmp    %rdx,%rax
    75d1:	73 4c                	jae    761f <fwp_task_dispose+0xbf>
    75d3:	48 89 c2             	mov    %rax,%rdx
    75d6:	48 c1 ea 10          	shr    $0x10,%rdx
    75da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75de:	48 8b 15 33 26 06 00 	mov    0x62633(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    75e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    75e9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    75ed:	48 85 c9             	test   %rcx,%rcx
    75f0:	74 2d                	je     761f <fwp_task_dispose+0xbf>
    75f2:	0f b6 32             	movzbl (%rdx),%esi
    75f5:	40 80 fe 02          	cmp    $0x2,%sil
    75f9:	74 3d                	je     7638 <fwp_task_dispose+0xd8>
    75fb:	40 80 fe 01          	cmp    $0x1,%sil
    75ff:	75 1e                	jne    761f <fwp_task_dispose+0xbf>
    7601:	8b 72 18             	mov    0x18(%rdx),%esi
    7604:	0f b7 c0             	movzwl %ax,%eax
    7607:	8b 52 1c             	mov    0x1c(%rdx),%edx
    760a:	48 0f af c6          	imul   %rsi,%rax
    760e:	48 c1 e8 20          	shr    $0x20,%rax
    7612:	48 39 d0             	cmp    %rdx,%rax
    7615:	73 08                	jae    761f <fwp_task_dispose+0xbf>
    7617:	48 01 c1             	add    %rax,%rcx
    761a:	80 39 01             	cmpb   $0x1,(%rcx)
    761d:	74 09                	je     7628 <fwp_task_dispose+0xc8>
    761f:	5b                   	pop    %rbx
    7620:	c3                   	ret
    7621:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7628:	48 89 df             	mov    %rbx,%rdi
    762b:	5b                   	pop    %rbx
    762c:	e9 df e3 ff ff       	jmp    5a10 <fwp_mem_free>
    7631:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7638:	66 85 c0             	test   %ax,%ax
    763b:	74 dd                	je     761a <fwp_task_dispose+0xba>
    763d:	5b                   	pop    %rbx
    763e:	c3                   	ret
    763f:	90                   	nop

0000000000007640 <fwp_free_zombie>:
    7640:	48 8b 15 a9 11 06 00 	mov    0x611a9(%rip),%rdx        # 687f0 <fwp_zombie>
    7647:	48 85 d2             	test   %rdx,%rdx
    764a:	0f 84 98 00 00 00    	je     76e8 <fwp_free_zombie+0xa8>
    7650:	48 3b 15 a9 11 06 00 	cmp    0x611a9(%rip),%rdx        # 68800 <fwp_cur>
    7657:	0f 84 8b 00 00 00    	je     76e8 <fwp_free_zombie+0xa8>
    765d:	48 83 ec 18          	sub    $0x18,%rsp
    7661:	48 63 05 6c 0b 06 00 	movslq 0x60b6c(%rip),%rax        # 681d4 <fwp_stack_pool_n>
    7668:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    766c:	83 f8 3f             	cmp    $0x3f,%eax
    766f:	7f 7f                	jg     76f0 <fwp_free_zombie+0xb0>
    7671:	8d 48 01             	lea    0x1(%rax),%ecx
    7674:	89 0d 5a 0b 06 00    	mov    %ecx,0x60b5a(%rip)        # 681d4 <fwp_stack_pool_n>
    767a:	48 8d 0d 5f 0b 06 00 	lea    0x60b5f(%rip),%rcx        # 681e0 <fwp_stack_pool>
    7681:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7685:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    768c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7690:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7697:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    769b:	48 85 c9             	test   %rcx,%rcx
    769e:	0f 84 fc 00 00 00    	je     77a0 <fwp_free_zombie+0x160>
    76a4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    76ab:	48 85 c0             	test   %rax,%rax
    76ae:	74 07                	je     76b7 <fwp_free_zombie+0x77>
    76b0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    76b7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    76ba:	66 0f ef c0          	pxor   %xmm0,%xmm0
    76be:	48 c7 05 27 11 06 00 	movq   $0x0,0x61127(%rip)        # 687f0 <fwp_zombie>
    76c5:	00 00 00 00 
    76c9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    76d0:	85 c0                	test   %eax,%eax
    76d2:	74 34                	je     7708 <fwp_free_zombie+0xc8>
    76d4:	83 f8 01             	cmp    $0x1,%eax
    76d7:	0f 84 b3 00 00 00    	je     7790 <fwp_free_zombie+0x150>
    76dd:	48 83 c4 18          	add    $0x18,%rsp
    76e1:	c3                   	ret
    76e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76e8:	c3                   	ret
    76e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76f0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    76f4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    76f9:	e8 c2 be ff ff       	call   35c0 <munmap@plt>
    76fe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7703:	eb 80                	jmp    7685 <fwp_free_zombie+0x45>
    7705:	0f 1f 00             	nopl   (%rax)
    7708:	48 8b 0d e9 24 06 00 	mov    0x624e9(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    770f:	48 89 d0             	mov    %rdx,%rax
    7712:	48 2b 05 b7 24 06 00 	sub    0x624b7(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7719:	48 c1 e1 10          	shl    $0x10,%rcx
    771d:	48 39 c8             	cmp    %rcx,%rax
    7720:	73 bb                	jae    76dd <fwp_free_zombie+0x9d>
    7722:	48 89 c1             	mov    %rax,%rcx
    7725:	48 c1 e9 10          	shr    $0x10,%rcx
    7729:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    772d:	48 8b 0d e4 24 06 00 	mov    0x624e4(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    7734:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7738:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    773c:	48 85 c9             	test   %rcx,%rcx
    773f:	74 9c                	je     76dd <fwp_free_zombie+0x9d>
    7741:	0f b6 3e             	movzbl (%rsi),%edi
    7744:	40 80 ff 02          	cmp    $0x2,%dil
    7748:	74 66                	je     77b0 <fwp_free_zombie+0x170>
    774a:	40 80 ff 01          	cmp    $0x1,%dil
    774e:	75 8d                	jne    76dd <fwp_free_zombie+0x9d>
    7750:	8b 7e 18             	mov    0x18(%rsi),%edi
    7753:	0f b7 c0             	movzwl %ax,%eax
    7756:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7759:	48 0f af c7          	imul   %rdi,%rax
    775d:	48 c1 e8 20          	shr    $0x20,%rax
    7761:	48 39 f0             	cmp    %rsi,%rax
    7764:	0f 83 73 ff ff ff    	jae    76dd <fwp_free_zombie+0x9d>
    776a:	48 01 c1             	add    %rax,%rcx
    776d:	0f b6 01             	movzbl (%rcx),%eax
    7770:	84 c0                	test   %al,%al
    7772:	0f 84 65 ff ff ff    	je     76dd <fwp_free_zombie+0x9d>
    7778:	3c 01                	cmp    $0x1,%al
    777a:	74 14                	je     7790 <fwp_free_zombie+0x150>
    777c:	3c ff                	cmp    $0xff,%al
    777e:	74 3b                	je     77bb <fwp_free_zombie+0x17b>
    7780:	83 e8 01             	sub    $0x1,%eax
    7783:	88 01                	mov    %al,(%rcx)
    7785:	e9 53 ff ff ff       	jmp    76dd <fwp_free_zombie+0x9d>
    778a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7790:	48 89 d7             	mov    %rdx,%rdi
    7793:	48 83 c4 18          	add    $0x18,%rsp
    7797:	e9 c4 fd ff ff       	jmp    7560 <fwp_task_dispose>
    779c:	0f 1f 40 00          	nopl   0x0(%rax)
    77a0:	48 89 05 21 10 06 00 	mov    %rax,0x61021(%rip)        # 687c8 <fwp_tasks_active>
    77a7:	e9 ff fe ff ff       	jmp    76ab <fwp_free_zombie+0x6b>
    77ac:	0f 1f 40 00          	nopl   0x0(%rax)
    77b0:	66 85 c0             	test   %ax,%ax
    77b3:	0f 85 24 ff ff ff    	jne    76dd <fwp_free_zombie+0x9d>
    77b9:	eb b2                	jmp    776d <fwp_free_zombie+0x12d>
    77bb:	48 89 ca             	mov    %rcx,%rdx
    77be:	48 8d 35 5b 10 06 00 	lea    0x6105b(%rip),%rsi        # 68820 <fwp_heap>
    77c5:	48 c1 ea 11          	shr    $0x11,%rdx
    77c9:	48 31 ca             	xor    %rcx,%rdx
    77cc:	48 89 d0             	mov    %rdx,%rax
    77cf:	48 c1 e8 09          	shr    $0x9,%rax
    77d3:	48 31 c2             	xor    %rax,%rdx
    77d6:	0f b6 d2             	movzbl %dl,%edx
    77d9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    77e0:	00 
    77e1:	48 85 c0             	test   %rax,%rax
    77e4:	75 23                	jne    7809 <fwp_free_zombie+0x1c9>
    77e6:	eb 5c                	jmp    7844 <fwp_free_zombie+0x204>
    77e8:	66 90                	xchg   %ax,%ax
    77ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77f1:	00 00 00 00 
    77f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77fc:	00 00 00 00 
    7800:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7804:	48 85 c0             	test   %rax,%rax
    7807:	74 3b                	je     7844 <fwp_free_zombie+0x204>
    7809:	48 89 c2             	mov    %rax,%rdx
    780c:	48 39 08             	cmp    %rcx,(%rax)
    780f:	75 ef                	jne    7800 <fwp_free_zombie+0x1c0>
    7811:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7815:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7819:	48 89 50 08          	mov    %rdx,0x8(%rax)
    781d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7824:	0f 85 b3 fe ff ff    	jne    76dd <fwp_free_zombie+0x9d>
    782a:	48 89 cf             	mov    %rcx,%rdi
    782d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7832:	e8 99 df ff ff       	call   57d0 <fwp_rc_forget_slot>
    7837:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    783c:	c6 01 fe             	movb   $0xfe,(%rcx)
    783f:	e9 99 fe ff ff       	jmp    76dd <fwp_free_zombie+0x9d>
    7844:	48 8d 3d a5 51 00 00 	lea    0x51a5(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    784b:	e8 00 cc ff ff       	call   4450 <fwp_trap>

0000000000007850 <fwp_block>:
    7850:	48 83 ec 08          	sub    $0x8,%rsp
    7854:	48 8b 05 8d 0f 06 00 	mov    0x60f8d(%rip),%rax        # 687e8 <fwp_ready_head>
    785b:	48 85 c0             	test   %rax,%rax
    785e:	0f 84 1c 01 00 00    	je     7980 <fwp_block+0x130>
    7864:	90                   	nop
    7865:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    786c:	00 00 00 00 
    7870:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7877:	48 89 15 6a 0f 06 00 	mov    %rdx,0x60f6a(%rip)        # 687e8 <fwp_ready_head>
    787e:	48 85 d2             	test   %rdx,%rdx
    7881:	0f 84 19 01 00 00    	je     79a0 <fwp_block+0x150>
    7887:	48 8b 15 72 0f 06 00 	mov    0x60f72(%rip),%rdx        # 68800 <fwp_cur>
    788e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7892:	48 39 c2             	cmp    %rax,%rdx
    7895:	0f 84 d5 00 00 00    	je     7970 <fwp_block+0x120>
    789b:	48 8b 0d e6 2b 06 00 	mov    0x62be6(%rip),%rcx        # 6a488 <fwp_state_owners>
    78a2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    78a6:	48 89 05 53 0f 06 00 	mov    %rax,0x60f53(%rip)        # 68800 <fwp_cur>
    78ad:	f3 0f 7e 05 fb 2b 06 	movq   0x62bfb(%rip),%xmm0        # 6a4b0 <fwp_foreign_callbacks>
    78b4:	00 
    78b5:	0f 16 05 e4 2b 06 00 	movhps 0x62be4(%rip),%xmm0        # 6a4a0 <fwp_state>
    78bc:	f3 0f 7e 0d e4 2b 06 	movq   0x62be4(%rip),%xmm1        # 6a4a8 <fwp_handlers>
    78c3:	00 
    78c4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    78cb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    78d2:	0f 16 0d df 2b 06 00 	movhps 0x62bdf(%rip),%xmm1        # 6a4b8 <fwp_cleanups>
    78d9:	f3 0f 7e 05 b7 2b 06 	movq   0x62bb7(%rip),%xmm0        # 6a498 <fwp_state_len>
    78e0:	00 
    78e1:	0f 16 05 a8 2b 06 00 	movhps 0x62ba8(%rip),%xmm0        # 6a490 <fwp_state_cap>
    78e8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    78ef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    78f6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    78fa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7901:	48 89 0d a0 2b 06 00 	mov    %rcx,0x62ba0(%rip)        # 6a4a8 <fwp_handlers>
    7908:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    790f:	48 89 0d a2 2b 06 00 	mov    %rcx,0x62ba2(%rip)        # 6a4b8 <fwp_cleanups>
    7916:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    791d:	48 89 0d 8c 2b 06 00 	mov    %rcx,0x62b8c(%rip)        # 6a4b0 <fwp_foreign_callbacks>
    7924:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    792b:	48 89 0d 6e 2b 06 00 	mov    %rcx,0x62b6e(%rip)        # 6a4a0 <fwp_state>
    7932:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7939:	48 89 0d 58 2b 06 00 	mov    %rcx,0x62b58(%rip)        # 6a498 <fwp_state_len>
    7940:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7947:	48 89 0d 42 2b 06 00 	mov    %rcx,0x62b42(%rip)        # 6a490 <fwp_state_cap>
    794e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7955:	48 89 0d 2c 2b 06 00 	mov    %rcx,0x62b2c(%rip)        # 6a488 <fwp_state_owners>
    795c:	e8 1f bb ff ff       	call   3480 <swapcontext@plt>
    7961:	f3 0f 1e fa          	endbr64
    7965:	e8 d6 fc ff ff       	call   7640 <fwp_free_zombie>
    796a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7970:	8b 05 5a 08 06 00    	mov    0x6085a(%rip),%eax        # 681d0 <fwp_slice>
    7976:	85 c0                	test   %eax,%eax
    7978:	74 36                	je     79b0 <fwp_block+0x160>
    797a:	48 83 c4 08          	add    $0x8,%rsp
    797e:	c3                   	ret
    797f:	90                   	nop
    7980:	e8 8b da ff ff       	call   5410 <fwp_poll_events>
    7985:	48 8b 05 5c 0e 06 00 	mov    0x60e5c(%rip),%rax        # 687e8 <fwp_ready_head>
    798c:	48 85 c0             	test   %rax,%rax
    798f:	0f 85 db fe ff ff    	jne    7870 <fwp_block+0x20>
    7995:	eb e9                	jmp    7980 <fwp_block+0x130>
    7997:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    799e:	00 00 
    79a0:	48 c7 05 35 0e 06 00 	movq   $0x0,0x60e35(%rip)        # 687e0 <fwp_ready_tail>
    79a7:	00 00 00 00 
    79ab:	e9 d7 fe ff ff       	jmp    7887 <fwp_block+0x37>
    79b0:	48 8d 3d 28 48 00 00 	lea    0x4828(%rip),%rdi        # c1df <_IO_stdin_used+0x1df>
    79b7:	e8 d4 b9 ff ff       	call   3390 <getenv@plt>
    79bc:	ba 10 27 00 00       	mov    $0x2710,%edx
    79c1:	48 85 c0             	test   %rax,%rax
    79c4:	74 05                	je     79cb <fwp_block+0x17b>
    79c6:	80 38 00             	cmpb   $0x0,(%rax)
    79c9:	75 0b                	jne    79d6 <fwp_block+0x186>
    79cb:	89 15 ff 07 06 00    	mov    %edx,0x607ff(%rip)        # 681d0 <fwp_slice>
    79d1:	48 83 c4 08          	add    $0x8,%rsp
    79d5:	c3                   	ret
    79d6:	ba 0a 00 00 00       	mov    $0xa,%edx
    79db:	31 f6                	xor    %esi,%esi
    79dd:	48 89 c7             	mov    %rax,%rdi
    79e0:	e8 5b bb ff ff       	call   3540 <strtoll@plt>
    79e5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    79e9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    79f0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    79f5:	0f 46 d0             	cmovbe %eax,%edx
    79f8:	eb d1                	jmp    79cb <fwp_block+0x17b>
    79fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007a00 <fwp_caps173>:
    7a00:	f3 0f 1e fa          	endbr64
    7a04:	85 f6                	test   %esi,%esi
    7a06:	74 08                	je     7a10 <fwp_caps173+0x10>
    7a08:	c3                   	ret
    7a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a10:	48 8b 15 e1 21 06 00 	mov    0x621e1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7a17:	48 89 f8             	mov    %rdi,%rax
    7a1a:	48 2b 05 af 21 06 00 	sub    0x621af(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7a21:	48 c1 e2 10          	shl    $0x10,%rdx
    7a25:	48 39 d0             	cmp    %rdx,%rax
    7a28:	73 de                	jae    7a08 <fwp_caps173+0x8>
    7a2a:	48 89 c2             	mov    %rax,%rdx
    7a2d:	48 c1 ea 10          	shr    $0x10,%rdx
    7a31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a35:	48 8b 15 dc 21 06 00 	mov    0x621dc(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    7a3c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a40:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7a44:	48 85 c9             	test   %rcx,%rcx
    7a47:	74 bf                	je     7a08 <fwp_caps173+0x8>
    7a49:	0f b6 32             	movzbl (%rdx),%esi
    7a4c:	40 80 fe 02          	cmp    $0x2,%sil
    7a50:	74 2e                	je     7a80 <fwp_caps173+0x80>
    7a52:	40 80 fe 01          	cmp    $0x1,%sil
    7a56:	75 b0                	jne    7a08 <fwp_caps173+0x8>
    7a58:	8b 72 18             	mov    0x18(%rdx),%esi
    7a5b:	0f b7 c0             	movzwl %ax,%eax
    7a5e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a61:	48 0f af c6          	imul   %rsi,%rax
    7a65:	48 c1 e8 20          	shr    $0x20,%rax
    7a69:	48 39 d0             	cmp    %rdx,%rax
    7a6c:	73 9a                	jae    7a08 <fwp_caps173+0x8>
    7a6e:	48 01 c1             	add    %rax,%rcx
    7a71:	80 39 01             	cmpb   $0x1,(%rcx)
    7a74:	75 92                	jne    7a08 <fwp_caps173+0x8>
    7a76:	e9 95 df ff ff       	jmp    5a10 <fwp_mem_free>
    7a7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a80:	66 85 c0             	test   %ax,%ax
    7a83:	74 ec                	je     7a71 <fwp_caps173+0x71>
    7a85:	c3                   	ret
    7a86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a8d:	00 00 00 

0000000000007a90 <fwp_args37>:
    7a90:	f3 0f 1e fa          	endbr64
    7a94:	85 d2                	test   %edx,%edx
    7a96:	74 04                	je     7a9c <fwp_args37+0xc>
    7a98:	85 f6                	test   %esi,%esi
    7a9a:	74 04                	je     7aa0 <fwp_args37+0x10>
    7a9c:	c3                   	ret
    7a9d:	0f 1f 00             	nopl   (%rax)
    7aa0:	48 8b 15 51 21 06 00 	mov    0x62151(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7aa7:	48 8b 07             	mov    (%rdi),%rax
    7aaa:	48 2b 05 1f 21 06 00 	sub    0x6211f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7ab1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ab5:	48 39 d0             	cmp    %rdx,%rax
    7ab8:	73 e2                	jae    7a9c <fwp_args37+0xc>
    7aba:	48 89 c2             	mov    %rax,%rdx
    7abd:	48 c1 ea 10          	shr    $0x10,%rdx
    7ac1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ac5:	48 8b 15 4c 21 06 00 	mov    0x6214c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    7acc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ad0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ad4:	48 85 ff             	test   %rdi,%rdi
    7ad7:	74 c3                	je     7a9c <fwp_args37+0xc>
    7ad9:	0f b6 0a             	movzbl (%rdx),%ecx
    7adc:	80 f9 02             	cmp    $0x2,%cl
    7adf:	74 4f                	je     7b30 <fwp_args37+0xa0>
    7ae1:	80 f9 01             	cmp    $0x1,%cl
    7ae4:	75 b6                	jne    7a9c <fwp_args37+0xc>
    7ae6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ae9:	0f b7 c0             	movzwl %ax,%eax
    7aec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aef:	48 0f af c1          	imul   %rcx,%rax
    7af3:	48 c1 e8 20          	shr    $0x20,%rax
    7af7:	48 39 d0             	cmp    %rdx,%rax
    7afa:	73 a0                	jae    7a9c <fwp_args37+0xc>
    7afc:	48 01 c7             	add    %rax,%rdi
    7aff:	0f b6 07             	movzbl (%rdi),%eax
    7b02:	84 c0                	test   %al,%al
    7b04:	74 96                	je     7a9c <fwp_args37+0xc>
    7b06:	8b 15 dc 29 06 00    	mov    0x629dc(%rip),%edx        # 6a4e8 <iteration_active>
    7b0c:	85 d2                	test   %edx,%edx
    7b0e:	75 10                	jne    7b20 <fwp_args37+0x90>
    7b10:	3c fd                	cmp    $0xfd,%al
    7b12:	77 22                	ja     7b36 <fwp_args37+0xa6>
    7b14:	83 c0 01             	add    $0x1,%eax
    7b17:	88 07                	mov    %al,(%rdi)
    7b19:	c3                   	ret
    7b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b20:	48 83 05 a8 29 06 00 	addq   $0x1,0x629a8(%rip)        # 6a4d0 <iteration_retains>
    7b27:	01 
    7b28:	eb e6                	jmp    7b10 <fwp_args37+0x80>
    7b2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b30:	66 85 c0             	test   %ax,%ax
    7b33:	74 ca                	je     7aff <fwp_args37+0x6f>
    7b35:	c3                   	ret
    7b36:	e9 75 db ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7b3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007b40 <fwp_caps37>:
    7b40:	f3 0f 1e fa          	endbr64
    7b44:	48 83 ec 18          	sub    $0x18,%rsp
    7b48:	48 89 f8             	mov    %rdi,%rax
    7b4b:	8b 7f 04             	mov    0x4(%rdi),%edi
    7b4e:	85 ff                	test   %edi,%edi
    7b50:	0f 84 9a 00 00 00    	je     7bf0 <fwp_caps37+0xb0>
    7b56:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7b5a:	85 f6                	test   %esi,%esi
    7b5c:	0f 85 9e 00 00 00    	jne    7c00 <fwp_caps37+0xc0>
    7b62:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7b67:	e8 24 f7 ff ff       	call   7290 <fwp_drop4>
    7b6c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b71:	48 8b 0d 80 20 06 00 	mov    0x62080(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    7b78:	48 89 c2             	mov    %rax,%rdx
    7b7b:	48 2b 15 4e 20 06 00 	sub    0x6204e(%rip),%rdx        # 69bd0 <fwp_heap+0x13b0>
    7b82:	48 c1 e1 10          	shl    $0x10,%rcx
    7b86:	48 39 ca             	cmp    %rcx,%rdx
    7b89:	73 6d                	jae    7bf8 <fwp_caps37+0xb8>
    7b8b:	48 89 d1             	mov    %rdx,%rcx
    7b8e:	48 c1 e9 10          	shr    $0x10,%rcx
    7b92:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7b96:	48 8b 0d 7b 20 06 00 	mov    0x6207b(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    7b9d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7ba1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7ba5:	48 85 f6             	test   %rsi,%rsi
    7ba8:	74 4e                	je     7bf8 <fwp_caps37+0xb8>
    7baa:	0f b6 39             	movzbl (%rcx),%edi
    7bad:	40 80 ff 02          	cmp    $0x2,%dil
    7bb1:	0f 84 c9 00 00 00    	je     7c80 <fwp_caps37+0x140>
    7bb7:	40 80 ff 01          	cmp    $0x1,%dil
    7bbb:	75 3b                	jne    7bf8 <fwp_caps37+0xb8>
    7bbd:	8b 79 18             	mov    0x18(%rcx),%edi
    7bc0:	0f b7 d2             	movzwl %dx,%edx
    7bc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7bc6:	48 0f af d7          	imul   %rdi,%rdx
    7bca:	48 c1 ea 20          	shr    $0x20,%rdx
    7bce:	48 39 ca             	cmp    %rcx,%rdx
    7bd1:	73 25                	jae    7bf8 <fwp_caps37+0xb8>
    7bd3:	48 01 d6             	add    %rdx,%rsi
    7bd6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7bd9:	75 1d                	jne    7bf8 <fwp_caps37+0xb8>
    7bdb:	48 89 c7             	mov    %rax,%rdi
    7bde:	48 83 c4 18          	add    $0x18,%rsp
    7be2:	e9 29 de ff ff       	jmp    5a10 <fwp_mem_free>
    7be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bee:	00 00 
    7bf0:	85 f6                	test   %esi,%esi
    7bf2:	0f 84 79 ff ff ff    	je     7b71 <fwp_caps37+0x31>
    7bf8:	48 83 c4 18          	add    $0x18,%rsp
    7bfc:	c3                   	ret
    7bfd:	0f 1f 00             	nopl   (%rax)
    7c00:	48 8b 05 f1 1f 06 00 	mov    0x61ff1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    7c07:	48 2b 3d c2 1f 06 00 	sub    0x61fc2(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    7c0e:	48 c1 e0 10          	shl    $0x10,%rax
    7c12:	48 39 c7             	cmp    %rax,%rdi
    7c15:	73 e1                	jae    7bf8 <fwp_caps37+0xb8>
    7c17:	48 89 f8             	mov    %rdi,%rax
    7c1a:	48 c1 e8 10          	shr    $0x10,%rax
    7c1e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7c22:	48 8b 05 ef 1f 06 00 	mov    0x61fef(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    7c29:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7c2d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7c31:	48 85 c0             	test   %rax,%rax
    7c34:	74 c2                	je     7bf8 <fwp_caps37+0xb8>
    7c36:	0f b6 0a             	movzbl (%rdx),%ecx
    7c39:	80 f9 02             	cmp    $0x2,%cl
    7c3c:	74 52                	je     7c90 <fwp_caps37+0x150>
    7c3e:	80 f9 01             	cmp    $0x1,%cl
    7c41:	75 b5                	jne    7bf8 <fwp_caps37+0xb8>
    7c43:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c46:	0f b7 ff             	movzwl %di,%edi
    7c49:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c4c:	48 0f af f9          	imul   %rcx,%rdi
    7c50:	48 c1 ef 20          	shr    $0x20,%rdi
    7c54:	48 39 d7             	cmp    %rdx,%rdi
    7c57:	73 9f                	jae    7bf8 <fwp_caps37+0xb8>
    7c59:	48 01 f8             	add    %rdi,%rax
    7c5c:	0f b6 10             	movzbl (%rax),%edx
    7c5f:	84 d2                	test   %dl,%dl
    7c61:	74 95                	je     7bf8 <fwp_caps37+0xb8>
    7c63:	8b 0d 7f 28 06 00    	mov    0x6287f(%rip),%ecx        # 6a4e8 <iteration_active>
    7c69:	85 c9                	test   %ecx,%ecx
    7c6b:	75 33                	jne    7ca0 <fwp_caps37+0x160>
    7c6d:	80 fa fd             	cmp    $0xfd,%dl
    7c70:	77 38                	ja     7caa <fwp_caps37+0x16a>
    7c72:	83 c2 01             	add    $0x1,%edx
    7c75:	88 10                	mov    %dl,(%rax)
    7c77:	e9 7c ff ff ff       	jmp    7bf8 <fwp_caps37+0xb8>
    7c7c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c80:	66 85 d2             	test   %dx,%dx
    7c83:	0f 85 6f ff ff ff    	jne    7bf8 <fwp_caps37+0xb8>
    7c89:	e9 48 ff ff ff       	jmp    7bd6 <fwp_caps37+0x96>
    7c8e:	66 90                	xchg   %ax,%ax
    7c90:	66 85 ff             	test   %di,%di
    7c93:	0f 85 5f ff ff ff    	jne    7bf8 <fwp_caps37+0xb8>
    7c99:	eb c1                	jmp    7c5c <fwp_caps37+0x11c>
    7c9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ca0:	48 83 05 28 28 06 00 	addq   $0x1,0x62828(%rip)        # 6a4d0 <iteration_retains>
    7ca7:	01 
    7ca8:	eb c3                	jmp    7c6d <fwp_caps37+0x12d>
    7caa:	48 89 c7             	mov    %rax,%rdi
    7cad:	48 83 c4 18          	add    $0x18,%rsp
    7cb1:	e9 fa d9 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7cbd:	00 00 00 

0000000000007cc0 <fwp_drop0>:
    7cc0:	f3 0f 1e fa          	endbr64
    7cc4:	48 8b 15 2d 1f 06 00 	mov    0x61f2d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7ccb:	48 89 f8             	mov    %rdi,%rax
    7cce:	48 2b 05 fb 1e 06 00 	sub    0x61efb(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7cd5:	48 c1 e2 10          	shl    $0x10,%rdx
    7cd9:	48 39 d0             	cmp    %rdx,%rax
    7cdc:	0f 83 36 01 00 00    	jae    7e18 <fwp_drop0+0x158>
    7ce2:	48 83 ec 18          	sub    $0x18,%rsp
    7ce6:	48 8d 35 33 0b 06 00 	lea    0x60b33(%rip),%rsi        # 68820 <fwp_heap>
    7ced:	48 89 c2             	mov    %rax,%rdx
    7cf0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7cf7:	48 c1 ea 10          	shr    $0x10,%rdx
    7cfb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7cff:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7d03:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7d07:	48 85 d2             	test   %rdx,%rdx
    7d0a:	74 42                	je     7d4e <fwp_drop0+0x8e>
    7d0c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7d10:	41 80 f8 02          	cmp    $0x2,%r8b
    7d14:	74 42                	je     7d58 <fwp_drop0+0x98>
    7d16:	41 80 f8 01          	cmp    $0x1,%r8b
    7d1a:	75 32                	jne    7d4e <fwp_drop0+0x8e>
    7d1c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7d20:	0f b7 c0             	movzwl %ax,%eax
    7d23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d26:	49 0f af c0          	imul   %r8,%rax
    7d2a:	48 c1 e8 20          	shr    $0x20,%rax
    7d2e:	48 39 c8             	cmp    %rcx,%rax
    7d31:	73 1b                	jae    7d4e <fwp_drop0+0x8e>
    7d33:	48 01 c2             	add    %rax,%rdx
    7d36:	0f b6 02             	movzbl (%rdx),%eax
    7d39:	84 c0                	test   %al,%al
    7d3b:	74 11                	je     7d4e <fwp_drop0+0x8e>
    7d3d:	3c 01                	cmp    $0x1,%al
    7d3f:	74 27                	je     7d68 <fwp_drop0+0xa8>
    7d41:	3c ff                	cmp    $0xff,%al
    7d43:	0f 84 e7 00 00 00    	je     7e30 <fwp_drop0+0x170>
    7d49:	83 e8 01             	sub    $0x1,%eax
    7d4c:	88 02                	mov    %al,(%rdx)
    7d4e:	48 83 c4 18          	add    $0x18,%rsp
    7d52:	c3                   	ret
    7d53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d58:	66 85 c0             	test   %ax,%ax
    7d5b:	74 d9                	je     7d36 <fwp_drop0+0x76>
    7d5d:	48 83 c4 18          	add    $0x18,%rsp
    7d61:	c3                   	ret
    7d62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d68:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d6f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d76:	48 89 f8             	mov    %rdi,%rax
    7d79:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7d7d:	48 29 c8             	sub    %rcx,%rax
    7d80:	48 c1 e2 10          	shl    $0x10,%rdx
    7d84:	48 39 d0             	cmp    %rdx,%rax
    7d87:	73 71                	jae    7dfa <fwp_drop0+0x13a>
    7d89:	49 89 c2             	mov    %rax,%r10
    7d8c:	49 c1 ea 10          	shr    $0x10,%r10
    7d90:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7d94:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7d98:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7d9c:	4d 85 d2             	test   %r10,%r10
    7d9f:	74 59                	je     7dfa <fwp_drop0+0x13a>
    7da1:	45 0f b6 19          	movzbl (%r9),%r11d
    7da5:	41 80 fb 02          	cmp    $0x2,%r11b
    7da9:	74 75                	je     7e20 <fwp_drop0+0x160>
    7dab:	41 80 fb 01          	cmp    $0x1,%r11b
    7daf:	75 49                	jne    7dfa <fwp_drop0+0x13a>
    7db1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7db5:	0f b7 c0             	movzwl %ax,%eax
    7db8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7dbc:	49 0f af c3          	imul   %r11,%rax
    7dc0:	48 c1 e8 20          	shr    $0x20,%rax
    7dc4:	4c 39 c8             	cmp    %r9,%rax
    7dc7:	73 31                	jae    7dfa <fwp_drop0+0x13a>
    7dc9:	49 01 c2             	add    %rax,%r10
    7dcc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7dd0:	75 28                	jne    7dfa <fwp_drop0+0x13a>
    7dd2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7dd7:	e8 34 dc ff ff       	call   5a10 <fwp_mem_free>
    7ddc:	48 8d 35 3d 0a 06 00 	lea    0x60a3d(%rip),%rsi        # 68820 <fwp_heap>
    7de3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7de8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7def:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7df6:	48 c1 e2 10          	shl    $0x10,%rdx
    7dfa:	4c 89 c0             	mov    %r8,%rax
    7dfd:	48 29 c8             	sub    %rcx,%rax
    7e00:	48 39 d0             	cmp    %rdx,%rax
    7e03:	0f 83 45 ff ff ff    	jae    7d4e <fwp_drop0+0x8e>
    7e09:	4c 89 c7             	mov    %r8,%rdi
    7e0c:	e9 dc fe ff ff       	jmp    7ced <fwp_drop0+0x2d>
    7e11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e18:	c3                   	ret
    7e19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e20:	66 85 c0             	test   %ax,%ax
    7e23:	75 d5                	jne    7dfa <fwp_drop0+0x13a>
    7e25:	eb a5                	jmp    7dcc <fwp_drop0+0x10c>
    7e27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e2e:	00 00 
    7e30:	48 89 d0             	mov    %rdx,%rax
    7e33:	48 c1 e8 11          	shr    $0x11,%rax
    7e37:	48 31 d0             	xor    %rdx,%rax
    7e3a:	48 89 c1             	mov    %rax,%rcx
    7e3d:	48 c1 e9 09          	shr    $0x9,%rcx
    7e41:	48 31 c8             	xor    %rcx,%rax
    7e44:	0f b6 c8             	movzbl %al,%ecx
    7e47:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7e4e:	00 
    7e4f:	48 85 c0             	test   %rax,%rax
    7e52:	75 15                	jne    7e69 <fwp_drop0+0x1a9>
    7e54:	eb 4e                	jmp    7ea4 <fwp_drop0+0x1e4>
    7e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e5d:	00 00 00 
    7e60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7e64:	48 85 c0             	test   %rax,%rax
    7e67:	74 3b                	je     7ea4 <fwp_drop0+0x1e4>
    7e69:	48 89 c1             	mov    %rax,%rcx
    7e6c:	48 39 10             	cmp    %rdx,(%rax)
    7e6f:	75 ef                	jne    7e60 <fwp_drop0+0x1a0>
    7e71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7e79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7e7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7e84:	0f 85 c4 fe ff ff    	jne    7d4e <fwp_drop0+0x8e>
    7e8a:	48 89 d7             	mov    %rdx,%rdi
    7e8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e92:	e8 39 d9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7e97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7e9f:	e9 aa fe ff ff       	jmp    7d4e <fwp_drop0+0x8e>
    7ea4:	48 8d 3d 45 4b 00 00 	lea    0x4b45(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    7eab:	e8 a0 c5 ff ff       	call   4450 <fwp_trap>

0000000000007eb0 <fwp_drop1>:
    7eb0:	f3 0f 1e fa          	endbr64
    7eb4:	48 8b 15 3d 1d 06 00 	mov    0x61d3d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7ebb:	48 89 f8             	mov    %rdi,%rax
    7ebe:	48 2b 05 0b 1d 06 00 	sub    0x61d0b(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7ec5:	48 c1 e2 10          	shl    $0x10,%rdx
    7ec9:	48 39 d0             	cmp    %rdx,%rax
    7ecc:	0f 83 36 01 00 00    	jae    8008 <fwp_drop1+0x158>
    7ed2:	48 83 ec 18          	sub    $0x18,%rsp
    7ed6:	48 8d 35 43 09 06 00 	lea    0x60943(%rip),%rsi        # 68820 <fwp_heap>
    7edd:	48 89 c2             	mov    %rax,%rdx
    7ee0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7ee7:	48 c1 ea 10          	shr    $0x10,%rdx
    7eeb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7eef:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7ef3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7ef7:	48 85 d2             	test   %rdx,%rdx
    7efa:	74 42                	je     7f3e <fwp_drop1+0x8e>
    7efc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7f00:	41 80 f8 02          	cmp    $0x2,%r8b
    7f04:	74 42                	je     7f48 <fwp_drop1+0x98>
    7f06:	41 80 f8 01          	cmp    $0x1,%r8b
    7f0a:	75 32                	jne    7f3e <fwp_drop1+0x8e>
    7f0c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7f10:	0f b7 c0             	movzwl %ax,%eax
    7f13:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f16:	49 0f af c0          	imul   %r8,%rax
    7f1a:	48 c1 e8 20          	shr    $0x20,%rax
    7f1e:	48 39 c8             	cmp    %rcx,%rax
    7f21:	73 1b                	jae    7f3e <fwp_drop1+0x8e>
    7f23:	48 01 c2             	add    %rax,%rdx
    7f26:	0f b6 02             	movzbl (%rdx),%eax
    7f29:	84 c0                	test   %al,%al
    7f2b:	74 11                	je     7f3e <fwp_drop1+0x8e>
    7f2d:	3c 01                	cmp    $0x1,%al
    7f2f:	74 27                	je     7f58 <fwp_drop1+0xa8>
    7f31:	3c ff                	cmp    $0xff,%al
    7f33:	0f 84 e7 00 00 00    	je     8020 <fwp_drop1+0x170>
    7f39:	83 e8 01             	sub    $0x1,%eax
    7f3c:	88 02                	mov    %al,(%rdx)
    7f3e:	48 83 c4 18          	add    $0x18,%rsp
    7f42:	c3                   	ret
    7f43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7f48:	66 85 c0             	test   %ax,%ax
    7f4b:	74 d9                	je     7f26 <fwp_drop1+0x76>
    7f4d:	48 83 c4 18          	add    $0x18,%rsp
    7f51:	c3                   	ret
    7f52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f58:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7f5f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7f66:	48 89 f8             	mov    %rdi,%rax
    7f69:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7f6d:	48 29 c8             	sub    %rcx,%rax
    7f70:	48 c1 e2 10          	shl    $0x10,%rdx
    7f74:	48 39 d0             	cmp    %rdx,%rax
    7f77:	73 71                	jae    7fea <fwp_drop1+0x13a>
    7f79:	49 89 c2             	mov    %rax,%r10
    7f7c:	49 c1 ea 10          	shr    $0x10,%r10
    7f80:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7f84:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7f88:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7f8c:	4d 85 d2             	test   %r10,%r10
    7f8f:	74 59                	je     7fea <fwp_drop1+0x13a>
    7f91:	45 0f b6 19          	movzbl (%r9),%r11d
    7f95:	41 80 fb 02          	cmp    $0x2,%r11b
    7f99:	74 75                	je     8010 <fwp_drop1+0x160>
    7f9b:	41 80 fb 01          	cmp    $0x1,%r11b
    7f9f:	75 49                	jne    7fea <fwp_drop1+0x13a>
    7fa1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7fa5:	0f b7 c0             	movzwl %ax,%eax
    7fa8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7fac:	49 0f af c3          	imul   %r11,%rax
    7fb0:	48 c1 e8 20          	shr    $0x20,%rax
    7fb4:	4c 39 c8             	cmp    %r9,%rax
    7fb7:	73 31                	jae    7fea <fwp_drop1+0x13a>
    7fb9:	49 01 c2             	add    %rax,%r10
    7fbc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7fc0:	75 28                	jne    7fea <fwp_drop1+0x13a>
    7fc2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7fc7:	e8 44 da ff ff       	call   5a10 <fwp_mem_free>
    7fcc:	48 8d 35 4d 08 06 00 	lea    0x6084d(%rip),%rsi        # 68820 <fwp_heap>
    7fd3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7fd8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7fdf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7fe6:	48 c1 e2 10          	shl    $0x10,%rdx
    7fea:	4c 89 c0             	mov    %r8,%rax
    7fed:	48 29 c8             	sub    %rcx,%rax
    7ff0:	48 39 d0             	cmp    %rdx,%rax
    7ff3:	0f 83 45 ff ff ff    	jae    7f3e <fwp_drop1+0x8e>
    7ff9:	4c 89 c7             	mov    %r8,%rdi
    7ffc:	e9 dc fe ff ff       	jmp    7edd <fwp_drop1+0x2d>
    8001:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8008:	c3                   	ret
    8009:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8010:	66 85 c0             	test   %ax,%ax
    8013:	75 d5                	jne    7fea <fwp_drop1+0x13a>
    8015:	eb a5                	jmp    7fbc <fwp_drop1+0x10c>
    8017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    801e:	00 00 
    8020:	48 89 d0             	mov    %rdx,%rax
    8023:	48 c1 e8 11          	shr    $0x11,%rax
    8027:	48 31 d0             	xor    %rdx,%rax
    802a:	48 89 c1             	mov    %rax,%rcx
    802d:	48 c1 e9 09          	shr    $0x9,%rcx
    8031:	48 31 c8             	xor    %rcx,%rax
    8034:	0f b6 c8             	movzbl %al,%ecx
    8037:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    803e:	00 
    803f:	48 85 c0             	test   %rax,%rax
    8042:	75 25                	jne    8069 <fwp_drop1+0x1b9>
    8044:	eb 5e                	jmp    80a4 <fwp_drop1+0x1f4>
    8046:	0f 1f 40 00          	nopl   0x0(%rax)
    804a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8051:	00 00 00 00 
    8055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    805c:	00 00 00 00 
    8060:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8064:	48 85 c0             	test   %rax,%rax
    8067:	74 3b                	je     80a4 <fwp_drop1+0x1f4>
    8069:	48 89 c1             	mov    %rax,%rcx
    806c:	48 39 10             	cmp    %rdx,(%rax)
    806f:	75 ef                	jne    8060 <fwp_drop1+0x1b0>
    8071:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8075:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8079:	48 89 48 08          	mov    %rcx,0x8(%rax)
    807d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8084:	0f 85 b4 fe ff ff    	jne    7f3e <fwp_drop1+0x8e>
    808a:	48 89 d7             	mov    %rdx,%rdi
    808d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8092:	e8 39 d7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8097:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    809c:	c6 02 fe             	movb   $0xfe,(%rdx)
    809f:	e9 9a fe ff ff       	jmp    7f3e <fwp_drop1+0x8e>
    80a4:	48 8d 3d 45 49 00 00 	lea    0x4945(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    80ab:	e8 a0 c3 ff ff       	call   4450 <fwp_trap>

00000000000080b0 <fwp_drop10>:
    80b0:	48 8b 0d 41 1b 06 00 	mov    0x61b41(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    80b7:	48 89 f8             	mov    %rdi,%rax
    80ba:	48 2b 05 0f 1b 06 00 	sub    0x61b0f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    80c1:	48 c1 e1 10          	shl    $0x10,%rcx
    80c5:	48 39 c8             	cmp    %rcx,%rax
    80c8:	0f 83 c2 01 00 00    	jae    8290 <fwp_drop10+0x1e0>
    80ce:	48 83 ec 18          	sub    $0x18,%rsp
    80d2:	48 89 fa             	mov    %rdi,%rdx
    80d5:	48 8d 35 44 07 06 00 	lea    0x60744(%rip),%rsi        # 68820 <fwp_heap>
    80dc:	48 89 c1             	mov    %rax,%rcx
    80df:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    80e6:	48 c1 e9 10          	shr    $0x10,%rcx
    80ea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    80ee:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    80f2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    80f6:	48 85 c9             	test   %rcx,%rcx
    80f9:	74 46                	je     8141 <fwp_drop10+0x91>
    80fb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    80ff:	41 80 f9 02          	cmp    $0x2,%r9b
    8103:	0f 84 d7 00 00 00    	je     81e0 <fwp_drop10+0x130>
    8109:	41 80 f9 01          	cmp    $0x1,%r9b
    810d:	75 32                	jne    8141 <fwp_drop10+0x91>
    810f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    8113:	0f b7 c0             	movzwl %ax,%eax
    8116:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    8119:	49 0f af c1          	imul   %r9,%rax
    811d:	48 c1 e8 20          	shr    $0x20,%rax
    8121:	48 39 f8             	cmp    %rdi,%rax
    8124:	73 1b                	jae    8141 <fwp_drop10+0x91>
    8126:	48 01 c1             	add    %rax,%rcx
    8129:	0f b6 01             	movzbl (%rcx),%eax
    812c:	84 c0                	test   %al,%al
    812e:	74 11                	je     8141 <fwp_drop10+0x91>
    8130:	3c 01                	cmp    $0x1,%al
    8132:	74 1c                	je     8150 <fwp_drop10+0xa0>
    8134:	3c ff                	cmp    $0xff,%al
    8136:	0f 84 5c 01 00 00    	je     8298 <fwp_drop10+0x1e8>
    813c:	83 e8 01             	sub    $0x1,%eax
    813f:	88 01                	mov    %al,(%rcx)
    8141:	48 83 c4 18          	add    $0x18,%rsp
    8145:	c3                   	ret
    8146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    814d:	00 00 00 
    8150:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8157:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    815e:	48 89 d0             	mov    %rdx,%rax
    8161:	49 89 d1             	mov    %rdx,%r9
    8164:	48 c1 e1 10          	shl    $0x10,%rcx
    8168:	48 29 f8             	sub    %rdi,%rax
    816b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    816f:	78 7f                	js     81f0 <fwp_drop10+0x140>
    8171:	48 39 c8             	cmp    %rcx,%rax
    8174:	73 cb                	jae    8141 <fwp_drop10+0x91>
    8176:	48 89 c1             	mov    %rax,%rcx
    8179:	48 c1 e9 10          	shr    $0x10,%rcx
    817d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8181:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8185:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8189:	48 85 f6             	test   %rsi,%rsi
    818c:	74 b3                	je     8141 <fwp_drop10+0x91>
    818e:	0f b6 39             	movzbl (%rcx),%edi
    8191:	40 80 ff 02          	cmp    $0x2,%dil
    8195:	74 39                	je     81d0 <fwp_drop10+0x120>
    8197:	40 80 ff 01          	cmp    $0x1,%dil
    819b:	75 a4                	jne    8141 <fwp_drop10+0x91>
    819d:	8b 79 18             	mov    0x18(%rcx),%edi
    81a0:	0f b7 c0             	movzwl %ax,%eax
    81a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    81a6:	48 0f af c7          	imul   %rdi,%rax
    81aa:	48 c1 e8 20          	shr    $0x20,%rax
    81ae:	48 39 c8             	cmp    %rcx,%rax
    81b1:	73 8e                	jae    8141 <fwp_drop10+0x91>
    81b3:	48 01 c6             	add    %rax,%rsi
    81b6:	80 3e 01             	cmpb   $0x1,(%rsi)
    81b9:	75 86                	jne    8141 <fwp_drop10+0x91>
    81bb:	48 89 d7             	mov    %rdx,%rdi
    81be:	48 83 c4 18          	add    $0x18,%rsp
    81c2:	e9 49 d8 ff ff       	jmp    5a10 <fwp_mem_free>
    81c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81ce:	00 00 
    81d0:	66 85 c0             	test   %ax,%ax
    81d3:	74 e1                	je     81b6 <fwp_drop10+0x106>
    81d5:	48 83 c4 18          	add    $0x18,%rsp
    81d9:	c3                   	ret
    81da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81e0:	66 85 c0             	test   %ax,%ax
    81e3:	0f 84 40 ff ff ff    	je     8129 <fwp_drop10+0x79>
    81e9:	48 83 c4 18          	add    $0x18,%rsp
    81ed:	c3                   	ret
    81ee:	66 90                	xchg   %ax,%ax
    81f0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    81f4:	48 39 c8             	cmp    %rcx,%rax
    81f7:	73 74                	jae    826d <fwp_drop10+0x1bd>
    81f9:	49 89 c2             	mov    %rax,%r10
    81fc:	49 c1 ea 10          	shr    $0x10,%r10
    8200:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8204:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8208:	4d 8b 50 20          	mov    0x20(%r8),%r10
    820c:	4d 85 d2             	test   %r10,%r10
    820f:	74 5c                	je     826d <fwp_drop10+0x1bd>
    8211:	45 0f b6 18          	movzbl (%r8),%r11d
    8215:	41 80 fb 02          	cmp    $0x2,%r11b
    8219:	74 6d                	je     8288 <fwp_drop10+0x1d8>
    821b:	41 80 fb 01          	cmp    $0x1,%r11b
    821f:	75 4c                	jne    826d <fwp_drop10+0x1bd>
    8221:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8225:	0f b7 c0             	movzwl %ax,%eax
    8228:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    822c:	49 0f af c3          	imul   %r11,%rax
    8230:	48 c1 e8 20          	shr    $0x20,%rax
    8234:	4c 39 c0             	cmp    %r8,%rax
    8237:	73 34                	jae    826d <fwp_drop10+0x1bd>
    8239:	49 01 c2             	add    %rax,%r10
    823c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8240:	75 2b                	jne    826d <fwp_drop10+0x1bd>
    8242:	4c 89 cf             	mov    %r9,%rdi
    8245:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    824a:	e8 c1 d7 ff ff       	call   5a10 <fwp_mem_free>
    824f:	48 8d 35 ca 05 06 00 	lea    0x605ca(%rip),%rsi        # 68820 <fwp_heap>
    8256:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    825b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8262:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8269:	48 c1 e1 10          	shl    $0x10,%rcx
    826d:	48 89 d0             	mov    %rdx,%rax
    8270:	48 29 f8             	sub    %rdi,%rax
    8273:	48 39 c8             	cmp    %rcx,%rax
    8276:	0f 82 60 fe ff ff    	jb     80dc <fwp_drop10+0x2c>
    827c:	e9 c0 fe ff ff       	jmp    8141 <fwp_drop10+0x91>
    8281:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8288:	66 85 c0             	test   %ax,%ax
    828b:	75 e0                	jne    826d <fwp_drop10+0x1bd>
    828d:	eb ad                	jmp    823c <fwp_drop10+0x18c>
    828f:	90                   	nop
    8290:	c3                   	ret
    8291:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8298:	48 89 c8             	mov    %rcx,%rax
    829b:	48 c1 e8 11          	shr    $0x11,%rax
    829f:	48 31 c8             	xor    %rcx,%rax
    82a2:	48 89 c2             	mov    %rax,%rdx
    82a5:	48 c1 ea 09          	shr    $0x9,%rdx
    82a9:	48 31 d0             	xor    %rdx,%rax
    82ac:	0f b6 d0             	movzbl %al,%edx
    82af:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    82b6:	00 
    82b7:	48 85 c0             	test   %rax,%rax
    82ba:	75 0d                	jne    82c9 <fwp_drop10+0x219>
    82bc:	eb 46                	jmp    8304 <fwp_drop10+0x254>
    82be:	66 90                	xchg   %ax,%ax
    82c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    82c4:	48 85 c0             	test   %rax,%rax
    82c7:	74 3b                	je     8304 <fwp_drop10+0x254>
    82c9:	48 89 c2             	mov    %rax,%rdx
    82cc:	48 39 08             	cmp    %rcx,(%rax)
    82cf:	75 ef                	jne    82c0 <fwp_drop10+0x210>
    82d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    82d5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    82d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    82dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    82e4:	0f 85 57 fe ff ff    	jne    8141 <fwp_drop10+0x91>
    82ea:	48 89 cf             	mov    %rcx,%rdi
    82ed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    82f2:	e8 d9 d4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    82f7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    82fc:	c6 01 fe             	movb   $0xfe,(%rcx)
    82ff:	e9 3d fe ff ff       	jmp    8141 <fwp_drop10+0x91>
    8304:	48 8d 3d e5 46 00 00 	lea    0x46e5(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    830b:	e8 40 c1 ff ff       	call   4450 <fwp_trap>

0000000000008310 <f37>:
    8310:	41 57                	push   %r15
    8312:	41 56                	push   %r14
    8314:	41 55                	push   %r13
    8316:	41 54                	push   %r12
    8318:	55                   	push   %rbp
    8319:	53                   	push   %rbx
    831a:	48 83 ec 38          	sub    $0x38,%rsp
    831e:	48 8b 15 d3 18 06 00 	mov    0x618d3(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    8325:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    832a:	48 c1 e2 10          	shl    $0x10,%rdx
    832e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8335:	00 00 
    8337:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    833c:	48 8b 0d 8d 18 06 00 	mov    0x6188d(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    8343:	48 85 ff             	test   %rdi,%rdi
    8346:	0f 84 1e 03 00 00    	je     866a <f37+0x35a>
    834c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8351:	4c 8b 68 10          	mov    0x10(%rax),%r13
    8355:	4c 89 e8             	mov    %r13,%rax
    8358:	48 29 c8             	sub    %rcx,%rax
    835b:	48 39 d0             	cmp    %rdx,%rax
    835e:	0f 83 ec 02 00 00    	jae    8650 <f37+0x340>
    8364:	48 89 c2             	mov    %rax,%rdx
    8367:	48 c1 ea 10          	shr    $0x10,%rdx
    836b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    836f:	48 8b 15 a2 18 06 00 	mov    0x618a2(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8376:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    837a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    837e:	48 85 ff             	test   %rdi,%rdi
    8381:	0f 84 c9 02 00 00    	je     8650 <f37+0x340>
    8387:	0f b6 0a             	movzbl (%rdx),%ecx
    838a:	80 f9 02             	cmp    $0x2,%cl
    838d:	0f 84 4d 02 00 00    	je     85e0 <f37+0x2d0>
    8393:	80 f9 01             	cmp    $0x1,%cl
    8396:	75 24                	jne    83bc <f37+0xac>
    8398:	8b 4a 18             	mov    0x18(%rdx),%ecx
    839b:	0f b7 c0             	movzwl %ax,%eax
    839e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83a1:	48 0f af c1          	imul   %rcx,%rax
    83a5:	48 c1 e8 20          	shr    $0x20,%rax
    83a9:	48 39 d0             	cmp    %rdx,%rax
    83ac:	73 0e                	jae    83bc <f37+0xac>
    83ae:	48 01 c7             	add    %rax,%rdi
    83b1:	0f b6 07             	movzbl (%rdi),%eax
    83b4:	84 c0                	test   %al,%al
    83b6:	0f 85 44 02 00 00    	jne    8600 <f37+0x2f0>
    83bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    83c1:	48 8b 40 10          	mov    0x10(%rax),%rax
    83c5:	ba 01 00 00 00       	mov    $0x1,%edx
    83ca:	48 85 c0             	test   %rax,%rax
    83cd:	74 0e                	je     83dd <f37+0xcd>
    83cf:	90                   	nop
    83d0:	48 8b 40 10          	mov    0x10(%rax),%rax
    83d4:	48 83 c2 01          	add    $0x1,%rdx
    83d8:	48 85 c0             	test   %rax,%rax
    83db:	75 f3                	jne    83d0 <f37+0xc0>
    83dd:	4d 85 ed             	test   %r13,%r13
    83e0:	0f 84 9a 02 00 00    	je     8680 <f37+0x370>
    83e6:	4c 89 e8             	mov    %r13,%rax
    83e9:	31 db                	xor    %ebx,%ebx
    83eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    83f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    83f4:	48 83 c3 01          	add    $0x1,%rbx
    83f8:	48 85 c0             	test   %rax,%rax
    83fb:	75 f3                	jne    83f0 <f37+0xe0>
    83fd:	48 39 d3             	cmp    %rdx,%rbx
    8400:	48 0f 47 da          	cmova  %rdx,%rbx
    8404:	48 89 d8             	mov    %rbx,%rax
    8407:	48 c1 e8 3c          	shr    $0x3c,%rax
    840b:	0f 85 7d 03 00 00    	jne    878e <f37+0x47e>
    8411:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8415:	be 02 00 00 00       	mov    $0x2,%esi
    841a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8421:	00 
    8422:	e8 e9 da ff ff       	call   5f10 <fwp_heap_alloc>
    8427:	48 89 28             	mov    %rbp,(%rax)
    842a:	48 8b 15 c7 17 06 00 	mov    0x617c7(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    8431:	49 89 c4             	mov    %rax,%r12
    8434:	48 2b 05 95 17 06 00 	sub    0x61795(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    843b:	48 c1 e2 10          	shl    $0x10,%rdx
    843f:	48 39 d0             	cmp    %rdx,%rax
    8442:	73 57                	jae    849b <f37+0x18b>
    8444:	48 89 c2             	mov    %rax,%rdx
    8447:	48 c1 ea 10          	shr    $0x10,%rdx
    844b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    844f:	48 8b 15 c2 17 06 00 	mov    0x617c2(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8456:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    845a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    845e:	48 85 ed             	test   %rbp,%rbp
    8461:	74 38                	je     849b <f37+0x18b>
    8463:	0f b6 0a             	movzbl (%rdx),%ecx
    8466:	80 f9 02             	cmp    $0x2,%cl
    8469:	0f 84 d1 01 00 00    	je     8640 <f37+0x330>
    846f:	80 f9 01             	cmp    $0x1,%cl
    8472:	75 27                	jne    849b <f37+0x18b>
    8474:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8477:	0f b7 c0             	movzwl %ax,%eax
    847a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    847d:	48 0f af c1          	imul   %rcx,%rax
    8481:	48 c1 e8 20          	shr    $0x20,%rax
    8485:	48 39 d0             	cmp    %rdx,%rax
    8488:	73 11                	jae    849b <f37+0x18b>
    848a:	48 01 c5             	add    %rax,%rbp
    848d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8491:	0f 84 57 02 00 00    	je     86ee <f37+0x3de>
    8497:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    849b:	48 85 db             	test   %rbx,%rbx
    849e:	74 5d                	je     84fd <f37+0x1ed>
    84a0:	48 c1 e3 04          	shl    $0x4,%rbx
    84a4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    84a9:	4c 89 e5             	mov    %r12,%rbp
    84ac:	4d 89 ef             	mov    %r13,%r15
    84af:	4c 01 e3             	add    %r12,%rbx
    84b2:	0f 1f 00             	nopl   (%rax)
    84b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    84bc:	00 00 00 00 
    84c0:	49 8b 46 08          	mov    0x8(%r14),%rax
    84c4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    84c8:	48 83 c5 10          	add    $0x10,%rbp
    84cc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    84d1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    84d5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    84d9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    84de:	e8 0d e3 ff ff       	call   67f0 <w120>
    84e3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    84e8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    84ec:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    84f0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    84f4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    84f8:	48 39 dd             	cmp    %rbx,%rbp
    84fb:	75 c3                	jne    84c0 <f37+0x1b0>
    84fd:	4c 89 ef             	mov    %r13,%rdi
    8500:	e8 8b ed ff ff       	call   7290 <fwp_drop4>
    8505:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    850a:	e8 81 ed ff ff       	call   7290 <fwp_drop4>
    850f:	4c 89 e7             	mov    %r12,%rdi
    8512:	e8 99 e4 ff ff       	call   69b0 <w176.constprop.0>
    8517:	4c 89 e7             	mov    %r12,%rdi
    851a:	48 89 c3             	mov    %rax,%rbx
    851d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8523:	e8 88 fb ff ff       	call   80b0 <fwp_drop10>
    8528:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    852e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8533:	31 ff                	xor    %edi,%edi
    8535:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    853a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    853e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8543:	e8 b8 db ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    8548:	48 8b 15 a9 16 06 00 	mov    0x616a9(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    854f:	48 89 c5             	mov    %rax,%rbp
    8552:	48 2b 05 77 16 06 00 	sub    0x61677(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    8559:	48 c1 e2 10          	shl    $0x10,%rdx
    855d:	48 39 d0             	cmp    %rdx,%rax
    8560:	73 55                	jae    85b7 <f37+0x2a7>
    8562:	48 89 c2             	mov    %rax,%rdx
    8565:	48 c1 ea 10          	shr    $0x10,%rdx
    8569:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    856d:	48 8b 15 a4 16 06 00 	mov    0x616a4(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8574:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8578:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    857c:	48 85 db             	test   %rbx,%rbx
    857f:	74 36                	je     85b7 <f37+0x2a7>
    8581:	0f b6 0a             	movzbl (%rdx),%ecx
    8584:	80 f9 02             	cmp    $0x2,%cl
    8587:	0f 84 a3 00 00 00    	je     8630 <f37+0x320>
    858d:	80 f9 01             	cmp    $0x1,%cl
    8590:	75 25                	jne    85b7 <f37+0x2a7>
    8592:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8595:	0f b7 c0             	movzwl %ax,%eax
    8598:	8b 52 1c             	mov    0x1c(%rdx),%edx
    859b:	48 0f af c1          	imul   %rcx,%rax
    859f:	48 c1 e8 20          	shr    $0x20,%rax
    85a3:	48 39 d0             	cmp    %rdx,%rax
    85a6:	73 0f                	jae    85b7 <f37+0x2a7>
    85a8:	48 01 c3             	add    %rax,%rbx
    85ab:	80 3b ff             	cmpb   $0xff,(%rbx)
    85ae:	0f 84 2d 01 00 00    	je     86e1 <f37+0x3d1>
    85b4:	c6 03 01             	movb   $0x1,(%rbx)
    85b7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    85bc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    85c3:	00 00 
    85c5:	0f 85 cf 01 00 00    	jne    879a <f37+0x48a>
    85cb:	48 83 c4 38          	add    $0x38,%rsp
    85cf:	48 89 e8             	mov    %rbp,%rax
    85d2:	5b                   	pop    %rbx
    85d3:	5d                   	pop    %rbp
    85d4:	41 5c                	pop    %r12
    85d6:	41 5d                	pop    %r13
    85d8:	41 5e                	pop    %r14
    85da:	41 5f                	pop    %r15
    85dc:	c3                   	ret
    85dd:	0f 1f 00             	nopl   (%rax)
    85e0:	66 85 c0             	test   %ax,%ax
    85e3:	0f 85 d3 fd ff ff    	jne    83bc <f37+0xac>
    85e9:	0f b6 07             	movzbl (%rdi),%eax
    85ec:	84 c0                	test   %al,%al
    85ee:	0f 84 c8 fd ff ff    	je     83bc <f37+0xac>
    85f4:	90                   	nop
    85f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    85fc:	00 00 00 00 
    8600:	8b 15 e2 1e 06 00    	mov    0x61ee2(%rip),%edx        # 6a4e8 <iteration_active>
    8606:	85 d2                	test   %edx,%edx
    8608:	75 56                	jne    8660 <f37+0x350>
    860a:	3c fd                	cmp    $0xfd,%al
    860c:	0f 87 4b 01 00 00    	ja     875d <f37+0x44d>
    8612:	83 c0 01             	add    $0x1,%eax
    8615:	88 07                	mov    %al,(%rdi)
    8617:	31 d2                	xor    %edx,%edx
    8619:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    861f:	0f 85 97 fd ff ff    	jne    83bc <f37+0xac>
    8625:	e9 b3 fd ff ff       	jmp    83dd <f37+0xcd>
    862a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8630:	66 85 c0             	test   %ax,%ax
    8633:	0f 85 7e ff ff ff    	jne    85b7 <f37+0x2a7>
    8639:	e9 6d ff ff ff       	jmp    85ab <f37+0x29b>
    863e:	66 90                	xchg   %ax,%ax
    8640:	66 85 c0             	test   %ax,%ax
    8643:	0f 85 52 fe ff ff    	jne    849b <f37+0x18b>
    8649:	e9 3f fe ff ff       	jmp    848d <f37+0x17d>
    864e:	66 90                	xchg   %ax,%ax
    8650:	4c 89 e8             	mov    %r13,%rax
    8653:	e9 6d fd ff ff       	jmp    83c5 <f37+0xb5>
    8658:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    865f:	00 
    8660:	48 83 05 68 1e 06 00 	addq   $0x1,0x61e68(%rip)        # 6a4d0 <iteration_retains>
    8667:	01 
    8668:	eb a0                	jmp    860a <f37+0x2fa>
    866a:	48 f7 d9             	neg    %rcx
    866d:	48 39 d1             	cmp    %rdx,%rcx
    8670:	0f 82 85 00 00 00    	jb     86fb <f37+0x3eb>
    8676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    867d:	00 00 00 
    8680:	be 02 00 00 00       	mov    $0x2,%esi
    8685:	bf 08 00 00 00       	mov    $0x8,%edi
    868a:	e8 81 d8 ff ff       	call   5f10 <fwp_heap_alloc>
    868f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8696:	48 8b 15 5b 15 06 00 	mov    0x6155b(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    869d:	49 89 c4             	mov    %rax,%r12
    86a0:	48 2b 05 29 15 06 00 	sub    0x61529(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    86a7:	48 c1 e2 10          	shl    $0x10,%rdx
    86ab:	48 39 d0             	cmp    %rdx,%rax
    86ae:	0f 83 b3 00 00 00    	jae    8767 <f37+0x457>
    86b4:	48 89 c2             	mov    %rax,%rdx
    86b7:	48 c1 ea 10          	shr    $0x10,%rdx
    86bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86bf:	48 8b 15 52 15 06 00 	mov    0x61552(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    86c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86ca:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    86ce:	48 85 ed             	test   %rbp,%rbp
    86d1:	0f 84 90 00 00 00    	je     8767 <f37+0x457>
    86d7:	31 db                	xor    %ebx,%ebx
    86d9:	45 31 ed             	xor    %r13d,%r13d
    86dc:	e9 82 fd ff ff       	jmp    8463 <f37+0x153>
    86e1:	48 89 df             	mov    %rbx,%rdi
    86e4:	e8 e7 d0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    86e9:	e9 c6 fe ff ff       	jmp    85b4 <f37+0x2a4>
    86ee:	48 89 ef             	mov    %rbp,%rdi
    86f1:	e8 da d0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    86f6:	e9 9c fd ff ff       	jmp    8497 <f37+0x187>
    86fb:	48 89 c8             	mov    %rcx,%rax
    86fe:	48 c1 e8 10          	shr    $0x10,%rax
    8702:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8706:	48 8b 05 0b 15 06 00 	mov    0x6150b(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    870d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8711:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8715:	48 85 ff             	test   %rdi,%rdi
    8718:	0f 84 62 ff ff ff    	je     8680 <f37+0x370>
    871e:	0f b6 02             	movzbl (%rdx),%eax
    8721:	3c 02                	cmp    $0x2,%al
    8723:	74 4a                	je     876f <f37+0x45f>
    8725:	3c 01                	cmp    $0x1,%al
    8727:	0f 85 53 ff ff ff    	jne    8680 <f37+0x370>
    872d:	0f b7 c1             	movzwl %cx,%eax
    8730:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8733:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8736:	48 0f af c1          	imul   %rcx,%rax
    873a:	48 c1 e8 20          	shr    $0x20,%rax
    873e:	48 39 d0             	cmp    %rdx,%rax
    8741:	0f 83 39 ff ff ff    	jae    8680 <f37+0x370>
    8747:	48 01 c7             	add    %rax,%rdi
    874a:	0f b6 07             	movzbl (%rdi),%eax
    874d:	84 c0                	test   %al,%al
    874f:	0f 84 2b ff ff ff    	je     8680 <f37+0x370>
    8755:	45 31 ed             	xor    %r13d,%r13d
    8758:	e9 a3 fe ff ff       	jmp    8600 <f37+0x2f0>
    875d:	e8 4e cf ff ff       	call   56b0 <fwp_rc_wide_dup>
    8762:	e9 b0 fe ff ff       	jmp    8617 <f37+0x307>
    8767:	45 31 ed             	xor    %r13d,%r13d
    876a:	e9 8e fd ff ff       	jmp    84fd <f37+0x1ed>
    876f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8775:	49 89 cd             	mov    %rcx,%r13
    8778:	0f 85 02 ff ff ff    	jne    8680 <f37+0x370>
    877e:	0f b6 07             	movzbl (%rdi),%eax
    8781:	84 c0                	test   %al,%al
    8783:	0f 85 77 fe ff ff    	jne    8600 <f37+0x2f0>
    8789:	e9 f2 fe ff ff       	jmp    8680 <f37+0x370>
    878e:	48 8d 3d 56 3a 00 00 	lea    0x3a56(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    8795:	e8 b6 bc ff ff       	call   4450 <fwp_trap>
    879a:	e8 b1 ac ff ff       	call   3450 <__stack_chk_fail@plt>
    879f:	90                   	nop

00000000000087a0 <fwp_owned_entry37>:
    87a0:	f3 0f 1e fa          	endbr64
    87a4:	48 8b 3f             	mov    (%rdi),%rdi
    87a7:	e9 64 fb ff ff       	jmp    8310 <f37>
    87ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000087b0 <e37>:
    87b0:	f3 0f 1e fa          	endbr64
    87b4:	53                   	push   %rbx
    87b5:	48 8b 1f             	mov    (%rdi),%rbx
    87b8:	48 89 df             	mov    %rbx,%rdi
    87bb:	e8 70 e2 ff ff       	call   6a30 <fwp_rc_share>
    87c0:	48 89 df             	mov    %rbx,%rdi
    87c3:	e8 48 fb ff ff       	call   8310 <f37>
    87c8:	48 89 c3             	mov    %rax,%rbx
    87cb:	48 89 c7             	mov    %rax,%rdi
    87ce:	e8 5d e2 ff ff       	call   6a30 <fwp_rc_share>
    87d3:	48 89 d8             	mov    %rbx,%rax
    87d6:	5b                   	pop    %rbx
    87d7:	c3                   	ret
    87d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    87df:	00 

00000000000087e0 <fwp_write>:
    87e0:	41 57                	push   %r15
    87e2:	41 56                	push   %r14
    87e4:	41 55                	push   %r13
    87e6:	41 54                	push   %r12
    87e8:	55                   	push   %rbp
    87e9:	53                   	push   %rbx
    87ea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    87f1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    87f8:	00 00 
    87fa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8801:	00 
    8802:	49 89 d4             	mov    %rdx,%r12
    8805:	8b 12                	mov    (%rdx),%edx
    8807:	83 fa 19             	cmp    $0x19,%edx
    880a:	77 6a                	ja     8876 <fwp_write+0x96>
    880c:	48 89 f5             	mov    %rsi,%rbp
    880f:	89 d0                	mov    %edx,%eax
    8811:	89 ce                	mov    %ecx,%esi
    8813:	48 89 fb             	mov    %rdi,%rbx
    8816:	48 8d 0d b3 44 00 00 	lea    0x44b3(%rip),%rcx        # ccd0 <_IO_stdin_used+0xcd0>
    881d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8821:	48 01 c8             	add    %rcx,%rax
    8824:	3e ff e0             	notrack jmp *%rax
    8827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    882e:	00 00 
    8830:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8834:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8838:	48 89 ca             	mov    %rcx,%rdx
    883b:	48 85 c9             	test   %rcx,%rcx
    883e:	0f 88 9c 0c 00 00    	js     94e0 <fwp_write+0xd00>
    8844:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    884b:	00 
    884c:	48 89 c6             	mov    %rax,%rsi
    884f:	4c 89 e7             	mov    %r12,%rdi
    8852:	e8 e9 b1 ff ff       	call   3a40 <fwp_fmt_u128>
    8857:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    885e:	00 00 
    8860:	4c 89 e7             	mov    %r12,%rdi
    8863:	e8 d8 ab ff ff       	call   3440 <strlen@plt>
    8868:	4c 89 e6             	mov    %r12,%rsi
    886b:	48 89 df             	mov    %rbx,%rdi
    886e:	48 89 c2             	mov    %rax,%rdx
    8871:	e8 7a b8 ff ff       	call   40f0 <buf_put>
    8876:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    887d:	00 
    887e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8885:	00 00 
    8887:	0f 85 28 04 00 00    	jne    8cb5 <fwp_write+0x4d5>
    888d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8894:	5b                   	pop    %rbx
    8895:	5d                   	pop    %rbp
    8896:	41 5c                	pop    %r12
    8898:	41 5d                	pop    %r13
    889a:	41 5e                	pop    %r14
    889c:	41 5f                	pop    %r15
    889e:	c3                   	ret
    889f:	90                   	nop
    88a0:	49 89 e9             	mov    %rbp,%r9
    88a3:	4c 8d 05 6b 39 00 00 	lea    0x396b(%rip),%r8        # c215 <_IO_stdin_used+0x215>
    88aa:	b9 00 02 00 00       	mov    $0x200,%ecx
    88af:	ba 02 00 00 00       	mov    $0x2,%edx
    88b4:	be 00 02 00 00       	mov    $0x200,%esi
    88b9:	31 c0                	xor    %eax,%eax
    88bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    88c2:	00 
    88c3:	e8 d8 aa ff ff       	call   33a0 <__snprintf_chk@plt>
    88c8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    88cf:	00 
    88d0:	e8 6b ab ff ff       	call   3440 <strlen@plt>
    88d5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    88dc:	00 
    88dd:	48 89 df             	mov    %rbx,%rdi
    88e0:	48 89 c2             	mov    %rax,%rdx
    88e3:	e8 08 b8 ff ff       	call   40f0 <buf_put>
    88e8:	eb 8c                	jmp    8876 <fwp_write+0x96>
    88ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    88f0:	49 89 e9             	mov    %rbp,%r9
    88f3:	4c 8d 05 16 39 00 00 	lea    0x3916(%rip),%r8        # c210 <_IO_stdin_used+0x210>
    88fa:	eb ae                	jmp    88aa <fwp_write+0xca>
    88fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8900:	83 fa 13             	cmp    $0x13,%edx
    8903:	48 8d 05 fc 38 00 00 	lea    0x38fc(%rip),%rax        # c206 <_IO_stdin_used+0x206>
    890a:	48 8d 35 fa 38 00 00 	lea    0x38fa(%rip),%rsi        # c20b <_IO_stdin_used+0x20b>
    8911:	ba 04 00 00 00       	mov    $0x4,%edx
    8916:	48 0f 44 f0          	cmove  %rax,%rsi
    891a:	45 31 ed             	xor    %r13d,%r13d
    891d:	e8 ce b7 ff ff       	call   40f0 <buf_put>
    8922:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8927:	0f 84 a3 08 00 00    	je     91d0 <fwp_write+0x9f0>
    892d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8932:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8937:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    893c:	48 89 df             	mov    %rbx,%rdi
    893f:	49 0f 44 c5          	cmove  %r13,%rax
    8943:	31 c9                	xor    %ecx,%ecx
    8945:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    894a:	e8 91 fe ff ff       	call   87e0 <fwp_write>
    894f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8954:	0f 84 6e 09 00 00    	je     92c8 <fwp_write+0xae8>
    895a:	49 83 c5 01          	add    $0x1,%r13
    895e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8962:	0f 83 68 08 00 00    	jae    91d0 <fwp_write+0x9f0>
    8968:	ba 02 00 00 00       	mov    $0x2,%edx
    896d:	48 8d 35 e1 38 00 00 	lea    0x38e1(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8974:	48 89 df             	mov    %rbx,%rdi
    8977:	e8 74 b7 ff ff       	call   40f0 <buf_put>
    897c:	eb af                	jmp    892d <fwp_write+0x14d>
    897e:	66 90                	xchg   %ax,%ax
    8980:	ba 06 00 00 00       	mov    $0x6,%edx
    8985:	48 8d 35 a2 38 00 00 	lea    0x38a2(%rip),%rsi        # c22e <_IO_stdin_used+0x22e>
    898c:	48 83 c5 10          	add    $0x10,%rbp
    8990:	e8 5b b7 ff ff       	call   40f0 <buf_put>
    8995:	48 89 ef             	mov    %rbp,%rdi
    8998:	e8 a3 aa ff ff       	call   3440 <strlen@plt>
    899d:	48 89 ee             	mov    %rbp,%rsi
    89a0:	48 89 df             	mov    %rbx,%rdi
    89a3:	48 89 c2             	mov    %rax,%rdx
    89a6:	e8 45 b7 ff ff       	call   40f0 <buf_put>
    89ab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89b0:	ba 01 00 00 00       	mov    $0x1,%edx
    89b5:	48 89 df             	mov    %rbx,%rdi
    89b8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    89bd:	e8 2e b7 ff ff       	call   40f0 <buf_put>
    89c2:	e9 af fe ff ff       	jmp    8876 <fwp_write+0x96>
    89c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    89ce:	00 00 
    89d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    89d7:	00 
    89d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89df:	00 00 
    89e1:	0f 85 ce 02 00 00    	jne    8cb5 <fwp_write+0x4d5>
    89e7:	ba 0a 00 00 00       	mov    $0xa,%edx
    89ec:	48 8d 35 27 38 00 00 	lea    0x3827(%rip),%rsi        # c21a <_IO_stdin_used+0x21a>
    89f3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    89fa:	48 89 df             	mov    %rbx,%rdi
    89fd:	5b                   	pop    %rbx
    89fe:	5d                   	pop    %rbp
    89ff:	41 5c                	pop    %r12
    8a01:	41 5d                	pop    %r13
    8a03:	41 5e                	pop    %r14
    8a05:	41 5f                	pop    %r15
    8a07:	e9 e4 b6 ff ff       	jmp    40f0 <buf_put>
    8a0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a10:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8a15:	4d 85 ed             	test   %r13,%r13
    8a18:	0f 84 02 0c 00 00    	je     9620 <fwp_write+0xe40>
    8a1e:	48 8d 35 3d 38 00 00 	lea    0x383d(%rip),%rsi        # c262 <_IO_stdin_used+0x262>
    8a25:	4c 89 ef             	mov    %r13,%rdi
    8a28:	e8 f3 aa ff ff       	call   3520 <strcmp@plt>
    8a2d:	41 89 c1             	mov    %eax,%r9d
    8a30:	85 c0                	test   %eax,%eax
    8a32:	0f 84 6c 0c 00 00    	je     96a4 <fwp_write+0xec4>
    8a38:	4c 89 ef             	mov    %r13,%rdi
    8a3b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8a40:	e8 fb a9 ff ff       	call   3440 <strlen@plt>
    8a45:	4c 89 ee             	mov    %r13,%rsi
    8a48:	48 89 df             	mov    %rbx,%rdi
    8a4b:	48 89 c2             	mov    %rax,%rdx
    8a4e:	e8 9d b6 ff ff       	call   40f0 <buf_put>
    8a53:	ba 01 00 00 00       	mov    $0x1,%edx
    8a58:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a5d:	48 89 df             	mov    %rbx,%rdi
    8a60:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8a65:	e8 86 b6 ff ff       	call   40f0 <buf_put>
    8a6a:	ba 01 00 00 00       	mov    $0x1,%edx
    8a6f:	4c 89 fe             	mov    %r15,%rsi
    8a72:	48 89 df             	mov    %rbx,%rdi
    8a75:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8a7a:	e8 71 b6 ff ff       	call   40f0 <buf_put>
    8a7f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8a84:	45 31 f6             	xor    %r14d,%r14d
    8a87:	85 d2                	test   %edx,%edx
    8a89:	0f 8e 81 0a 00 00    	jle    9510 <fwp_write+0xd30>
    8a8f:	45 31 ed             	xor    %r13d,%r13d
    8a92:	4d 85 ed             	test   %r13,%r13
    8a95:	0f 85 75 07 00 00    	jne    9210 <fwp_write+0xa30>
    8a9b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8aa2:	00 
    8aa3:	45 85 f6             	test   %r14d,%r14d
    8aa6:	0f 84 84 07 00 00    	je     9230 <fwp_write+0xa50>
    8aac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8ab1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8ab6:	48 89 df             	mov    %rbx,%rdi
    8ab9:	49 83 c5 01          	add    $0x1,%r13
    8abd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8ac1:	31 c9                	xor    %ecx,%ecx
    8ac3:	e8 18 fd ff ff       	call   87e0 <fwp_write>
    8ac8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8acd:	7f c3                	jg     8a92 <fwp_write+0x2b2>
    8acf:	45 85 f6             	test   %r14d,%r14d
    8ad2:	0f 84 38 0a 00 00    	je     9510 <fwp_write+0xd30>
    8ad8:	b8 29 00 00 00       	mov    $0x29,%eax
    8add:	ba 01 00 00 00       	mov    $0x1,%edx
    8ae2:	4c 89 fe             	mov    %r15,%rsi
    8ae5:	48 89 df             	mov    %rbx,%rdi
    8ae8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8aec:	e8 ff b5 ff ff       	call   40f0 <buf_put>
    8af1:	e9 80 fd ff ff       	jmp    8876 <fwp_write+0x96>
    8af6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8afd:	00 00 00 
    8b00:	ba 01 00 00 00       	mov    $0x1,%edx
    8b05:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b0a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8b0f:	e8 dc b5 ff ff       	call   40f0 <buf_put>
    8b14:	48 85 ed             	test   %rbp,%rbp
    8b17:	0f 84 93 06 00 00    	je     91b0 <fwp_write+0x9d0>
    8b1d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8b21:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8b26:	31 c9                	xor    %ecx,%ecx
    8b28:	48 89 df             	mov    %rbx,%rdi
    8b2b:	e8 b0 fc ff ff       	call   87e0 <fwp_write>
    8b30:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8b34:	48 85 ed             	test   %rbp,%rbp
    8b37:	0f 84 73 06 00 00    	je     91b0 <fwp_write+0x9d0>
    8b3d:	ba 02 00 00 00       	mov    $0x2,%edx
    8b42:	48 8d 35 0c 37 00 00 	lea    0x370c(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8b49:	48 89 df             	mov    %rbx,%rdi
    8b4c:	e8 9f b5 ff ff       	call   40f0 <buf_put>
    8b51:	eb ca                	jmp    8b1d <fwp_write+0x33d>
    8b53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b58:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8b5c:	85 f6                	test   %esi,%esi
    8b5e:	0f 84 fc 07 00 00    	je     9360 <fwp_write+0xb80>
    8b64:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b6b:	00 
    8b6c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b73:	00 00 
    8b75:	0f 85 3a 01 00 00    	jne    8cb5 <fwp_write+0x4d5>
    8b7b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8b7f:	4c 89 ea             	mov    %r13,%rdx
    8b82:	e9 6c fe ff ff       	jmp    89f3 <fwp_write+0x213>
    8b87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b8e:	00 00 
    8b90:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8b95:	ba 01 00 00 00       	mov    $0x1,%edx
    8b9a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8b9f:	48 89 ee             	mov    %rbp,%rsi
    8ba2:	e8 49 b5 ff ff       	call   40f0 <buf_put>
    8ba7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8bac:	4c 89 e7             	mov    %r12,%rdi
    8baf:	e8 8c a8 ff ff       	call   3440 <strlen@plt>
    8bb4:	4c 89 e6             	mov    %r12,%rsi
    8bb7:	48 89 df             	mov    %rbx,%rdi
    8bba:	48 89 c2             	mov    %rax,%rdx
    8bbd:	e8 2e b5 ff ff       	call   40f0 <buf_put>
    8bc2:	ba 01 00 00 00       	mov    $0x1,%edx
    8bc7:	48 89 ee             	mov    %rbp,%rsi
    8bca:	48 89 df             	mov    %rbx,%rdi
    8bcd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8bd2:	e8 19 b5 ff ff       	call   40f0 <buf_put>
    8bd7:	e9 9a fc ff ff       	jmp    8876 <fwp_write+0x96>
    8bdc:	0f 1f 40 00          	nopl   0x0(%rax)
    8be0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8be5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8be9:	0f 8a 8e 0b 00 00    	jp     977d <fwp_write+0xf9d>
    8bef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8bf3:	66 0f 54 05 05 42 00 	andpd  0x4205(%rip),%xmm0        # ce00 <msg.4+0xc0>
    8bfa:	00 
    8bfb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8c00:	66 0f 2e 05 70 41 00 	ucomisd 0x4170(%rip),%xmm0        # cd78 <msg.4+0x38>
    8c07:	00 
    8c08:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c0f:	00 
    8c10:	0f 87 b2 09 00 00    	ja     95c8 <fwp_write+0xde8>
    8c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c1d:	00 00 00 
    8c20:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8c24:	89 ee                	mov    %ebp,%esi
    8c26:	4c 89 e7             	mov    %r12,%rdi
    8c29:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8c2e:	e8 3d bb ff ff       	call   4770 <fwp_format_g.constprop.0>
    8c33:	31 f6                	xor    %esi,%esi
    8c35:	4c 89 e7             	mov    %r12,%rdi
    8c38:	e8 c3 a7 ff ff       	call   3400 <strtod@plt>
    8c3d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8c42:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8c46:	7a 06                	jp     8c4e <fwp_write+0x46e>
    8c48:	0f 84 e9 01 00 00    	je     8e37 <fwp_write+0x657>
    8c4e:	83 c5 01             	add    $0x1,%ebp
    8c51:	83 fd 12             	cmp    $0x12,%ebp
    8c54:	75 ca                	jne    8c20 <fwp_write+0x440>
    8c56:	be 11 00 00 00       	mov    $0x11,%esi
    8c5b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8c5f:	4c 89 e7             	mov    %r12,%rdi
    8c62:	e8 09 bb ff ff       	call   4770 <fwp_format_g.constprop.0>
    8c67:	e9 cb 01 00 00       	jmp    8e37 <fwp_write+0x657>
    8c6c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c70:	48 83 fd 01          	cmp    $0x1,%rbp
    8c74:	0f 84 e6 08 00 00    	je     9560 <fwp_write+0xd80>
    8c7a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8c7e:	b8 02 00 00 00       	mov    $0x2,%eax
    8c83:	ba 01 00 00 00       	mov    $0x1,%edx
    8c88:	48 0f 44 d0          	cmove  %rax,%rdx
    8c8c:	48 8d 35 6b 35 00 00 	lea    0x356b(%rip),%rsi        # c1fe <_IO_stdin_used+0x1fe>
    8c93:	48 8d 05 69 35 00 00 	lea    0x3569(%rip),%rax        # c203 <_IO_stdin_used+0x203>
    8c9a:	48 0f 44 f0          	cmove  %rax,%rsi
    8c9e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8ca5:	00 
    8ca6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8cad:	00 00 
    8caf:	0f 84 3e fd ff ff    	je     89f3 <fwp_write+0x213>
    8cb5:	e8 96 a7 ff ff       	call   3450 <__stack_chk_fail@plt>
    8cba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8cc0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8cc5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8cca:	e8 61 b3 ff ff       	call   4030 <buf_grow>
    8ccf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8cd3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8cd9:	4c 03 0b             	add    (%rbx),%r9
    8cdc:	66 45 89 11          	mov    %r10w,(%r9)
    8ce0:	45 85 e4             	test   %r12d,%r12d
    8ce3:	0f 8e 07 05 00 00    	jle    91f0 <fwp_write+0xa10>
    8ce9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8cf0:	55 55 55 
    8cf3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8cf8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8cff:	aa aa aa 
    8d02:	49 83 c1 01          	add    $0x1,%r9
    8d06:	eb 45                	jmp    8d4d <fwp_write+0x56d>
    8d08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d0f:	00 
    8d10:	be 01 00 00 00       	mov    $0x1,%esi
    8d15:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8d1a:	88 07                	mov    %al,(%rdi)
    8d1c:	48 89 e8             	mov    %rbp,%rax
    8d1f:	49 f7 e8             	imul   %r8
    8d22:	48 89 e8             	mov    %rbp,%rax
    8d25:	48 c1 f8 3f          	sar    $0x3f,%rax
    8d29:	48 29 c2             	sub    %rax,%rdx
    8d2c:	48 85 c9             	test   %rcx,%rcx
    8d2f:	0f 95 c0             	setne  %al
    8d32:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8d36:	48 83 ef 01          	sub    $0x1,%rdi
    8d3a:	48 21 c5             	and    %rax,%rbp
    8d3d:	48 29 ea             	sub    %rbp,%rdx
    8d40:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8d44:	49 39 f9             	cmp    %rdi,%r9
    8d47:	0f 84 a3 04 00 00    	je     91f0 <fwp_write+0xa10>
    8d4d:	48 89 e8             	mov    %rbp,%rax
    8d50:	49 f7 e8             	imul   %r8
    8d53:	48 89 e8             	mov    %rbp,%rax
    8d56:	48 c1 f8 3f          	sar    $0x3f,%rax
    8d5a:	48 89 d1             	mov    %rdx,%rcx
    8d5d:	48 29 c1             	sub    %rax,%rcx
    8d60:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8d64:	48 89 e9             	mov    %rbp,%rcx
    8d67:	48 29 c1             	sub    %rax,%rcx
    8d6a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8d6e:	49 f7 e2             	mul    %r10
    8d71:	b8 30 00 00 00       	mov    $0x30,%eax
    8d76:	48 89 d6             	mov    %rdx,%rsi
    8d79:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8d7d:	48 d1 ee             	shr    $1,%rsi
    8d80:	48 01 f2             	add    %rsi,%rdx
    8d83:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8d87:	48 29 d6             	sub    %rdx,%rsi
    8d8a:	74 8e                	je     8d1a <fwp_write+0x53a>
    8d8c:	48 83 fe 01          	cmp    $0x1,%rsi
    8d90:	0f 85 7a ff ff ff    	jne    8d10 <fwp_write+0x530>
    8d96:	31 f6                	xor    %esi,%esi
    8d98:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8d9d:	e9 78 ff ff ff       	jmp    8d1a <fwp_write+0x53a>
    8da2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8da8:	66 0f 6e cd          	movd   %ebp,%xmm1
    8dac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8daf:	0f 8a c8 09 00 00    	jp     977d <fwp_write+0xf9d>
    8db5:	0f 28 c1             	movaps %xmm1,%xmm0
    8db8:	0f 54 05 31 40 00 00 	andps  0x4031(%rip),%xmm0        # cdf0 <msg.4+0xb0>
    8dbf:	0f 2e 05 3e 32 00 00 	ucomiss 0x323e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8dc6:	0f 87 24 08 00 00    	ja     95f0 <fwp_write+0xe10>
    8dcc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8dd0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8dd6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8ddd:	00 
    8dde:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8de2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8de7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8dee:	00 00 
    8df0:	44 89 ee             	mov    %r13d,%esi
    8df3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8df8:	4c 89 e7             	mov    %r12,%rdi
    8dfb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8e00:	e8 6b b9 ff ff       	call   4770 <fwp_format_g.constprop.0>
    8e05:	31 f6                	xor    %esi,%esi
    8e07:	4c 89 e7             	mov    %r12,%rdi
    8e0a:	e8 91 a6 ff ff       	call   34a0 <strtof@plt>
    8e0f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8e14:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8e17:	7a 02                	jp     8e1b <fwp_write+0x63b>
    8e19:	74 1c                	je     8e37 <fwp_write+0x657>
    8e1b:	41 83 c5 01          	add    $0x1,%r13d
    8e1f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8e23:	75 cb                	jne    8df0 <fwp_write+0x610>
    8e25:	be 09 00 00 00       	mov    $0x9,%esi
    8e2a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8e2f:	4c 89 e7             	mov    %r12,%rdi
    8e32:	e8 39 b9 ff ff       	call   4770 <fwp_format_g.constprop.0>
    8e37:	4c 89 e7             	mov    %r12,%rdi
    8e3a:	e8 71 b3 ff ff       	call   41b0 <fwp_finish_float>
    8e3f:	e9 1c fa ff ff       	jmp    8860 <fwp_write+0x80>
    8e44:	0f 1f 40 00          	nopl   0x0(%rax)
    8e48:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8e4c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8e50:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8e57:	00 
    8e58:	48 89 ef             	mov    %rbp,%rdi
    8e5b:	e8 e0 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8e60:	48 89 ef             	mov    %rbp,%rdi
    8e63:	e8 d8 a5 ff ff       	call   3440 <strlen@plt>
    8e68:	48 89 ee             	mov    %rbp,%rsi
    8e6b:	48 89 df             	mov    %rbx,%rdi
    8e6e:	48 89 c2             	mov    %rax,%rdx
    8e71:	e8 7a b2 ff ff       	call   40f0 <buf_put>
    8e76:	e9 fb f9 ff ff       	jmp    8876 <fwp_write+0x96>
    8e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8e80:	ba 06 00 00 00       	mov    $0x6,%edx
    8e85:	48 8d 35 cc 33 00 00 	lea    0x33cc(%rip),%rsi        # c258 <_IO_stdin_used+0x258>
    8e8c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8e92:	e8 59 b2 ff ff       	call   40f0 <buf_put>
    8e97:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8e9e:	ff ff 7f 
    8ea1:	48 23 55 00          	and    0x0(%rbp),%rdx
    8ea5:	0f 84 86 02 00 00    	je     9131 <fwp_write+0x951>
    8eab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8eb0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8eb4:	48 85 d2             	test   %rdx,%rdx
    8eb7:	0f 84 ae 00 00 00    	je     8f6b <fwp_write+0x78b>
    8ebd:	8b 0a                	mov    (%rdx),%ecx
    8ebf:	83 f9 1c             	cmp    $0x1c,%ecx
    8ec2:	0f 84 58 06 00 00    	je     9520 <fwp_write+0xd40>
    8ec8:	83 f9 1b             	cmp    $0x1b,%ecx
    8ecb:	0f 87 9a 00 00 00    	ja     8f6b <fwp_write+0x78b>
    8ed1:	be 01 00 00 00       	mov    $0x1,%esi
    8ed6:	48 d3 e6             	shl    %cl,%rsi
    8ed9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8edf:	0f 85 4b 04 00 00    	jne    9330 <fwp_write+0xb50>
    8ee5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8eeb:	0f 85 0f 04 00 00    	jne    9300 <fwp_write+0xb20>
    8ef1:	83 e6 21             	and    $0x21,%esi
    8ef4:	74 75                	je     8f6b <fwp_write+0x78b>
    8ef6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8efb:	48 85 ff             	test   %rdi,%rdi
    8efe:	79 07                	jns    8f07 <fwp_write+0x727>
    8f00:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8f04:	4c 01 ee             	add    %r13,%rsi
    8f07:	48 0f be 3e          	movsbq (%rsi),%rdi
    8f0b:	85 c9                	test   %ecx,%ecx
    8f0d:	40 0f b6 f7          	movzbl %dil,%esi
    8f11:	48 0f 44 f7          	cmove  %rdi,%rsi
    8f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8f1c:	00 00 00 00 
    8f20:	31 c9                	xor    %ecx,%ecx
    8f22:	48 89 df             	mov    %rbx,%rdi
    8f25:	49 83 c5 01          	add    $0x1,%r13
    8f29:	e8 b2 f8 ff ff       	call   87e0 <fwp_write>
    8f2e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8f35:	ff ff 7f 
    8f38:	48 23 55 00          	and    0x0(%rbp),%rdx
    8f3c:	49 39 d5             	cmp    %rdx,%r13
    8f3f:	0f 83 ec 01 00 00    	jae    9131 <fwp_write+0x951>
    8f45:	ba 02 00 00 00       	mov    $0x2,%edx
    8f4a:	48 89 df             	mov    %rbx,%rdi
    8f4d:	48 8d 35 01 33 00 00 	lea    0x3301(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8f54:	e8 97 b1 ff ff       	call   40f0 <buf_put>
    8f59:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8f5e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8f62:	48 85 d2             	test   %rdx,%rdx
    8f65:	0f 85 52 ff ff ff    	jne    8ebd <fwp_write+0x6dd>
    8f6b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8f70:	48 85 ff             	test   %rdi,%rdi
    8f73:	0f 88 cf 05 00 00    	js     9548 <fwp_write+0xd68>
    8f79:	48 8b 31             	mov    (%rcx),%rsi
    8f7c:	eb a2                	jmp    8f20 <fwp_write+0x740>
    8f7e:	66 90                	xchg   %ax,%ax
    8f80:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8f87:	00 
    8f88:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8f8f:	00 00 
    8f91:	0f 85 1e fd ff ff    	jne    8cb5 <fwp_write+0x4d5>
    8f97:	ba 08 00 00 00       	mov    $0x8,%edx
    8f9c:	48 8d 35 82 32 00 00 	lea    0x3282(%rip),%rsi        # c225 <_IO_stdin_used+0x225>
    8fa3:	e9 4b fa ff ff       	jmp    89f3 <fwp_write+0x213>
    8fa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8faf:	00 
    8fb0:	89 e8                	mov    %ebp,%eax
    8fb2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8fb9:	76 03                	jbe    8fbe <fwp_write+0x7de>
    8fbb:	8b 45 00             	mov    0x0(%rbp),%eax
    8fbe:	41 89 c6             	mov    %eax,%r14d
    8fc1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8fc6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8fcb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8fcf:	4c 89 ef             	mov    %r13,%rdi
    8fd2:	e8 69 a4 ff ff       	call   3440 <strlen@plt>
    8fd7:	4c 89 ee             	mov    %r13,%rsi
    8fda:	48 89 df             	mov    %rbx,%rdi
    8fdd:	48 89 c2             	mov    %rax,%rdx
    8fe0:	e8 0b b1 ff ff       	call   40f0 <buf_put>
    8fe5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8fea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8fee:	85 f6                	test   %esi,%esi
    8ff0:	0f 8e 80 f8 ff ff    	jle    8876 <fwp_write+0x96>
    8ff6:	45 31 ed             	xor    %r13d,%r13d
    8ff9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8ffe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    9003:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9008:	ba 01 00 00 00       	mov    $0x1,%edx
    900d:	4c 89 fe             	mov    %r15,%rsi
    9010:	48 89 04 24          	mov    %rax,(%rsp)
    9014:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    9019:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    901d:	48 89 df             	mov    %rbx,%rdi
    9020:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9024:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9029:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    902e:	e8 bd b0 ff ff       	call   40f0 <buf_put>
    9033:	41 8b 06             	mov    (%r14),%eax
    9036:	83 f8 0e             	cmp    $0xe,%eax
    9039:	0f 84 71 02 00 00    	je     92b0 <fwp_write+0xad0>
    903f:	83 f8 10             	cmp    $0x10,%eax
    9042:	0f 84 38 02 00 00    	je     9280 <fwp_write+0xaa0>
    9048:	83 f8 0a             	cmp    $0xa,%eax
    904b:	0f 84 7f 04 00 00    	je     94d0 <fwp_write+0xcf0>
    9051:	0f 8f f9 00 00 00    	jg     9150 <fwp_write+0x970>
    9057:	83 f8 03             	cmp    $0x3,%eax
    905a:	0f 8f 50 04 00 00    	jg     94b0 <fwp_write+0xcd0>
    9060:	85 c0                	test   %eax,%eax
    9062:	78 10                	js     9074 <fwp_write+0x894>
    9064:	48 8b 04 24          	mov    (%rsp),%rax
    9068:	48 c1 e8 3f          	shr    $0x3f,%rax
    906c:	85 c0                	test   %eax,%eax
    906e:	0f 85 f9 00 00 00    	jne    916d <fwp_write+0x98d>
    9074:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9079:	48 8b 34 24          	mov    (%rsp),%rsi
    907d:	31 c9                	xor    %ecx,%ecx
    907f:	48 89 df             	mov    %rbx,%rdi
    9082:	e8 59 f7 ff ff       	call   87e0 <fwp_write>
    9087:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    908c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9091:	49 83 c5 01          	add    $0x1,%r13
    9095:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9099:	0f 8f 5f ff ff ff    	jg     8ffe <fwp_write+0x81e>
    909f:	e9 d2 f7 ff ff       	jmp    8876 <fwp_write+0x96>
    90a4:	0f 1f 40 00          	nopl   0x0(%rax)
    90a8:	ba 06 00 00 00       	mov    $0x6,%edx
    90ad:	48 8d 35 97 31 00 00 	lea    0x3197(%rip),%rsi        # c24b <_IO_stdin_used+0x24b>
    90b4:	45 31 ed             	xor    %r13d,%r13d
    90b7:	e8 34 b0 ff ff       	call   40f0 <buf_put>
    90bc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    90c1:	75 19                	jne    90dc <fwp_write+0x8fc>
    90c3:	eb 6c                	jmp    9131 <fwp_write+0x951>
    90c5:	0f 1f 00             	nopl   (%rax)
    90c8:	ba 02 00 00 00       	mov    $0x2,%edx
    90cd:	48 8d 35 81 31 00 00 	lea    0x3181(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    90d4:	48 89 df             	mov    %rbx,%rdi
    90d7:	e8 14 b0 ff ff       	call   40f0 <buf_put>
    90dc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    90e2:	b9 00 02 00 00       	mov    $0x200,%ecx
    90e7:	31 c0                	xor    %eax,%eax
    90e9:	49 83 c5 01          	add    $0x1,%r13
    90ed:	4c 8d 05 5e 31 00 00 	lea    0x315e(%rip),%r8        # c252 <_IO_stdin_used+0x252>
    90f4:	ba 02 00 00 00       	mov    $0x2,%edx
    90f9:	be 00 02 00 00       	mov    $0x200,%esi
    90fe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9105:	00 
    9106:	e8 95 a2 ff ff       	call   33a0 <__snprintf_chk@plt>
    910b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9112:	00 
    9113:	e8 28 a3 ff ff       	call   3440 <strlen@plt>
    9118:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    911f:	00 
    9120:	48 89 df             	mov    %rbx,%rdi
    9123:	48 89 c2             	mov    %rax,%rdx
    9126:	e8 c5 af ff ff       	call   40f0 <buf_put>
    912b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    912f:	72 97                	jb     90c8 <fwp_write+0x8e8>
    9131:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9136:	ba 01 00 00 00       	mov    $0x1,%edx
    913b:	48 89 df             	mov    %rbx,%rdi
    913e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9143:	e8 a8 af ff ff       	call   40f0 <buf_put>
    9148:	e9 29 f7 ff ff       	jmp    8876 <fwp_write+0x96>
    914d:	0f 1f 00             	nopl   (%rax)
    9150:	83 f8 0b             	cmp    $0xb,%eax
    9153:	0f 85 1b ff ff ff    	jne    9074 <fwp_write+0x894>
    9159:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    915e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9162:	83 e0 01             	and    $0x1,%eax
    9165:	85 c0                	test   %eax,%eax
    9167:	0f 84 07 ff ff ff    	je     9074 <fwp_write+0x894>
    916d:	4c 89 fe             	mov    %r15,%rsi
    9170:	48 89 df             	mov    %rbx,%rdi
    9173:	ba 01 00 00 00       	mov    $0x1,%edx
    9178:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    917d:	e8 6e af ff ff       	call   40f0 <buf_put>
    9182:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9187:	48 8b 34 24          	mov    (%rsp),%rsi
    918b:	31 c9                	xor    %ecx,%ecx
    918d:	48 89 df             	mov    %rbx,%rdi
    9190:	e8 4b f6 ff ff       	call   87e0 <fwp_write>
    9195:	ba 01 00 00 00       	mov    $0x1,%edx
    919a:	4c 89 fe             	mov    %r15,%rsi
    919d:	48 89 df             	mov    %rbx,%rdi
    91a0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    91a5:	e8 46 af ff ff       	call   40f0 <buf_put>
    91aa:	e9 d8 fe ff ff       	jmp    9087 <fwp_write+0x8a7>
    91af:	90                   	nop
    91b0:	ba 01 00 00 00       	mov    $0x1,%edx
    91b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    91ba:	48 89 df             	mov    %rbx,%rdi
    91bd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    91c2:	e8 29 af ff ff       	call   40f0 <buf_put>
    91c7:	e9 aa f6 ff ff       	jmp    8876 <fwp_write+0x96>
    91cc:	0f 1f 40 00          	nopl   0x0(%rax)
    91d0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    91d5:	ba 01 00 00 00       	mov    $0x1,%edx
    91da:	48 89 df             	mov    %rbx,%rdi
    91dd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    91e2:	e8 09 af ff ff       	call   40f0 <buf_put>
    91e7:	e9 8a f6 ff ff       	jmp    8876 <fwp_write+0x96>
    91ec:	0f 1f 40 00          	nopl   0x0(%rax)
    91f0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    91f4:	48 8b 13             	mov    (%rbx),%rdx
    91f7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    91fc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9200:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9204:	e9 6d f6 ff ff       	jmp    8876 <fwp_write+0x96>
    9209:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9210:	ba 02 00 00 00       	mov    $0x2,%edx
    9215:	48 8d 35 39 30 00 00 	lea    0x3039(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    921c:	48 89 df             	mov    %rbx,%rdi
    921f:	e8 cc ae ff ff       	call   40f0 <buf_put>
    9224:	e9 72 f8 ff ff       	jmp    8a9b <fwp_write+0x2bb>
    9229:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9230:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9235:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    923a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    923e:	48 89 f7             	mov    %rsi,%rdi
    9241:	48 89 34 24          	mov    %rsi,(%rsp)
    9245:	e8 f6 a1 ff ff       	call   3440 <strlen@plt>
    924a:	48 8b 34 24          	mov    (%rsp),%rsi
    924e:	48 89 df             	mov    %rbx,%rdi
    9251:	48 89 c2             	mov    %rax,%rdx
    9254:	e8 97 ae ff ff       	call   40f0 <buf_put>
    9259:	ba 03 00 00 00       	mov    $0x3,%edx
    925e:	48 8d 35 13 30 00 00 	lea    0x3013(%rip),%rsi        # c278 <_IO_stdin_used+0x278>
    9265:	48 89 df             	mov    %rbx,%rdi
    9268:	e8 83 ae ff ff       	call   40f0 <buf_put>
    926d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9272:	e9 35 f8 ff ff       	jmp    8aac <fwp_write+0x2cc>
    9277:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    927e:	00 00 
    9280:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9285:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9289:	48 85 ff             	test   %rdi,%rdi
    928c:	0f 84 e2 fd ff ff    	je     9074 <fwp_write+0x894>
    9292:	48 8d 35 c9 2f 00 00 	lea    0x2fc9(%rip),%rsi        # c262 <_IO_stdin_used+0x262>
    9299:	e8 82 a2 ff ff       	call   3520 <strcmp@plt>
    929e:	85 c0                	test   %eax,%eax
    92a0:	0f 95 c0             	setne  %al
    92a3:	0f b6 c0             	movzbl %al,%eax
    92a6:	e9 c1 fd ff ff       	jmp    906c <fwp_write+0x88c>
    92ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    92b0:	31 c0                	xor    %eax,%eax
    92b2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    92b9:	00 
    92ba:	0f 97 c0             	seta   %al
    92bd:	e9 aa fd ff ff       	jmp    906c <fwp_write+0x88c>
    92c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92c8:	48 89 df             	mov    %rbx,%rdi
    92cb:	ba 02 00 00 00       	mov    $0x2,%edx
    92d0:	48 8d 35 88 2f 00 00 	lea    0x2f88(%rip),%rsi        # c25f <_IO_stdin_used+0x25f>
    92d7:	e8 14 ae ff ff       	call   40f0 <buf_put>
    92dc:	4c 89 e8             	mov    %r13,%rax
    92df:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    92e4:	31 c9                	xor    %ecx,%ecx
    92e6:	48 c1 e0 04          	shl    $0x4,%rax
    92ea:	48 89 df             	mov    %rbx,%rdi
    92ed:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    92f2:	e8 e9 f4 ff ff       	call   87e0 <fwp_write>
    92f7:	e9 5e f6 ff ff       	jmp    895a <fwp_write+0x17a>
    92fc:	0f 1f 40 00          	nopl   0x0(%rax)
    9300:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9305:	48 85 ff             	test   %rdi,%rdi
    9308:	79 0c                	jns    9316 <fwp_write+0xb36>
    930a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9311:	00 
    9312:	48 03 75 10          	add    0x10(%rbp),%rsi
    9316:	48 63 3e             	movslq (%rsi),%rdi
    9319:	83 f9 02             	cmp    $0x2,%ecx
    931c:	89 fe                	mov    %edi,%esi
    931e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9322:	e9 f9 fb ff ff       	jmp    8f20 <fwp_write+0x740>
    9327:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    932e:	00 00 
    9330:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9335:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    933a:	48 85 ff             	test   %rdi,%rdi
    933d:	0f 88 0f 03 00 00    	js     9652 <fwp_write+0xe72>
    9343:	49 0f bf 38          	movswq (%r8),%rdi
    9347:	83 f9 01             	cmp    $0x1,%ecx
    934a:	0f b7 f7             	movzwl %di,%esi
    934d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9351:	e9 ca fb ff ff       	jmp    8f20 <fwp_write+0x740>
    9356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    935d:	00 00 00 
    9360:	ba 01 00 00 00       	mov    $0x1,%edx
    9365:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    936a:	48 83 c5 08          	add    $0x8,%rbp
    936e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9373:	e8 78 ad ff ff       	call   40f0 <buf_put>
    9378:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    937d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9382:	4d 85 ed             	test   %r13,%r13
    9385:	75 46                	jne    93cd <fwp_write+0xbed>
    9387:	e9 04 01 00 00       	jmp    9490 <fwp_write+0xcb0>
    938c:	0f 1f 40 00          	nopl   0x0(%rax)
    9390:	41 80 f9 09          	cmp    $0x9,%r9b
    9394:	0f 84 d6 00 00 00    	je     9470 <fwp_write+0xc90>
    939a:	41 80 f9 0a          	cmp    $0xa,%r9b
    939e:	0f 85 9c 00 00 00    	jne    9440 <fwp_write+0xc60>
    93a4:	ba 02 00 00 00       	mov    $0x2,%edx
    93a9:	48 8d 35 8b 2e 00 00 	lea    0x2e8b(%rip),%rsi        # c23b <_IO_stdin_used+0x23b>
    93b0:	48 89 df             	mov    %rbx,%rdi
    93b3:	e8 38 ad ff ff       	call   40f0 <buf_put>
    93b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93bf:	00 
    93c0:	48 83 c5 01          	add    $0x1,%rbp
    93c4:	49 39 ec             	cmp    %rbp,%r12
    93c7:	0f 84 c3 00 00 00    	je     9490 <fwp_write+0xcb0>
    93cd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    93d2:	41 80 f9 0d          	cmp    $0xd,%r9b
    93d6:	74 28                	je     9400 <fwp_write+0xc20>
    93d8:	7e b6                	jle    9390 <fwp_write+0xbb0>
    93da:	41 80 f9 22          	cmp    $0x22,%r9b
    93de:	74 40                	je     9420 <fwp_write+0xc40>
    93e0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    93e4:	75 5a                	jne    9440 <fwp_write+0xc60>
    93e6:	ba 02 00 00 00       	mov    $0x2,%edx
    93eb:	48 8d 35 46 2e 00 00 	lea    0x2e46(%rip),%rsi        # c238 <_IO_stdin_used+0x238>
    93f2:	48 89 df             	mov    %rbx,%rdi
    93f5:	e8 f6 ac ff ff       	call   40f0 <buf_put>
    93fa:	eb c4                	jmp    93c0 <fwp_write+0xbe0>
    93fc:	0f 1f 40 00          	nopl   0x0(%rax)
    9400:	ba 02 00 00 00       	mov    $0x2,%edx
    9405:	48 8d 35 35 2e 00 00 	lea    0x2e35(%rip),%rsi        # c241 <_IO_stdin_used+0x241>
    940c:	48 89 df             	mov    %rbx,%rdi
    940f:	e8 dc ac ff ff       	call   40f0 <buf_put>
    9414:	eb aa                	jmp    93c0 <fwp_write+0xbe0>
    9416:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    941d:	00 00 00 
    9420:	ba 02 00 00 00       	mov    $0x2,%edx
    9425:	48 8d 35 09 2e 00 00 	lea    0x2e09(%rip),%rsi        # c235 <_IO_stdin_used+0x235>
    942c:	48 89 df             	mov    %rbx,%rdi
    942f:	e8 bc ac ff ff       	call   40f0 <buf_put>
    9434:	eb 8a                	jmp    93c0 <fwp_write+0xbe0>
    9436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    943d:	00 00 00 
    9440:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9444:	0f 86 2e 01 00 00    	jbe    9578 <fwp_write+0xd98>
    944a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    944e:	0f 84 24 01 00 00    	je     9578 <fwp_write+0xd98>
    9454:	ba 01 00 00 00       	mov    $0x1,%edx
    9459:	4c 89 fe             	mov    %r15,%rsi
    945c:	48 89 df             	mov    %rbx,%rdi
    945f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9464:	e8 87 ac ff ff       	call   40f0 <buf_put>
    9469:	e9 52 ff ff ff       	jmp    93c0 <fwp_write+0xbe0>
    946e:	66 90                	xchg   %ax,%ax
    9470:	ba 02 00 00 00       	mov    $0x2,%edx
    9475:	48 8d 35 c2 2d 00 00 	lea    0x2dc2(%rip),%rsi        # c23e <_IO_stdin_used+0x23e>
    947c:	48 89 df             	mov    %rbx,%rdi
    947f:	e8 6c ac ff ff       	call   40f0 <buf_put>
    9484:	e9 37 ff ff ff       	jmp    93c0 <fwp_write+0xbe0>
    9489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9490:	ba 01 00 00 00       	mov    $0x1,%edx
    9495:	4c 89 fe             	mov    %r15,%rsi
    9498:	48 89 df             	mov    %rbx,%rdi
    949b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    94a0:	e8 4b ac ff ff       	call   40f0 <buf_put>
    94a5:	e9 cc f3 ff ff       	jmp    8876 <fwp_write+0x96>
    94aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    94b0:	83 f8 04             	cmp    $0x4,%eax
    94b3:	0f 85 bb fb ff ff    	jne    9074 <fwp_write+0x894>
    94b9:	48 8b 04 24          	mov    (%rsp),%rax
    94bd:	48 8b 40 08          	mov    0x8(%rax),%rax
    94c1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    94c6:	48 c1 e8 3f          	shr    $0x3f,%rax
    94ca:	e9 96 fc ff ff       	jmp    9165 <fwp_write+0x985>
    94cf:	90                   	nop
    94d0:	8b 0c 24             	mov    (%rsp),%ecx
    94d3:	31 c0                	xor    %eax,%eax
    94d5:	85 c9                	test   %ecx,%ecx
    94d7:	0f 98 c0             	sets   %al
    94da:	e9 86 fc ff ff       	jmp    9165 <fwp_write+0x985>
    94df:	90                   	nop
    94e0:	48 f7 d8             	neg    %rax
    94e3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    94ea:	00 
    94eb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    94f2:	2d 
    94f3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    94fa:	00 
    94fb:	48 83 d2 00          	adc    $0x0,%rdx
    94ff:	48 89 c6             	mov    %rax,%rsi
    9502:	48 f7 da             	neg    %rdx
    9505:	e8 36 a5 ff ff       	call   3a40 <fwp_fmt_u128>
    950a:	e9 51 f3 ff ff       	jmp    8860 <fwp_write+0x80>
    950f:	90                   	nop
    9510:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9515:	e9 c3 f5 ff ff       	jmp    8add <fwp_write+0x2fd>
    951a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9520:	4c 89 e9             	mov    %r13,%rcx
    9523:	48 c1 e1 04          	shl    $0x4,%rcx
    9527:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    952c:	48 85 ff             	test   %rdi,%rdi
    952f:	0f 89 eb f9 ff ff    	jns    8f20 <fwp_write+0x740>
    9535:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9539:	48 89 ce             	mov    %rcx,%rsi
    953c:	e9 df f9 ff ff       	jmp    8f20 <fwp_write+0x740>
    9541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9548:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    954f:	00 
    9550:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9554:	e9 20 fa ff ff       	jmp    8f79 <fwp_write+0x799>
    9559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9560:	ba 02 00 00 00       	mov    $0x2,%edx
    9565:	48 8d 35 94 2c 00 00 	lea    0x2c94(%rip),%rsi        # c200 <_IO_stdin_used+0x200>
    956c:	e9 2d f7 ff ff       	jmp    8c9e <fwp_write+0x4be>
    9571:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9578:	4c 8d 05 c5 2c 00 00 	lea    0x2cc5(%rip),%r8        # c244 <_IO_stdin_used+0x244>
    957f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9584:	31 c0                	xor    %eax,%eax
    9586:	ba 02 00 00 00       	mov    $0x2,%edx
    958b:	be 10 00 00 00       	mov    $0x10,%esi
    9590:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9597:	00 
    9598:	e8 03 9e ff ff       	call   33a0 <__snprintf_chk@plt>
    959d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    95a4:	00 
    95a5:	e8 96 9e ff ff       	call   3440 <strlen@plt>
    95aa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    95b1:	00 
    95b2:	48 89 df             	mov    %rbx,%rdi
    95b5:	48 89 c2             	mov    %rax,%rdx
    95b8:	e8 33 ab ff ff       	call   40f0 <buf_put>
    95bd:	e9 fe fd ff ff       	jmp    93c0 <fwp_write+0xbe0>
    95c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95c8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    95cc:	48 8d 35 27 2c 00 00 	lea    0x2c27(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    95d3:	48 8d 05 1f 2c 00 00 	lea    0x2c1f(%rip),%rax        # c1f9 <_IO_stdin_used+0x1f9>
    95da:	4c 89 e7             	mov    %r12,%rdi
    95dd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    95e1:	48 0f 46 f0          	cmovbe %rax,%rsi
    95e5:	e8 f6 9d ff ff       	call   33e0 <strcpy@plt>
    95ea:	e9 71 f2 ff ff       	jmp    8860 <fwp_write+0x80>
    95ef:	90                   	nop
    95f0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    95f4:	48 8d 35 ff 2b 00 00 	lea    0x2bff(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    95fb:	48 8d 05 f7 2b 00 00 	lea    0x2bf7(%rip),%rax        # c1f9 <_IO_stdin_used+0x1f9>
    9602:	0f 2f c8             	comiss %xmm0,%xmm1
    9605:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    960c:	00 
    960d:	4c 89 e7             	mov    %r12,%rdi
    9610:	48 0f 46 f0          	cmovbe %rax,%rsi
    9614:	e8 c7 9d ff ff       	call   33e0 <strcpy@plt>
    9619:	e9 42 f2 ff ff       	jmp    8860 <fwp_write+0x80>
    961e:	66 90                	xchg   %ax,%ax
    9620:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9625:	45 85 c0             	test   %r8d,%r8d
    9628:	75 34                	jne    965e <fwp_write+0xe7e>
    962a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9631:	00 
    9632:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9639:	00 00 
    963b:	0f 85 74 f6 ff ff    	jne    8cb5 <fwp_write+0x4d5>
    9641:	ba 02 00 00 00       	mov    $0x2,%edx
    9646:	48 8d 35 28 2c 00 00 	lea    0x2c28(%rip),%rsi        # c275 <_IO_stdin_used+0x275>
    964d:	e9 a1 f3 ff ff       	jmp    89f3 <fwp_write+0x213>
    9652:	48 03 75 10          	add    0x10(%rbp),%rsi
    9656:	49 89 f0             	mov    %rsi,%r8
    9659:	e9 e5 fc ff ff       	jmp    9343 <fwp_write+0xb63>
    965e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9663:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9668:	85 ff                	test   %edi,%edi
    966a:	0f 84 fa f3 ff ff    	je     8a6a <fwp_write+0x28a>
    9670:	ba 01 00 00 00       	mov    $0x1,%edx
    9675:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    967a:	48 89 df             	mov    %rbx,%rdi
    967d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9682:	e8 69 aa ff ff       	call   40f0 <buf_put>
    9687:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    968c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9691:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9697:	85 c0                	test   %eax,%eax
    9699:	0f 8f f0 f3 ff ff    	jg     8a8f <fwp_write+0x2af>
    969f:	e9 34 f4 ff ff       	jmp    8ad8 <fwp_write+0x2f8>
    96a4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    96a8:	49 89 c5             	mov    %rax,%r13
    96ab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    96b0:	49 89 c4             	mov    %rax,%r12
    96b3:	49 c1 fd 3f          	sar    $0x3f,%r13
    96b7:	4c 09 e8             	or     %r13,%rax
    96ba:	0f 84 a7 00 00 00    	je     9767 <fwp_write+0xf87>
    96c0:	48 8d 2d f9 4b 00 00 	lea    0x4bf9(%rip),%rbp        # e2c0 <units.0>
    96c7:	4d 89 e7             	mov    %r12,%r15
    96ca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    96ce:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    96d3:	4c 89 ff             	mov    %r15,%rdi
    96d6:	4c 89 ee             	mov    %r13,%rsi
    96d9:	44 89 0c 24          	mov    %r9d,(%rsp)
    96dd:	48 99                	cqto
    96df:	48 89 d1             	mov    %rdx,%rcx
    96e2:	48 89 c2             	mov    %rax,%rdx
    96e5:	e8 f6 24 00 00       	call   bbe0 <__divmodti4>
    96ea:	44 8b 0c 24          	mov    (%rsp),%r9d
    96ee:	48 89 c1             	mov    %rax,%rcx
    96f1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    96f6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    96fb:	0f 84 94 00 00 00    	je     9795 <fwp_write+0xfb5>
    9701:	41 83 c1 01          	add    $0x1,%r9d
    9705:	48 83 c5 10          	add    $0x10,%rbp
    9709:	41 83 f9 05          	cmp    $0x5,%r9d
    970d:	75 bb                	jne    96ca <fwp_write+0xeea>
    970f:	4d 85 ed             	test   %r13,%r13
    9712:	79 53                	jns    9767 <fwp_write+0xf87>
    9714:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9719:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    971e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9723:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9728:	48 99                	cqto
    972a:	48 f7 d8             	neg    %rax
    972d:	48 83 d2 00          	adc    $0x0,%rdx
    9731:	48 89 c6             	mov    %rax,%rsi
    9734:	48 f7 da             	neg    %rdx
    9737:	e8 04 a3 ff ff       	call   3a40 <fwp_fmt_u128>
    973c:	49 89 e8             	mov    %rbp,%r8
    973f:	ba 00 02 00 00       	mov    $0x200,%edx
    9744:	be 02 00 00 00       	mov    $0x2,%esi
    9749:	31 c0                	xor    %eax,%eax
    974b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9752:	00 
    9753:	48 8d 0d 16 2b 00 00 	lea    0x2b16(%rip),%rcx        # c270 <_IO_stdin_used+0x270>
    975a:	4c 89 e7             	mov    %r12,%rdi
    975d:	e8 5e 9f ff ff       	call   36c0 <__sprintf_chk@plt>
    9762:	e9 f9 f0 ff ff       	jmp    8860 <fwp_write+0x80>
    9767:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    976c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9771:	31 d2                	xor    %edx,%edx
    9773:	48 89 ef             	mov    %rbp,%rdi
    9776:	e8 c5 a2 ff ff       	call   3a40 <fwp_fmt_u128>
    977b:	eb bf                	jmp    973c <fwp_write+0xf5c>
    977d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9784:	4e 61 4e 00 
    9788:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    978f:	00 
    9790:	e9 cb f0 ff ff       	jmp    8860 <fwp_write+0x80>
    9795:	44 89 0c 24          	mov    %r9d,(%rsp)
    9799:	48 89 c8             	mov    %rcx,%rax
    979c:	48 85 d2             	test   %rdx,%rdx
    979f:	78 51                	js     97f2 <fwp_write+0x1012>
    97a1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    97a6:	48 89 c6             	mov    %rax,%rsi
    97a9:	48 89 ef             	mov    %rbp,%rdi
    97ac:	e8 8f a2 ff ff       	call   3a40 <fwp_fmt_u128>
    97b1:	44 8b 0c 24          	mov    (%rsp),%r9d
    97b5:	49 63 c1             	movslq %r9d,%rax
    97b8:	49 89 e8             	mov    %rbp,%r8
    97bb:	ba 00 02 00 00       	mov    $0x200,%edx
    97c0:	be 02 00 00 00       	mov    $0x2,%esi
    97c5:	48 c1 e0 04          	shl    $0x4,%rax
    97c9:	48 8d 3d f0 4a 00 00 	lea    0x4af0(%rip),%rdi        # e2c0 <units.0>
    97d0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    97d7:	00 
    97d8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    97dc:	48 8d 0d 88 2a 00 00 	lea    0x2a88(%rip),%rcx        # c26b <_IO_stdin_used+0x26b>
    97e3:	4c 89 e7             	mov    %r12,%rdi
    97e6:	31 c0                	xor    %eax,%eax
    97e8:	e8 d3 9e ff ff       	call   36c0 <__sprintf_chk@plt>
    97ed:	e9 6e f0 ff ff       	jmp    8860 <fwp_write+0x80>
    97f2:	48 f7 d8             	neg    %rax
    97f5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    97fa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    97ff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9804:	48 83 d2 00          	adc    $0x0,%rdx
    9808:	48 89 c6             	mov    %rax,%rsi
    980b:	48 f7 da             	neg    %rdx
    980e:	e8 2d a2 ff ff       	call   3a40 <fwp_fmt_u128>
    9813:	44 8b 0c 24          	mov    (%rsp),%r9d
    9817:	eb 9c                	jmp    97b5 <fwp_write+0xfd5>
    9819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009820 <fwp_main_thread>:
    9820:	f3 0f 1e fa          	endbr64
    9824:	41 57                	push   %r15
    9826:	41 56                	push   %r14
    9828:	41 55                	push   %r13
    982a:	41 54                	push   %r12
    982c:	55                   	push   %rbp
    982d:	53                   	push   %rbx
    982e:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    9835:	44 8b 1d 88 03 06 00 	mov    0x60388(%rip),%r11d        # 69bc4 <fwp_heap+0x13a4>
    983c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9843:	00 00 
    9845:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    984c:	00 
    984d:	31 c0                	xor    %eax,%eax
    984f:	45 85 db             	test   %r11d,%r11d
    9852:	0f 84 22 14 00 00    	je     ac7a <fwp_main_thread+0x145a>
    9858:	44 8b 15 69 03 06 00 	mov    0x60369(%rip),%r10d        # 69bc8 <fwp_heap+0x13a8>
    985f:	45 85 d2             	test   %r10d,%r10d
    9862:	0f 85 01 14 00 00    	jne    ac69 <fwp_main_thread+0x1449>
    9868:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    986f:	00 
    9870:	31 f6                	xor    %esi,%esi
    9872:	48 c7 05 43 e9 05 00 	movq   $0x40000000,0x5e943(%rip)        # 681c0 <fwp_main_stack_size>
    9879:	00 00 00 40 
    987d:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    9882:	48 89 05 3f e9 05 00 	mov    %rax,0x5e93f(%rip)        # 681c8 <fwp_main_stack_top>
    9889:	48 8d 05 f0 67 00 00 	lea    0x67f0(%rip),%rax        # 10080 <alt.5>
    9890:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    9897:	00 
    9898:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    989f:	00 
    98a0:	48 89 c7             	mov    %rax,%rdi
    98a3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    98a8:	48 c7 84 24 e0 00 00 	movq   $0x10000,0xe0(%rsp)
    98af:	00 00 00 01 00 
    98b4:	c7 84 24 d8 00 00 00 	movl   $0x0,0xd8(%rsp)
    98bb:	00 00 00 00 
    98bf:	e8 dc 9d ff ff       	call   36a0 <sigaltstack@plt>
    98c4:	85 c0                	test   %eax,%eax
    98c6:	0f 85 a9 22 00 00    	jne    bb75 <fwp_main_thread+0x2355>
    98cc:	31 c0                	xor    %eax,%eax
    98ce:	b9 12 00 00 00       	mov    $0x12,%ecx
    98d3:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    98da:	00 
    98db:	f3 48 ab             	rep stos %rax,(%rdi)
    98de:	48 8d 9c 24 40 01 00 	lea    0x140(%rsp),%rbx
    98e5:	00 
    98e6:	48 8d 05 53 a4 ff ff 	lea    -0x5bad(%rip),%rax        # 3d40 <fwp_segv>
    98ed:	c7 84 24 c8 01 00 00 	movl   $0x8000004,0x1c8(%rsp)
    98f4:	04 00 00 08 
    98f8:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    98ff:	00 
    9900:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9905:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
    990c:	00 
    990d:	e8 4e 9c ff ff       	call   3560 <sigemptyset@plt>
    9912:	85 c0                	test   %eax,%eax
    9914:	0f 85 5b 22 00 00    	jne    bb75 <fwp_main_thread+0x2355>
    991a:	31 d2                	xor    %edx,%edx
    991c:	48 89 de             	mov    %rbx,%rsi
    991f:	bf 0b 00 00 00       	mov    $0xb,%edi
    9924:	e8 c7 9a ff ff       	call   33f0 <sigaction@plt>
    9929:	85 c0                	test   %eax,%eax
    992b:	0f 85 44 22 00 00    	jne    bb75 <fwp_main_thread+0x2355>
    9931:	31 d2                	xor    %edx,%edx
    9933:	48 89 de             	mov    %rbx,%rsi
    9936:	bf 07 00 00 00       	mov    $0x7,%edi
    993b:	e8 b0 9a ff ff       	call   33f0 <sigaction@plt>
    9940:	85 c0                	test   %eax,%eax
    9942:	0f 85 2d 22 00 00    	jne    bb75 <fwp_main_thread+0x2355>
    9948:	48 8b 05 f1 02 06 00 	mov    0x602f1(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    994f:	48 85 c0             	test   %rax,%rax
    9952:	0f 88 08 06 00 00    	js     9f60 <fwp_main_thread+0x740>
    9958:	66 0f ef c0          	pxor   %xmm0,%xmm0
    995c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9961:	48 8d 3d b8 a8 ff ff 	lea    -0x5748(%rip),%rdi        # 4220 <ad_raw_report>
    9968:	f2 0f 11 05 58 0b 06 	movsd  %xmm0,0x60b58(%rip)        # 6a4c8 <iteration_start_charge>
    996f:	00 
    9970:	c7 05 6e 0b 06 00 01 	movl   $0x1,0x60b6e(%rip)        # 6a4e8 <iteration_active>
    9977:	00 00 00 
    997a:	e8 71 24 00 00       	call   bdf0 <atexit>
    997f:	85 c0                	test   %eax,%eax
    9981:	0f 85 1d 22 00 00    	jne    bba4 <fwp_main_thread+0x2384>
    9987:	44 8b 0d e2 66 00 00 	mov    0x66e2(%rip),%r9d        # 10070 <st.3>
    998e:	45 85 c9             	test   %r9d,%r9d
    9991:	0f 84 07 06 00 00    	je     9f9e <fwp_main_thread+0x77e>
    9997:	48 8b 2d 62 ee 05 00 	mov    0x5ee62(%rip),%rbp        # 68800 <fwp_cur>
    999e:	48 85 ed             	test   %rbp,%rbp
    99a1:	0f 84 5f 01 00 00    	je     9b06 <fwp_main_thread+0x2e6>
    99a7:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    99ac:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    99b0:	48 89 eb             	mov    %rbp,%rbx
    99b3:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    99b8:	0f 84 41 01 00 00    	je     9aff <fwp_main_thread+0x2df>
    99be:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    99c3:	0f 84 b7 04 00 00    	je     9e80 <fwp_main_thread+0x660>
    99c9:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    99cd:	0f 84 8d 04 00 00    	je     9e60 <fwp_main_thread+0x640>
    99d3:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    99d7:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    99db:	0f 85 1f 05 00 00    	jne    9f00 <fwp_main_thread+0x6e0>
    99e1:	48 8b 43 60          	mov    0x60(%rbx),%rax
    99e5:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    99ec:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    99f0:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    99f7:	00 00 00 00 
    99fb:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9a02:	48 85 d2             	test   %rdx,%rdx
    9a05:	74 07                	je     9a0e <fwp_main_thread+0x1ee>
    9a07:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9a0e:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9a12:	48 85 c0             	test   %rax,%rax
    9a15:	74 34                	je     9a4b <fwp_main_thread+0x22b>
    9a17:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9a1b:	48 8b 05 b6 ed 05 00 	mov    0x5edb6(%rip),%rax        # 687d8 <fwp_timers>
    9a22:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9a26:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9a2d:	00 00 00 00 
    9a31:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9a38:	48 85 c0             	test   %rax,%rax
    9a3b:	74 07                	je     9a44 <fwp_main_thread+0x224>
    9a3d:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9a44:	48 89 1d 8d ed 05 00 	mov    %rbx,0x5ed8d(%rip)        # 687d8 <fwp_timers>
    9a4b:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9a4f:	e8 fc dd ff ff       	call   7850 <fwp_block>
    9a54:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9a5b:	48 85 c9             	test   %rcx,%rcx
    9a5e:	74 47                	je     9aa7 <fwp_main_thread+0x287>
    9a60:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9a67:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9a6e:	48 85 d2             	test   %rdx,%rdx
    9a71:	0f 84 c9 04 00 00    	je     9f40 <fwp_main_thread+0x720>
    9a77:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9a7e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9a85:	48 85 c0             	test   %rax,%rax
    9a88:	74 07                	je     9a91 <fwp_main_thread+0x271>
    9a8a:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9a91:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9a98:	00 00 00 00 
    9a9c:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9aa0:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    9aa7:	48 8b 0d 52 ed 05 00 	mov    0x5ed52(%rip),%rcx        # 68800 <fwp_cur>
    9aae:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9ab2:	0f 84 38 04 00 00    	je     9ef0 <fwp_main_thread+0x6d0>
    9ab8:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9abf:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9ac6:	48 85 d2             	test   %rdx,%rdx
    9ac9:	0f 84 81 04 00 00    	je     9f50 <fwp_main_thread+0x730>
    9acf:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9ad6:	48 85 c0             	test   %rax,%rax
    9ad9:	74 07                	je     9ae2 <fwp_main_thread+0x2c2>
    9adb:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9ae2:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9ae6:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9aea:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    9af1:	48 89 cb             	mov    %rcx,%rbx
    9af4:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9af9:	0f 85 bf fe ff ff    	jne    99be <fwp_main_thread+0x19e>
    9aff:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9b03:	48 89 dd             	mov    %rbx,%rbp
    9b06:	48 83 3d 8a 09 06 00 	cmpq   $0x0,0x6098a(%rip)        # 6a498 <fwp_state_len>
    9b0d:	00 
    9b0e:	0f 84 dc 02 00 00    	je     9df0 <fwp_main_thread+0x5d0>
    9b14:	48 8b 15 dd ec 05 00 	mov    0x5ecdd(%rip),%rdx        # 687f8 <fwp_root>
    9b1b:	c7 05 5b 65 01 00 00 	movl   $0x0,0x1655b(%rip)        # 20080 <fwp_exit_code>
    9b22:	00 00 00 
    9b25:	48 39 d5             	cmp    %rdx,%rbp
    9b28:	0f 85 a6 20 00 00    	jne    bbd4 <fwp_main_thread+0x23b4>
    9b2e:	48 85 d2             	test   %rdx,%rdx
    9b31:	0f 84 99 00 00 00    	je     9bd0 <fwp_main_thread+0x3b0>
    9b37:	48 8b 0d 8a ec 05 00 	mov    0x5ec8a(%rip),%rcx        # 687c8 <fwp_tasks_active>
    9b3e:	c6 42 52 01          	movb   $0x1,0x52(%rdx)
    9b42:	48 85 c9             	test   %rcx,%rcx
    9b45:	0f 84 85 00 00 00    	je     9bd0 <fwp_main_thread+0x3b0>
    9b4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b50:	80 79 50 00          	cmpb   $0x0,0x50(%rcx)
    9b54:	75 08                	jne    9b5e <fwp_main_thread+0x33e>
    9b56:	48 89 cf             	mov    %rcx,%rdi
    9b59:	e8 d2 a5 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    9b5e:	48 8b 89 38 01 00 00 	mov    0x138(%rcx),%rcx
    9b65:	48 85 c9             	test   %rcx,%rcx
    9b68:	75 e6                	jne    9b50 <fwp_main_thread+0x330>
    9b6a:	eb 2d                	jmp    9b99 <fwp_main_thread+0x379>
    9b6c:	0f 1f 40 00          	nopl   0x0(%rax)
    9b70:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    9b77:	48 89 15 62 ec 05 00 	mov    %rdx,0x5ec62(%rip)        # 687e0 <fwp_ready_tail>
    9b7e:	e8 cd dc ff ff       	call   7850 <fwp_block>
    9b83:	e8 b8 da ff ff       	call   7640 <fwp_free_zombie>
    9b88:	48 83 3d 38 ec 05 00 	cmpq   $0x0,0x5ec38(%rip)        # 687c8 <fwp_tasks_active>
    9b8f:	00 
    9b90:	74 3e                	je     9bd0 <fwp_main_thread+0x3b0>
    9b92:	48 8b 15 5f ec 05 00 	mov    0x5ec5f(%rip),%rdx        # 687f8 <fwp_root>
    9b99:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    9b9d:	75 df                	jne    9b7e <fwp_main_thread+0x35e>
    9b9f:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9ba3:	75 d9                	jne    9b7e <fwp_main_thread+0x35e>
    9ba5:	48 8b 05 34 ec 05 00 	mov    0x5ec34(%rip),%rax        # 687e0 <fwp_ready_tail>
    9bac:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    9bb0:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    9bb7:	00 00 00 00 
    9bbb:	48 85 c0             	test   %rax,%rax
    9bbe:	75 b0                	jne    9b70 <fwp_main_thread+0x350>
    9bc0:	48 89 15 21 ec 05 00 	mov    %rdx,0x5ec21(%rip)        # 687e8 <fwp_ready_head>
    9bc7:	eb ae                	jmp    9b77 <fwp_main_thread+0x357>
    9bc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9bd0:	e8 6b da ff ff       	call   7640 <fwp_free_zombie>
    9bd5:	48 83 3d 0b ec 05 00 	cmpq   $0x0,0x5ec0b(%rip)        # 687e8 <fwp_ready_head>
    9bdc:	00 
    9bdd:	0f 85 68 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9be3:	48 83 3d ed eb 05 00 	cmpq   $0x0,0x5ebed(%rip)        # 687d8 <fwp_timers>
    9bea:	00 
    9beb:	0f 85 5a 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9bf1:	8b 05 dd e5 05 00    	mov    0x5e5dd(%rip),%eax        # 681d4 <fwp_stack_pool_n>
    9bf7:	85 c0                	test   %eax,%eax
    9bf9:	74 42                	je     9c3d <fwp_main_thread+0x41d>
    9bfb:	83 e8 01             	sub    $0x1,%eax
    9bfe:	4c 8d 25 db e5 05 00 	lea    0x5e5db(%rip),%r12        # 681e0 <fwp_stack_pool>
    9c05:	48 63 d8             	movslq %eax,%rbx
    9c08:	89 c0                	mov    %eax,%eax
    9c0a:	48 89 da             	mov    %rbx,%rdx
    9c0d:	48 29 c2             	sub    %rax,%rdx
    9c10:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9c14:	90                   	nop
    9c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9c1c:	00 00 00 00 
    9c20:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9c24:	89 1d aa e5 05 00    	mov    %ebx,0x5e5aa(%rip)        # 681d4 <fwp_stack_pool_n>
    9c2a:	be 00 00 00 10       	mov    $0x10000000,%esi
    9c2f:	48 83 eb 01          	sub    $0x1,%rbx
    9c33:	e8 88 99 ff ff       	call   35c0 <munmap@plt>
    9c38:	48 39 eb             	cmp    %rbp,%rbx
    9c3b:	75 e3                	jne    9c20 <fwp_main_thread+0x400>
    9c3d:	8b 3d d5 63 00 00    	mov    0x63d5(%rip),%edi        # 10018 <fwp_epfd>
    9c43:	85 ff                	test   %edi,%edi
    9c45:	78 05                	js     9c4c <fwp_main_thread+0x42c>
    9c47:	e8 74 98 ff ff       	call   34c0 <close@plt>
    9c4c:	4c 8b 25 8d e7 05 00 	mov    0x5e78d(%rip),%r12        # 683e0 <fwp_nfdws>
    9c53:	48 8b 2d 8e e7 05 00 	mov    0x5e78e(%rip),%rbp        # 683e8 <fwp_fdws>
    9c5a:	31 db                	xor    %ebx,%ebx
    9c5c:	c7 05 b2 63 00 00 ff 	movl   $0xffffffff,0x63b2(%rip)        # 10018 <fwp_epfd>
    9c63:	ff ff ff 
    9c66:	4d 85 e4             	test   %r12,%r12
    9c69:	74 32                	je     9c9d <fwp_main_thread+0x47d>
    9c6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c70:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9c75:	48 85 ff             	test   %rdi,%rdi
    9c78:	74 1a                	je     9c94 <fwp_main_thread+0x474>
    9c7a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9c7e:	0f 85 c7 9a ff ff    	jne    374b <fwp_main_thread.cold>
    9c84:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9c89:	0f 85 bc 9a ff ff    	jne    374b <fwp_main_thread.cold>
    9c8f:	e8 7c bd ff ff       	call   5a10 <fwp_mem_free>
    9c94:	48 83 c3 01          	add    $0x1,%rbx
    9c98:	4c 39 e3             	cmp    %r12,%rbx
    9c9b:	75 d3                	jne    9c70 <fwp_main_thread+0x450>
    9c9d:	48 89 ef             	mov    %rbp,%rdi
    9ca0:	e8 6b bd ff ff       	call   5a10 <fwp_mem_free>
    9ca5:	48 8b 15 4c eb 05 00 	mov    0x5eb4c(%rip),%rdx        # 687f8 <fwp_root>
    9cac:	48 c7 05 31 e7 05 00 	movq   $0x0,0x5e731(%rip)        # 683e8 <fwp_fdws>
    9cb3:	00 00 00 00 
    9cb7:	48 c7 05 1e e7 05 00 	movq   $0x0,0x5e71e(%rip)        # 683e0 <fwp_nfdws>
    9cbe:	00 00 00 00 
    9cc2:	48 85 d2             	test   %rdx,%rdx
    9cc5:	74 4e                	je     9d15 <fwp_main_thread+0x4f5>
    9cc7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9ccc:	0f 85 79 9a ff ff    	jne    374b <fwp_main_thread.cold>
    9cd2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9cd9:	00 
    9cda:	0f 85 6b 9a ff ff    	jne    374b <fwp_main_thread.cold>
    9ce0:	48 83 3d b0 07 06 00 	cmpq   $0x0,0x607b0(%rip)        # 6a498 <fwp_state_len>
    9ce7:	00 
    9ce8:	0f 85 5d 9a ff ff    	jne    374b <fwp_main_thread.cold>
    9cee:	48 83 3d 92 07 06 00 	cmpq   $0x0,0x60792(%rip)        # 6a488 <fwp_state_owners>
    9cf5:	00 
    9cf6:	0f 85 4f 9a ff ff    	jne    374b <fwp_main_thread.cold>
    9cfc:	b9 79 00 00 00       	mov    $0x79,%ecx
    9d01:	31 c0                	xor    %eax,%eax
    9d03:	48 8d 3d f6 e6 05 00 	lea    0x5e6f6(%rip),%rdi        # 68400 <fwp_root_context>
    9d0a:	f3 48 ab             	rep stos %rax,(%rdi)
    9d0d:	48 89 d7             	mov    %rdx,%rdi
    9d10:	e8 fb bc ff ff       	call   5a10 <fwp_mem_free>
    9d15:	66 0f 6f 05 93 64 04 	movdqa 0x46493(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    9d1c:	00 
    9d1d:	66 0f d4 05 7b 64 04 	paddq  0x4647b(%rip),%xmm0        # 501a0 <ad_raw_live>
    9d24:	00 
    9d25:	48 c7 05 d0 ea 05 00 	movq   $0x0,0x5ead0(%rip)        # 68800 <fwp_cur>
    9d2c:	00 00 00 00 
    9d30:	48 8b 05 09 ff 05 00 	mov    0x5ff09(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    9d37:	48 c7 05 b6 ea 05 00 	movq   $0x0,0x5eab6(%rip)        # 687f8 <fwp_root>
    9d3e:	00 00 00 00 
    9d42:	c7 05 9c 07 06 00 00 	movl   $0x0,0x6079c(%rip)        # 6a4e8 <iteration_active>
    9d49:	00 00 00 
    9d4c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    9d50:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    9d55:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    9d59:	66 0f d6 05 97 63 01 	movq   %xmm0,0x16397(%rip)        # 200f8 <ad_raw_before_shutdown>
    9d60:	00 
    9d61:	48 85 c0             	test   %rax,%rax
    9d64:	0f 88 16 02 00 00    	js     9f80 <fwp_main_thread+0x760>
    9d6a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9d6e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    9d73:	f2 0f 5c 0d 4d 07 06 	subsd  0x6074d(%rip),%xmm1        # 6a4c8 <iteration_start_charge>
    9d7a:	00 
    9d7b:	48 8b 3d be 62 00 00 	mov    0x62be(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    9d82:	48 8d 15 b7 2d 00 00 	lea    0x2db7(%rip),%rdx        # cb40 <_IO_stdin_used+0xb40>
    9d89:	be 02 00 00 00       	mov    $0x2,%esi
    9d8e:	f2 0f 10 05 2a 07 06 	movsd  0x6072a(%rip),%xmm0        # 6a4c0 <iteration_peak>
    9d95:	00 
    9d96:	4c 8b 0d 33 07 06 00 	mov    0x60733(%rip),%r9        # 6a4d0 <iteration_retains>
    9d9d:	b8 02 00 00 00       	mov    $0x2,%eax
    9da2:	4c 8b 05 2f 07 06 00 	mov    0x6072f(%rip),%r8        # 6a4d8 <iteration_bytes>
    9da9:	48 8b 0d 30 07 06 00 	mov    0x60730(%rip),%rcx        # 6a4e0 <iteration_requests>
    9db0:	e8 bb 98 ff ff       	call   3670 <__fprintf_chk@plt>
    9db5:	48 8b 3d 64 62 00 00 	mov    0x6264(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    9dbc:	e8 df 97 ff ff       	call   35a0 <fflush@plt>
    9dc1:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
    9dc8:	00 
    9dc9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9dd0:	00 00 
    9dd2:	0f 85 a9 1d 00 00    	jne    bb81 <fwp_main_thread+0x2361>
    9dd8:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    9ddf:	31 c0                	xor    %eax,%eax
    9de1:	5b                   	pop    %rbx
    9de2:	5d                   	pop    %rbp
    9de3:	41 5c                	pop    %r12
    9de5:	41 5d                	pop    %r13
    9de7:	41 5e                	pop    %r14
    9de9:	41 5f                	pop    %r15
    9deb:	c3                   	ret
    9dec:	0f 1f 40 00          	nopl   0x0(%rax)
    9df0:	48 83 3d 90 06 06 00 	cmpq   $0x0,0x60690(%rip)        # 6a488 <fwp_state_owners>
    9df7:	00 
    9df8:	0f 85 16 fd ff ff    	jne    9b14 <fwp_main_thread+0x2f4>
    9dfe:	48 8b 3d 9b 06 06 00 	mov    0x6069b(%rip),%rdi        # 6a4a0 <fwp_state>
    9e05:	e8 06 bc ff ff       	call   5a10 <fwp_mem_free>
    9e0a:	48 c7 05 8b 06 06 00 	movq   $0x0,0x6068b(%rip)        # 6a4a0 <fwp_state>
    9e11:	00 00 00 00 
    9e15:	48 c7 05 70 06 06 00 	movq   $0x0,0x60670(%rip)        # 6a490 <fwp_state_cap>
    9e1c:	00 00 00 00 
    9e20:	48 85 ed             	test   %rbp,%rbp
    9e23:	0f 84 eb fc ff ff    	je     9b14 <fwp_main_thread+0x2f4>
    9e29:	48 8b 15 c8 e9 05 00 	mov    0x5e9c8(%rip),%rdx        # 687f8 <fwp_root>
    9e30:	48 c7 85 a8 00 00 00 	movq   $0x0,0xa8(%rbp)
    9e37:	00 00 00 00 
    9e3b:	48 c7 85 b8 00 00 00 	movq   $0x0,0xb8(%rbp)
    9e42:	00 00 00 00 
    9e46:	c7 05 30 62 01 00 00 	movl   $0x0,0x16230(%rip)        # 20080 <fwp_exit_code>
    9e4d:	00 00 00 
    9e50:	48 39 d5             	cmp    %rdx,%rbp
    9e53:	0f 84 de fc ff ff    	je     9b37 <fwp_main_thread+0x317>
    9e59:	e9 ed 98 ff ff       	jmp    374b <fwp_main_thread.cold>
    9e5e:	66 90                	xchg   %ax,%ax
    9e60:	e8 5b a7 ff ff       	call   45c0 <fwp_now_ns>
    9e65:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9e69:	7c 15                	jl     9e80 <fwp_main_thread+0x660>
    9e6b:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9e6f:	75 0f                	jne    9e80 <fwp_main_thread+0x660>
    9e71:	48 89 ef             	mov    %rbp,%rdi
    9e74:	e8 b7 a2 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    9e79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9e80:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9e84:	0f 85 49 fb ff ff    	jne    99d3 <fwp_main_thread+0x1b3>
    9e8a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9e8e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9e92:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9e96:	0f 85 49 fb ff ff    	jne    99e5 <fwp_main_thread+0x1c5>
    9e9c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9ea0:	48 85 c9             	test   %rcx,%rcx
    9ea3:	0f 84 3c fb ff ff    	je     99e5 <fwp_main_thread+0x1c5>
    9ea9:	48 39 c8             	cmp    %rcx,%rax
    9eac:	48 89 ce             	mov    %rcx,%rsi
    9eaf:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9eb6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9eba:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9ec1:	00 00 00 00 
    9ec5:	48 0f 4e f0          	cmovle %rax,%rsi
    9ec9:	48 85 c0             	test   %rax,%rax
    9ecc:	48 89 c8             	mov    %rcx,%rax
    9ecf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9ed6:	48 0f 45 c6          	cmovne %rsi,%rax
    9eda:	48 85 d2             	test   %rdx,%rdx
    9edd:	74 07                	je     9ee6 <fwp_main_thread+0x6c6>
    9edf:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9ee6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9eea:	e9 28 fb ff ff       	jmp    9a17 <fwp_main_thread+0x1f7>
    9eef:	90                   	nop
    9ef0:	48 89 cb             	mov    %rcx,%rbx
    9ef3:	e9 bb fa ff ff       	jmp    99b3 <fwp_main_thread+0x193>
    9ef8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9eff:	00 
    9f00:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9f04:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9f0b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9f12:	00 00 00 00 
    9f16:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9f1d:	48 85 c0             	test   %rax,%rax
    9f20:	0f 84 6b 19 00 00    	je     b891 <fwp_main_thread+0x2071>
    9f26:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9f2d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9f31:	e9 15 fb ff ff       	jmp    9a4b <fwp_main_thread+0x22b>
    9f36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9f3d:	00 00 00 
    9f40:	48 89 01             	mov    %rax,(%rcx)
    9f43:	e9 3d fb ff ff       	jmp    9a85 <fwp_main_thread+0x265>
    9f48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f4f:	00 
    9f50:	48 89 05 81 e8 05 00 	mov    %rax,0x5e881(%rip)        # 687d8 <fwp_timers>
    9f57:	e9 7a fb ff ff       	jmp    9ad6 <fwp_main_thread+0x2b6>
    9f5c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f60:	48 89 c2             	mov    %rax,%rdx
    9f63:	83 e0 01             	and    $0x1,%eax
    9f66:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9f6a:	48 d1 ea             	shr    $1,%rdx
    9f6d:	48 09 c2             	or     %rax,%rdx
    9f70:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    9f75:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    9f79:	e9 e3 f9 ff ff       	jmp    9961 <fwp_main_thread+0x141>
    9f7e:	66 90                	xchg   %ax,%ax
    9f80:	48 89 c2             	mov    %rax,%rdx
    9f83:	83 e0 01             	and    $0x1,%eax
    9f86:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9f8a:	48 d1 ea             	shr    $1,%rdx
    9f8d:	48 09 c2             	or     %rax,%rdx
    9f90:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    9f95:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    9f99:	e9 d5 fd ff ff       	jmp    9d73 <fwp_main_thread+0x553>
    9f9e:	48 8d 05 0b df ff ff 	lea    -0x20f5(%rip),%rax        # 7eb0 <fwp_drop1>
    9fa5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9fa9:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    9fae:	45 31 f6             	xor    %r14d,%r14d
    9fb1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    9fb6:	48 8b 05 fb 04 06 00 	mov    0x604fb(%rip),%rax        # 6a4b8 <fwp_cleanups>
    9fbd:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    9fc4:	00 00 00 00 00 
    9fc9:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    9fce:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9fd2:	48 8d 2d 47 e8 05 00 	lea    0x5e847(%rip),%rbp        # 68820 <fwp_heap>
    9fd9:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9fe0:	00 
    9fe1:	48 8d 05 e8 9b ff ff 	lea    -0x6418(%rip),%rax        # 3bd0 <fwp_range_release>
    9fe8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    9fef:	00 
    9ff0:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9ff5:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9ffc:	00 
    9ffd:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a004:	00 
    a005:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    a00a:	48 89 05 a7 04 06 00 	mov    %rax,0x604a7(%rip)        # 6a4b8 <fwp_cleanups>
    a011:	eb 45                	jmp    a058 <fwp_main_thread+0x838>
    a013:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a018:	80 f9 01             	cmp    $0x1,%cl
    a01b:	75 29                	jne    a046 <fwp_main_thread+0x826>
    a01d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a020:	0f b7 c0             	movzwl %ax,%eax
    a023:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a026:	48 0f af c1          	imul   %rcx,%rax
    a02a:	48 c1 e8 20          	shr    $0x20,%rax
    a02e:	48 39 d0             	cmp    %rdx,%rax
    a031:	73 13                	jae    a046 <fwp_main_thread+0x826>
    a033:	49 01 c5             	add    %rax,%r13
    a036:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a03b:	0f 84 f9 18 00 00    	je     b93a <fwp_main_thread+0x211a>
    a041:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a046:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    a04d:	00 
    a04e:	48 83 eb 01          	sub    $0x1,%rbx
    a052:	0f 82 85 00 00 00    	jb     a0dd <fwp_main_thread+0x8bd>
    a058:	4c 89 e6             	mov    %r12,%rsi
    a05b:	bf 01 00 00 00       	mov    $0x1,%edi
    a060:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
    a067:	00 
    a068:	48 89 9c 24 d8 00 00 	mov    %rbx,0xd8(%rsp)
    a06f:	00 
    a070:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
    a077:	00 
    a078:	e8 83 c0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a07d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a084:	49 89 c6             	mov    %rax,%r14
    a087:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a08e:	48 c1 e2 10          	shl    $0x10,%rdx
    a092:	48 39 d0             	cmp    %rdx,%rax
    a095:	73 af                	jae    a046 <fwp_main_thread+0x826>
    a097:	48 89 c2             	mov    %rax,%rdx
    a09a:	48 c1 ea 10          	shr    $0x10,%rdx
    a09e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a0a2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a0a9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a0ad:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a0b1:	4d 85 ed             	test   %r13,%r13
    a0b4:	74 90                	je     a046 <fwp_main_thread+0x826>
    a0b6:	0f b6 0a             	movzbl (%rdx),%ecx
    a0b9:	80 f9 02             	cmp    $0x2,%cl
    a0bc:	0f 85 56 ff ff ff    	jne    a018 <fwp_main_thread+0x7f8>
    a0c2:	66 85 c0             	test   %ax,%ax
    a0c5:	0f 84 6b ff ff ff    	je     a036 <fwp_main_thread+0x816>
    a0cb:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    a0d2:	00 
    a0d3:	48 83 eb 01          	sub    $0x1,%rbx
    a0d7:	0f 83 7b ff ff ff    	jae    a058 <fwp_main_thread+0x838>
    a0dd:	48 8b 9c 24 b0 00 00 	mov    0xb0(%rsp),%rbx
    a0e4:	00 
    a0e5:	66 0f 6f 05 23 2d 00 	movdqa 0x2d23(%rip),%xmm0        # ce10 <msg.4+0xd0>
    a0ec:	00 
    a0ed:	bf 01 00 00 00       	mov    $0x1,%edi
    a0f2:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    a0f9:	00 
    a0fa:	48 89 1d b7 03 06 00 	mov    %rbx,0x603b7(%rip)        # 6a4b8 <fwp_cleanups>
    a101:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
    a108:	00 
    a109:	e8 f2 bf ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a10e:	48 8b 15 e3 fa 05 00 	mov    0x5fae3(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    a115:	49 89 c5             	mov    %rax,%r13
    a118:	48 2b 05 b1 fa 05 00 	sub    0x5fab1(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    a11f:	48 c1 e2 10          	shl    $0x10,%rdx
    a123:	48 39 d0             	cmp    %rdx,%rax
    a126:	73 59                	jae    a181 <fwp_main_thread+0x961>
    a128:	48 89 c2             	mov    %rax,%rdx
    a12b:	48 c1 ea 10          	shr    $0x10,%rdx
    a12f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a133:	48 8b 15 de fa 05 00 	mov    0x5fade(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    a13a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a13e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a142:	4d 85 e4             	test   %r12,%r12
    a145:	74 3a                	je     a181 <fwp_main_thread+0x961>
    a147:	0f b6 0a             	movzbl (%rdx),%ecx
    a14a:	80 f9 02             	cmp    $0x2,%cl
    a14d:	0f 84 bb 17 00 00    	je     b90e <fwp_main_thread+0x20ee>
    a153:	80 f9 01             	cmp    $0x1,%cl
    a156:	75 29                	jne    a181 <fwp_main_thread+0x961>
    a158:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a15b:	0f b7 c0             	movzwl %ax,%eax
    a15e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a161:	48 0f af c1          	imul   %rcx,%rax
    a165:	48 c1 e8 20          	shr    $0x20,%rax
    a169:	48 39 d0             	cmp    %rdx,%rax
    a16c:	73 13                	jae    a181 <fwp_main_thread+0x961>
    a16e:	49 01 c4             	add    %rax,%r12
    a171:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a176:	0f 84 63 19 00 00    	je     badf <fwp_main_thread+0x22bf>
    a17c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a181:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a188:	00 f0 3f 
    a18b:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    a192:	00 
    a193:	bf 01 00 00 00       	mov    $0x1,%edi
    a198:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
    a19f:	00 
    a1a0:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    a1a7:	00 
    a1a8:	e8 53 bf ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a1ad:	48 8b 15 44 fa 05 00 	mov    0x5fa44(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    a1b4:	49 89 c5             	mov    %rax,%r13
    a1b7:	48 2b 05 12 fa 05 00 	sub    0x5fa12(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    a1be:	48 c1 e2 10          	shl    $0x10,%rdx
    a1c2:	48 39 d0             	cmp    %rdx,%rax
    a1c5:	73 59                	jae    a220 <fwp_main_thread+0xa00>
    a1c7:	48 89 c2             	mov    %rax,%rdx
    a1ca:	48 c1 ea 10          	shr    $0x10,%rdx
    a1ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a1d2:	48 8b 15 3f fa 05 00 	mov    0x5fa3f(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    a1d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1dd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a1e1:	4d 85 e4             	test   %r12,%r12
    a1e4:	74 3a                	je     a220 <fwp_main_thread+0xa00>
    a1e6:	0f b6 0a             	movzbl (%rdx),%ecx
    a1e9:	80 f9 02             	cmp    $0x2,%cl
    a1ec:	0f 84 2a 17 00 00    	je     b91c <fwp_main_thread+0x20fc>
    a1f2:	80 f9 01             	cmp    $0x1,%cl
    a1f5:	75 29                	jne    a220 <fwp_main_thread+0xa00>
    a1f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1fa:	0f b7 c0             	movzwl %ax,%eax
    a1fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a200:	48 0f af c1          	imul   %rcx,%rax
    a204:	48 c1 e8 20          	shr    $0x20,%rax
    a208:	48 39 d0             	cmp    %rdx,%rax
    a20b:	73 13                	jae    a220 <fwp_main_thread+0xa00>
    a20d:	49 01 c4             	add    %rax,%r12
    a210:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a215:	0f 84 d1 18 00 00    	je     baec <fwp_main_thread+0x22cc>
    a21b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a220:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a227:	33 f3 bf 
    a22a:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    a231:	00 
    a232:	bf 01 00 00 00       	mov    $0x1,%edi
    a237:	4c 89 ac 24 18 01 00 	mov    %r13,0x118(%rsp)
    a23e:	00 
    a23f:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
    a246:	00 
    a247:	e8 b4 be ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a24c:	48 8b 15 a5 f9 05 00 	mov    0x5f9a5(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    a253:	48 8b 0d 76 f9 05 00 	mov    0x5f976(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    a25a:	48 89 04 24          	mov    %rax,(%rsp)
    a25e:	48 89 d6             	mov    %rdx,%rsi
    a261:	48 29 c8             	sub    %rcx,%rax
    a264:	48 c1 e6 10          	shl    $0x10,%rsi
    a268:	48 39 f0             	cmp    %rsi,%rax
    a26b:	73 69                	jae    a2d6 <fwp_main_thread+0xab6>
    a26d:	48 89 c6             	mov    %rax,%rsi
    a270:	48 c1 ee 10          	shr    $0x10,%rsi
    a274:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a278:	48 8b 35 99 f9 05 00 	mov    0x5f999(%rip),%rsi        # 69c18 <fwp_heap+0x13f8>
    a27f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a283:	4c 8b 66 20          	mov    0x20(%rsi),%r12
    a287:	4d 85 e4             	test   %r12,%r12
    a28a:	74 4a                	je     a2d6 <fwp_main_thread+0xab6>
    a28c:	0f b6 3e             	movzbl (%rsi),%edi
    a28f:	40 80 ff 02          	cmp    $0x2,%dil
    a293:	0f 84 67 16 00 00    	je     b900 <fwp_main_thread+0x20e0>
    a299:	40 80 ff 01          	cmp    $0x1,%dil
    a29d:	75 37                	jne    a2d6 <fwp_main_thread+0xab6>
    a29f:	8b 7e 18             	mov    0x18(%rsi),%edi
    a2a2:	0f b7 c0             	movzwl %ax,%eax
    a2a5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a2a8:	48 0f af c7          	imul   %rdi,%rax
    a2ac:	48 c1 e8 20          	shr    $0x20,%rax
    a2b0:	48 39 f0             	cmp    %rsi,%rax
    a2b3:	73 21                	jae    a2d6 <fwp_main_thread+0xab6>
    a2b5:	49 01 c4             	add    %rax,%r12
    a2b8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a2bd:	0f 84 0f 18 00 00    	je     bad2 <fwp_main_thread+0x22b2>
    a2c3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a2c8:	48 8b 0d 01 f9 05 00 	mov    0x5f901(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    a2cf:	48 8b 15 22 f9 05 00 	mov    0x5f922(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    a2d6:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    a2dd:	00 
    a2de:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
    a2e3:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a2e8:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    a2ef:	00 
    a2f0:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a2f5:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    a2fa:	48 8b 04 24          	mov    (%rsp),%rax
    a2fe:	48 c1 e2 10          	shl    $0x10,%rdx
    a302:	48 29 c8             	sub    %rcx,%rax
    a305:	48 39 d0             	cmp    %rdx,%rax
    a308:	0f 83 87 00 00 00    	jae    a395 <fwp_main_thread+0xb75>
    a30e:	48 89 c6             	mov    %rax,%rsi
    a311:	48 c1 ee 10          	shr    $0x10,%rsi
    a315:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a319:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a320:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a324:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a328:	48 85 ff             	test   %rdi,%rdi
    a32b:	74 68                	je     a395 <fwp_main_thread+0xb75>
    a32d:	44 0f b6 06          	movzbl (%rsi),%r8d
    a331:	41 80 f8 02          	cmp    $0x2,%r8b
    a335:	0f 84 f5 14 00 00    	je     b830 <fwp_main_thread+0x2010>
    a33b:	41 80 f8 01          	cmp    $0x1,%r8b
    a33f:	75 54                	jne    a395 <fwp_main_thread+0xb75>
    a341:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a345:	0f b7 c0             	movzwl %ax,%eax
    a348:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a34b:	49 0f af c0          	imul   %r8,%rax
    a34f:	48 c1 e8 20          	shr    $0x20,%rax
    a353:	48 39 f0             	cmp    %rsi,%rax
    a356:	73 3d                	jae    a395 <fwp_main_thread+0xb75>
    a358:	48 01 c7             	add    %rax,%rdi
    a35b:	0f b6 07             	movzbl (%rdi),%eax
    a35e:	84 c0                	test   %al,%al
    a360:	74 33                	je     a395 <fwp_main_thread+0xb75>
    a362:	44 8b 05 7f 01 06 00 	mov    0x6017f(%rip),%r8d        # 6a4e8 <iteration_active>
    a369:	45 85 c0             	test   %r8d,%r8d
    a36c:	74 08                	je     a376 <fwp_main_thread+0xb56>
    a36e:	48 83 05 5a 01 06 00 	addq   $0x1,0x6015a(%rip)        # 6a4d0 <iteration_retains>
    a375:	01 
    a376:	3c fd                	cmp    $0xfd,%al
    a378:	0f 87 cf 16 00 00    	ja     ba4d <fwp_main_thread+0x222d>
    a37e:	83 c0 01             	add    $0x1,%eax
    a381:	88 07                	mov    %al,(%rdi)
    a383:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a38a:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    a391:	48 c1 e2 10          	shl    $0x10,%rdx
    a395:	48 8d 05 c4 cd ff ff 	lea    -0x323c(%rip),%rax        # 7160 <fwp_tape_scope_release>
    a39c:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
    a3a3:	00 
    a3a4:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    a3ab:	00 
    a3ac:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a3b1:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    a3b8:	ff ff ff ff 
    a3bc:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    a3c3:	00 
    a3c4:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a3c9:	48 89 05 e8 00 06 00 	mov    %rax,0x600e8(%rip)        # 6a4b8 <fwp_cleanups>
    a3d0:	48 8d 05 39 5c 00 00 	lea    0x5c39(%rip),%rax        # 10010 <fc37>
    a3d7:	48 29 c8             	sub    %rcx,%rax
    a3da:	48 39 d0             	cmp    %rdx,%rax
    a3dd:	73 6f                	jae    a44e <fwp_main_thread+0xc2e>
    a3df:	48 89 c2             	mov    %rax,%rdx
    a3e2:	48 c1 ea 10          	shr    $0x10,%rdx
    a3e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a3ea:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a3f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a3f5:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a3f9:	48 85 ff             	test   %rdi,%rdi
    a3fc:	74 50                	je     a44e <fwp_main_thread+0xc2e>
    a3fe:	0f b6 0a             	movzbl (%rdx),%ecx
    a401:	80 f9 02             	cmp    $0x2,%cl
    a404:	0f 84 26 12 00 00    	je     b630 <fwp_main_thread+0x1e10>
    a40a:	80 f9 01             	cmp    $0x1,%cl
    a40d:	75 3f                	jne    a44e <fwp_main_thread+0xc2e>
    a40f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a412:	0f b7 c0             	movzwl %ax,%eax
    a415:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a418:	48 0f af c1          	imul   %rcx,%rax
    a41c:	48 c1 e8 20          	shr    $0x20,%rax
    a420:	48 39 d0             	cmp    %rdx,%rax
    a423:	73 29                	jae    a44e <fwp_main_thread+0xc2e>
    a425:	48 01 c7             	add    %rax,%rdi
    a428:	0f b6 07             	movzbl (%rdi),%eax
    a42b:	84 c0                	test   %al,%al
    a42d:	74 1f                	je     a44e <fwp_main_thread+0xc2e>
    a42f:	8b 35 b3 00 06 00    	mov    0x600b3(%rip),%esi        # 6a4e8 <iteration_active>
    a435:	85 f6                	test   %esi,%esi
    a437:	74 08                	je     a441 <fwp_main_thread+0xc21>
    a439:	48 83 05 8f 00 06 00 	addq   $0x1,0x6008f(%rip)        # 6a4d0 <iteration_retains>
    a440:	01 
    a441:	3c fd                	cmp    $0xfd,%al
    a443:	0f 87 be 15 00 00    	ja     ba07 <fwp_main_thread+0x21e7>
    a449:	83 c0 01             	add    $0x1,%eax
    a44c:	88 07                	mov    %al,(%rdi)
    a44e:	48 8d 3d bb 5b 00 00 	lea    0x5bbb(%rip),%rdi        # 10010 <fc37>
    a455:	31 db                	xor    %ebx,%ebx
    a457:	e8 84 c9 ff ff       	call   6de0 <fwp_closure_drop>
    a45c:	4c 8b 24 24          	mov    (%rsp),%r12
    a460:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    a465:	48 83 c3 01          	add    $0x1,%rbx
    a469:	4d 85 e4             	test   %r12,%r12
    a46c:	75 f2                	jne    a460 <fwp_main_thread+0xc40>
    a46e:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    a475:	0f 87 8f 16 00 00    	ja     bb0a <fwp_main_thread+0x22ea>
    a47b:	8b 0d df 5b 00 00    	mov    0x5bdf(%rip),%ecx        # 10060 <registered_finish.1>
    a481:	85 c9                	test   %ecx,%ecx
    a483:	0f 84 6f 11 00 00    	je     b5f8 <fwp_main_thread+0x1dd8>
    a489:	4c 8b 2d 48 5c 01 00 	mov    0x15c48(%rip),%r13        # 200d8 <fwp_tape_next_slot>
    a490:	4c 8b 35 51 5c 01 00 	mov    0x15c51(%rip),%r14        # 200e8 <fwp_ntapes>
    a497:	4d 39 f5             	cmp    %r14,%r13
    a49a:	0f 8d 38 0e 00 00    	jge    b2d8 <fwp_main_thread+0x1ab8>
    a4a0:	49 6b c5 68          	imul   $0x68,%r13,%rax
    a4a4:	48 03 05 45 5c 01 00 	add    0x15c45(%rip),%rax        # 200f0 <fwp_tapes>
    a4ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4b0:	8b 50 04             	mov    0x4(%rax),%edx
    a4b3:	85 d2                	test   %edx,%edx
    a4b5:	75 0c                	jne    a4c3 <fwp_main_thread+0xca3>
    a4b7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    a4bd:	0f 86 15 0e 00 00    	jbe    b2d8 <fwp_main_thread+0x1ab8>
    a4c3:	49 83 c5 01          	add    $0x1,%r13
    a4c7:	48 83 c0 68          	add    $0x68,%rax
    a4cb:	4d 39 f5             	cmp    %r14,%r13
    a4ce:	75 e0                	jne    a4b0 <fwp_main_thread+0xc90>
    a4d0:	49 81 fe fe ff 00 00 	cmp    $0xfffe,%r14
    a4d7:	0f 8f a9 16 00 00    	jg     bb86 <fwp_main_thread+0x2366>
    a4dd:	4c 39 35 fc 5b 01 00 	cmp    %r14,0x15bfc(%rip)        # 200e0 <fwp_tapes_cap>
    a4e4:	4c 8b 3d 05 5c 01 00 	mov    0x15c05(%rip),%r15        # 200f0 <fwp_tapes>
    a4eb:	75 4b                	jne    a538 <fwp_main_thread+0xd18>
    a4ed:	4d 85 f6             	test   %r14,%r14
    a4f0:	0f 84 a4 13 00 00    	je     b89a <fwp_main_thread+0x207a>
    a4f6:	4b 8d 0c 36          	lea    (%r14,%r14,1),%rcx
    a4fa:	b8 ff ff 00 00       	mov    $0xffff,%eax
    a4ff:	48 39 c1             	cmp    %rax,%rcx
    a502:	48 0f 4f c8          	cmovg  %rax,%rcx
    a506:	48 6b f1 68          	imul   $0x68,%rcx,%rsi
    a50a:	31 d2                	xor    %edx,%edx
    a50c:	4c 89 ff             	mov    %r15,%rdi
    a50f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a514:	e8 77 ac ff ff       	call   5190 <ad_raw_realloc>
    a519:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a51e:	48 85 c0             	test   %rax,%rax
    a521:	49 89 c7             	mov    %rax,%r15
    a524:	0f 84 1d 16 00 00    	je     bb47 <fwp_main_thread+0x2327>
    a52a:	48 89 05 bf 5b 01 00 	mov    %rax,0x15bbf(%rip)        # 200f0 <fwp_tapes>
    a531:	48 89 0d a8 5b 01 00 	mov    %rcx,0x15ba8(%rip)        # 200e0 <fwp_tapes_cap>
    a538:	49 6b c6 68          	imul   $0x68,%r14,%rax
    a53c:	49 83 c6 01          	add    $0x1,%r14
    a540:	4c 01 f8             	add    %r15,%rax
    a543:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a547:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a54e:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    a552:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    a559:	00 
    a55a:	48 29 f8             	sub    %rdi,%rax
    a55d:	8d 48 68             	lea    0x68(%rax),%ecx
    a560:	31 c0                	xor    %eax,%eax
    a562:	c1 e9 03             	shr    $0x3,%ecx
    a565:	f3 48 ab             	rep stos %rax,(%rdi)
    a568:	4c 89 35 79 5b 01 00 	mov    %r14,0x15b79(%rip)        # 200e8 <fwp_ntapes>
    a56f:	4d 6b f5 68          	imul   $0x68,%r13,%r14
    a573:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    a578:	48 8d 3d e1 1b 00 00 	lea    0x1be1(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    a57f:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    a583:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    a588:	4d 01 fe             	add    %r15,%r14
    a58b:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    a592:	00 
    a593:	e8 f8 8d ff ff       	call   3390 <getenv@plt>
    a598:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    a59e:	48 85 c0             	test   %rax,%rax
    a5a1:	0f 84 49 0d 00 00    	je     b2f0 <fwp_main_thread+0x1ad0>
    a5a7:	80 38 30             	cmpb   $0x30,(%rax)
    a5aa:	0f 85 40 0d 00 00    	jne    b2f0 <fwp_main_thread+0x1ad0>
    a5b0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    a5b4:	0f 85 36 0d 00 00    	jne    b2f0 <fwp_main_thread+0x1ad0>
    a5ba:	41 8b 06             	mov    (%r14),%eax
    a5bd:	49 8d 5d 01          	lea    0x1(%r13),%rbx
    a5c1:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    a5c8:	00 
    a5c9:	48 89 1d 08 5b 01 00 	mov    %rbx,0x15b08(%rip)        # 200d8 <fwp_tape_next_slot>
    a5d0:	8d 50 01             	lea    0x1(%rax),%edx
    a5d3:	48 8b 05 86 27 00 00 	mov    0x2786(%rip),%rax        # cd60 <msg.4+0x20>
    a5da:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    a5df:	41 89 16             	mov    %edx,(%r14)
    a5e2:	49 89 46 58          	mov    %rax,0x58(%r14)
    a5e6:	48 8b 05 cb fe 05 00 	mov    0x5fecb(%rip),%rax        # 6a4b8 <fwp_cleanups>
    a5ed:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    a5f4:	00 
    a5f5:	48 85 c0             	test   %rax,%rax
    a5f8:	75 12                	jne    a60c <fwp_main_thread+0xdec>
    a5fa:	e9 99 15 00 00       	jmp    bb98 <fwp_main_thread+0x2378>
    a5ff:	90                   	nop
    a600:	48 8b 00             	mov    (%rax),%rax
    a603:	48 85 c0             	test   %rax,%rax
    a606:	0f 84 8c 15 00 00    	je     bb98 <fwp_main_thread+0x2378>
    a60c:	48 8d 3d 4d cb ff ff 	lea    -0x34b3(%rip),%rdi        # 7160 <fwp_tape_scope_release>
    a613:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    a617:	75 e7                	jne    a600 <fwp_main_thread+0xde0>
    a619:	48 8b 70 10          	mov    0x10(%rax),%rsi
    a61d:	44 89 e9             	mov    %r13d,%ecx
    a620:	48 63 06             	movslq (%rsi),%rax
    a623:	49 89 76 50          	mov    %rsi,0x50(%r14)
    a627:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    a62b:	85 c0                	test   %eax,%eax
    a62d:	78 09                	js     a638 <fwp_main_thread+0xe18>
    a62f:	48 6b c0 68          	imul   $0x68,%rax,%rax
    a633:	45 89 6c 07 58       	mov    %r13d,0x58(%r15,%rax,1)
    a638:	89 0e                	mov    %ecx,(%rsi)
    a63a:	48 8b 04 24          	mov    (%rsp),%rax
    a63e:	66 90                	xchg   %ax,%ax
    a640:	48 8b 40 10          	mov    0x10(%rax),%rax
    a644:	49 83 c4 01          	add    $0x1,%r12
    a648:	48 85 c0             	test   %rax,%rax
    a64b:	75 f3                	jne    a640 <fwp_main_thread+0xe20>
    a64d:	4c 8b 3c 24          	mov    (%rsp),%r15
    a651:	0f 1f 40 00          	nopl   0x0(%rax)
    a655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a65c:	00 00 00 00 
    a660:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    a664:	48 83 c0 01          	add    $0x1,%rax
    a668:	4d 85 ff             	test   %r15,%r15
    a66b:	75 f3                	jne    a660 <fwp_main_thread+0xe40>
    a66d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    a674:	ff ff 1f 
    a677:	48 39 c1             	cmp    %rax,%rcx
    a67a:	0f 82 96 14 00 00    	jb     bb16 <fwp_main_thread+0x22f6>
    a680:	4d 85 e4             	test   %r12,%r12
    a683:	0f 8e e7 0d 00 00    	jle    b470 <fwp_main_thread+0x1c50>
    a689:	49 39 c4             	cmp    %rax,%r12
    a68c:	4c 0f 47 e0          	cmova  %rax,%r12
    a690:	4c 89 e0             	mov    %r12,%rax
    a693:	48 c1 e8 3c          	shr    $0x3c,%rax
    a697:	0f 85 79 14 00 00    	jne    bb16 <fwp_main_thread+0x22f6>
    a69d:	4f 8d 2c 24          	lea    (%r12,%r12,1),%r13
    a6a1:	48 c1 e2 10          	shl    $0x10,%rdx
    a6a5:	be 02 00 00 00       	mov    $0x2,%esi
    a6aa:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    a6b1:	00 
    a6b2:	48 09 d3             	or     %rdx,%rbx
    a6b5:	e8 56 b8 ff ff       	call   5f10 <fwp_heap_alloc>
    a6ba:	4c 89 28             	mov    %r13,(%rax)
    a6bd:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a6c4:	49 89 c6             	mov    %rax,%r14
    a6c7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a6ce:	48 c1 e2 10          	shl    $0x10,%rdx
    a6d2:	48 39 d0             	cmp    %rdx,%rax
    a6d5:	0f 83 75 0d 00 00    	jae    b450 <fwp_main_thread+0x1c30>
    a6db:	48 89 c2             	mov    %rax,%rdx
    a6de:	48 c1 ea 10          	shr    $0x10,%rdx
    a6e2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a6e6:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a6ed:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a6f1:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a6f5:	4d 85 ed             	test   %r13,%r13
    a6f8:	74 3a                	je     a734 <fwp_main_thread+0xf14>
    a6fa:	0f b6 0a             	movzbl (%rdx),%ecx
    a6fd:	80 f9 02             	cmp    $0x2,%cl
    a700:	0f 84 d3 0d 00 00    	je     b4d9 <fwp_main_thread+0x1cb9>
    a706:	80 f9 01             	cmp    $0x1,%cl
    a709:	75 29                	jne    a734 <fwp_main_thread+0xf14>
    a70b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a70e:	0f b7 c0             	movzwl %ax,%eax
    a711:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a714:	48 0f af c1          	imul   %rcx,%rax
    a718:	48 c1 e8 20          	shr    $0x20,%rax
    a71c:	48 39 d0             	cmp    %rdx,%rax
    a71f:	73 13                	jae    a734 <fwp_main_thread+0xf14>
    a721:	49 01 c5             	add    %rax,%r13
    a724:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a729:	0f 84 be 0d 00 00    	je     b4ed <fwp_main_thread+0x1ccd>
    a72f:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a734:	4d 85 e4             	test   %r12,%r12
    a737:	74 7b                	je     a7b4 <fwp_main_thread+0xf94>
    a739:	48 89 d9             	mov    %rbx,%rcx
    a73c:	48 8b 14 24          	mov    (%rsp),%rdx
    a740:	31 c0                	xor    %eax,%eax
    a742:	48 c1 e1 20          	shl    $0x20,%rcx
    a746:	0f 1f 00             	nopl   (%rax)
    a749:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a750:	00 00 00 00 
    a754:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a75b:	00 00 00 00 
    a75f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a766:	00 00 00 00 
    a76a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a771:	00 00 00 00 
    a775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a77c:	00 00 00 00 
    a780:	48 89 c6             	mov    %rax,%rsi
    a783:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a788:	48 01 ce             	add    %rcx,%rsi
    a78b:	0f 80 68 13 00 00    	jo     baf9 <fwp_main_thread+0x22d9>
    a791:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    a796:	48 89 c6             	mov    %rax,%rsi
    a799:	48 83 c0 01          	add    $0x1,%rax
    a79d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a7a1:	48 c1 e6 04          	shl    $0x4,%rsi
    a7a5:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    a7ab:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a7af:	4c 39 e0             	cmp    %r12,%rax
    a7b2:	72 cc                	jb     a780 <fwp_main_thread+0xf60>
    a7b4:	49 8b 06             	mov    (%r14),%rax
    a7b7:	48 d1 e8             	shr    $1,%rax
    a7ba:	0f 84 a0 0c 00 00    	je     b460 <fwp_main_thread+0x1c40>
    a7c0:	48 8d 48 ff          	lea    -0x1(%rax),%rcx
    a7c4:	48 89 cf             	mov    %rcx,%rdi
    a7c7:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a7cb:	0f 85 45 13 00 00    	jne    bb16 <fwp_main_thread+0x22f6>
    a7d1:	48 8d 14 09          	lea    (%rcx,%rcx,1),%rdx
    a7d5:	48 85 c9             	test   %rcx,%rcx
    a7d8:	74 49                	je     a823 <fwp_main_thread+0x1003>
    a7da:	48 c1 e0 04          	shl    $0x4,%rax
    a7de:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    a7e3:	49 89 d5             	mov    %rdx,%r13
    a7e6:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    a7ea:	4d 8d 64 06 f8       	lea    -0x8(%r14,%rax,1),%r12
    a7ef:	90                   	nop
    a7f0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    a7f4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    a7f8:	48 83 c3 10          	add    $0x10,%rbx
    a7fc:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    a800:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    a804:	e8 e7 bf ff ff       	call   67f0 <w120>
    a809:	66 48 0f 6e e8       	movq   %rax,%xmm5
    a80e:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a812:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    a816:	49 39 dc             	cmp    %rbx,%r12
    a819:	75 d5                	jne    a7f0 <fwp_main_thread+0xfd0>
    a81b:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    a820:	4c 89 ea             	mov    %r13,%rdx
    a823:	49 89 16             	mov    %rdx,(%r14)
    a826:	4c 89 f7             	mov    %r14,%rdi
    a829:	4c 63 eb             	movslq %ebx,%r13
    a82c:	e8 7f c1 ff ff       	call   69b0 <w176.constprop.0>
    a831:	4c 89 f7             	mov    %r14,%rdi
    a834:	49 89 c4             	mov    %rax,%r12
    a837:	e8 74 d8 ff ff       	call   80b0 <fwp_drop10>
    a83c:	4c 89 ef             	mov    %r13,%rdi
    a83f:	e8 ec 9e ff ff       	call   4730 <fwp_tape_of>
    a844:	48 89 c6             	mov    %rax,%rsi
    a847:	48 8b 40 60          	mov    0x60(%rax),%rax
    a84b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a850:	48 85 c0             	test   %rax,%rax
    a853:	0f 85 6f 13 00 00    	jne    bbc8 <fwp_main_thread+0x23a8>
    a859:	48 89 f7             	mov    %rsi,%rdi
    a85c:	e8 2f 94 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    a861:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    a865:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a86a:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a871:	4c 8b 4e 08          	mov    0x8(%rsi),%r9
    a875:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a879:	66 49 0f 6e fe       	movq   %r14,%xmm7
    a87e:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    a883:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    a888:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    a88c:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    a890:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a896:	77 18                	ja     a8b0 <fwp_main_thread+0x1090>
    a898:	0f b7 c3             	movzwl %bx,%eax
    a89b:	83 e8 01             	sub    $0x1,%eax
    a89e:	48 98                	cltq
    a8a0:	48 3b 05 31 58 01 00 	cmp    0x15831(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    a8a7:	7d 07                	jge    a8b0 <fwp_main_thread+0x1090>
    a8a9:	48 89 05 28 58 01 00 	mov    %rax,0x15828(%rip)        # 200d8 <fwp_tape_next_slot>
    a8b0:	48 8b 05 01 fc 05 00 	mov    0x5fc01(%rip),%rax        # 6a4b8 <fwp_cleanups>
    a8b7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a8bb:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    a8c2:	00 
    a8c3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    a8ca:	00 
    a8cb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a8d2:	00 
    a8d3:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a8d7:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    a8db:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a8df:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a8e6:	00 
    a8e7:	48 8d 05 72 a9 ff ff 	lea    -0x568e(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    a8ee:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    a8f5:	00 
    a8f6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    a8fb:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    a902:	00 
    a903:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a90a:	00 
    a90b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    a910:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
    a917:	00 
    a918:	48 89 05 99 fb 05 00 	mov    %rax,0x5fb99(%rip)        # 6a4b8 <fwp_cleanups>
    a91f:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
    a926:	00 
    a927:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    a92e:	00 
    a92f:	4d 85 e4             	test   %r12,%r12
    a932:	0f 88 08 0d 00 00    	js     b640 <fwp_main_thread+0x1e20>
    a938:	4c 89 e0             	mov    %r12,%rax
    a93b:	48 c1 f8 20          	sar    $0x20,%rax
    a93f:	49 39 c5             	cmp    %rax,%r13
    a942:	0f 85 72 11 00 00    	jne    baba <fwp_main_thread+0x229a>
    a948:	44 89 e1             	mov    %r12d,%ecx
    a94b:	49 89 cd             	mov    %rcx,%r13
    a94e:	48 39 ca             	cmp    %rcx,%rdx
    a951:	0f 8e 6f 11 00 00    	jle    bac6 <fwp_main_thread+0x22a6>
    a957:	49 39 c9             	cmp    %rcx,%r9
    a95a:	0f 8e a0 0b 00 00    	jle    b500 <fwp_main_thread+0x1ce0>
    a960:	4d 39 f1             	cmp    %r14,%r9
    a963:	0f 8f d7 0b 00 00    	jg     b540 <fwp_main_thread+0x1d20>
    a969:	4d 85 c0             	test   %r8,%r8
    a96c:	0f 84 bc 11 00 00    	je     bb2e <fwp_main_thread+0x230e>
    a972:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    a977:	4d 8d 69 ff          	lea    -0x1(%r9),%r13
    a97b:	31 f6                	xor    %esi,%esi
    a97d:	4c 89 c7             	mov    %r8,%rdi
    a980:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    a985:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    a98c:	00 
    a98d:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    a992:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    a997:	e8 14 8b ff ff       	call   34b0 <memset@plt>
    a99c:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a9a1:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    a9a7:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    a9ad:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
    a9b2:	49 89 c0             	mov    %rax,%r8
    a9b5:	f2 0f 10 05 ab 23 00 	movsd  0x23ab(%rip),%xmm0        # cd68 <msg.4+0x28>
    a9bc:	00 
    a9bd:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    a9c3:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    a9c9:	4d 39 e9             	cmp    %r13,%r9
    a9cc:	0f 8f 8f 00 00 00    	jg     aa61 <fwp_main_thread+0x1241>
    a9d2:	0f 12 fb             	movhlps %xmm3,%xmm7
    a9d5:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    a9da:	0f 12 da             	movhlps %xmm2,%xmm3
    a9dd:	4d 29 cd             	sub    %r9,%r13
    a9e0:	66 49 0f 7e da       	movq   %xmm3,%r10
    a9e5:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    a9ea:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    a9ef:	4f 8d 1c c8          	lea    (%r8,%r9,8),%r11
    a9f3:	4b 8d 14 ea          	lea    (%r10,%r13,8),%rdx
    a9f7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a9fb:	48 29 f1             	sub    %rsi,%rcx
    a9fe:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    aa02:	4d 29 d3             	sub    %r10,%r11
    aa05:	4c 29 d7             	sub    %r10,%rdi
    aa08:	eb 0a                	jmp    aa14 <fwp_main_thread+0x11f4>
    aa0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa10:	48 83 e8 04          	sub    $0x4,%rax
    aa14:	f2 41 0f 10 04 13    	movsd  (%r11,%rdx,1),%xmm0
    aa1a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    aa1e:	7a 02                	jp     aa22 <fwp_main_thread+0x1202>
    aa20:	74 36                	je     aa58 <fwp_main_thread+0x1238>
    aa22:	4c 63 14 01          	movslq (%rcx,%rax,1),%r10
    aa26:	45 85 d2             	test   %r10d,%r10d
    aa29:	78 15                	js     aa40 <fwp_main_thread+0x1220>
    aa2b:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    aa30:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    aa34:	f2 43 0f 58 0c d0    	addsd  (%r8,%r10,8),%xmm1
    aa3a:	f2 43 0f 11 0c d0    	movsd  %xmm1,(%r8,%r10,8)
    aa40:	4c 63 10             	movslq (%rax),%r10
    aa43:	45 85 d2             	test   %r10d,%r10d
    aa46:	78 10                	js     aa58 <fwp_main_thread+0x1238>
    aa48:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    aa4c:	f2 43 0f 58 04 d0    	addsd  (%r8,%r10,8),%xmm0
    aa52:	f2 43 0f 11 04 d0    	movsd  %xmm0,(%r8,%r10,8)
    aa58:	48 83 ea 08          	sub    $0x8,%rdx
    aa5c:	48 39 f0             	cmp    %rsi,%rax
    aa5f:	75 af                	jne    aa10 <fwp_main_thread+0x11f0>
    aa61:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    aa68:	ff ff 1f 
    aa6b:	4c 39 c8             	cmp    %r9,%rax
    aa6e:	0f 82 ae 10 00 00    	jb     bb22 <fwp_main_thread+0x2302>
    aa74:	4a 8d 3c cd 08 00 00 	lea    0x8(,%r9,8),%rdi
    aa7b:	00 
    aa7c:	be 02 00 00 00       	mov    $0x2,%esi
    aa81:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
    aa86:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    aa8b:	e8 80 b4 ff ff       	call   5f10 <fwp_heap_alloc>
    aa90:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    aa95:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
    aa9a:	48 89 c3             	mov    %rax,%rbx
    aa9d:	4c 89 08             	mov    %r9,(%rax)
    aaa0:	31 c0                	xor    %eax,%eax
    aaa2:	4d 85 c9             	test   %r9,%r9
    aaa5:	74 2b                	je     aad2 <fwp_main_thread+0x12b2>
    aaa7:	0f 1f 00             	nopl   (%rax)
    aaaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aab1:	00 00 00 00 
    aab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aabc:	00 00 00 00 
    aac0:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    aac4:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    aac9:	48 83 c0 01          	add    $0x1,%rax
    aacd:	49 39 c1             	cmp    %rax,%r9
    aad0:	75 ee                	jne    aac0 <fwp_main_thread+0x12a0>
    aad2:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
    aad9:	00 
    aada:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    aadf:	4c 89 25 d2 f9 05 00 	mov    %r12,0x5f9d2(%rip)        # 6a4b8 <fwp_cleanups>
    aae6:	e8 75 a7 ff ff       	call   5260 <fwp_tape_buffers_release>
    aaeb:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aaf2:	48 89 d8             	mov    %rbx,%rax
    aaf5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aafc:	48 c1 e2 10          	shl    $0x10,%rdx
    ab00:	48 39 d0             	cmp    %rdx,%rax
    ab03:	73 59                	jae    ab5e <fwp_main_thread+0x133e>
    ab05:	48 89 c2             	mov    %rax,%rdx
    ab08:	48 c1 ea 10          	shr    $0x10,%rdx
    ab0c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ab10:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    ab17:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ab1b:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    ab1f:	4d 85 ed             	test   %r13,%r13
    ab22:	74 3a                	je     ab5e <fwp_main_thread+0x133e>
    ab24:	0f b6 0a             	movzbl (%rdx),%ecx
    ab27:	80 f9 02             	cmp    $0x2,%cl
    ab2a:	0f 84 40 0b 00 00    	je     b670 <fwp_main_thread+0x1e50>
    ab30:	80 f9 01             	cmp    $0x1,%cl
    ab33:	75 29                	jne    ab5e <fwp_main_thread+0x133e>
    ab35:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ab38:	0f b7 c0             	movzwl %ax,%eax
    ab3b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab3e:	48 0f af c1          	imul   %rcx,%rax
    ab42:	48 c1 e8 20          	shr    $0x20,%rax
    ab46:	48 39 d0             	cmp    %rdx,%rax
    ab49:	73 13                	jae    ab5e <fwp_main_thread+0x133e>
    ab4b:	49 01 c5             	add    %rax,%r13
    ab4e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    ab53:	0f 84 2b 0b 00 00    	je     b684 <fwp_main_thread+0x1e64>
    ab59:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    ab5e:	4c 3b 64 24 48       	cmp    0x48(%rsp),%r12
    ab63:	0f 85 e2 8b ff ff    	jne    374b <fwp_main_thread.cold>
    ab69:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    ab70:	00 
    ab71:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    ab76:	48 89 05 3b f9 05 00 	mov    %rax,0x5f93b(%rip)        # 6a4b8 <fwp_cleanups>
    ab7d:	e8 de c5 ff ff       	call   7160 <fwp_tape_scope_release>
    ab82:	48 8b 03             	mov    (%rbx),%rax
    ab85:	49 89 c5             	mov    %rax,%r13
    ab88:	49 0f ba f5 3f       	btr    $0x3f,%r13
    ab8d:	48 85 c0             	test   %rax,%rax
    ab90:	0f 88 ea 07 00 00    	js     b380 <fwp_main_thread+0x1b60>
    ab96:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ab9d:	48 89 d8             	mov    %rbx,%rax
    aba0:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aba7:	48 c1 e2 10          	shl    $0x10,%rdx
    abab:	48 39 d0             	cmp    %rdx,%rax
    abae:	0f 83 cc 07 00 00    	jae    b380 <fwp_main_thread+0x1b60>
    abb4:	48 89 c2             	mov    %rax,%rdx
    abb7:	48 c1 ea 10          	shr    $0x10,%rdx
    abbb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    abbf:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    abc6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    abca:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    abce:	48 85 c9             	test   %rcx,%rcx
    abd1:	0f 84 a9 07 00 00    	je     b380 <fwp_main_thread+0x1b60>
    abd7:	0f b6 32             	movzbl (%rdx),%esi
    abda:	40 80 fe 02          	cmp    $0x2,%sil
    abde:	0f 84 8c 07 00 00    	je     b370 <fwp_main_thread+0x1b50>
    abe4:	40 80 fe 01          	cmp    $0x1,%sil
    abe8:	0f 85 92 07 00 00    	jne    b380 <fwp_main_thread+0x1b60>
    abee:	8b 72 18             	mov    0x18(%rdx),%esi
    abf1:	0f b7 c0             	movzwl %ax,%eax
    abf4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    abf7:	48 0f af c6          	imul   %rsi,%rax
    abfb:	48 c1 e8 20          	shr    $0x20,%rax
    abff:	48 39 d0             	cmp    %rdx,%rax
    ac02:	0f 83 78 07 00 00    	jae    b380 <fwp_main_thread+0x1b60>
    ac08:	48 01 c1             	add    %rax,%rcx
    ac0b:	80 39 01             	cmpb   $0x1,(%rcx)
    ac0e:	0f 85 6c 07 00 00    	jne    b380 <fwp_main_thread+0x1b60>
    ac14:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    ac19:	48 89 da             	mov    %rbx,%rdx
    ac1c:	31 ff                	xor    %edi,%edi
    ac1e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    ac23:	48 8d 48 08          	lea    0x8(%rax),%rcx
    ac27:	31 c0                	xor    %eax,%eax
    ac29:	4d 85 ed             	test   %r13,%r13
    ac2c:	75 2b                	jne    ac59 <fwp_main_thread+0x1439>
    ac2e:	eb 58                	jmp    ac88 <fwp_main_thread+0x1468>
    ac30:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    ac34:	0f 88 c4 0e 00 00    	js     bafe <fwp_main_thread+0x22de>
    ac3a:	f2 0f 10 05 3e 21 00 	movsd  0x213e(%rip),%xmm0        # cd80 <msg.4+0x40>
    ac41:	00 
    ac42:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    ac47:	48 83 c0 01          	add    $0x1,%rax
    ac4b:	48 83 c1 08          	add    $0x8,%rcx
    ac4f:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    ac54:	49 39 c5             	cmp    %rax,%r13
    ac57:	74 2f                	je     ac88 <fwp_main_thread+0x1468>
    ac59:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    ac5d:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    ac61:	79 cd                	jns    ac30 <fwp_main_thread+0x1410>
    ac63:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    ac67:	eb c7                	jmp    ac30 <fwp_main_thread+0x1410>
    ac69:	48 8d 3d 50 a0 ff ff 	lea    -0x5fb0(%rip),%rdi        # 4cc0 <fwp_heap_report>
    ac70:	e8 7b 11 00 00       	call   bdf0 <atexit>
    ac75:	e9 ee eb ff ff       	jmp    9868 <fwp_main_thread+0x48>
    ac7a:	e8 51 a1 ff ff       	call   4dd0 <fwp_heap_init>
    ac7f:	e9 d4 eb ff ff       	jmp    9858 <fwp_main_thread+0x38>
    ac84:	0f 1f 40 00          	nopl   0x0(%rax)
    ac88:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    ac8d:	e8 1e d4 ff ff       	call   80b0 <fwp_drop10>
    ac92:	48 8b 1c 24          	mov    (%rsp),%rbx
    ac96:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    ac9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aca0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    aca4:	49 83 c7 01          	add    $0x1,%r15
    aca8:	48 85 db             	test   %rbx,%rbx
    acab:	75 f3                	jne    aca0 <fwp_main_thread+0x1480>
    acad:	4c 8b 32             	mov    (%rdx),%r14
    acb0:	4d 85 f6             	test   %r14,%r14
    acb3:	0f 88 07 01 00 00    	js     adc0 <fwp_main_thread+0x15a0>
    acb9:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    acc0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    acc5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    accc:	48 c1 e1 10          	shl    $0x10,%rcx
    acd0:	48 39 c8             	cmp    %rcx,%rax
    acd3:	0f 83 e7 00 00 00    	jae    adc0 <fwp_main_thread+0x15a0>
    acd9:	48 89 c1             	mov    %rax,%rcx
    acdc:	48 c1 e9 10          	shr    $0x10,%rcx
    ace0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ace4:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    aceb:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    acef:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    acf3:	48 85 f6             	test   %rsi,%rsi
    acf6:	0f 84 c4 00 00 00    	je     adc0 <fwp_main_thread+0x15a0>
    acfc:	0f b6 39             	movzbl (%rcx),%edi
    acff:	40 80 ff 02          	cmp    $0x2,%dil
    ad03:	0f 84 a7 00 00 00    	je     adb0 <fwp_main_thread+0x1590>
    ad09:	40 80 ff 01          	cmp    $0x1,%dil
    ad0d:	0f 85 ad 00 00 00    	jne    adc0 <fwp_main_thread+0x15a0>
    ad13:	8b 79 18             	mov    0x18(%rcx),%edi
    ad16:	0f b7 c0             	movzwl %ax,%eax
    ad19:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ad1c:	48 0f af c7          	imul   %rdi,%rax
    ad20:	48 c1 e8 20          	shr    $0x20,%rax
    ad24:	48 39 c8             	cmp    %rcx,%rax
    ad27:	0f 83 93 00 00 00    	jae    adc0 <fwp_main_thread+0x15a0>
    ad2d:	48 01 c6             	add    %rax,%rsi
    ad30:	80 3e 01             	cmpb   $0x1,(%rsi)
    ad33:	0f 85 87 00 00 00    	jne    adc0 <fwp_main_thread+0x15a0>
    ad39:	4d 39 f7             	cmp    %r14,%r15
    ad3c:	4d 0f 46 f7          	cmovbe %r15,%r14
    ad40:	4d 85 f6             	test   %r14,%r14
    ad43:	0f 84 b3 0c 00 00    	je     b9fc <fwp_main_thread+0x21dc>
    ad49:	4c 8d 62 08          	lea    0x8(%rdx),%r12
    ad4d:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    ad53:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    ad58:	48 8b 34 24          	mov    (%rsp),%rsi
    ad5c:	4e 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%r8
    ad63:	00 
    ad64:	31 c0                	xor    %eax,%eax
    ad66:	49 8d 79 08          	lea    0x8(%r9),%rdi
    ad6a:	eb 35                	jmp    ada1 <fwp_main_thread+0x1581>
    ad6c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ad73:	00 00 
    ad75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad7c:	00 00 00 00 
    ad80:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    ad85:	f2 0f 5c 04 01       	subsd  (%rcx,%rax,1),%xmm0
    ad8a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    ad90:	48 83 c0 08          	add    $0x8,%rax
    ad94:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    ad98:	49 39 c0             	cmp    %rax,%r8
    ad9b:	0f 84 b7 00 00 00    	je     ae58 <fwp_main_thread+0x1638>
    ada1:	48 89 f9             	mov    %rdi,%rcx
    ada4:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    ada8:	79 d6                	jns    ad80 <fwp_main_thread+0x1560>
    adaa:	49 8b 49 10          	mov    0x10(%r9),%rcx
    adae:	eb d0                	jmp    ad80 <fwp_main_thread+0x1560>
    adb0:	66 85 c0             	test   %ax,%ax
    adb3:	0f 84 77 ff ff ff    	je     ad30 <fwp_main_thread+0x1510>
    adb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    adc0:	48 8b 04 24          	mov    (%rsp),%rax
    adc4:	45 31 ed             	xor    %r13d,%r13d
    adc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    adce:	00 00 
    add0:	48 8b 40 10          	mov    0x10(%rax),%rax
    add4:	4c 89 e9             	mov    %r13,%rcx
    add7:	49 83 c5 01          	add    $0x1,%r13
    addb:	48 85 c0             	test   %rax,%rax
    adde:	75 f0                	jne    add0 <fwp_main_thread+0x15b0>
    ade0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    ade7:	ff ff 1f 
    adea:	4c 39 e8             	cmp    %r13,%rax
    aded:	0f 82 23 0d 00 00    	jb     bb16 <fwp_main_thread+0x22f6>
    adf3:	be 02 00 00 00       	mov    $0x2,%esi
    adf8:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    adff:	00 
    ae00:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    ae05:	e8 06 b1 ff ff       	call   5f10 <fwp_heap_alloc>
    ae0a:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    ae0f:	49 89 c4             	mov    %rax,%r12
    ae12:	48 89 c6             	mov    %rax,%rsi
    ae15:	48 8b 04 24          	mov    (%rsp),%rax
    ae19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ae20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    ae24:	48 83 c6 08          	add    $0x8,%rsi
    ae28:	48 89 4e f8          	mov    %rcx,-0x8(%rsi)
    ae2c:	48 8b 40 10          	mov    0x10(%rax),%rax
    ae30:	48 85 c0             	test   %rax,%rax
    ae33:	75 eb                	jne    ae20 <fwp_main_thread+0x1600>
    ae35:	49 0f ba f6 3f       	btr    $0x3f,%r14
    ae3a:	4d 39 ee             	cmp    %r13,%r14
    ae3d:	4d 0f 47 f5          	cmova  %r13,%r14
    ae41:	4d 85 f6             	test   %r14,%r14
    ae44:	0f 84 e0 0a 00 00    	je     b92a <fwp_main_thread+0x210a>
    ae4a:	45 31 ed             	xor    %r13d,%r13d
    ae4d:	e9 01 ff ff ff       	jmp    ad53 <fwp_main_thread+0x1533>
    ae52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae58:	48 8b bd d8 13 00 00 	mov    0x13d8(%rbp),%rdi
    ae5f:	4c 8b 85 b0 13 00 00 	mov    0x13b0(%rbp),%r8
    ae66:	45 31 ff             	xor    %r15d,%r15d
    ae69:	4c 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%r9
    ae70:	48 8b 14 24          	mov    (%rsp),%rdx
    ae74:	48 c1 e7 10          	shl    $0x10,%rdi
    ae78:	eb 1c                	jmp    ae96 <fwp_main_thread+0x1676>
    ae7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae80:	49 83 c7 01          	add    $0x1,%r15
    ae84:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    ae88:	4d 39 f7             	cmp    %r14,%r15
    ae8b:	0f 83 ff 03 00 00    	jae    b290 <fwp_main_thread+0x1a70>
    ae91:	48 85 d2             	test   %rdx,%rdx
    ae94:	74 56                	je     aeec <fwp_main_thread+0x16cc>
    ae96:	48 89 d0             	mov    %rdx,%rax
    ae99:	4c 29 c0             	sub    %r8,%rax
    ae9c:	48 39 f8             	cmp    %rdi,%rax
    ae9f:	73 4b                	jae    aeec <fwp_main_thread+0x16cc>
    aea1:	48 89 c1             	mov    %rax,%rcx
    aea4:	48 c1 e9 10          	shr    $0x10,%rcx
    aea8:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    aeac:	49 8d 0c c9          	lea    (%r9,%rcx,8),%rcx
    aeb0:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    aeb4:	48 85 f6             	test   %rsi,%rsi
    aeb7:	74 33                	je     aeec <fwp_main_thread+0x16cc>
    aeb9:	44 0f b6 11          	movzbl (%rcx),%r10d
    aebd:	41 80 fa 02          	cmp    $0x2,%r10b
    aec1:	0f 84 b1 03 00 00    	je     b278 <fwp_main_thread+0x1a58>
    aec7:	41 80 fa 01          	cmp    $0x1,%r10b
    aecb:	75 1f                	jne    aeec <fwp_main_thread+0x16cc>
    aecd:	44 8b 51 18          	mov    0x18(%rcx),%r10d
    aed1:	0f b7 c0             	movzwl %ax,%eax
    aed4:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aed7:	49 0f af c2          	imul   %r10,%rax
    aedb:	48 c1 e8 20          	shr    $0x20,%rax
    aedf:	48 39 c8             	cmp    %rcx,%rax
    aee2:	73 08                	jae    aeec <fwp_main_thread+0x16cc>
    aee4:	48 01 c6             	add    %rax,%rsi
    aee7:	80 3e 01             	cmpb   $0x1,(%rsi)
    aeea:	74 94                	je     ae80 <fwp_main_thread+0x1660>
    aeec:	4d 39 f7             	cmp    %r14,%r15
    aeef:	72 43                	jb     af34 <fwp_main_thread+0x1714>
    aef1:	e9 9a 03 00 00       	jmp    b290 <fwp_main_thread+0x1a70>
    aef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aefd:	00 00 00 
    af00:	40 80 fe 01          	cmp    $0x1,%sil
    af04:	75 25                	jne    af2b <fwp_main_thread+0x170b>
    af06:	8b 71 18             	mov    0x18(%rcx),%esi
    af09:	0f b7 c0             	movzwl %ax,%eax
    af0c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    af0f:	48 0f af c6          	imul   %rsi,%rax
    af13:	48 c1 e8 20          	shr    $0x20,%rax
    af17:	48 39 c8             	cmp    %rcx,%rax
    af1a:	73 0f                	jae    af2b <fwp_main_thread+0x170b>
    af1c:	48 01 c2             	add    %rax,%rdx
    af1f:	80 3a ff             	cmpb   $0xff,(%rdx)
    af22:	0f 84 08 05 00 00    	je     b430 <fwp_main_thread+0x1c10>
    af28:	c6 02 01             	movb   $0x1,(%rdx)
    af2b:	4d 39 fe             	cmp    %r15,%r14
    af2e:	0f 84 8c 00 00 00    	je     afc0 <fwp_main_thread+0x17a0>
    af34:	49 83 ee 01          	sub    $0x1,%r14
    af38:	66 48 0f 6e f3       	movq   %rbx,%xmm6
    af3d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    af42:	bf 01 00 00 00       	mov    $0x1,%edi
    af47:	f3 43 0f 7e 04 f4    	movq   (%r12,%r14,8),%xmm0
    af4d:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    af51:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    af58:	00 
    af59:	e8 a2 b1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    af5e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    af65:	48 89 c3             	mov    %rax,%rbx
    af68:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    af6f:	48 c1 e2 10          	shl    $0x10,%rdx
    af73:	48 39 d0             	cmp    %rdx,%rax
    af76:	73 b3                	jae    af2b <fwp_main_thread+0x170b>
    af78:	48 89 c2             	mov    %rax,%rdx
    af7b:	48 c1 ea 10          	shr    $0x10,%rdx
    af7f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af83:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    af8a:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    af8e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    af92:	48 85 d2             	test   %rdx,%rdx
    af95:	74 94                	je     af2b <fwp_main_thread+0x170b>
    af97:	0f b6 31             	movzbl (%rcx),%esi
    af9a:	40 80 fe 02          	cmp    $0x2,%sil
    af9e:	0f 85 5c ff ff ff    	jne    af00 <fwp_main_thread+0x16e0>
    afa4:	66 85 c0             	test   %ax,%ax
    afa7:	0f 84 72 ff ff ff    	je     af1f <fwp_main_thread+0x16ff>
    afad:	4d 39 fe             	cmp    %r15,%r14
    afb0:	75 82                	jne    af34 <fwp_main_thread+0x1714>
    afb2:	0f 1f 00             	nopl   (%rax)
    afb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    afbc:	00 00 00 00 
    afc0:	4d 85 f6             	test   %r14,%r14
    afc3:	0f 85 c7 02 00 00    	jne    b290 <fwp_main_thread+0x1a70>
    afc9:	45 85 ed             	test   %r13d,%r13d
    afcc:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    afd2:	4c 8b 34 24          	mov    (%rsp),%r14
    afd6:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    afdb:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    afe0:	e8 2b aa ff ff       	call   5a10 <fwp_mem_free>
    afe5:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    afea:	e8 c1 d0 ff ff       	call   80b0 <fwp_drop10>
    afef:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aff6:	4c 89 f0             	mov    %r14,%rax
    aff9:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b000:	48 c1 e2 10          	shl    $0x10,%rdx
    b004:	48 39 d0             	cmp    %rdx,%rax
    b007:	73 77                	jae    b080 <fwp_main_thread+0x1860>
    b009:	48 89 c2             	mov    %rax,%rdx
    b00c:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    b013:	48 c1 ea 10          	shr    $0x10,%rdx
    b017:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    b01b:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    b01f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b023:	4d 85 e4             	test   %r12,%r12
    b026:	74 58                	je     b080 <fwp_main_thread+0x1860>
    b028:	0f b6 0a             	movzbl (%rdx),%ecx
    b02b:	80 f9 02             	cmp    $0x2,%cl
    b02e:	0f 84 ec 05 00 00    	je     b620 <fwp_main_thread+0x1e00>
    b034:	80 f9 01             	cmp    $0x1,%cl
    b037:	75 47                	jne    b080 <fwp_main_thread+0x1860>
    b039:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b03c:	0f b7 c0             	movzwl %ax,%eax
    b03f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b042:	48 0f af c1          	imul   %rcx,%rax
    b046:	48 c1 e8 20          	shr    $0x20,%rax
    b04a:	48 39 d0             	cmp    %rdx,%rax
    b04d:	73 31                	jae    b080 <fwp_main_thread+0x1860>
    b04f:	49 01 c4             	add    %rax,%r12
    b052:	41 0f b6 04 24       	movzbl (%r12),%eax
    b057:	84 c0                	test   %al,%al
    b059:	74 25                	je     b080 <fwp_main_thread+0x1860>
    b05b:	3c 01                	cmp    $0x1,%al
    b05d:	0f 84 35 06 00 00    	je     b698 <fwp_main_thread+0x1e78>
    b063:	3c ff                	cmp    $0xff,%al
    b065:	0f 84 1a 09 00 00    	je     b985 <fwp_main_thread+0x2165>
    b06b:	83 e8 01             	sub    $0x1,%eax
    b06e:	41 88 04 24          	mov    %al,(%r12)
    b072:	0f 1f 00             	nopl   (%rax)
    b075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b07c:	00 00 00 00 
    b080:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    b085:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b089:	b9 01 00 00 00       	mov    $0x1,%ecx
    b08e:	48 89 de             	mov    %rbx,%rsi
    b091:	48 8d 15 08 4b 00 00 	lea    0x4b08(%rip),%rdx        # fba0 <d0>
    b098:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    b09f:	00 
    b0a0:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    b0a7:	00 00 00 00 00 
    b0ac:	e8 2f d7 ff ff       	call   87e0 <fwp_write>
    b0b1:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
    b0b8:	00 
    b0b9:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    b0c0:	00 
    b0c1:	48 8d 05 a4 0f 00 00 	lea    0xfa4(%rip),%rax        # c06c <_IO_stdin_used+0x6c>
    b0c8:	4d 85 f6             	test   %r14,%r14
    b0cb:	4c 0f 44 f0          	cmove  %rax,%r14
    b0cf:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    b0d3:	0f 87 e3 0a 00 00    	ja     bbbc <fwp_main_thread+0x239c>
    b0d9:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    b0dd:	be 01 00 00 00       	mov    $0x1,%esi
    b0e2:	e8 29 ae ff ff       	call   5f10 <fwp_heap_alloc>
    b0e7:	4c 89 fa             	mov    %r15,%rdx
    b0ea:	4c 89 f6             	mov    %r14,%rsi
    b0ed:	4c 89 38             	mov    %r15,(%rax)
    b0f0:	4c 8d 68 08          	lea    0x8(%rax),%r13
    b0f4:	49 89 c4             	mov    %rax,%r12
    b0f7:	4c 89 ef             	mov    %r13,%rdi
    b0fa:	e8 81 84 ff ff       	call   3580 <memcpy@plt>
    b0ff:	43 c6 44 3c 08 00    	movb   $0x0,0x8(%r12,%r15,1)
    b105:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    b10c:	00 
    b10d:	e8 9e 82 ff ff       	call   33b0 <free@plt>
    b112:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b119:	4c 89 e0             	mov    %r12,%rax
    b11c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b123:	48 c1 e2 10          	shl    $0x10,%rdx
    b127:	48 39 d0             	cmp    %rdx,%rax
    b12a:	73 57                	jae    b183 <fwp_main_thread+0x1963>
    b12c:	48 89 c2             	mov    %rax,%rdx
    b12f:	48 c1 ea 10          	shr    $0x10,%rdx
    b133:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b137:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    b13e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b142:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b146:	4d 85 f6             	test   %r14,%r14
    b149:	74 38                	je     b183 <fwp_main_thread+0x1963>
    b14b:	0f b6 0a             	movzbl (%rdx),%ecx
    b14e:	80 f9 02             	cmp    $0x2,%cl
    b151:	0f 84 09 07 00 00    	je     b860 <fwp_main_thread+0x2040>
    b157:	80 f9 01             	cmp    $0x1,%cl
    b15a:	75 27                	jne    b183 <fwp_main_thread+0x1963>
    b15c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b15f:	0f b7 c0             	movzwl %ax,%eax
    b162:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b165:	48 0f af c1          	imul   %rcx,%rax
    b169:	48 c1 e8 20          	shr    $0x20,%rax
    b16d:	48 39 d0             	cmp    %rdx,%rax
    b170:	73 11                	jae    b183 <fwp_main_thread+0x1963>
    b172:	49 01 c6             	add    %rax,%r14
    b175:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b179:	0f 84 f4 06 00 00    	je     b873 <fwp_main_thread+0x2053>
    b17f:	41 c6 06 01          	movb   $0x1,(%r14)
    b183:	48 89 df             	mov    %rbx,%rdi
    b186:	e8 35 cb ff ff       	call   7cc0 <fwp_drop0>
    b18b:	49 8b 14 24          	mov    (%r12),%rdx
    b18f:	be 01 00 00 00       	mov    $0x1,%esi
    b194:	4c 89 ef             	mov    %r13,%rdi
    b197:	48 8b 0d e2 f2 05 00 	mov    0x5f2e2(%rip),%rcx        # 6a480 <fwp_prog_out>
    b19e:	e8 bd 84 ff ff       	call   3660 <fwrite@plt>
    b1a3:	48 8b 35 d6 f2 05 00 	mov    0x5f2d6(%rip),%rsi        # 6a480 <fwp_prog_out>
    b1aa:	bf 0a 00 00 00       	mov    $0xa,%edi
    b1af:	e8 1c 83 ff ff       	call   34d0 <fputc@plt>
    b1b4:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b1bb:	4c 89 e0             	mov    %r12,%rax
    b1be:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b1c5:	48 c1 e2 10          	shl    $0x10,%rdx
    b1c9:	48 39 d0             	cmp    %rdx,%rax
    b1cc:	73 72                	jae    b240 <fwp_main_thread+0x1a20>
    b1ce:	48 89 c2             	mov    %rax,%rdx
    b1d1:	48 c1 ea 10          	shr    $0x10,%rdx
    b1d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b1d9:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    b1e0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b1e4:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b1e8:	48 85 db             	test   %rbx,%rbx
    b1eb:	74 53                	je     b240 <fwp_main_thread+0x1a20>
    b1ed:	0f b6 0a             	movzbl (%rdx),%ecx
    b1f0:	80 f9 02             	cmp    $0x2,%cl
    b1f3:	0f 84 47 06 00 00    	je     b840 <fwp_main_thread+0x2020>
    b1f9:	80 f9 01             	cmp    $0x1,%cl
    b1fc:	75 42                	jne    b240 <fwp_main_thread+0x1a20>
    b1fe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b201:	0f b7 c0             	movzwl %ax,%eax
    b204:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b207:	48 0f af c1          	imul   %rcx,%rax
    b20b:	48 c1 e8 20          	shr    $0x20,%rax
    b20f:	48 39 d0             	cmp    %rdx,%rax
    b212:	73 2c                	jae    b240 <fwp_main_thread+0x1a20>
    b214:	48 01 c3             	add    %rax,%rbx
    b217:	0f b6 03             	movzbl (%rbx),%eax
    b21a:	84 c0                	test   %al,%al
    b21c:	74 22                	je     b240 <fwp_main_thread+0x1a20>
    b21e:	3c 01                	cmp    $0x1,%al
    b220:	0f 84 83 06 00 00    	je     b8a9 <fwp_main_thread+0x2089>
    b226:	3c ff                	cmp    $0xff,%al
    b228:	0f 84 e3 07 00 00    	je     ba11 <fwp_main_thread+0x21f1>
    b22e:	83 e8 01             	sub    $0x1,%eax
    b231:	88 03                	mov    %al,(%rbx)
    b233:	66 90                	xchg   %ax,%ax
    b235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b23c:	00 00 00 00 
    b240:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    b245:	48 8b 40 10          	mov    0x10(%rax),%rax
    b249:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    b24e:	48 85 c0             	test   %rax,%rax
    b251:	0f 84 fe 06 00 00    	je     b955 <fwp_main_thread+0x2135>
    b257:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b25e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b265:	48 8b 1d 4c f2 05 00 	mov    0x5f24c(%rip),%rbx        # 6a4b8 <fwp_cleanups>
    b26c:	e9 89 f0 ff ff       	jmp    a2fa <fwp_main_thread+0xada>
    b271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b278:	66 85 c0             	test   %ax,%ax
    b27b:	0f 84 66 fc ff ff    	je     aee7 <fwp_main_thread+0x16c7>
    b281:	4d 39 f7             	cmp    %r14,%r15
    b284:	0f 82 aa fc ff ff    	jb     af34 <fwp_main_thread+0x1714>
    b28a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b290:	4c 8b 34 24          	mov    (%rsp),%r14
    b294:	4c 89 e0             	mov    %r12,%rax
    b297:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    b29b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b2a0:	48 8b 10             	mov    (%rax),%rdx
    b2a3:	48 83 c0 08          	add    $0x8,%rax
    b2a7:	4c 89 f6             	mov    %r14,%rsi
    b2aa:	49 89 56 08          	mov    %rdx,0x8(%r14)
    b2ae:	4d 8b 76 10          	mov    0x10(%r14),%r14
    b2b2:	48 39 f8             	cmp    %rdi,%rax
    b2b5:	75 e9                	jne    b2a0 <fwp_main_thread+0x1a80>
    b2b7:	45 85 ed             	test   %r13d,%r13d
    b2ba:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    b2c0:	48 89 5e 10          	mov    %rbx,0x10(%rsi)
    b2c4:	48 8b 1c 24          	mov    (%rsp),%rbx
    b2c8:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    b2cd:	e9 09 fd ff ff       	jmp    afdb <fwp_main_thread+0x17bb>
    b2d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b2d8:	4d 39 f5             	cmp    %r14,%r13
    b2db:	0f 84 ef f1 ff ff    	je     a4d0 <fwp_main_thread+0xcb0>
    b2e1:	4c 8b 3d 08 4e 01 00 	mov    0x14e08(%rip),%r15        # 200f0 <fwp_tapes>
    b2e8:	e9 82 f2 ff ff       	jmp    a56f <fwp_main_thread+0xd4f>
    b2ed:	0f 1f 00             	nopl   (%rax)
    b2f0:	48 83 3d 90 4d 01 00 	cmpq   $0x0,0x14d90(%rip)        # 20088 <fwp_tape_cached_bytes>
    b2f7:	00 
    b2f8:	0f 84 bc f2 ff ff    	je     a5ba <fwp_main_thread+0xd9a>
    b2fe:	66 0f 6f 0d 9a 4d 01 	movdqa 0x14d9a(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    b305:	00 
    b306:	48 c7 05 77 4d 01 00 	movq   $0x0,0x14d77(%rip)        # 20088 <fwp_tape_cached_bytes>
    b30d:	00 00 00 00 
    b311:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    b316:	48 8b 05 a3 4d 01 00 	mov    0x14da3(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    b31d:	66 0f 6f 0d 8b 4d 01 	movdqa 0x14d8b(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    b324:	00 
    b325:	49 89 46 40          	mov    %rax,0x40(%r14)
    b329:	48 8b 05 98 4d 01 00 	mov    0x14d98(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    b330:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    b335:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b339:	49 89 46 18          	mov    %rax,0x18(%r14)
    b33d:	48 8b 05 8c 4d 01 00 	mov    0x14d8c(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    b344:	0f 29 0d 55 4d 01 00 	movaps %xmm1,0x14d55(%rip)        # 200a0 <fwp_tape_workspace>
    b34b:	49 89 46 48          	mov    %rax,0x48(%r14)
    b34f:	0f 29 0d 5a 4d 01 00 	movaps %xmm1,0x14d5a(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    b356:	48 c7 05 6f 4d 01 00 	movq   $0x0,0x14d6f(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    b35d:	00 00 00 00 
    b361:	0f 29 0d 58 4d 01 00 	movaps %xmm1,0x14d58(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    b368:	e9 4d f2 ff ff       	jmp    a5ba <fwp_main_thread+0xd9a>
    b36d:	0f 1f 00             	nopl   (%rax)
    b370:	66 85 c0             	test   %ax,%ax
    b373:	0f 84 92 f8 ff ff    	je     ac0b <fwp_main_thread+0x13eb>
    b379:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b380:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    b387:	ff ff 1f 
    b38a:	4c 39 e8             	cmp    %r13,%rax
    b38d:	0f 82 8f 07 00 00    	jb     bb22 <fwp_main_thread+0x2302>
    b393:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    b39a:	00 
    b39b:	be 01 00 00 00       	mov    $0x1,%esi
    b3a0:	e8 6b ab ff ff       	call   5f10 <fwp_heap_alloc>
    b3a5:	4c 89 28             	mov    %r13,(%rax)
    b3a8:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    b3af:	48 89 c2             	mov    %rax,%rdx
    b3b2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b3b7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b3be:	48 c1 e1 10          	shl    $0x10,%rcx
    b3c2:	48 39 c8             	cmp    %rcx,%rax
    b3c5:	73 59                	jae    b420 <fwp_main_thread+0x1c00>
    b3c7:	48 89 c1             	mov    %rax,%rcx
    b3ca:	48 c1 e9 10          	shr    $0x10,%rcx
    b3ce:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b3d2:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    b3d9:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b3dd:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    b3e1:	4d 85 f6             	test   %r14,%r14
    b3e4:	74 3a                	je     b420 <fwp_main_thread+0x1c00>
    b3e6:	0f b6 31             	movzbl (%rcx),%esi
    b3e9:	40 80 fe 02          	cmp    $0x2,%sil
    b3ed:	0f 84 45 03 00 00    	je     b738 <fwp_main_thread+0x1f18>
    b3f3:	40 80 fe 01          	cmp    $0x1,%sil
    b3f7:	75 27                	jne    b420 <fwp_main_thread+0x1c00>
    b3f9:	8b 71 18             	mov    0x18(%rcx),%esi
    b3fc:	0f b7 c0             	movzwl %ax,%eax
    b3ff:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b402:	48 0f af c6          	imul   %rsi,%rax
    b406:	48 c1 e8 20          	shr    $0x20,%rax
    b40a:	48 39 c8             	cmp    %rcx,%rax
    b40d:	73 11                	jae    b420 <fwp_main_thread+0x1c00>
    b40f:	49 01 c6             	add    %rax,%r14
    b412:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b416:	0f 84 2f 03 00 00    	je     b74b <fwp_main_thread+0x1f2b>
    b41c:	41 c6 06 01          	movb   $0x1,(%r14)
    b420:	48 89 df             	mov    %rbx,%rdi
    b423:	e9 f6 f7 ff ff       	jmp    ac1e <fwp_main_thread+0x13fe>
    b428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b42f:	00 
    b430:	48 89 d7             	mov    %rdx,%rdi
    b433:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    b438:	e8 93 a3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b43d:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    b442:	e9 e1 fa ff ff       	jmp    af28 <fwp_main_thread+0x1708>
    b447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b44e:	00 00 
    b450:	4d 85 e4             	test   %r12,%r12
    b453:	0f 85 e0 f2 ff ff    	jne    a739 <fwp_main_thread+0xf19>
    b459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b460:	31 d2                	xor    %edx,%edx
    b462:	e9 bc f3 ff ff       	jmp    a823 <fwp_main_thread+0x1003>
    b467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b46e:	00 00 
    b470:	48 c1 e2 10          	shl    $0x10,%rdx
    b474:	be 02 00 00 00       	mov    $0x2,%esi
    b479:	bf 08 00 00 00       	mov    $0x8,%edi
    b47e:	48 09 d3             	or     %rdx,%rbx
    b481:	e8 8a aa ff ff       	call   5f10 <fwp_heap_alloc>
    b486:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    b48d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b494:	49 89 c6             	mov    %rax,%r14
    b497:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b49e:	48 c1 e2 10          	shl    $0x10,%rdx
    b4a2:	48 39 d0             	cmp    %rdx,%rax
    b4a5:	73 b9                	jae    b460 <fwp_main_thread+0x1c40>
    b4a7:	48 89 c2             	mov    %rax,%rdx
    b4aa:	48 c1 ea 10          	shr    $0x10,%rdx
    b4ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b4b2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    b4b9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b4bd:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b4c1:	4d 85 ed             	test   %r13,%r13
    b4c4:	0f 84 ea f2 ff ff    	je     a7b4 <fwp_main_thread+0xf94>
    b4ca:	0f b6 0a             	movzbl (%rdx),%ecx
    b4cd:	45 31 e4             	xor    %r12d,%r12d
    b4d0:	80 f9 02             	cmp    $0x2,%cl
    b4d3:	0f 85 2d f2 ff ff    	jne    a706 <fwp_main_thread+0xee6>
    b4d9:	66 85 c0             	test   %ax,%ax
    b4dc:	0f 85 52 f2 ff ff    	jne    a734 <fwp_main_thread+0xf14>
    b4e2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b4e7:	0f 85 42 f2 ff ff    	jne    a72f <fwp_main_thread+0xf0f>
    b4ed:	4c 89 ef             	mov    %r13,%rdi
    b4f0:	e8 db a2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b4f5:	e9 35 f2 ff ff       	jmp    a72f <fwp_main_thread+0xf0f>
    b4fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b500:	48 8d 59 01          	lea    0x1(%rcx),%rbx
    b504:	49 39 de             	cmp    %rbx,%r14
    b507:	7c 3a                	jl     b543 <fwp_main_thread+0x1d23>
    b509:	4d 85 c0             	test   %r8,%r8
    b50c:	0f 84 1c 06 00 00    	je     bb2e <fwp_main_thread+0x230e>
    b512:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b517:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b51e:	00 
    b51f:	31 f6                	xor    %esi,%esi
    b521:	4c 89 c7             	mov    %r8,%rdi
    b524:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    b529:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b52e:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b533:	e9 5f f4 ff ff       	jmp    a997 <fwp_main_thread+0x1177>
    b538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b53f:	00 
    b540:	4c 89 cb             	mov    %r9,%rbx
    b543:	4d 85 f6             	test   %r14,%r14
    b546:	4c 0f 44 f3          	cmove  %rbx,%r14
    b54a:	eb 29                	jmp    b575 <fwp_main_thread+0x1d55>
    b54c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b553:	00 00 
    b555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b55c:	00 00 00 00 
    b560:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    b564:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    b56b:	48 89 d8             	mov    %rbx,%rax
    b56e:	48 0f 4c c2          	cmovl  %rdx,%rax
    b572:	49 89 c6             	mov    %rax,%r14
    b575:	49 39 de             	cmp    %rbx,%r14
    b578:	7c e6                	jl     b560 <fwp_main_thread+0x1d40>
    b57a:	4d 85 c0             	test   %r8,%r8
    b57d:	0f 84 e5 01 00 00    	je     b768 <fwp_main_thread+0x1f48>
    b583:	4c 89 c7             	mov    %r8,%rdi
    b586:	ba 03 00 00 00       	mov    $0x3,%edx
    b58b:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b590:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    b597:	00 
    b598:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b59d:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b5a2:	e8 e9 9b ff ff       	call   5190 <ad_raw_realloc>
    b5a7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b5ac:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b5b2:	48 85 c0             	test   %rax,%rax
    b5b5:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b5bb:	49 89 c0             	mov    %rax,%r8
    b5be:	0f 84 bc 02 00 00    	je     b880 <fwp_main_thread+0x2060>
    b5c4:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    b5cb:	00 
    b5cc:	4c 89 b4 24 00 01 00 	mov    %r14,0x100(%rsp)
    b5d3:	00 
    b5d4:	48 85 db             	test   %rbx,%rbx
    b5d7:	0f 85 e5 02 00 00    	jne    b8c2 <fwp_main_thread+0x20a2>
    b5dd:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b5e4:	4d 85 e4             	test   %r12,%r12
    b5e7:	0f 88 dc f3 ff ff    	js     a9c9 <fwp_main_thread+0x11a9>
    b5ed:	44 89 e1             	mov    %r12d,%ecx
    b5f0:	e9 c0 f3 ff ff       	jmp    a9b5 <fwp_main_thread+0x1195>
    b5f5:	0f 1f 00             	nopl   (%rax)
    b5f8:	48 8d 3d 41 ba ff ff 	lea    -0x45bf(%rip),%rdi        # 7040 <fwp_tape_finish>
    b5ff:	e8 ec 07 00 00       	call   bdf0 <atexit>
    b604:	85 c0                	test   %eax,%eax
    b606:	0f 85 3b 05 00 00    	jne    bb47 <fwp_main_thread+0x2327>
    b60c:	c7 05 4a 4a 00 00 01 	movl   $0x1,0x4a4a(%rip)        # 10060 <registered_finish.1>
    b613:	00 00 00 
    b616:	e9 6e ee ff ff       	jmp    a489 <fwp_main_thread+0xc69>
    b61b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b620:	66 85 c0             	test   %ax,%ax
    b623:	0f 85 57 fa ff ff    	jne    b080 <fwp_main_thread+0x1860>
    b629:	e9 24 fa ff ff       	jmp    b052 <fwp_main_thread+0x1832>
    b62e:	66 90                	xchg   %ax,%ax
    b630:	66 85 c0             	test   %ax,%ax
    b633:	0f 85 15 ee ff ff    	jne    a44e <fwp_main_thread+0xc2e>
    b639:	e9 ea ed ff ff       	jmp    a428 <fwp_main_thread+0xc08>
    b63e:	66 90                	xchg   %ax,%ax
    b640:	4d 39 f1             	cmp    %r14,%r9
    b643:	0f 8f f7 fe ff ff    	jg     b540 <fwp_main_thread+0x1d20>
    b649:	4d 85 c0             	test   %r8,%r8
    b64c:	0f 85 64 02 00 00    	jne    b8b6 <fwp_main_thread+0x2096>
    b652:	4d 85 c9             	test   %r9,%r9
    b655:	0f 85 d3 04 00 00    	jne    bb2e <fwp_main_thread+0x230e>
    b65b:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b662:	e9 62 f3 ff ff       	jmp    a9c9 <fwp_main_thread+0x11a9>
    b667:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b66e:	00 00 
    b670:	66 85 c0             	test   %ax,%ax
    b673:	0f 85 e5 f4 ff ff    	jne    ab5e <fwp_main_thread+0x133e>
    b679:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b67e:	0f 85 d5 f4 ff ff    	jne    ab59 <fwp_main_thread+0x1339>
    b684:	4c 89 ef             	mov    %r13,%rdi
    b687:	e8 44 a1 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b68c:	e9 c8 f4 ff ff       	jmp    ab59 <fwp_main_thread+0x1339>
    b691:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b698:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b69f:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b6a6:	4c 89 f0             	mov    %r14,%rax
    b6a9:	4d 8b 66 10          	mov    0x10(%r14),%r12
    b6ad:	48 29 c8             	sub    %rcx,%rax
    b6b0:	48 c1 e2 10          	shl    $0x10,%rdx
    b6b4:	48 39 d0             	cmp    %rdx,%rax
    b6b7:	73 65                	jae    b71e <fwp_main_thread+0x1efe>
    b6b9:	48 89 c7             	mov    %rax,%rdi
    b6bc:	48 c1 ef 10          	shr    $0x10,%rdi
    b6c0:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    b6c4:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b6c8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b6cc:	48 85 ff             	test   %rdi,%rdi
    b6cf:	74 4d                	je     b71e <fwp_main_thread+0x1efe>
    b6d1:	44 0f b6 06          	movzbl (%rsi),%r8d
    b6d5:	41 80 f8 02          	cmp    $0x2,%r8b
    b6d9:	0f 84 68 02 00 00    	je     b947 <fwp_main_thread+0x2127>
    b6df:	41 80 f8 01          	cmp    $0x1,%r8b
    b6e3:	75 39                	jne    b71e <fwp_main_thread+0x1efe>
    b6e5:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    b6e9:	0f b7 c0             	movzwl %ax,%eax
    b6ec:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b6ef:	49 0f af c0          	imul   %r8,%rax
    b6f3:	48 c1 e8 20          	shr    $0x20,%rax
    b6f7:	48 39 f0             	cmp    %rsi,%rax
    b6fa:	73 22                	jae    b71e <fwp_main_thread+0x1efe>
    b6fc:	48 01 c7             	add    %rax,%rdi
    b6ff:	80 3f 01             	cmpb   $0x1,(%rdi)
    b702:	75 1a                	jne    b71e <fwp_main_thread+0x1efe>
    b704:	4c 89 f7             	mov    %r14,%rdi
    b707:	e8 04 a3 ff ff       	call   5a10 <fwp_mem_free>
    b70c:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b713:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b71a:	48 c1 e2 10          	shl    $0x10,%rdx
    b71e:	4c 89 e0             	mov    %r12,%rax
    b721:	48 29 c8             	sub    %rcx,%rax
    b724:	48 39 d0             	cmp    %rdx,%rax
    b727:	0f 83 53 f9 ff ff    	jae    b080 <fwp_main_thread+0x1860>
    b72d:	4d 89 e6             	mov    %r12,%r14
    b730:	e9 d4 f8 ff ff       	jmp    b009 <fwp_main_thread+0x17e9>
    b735:	0f 1f 00             	nopl   (%rax)
    b738:	66 85 c0             	test   %ax,%ax
    b73b:	0f 85 df fc ff ff    	jne    b420 <fwp_main_thread+0x1c00>
    b741:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b745:	0f 85 d1 fc ff ff    	jne    b41c <fwp_main_thread+0x1bfc>
    b74b:	4c 89 f7             	mov    %r14,%rdi
    b74e:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    b753:	e8 78 a0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b758:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    b75d:	e9 ba fc ff ff       	jmp    b41c <fwp_main_thread+0x1bfc>
    b762:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b768:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    b76f:	ff ff 1f 
    b772:	49 8d 46 ff          	lea    -0x1(%r14),%rax
    b776:	48 39 c2             	cmp    %rax,%rdx
    b779:	0f 82 31 04 00 00    	jb     bbb0 <fwp_main_thread+0x2390>
    b77f:	48 8d 05 3a 4a 04 00 	lea    0x44a3a(%rip),%rax        # 501c0 <ad_raw_blocks>
    b786:	45 31 ed             	xor    %r13d,%r13d
    b789:	eb 2a                	jmp    b7b5 <fwp_main_thread+0x1f95>
    b78b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b792:	00 00 00 
    b795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b79c:	00 00 00 00 
    b7a0:	49 83 c5 01          	add    $0x1,%r13
    b7a4:	48 83 c0 18          	add    $0x18,%rax
    b7a8:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    b7af:	0f 84 8c 02 00 00    	je     ba41 <fwp_main_thread+0x2221>
    b7b5:	48 83 38 00          	cmpq   $0x0,(%rax)
    b7b9:	75 e5                	jne    b7a0 <fwp_main_thread+0x1f80>
    b7bb:	be 08 00 00 00       	mov    $0x8,%esi
    b7c0:	4c 89 f7             	mov    %r14,%rdi
    b7c3:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b7c8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b7cd:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b7d2:	e8 39 7d ff ff       	call   3510 <calloc@plt>
    b7d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b7dc:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b7e2:	48 8d 15 d7 49 04 00 	lea    0x449d7(%rip),%rdx        # 501c0 <ad_raw_blocks>
    b7e9:	48 85 c0             	test   %rax,%rax
    b7ec:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b7f2:	0f 84 88 00 00 00    	je     b880 <fwp_main_thread+0x2060>
    b7f8:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    b7fd:	48 89 c6             	mov    %rax,%rsi
    b800:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
    b805:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    b809:	b9 03 00 00 00       	mov    $0x3,%ecx
    b80e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b813:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    b81a:	00 
    b81b:	e8 e0 83 ff ff       	call   3c00 <ad_raw_record>
    b820:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
    b825:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    b82a:	e9 95 fd ff ff       	jmp    b5c4 <fwp_main_thread+0x1da4>
    b82f:	90                   	nop
    b830:	66 85 c0             	test   %ax,%ax
    b833:	0f 85 5c eb ff ff    	jne    a395 <fwp_main_thread+0xb75>
    b839:	e9 1d eb ff ff       	jmp    a35b <fwp_main_thread+0xb3b>
    b83e:	66 90                	xchg   %ax,%ax
    b840:	66 85 c0             	test   %ax,%ax
    b843:	0f 85 f7 f9 ff ff    	jne    b240 <fwp_main_thread+0x1a20>
    b849:	0f b6 03             	movzbl (%rbx),%eax
    b84c:	84 c0                	test   %al,%al
    b84e:	0f 85 ca f9 ff ff    	jne    b21e <fwp_main_thread+0x19fe>
    b854:	e9 e7 f9 ff ff       	jmp    b240 <fwp_main_thread+0x1a20>
    b859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b860:	66 85 c0             	test   %ax,%ax
    b863:	0f 85 1a f9 ff ff    	jne    b183 <fwp_main_thread+0x1963>
    b869:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b86d:	0f 85 0c f9 ff ff    	jne    b17f <fwp_main_thread+0x195f>
    b873:	4c 89 f7             	mov    %r14,%rdi
    b876:	e8 55 9f ff ff       	call   57d0 <fwp_rc_forget_slot>
    b87b:	e9 ff f8 ff ff       	jmp    b17f <fwp_main_thread+0x195f>
    b880:	48 85 db             	test   %rbx,%rbx
    b883:	0f 85 a5 02 00 00    	jne    bb2e <fwp_main_thread+0x230e>
    b889:	45 31 c0             	xor    %r8d,%r8d
    b88c:	e9 4c fd ff ff       	jmp    b5dd <fwp_main_thread+0x1dbd>
    b891:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b895:	e9 b1 e1 ff ff       	jmp    9a4b <fwp_main_thread+0x22b>
    b89a:	be 68 00 00 00       	mov    $0x68,%esi
    b89f:	b9 01 00 00 00       	mov    $0x1,%ecx
    b8a4:	e9 61 ec ff ff       	jmp    a50a <fwp_main_thread+0xcea>
    b8a9:	4c 89 e7             	mov    %r12,%rdi
    b8ac:	e8 5f a1 ff ff       	call   5a10 <fwp_mem_free>
    b8b1:	e9 8a f9 ff ff       	jmp    b240 <fwp_main_thread+0x1a20>
    b8b6:	4d 85 c9             	test   %r9,%r9
    b8b9:	0f 84 9c fd ff ff    	je     b65b <fwp_main_thread+0x1e3b>
    b8bf:	4c 89 cb             	mov    %r9,%rbx
    b8c2:	4c 89 c7             	mov    %r8,%rdi
    b8c5:	31 f6                	xor    %esi,%esi
    b8c7:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b8cc:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    b8d0:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b8d7:	00 
    b8d8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b8dd:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b8e2:	e8 c9 7b ff ff       	call   34b0 <memset@plt>
    b8e7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b8ec:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b8f2:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b8f8:	49 89 c0             	mov    %rax,%r8
    b8fb:	e9 e4 fc ff ff       	jmp    b5e4 <fwp_main_thread+0x1dc4>
    b900:	66 85 c0             	test   %ax,%ax
    b903:	0f 85 cd e9 ff ff    	jne    a2d6 <fwp_main_thread+0xab6>
    b909:	e9 aa e9 ff ff       	jmp    a2b8 <fwp_main_thread+0xa98>
    b90e:	66 85 c0             	test   %ax,%ax
    b911:	0f 85 6a e8 ff ff    	jne    a181 <fwp_main_thread+0x961>
    b917:	e9 55 e8 ff ff       	jmp    a171 <fwp_main_thread+0x951>
    b91c:	66 85 c0             	test   %ax,%ax
    b91f:	0f 85 fb e8 ff ff    	jne    a220 <fwp_main_thread+0xa00>
    b925:	e9 e6 e8 ff ff       	jmp    a210 <fwp_main_thread+0x9f0>
    b92a:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    b92f:	4c 8b 34 24          	mov    (%rsp),%r14
    b933:	31 db                	xor    %ebx,%ebx
    b935:	e9 a1 f6 ff ff       	jmp    afdb <fwp_main_thread+0x17bb>
    b93a:	4c 89 ef             	mov    %r13,%rdi
    b93d:	e8 8e 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b942:	e9 fa e6 ff ff       	jmp    a041 <fwp_main_thread+0x821>
    b947:	66 85 c0             	test   %ax,%ax
    b94a:	0f 85 ce fd ff ff    	jne    b71e <fwp_main_thread+0x1efe>
    b950:	e9 aa fd ff ff       	jmp    b6ff <fwp_main_thread+0x1edf>
    b955:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    b95a:	48 8b 3c 24          	mov    (%rsp),%rdi
    b95e:	e8 5d c3 ff ff       	call   7cc0 <fwp_drop0>
    b963:	4c 89 f7             	mov    %r14,%rdi
    b966:	e8 55 c3 ff ff       	call   7cc0 <fwp_drop0>
    b96b:	48 c7 05 f2 46 00 00 	movq   $0x0,0x46f2(%rip)        # 10068 <v.2>
    b972:	00 00 00 00 
    b976:	c7 05 f0 46 00 00 01 	movl   $0x1,0x46f0(%rip)        # 10070 <st.3>
    b97d:	00 00 00 
    b980:	e9 12 e0 ff ff       	jmp    9997 <fwp_main_thread+0x177>
    b985:	4c 89 e2             	mov    %r12,%rdx
    b988:	48 c1 ea 11          	shr    $0x11,%rdx
    b98c:	4c 31 e2             	xor    %r12,%rdx
    b98f:	48 89 d0             	mov    %rdx,%rax
    b992:	48 c1 e8 09          	shr    $0x9,%rax
    b996:	48 31 c2             	xor    %rax,%rdx
    b999:	0f b6 d2             	movzbl %dl,%edx
    b99c:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b9a3:	00 
    b9a4:	48 85 c0             	test   %rax,%rax
    b9a7:	75 20                	jne    b9c9 <fwp_main_thread+0x21a9>
    b9a9:	e9 87 00 00 00       	jmp    ba35 <fwp_main_thread+0x2215>
    b9ae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b9b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b9bc:	00 00 00 00 
    b9c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b9c4:	48 85 c0             	test   %rax,%rax
    b9c7:	74 6c                	je     ba35 <fwp_main_thread+0x2215>
    b9c9:	48 89 c2             	mov    %rax,%rdx
    b9cc:	4c 39 20             	cmp    %r12,(%rax)
    b9cf:	75 ef                	jne    b9c0 <fwp_main_thread+0x21a0>
    b9d1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b9d5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b9d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b9dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b9e4:	0f 85 96 f6 ff ff    	jne    b080 <fwp_main_thread+0x1860>
    b9ea:	4c 89 e7             	mov    %r12,%rdi
    b9ed:	e8 de 9d ff ff       	call   57d0 <fwp_rc_forget_slot>
    b9f2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b9f7:	e9 84 f6 ff ff       	jmp    b080 <fwp_main_thread+0x1860>
    b9fc:	4c 8b 34 24          	mov    (%rsp),%r14
    ba00:	31 db                	xor    %ebx,%ebx
    ba02:	e9 d4 f5 ff ff       	jmp    afdb <fwp_main_thread+0x17bb>
    ba07:	e8 a4 9c ff ff       	call   56b0 <fwp_rc_wide_dup>
    ba0c:	e9 3d ea ff ff       	jmp    a44e <fwp_main_thread+0xc2e>
    ba11:	48 89 d8             	mov    %rbx,%rax
    ba14:	48 c1 e8 11          	shr    $0x11,%rax
    ba18:	48 31 d8             	xor    %rbx,%rax
    ba1b:	48 89 c2             	mov    %rax,%rdx
    ba1e:	48 c1 ea 09          	shr    $0x9,%rdx
    ba22:	48 31 d0             	xor    %rdx,%rax
    ba25:	0f b6 d0             	movzbl %al,%edx
    ba28:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    ba2f:	00 
    ba30:	48 85 c0             	test   %rax,%rax
    ba33:	75 54                	jne    ba89 <fwp_main_thread+0x2269>
    ba35:	48 8d 3d b4 0f 00 00 	lea    0xfb4(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    ba3c:	e8 0f 8a ff ff       	call   4450 <fwp_trap>
    ba41:	48 8d 3d ca 06 00 00 	lea    0x6ca(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    ba48:	e8 b3 85 ff ff       	call   4000 <ad_raw_fail>
    ba4d:	e8 5e 9c ff ff       	call   56b0 <fwp_rc_wide_dup>
    ba52:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ba59:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ba60:	48 c1 e2 10          	shl    $0x10,%rdx
    ba64:	e9 2c e9 ff ff       	jmp    a395 <fwp_main_thread+0xb75>
    ba69:	90                   	nop
    ba6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba71:	00 00 00 00 
    ba75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba7c:	00 00 00 00 
    ba80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    ba84:	48 85 c0             	test   %rax,%rax
    ba87:	74 ac                	je     ba35 <fwp_main_thread+0x2215>
    ba89:	48 89 c2             	mov    %rax,%rdx
    ba8c:	48 3b 18             	cmp    (%rax),%rbx
    ba8f:	75 ef                	jne    ba80 <fwp_main_thread+0x2260>
    ba91:	48 8b 78 08          	mov    0x8(%rax),%rdi
    ba95:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    ba99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    ba9d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    baa4:	0f 85 96 f7 ff ff    	jne    b240 <fwp_main_thread+0x1a20>
    baaa:	48 89 df             	mov    %rbx,%rdi
    baad:	e8 1e 9d ff ff       	call   57d0 <fwp_rc_forget_slot>
    bab2:	c6 03 fe             	movb   $0xfe,(%rbx)
    bab5:	e9 86 f7 ff ff       	jmp    b240 <fwp_main_thread+0x1a20>
    baba:	48 8d 3d 57 0f 00 00 	lea    0xf57(%rip),%rdi        # ca18 <_IO_stdin_used+0xa18>
    bac1:	e8 8a 89 ff ff       	call   4450 <fwp_trap>
    bac6:	48 8d 3d f5 06 00 00 	lea    0x6f5(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    bacd:	e8 7e 89 ff ff       	call   4450 <fwp_trap>
    bad2:	4c 89 e7             	mov    %r12,%rdi
    bad5:	e8 f6 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bada:	e9 e4 e7 ff ff       	jmp    a2c3 <fwp_main_thread+0xaa3>
    badf:	4c 89 e7             	mov    %r12,%rdi
    bae2:	e8 e9 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bae7:	e9 90 e6 ff ff       	jmp    a17c <fwp_main_thread+0x95c>
    baec:	4c 89 e7             	mov    %r12,%rdi
    baef:	e8 dc 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    baf4:	e9 22 e7 ff ff       	jmp    a21b <fwp_main_thread+0x9fb>
    baf9:	e8 02 7c ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    bafe:	48 8d 3d 13 10 00 00 	lea    0x1013(%rip),%rdi        # cb18 <_IO_stdin_used+0xb18>
    bb05:	e8 46 89 ff ff       	call   4450 <fwp_trap>
    bb0a:	48 8d 3d 86 07 00 00 	lea    0x786(%rip),%rdi        # c297 <_IO_stdin_used+0x297>
    bb11:	e8 3a 89 ff ff       	call   4450 <fwp_trap>
    bb16:	48 8d 3d ce 06 00 00 	lea    0x6ce(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    bb1d:	e8 2e 89 ff ff       	call   4450 <fwp_trap>
    bb22:	48 8d 3d a4 07 00 00 	lea    0x7a4(%rip),%rdi        # c2cd <_IO_stdin_used+0x2cd>
    bb29:	e8 22 89 ff ff       	call   4450 <fwp_trap>
    bb2e:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    bb35:	00 
    bb36:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    bb3b:	48 89 05 76 e9 05 00 	mov    %rax,0x5e976(%rip)        # 6a4b8 <fwp_cleanups>
    bb42:	e8 19 97 ff ff       	call   5260 <fwp_tape_buffers_release>
    bb47:	48 8b 0d f2 44 00 00 	mov    0x44f2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    bb4e:	ba 13 00 00 00       	mov    $0x13,%edx
    bb53:	be 01 00 00 00       	mov    $0x1,%esi
    bb58:	48 8d 3d a9 04 00 00 	lea    0x4a9(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    bb5f:	e8 fc 7a ff ff       	call   3660 <fwrite@plt>
    bb64:	31 ff                	xor    %edi,%edi
    bb66:	e8 35 7a ff ff       	call   35a0 <fflush@plt>
    bb6b:	bf 66 00 00 00       	mov    $0x66,%edi
    bb70:	e8 0b 7b ff ff       	call   3680 <_Exit@plt>
    bb75:	48 8d 3d 44 0f 00 00 	lea    0xf44(%rip),%rdi        # cac0 <_IO_stdin_used+0xac0>
    bb7c:	e8 cf 88 ff ff       	call   4450 <fwp_trap>
    bb81:	e8 ca 78 ff ff       	call   3450 <__stack_chk_fail@plt>
    bb86:	48 8d 3d 5b 0f 00 00 	lea    0xf5b(%rip),%rdi        # cae8 <_IO_stdin_used+0xae8>
    bb8d:	e8 be 88 ff ff       	call   4450 <fwp_trap>
    bb92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bb98:	48 8d 3d 11 10 00 00 	lea    0x1011(%rip),%rdi        # cbb0 <_IO_stdin_used+0xbb0>
    bb9f:	e8 ac 88 ff ff       	call   4450 <fwp_trap>
    bba4:	48 8d 3d d1 06 00 00 	lea    0x6d1(%rip),%rdi        # c27c <_IO_stdin_used+0x27c>
    bbab:	e8 50 84 ff ff       	call   4000 <ad_raw_fail>
    bbb0:	48 8d 3d fa 06 00 00 	lea    0x6fa(%rip),%rdi        # c2b1 <_IO_stdin_used+0x2b1>
    bbb7:	e8 44 84 ff ff       	call   4000 <ad_raw_fail>
    bbbc:	48 8d 3d 1a 07 00 00 	lea    0x71a(%rip),%rdi        # c2dd <_IO_stdin_used+0x2dd>
    bbc3:	e8 88 88 ff ff       	call   4450 <fwp_trap>
    bbc8:	48 8d 3d 91 0e 00 00 	lea    0xe91(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    bbcf:	e8 7c 88 ff ff       	call   4450 <fwp_trap>
    bbd4:	e9 72 7b ff ff       	jmp    374b <fwp_main_thread.cold>
    bbd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000bbe0 <__divmodti4>:
    bbe0:	f3 0f 1e fa          	endbr64
    bbe4:	55                   	push   %rbp
    bbe5:	49 89 f1             	mov    %rsi,%r9
    bbe8:	49 89 d2             	mov    %rdx,%r10
    bbeb:	48 89 fe             	mov    %rdi,%rsi
    bbee:	49 89 cb             	mov    %rcx,%r11
    bbf1:	48 89 e5             	mov    %rsp,%rbp
    bbf4:	41 57                	push   %r15
    bbf6:	41 56                	push   %r14
    bbf8:	41 55                	push   %r13
    bbfa:	41 54                	push   %r12
    bbfc:	53                   	push   %rbx
    bbfd:	4c 89 c3             	mov    %r8,%rbx
    bc00:	45 31 c0             	xor    %r8d,%r8d
    bc03:	4d 85 c9             	test   %r9,%r9
    bc06:	79 12                	jns    bc1a <__divmodti4+0x3a>
    bc08:	31 ff                	xor    %edi,%edi
    bc0a:	48 f7 de             	neg    %rsi
    bc0d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bc14:	4c 19 cf             	sbb    %r9,%rdi
    bc17:	49 89 f9             	mov    %rdi,%r9
    bc1a:	4c 89 d8             	mov    %r11,%rax
    bc1d:	4d 85 db             	test   %r11,%r11
    bc20:	0f 88 1a 01 00 00    	js     bd40 <__divmodti4+0x160>
    bc26:	4c 89 d9             	mov    %r11,%rcx
    bc29:	49 89 f3             	mov    %rsi,%r11
    bc2c:	75 62                	jne    bc90 <__divmodti4+0xb0>
    bc2e:	4d 89 c4             	mov    %r8,%r12
    bc31:	4d 39 d1             	cmp    %r10,%r9
    bc34:	0f 83 46 01 00 00    	jae    bd80 <__divmodti4+0x1a0>
    bc3a:	4c 89 d8             	mov    %r11,%rax
    bc3d:	4c 89 ca             	mov    %r9,%rdx
    bc40:	49 f7 f2             	div    %r10
    bc43:	49 89 c3             	mov    %rax,%r11
    bc46:	31 c0                	xor    %eax,%eax
    bc48:	48 89 d6             	mov    %rdx,%rsi
    bc4b:	31 ff                	xor    %edi,%edi
    bc4d:	4c 89 d9             	mov    %r11,%rcx
    bc50:	48 89 c2             	mov    %rax,%rdx
    bc53:	48 89 c8             	mov    %rcx,%rax
    bc56:	4d 85 e4             	test   %r12,%r12
    bc59:	74 0a                	je     bc65 <__divmodti4+0x85>
    bc5b:	48 f7 d8             	neg    %rax
    bc5e:	48 83 d2 00          	adc    $0x0,%rdx
    bc62:	48 f7 da             	neg    %rdx
    bc65:	4d 85 c0             	test   %r8,%r8
    bc68:	74 0a                	je     bc74 <__divmodti4+0x94>
    bc6a:	48 f7 de             	neg    %rsi
    bc6d:	48 83 d7 00          	adc    $0x0,%rdi
    bc71:	48 f7 df             	neg    %rdi
    bc74:	48 89 33             	mov    %rsi,(%rbx)
    bc77:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bc7b:	5b                   	pop    %rbx
    bc7c:	41 5c                	pop    %r12
    bc7e:	41 5d                	pop    %r13
    bc80:	41 5e                	pop    %r14
    bc82:	41 5f                	pop    %r15
    bc84:	5d                   	pop    %rbp
    bc85:	c3                   	ret
    bc86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bc8d:	00 00 00 
    bc90:	4d 89 c4             	mov    %r8,%r12
    bc93:	49 39 c1             	cmp    %rax,%r9
    bc96:	0f 82 ce 00 00 00    	jb     bd6a <__divmodti4+0x18a>
    bc9c:	31 ff                	xor    %edi,%edi
    bc9e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bca3:	48 63 c7             	movslq %edi,%rax
    bca6:	be 40 00 00 00       	mov    $0x40,%esi
    bcab:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bcb0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bcb5:	48 29 c6             	sub    %rax,%rsi
    bcb8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bcbd:	48 09 c8             	or     %rcx,%rax
    bcc0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bcc5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bcca:	49 89 c6             	mov    %rax,%r14
    bccd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bcd1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bcd6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bcdb:	49 09 c1             	or     %rax,%r9
    bcde:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bce2:	4c 89 c8             	mov    %r9,%rax
    bce5:	49 f7 f6             	div    %r14
    bce8:	48 89 d1             	mov    %rdx,%rcx
    bceb:	49 89 c3             	mov    %rax,%r11
    bcee:	49 89 c1             	mov    %rax,%r9
    bcf1:	49 f7 e2             	mul    %r10
    bcf4:	49 89 c6             	mov    %rax,%r14
    bcf7:	49 89 d2             	mov    %rdx,%r10
    bcfa:	48 39 d1             	cmp    %rdx,%rcx
    bcfd:	72 07                	jb     bd06 <__divmodti4+0x126>
    bcff:	75 17                	jne    bd18 <__divmodti4+0x138>
    bd01:	49 39 c7             	cmp    %rax,%r15
    bd04:	73 12                	jae    bd18 <__divmodti4+0x138>
    bd06:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bd0a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bd0e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bd12:	49 89 d2             	mov    %rdx,%r10
    bd15:	49 89 c6             	mov    %rax,%r14
    bd18:	4c 89 f8             	mov    %r15,%rax
    bd1b:	4c 29 f0             	sub    %r14,%rax
    bd1e:	4c 19 d1             	sbb    %r10,%rcx
    bd21:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bd26:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bd2b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bd30:	48 09 c6             	or     %rax,%rsi
    bd33:	48 89 cf             	mov    %rcx,%rdi
    bd36:	31 c0                	xor    %eax,%eax
    bd38:	4c 89 c9             	mov    %r9,%rcx
    bd3b:	e9 10 ff ff ff       	jmp    bc50 <__divmodti4+0x70>
    bd40:	4c 89 d0             	mov    %r10,%rax
    bd43:	4c 89 da             	mov    %r11,%rdx
    bd46:	4d 89 c4             	mov    %r8,%r12
    bd49:	49 89 f3             	mov    %rsi,%r11
    bd4c:	48 f7 d8             	neg    %rax
    bd4f:	49 f7 d4             	not    %r12
    bd52:	48 83 d2 00          	adc    $0x0,%rdx
    bd56:	49 89 c2             	mov    %rax,%r10
    bd59:	48 f7 da             	neg    %rdx
    bd5c:	48 89 d1             	mov    %rdx,%rcx
    bd5f:	0f 84 cc fe ff ff    	je     bc31 <__divmodti4+0x51>
    bd65:	49 39 d1             	cmp    %rdx,%r9
    bd68:	73 46                	jae    bdb0 <__divmodti4+0x1d0>
    bd6a:	4c 89 cf             	mov    %r9,%rdi
    bd6d:	31 c0                	xor    %eax,%eax
    bd6f:	31 c9                	xor    %ecx,%ecx
    bd71:	e9 da fe ff ff       	jmp    bc50 <__divmodti4+0x70>
    bd76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bd7d:	00 00 00 
    bd80:	4d 85 d2             	test   %r10,%r10
    bd83:	75 0d                	jne    bd92 <__divmodti4+0x1b2>
    bd85:	b8 01 00 00 00       	mov    $0x1,%eax
    bd8a:	31 d2                	xor    %edx,%edx
    bd8c:	49 f7 f2             	div    %r10
    bd8f:	49 89 c2             	mov    %rax,%r10
    bd92:	4c 89 c8             	mov    %r9,%rax
    bd95:	31 d2                	xor    %edx,%edx
    bd97:	49 f7 f2             	div    %r10
    bd9a:	49 89 c1             	mov    %rax,%r9
    bd9d:	4c 89 d8             	mov    %r11,%rax
    bda0:	49 f7 f2             	div    %r10
    bda3:	49 89 c3             	mov    %rax,%r11
    bda6:	4c 89 c8             	mov    %r9,%rax
    bda9:	e9 9a fe ff ff       	jmp    bc48 <__divmodti4+0x68>
    bdae:	66 90                	xchg   %ax,%ax
    bdb0:	45 31 f6             	xor    %r14d,%r14d
    bdb3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bdb8:	44 89 f7             	mov    %r14d,%edi
    bdbb:	45 85 f6             	test   %r14d,%r14d
    bdbe:	0f 85 df fe ff ff    	jne    bca3 <__divmodti4+0xc3>
    bdc4:	4c 39 ca             	cmp    %r9,%rdx
    bdc7:	72 17                	jb     bde0 <__divmodti4+0x200>
    bdc9:	31 c9                	xor    %ecx,%ecx
    bdcb:	48 39 c6             	cmp    %rax,%rsi
    bdce:	73 10                	jae    bde0 <__divmodti4+0x200>
    bdd0:	4c 89 cf             	mov    %r9,%rdi
    bdd3:	31 c0                	xor    %eax,%eax
    bdd5:	e9 76 fe ff ff       	jmp    bc50 <__divmodti4+0x70>
    bdda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bde0:	4c 89 de             	mov    %r11,%rsi
    bde3:	b9 01 00 00 00       	mov    $0x1,%ecx
    bde8:	48 29 c6             	sub    %rax,%rsi
    bdeb:	49 19 d1             	sbb    %rdx,%r9
    bdee:	eb e0                	jmp    bdd0 <__divmodti4+0x1f0>

000000000000bdf0 <atexit>:
    bdf0:	f3 0f 1e fa          	endbr64
    bdf4:	48 8b 15 0d 42 00 00 	mov    0x420d(%rip),%rdx        # 10008 <__dso_handle>
    bdfb:	31 f6                	xor    %esi,%esi
    bdfd:	e9 3e 78 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000be04 <_fini>:
    be04:	f3 0f 1e fa          	endbr64
    be08:	48 83 ec 08          	sub    $0x8,%rsp
    be0c:	48 83 c4 08          	add    $0x8,%rsp
    be10:	c3                   	ret
