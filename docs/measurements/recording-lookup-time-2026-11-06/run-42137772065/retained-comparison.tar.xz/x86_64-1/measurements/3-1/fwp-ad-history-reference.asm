
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 df 00 00 	mov    0xdfc9(%rip),%rax        # 10fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 dd 00 00    	push   0xdde2(%rip)        # 10e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 dd 00 00    	jmp    *0xdde4(%rip)        # 10e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e dc 00 00    	jmp    *0xdc4e(%rip)        # 10fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e da 00 00    	jmp    *0xda6e(%rip)        # 10e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 da 00 00    	jmp    *0xda66(%rip)        # 10e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e da 00 00    	jmp    *0xda5e(%rip)        # 10e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 da 00 00    	jmp    *0xda56(%rip)        # 10e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e da 00 00    	jmp    *0xda4e(%rip)        # 10e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 da 00 00    	jmp    *0xda46(%rip)        # 10e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e da 00 00    	jmp    *0xda3e(%rip)        # 10e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 da 00 00    	jmp    *0xda36(%rip)        # 10e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e da 00 00    	jmp    *0xda2e(%rip)        # 10e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 da 00 00    	jmp    *0xda26(%rip)        # 10e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e da 00 00    	jmp    *0xda1e(%rip)        # 10e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 da 00 00    	jmp    *0xda16(%rip)        # 10e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e da 00 00    	jmp    *0xda0e(%rip)        # 10e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 da 00 00    	jmp    *0xda06(%rip)        # 10e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe d9 00 00    	jmp    *0xd9fe(%rip)        # 10e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 d9 00 00    	jmp    *0xd9f6(%rip)        # 10e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee d9 00 00    	jmp    *0xd9ee(%rip)        # 10e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 d9 00 00    	jmp    *0xd9e6(%rip)        # 10ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de d9 00 00    	jmp    *0xd9de(%rip)        # 10ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 d9 00 00    	jmp    *0xd9d6(%rip)        # 10eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce d9 00 00    	jmp    *0xd9ce(%rip)        # 10eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 d9 00 00    	jmp    *0xd9c6(%rip)        # 10ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be d9 00 00    	jmp    *0xd9be(%rip)        # 10ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 d9 00 00    	jmp    *0xd9b6(%rip)        # 10ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae d9 00 00    	jmp    *0xd9ae(%rip)        # 10ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 d9 00 00    	jmp    *0xd9a6(%rip)        # 10ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e d9 00 00    	jmp    *0xd99e(%rip)        # 10ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 d9 00 00    	jmp    *0xd996(%rip)        # 10ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e d9 00 00    	jmp    *0xd98e(%rip)        # 10ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 d9 00 00    	jmp    *0xd986(%rip)        # 10f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e d9 00 00    	jmp    *0xd97e(%rip)        # 10f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 d9 00 00    	jmp    *0xd976(%rip)        # 10f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e d9 00 00    	jmp    *0xd96e(%rip)        # 10f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 d9 00 00    	jmp    *0xd966(%rip)        # 10f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e d9 00 00    	jmp    *0xd95e(%rip)        # 10f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 d9 00 00    	jmp    *0xd956(%rip)        # 10f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e d9 00 00    	jmp    *0xd94e(%rip)        # 10f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 d9 00 00    	jmp    *0xd946(%rip)        # 10f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e d9 00 00    	jmp    *0xd93e(%rip)        # 10f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 d9 00 00    	jmp    *0xd936(%rip)        # 10f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e d9 00 00    	jmp    *0xd92e(%rip)        # 10f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 d9 00 00    	jmp    *0xd926(%rip)        # 10f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e d9 00 00    	jmp    *0xd91e(%rip)        # 10f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 d9 00 00    	jmp    *0xd916(%rip)        # 10f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e d9 00 00    	jmp    *0xd90e(%rip)        # 10f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 d9 00 00    	jmp    *0xd906(%rip)        # 10f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe d8 00 00    	jmp    *0xd8fe(%rip)        # 10f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 d8 00 00    	jmp    *0xd8f6(%rip)        # 10f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee d8 00 00    	jmp    *0xd8ee(%rip)        # 10f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 d8 00 00    	jmp    *0xd8e6(%rip)        # 10fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de d8 00 00    	jmp    *0xd8de(%rip)        # 10fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 d8 00 00    	jmp    *0xd8d6(%rip)        # 10fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce d8 00 00    	jmp    *0xd8ce(%rip)        # 10fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 d8 00 00    	jmp    *0xd8c6(%rip)        # 10fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 99 00 00 	lea    0x997a(%rip),%r9        # d091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 99 00 00 	lea    0x9977(%rip),%r8        # d095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 bd 00 00 	lea    0xbd01(%rip),%rax        # f480 <fwp_fn_table>
    377f:	48 89 05 52 fc 01 00 	mov    %rax,0x1fc52(%rip)        # 233d8 <fwp_fns>
    3786:	48 8b 05 b3 d8 00 00 	mov    0xd8b3(%rip),%rax        # 11040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 4c fc 01 00 	mov    %rax,0x1fc4c(%rip)        # 233e0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 9a 00 00 	lea    0x9a59(%rip),%rdi        # d1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 d8 00 00 	mov    0xd838(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ef 71 00 00 	lea    0x71ef(%rip),%rdx        # aa50 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 d7 00 00 	mov    0xd7a3(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 d7 01 00    	mov    0x1d7f8(%rip),%eax        # 210a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 99 00 00 	lea    0x9909(%rip),%rdi        # d202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e a0 00 00 	lea    0xa08e(%rip),%rdi        # d998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 a0 00 00 	lea    0xa048(%rip),%rdi        # d970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c a0 00 00 	lea    0xa00c(%rip),%rdi        # d940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 9f 00 00 	lea    0x9fd8(%rip),%rdi        # d918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 d6 00 00    	call   *0xd653(%rip)        # 10fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 d6 00 00 	lea    0xd6a1(%rip),%rdi        # 11028 <__TMC_END__>
    3987:	48 8d 05 9a d6 00 00 	lea    0xd69a(%rip),%rax        # 11028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 d6 00 00 	mov    0xd636(%rip),%rax        # 10fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 d6 00 00 	lea    0xd671(%rip),%rdi        # 11028 <__TMC_END__>
    39b7:	48 8d 35 6a d6 00 00 	lea    0xd66a(%rip),%rsi        # 11028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 d6 00 00 	mov    0xd605(%rip),%rax        # 10fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d d6 00 00 00 	cmpb   $0x0,0xd66d(%rip)        # 11068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 d5 00 00 	cmpq   $0x0,0xd5e2(%rip)        # 10fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 d5 00 00 	mov    0xd5f6(%rip),%rdi        # 11008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 d6 00 00 01 	movb   $0x1,0xd645(%rip)        # 11068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee d4 01 00 	add    0x1d4ee(%rip),%rdx        # 21110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc d4 01 00 	add    0x1d4dc(%rip),%rax        # 21110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 69 f7 01 00 	mov    0x1f769(%rip),%rdi        # 233e0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 d3 00 00 	mov    0xd3b4(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 d3 00 00 	mov    0xd3a1(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 93 00 00 	lea    0x9345(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 d3 00 00 	mov    0xd392(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 61 da 01 00 	mov    0x1da61(%rip),%rax        # 21760 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 a1 d3 01 00 	mov    0x1d3a1(%rip),%rax        # 21120 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 8d d3 01 00 	sub    0x1d38d(%rip),%rax        # 21118 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd 9c 00 00 	lea    0x9cbd(%rip),%rsi        # da80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 7b ed 01 00 	mov    0x1ed7b(%rip),%rax        # 22b70 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 74 ed 01 00 	lea    0x1ed74(%rip),%r8        # 22b70 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 55 ed 01 00 	mov    0x1ed55(%rip),%rbx        # 22b58 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 65 ed 01 00 	mov    0x1ed65(%rip),%rcx        # 22b78 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d 01 ed 01 00 	mov    0x1ed01(%rip),%rdi        # 22b60 <fwp_heap+0x13e0>
    3e5f:	48 29 35 4a ed 01 00 	sub    %rsi,0x1ed4a(%rip)        # 22bb0 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 da ec 01 00 	mov    0x1ecda(%rip),%rax        # 22b50 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 90 ec 01 00 	add    0x1ec90(%rip),%rdi        # 22b30 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 9e ec 01 00 	mov    0x1ec9e(%rip),%rsi        # 22b60 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 ac ec 01 00 	mov    0x1ecac(%rip),%rax        # 22b78 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 5b ec 01 00 	mov    %r12,0x1ec5b(%rip)        # 22b60 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 49 ec 01 00 	mov    %rbp,0x1ec49(%rip)        # 22b58 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 2e ec 01 00 	cmp    %rdi,0x1ec2e(%rip)        # 22b48 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 25 ec 01 00 	mov    %rdi,0x1ec25(%rip)        # 22b48 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 69 ec 01 00 	sub    %rdi,0x1ec69(%rip)        # 22bb0 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 11 ec 01 00 	mov    0x1ec11(%rip),%rax        # 22b68 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 0a ec 01 00 	lea    0x1ec0a(%rip),%r8        # 22b68 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d 1d d0 00 00 	mov    0xd01d(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 8f 00 00 	lea    0x8fb4(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d a9 d6 01 00 	cmp    0x1d6a9(%rip),%rdi        # 21760 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 6f d6 01 00 	mov    0x1d66f(%rip),%rax        # 21740 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 4d d6 01 00 	mov    %rdi,0x1d64d(%rip)        # 21740 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 29 d6 01 00 	mov    %rdi,0x1d629(%rip)        # 21748 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 90 00 00 	lea    0x9005(%rip),%rsi        # d166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 8e 00 00 	lea    0x8ea7(%rip),%rsi        # d01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 98 ce 00 00 	mov    0xce98(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 8e 00 00 	lea    0x8e51(%rip),%rdx        # d020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 80 ce 00 00 	mov    0xce80(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 91 cd 00 00 	mov    0xcd91(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 8d 00 00 	lea    0x8d28(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 8d 00 00 	lea    0x8d32(%rip),%rdi        # d02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 8c 00 00 	lea    0x8cba(%rip),%rdi        # d049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 92 00 00 	lea    0x9268(%rip),%rdi        # d608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 96 00 	movdqa 0x96e0(%rip),%xmm0        # daa0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 ba ef 01 00 	add    0x1efba(%rip),%rax        # 233d8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 91 00 00 	lea    0x91c4(%rip),%rdi        # d638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 75 cc 01 00 	cmp    %rax,0x1cc75(%rip)        # 21108 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 70 cc 01 00 	add    0x1cc70(%rip),%rax        # 21110 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad 91 00 00 	lea    0x91ad(%rip),%rdi        # d668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 8b 00 00 	lea    0x8b92(%rip),%r8        # d065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 89 00 00 	lea    0x89e7(%rip),%r8        # d074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 88 00 00 	lea    0x8874(%rip),%r8        # d06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 86 00 00 	lea    0x864c(%rip),%rdi        # d079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 87 00 00 	lea    0x8760(%rip),%rsi        # d1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 85 e0 01 00 	mov    0x1e085(%rip),%r9        # 22b48 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 de e0 01 00 	mov    0x1e0de(%rip),%r8        # 22ba8 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 8b 00 00 	lea    0x8be7(%rip),%rdx        # d6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d c6 e0 01 00 	mov    0x1e0c6(%rip),%rcx        # 22ba0 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d d4 e0 01 	movsd  0x1e0d4(%rip),%xmm1        # 22bc0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 c4 e0 01 	movsd  0x1e0c4(%rip),%xmm0        # 22bb8 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 65 c5 00 00 	mov    0xc565(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 8f 00 	movdqa 0x8f78(%rip),%xmm0        # dab0 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 7f db 01 00 	lea    0x1db7f(%rip),%rax        # 226c0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 8f 00 	movdqa 0x8fa1(%rip),%xmm2        # daf0 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 25 db 01 00 	movaps %xmm0,0x1db25(%rip)        # 22680 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d 8f 00 	movdqa 0x8f5d(%rip),%xmm0        # dac0 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 b3 df 01 00 01 	movl   $0x1,0x1dfb3(%rip)        # 22b24 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 13 db 01 00 	movaps %xmm0,0x1db13(%rip)        # 22690 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b 8f 00 	movdqa 0x8f4b(%rip),%xmm0        # dad0 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 14 db 01 00 	movaps %xmm0,0x1db14(%rip)        # 226a0 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c 8f 00 	movdqa 0x8f4c(%rip),%xmm0        # dae0 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 15 db 01 00 	movaps %xmm0,0x1db15(%rip)        # 226b0 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 95 cb 01 00 	lea    0x1cb95(%rip),%r8        # 21780 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 b0 de 01 00 	mov    %rax,0x1deb0(%rip)        # 22b38 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 8e de 01 00 	mov    %r12,0x1de8e(%rip)        # 22b40 <fwp_heap+0x13c0>
    4cb2:	48 89 05 77 de 01 00 	mov    %rax,0x1de77(%rip)        # 22b30 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 90 de 01 00 	mov    %rbx,0x1de90(%rip)        # 22b50 <fwp_heap+0x13d0>
    4cc0:	48 89 35 b9 de 01 00 	mov    %rsi,0x1deb9(%rip)        # 22b80 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 83 00 00 	lea    0x83d6(%rip),%rdi        # d0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 98 de 01 00 	mov    %rax,0x1de98(%rip)        # 22b78 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 1c de 01 00    	mov    %eax,0x1de1c(%rip)        # 22b28 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 0c ca 01 00 	mov    0x1ca0c(%rip),%r8        # 21740 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 3c c9 01 00 	mov    %rbx,0x1c93c(%rip)        # 21748 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 28 c9 01 00 	mov    %r8,0x1c928(%rip)        # 21740 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 82 00 00 	lea    0x8239(%rip),%rdi        # d0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d fd c1 01 00 	lea    0x1c1fd(%rip),%rdi        # 210c0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 e5 c1 01 00 	movaps %xmm0,0x1c1e5(%rip)        # 210c0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 c1 c1 01 00 	mov    %rax,0x1c1c1(%rip)        # 210a8 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 e2 c1 01 00 	movaps %xmm0,0x1c1e2(%rip)        # 210d0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 e6 c1 01 00 	movaps %xmm0,0x1c1e6(%rip)        # 210e0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 e7 c1 01 00 	mov    %rdx,0x1c1e7(%rip)        # 210f0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 81 00 00 	lea    0x8190(%rip),%rdi        # d0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d b7 c7 01 00 	mov    0x1c7b7(%rip),%rbx        # 21738 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ea bf 00 00 	mov    0xbfea(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d c3 86 00 00 	lea    0x86c3(%rip),%rdi        # d740 <_IO_stdin_used+0x740>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 8d c6 01 00 	mov    0x1c68d(%rip),%rax        # 21740 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 67 c6 01 00 	mov    %rdx,0x1c667(%rip)        # 21740 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d b4 c5 01 00 	mov    0x1c5b4(%rip),%rbx        # 21738 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 71 c5 01 00 	mov    %rbx,0x1c571(%rip)        # 21738 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 71 c5 01 00 	mov    %rdx,0x1c571(%rip)        # 21748 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 86 c5 01 00 	lea    0x1c586(%rip),%rsi        # 21780 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 05 e1 01 00 	addq   $0x1,0x1e105(%rip)        # 233c8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 97 84 00 00 	lea    0x8497(%rip),%rdi        # d770 <_IO_stdin_used+0x770>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d a8 84 00 00 	lea    0x84a8(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 7d 00 00 	lea    0x7dd4(%rip),%rdi        # d0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 3e c4 01 00 	lea    0x1c43e(%rip),%rcx        # 21780 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 3f e0 01 00 	subq   $0x1,0x1e03f(%rip)        # 233c8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 03 84 00 00 	lea    0x8403(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 20 e0 01 00 	cmpq   $0x0,0x1e020(%rip)        # 233c8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 75 df 01 00 	sub    %rax,0x1df75(%rip)        # 233d0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 53 df 01 00 	add    %r12,0x1df53(%rip)        # 233d0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 af d6 01 00 	mov    0x1d6af(%rip),%rax        # 22b78 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 ac c2 01 00 	lea    0x1c2ac(%rip),%rax        # 21780 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 03 d6 01 00 	add    0x1d603(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 d0 d5 01 00 	mov    0x1d5d0(%rip),%rsi        # 22b30 <fwp_heap+0x13b0>
    5560:	48 8b 05 f1 d5 01 00 	mov    0x1d5f1(%rip),%rax        # 22b58 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 e5 d5 01 00 	add    0x1d5e5(%rip),%r8        # 22b78 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 ad d5 01 	addsd  0x1d5ad(%rip),%xmm0        # 22bc0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 62 c1 01 00 	lea    0x1c162(%rip),%rax        # 21780 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 6c d5 01 00 	sub    %rdi,0x1d56c(%rip)        # 22ba0 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 84 d5 01 	movsd  %xmm0,0x1d584(%rip)        # 22bc0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 3e d5 01 00 	sub    %rdx,0x1d53e(%rip)        # 22ba0 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 44 d5 01 	addsd  0x1d544(%rip),%xmm0        # 22bc0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 38 d5 01 	movsd  %xmm0,0x1d538(%rip)        # 22bc0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 cf d4 01 00 	mov    0x1d4cf(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d c9 d4 01 00 	add    %rcx,0x1d4c9(%rip)        # 22bb0 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 82 d4 01 00 	cmp    0x1d482(%rip),%r9        # 22b70 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 79 d4 01 00 	mov    %r9,0x1d479(%rip)        # 22b70 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 6a d4 01 00 	cmp    0x1d46a(%rip),%r9        # 22b68 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 5d d4 01 00 	mov    %r9,0x1d45d(%rip)        # 22b68 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 73 d3 01 00 	add    0x1d373(%rip),%rdi        # 22b78 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 50 bf 01 00 	lea    0x1bf50(%rip),%r15        # 21780 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 c0 d2 01 00 	add    0x1d2c0(%rip),%r12        # 22b30 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 19 d3 01 00 	add    0x1d319(%rip),%rax        # 22ba0 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 18 d3 01 00 	cmp    %rax,0x1d318(%rip)        # 22ba8 <fwp_heap+0x1428>
    5890:	48 89 05 09 d3 01 00 	mov    %rax,0x1d309(%rip)        # 22ba0 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 08 d3 01 00 	mov    %rax,0x1d308(%rip)        # 22ba8 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 04 d3 01 	addsd  0x1d304(%rip),%xmm0        # 22bb8 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 fc d2 01 	movsd  %xmm0,0x1d2fc(%rip)        # 22bb8 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 43 d2 01 00    	mov    0x1d243(%rip),%eax        # 22b24 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 7f be 01 00 	lea    0x1be7f(%rip),%rdi        # 21780 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 38 d2 01 00 	add    0x1d238(%rip),%rax        # 22ba0 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 33 d2 01 00 	cmp    %rax,0x1d233(%rip)        # 22ba8 <fwp_heap+0x1428>
    5975:	48 89 05 24 d2 01 00 	mov    %rax,0x1d224(%rip)        # 22ba0 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 23 d2 01 00 	mov    %rax,0x1d223(%rip)        # 22ba8 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 1f d2 01 	addsd  0x1d21f(%rip),%xmm0        # 22bb8 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 17 d2 01 	movsd  %xmm0,0x1d217(%rip)        # 22bb8 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ce d0 01 00    	mov    0x1d0ce(%rip),%eax        # 22b24 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 05 bd 01 00 	lea    0x1bd05(%rip),%rax        # 21780 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 bb d0 01 00 	add    0x1d0bb(%rip),%rax        # 22ba0 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 ba d0 01 00 	cmp    %rax,0x1d0ba(%rip)        # 22ba8 <fwp_heap+0x1428>
    5aee:	48 89 05 ab d0 01 00 	mov    %rax,0x1d0ab(%rip)        # 22ba0 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 aa d0 01 00 	mov    %rax,0x1d0aa(%rip)        # 22ba8 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 a6 d0 01 	addsd  0x1d0a6(%rip),%xmm0        # 22bb8 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 9e d0 01 	movsd  %xmm0,0x1d09e(%rip)        # 22bb8 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_apply>:
    5b70:	55                   	push   %rbp
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	48 89 e5             	mov    %rsp,%rbp
    5b77:	41 57                	push   %r15
    5b79:	41 56                	push   %r14
    5b7b:	41 55                	push   %r13
    5b7d:	41 89 f5             	mov    %esi,%r13d
    5b80:	41 54                	push   %r12
    5b82:	53                   	push   %rbx
    5b83:	48 83 ec 28          	sub    $0x28,%rsp
    5b87:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5b8e:	00 00 
    5b90:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5b94:	49 89 d6             	mov    %rdx,%r14
    5b97:	44 8b 09             	mov    (%rcx),%r9d
    5b9a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5b9e:	49 89 e0             	mov    %rsp,%r8
    5ba1:	49 c1 e1 05          	shl    $0x5,%r9
    5ba5:	4c 03 0d 2c d8 01 00 	add    0x1d82c(%rip),%r9        # 233d8 <fwp_fns>
    5bac:	41 8b 19             	mov    (%r9),%ebx
    5baf:	45 85 e4             	test   %r12d,%r12d
    5bb2:	75 2c                	jne    5be0 <fwp_apply+0x70>
    5bb4:	41 39 dd             	cmp    %ebx,%r13d
    5bb7:	72 27                	jb     5be0 <fwp_apply+0x70>
    5bb9:	85 db                	test   %ebx,%ebx
    5bbb:	0f 84 a7 01 00 00    	je     5d68 <fwp_apply+0x1f8>
    5bc1:	4c 89 f7             	mov    %r14,%rdi
    5bc4:	41 ff 51 08          	call   *0x8(%r9)
    5bc8:	48 89 c1             	mov    %rax,%rcx
    5bcb:	41 39 dd             	cmp    %ebx,%r13d
    5bce:	0f 84 6c 01 00 00    	je     5d40 <fwp_apply+0x1d0>
    5bd4:	89 d8                	mov    %ebx,%eax
    5bd6:	41 29 dd             	sub    %ebx,%r13d
    5bd9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5bdd:	eb b8                	jmp    5b97 <fwp_apply+0x27>
    5bdf:	90                   	nop
    5be0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5be5:	41 39 df             	cmp    %ebx,%r15d
    5be8:	0f 82 cc 00 00 00    	jb     5cba <fwp_apply+0x14a>
    5bee:	41 89 df             	mov    %ebx,%r15d
    5bf1:	b8 01 00 00 00       	mov    $0x1,%eax
    5bf6:	48 89 e2             	mov    %rsp,%rdx
    5bf9:	45 29 e7             	sub    %r12d,%r15d
    5bfc:	85 db                	test   %ebx,%ebx
    5bfe:	0f 45 c3             	cmovne %ebx,%eax
    5c01:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c08:	00 
    5c09:	48 c1 e8 04          	shr    $0x4,%rax
    5c0d:	48 c1 e0 04          	shl    $0x4,%rax
    5c11:	48 89 c6             	mov    %rax,%rsi
    5c14:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c1b:	48 29 f2             	sub    %rsi,%rdx
    5c1e:	48 39 d4             	cmp    %rdx,%rsp
    5c21:	74 15                	je     5c38 <fwp_apply+0xc8>
    5c23:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c2a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c31:	00 00 
    5c33:	48 39 d4             	cmp    %rdx,%rsp
    5c36:	75 eb                	jne    5c23 <fwp_apply+0xb3>
    5c38:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c3d:	48 29 c4             	sub    %rax,%rsp
    5c40:	48 85 c0             	test   %rax,%rax
    5c43:	0f 85 49 01 00 00    	jne    5d92 <fwp_apply+0x222>
    5c49:	45 89 e2             	mov    %r12d,%r10d
    5c4c:	48 89 e6             	mov    %rsp,%rsi
    5c4f:	48 89 e7             	mov    %rsp,%rdi
    5c52:	31 c0                	xor    %eax,%eax
    5c54:	49 c1 e2 03          	shl    $0x3,%r10
    5c58:	45 85 e4             	test   %r12d,%r12d
    5c5b:	74 15                	je     5c72 <fwp_apply+0x102>
    5c5d:	0f 1f 00             	nopl   (%rax)
    5c60:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5c65:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5c69:	48 83 c0 08          	add    $0x8,%rax
    5c6d:	4c 39 d0             	cmp    %r10,%rax
    5c70:	75 ee                	jne    5c60 <fwp_apply+0xf0>
    5c72:	45 85 ff             	test   %r15d,%r15d
    5c75:	0f 84 f4 00 00 00    	je     5d6f <fwp_apply+0x1ff>
    5c7b:	44 89 fa             	mov    %r15d,%edx
    5c7e:	4c 89 f0             	mov    %r14,%rax
    5c81:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5c85:	44 89 e2             	mov    %r12d,%edx
    5c88:	66 90                	xchg   %ax,%ax
    5c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c91:	00 00 00 00 
    5c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c9c:	00 00 00 00 
    5ca0:	4c 8b 10             	mov    (%rax),%r10
    5ca3:	89 d1                	mov    %edx,%ecx
    5ca5:	48 83 c0 08          	add    $0x8,%rax
    5ca9:	83 c2 01             	add    $0x1,%edx
    5cac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5cb0:	4c 39 d8             	cmp    %r11,%rax
    5cb3:	75 eb                	jne    5ca0 <fwp_apply+0x130>
    5cb5:	e9 b5 00 00 00       	jmp    5d6f <fwp_apply+0x1ff>
    5cba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5cbe:	be 02 00 00 00       	mov    $0x2,%esi
    5cc3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5cc7:	48 c1 e7 03          	shl    $0x3,%rdi
    5ccb:	e8 80 fd ff ff       	call   5a50 <fwp_heap_alloc>
    5cd0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5cd4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5cd9:	48 89 c3             	mov    %rax,%rbx
    5cdc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5ce0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ce4:	66 0f d6 00          	movq   %xmm0,(%rax)
    5ce8:	45 85 e4             	test   %r12d,%r12d
    5ceb:	74 14                	je     5d01 <fwp_apply+0x191>
    5ced:	44 89 e2             	mov    %r12d,%edx
    5cf0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5cf4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5cf8:	48 c1 e2 03          	shl    $0x3,%rdx
    5cfc:	e8 0f d9 ff ff       	call   3610 <memmove@plt>
    5d01:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d05:	45 85 ed             	test   %r13d,%r13d
    5d08:	74 2e                	je     5d38 <fwp_apply+0x1c8>
    5d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d11:	00 00 00 00 
    5d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d1c:	00 00 00 00 
    5d20:	49 8b 16             	mov    (%r14),%rdx
    5d23:	44 89 e0             	mov    %r12d,%eax
    5d26:	49 83 c6 08          	add    $0x8,%r14
    5d2a:	41 83 c4 01          	add    $0x1,%r12d
    5d2e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d33:	49 39 ce             	cmp    %rcx,%r14
    5d36:	75 e8                	jne    5d20 <fwp_apply+0x1b0>
    5d38:	48 89 d9             	mov    %rbx,%rcx
    5d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d40:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5d44:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d4b:	00 00 
    5d4d:	75 4e                	jne    5d9d <fwp_apply+0x22d>
    5d4f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5d53:	48 89 c8             	mov    %rcx,%rax
    5d56:	5b                   	pop    %rbx
    5d57:	41 5c                	pop    %r12
    5d59:	41 5d                	pop    %r13
    5d5b:	41 5e                	pop    %r14
    5d5d:	41 5f                	pop    %r15
    5d5f:	5d                   	pop    %rbp
    5d60:	c3                   	ret
    5d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d68:	45 31 ff             	xor    %r15d,%r15d
    5d6b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5d6f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5d73:	41 ff 51 08          	call   *0x8(%r9)
    5d77:	48 89 c1             	mov    %rax,%rcx
    5d7a:	45 39 fd             	cmp    %r15d,%r13d
    5d7d:	74 c1                	je     5d40 <fwp_apply+0x1d0>
    5d7f:	45 01 e5             	add    %r12d,%r13d
    5d82:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5d86:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5d8a:	41 29 dd             	sub    %ebx,%r13d
    5d8d:	e9 05 fe ff ff       	jmp    5b97 <fwp_apply+0x27>
    5d92:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5d98:	e9 ac fe ff ff       	jmp    5c49 <fwp_apply+0xd9>
    5d9d:	e8 be d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5da2:	0f 1f 00             	nopl   (%rax)
    5da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dac:	00 00 00 00 

0000000000005db0 <fwp_p_ad_push.constprop.0>:
    5db0:	41 57                	push   %r15
    5db2:	41 56                	push   %r14
    5db4:	41 55                	push   %r13
    5db6:	49 89 d5             	mov    %rdx,%r13
    5db9:	41 54                	push   %r12
    5dbb:	49 89 fc             	mov    %rdi,%r12
    5dbe:	55                   	push   %rbp
    5dbf:	53                   	push   %rbx
    5dc0:	48 83 ec 38          	sub    $0x38,%rsp
    5dc4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5dc9:	48 85 ff             	test   %rdi,%rdi
    5dcc:	79 09                	jns    5dd7 <fwp_p_ad_push.constprop.0+0x27>
    5dce:	48 85 d2             	test   %rdx,%rdx
    5dd1:	0f 88 a9 01 00 00    	js     5f80 <fwp_p_ad_push.constprop.0+0x1d0>
    5dd7:	48 89 f8             	mov    %rdi,%rax
    5dda:	48 89 0c 24          	mov    %rcx,(%rsp)
    5dde:	48 09 d0             	or     %rdx,%rax
    5de1:	0f 89 79 01 00 00    	jns    5f60 <fwp_p_ad_push.constprop.0+0x1b0>
    5de7:	48 89 f8             	mov    %rdi,%rax
    5dea:	48 c1 f8 20          	sar    $0x20,%rax
    5dee:	48 85 ff             	test   %rdi,%rdi
    5df1:	79 24                	jns    5e17 <fwp_p_ad_push.constprop.0+0x67>
    5df3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5df8:	48 89 d0             	mov    %rdx,%rax
    5dfb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5e02:	00 
    5e03:	49 89 d4             	mov    %rdx,%r12
    5e06:	48 c1 f8 20          	sar    $0x20,%rax
    5e0a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5e11:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5e17:	48 89 c7             	mov    %rax,%rdi
    5e1a:	e8 61 e6 ff ff       	call   4480 <fwp_tape_of>
    5e1f:	48 89 c3             	mov    %rax,%rbx
    5e22:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5e27:	0f 85 f0 02 00 00    	jne    611d <fwp_p_ad_push.constprop.0+0x36d>
    5e2d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5e31:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5e38:	0f 8f 51 02 00 00    	jg     608f <fwp_p_ad_push.constprop.0+0x2df>
    5e3e:	44 89 e0             	mov    %r12d,%eax
    5e41:	49 39 c7             	cmp    %rax,%r15
    5e44:	0f 8e 51 02 00 00    	jle    609b <fwp_p_ad_push.constprop.0+0x2eb>
    5e4a:	4d 85 ed             	test   %r13,%r13
    5e4d:	78 0c                	js     5e5b <fwp_p_ad_push.constprop.0+0xab>
    5e4f:	44 89 e8             	mov    %r13d,%eax
    5e52:	49 39 c7             	cmp    %rax,%r15
    5e55:	0f 8e 40 02 00 00    	jle    609b <fwp_p_ad_push.constprop.0+0x2eb>
    5e5b:	4d 89 fe             	mov    %r15,%r14
    5e5e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5e62:	49 8d 46 01          	lea    0x1(%r14),%rax
    5e66:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5e6c:	0f 87 1d 02 00 00    	ja     608f <fwp_p_ad_push.constprop.0+0x2df>
    5e72:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5e76:	48 39 e8             	cmp    %rbp,%rax
    5e79:	0f 8e 31 01 00 00    	jle    5fb0 <fwp_p_ad_push.constprop.0+0x200>
    5e7f:	48 85 ed             	test   %rbp,%rbp
    5e82:	b9 40 00 00 00       	mov    $0x40,%ecx
    5e87:	48 0f 44 e9          	cmove  %rcx,%rbp
    5e8b:	48 39 e8             	cmp    %rbp,%rax
    5e8e:	7e 20                	jle    5eb0 <fwp_p_ad_push.constprop.0+0x100>
    5e90:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5e97:	0f 8f 03 01 00 00    	jg     5fa0 <fwp_p_ad_push.constprop.0+0x1f0>
    5e9d:	48 01 ed             	add    %rbp,%rbp
    5ea0:	48 39 e8             	cmp    %rbp,%rax
    5ea3:	7f eb                	jg     5e90 <fwp_p_ad_push.constprop.0+0xe0>
    5ea5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5eac:	00 00 00 00 
    5eb0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5eb7:	00 
    5eb8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5ebc:	48 89 c6             	mov    %rax,%rsi
    5ebf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5ec4:	e8 07 d7 ff ff       	call   35d0 <realloc@plt>
    5ec9:	48 85 c0             	test   %rax,%rax
    5ecc:	0f 84 d5 01 00 00    	je     60a7 <fwp_p_ad_push.constprop.0+0x2f7>
    5ed2:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5ed6:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5eda:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5ede:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5ee2:	48 89 e9             	mov    %rbp,%rcx
    5ee5:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5ee9:	48 c1 e1 04          	shl    $0x4,%rcx
    5eed:	48 89 ce             	mov    %rcx,%rsi
    5ef0:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5ef5:	e8 d6 d6 ff ff       	call   35d0 <realloc@plt>
    5efa:	48 85 c0             	test   %rax,%rax
    5efd:	0f 84 a4 01 00 00    	je     60a7 <fwp_p_ad_push.constprop.0+0x2f7>
    5f03:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5f07:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5f0c:	4d 85 f6             	test   %r14,%r14
    5f0f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5f13:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5f18:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5f1f:	00 
    5f20:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5f27:	00 
    5f28:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5f2c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5f33:	00 
    5f34:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5f38:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5f3c:	0f 85 e6 00 00 00    	jne    6028 <fwp_p_ad_push.constprop.0+0x278>
    5f42:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5f46:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5f4a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5f4e:	49 01 c8             	add    %rcx,%r8
    5f51:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5f55:	eb 79                	jmp    5fd0 <fwp_p_ad_push.constprop.0+0x220>
    5f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f5e:	00 00 
    5f60:	48 89 d0             	mov    %rdx,%rax
    5f63:	48 c1 ff 20          	sar    $0x20,%rdi
    5f67:	48 c1 f8 20          	sar    $0x20,%rax
    5f6b:	48 39 c7             	cmp    %rax,%rdi
    5f6e:	0f 84 a3 fe ff ff    	je     5e17 <fwp_p_ad_push.constprop.0+0x67>
    5f74:	48 8d 3d 45 78 00 00 	lea    0x7845(%rip),%rdi        # d7c0 <_IO_stdin_used+0x7c0>
    5f7b:	e8 20 e2 ff ff       	call   41a0 <fwp_trap>
    5f80:	48 83 c4 38          	add    $0x38,%rsp
    5f84:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f8b:	5b                   	pop    %rbx
    5f8c:	5d                   	pop    %rbp
    5f8d:	41 5c                	pop    %r12
    5f8f:	41 5d                	pop    %r13
    5f91:	41 5e                	pop    %r14
    5f93:	41 5f                	pop    %r15
    5f95:	c3                   	ret
    5f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5f9d:	00 00 00 
    5fa0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5fa5:	e9 06 ff ff ff       	jmp    5eb0 <fwp_p_ad_push.constprop.0+0x100>
    5faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5fb0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5fb4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5fb8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5fbf:	00 
    5fc0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5fc7:	00 
    5fc8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5fcc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5fd0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5fd6:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5fda:	4d 85 ed             	test   %r13,%r13
    5fdd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5fe2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5fe8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5fef:	4c 0f 48 e8          	cmovs  %rax,%r13
    5ff3:	49 8d 47 01          	lea    0x1(%r15),%rax
    5ff7:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5ffb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6001:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6005:	48 83 c4 38          	add    $0x38,%rsp
    6009:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6010:	ff ff ff 
    6013:	4c 21 e0             	and    %r12,%rax
    6016:	5b                   	pop    %rbx
    6017:	5d                   	pop    %rbp
    6018:	4c 09 f8             	or     %r15,%rax
    601b:	41 5c                	pop    %r12
    601d:	41 5d                	pop    %r13
    601f:	41 5e                	pop    %r14
    6021:	41 5f                	pop    %r15
    6023:	c3                   	ret
    6024:	0f 1f 40 00          	nopl   0x0(%rax)
    6028:	48 39 ca             	cmp    %rcx,%rdx
    602b:	49 89 d6             	mov    %rdx,%r14
    602e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    6033:	48 0f 43 ca          	cmovae %rdx,%rcx
    6037:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    603c:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6041:	48 29 d1             	sub    %rdx,%rcx
    6044:	4c 89 ca             	mov    %r9,%rdx
    6047:	e8 14 d5 ff ff       	call   3560 <__memmove_chk@plt>
    604c:	4c 03 73 30          	add    0x30(%rbx),%r14
    6050:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6055:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6059:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    605e:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6062:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6066:	4c 89 d2             	mov    %r10,%rdx
    6069:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    606e:	e8 9d d5 ff ff       	call   3610 <memmove@plt>
    6073:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6077:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    607b:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6080:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    6085:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    608a:	e9 b7 fe ff ff       	jmp    5f46 <fwp_p_ad_push.constprop.0+0x196>
    608f:	48 8d 3d 53 70 00 00 	lea    0x7053(%rip),%rdi        # d0e9 <_IO_stdin_used+0xe9>
    6096:	e8 05 e1 ff ff       	call   41a0 <fwp_trap>
    609b:	48 8d 3d 62 70 00 00 	lea    0x7062(%rip),%rdi        # d104 <_IO_stdin_used+0x104>
    60a2:	e8 f9 e0 ff ff       	call   41a0 <fwp_trap>
    60a7:	48 89 df             	mov    %rbx,%rdi
    60aa:	e8 51 db ff ff       	call   3c00 <fwp_tape_unlink_scope>
    60af:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    60b3:	e8 08 d3 ff ff       	call   33c0 <free@plt>
    60b8:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    60bc:	e8 ff d2 ff ff       	call   33c0 <free@plt>
    60c1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    60c5:	e8 f6 d2 ff ff       	call   33c0 <free@plt>
    60ca:	31 c9                	xor    %ecx,%ecx
    60cc:	31 c0                	xor    %eax,%eax
    60ce:	31 d2                	xor    %edx,%edx
    60d0:	89 53 04             	mov    %edx,0x4(%rbx)
    60d3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60d7:	ba 13 00 00 00       	mov    $0x13,%edx
    60dc:	be 01 00 00 00       	mov    $0x1,%esi
    60e1:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    60e5:	48 8d 3d 1c 6f 00 00 	lea    0x6f1c(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    60ec:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    60f0:	48 8b 0d 69 af 00 00 	mov    0xaf69(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    60f7:	48 89 43 40          	mov    %rax,0x40(%rbx)
    60fb:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    60ff:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6103:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6107:	e8 74 d5 ff ff       	call   3680 <fwrite@plt>
    610c:	31 ff                	xor    %edi,%edi
    610e:	e8 ad d4 ff ff       	call   35c0 <fflush@plt>
    6113:	bf 66 00 00 00       	mov    $0x66,%edi
    6118:	e8 83 d5 ff ff       	call   36a0 <_Exit@plt>
    611d:	48 8d 3d e4 76 00 00 	lea    0x76e4(%rip),%rdi        # d808 <_IO_stdin_used+0x808>
    6124:	e8 77 e0 ff ff       	call   41a0 <fwp_trap>
    6129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006130 <w107>:
    6130:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6134:	41 55                	push   %r13
    6136:	48 89 fa             	mov    %rdi,%rdx
    6139:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    613d:	41 54                	push   %r12
    613f:	49 89 fc             	mov    %rdi,%r12
    6142:	55                   	push   %rbp
    6143:	53                   	push   %rbx
    6144:	48 89 f3             	mov    %rsi,%rbx
    6147:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    614c:	48 89 f1             	mov    %rsi,%rcx
    614f:	48 83 ec 28          	sub    $0x28,%rsp
    6153:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6159:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    615f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6165:	e8 46 fc ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    616a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6170:	48 89 da             	mov    %rbx,%rdx
    6173:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6179:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6180:	00 f0 3f 
    6183:	48 89 c7             	mov    %rax,%rdi
    6186:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    618d:	00 f0 bf 
    6190:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6195:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    619b:	e8 10 fc ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    61a0:	f2 0f 10 05 88 79 00 	movsd  0x7988(%rip),%xmm0        # db30 <msg.4+0xb0>
    61a7:	00 
    61a8:	4c 89 e7             	mov    %r12,%rdi
    61ab:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    61b1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    61b8:	00 f0 3f 
    61bb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    61c2:	49 89 c5             	mov    %rax,%r13
    61c5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    61cc:	00 f0 bf 
    61cf:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    61d4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61da:	e8 d1 fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    61df:	48 89 e9             	mov    %rbp,%rcx
    61e2:	4c 89 ea             	mov    %r13,%rdx
    61e5:	48 89 ee             	mov    %rbp,%rsi
    61e8:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    61ee:	4c 89 ef             	mov    %r13,%rdi
    61f1:	49 89 c4             	mov    %rax,%r12
    61f4:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    61f8:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    61fe:	e8 ad fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    6203:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6209:	f2 0f 59 1d 27 79 00 	mulsd  0x7927(%rip),%xmm3        # db38 <msg.4+0xb8>
    6210:	00 
    6211:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6218:	00 59 40 
    621b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6220:	48 89 c2             	mov    %rax,%rdx
    6223:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    622a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6230:	e8 7b fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    6235:	48 89 d9             	mov    %rbx,%rcx
    6238:	4c 89 e2             	mov    %r12,%rdx
    623b:	48 89 de             	mov    %rbx,%rsi
    623e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6244:	4c 89 e7             	mov    %r12,%rdi
    6247:	48 89 c5             	mov    %rax,%rbp
    624a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    624e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6254:	e8 57 fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    6259:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    625f:	48 89 ea             	mov    %rbp,%rdx
    6262:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6268:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    626f:	00 f0 3f 
    6272:	48 89 c7             	mov    %rax,%rdi
    6275:	48 89 ce             	mov    %rcx,%rsi
    6278:	66 48 0f 7e db       	movq   %xmm3,%rbx
    627d:	e8 2e fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    6282:	48 83 c4 28          	add    $0x28,%rsp
    6286:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    628b:	5b                   	pop    %rbx
    628c:	5d                   	pop    %rbp
    628d:	41 5c                	pop    %r12
    628f:	41 5d                	pop    %r13
    6291:	c3                   	ret
    6292:	0f 1f 00             	nopl   (%rax)
    6295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    629c:	00 00 00 00 

00000000000062a0 <w164.constprop.0>:
    62a0:	41 54                	push   %r12
    62a2:	55                   	push   %rbp
    62a3:	53                   	push   %rbx
    62a4:	48 83 ec 10          	sub    $0x10,%rsp
    62a8:	4c 8b 27             	mov    (%rdi),%r12
    62ab:	4d 85 e4             	test   %r12,%r12
    62ae:	74 58                	je     6308 <w164.constprop.0+0x68>
    62b0:	48 89 fd             	mov    %rdi,%rbp
    62b3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    62b7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    62be:	31 db                	xor    %ebx,%ebx
    62c0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    62c6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    62cb:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62d2:	00 f0 3f 
    62d5:	48 83 c3 02          	add    $0x2,%rbx
    62d9:	48 89 ce             	mov    %rcx,%rsi
    62dc:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    62e2:	e8 c9 fa ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    62e7:	4c 39 e3             	cmp    %r12,%rbx
    62ea:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    62f0:	48 89 c7             	mov    %rax,%rdi
    62f3:	72 cb                	jb     62c0 <w164.constprop.0+0x20>
    62f5:	48 83 c4 10          	add    $0x10,%rsp
    62f9:	48 89 f8             	mov    %rdi,%rax
    62fc:	5b                   	pop    %rbx
    62fd:	5d                   	pop    %rbp
    62fe:	41 5c                	pop    %r12
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	48 83 c4 10          	add    $0x10,%rsp
    630c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6313:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6317:	5b                   	pop    %rbx
    6318:	48 89 f8             	mov    %rdi,%rax
    631b:	5d                   	pop    %rbp
    631c:	41 5c                	pop    %r12
    631e:	c3                   	ret
    631f:	90                   	nop

0000000000006320 <fwp_data.part.0.constprop.0>:
    6320:	41 56                	push   %r14
    6322:	41 89 fe             	mov    %edi,%r14d
    6325:	41 54                	push   %r12
    6327:	49 89 f4             	mov    %rsi,%r12
    632a:	55                   	push   %rbp
    632b:	53                   	push   %rbx
    632c:	48 83 ec 08          	sub    $0x8,%rsp
    6330:	8b 05 ee c7 01 00    	mov    0x1c7ee(%rip),%eax        # 22b24 <fwp_heap+0x13a4>
    6336:	85 c0                	test   %eax,%eax
    6338:	0f 84 fa 00 00 00    	je     6438 <fwp_data.part.0.constprop.0+0x118>
    633e:	0f b6 05 dd c3 01 00 	movzbl 0x1c3dd(%rip),%eax        # 22722 <fwp_heap+0xfa2>
    6345:	48 8d 15 34 b4 01 00 	lea    0x1b434(%rip),%rdx        # 21780 <fwp_heap>
    634c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6353:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6357:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    635b:	48 8b 18             	mov    (%rax),%rbx
    635e:	48 85 db             	test   %rbx,%rbx
    6361:	0f 84 a9 00 00 00    	je     6410 <fwp_data.part.0.constprop.0+0xf0>
    6367:	48 8b 13             	mov    (%rbx),%rdx
    636a:	48 f7 d2             	not    %rdx
    636d:	48 89 10             	mov    %rdx,(%rax)
    6370:	48 83 fd 18          	cmp    $0x18,%rbp
    6374:	76 1b                	jbe    6391 <fwp_data.part.0.constprop.0+0x71>
    6376:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    637a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    637e:	31 f6                	xor    %esi,%esi
    6380:	48 c1 e8 03          	shr    $0x3,%rax
    6384:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    638b:	00 
    638c:	e8 2f d1 ff ff       	call   34c0 <memset@plt>
    6391:	48 89 e8             	mov    %rbp,%rax
    6394:	48 03 05 05 c8 01 00 	add    0x1c805(%rip),%rax        # 22ba0 <fwp_heap+0x1420>
    639b:	0f 82 a8 00 00 00    	jb     6449 <fwp_data.part.0.constprop.0+0x129>
    63a1:	48 39 05 00 c8 01 00 	cmp    %rax,0x1c800(%rip)        # 22ba8 <fwp_heap+0x1428>
    63a8:	48 89 05 f1 c7 01 00 	mov    %rax,0x1c7f1(%rip)        # 22ba0 <fwp_heap+0x1420>
    63af:	73 07                	jae    63b8 <fwp_data.part.0.constprop.0+0x98>
    63b1:	48 89 05 f0 c7 01 00 	mov    %rax,0x1c7f0(%rip)        # 22ba8 <fwp_heap+0x1428>
    63b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    63bc:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    63c1:	f2 0f 58 05 ef c7 01 	addsd  0x1c7ef(%rip),%xmm0        # 22bb8 <fwp_heap+0x1438>
    63c8:	00 
    63c9:	f2 0f 11 05 e7 c7 01 	movsd  %xmm0,0x1c7e7(%rip)        # 22bb8 <fwp_heap+0x1438>
    63d0:	00 
    63d1:	b8 02 00 00 00       	mov    $0x2,%eax
    63d6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    63db:	66 0f 6e c8          	movd   %eax,%xmm1
    63df:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    63e3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    63e7:	49 8b 04 24          	mov    (%r12),%rax
    63eb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    63ef:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    63f4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    63f8:	48 83 c4 08          	add    $0x8,%rsp
    63fc:	48 89 d8             	mov    %rbx,%rax
    63ff:	5b                   	pop    %rbx
    6400:	5d                   	pop    %rbp
    6401:	41 5c                	pop    %r12
    6403:	41 5e                	pop    %r14
    6405:	c3                   	ret
    6406:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    640d:	00 00 00 
    6410:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6414:	48 85 db             	test   %rbx,%rbx
    6417:	74 1f                	je     6438 <fwp_data.part.0.constprop.0+0x118>
    6419:	48 8b 50 10          	mov    0x10(%rax),%rdx
    641d:	48 29 da             	sub    %rbx,%rdx
    6420:	48 39 ea             	cmp    %rbp,%rdx
    6423:	72 13                	jb     6438 <fwp_data.part.0.constprop.0+0x118>
    6425:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6429:	48 89 50 08          	mov    %rdx,0x8(%rax)
    642d:	e9 3e ff ff ff       	jmp    6370 <fwp_data.part.0.constprop.0+0x50>
    6432:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6438:	31 f6                	xor    %esi,%esi
    643a:	bf 18 00 00 00       	mov    $0x18,%edi
    643f:	e8 0c f6 ff ff       	call   5a50 <fwp_heap_alloc>
    6444:	48 89 c3             	mov    %rax,%rbx
    6447:	eb 88                	jmp    63d1 <fwp_data.part.0.constprop.0+0xb1>
    6449:	e8 62 d8 ff ff       	call   3cb0 <fwp_heap_oom>
    644e:	66 90                	xchg   %ax,%ax

0000000000006450 <fwp_rc_share>:
    6450:	48 8b 05 01 c7 01 00 	mov    0x1c701(%rip),%rax        # 22b58 <fwp_heap+0x13d8>
    6457:	48 2b 3d d2 c6 01 00 	sub    0x1c6d2(%rip),%rdi        # 22b30 <fwp_heap+0x13b0>
    645e:	48 c1 e0 10          	shl    $0x10,%rax
    6462:	48 39 c7             	cmp    %rax,%rdi
    6465:	73 4a                	jae    64b1 <fwp_rc_share+0x61>
    6467:	48 89 f8             	mov    %rdi,%rax
    646a:	48 c1 e8 10          	shr    $0x10,%rax
    646e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6472:	48 8b 05 ff c6 01 00 	mov    0x1c6ff(%rip),%rax        # 22b78 <fwp_heap+0x13f8>
    6479:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    647d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6481:	48 85 d2             	test   %rdx,%rdx
    6484:	74 2b                	je     64b1 <fwp_rc_share+0x61>
    6486:	0f b6 08             	movzbl (%rax),%ecx
    6489:	80 f9 02             	cmp    $0x2,%cl
    648c:	74 2a                	je     64b8 <fwp_rc_share+0x68>
    648e:	80 f9 01             	cmp    $0x1,%cl
    6491:	75 1e                	jne    64b1 <fwp_rc_share+0x61>
    6493:	8b 48 18             	mov    0x18(%rax),%ecx
    6496:	0f b7 ff             	movzwl %di,%edi
    6499:	8b 40 1c             	mov    0x1c(%rax),%eax
    649c:	48 0f af f9          	imul   %rcx,%rdi
    64a0:	48 c1 ef 20          	shr    $0x20,%rdi
    64a4:	48 39 c7             	cmp    %rax,%rdi
    64a7:	73 08                	jae    64b1 <fwp_rc_share+0x61>
    64a9:	48 01 fa             	add    %rdi,%rdx
    64ac:	80 3a 00             	cmpb   $0x0,(%rdx)
    64af:	75 0d                	jne    64be <fwp_rc_share+0x6e>
    64b1:	c3                   	ret
    64b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64b8:	66 85 ff             	test   %di,%di
    64bb:	74 ef                	je     64ac <fwp_rc_share+0x5c>
    64bd:	c3                   	ret
    64be:	50                   	push   %rax
    64bf:	48 8d 3d 72 73 00 00 	lea    0x7372(%rip),%rdi        # d838 <_IO_stdin_used+0x838>
    64c6:	e8 d5 dc ff ff       	call   41a0 <fwp_trap>
    64cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000064d0 <fwp_rc_free_arr>:
    64d0:	48 8b 15 81 c6 01 00 	mov    0x1c681(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    64d7:	48 89 f8             	mov    %rdi,%rax
    64da:	48 2b 05 4f c6 01 00 	sub    0x1c64f(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    64e1:	48 c1 e2 10          	shl    $0x10,%rdx
    64e5:	48 39 d0             	cmp    %rdx,%rax
    64e8:	73 5b                	jae    6545 <fwp_rc_free_arr+0x75>
    64ea:	48 89 c2             	mov    %rax,%rdx
    64ed:	48 c1 ea 10          	shr    $0x10,%rdx
    64f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    64f5:	48 8b 15 7c c6 01 00 	mov    0x1c67c(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    64fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6500:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6504:	48 85 c9             	test   %rcx,%rcx
    6507:	74 3c                	je     6545 <fwp_rc_free_arr+0x75>
    6509:	0f b6 32             	movzbl (%rdx),%esi
    650c:	40 80 fe 02          	cmp    $0x2,%sil
    6510:	74 2e                	je     6540 <fwp_rc_free_arr+0x70>
    6512:	40 80 fe 01          	cmp    $0x1,%sil
    6516:	75 2d                	jne    6545 <fwp_rc_free_arr+0x75>
    6518:	8b 72 18             	mov    0x18(%rdx),%esi
    651b:	0f b7 c0             	movzwl %ax,%eax
    651e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6521:	48 0f af c6          	imul   %rsi,%rax
    6525:	48 c1 e8 20          	shr    $0x20,%rax
    6529:	48 39 d0             	cmp    %rdx,%rax
    652c:	73 17                	jae    6545 <fwp_rc_free_arr+0x75>
    652e:	48 01 c1             	add    %rax,%rcx
    6531:	80 39 01             	cmpb   $0x1,(%rcx)
    6534:	75 0f                	jne    6545 <fwp_rc_free_arr+0x75>
    6536:	e9 15 f0 ff ff       	jmp    5550 <fwp_mem_free>
    653b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6540:	66 85 c0             	test   %ax,%ax
    6543:	74 ec                	je     6531 <fwp_rc_free_arr+0x61>
    6545:	c3                   	ret
    6546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    654d:	00 00 00 

0000000000006550 <fwp_rc_dup>:
    6550:	f3 0f 1e fa          	endbr64
    6554:	48 8b 05 fd c5 01 00 	mov    0x1c5fd(%rip),%rax        # 22b58 <fwp_heap+0x13d8>
    655b:	48 2b 3d ce c5 01 00 	sub    0x1c5ce(%rip),%rdi        # 22b30 <fwp_heap+0x13b0>
    6562:	48 c1 e0 10          	shl    $0x10,%rax
    6566:	48 39 c7             	cmp    %rax,%rdi
    6569:	73 56                	jae    65c1 <fwp_rc_dup+0x71>
    656b:	48 89 f8             	mov    %rdi,%rax
    656e:	48 c1 e8 10          	shr    $0x10,%rax
    6572:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6576:	48 8b 05 fb c5 01 00 	mov    0x1c5fb(%rip),%rax        # 22b78 <fwp_heap+0x13f8>
    657d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6581:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6585:	48 85 c0             	test   %rax,%rax
    6588:	74 37                	je     65c1 <fwp_rc_dup+0x71>
    658a:	0f b6 0a             	movzbl (%rdx),%ecx
    658d:	80 f9 02             	cmp    $0x2,%cl
    6590:	74 36                	je     65c8 <fwp_rc_dup+0x78>
    6592:	80 f9 01             	cmp    $0x1,%cl
    6595:	75 2a                	jne    65c1 <fwp_rc_dup+0x71>
    6597:	8b 4a 18             	mov    0x18(%rdx),%ecx
    659a:	0f b7 ff             	movzwl %di,%edi
    659d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65a0:	48 0f af f9          	imul   %rcx,%rdi
    65a4:	48 c1 ef 20          	shr    $0x20,%rdi
    65a8:	48 39 d7             	cmp    %rdx,%rdi
    65ab:	73 14                	jae    65c1 <fwp_rc_dup+0x71>
    65ad:	48 01 f8             	add    %rdi,%rax
    65b0:	0f b6 10             	movzbl (%rax),%edx
    65b3:	84 d2                	test   %dl,%dl
    65b5:	74 0a                	je     65c1 <fwp_rc_dup+0x71>
    65b7:	80 fa fd             	cmp    $0xfd,%dl
    65ba:	77 14                	ja     65d0 <fwp_rc_dup+0x80>
    65bc:	83 c2 01             	add    $0x1,%edx
    65bf:	88 10                	mov    %dl,(%rax)
    65c1:	c3                   	ret
    65c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    65c8:	66 85 ff             	test   %di,%di
    65cb:	74 e3                	je     65b0 <fwp_rc_dup+0x60>
    65cd:	c3                   	ret
    65ce:	66 90                	xchg   %ax,%ax
    65d0:	48 89 c7             	mov    %rax,%rdi
    65d3:	e9 18 ec ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    65d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    65df:	00 

00000000000065e0 <fwp_drop0>:
    65e0:	f3 0f 1e fa          	endbr64
    65e4:	48 8b 15 6d c5 01 00 	mov    0x1c56d(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    65eb:	48 89 f8             	mov    %rdi,%rax
    65ee:	48 2b 05 3b c5 01 00 	sub    0x1c53b(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    65f5:	48 c1 e2 10          	shl    $0x10,%rdx
    65f9:	48 39 d0             	cmp    %rdx,%rax
    65fc:	0f 83 be 00 00 00    	jae    66c0 <fwp_drop0+0xe0>
    6602:	48 83 ec 18          	sub    $0x18,%rsp
    6606:	4c 8d 05 73 b1 01 00 	lea    0x1b173(%rip),%r8        # 21780 <fwp_heap>
    660d:	48 89 c2             	mov    %rax,%rdx
    6610:	48 c1 ea 10          	shr    $0x10,%rdx
    6614:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6618:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    661f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6623:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6627:	48 85 d2             	test   %rdx,%rdx
    662a:	74 3c                	je     6668 <fwp_drop0+0x88>
    662c:	0f b6 31             	movzbl (%rcx),%esi
    662f:	40 80 fe 02          	cmp    $0x2,%sil
    6633:	74 3b                	je     6670 <fwp_drop0+0x90>
    6635:	40 80 fe 01          	cmp    $0x1,%sil
    6639:	75 2d                	jne    6668 <fwp_drop0+0x88>
    663b:	8b 71 18             	mov    0x18(%rcx),%esi
    663e:	0f b7 c0             	movzwl %ax,%eax
    6641:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6644:	48 0f af c6          	imul   %rsi,%rax
    6648:	48 c1 e8 20          	shr    $0x20,%rax
    664c:	48 39 c8             	cmp    %rcx,%rax
    664f:	73 17                	jae    6668 <fwp_drop0+0x88>
    6651:	48 01 c2             	add    %rax,%rdx
    6654:	0f b6 02             	movzbl (%rdx),%eax
    6657:	84 c0                	test   %al,%al
    6659:	74 0d                	je     6668 <fwp_drop0+0x88>
    665b:	3c 01                	cmp    $0x1,%al
    665d:	74 21                	je     6680 <fwp_drop0+0xa0>
    665f:	3c ff                	cmp    $0xff,%al
    6661:	74 65                	je     66c8 <fwp_drop0+0xe8>
    6663:	83 e8 01             	sub    $0x1,%eax
    6666:	88 02                	mov    %al,(%rdx)
    6668:	48 83 c4 18          	add    $0x18,%rsp
    666c:	c3                   	ret
    666d:	0f 1f 00             	nopl   (%rax)
    6670:	66 85 c0             	test   %ax,%ax
    6673:	74 df                	je     6654 <fwp_drop0+0x74>
    6675:	48 83 c4 18          	add    $0x18,%rsp
    6679:	c3                   	ret
    667a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6680:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6684:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6689:	e8 42 fe ff ff       	call   64d0 <fwp_rc_free_arr>
    668e:	4c 8d 05 eb b0 01 00 	lea    0x1b0eb(%rip),%r8        # 21780 <fwp_heap>
    6695:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    669a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    66a1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    66a8:	48 c1 e2 10          	shl    $0x10,%rdx
    66ac:	48 39 d0             	cmp    %rdx,%rax
    66af:	73 b7                	jae    6668 <fwp_drop0+0x88>
    66b1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    66b6:	e9 52 ff ff ff       	jmp    660d <fwp_drop0+0x2d>
    66bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    66c0:	c3                   	ret
    66c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    66c8:	48 89 d0             	mov    %rdx,%rax
    66cb:	48 c1 e8 11          	shr    $0x11,%rax
    66cf:	48 31 d0             	xor    %rdx,%rax
    66d2:	48 89 c1             	mov    %rax,%rcx
    66d5:	48 c1 e9 09          	shr    $0x9,%rcx
    66d9:	48 31 c8             	xor    %rcx,%rax
    66dc:	0f b6 c8             	movzbl %al,%ecx
    66df:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    66e6:	00 
    66e7:	48 85 c0             	test   %rax,%rax
    66ea:	75 1d                	jne    6709 <fwp_drop0+0x129>
    66ec:	eb 56                	jmp    6744 <fwp_drop0+0x164>
    66ee:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    66f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    66fc:	00 00 00 00 
    6700:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6704:	48 85 c0             	test   %rax,%rax
    6707:	74 3b                	je     6744 <fwp_drop0+0x164>
    6709:	48 89 c1             	mov    %rax,%rcx
    670c:	48 39 10             	cmp    %rdx,(%rax)
    670f:	75 ef                	jne    6700 <fwp_drop0+0x120>
    6711:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6715:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6719:	48 89 48 08          	mov    %rcx,0x8(%rax)
    671d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6724:	0f 85 3e ff ff ff    	jne    6668 <fwp_drop0+0x88>
    672a:	48 89 d7             	mov    %rdx,%rdi
    672d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6732:	e8 d9 eb ff ff       	call   5310 <fwp_rc_forget_slot>
    6737:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    673c:	c6 02 fe             	movb   $0xfe,(%rdx)
    673f:	e9 24 ff ff ff       	jmp    6668 <fwp_drop0+0x88>
    6744:	48 8d 3d 4d 70 00 00 	lea    0x704d(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    674b:	e8 50 da ff ff       	call   41a0 <fwp_trap>

0000000000006750 <fwp_arg_drop12>:
    6750:	f3 0f 1e fa          	endbr64
    6754:	85 f6                	test   %esi,%esi
    6756:	75 04                	jne    675c <fwp_arg_drop12+0xc>
    6758:	85 d2                	test   %edx,%edx
    675a:	75 04                	jne    6760 <fwp_arg_drop12+0x10>
    675c:	c3                   	ret
    675d:	0f 1f 00             	nopl   (%rax)
    6760:	48 8b 3f             	mov    (%rdi),%rdi
    6763:	e9 78 fe ff ff       	jmp    65e0 <fwp_drop0>
    6768:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    676f:	00 

0000000000006770 <fwp_drop1>:
    6770:	f3 0f 1e fa          	endbr64
    6774:	48 8b 15 dd c3 01 00 	mov    0x1c3dd(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    677b:	48 89 f8             	mov    %rdi,%rax
    677e:	48 2b 05 ab c3 01 00 	sub    0x1c3ab(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    6785:	48 c1 e2 10          	shl    $0x10,%rdx
    6789:	48 39 d0             	cmp    %rdx,%rax
    678c:	0f 83 be 00 00 00    	jae    6850 <fwp_drop1+0xe0>
    6792:	48 83 ec 18          	sub    $0x18,%rsp
    6796:	4c 8d 05 e3 af 01 00 	lea    0x1afe3(%rip),%r8        # 21780 <fwp_heap>
    679d:	48 89 c2             	mov    %rax,%rdx
    67a0:	48 c1 ea 10          	shr    $0x10,%rdx
    67a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67a8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    67af:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    67b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    67b7:	48 85 d2             	test   %rdx,%rdx
    67ba:	74 3c                	je     67f8 <fwp_drop1+0x88>
    67bc:	0f b6 31             	movzbl (%rcx),%esi
    67bf:	40 80 fe 02          	cmp    $0x2,%sil
    67c3:	74 3b                	je     6800 <fwp_drop1+0x90>
    67c5:	40 80 fe 01          	cmp    $0x1,%sil
    67c9:	75 2d                	jne    67f8 <fwp_drop1+0x88>
    67cb:	8b 71 18             	mov    0x18(%rcx),%esi
    67ce:	0f b7 c0             	movzwl %ax,%eax
    67d1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    67d4:	48 0f af c6          	imul   %rsi,%rax
    67d8:	48 c1 e8 20          	shr    $0x20,%rax
    67dc:	48 39 c8             	cmp    %rcx,%rax
    67df:	73 17                	jae    67f8 <fwp_drop1+0x88>
    67e1:	48 01 c2             	add    %rax,%rdx
    67e4:	0f b6 02             	movzbl (%rdx),%eax
    67e7:	84 c0                	test   %al,%al
    67e9:	74 0d                	je     67f8 <fwp_drop1+0x88>
    67eb:	3c 01                	cmp    $0x1,%al
    67ed:	74 21                	je     6810 <fwp_drop1+0xa0>
    67ef:	3c ff                	cmp    $0xff,%al
    67f1:	74 65                	je     6858 <fwp_drop1+0xe8>
    67f3:	83 e8 01             	sub    $0x1,%eax
    67f6:	88 02                	mov    %al,(%rdx)
    67f8:	48 83 c4 18          	add    $0x18,%rsp
    67fc:	c3                   	ret
    67fd:	0f 1f 00             	nopl   (%rax)
    6800:	66 85 c0             	test   %ax,%ax
    6803:	74 df                	je     67e4 <fwp_drop1+0x74>
    6805:	48 83 c4 18          	add    $0x18,%rsp
    6809:	c3                   	ret
    680a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6810:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6814:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6819:	e8 b2 fc ff ff       	call   64d0 <fwp_rc_free_arr>
    681e:	4c 8d 05 5b af 01 00 	lea    0x1af5b(%rip),%r8        # 21780 <fwp_heap>
    6825:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    682a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6831:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6838:	48 c1 e2 10          	shl    $0x10,%rdx
    683c:	48 39 d0             	cmp    %rdx,%rax
    683f:	73 b7                	jae    67f8 <fwp_drop1+0x88>
    6841:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6846:	e9 52 ff ff ff       	jmp    679d <fwp_drop1+0x2d>
    684b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6850:	c3                   	ret
    6851:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6858:	48 89 d0             	mov    %rdx,%rax
    685b:	48 c1 e8 11          	shr    $0x11,%rax
    685f:	48 31 d0             	xor    %rdx,%rax
    6862:	48 89 c1             	mov    %rax,%rcx
    6865:	48 c1 e9 09          	shr    $0x9,%rcx
    6869:	48 31 c8             	xor    %rcx,%rax
    686c:	0f b6 c8             	movzbl %al,%ecx
    686f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6876:	00 
    6877:	48 85 c0             	test   %rax,%rax
    687a:	75 0d                	jne    6889 <fwp_drop1+0x119>
    687c:	eb 46                	jmp    68c4 <fwp_drop1+0x154>
    687e:	66 90                	xchg   %ax,%ax
    6880:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6884:	48 85 c0             	test   %rax,%rax
    6887:	74 3b                	je     68c4 <fwp_drop1+0x154>
    6889:	48 89 c1             	mov    %rax,%rcx
    688c:	48 39 10             	cmp    %rdx,(%rax)
    688f:	75 ef                	jne    6880 <fwp_drop1+0x110>
    6891:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6895:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6899:	48 89 48 08          	mov    %rcx,0x8(%rax)
    689d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    68a4:	0f 85 4e ff ff ff    	jne    67f8 <fwp_drop1+0x88>
    68aa:	48 89 d7             	mov    %rdx,%rdi
    68ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    68b2:	e8 59 ea ff ff       	call   5310 <fwp_rc_forget_slot>
    68b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    68bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    68bf:	e9 34 ff ff ff       	jmp    67f8 <fwp_drop1+0x88>
    68c4:	48 8d 3d cd 6e 00 00 	lea    0x6ecd(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    68cb:	e8 d0 d8 ff ff       	call   41a0 <fwp_trap>

00000000000068d0 <fwp_closure_drop>:
    68d0:	48 8b 15 81 c2 01 00 	mov    0x1c281(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    68d7:	48 89 f8             	mov    %rdi,%rax
    68da:	48 2b 05 4f c2 01 00 	sub    0x1c24f(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    68e1:	48 c1 e2 10          	shl    $0x10,%rdx
    68e5:	48 39 d0             	cmp    %rdx,%rax
    68e8:	73 6b                	jae    6955 <fwp_closure_drop+0x85>
    68ea:	48 89 c2             	mov    %rax,%rdx
    68ed:	48 c1 ea 10          	shr    $0x10,%rdx
    68f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68f5:	48 8b 15 7c c2 01 00 	mov    0x1c27c(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    68fc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6900:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6904:	48 85 d2             	test   %rdx,%rdx
    6907:	74 4c                	je     6955 <fwp_closure_drop+0x85>
    6909:	0f b6 31             	movzbl (%rcx),%esi
    690c:	40 80 fe 02          	cmp    $0x2,%sil
    6910:	74 3e                	je     6950 <fwp_closure_drop+0x80>
    6912:	40 80 fe 01          	cmp    $0x1,%sil
    6916:	75 3d                	jne    6955 <fwp_closure_drop+0x85>
    6918:	8b 71 18             	mov    0x18(%rcx),%esi
    691b:	0f b7 c0             	movzwl %ax,%eax
    691e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6921:	48 0f af c6          	imul   %rsi,%rax
    6925:	48 c1 e8 20          	shr    $0x20,%rax
    6929:	48 39 c8             	cmp    %rcx,%rax
    692c:	73 27                	jae    6955 <fwp_closure_drop+0x85>
    692e:	48 01 c2             	add    %rax,%rdx
    6931:	0f b6 02             	movzbl (%rdx),%eax
    6934:	84 c0                	test   %al,%al
    6936:	74 1d                	je     6955 <fwp_closure_drop+0x85>
    6938:	3c 01                	cmp    $0x1,%al
    693a:	74 24                	je     6960 <fwp_closure_drop+0x90>
    693c:	3c ff                	cmp    $0xff,%al
    693e:	74 48                	je     6988 <fwp_closure_drop+0xb8>
    6940:	83 e8 01             	sub    $0x1,%eax
    6943:	88 02                	mov    %al,(%rdx)
    6945:	c3                   	ret
    6946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    694d:	00 00 00 
    6950:	66 85 c0             	test   %ax,%ax
    6953:	74 dc                	je     6931 <fwp_closure_drop+0x61>
    6955:	c3                   	ret
    6956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    695d:	00 00 00 
    6960:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6967:	ff ff 
    6969:	48 85 c0             	test   %rax,%rax
    696c:	74 12                	je     6980 <fwp_closure_drop+0xb0>
    696e:	48 89 fe             	mov    %rdi,%rsi
    6971:	48 89 c7             	mov    %rax,%rdi
    6974:	e9 87 d8 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6980:	e9 2b da ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6985:	0f 1f 00             	nopl   (%rax)
    6988:	48 89 d0             	mov    %rdx,%rax
    698b:	48 8d 35 ee ad 01 00 	lea    0x1adee(%rip),%rsi        # 21780 <fwp_heap>
    6992:	48 83 ec 18          	sub    $0x18,%rsp
    6996:	48 c1 e8 11          	shr    $0x11,%rax
    699a:	48 31 d0             	xor    %rdx,%rax
    699d:	48 89 c1             	mov    %rax,%rcx
    69a0:	48 c1 e9 09          	shr    $0x9,%rcx
    69a4:	48 31 c8             	xor    %rcx,%rax
    69a7:	0f b6 c8             	movzbl %al,%ecx
    69aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    69b1:	00 
    69b2:	48 85 c0             	test   %rax,%rax
    69b5:	75 12                	jne    69c9 <fwp_closure_drop+0xf9>
    69b7:	eb 49                	jmp    6a02 <fwp_closure_drop+0x132>
    69b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    69c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    69c4:	48 85 c0             	test   %rax,%rax
    69c7:	74 39                	je     6a02 <fwp_closure_drop+0x132>
    69c9:	48 89 c1             	mov    %rax,%rcx
    69cc:	48 39 10             	cmp    %rdx,(%rax)
    69cf:	75 ef                	jne    69c0 <fwp_closure_drop+0xf0>
    69d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    69d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    69d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    69dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    69e4:	74 05                	je     69eb <fwp_closure_drop+0x11b>
    69e6:	48 83 c4 18          	add    $0x18,%rsp
    69ea:	c3                   	ret
    69eb:	48 89 d7             	mov    %rdx,%rdi
    69ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    69f3:	e8 18 e9 ff ff       	call   5310 <fwp_rc_forget_slot>
    69f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    69fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6a00:	eb e4                	jmp    69e6 <fwp_closure_drop+0x116>
    6a02:	48 8d 3d 8f 6d 00 00 	lea    0x6d8f(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    6a09:	e8 92 d7 ff ff       	call   41a0 <fwp_trap>
    6a0e:	66 90                	xchg   %ax,%ax

0000000000006a10 <fwp_owned_tape_release>:
    6a10:	48 85 ff             	test   %rdi,%rdi
    6a13:	0f 84 f7 00 00 00    	je     6b10 <fwp_owned_tape_release+0x100>
    6a19:	41 54                	push   %r12
    6a1b:	55                   	push   %rbp
    6a1c:	53                   	push   %rbx
    6a1d:	48 8b 07             	mov    (%rdi),%rax
    6a20:	48 85 c0             	test   %rax,%rax
    6a23:	74 08                	je     6a2d <fwp_owned_tape_release+0x1d>
    6a25:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6a29:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6a2d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6a31:	48 85 d2             	test   %rdx,%rdx
    6a34:	74 03                	je     6a39 <fwp_owned_tape_release+0x29>
    6a36:	48 89 02             	mov    %rax,(%rdx)
    6a39:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6a3d:	48 89 fb             	mov    %rdi,%rbx
    6a40:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6a44:	48 85 c0             	test   %rax,%rax
    6a47:	0f 84 89 00 00 00    	je     6ad6 <fwp_owned_tape_release+0xc6>
    6a4d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6a51:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6a55:	7e 47                	jle    6a9e <fwp_owned_tape_release+0x8e>
    6a57:	31 ed                	xor    %ebp,%ebp
    6a59:	eb 0d                	jmp    6a68 <fwp_owned_tape_release+0x58>
    6a5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a60:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a64:	48 8b 40 68          	mov    0x68(%rax),%rax
    6a68:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6a6c:	49 89 ec             	mov    %rbp,%r12
    6a6f:	48 83 c5 01          	add    $0x1,%rbp
    6a73:	49 c1 e4 04          	shl    $0x4,%r12
    6a77:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6a7b:	ff d0                	call   *%rax
    6a7d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6a81:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6a86:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a8a:	ff 50 68             	call   *0x68(%rax)
    6a8d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6a91:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6a95:	48 39 e8             	cmp    %rbp,%rax
    6a98:	7f c6                	jg     6a60 <fwp_owned_tape_release+0x50>
    6a9a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a9e:	31 ed                	xor    %ebp,%ebp
    6aa0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6aa5:	7e 28                	jle    6acf <fwp_owned_tape_release+0xbf>
    6aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6aae:	00 00 
    6ab0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6ab4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6ab8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6abc:	74 07                	je     6ac5 <fwp_owned_tape_release+0xb5>
    6abe:	ff 52 68             	call   *0x68(%rdx)
    6ac1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6ac5:	48 83 c5 01          	add    $0x1,%rbp
    6ac9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6acd:	7f e1                	jg     6ab0 <fwp_owned_tape_release+0xa0>
    6acf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6ad3:	ff 52 68             	call   *0x68(%rdx)
    6ad6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6ada:	e8 f1 fd ff ff       	call   68d0 <fwp_closure_drop>
    6adf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6ae3:	e8 e8 fd ff ff       	call   68d0 <fwp_closure_drop>
    6ae8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6aec:	e8 df fd ff ff       	call   68d0 <fwp_closure_drop>
    6af1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6af5:	e8 56 ea ff ff       	call   5550 <fwp_mem_free>
    6afa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6afe:	e8 4d ea ff ff       	call   5550 <fwp_mem_free>
    6b03:	48 89 df             	mov    %rbx,%rdi
    6b06:	5b                   	pop    %rbx
    6b07:	5d                   	pop    %rbp
    6b08:	41 5c                	pop    %r12
    6b0a:	e9 41 ea ff ff       	jmp    5550 <fwp_mem_free>
    6b0f:	90                   	nop
    6b10:	c3                   	ret
    6b11:	0f 1f 40 00          	nopl   0x0(%rax)
    6b15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b1c:	00 00 00 00 

0000000000006b20 <fwp_tape_finish>:
    6b20:	f3 0f 1e fa          	endbr64
    6b24:	41 56                	push   %r14
    6b26:	48 8d 3d 93 a5 01 00 	lea    0x1a593(%rip),%rdi        # 210c0 <fwp_tape_workspace>
    6b2d:	41 55                	push   %r13
    6b2f:	41 54                	push   %r12
    6b31:	55                   	push   %rbp
    6b32:	53                   	push   %rbx
    6b33:	e8 38 d4 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6b38:	48 83 3d c8 a5 01 00 	cmpq   $0x0,0x1a5c8(%rip)        # 21108 <fwp_ntapes>
    6b3f:	00 
    6b40:	48 c7 05 5d a5 01 00 	movq   $0x0,0x1a55d(%rip)        # 210a8 <fwp_tape_cached_bytes>
    6b47:	00 00 00 00 
    6b4b:	7e 68                	jle    6bb5 <fwp_tape_finish+0x95>
    6b4d:	45 31 e4             	xor    %r12d,%r12d
    6b50:	31 ed                	xor    %ebp,%ebp
    6b52:	0f 1f 00             	nopl   (%rax)
    6b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b5c:	00 00 00 00 
    6b60:	48 8b 1d a9 a5 01 00 	mov    0x1a5a9(%rip),%rbx        # 21110 <fwp_tapes>
    6b67:	48 83 c5 01          	add    $0x1,%rbp
    6b6b:	4c 01 e3             	add    %r12,%rbx
    6b6e:	49 83 c4 68          	add    $0x68,%r12
    6b72:	48 89 df             	mov    %rbx,%rdi
    6b75:	e8 86 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6b7a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6b7e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6b82:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6b86:	e8 35 c8 ff ff       	call   33c0 <free@plt>
    6b8b:	4c 89 f7             	mov    %r14,%rdi
    6b8e:	e8 2d c8 ff ff       	call   33c0 <free@plt>
    6b93:	4c 89 ef             	mov    %r13,%rdi
    6b96:	e8 25 c8 ff ff       	call   33c0 <free@plt>
    6b9b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6b9f:	e8 6c fe ff ff       	call   6a10 <fwp_owned_tape_release>
    6ba4:	48 39 2d 5d a5 01 00 	cmp    %rbp,0x1a55d(%rip)        # 21108 <fwp_ntapes>
    6bab:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6bb2:	00 
    6bb3:	7f ab                	jg     6b60 <fwp_tape_finish+0x40>
    6bb5:	48 8b 3d 54 a5 01 00 	mov    0x1a554(%rip),%rdi        # 21110 <fwp_tapes>
    6bbc:	e8 ff c7 ff ff       	call   33c0 <free@plt>
    6bc1:	5b                   	pop    %rbx
    6bc2:	5d                   	pop    %rbp
    6bc3:	48 c7 05 42 a5 01 00 	movq   $0x0,0x1a542(%rip)        # 21110 <fwp_tapes>
    6bca:	00 00 00 00 
    6bce:	48 c7 05 27 a5 01 00 	movq   $0x0,0x1a527(%rip)        # 21100 <fwp_tapes_cap>
    6bd5:	00 00 00 00 
    6bd9:	41 5c                	pop    %r12
    6bdb:	48 c7 05 22 a5 01 00 	movq   $0x0,0x1a522(%rip)        # 21108 <fwp_ntapes>
    6be2:	00 00 00 00 
    6be6:	41 5d                	pop    %r13
    6be8:	48 c7 05 05 a5 01 00 	movq   $0x0,0x1a505(%rip)        # 210f8 <fwp_tape_next_slot>
    6bef:	00 00 00 00 
    6bf3:	41 5e                	pop    %r14
    6bf5:	c3                   	ret
    6bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bfd:	00 00 00 

0000000000006c00 <fwp_tape_scope_release>:
    6c00:	f3 0f 1e fa          	endbr64
    6c04:	41 55                	push   %r13
    6c06:	41 54                	push   %r12
    6c08:	55                   	push   %rbp
    6c09:	53                   	push   %rbx
    6c0a:	48 83 ec 58          	sub    $0x58,%rsp
    6c0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6c15:	00 00 
    6c17:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6c1c:	48 63 07             	movslq (%rdi),%rax
    6c1f:	85 c0                	test   %eax,%eax
    6c21:	0f 88 05 01 00 00    	js     6d2c <fwp_tape_scope_release+0x12c>
    6c27:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6c2e:	ec c4 4e 
    6c31:	48 89 fb             	mov    %rdi,%rbx
    6c34:	eb 3c                	jmp    6c72 <fwp_tape_scope_release+0x72>
    6c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c3d:	00 00 00 
    6c40:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6c45:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6c49:	e8 72 c7 ff ff       	call   33c0 <free@plt>
    6c4e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6c52:	e8 69 c7 ff ff       	call   33c0 <free@plt>
    6c57:	4c 89 ef             	mov    %r13,%rdi
    6c5a:	e8 61 c7 ff ff       	call   33c0 <free@plt>
    6c5f:	4c 89 e7             	mov    %r12,%rdi
    6c62:	e8 a9 fd ff ff       	call   6a10 <fwp_owned_tape_release>
    6c67:	48 63 03             	movslq (%rbx),%rax
    6c6a:	85 c0                	test   %eax,%eax
    6c6c:	0f 88 ba 00 00 00    	js     6d2c <fwp_tape_scope_release+0x12c>
    6c72:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6c76:	48 8b 35 93 a4 01 00 	mov    0x1a493(%rip),%rsi        # 21110 <fwp_tapes>
    6c7d:	4c 01 c6             	add    %r8,%rsi
    6c80:	48 89 f7             	mov    %rsi,%rdi
    6c83:	e8 78 cf ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6c88:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6c8d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6c92:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6c99:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6c9d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6ca1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6ca8:	00 
    6ca9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6cae:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6cb2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6cb7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6cbb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6cc0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6cc7:	00 
    6cc8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6ccf:	00 
    6cd0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6cd7:	00 
    6cd8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6cdd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6ce2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6ce6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6cea:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6cee:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6cf4:	77 18                	ja     6d0e <fwp_tape_scope_release+0x10e>
    6cf6:	49 c1 f8 03          	sar    $0x3,%r8
    6cfa:	4c 0f af c5          	imul   %rbp,%r8
    6cfe:	4c 3b 05 f3 a3 01 00 	cmp    0x1a3f3(%rip),%r8        # 210f8 <fwp_tape_next_slot>
    6d05:	7d 07                	jge    6d0e <fwp_tape_scope_release+0x10e>
    6d07:	4c 89 05 ea a3 01 00 	mov    %r8,0x1a3ea(%rip)        # 210f8 <fwp_tape_next_slot>
    6d0e:	4d 85 e4             	test   %r12,%r12
    6d11:	0f 85 29 ff ff ff    	jne    6c40 <fwp_tape_scope_release+0x40>
    6d17:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6d1c:	e8 0f e1 ff ff       	call   4e30 <fwp_tape_buffers_release>
    6d21:	48 63 03             	movslq (%rbx),%rax
    6d24:	85 c0                	test   %eax,%eax
    6d26:	0f 89 46 ff ff ff    	jns    6c72 <fwp_tape_scope_release+0x72>
    6d2c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6d31:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d38:	00 00 
    6d3a:	75 0b                	jne    6d47 <fwp_tape_scope_release+0x147>
    6d3c:	48 83 c4 58          	add    $0x58,%rsp
    6d40:	5b                   	pop    %rbx
    6d41:	5d                   	pop    %rbp
    6d42:	41 5c                	pop    %r12
    6d44:	41 5d                	pop    %r13
    6d46:	c3                   	ret
    6d47:	e8 14 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6d4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006d50 <fwp_task_dispose>:
    6d50:	53                   	push   %rbx
    6d51:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6d55:	0f 84 eb c9 ff ff    	je     3746 <fwp_task_dispose.cold>
    6d5b:	48 89 fb             	mov    %rdi,%rbx
    6d5e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6d63:	0f 85 dd c9 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6d69:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6d6d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6d74:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6d7b:	00 
    6d7c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6d80:	48 85 ff             	test   %rdi,%rdi
    6d83:	74 07                	je     6d8c <fwp_task_dispose+0x3c>
    6d85:	48 85 c0             	test   %rax,%rax
    6d88:	74 02                	je     6d8c <fwp_task_dispose+0x3c>
    6d8a:	ff d0                	call   *%rax
    6d8c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6d93:	e8 b8 e7 ff ff       	call   5550 <fwp_mem_free>
    6d98:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6d9f:	00 00 00 00 
    6da3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6da7:	74 6f                	je     6e18 <fwp_task_dispose+0xc8>
    6da9:	48 8b 15 a8 bd 01 00 	mov    0x1bda8(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    6db0:	48 89 d8             	mov    %rbx,%rax
    6db3:	48 2b 05 76 bd 01 00 	sub    0x1bd76(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    6dba:	48 c1 e2 10          	shl    $0x10,%rdx
    6dbe:	48 39 d0             	cmp    %rdx,%rax
    6dc1:	73 4c                	jae    6e0f <fwp_task_dispose+0xbf>
    6dc3:	48 89 c2             	mov    %rax,%rdx
    6dc6:	48 c1 ea 10          	shr    $0x10,%rdx
    6dca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6dce:	48 8b 15 a3 bd 01 00 	mov    0x1bda3(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    6dd5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6dd9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6ddd:	48 85 c9             	test   %rcx,%rcx
    6de0:	74 2d                	je     6e0f <fwp_task_dispose+0xbf>
    6de2:	0f b6 32             	movzbl (%rdx),%esi
    6de5:	40 80 fe 02          	cmp    $0x2,%sil
    6de9:	74 3d                	je     6e28 <fwp_task_dispose+0xd8>
    6deb:	40 80 fe 01          	cmp    $0x1,%sil
    6def:	75 1e                	jne    6e0f <fwp_task_dispose+0xbf>
    6df1:	8b 72 18             	mov    0x18(%rdx),%esi
    6df4:	0f b7 c0             	movzwl %ax,%eax
    6df7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6dfa:	48 0f af c6          	imul   %rsi,%rax
    6dfe:	48 c1 e8 20          	shr    $0x20,%rax
    6e02:	48 39 d0             	cmp    %rdx,%rax
    6e05:	73 08                	jae    6e0f <fwp_task_dispose+0xbf>
    6e07:	48 01 c1             	add    %rax,%rcx
    6e0a:	80 39 01             	cmpb   $0x1,(%rcx)
    6e0d:	74 09                	je     6e18 <fwp_task_dispose+0xc8>
    6e0f:	5b                   	pop    %rbx
    6e10:	c3                   	ret
    6e11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e18:	48 89 df             	mov    %rbx,%rdi
    6e1b:	5b                   	pop    %rbx
    6e1c:	e9 2f e7 ff ff       	jmp    5550 <fwp_mem_free>
    6e21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e28:	66 85 c0             	test   %ax,%ax
    6e2b:	74 dd                	je     6e0a <fwp_task_dispose+0xba>
    6e2d:	5b                   	pop    %rbx
    6e2e:	c3                   	ret
    6e2f:	90                   	nop

0000000000006e30 <fwp_free_zombie>:
    6e30:	48 8b 15 19 a9 01 00 	mov    0x1a919(%rip),%rdx        # 21750 <fwp_zombie>
    6e37:	48 85 d2             	test   %rdx,%rdx
    6e3a:	0f 84 98 00 00 00    	je     6ed8 <fwp_free_zombie+0xa8>
    6e40:	48 3b 15 19 a9 01 00 	cmp    0x1a919(%rip),%rdx        # 21760 <fwp_cur>
    6e47:	0f 84 8b 00 00 00    	je     6ed8 <fwp_free_zombie+0xa8>
    6e4d:	48 83 ec 18          	sub    $0x18,%rsp
    6e51:	48 63 05 d4 a2 01 00 	movslq 0x1a2d4(%rip),%rax        # 2112c <fwp_stack_pool_n>
    6e58:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6e5c:	83 f8 3f             	cmp    $0x3f,%eax
    6e5f:	7f 7f                	jg     6ee0 <fwp_free_zombie+0xb0>
    6e61:	8d 48 01             	lea    0x1(%rax),%ecx
    6e64:	89 0d c2 a2 01 00    	mov    %ecx,0x1a2c2(%rip)        # 2112c <fwp_stack_pool_n>
    6e6a:	48 8d 0d cf a2 01 00 	lea    0x1a2cf(%rip),%rcx        # 21140 <fwp_stack_pool>
    6e71:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6e75:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6e7c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e80:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6e87:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6e8b:	48 85 c9             	test   %rcx,%rcx
    6e8e:	0f 84 fc 00 00 00    	je     6f90 <fwp_free_zombie+0x160>
    6e94:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    6e9b:	48 85 c0             	test   %rax,%rax
    6e9e:	74 07                	je     6ea7 <fwp_free_zombie+0x77>
    6ea0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    6ea7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    6eaa:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6eae:	48 c7 05 97 a8 01 00 	movq   $0x0,0x1a897(%rip)        # 21750 <fwp_zombie>
    6eb5:	00 00 00 00 
    6eb9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    6ec0:	85 c0                	test   %eax,%eax
    6ec2:	74 34                	je     6ef8 <fwp_free_zombie+0xc8>
    6ec4:	83 f8 01             	cmp    $0x1,%eax
    6ec7:	0f 84 b3 00 00 00    	je     6f80 <fwp_free_zombie+0x150>
    6ecd:	48 83 c4 18          	add    $0x18,%rsp
    6ed1:	c3                   	ret
    6ed2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ed8:	c3                   	ret
    6ed9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ee0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    6ee4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ee9:	e8 f2 c6 ff ff       	call   35e0 <munmap@plt>
    6eee:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6ef3:	eb 80                	jmp    6e75 <fwp_free_zombie+0x45>
    6ef5:	0f 1f 00             	nopl   (%rax)
    6ef8:	48 8b 0d 59 bc 01 00 	mov    0x1bc59(%rip),%rcx        # 22b58 <fwp_heap+0x13d8>
    6eff:	48 89 d0             	mov    %rdx,%rax
    6f02:	48 2b 05 27 bc 01 00 	sub    0x1bc27(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    6f09:	48 c1 e1 10          	shl    $0x10,%rcx
    6f0d:	48 39 c8             	cmp    %rcx,%rax
    6f10:	73 bb                	jae    6ecd <fwp_free_zombie+0x9d>
    6f12:	48 89 c1             	mov    %rax,%rcx
    6f15:	48 c1 e9 10          	shr    $0x10,%rcx
    6f19:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6f1d:	48 8b 0d 54 bc 01 00 	mov    0x1bc54(%rip),%rcx        # 22b78 <fwp_heap+0x13f8>
    6f24:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    6f28:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6f2c:	48 85 c9             	test   %rcx,%rcx
    6f2f:	74 9c                	je     6ecd <fwp_free_zombie+0x9d>
    6f31:	0f b6 3e             	movzbl (%rsi),%edi
    6f34:	40 80 ff 02          	cmp    $0x2,%dil
    6f38:	74 66                	je     6fa0 <fwp_free_zombie+0x170>
    6f3a:	40 80 ff 01          	cmp    $0x1,%dil
    6f3e:	75 8d                	jne    6ecd <fwp_free_zombie+0x9d>
    6f40:	8b 7e 18             	mov    0x18(%rsi),%edi
    6f43:	0f b7 c0             	movzwl %ax,%eax
    6f46:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6f49:	48 0f af c7          	imul   %rdi,%rax
    6f4d:	48 c1 e8 20          	shr    $0x20,%rax
    6f51:	48 39 f0             	cmp    %rsi,%rax
    6f54:	0f 83 73 ff ff ff    	jae    6ecd <fwp_free_zombie+0x9d>
    6f5a:	48 01 c1             	add    %rax,%rcx
    6f5d:	0f b6 01             	movzbl (%rcx),%eax
    6f60:	84 c0                	test   %al,%al
    6f62:	0f 84 65 ff ff ff    	je     6ecd <fwp_free_zombie+0x9d>
    6f68:	3c 01                	cmp    $0x1,%al
    6f6a:	74 14                	je     6f80 <fwp_free_zombie+0x150>
    6f6c:	3c ff                	cmp    $0xff,%al
    6f6e:	74 3b                	je     6fab <fwp_free_zombie+0x17b>
    6f70:	83 e8 01             	sub    $0x1,%eax
    6f73:	88 01                	mov    %al,(%rcx)
    6f75:	e9 53 ff ff ff       	jmp    6ecd <fwp_free_zombie+0x9d>
    6f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f80:	48 89 d7             	mov    %rdx,%rdi
    6f83:	48 83 c4 18          	add    $0x18,%rsp
    6f87:	e9 c4 fd ff ff       	jmp    6d50 <fwp_task_dispose>
    6f8c:	0f 1f 40 00          	nopl   0x0(%rax)
    6f90:	48 89 05 91 a7 01 00 	mov    %rax,0x1a791(%rip)        # 21728 <fwp_tasks_active>
    6f97:	e9 ff fe ff ff       	jmp    6e9b <fwp_free_zombie+0x6b>
    6f9c:	0f 1f 40 00          	nopl   0x0(%rax)
    6fa0:	66 85 c0             	test   %ax,%ax
    6fa3:	0f 85 24 ff ff ff    	jne    6ecd <fwp_free_zombie+0x9d>
    6fa9:	eb b2                	jmp    6f5d <fwp_free_zombie+0x12d>
    6fab:	48 89 ca             	mov    %rcx,%rdx
    6fae:	48 8d 35 cb a7 01 00 	lea    0x1a7cb(%rip),%rsi        # 21780 <fwp_heap>
    6fb5:	48 c1 ea 11          	shr    $0x11,%rdx
    6fb9:	48 31 ca             	xor    %rcx,%rdx
    6fbc:	48 89 d0             	mov    %rdx,%rax
    6fbf:	48 c1 e8 09          	shr    $0x9,%rax
    6fc3:	48 31 c2             	xor    %rax,%rdx
    6fc6:	0f b6 d2             	movzbl %dl,%edx
    6fc9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    6fd0:	00 
    6fd1:	48 85 c0             	test   %rax,%rax
    6fd4:	75 13                	jne    6fe9 <fwp_free_zombie+0x1b9>
    6fd6:	eb 4c                	jmp    7024 <fwp_free_zombie+0x1f4>
    6fd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6fdf:	00 
    6fe0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6fe4:	48 85 c0             	test   %rax,%rax
    6fe7:	74 3b                	je     7024 <fwp_free_zombie+0x1f4>
    6fe9:	48 89 c2             	mov    %rax,%rdx
    6fec:	48 39 08             	cmp    %rcx,(%rax)
    6fef:	75 ef                	jne    6fe0 <fwp_free_zombie+0x1b0>
    6ff1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6ff5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    6ff9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ffd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7004:	0f 85 c3 fe ff ff    	jne    6ecd <fwp_free_zombie+0x9d>
    700a:	48 89 cf             	mov    %rcx,%rdi
    700d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7012:	e8 f9 e2 ff ff       	call   5310 <fwp_rc_forget_slot>
    7017:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    701c:	c6 01 fe             	movb   $0xfe,(%rcx)
    701f:	e9 a9 fe ff ff       	jmp    6ecd <fwp_free_zombie+0x9d>
    7024:	48 8d 3d 6d 67 00 00 	lea    0x676d(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    702b:	e8 70 d1 ff ff       	call   41a0 <fwp_trap>

0000000000007030 <fwp_block>:
    7030:	48 83 ec 08          	sub    $0x8,%rsp
    7034:	48 8b 05 0d a7 01 00 	mov    0x1a70d(%rip),%rax        # 21748 <fwp_ready_head>
    703b:	48 85 c0             	test   %rax,%rax
    703e:	0f 84 1c 01 00 00    	je     7160 <fwp_block+0x130>
    7044:	90                   	nop
    7045:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    704c:	00 00 00 00 
    7050:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7057:	48 89 15 ea a6 01 00 	mov    %rdx,0x1a6ea(%rip)        # 21748 <fwp_ready_head>
    705e:	48 85 d2             	test   %rdx,%rdx
    7061:	0f 84 19 01 00 00    	je     7180 <fwp_block+0x150>
    7067:	48 8b 15 f2 a6 01 00 	mov    0x1a6f2(%rip),%rdx        # 21760 <fwp_cur>
    706e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7072:	48 39 c2             	cmp    %rax,%rdx
    7075:	0f 84 d5 00 00 00    	je     7150 <fwp_block+0x120>
    707b:	48 8b 0d 66 c3 01 00 	mov    0x1c366(%rip),%rcx        # 233e8 <fwp_state_owners>
    7082:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7086:	48 89 05 d3 a6 01 00 	mov    %rax,0x1a6d3(%rip)        # 21760 <fwp_cur>
    708d:	f3 0f 7e 05 7b c3 01 	movq   0x1c37b(%rip),%xmm0        # 23410 <fwp_foreign_callbacks>
    7094:	00 
    7095:	0f 16 05 64 c3 01 00 	movhps 0x1c364(%rip),%xmm0        # 23400 <fwp_state>
    709c:	f3 0f 7e 0d 64 c3 01 	movq   0x1c364(%rip),%xmm1        # 23408 <fwp_handlers>
    70a3:	00 
    70a4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    70ab:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    70b2:	0f 16 0d 5f c3 01 00 	movhps 0x1c35f(%rip),%xmm1        # 23418 <fwp_cleanups>
    70b9:	f3 0f 7e 05 37 c3 01 	movq   0x1c337(%rip),%xmm0        # 233f8 <fwp_state_len>
    70c0:	00 
    70c1:	0f 16 05 28 c3 01 00 	movhps 0x1c328(%rip),%xmm0        # 233f0 <fwp_state_cap>
    70c8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    70cf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    70d6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    70da:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    70e1:	48 89 0d 20 c3 01 00 	mov    %rcx,0x1c320(%rip)        # 23408 <fwp_handlers>
    70e8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    70ef:	48 89 0d 22 c3 01 00 	mov    %rcx,0x1c322(%rip)        # 23418 <fwp_cleanups>
    70f6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    70fd:	48 89 0d 0c c3 01 00 	mov    %rcx,0x1c30c(%rip)        # 23410 <fwp_foreign_callbacks>
    7104:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    710b:	48 89 0d ee c2 01 00 	mov    %rcx,0x1c2ee(%rip)        # 23400 <fwp_state>
    7112:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7119:	48 89 0d d8 c2 01 00 	mov    %rcx,0x1c2d8(%rip)        # 233f8 <fwp_state_len>
    7120:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7127:	48 89 0d c2 c2 01 00 	mov    %rcx,0x1c2c2(%rip)        # 233f0 <fwp_state_cap>
    712e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7135:	48 89 0d ac c2 01 00 	mov    %rcx,0x1c2ac(%rip)        # 233e8 <fwp_state_owners>
    713c:	e8 4f c3 ff ff       	call   3490 <swapcontext@plt>
    7141:	f3 0f 1e fa          	endbr64
    7145:	e8 e6 fc ff ff       	call   6e30 <fwp_free_zombie>
    714a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7150:	8b 05 d2 9f 01 00    	mov    0x19fd2(%rip),%eax        # 21128 <fwp_slice>
    7156:	85 c0                	test   %eax,%eax
    7158:	74 36                	je     7190 <fwp_block+0x160>
    715a:	48 83 c4 08          	add    $0x8,%rsp
    715e:	c3                   	ret
    715f:	90                   	nop
    7160:	e8 fb dd ff ff       	call   4f60 <fwp_poll_events>
    7165:	48 8b 05 dc a5 01 00 	mov    0x1a5dc(%rip),%rax        # 21748 <fwp_ready_head>
    716c:	48 85 c0             	test   %rax,%rax
    716f:	0f 85 db fe ff ff    	jne    7050 <fwp_block+0x20>
    7175:	eb e9                	jmp    7160 <fwp_block+0x130>
    7177:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    717e:	00 00 
    7180:	48 c7 05 b5 a5 01 00 	movq   $0x0,0x1a5b5(%rip)        # 21740 <fwp_ready_tail>
    7187:	00 00 00 00 
    718b:	e9 d7 fe ff ff       	jmp    7067 <fwp_block+0x37>
    7190:	48 8d 3d 8a 5f 00 00 	lea    0x5f8a(%rip),%rdi        # d121 <_IO_stdin_used+0x121>
    7197:	e8 04 c2 ff ff       	call   33a0 <getenv@plt>
    719c:	ba 10 27 00 00       	mov    $0x2710,%edx
    71a1:	48 85 c0             	test   %rax,%rax
    71a4:	74 05                	je     71ab <fwp_block+0x17b>
    71a6:	80 38 00             	cmpb   $0x0,(%rax)
    71a9:	75 0b                	jne    71b6 <fwp_block+0x186>
    71ab:	89 15 77 9f 01 00    	mov    %edx,0x19f77(%rip)        # 21128 <fwp_slice>
    71b1:	48 83 c4 08          	add    $0x8,%rsp
    71b5:	c3                   	ret
    71b6:	ba 0a 00 00 00       	mov    $0xa,%edx
    71bb:	31 f6                	xor    %esi,%esi
    71bd:	48 89 c7             	mov    %rax,%rdi
    71c0:	e8 8b c3 ff ff       	call   3550 <strtoll@plt>
    71c5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    71c9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    71d0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    71d5:	0f 46 d0             	cmovbe %eax,%edx
    71d8:	eb d1                	jmp    71ab <fwp_block+0x17b>
    71da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000071e0 <fwp_owned_entry161>:
    71e0:	f3 0f 1e fa          	endbr64
    71e4:	41 56                	push   %r14
    71e6:	55                   	push   %rbp
    71e7:	53                   	push   %rbx
    71e8:	48 83 ec 10          	sub    $0x10,%rsp
    71ec:	48 8b 07             	mov    (%rdi),%rax
    71ef:	48 03 47 10          	add    0x10(%rdi),%rax
    71f3:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    71f8:	0f 80 b7 01 00 00    	jo     73b5 <fwp_owned_entry161+0x1d5>
    71fe:	49 89 c6             	mov    %rax,%r14
    7201:	8b 05 1d b9 01 00    	mov    0x1b91d(%rip),%eax        # 22b24 <fwp_heap+0x13a4>
    7207:	48 8d 15 72 a5 01 00 	lea    0x1a572(%rip),%rdx        # 21780 <fwp_heap>
    720e:	85 c0                	test   %eax,%eax
    7210:	0f 84 52 01 00 00    	je     7368 <fwp_owned_entry161+0x188>
    7216:	0f b6 05 05 b5 01 00 	movzbl 0x1b505(%rip),%eax        # 22722 <fwp_heap+0xfa2>
    721d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7224:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7228:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    722c:	48 8b 18             	mov    (%rax),%rbx
    722f:	48 85 db             	test   %rbx,%rbx
    7232:	0f 84 08 01 00 00    	je     7340 <fwp_owned_entry161+0x160>
    7238:	48 8b 13             	mov    (%rbx),%rdx
    723b:	48 f7 d2             	not    %rdx
    723e:	48 89 10             	mov    %rdx,(%rax)
    7241:	48 83 fd 18          	cmp    $0x18,%rbp
    7245:	76 27                	jbe    726e <fwp_owned_entry161+0x8e>
    7247:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    724b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    724f:	31 f6                	xor    %esi,%esi
    7251:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7257:	48 c1 e8 03          	shr    $0x3,%rax
    725b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7262:	00 
    7263:	e8 58 c2 ff ff       	call   34c0 <memset@plt>
    7268:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    726e:	48 89 e8             	mov    %rbp,%rax
    7271:	48 03 05 28 b9 01 00 	add    0x1b928(%rip),%rax        # 22ba0 <fwp_heap+0x1420>
    7278:	0f 82 3c 01 00 00    	jb     73ba <fwp_owned_entry161+0x1da>
    727e:	48 39 05 23 b9 01 00 	cmp    %rax,0x1b923(%rip)        # 22ba8 <fwp_heap+0x1428>
    7285:	48 89 05 14 b9 01 00 	mov    %rax,0x1b914(%rip)        # 22ba0 <fwp_heap+0x1420>
    728c:	73 07                	jae    7295 <fwp_owned_entry161+0xb5>
    728e:	48 89 05 13 b9 01 00 	mov    %rax,0x1b913(%rip)        # 22ba8 <fwp_heap+0x1428>
    7295:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7299:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    729e:	f2 0f 58 0d 12 b9 01 	addsd  0x1b912(%rip),%xmm1        # 22bb8 <fwp_heap+0x1438>
    72a5:	00 
    72a6:	f2 0f 11 0d 0a b9 01 	movsd  %xmm1,0x1b90a(%rip)        # 22bb8 <fwp_heap+0x1438>
    72ad:	00 
    72ae:	48 8b 05 8b 68 00 00 	mov    0x688b(%rip),%rax        # db40 <msg.4+0xc0>
    72b5:	66 49 0f 6e d6       	movq   %r14,%xmm2
    72ba:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    72be:	48 89 03             	mov    %rax,(%rbx)
    72c1:	48 89 d8             	mov    %rbx,%rax
    72c4:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    72c8:	48 8b 15 89 b8 01 00 	mov    0x1b889(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    72cf:	48 2b 05 5a b8 01 00 	sub    0x1b85a(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    72d6:	48 c1 e2 10          	shl    $0x10,%rdx
    72da:	48 39 d0             	cmp    %rdx,%rax
    72dd:	73 53                	jae    7332 <fwp_owned_entry161+0x152>
    72df:	48 89 c2             	mov    %rax,%rdx
    72e2:	48 c1 ea 10          	shr    $0x10,%rdx
    72e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    72ea:	48 8b 15 87 b8 01 00 	mov    0x1b887(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    72f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    72f5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    72f9:	48 85 ed             	test   %rbp,%rbp
    72fc:	74 34                	je     7332 <fwp_owned_entry161+0x152>
    72fe:	0f b6 0a             	movzbl (%rdx),%ecx
    7301:	80 f9 02             	cmp    $0x2,%cl
    7304:	0f 84 86 00 00 00    	je     7390 <fwp_owned_entry161+0x1b0>
    730a:	80 f9 01             	cmp    $0x1,%cl
    730d:	75 23                	jne    7332 <fwp_owned_entry161+0x152>
    730f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7312:	0f b7 c0             	movzwl %ax,%eax
    7315:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7318:	48 0f af c1          	imul   %rcx,%rax
    731c:	48 c1 e8 20          	shr    $0x20,%rax
    7320:	48 39 d0             	cmp    %rdx,%rax
    7323:	73 0d                	jae    7332 <fwp_owned_entry161+0x152>
    7325:	48 01 c5             	add    %rax,%rbp
    7328:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    732c:	74 7a                	je     73a8 <fwp_owned_entry161+0x1c8>
    732e:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7332:	48 83 c4 10          	add    $0x10,%rsp
    7336:	48 89 d8             	mov    %rbx,%rax
    7339:	5b                   	pop    %rbx
    733a:	5d                   	pop    %rbp
    733b:	41 5e                	pop    %r14
    733d:	c3                   	ret
    733e:	66 90                	xchg   %ax,%ax
    7340:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7344:	48 85 db             	test   %rbx,%rbx
    7347:	74 1f                	je     7368 <fwp_owned_entry161+0x188>
    7349:	48 8b 50 10          	mov    0x10(%rax),%rdx
    734d:	48 29 da             	sub    %rbx,%rdx
    7350:	48 39 ea             	cmp    %rbp,%rdx
    7353:	72 13                	jb     7368 <fwp_owned_entry161+0x188>
    7355:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7359:	48 89 50 08          	mov    %rdx,0x8(%rax)
    735d:	e9 df fe ff ff       	jmp    7241 <fwp_owned_entry161+0x61>
    7362:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7368:	31 f6                	xor    %esi,%esi
    736a:	bf 18 00 00 00       	mov    $0x18,%edi
    736f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7375:	e8 d6 e6 ff ff       	call   5a50 <fwp_heap_alloc>
    737a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7380:	48 89 c3             	mov    %rax,%rbx
    7383:	e9 26 ff ff ff       	jmp    72ae <fwp_owned_entry161+0xce>
    7388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    738f:	00 
    7390:	66 85 c0             	test   %ax,%ax
    7393:	74 93                	je     7328 <fwp_owned_entry161+0x148>
    7395:	48 83 c4 10          	add    $0x10,%rsp
    7399:	48 89 d8             	mov    %rbx,%rax
    739c:	5b                   	pop    %rbx
    739d:	5d                   	pop    %rbp
    739e:	41 5e                	pop    %r14
    73a0:	c3                   	ret
    73a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73a8:	48 89 ef             	mov    %rbp,%rdi
    73ab:	e8 60 df ff ff       	call   5310 <fwp_rc_forget_slot>
    73b0:	e9 79 ff ff ff       	jmp    732e <fwp_owned_entry161+0x14e>
    73b5:	e8 46 c3 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    73ba:	e8 f1 c8 ff ff       	call   3cb0 <fwp_heap_oom>
    73bf:	90                   	nop

00000000000073c0 <e161>:
    73c0:	f3 0f 1e fa          	endbr64
    73c4:	41 56                	push   %r14
    73c6:	55                   	push   %rbp
    73c7:	53                   	push   %rbx
    73c8:	48 83 ec 10          	sub    $0x10,%rsp
    73cc:	48 8b 07             	mov    (%rdi),%rax
    73cf:	48 03 47 10          	add    0x10(%rdi),%rax
    73d3:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    73d8:	0f 80 bf 01 00 00    	jo     759d <e161+0x1dd>
    73de:	49 89 c6             	mov    %rax,%r14
    73e1:	8b 05 3d b7 01 00    	mov    0x1b73d(%rip),%eax        # 22b24 <fwp_heap+0x13a4>
    73e7:	48 8d 15 92 a3 01 00 	lea    0x1a392(%rip),%rdx        # 21780 <fwp_heap>
    73ee:	85 c0                	test   %eax,%eax
    73f0:	0f 84 62 01 00 00    	je     7558 <e161+0x198>
    73f6:	0f b6 05 25 b3 01 00 	movzbl 0x1b325(%rip),%eax        # 22722 <fwp_heap+0xfa2>
    73fd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7404:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7408:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    740c:	48 8b 18             	mov    (%rax),%rbx
    740f:	48 85 db             	test   %rbx,%rbx
    7412:	0f 84 18 01 00 00    	je     7530 <e161+0x170>
    7418:	48 8b 13             	mov    (%rbx),%rdx
    741b:	48 f7 d2             	not    %rdx
    741e:	48 89 10             	mov    %rdx,(%rax)
    7421:	48 83 fd 18          	cmp    $0x18,%rbp
    7425:	76 27                	jbe    744e <e161+0x8e>
    7427:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    742b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    742f:	31 f6                	xor    %esi,%esi
    7431:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7437:	48 c1 e8 03          	shr    $0x3,%rax
    743b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7442:	00 
    7443:	e8 78 c0 ff ff       	call   34c0 <memset@plt>
    7448:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    744e:	48 89 e8             	mov    %rbp,%rax
    7451:	48 03 05 48 b7 01 00 	add    0x1b748(%rip),%rax        # 22ba0 <fwp_heap+0x1420>
    7458:	0f 82 44 01 00 00    	jb     75a2 <e161+0x1e2>
    745e:	48 39 05 43 b7 01 00 	cmp    %rax,0x1b743(%rip)        # 22ba8 <fwp_heap+0x1428>
    7465:	48 89 05 34 b7 01 00 	mov    %rax,0x1b734(%rip)        # 22ba0 <fwp_heap+0x1420>
    746c:	73 07                	jae    7475 <e161+0xb5>
    746e:	48 89 05 33 b7 01 00 	mov    %rax,0x1b733(%rip)        # 22ba8 <fwp_heap+0x1428>
    7475:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7479:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    747e:	f2 0f 58 0d 32 b7 01 	addsd  0x1b732(%rip),%xmm1        # 22bb8 <fwp_heap+0x1438>
    7485:	00 
    7486:	f2 0f 11 0d 2a b7 01 	movsd  %xmm1,0x1b72a(%rip)        # 22bb8 <fwp_heap+0x1438>
    748d:	00 
    748e:	48 8b 05 ab 66 00 00 	mov    0x66ab(%rip),%rax        # db40 <msg.4+0xc0>
    7495:	66 49 0f 6e d6       	movq   %r14,%xmm2
    749a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    749e:	48 89 03             	mov    %rax,(%rbx)
    74a1:	48 89 d8             	mov    %rbx,%rax
    74a4:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    74a8:	48 8b 15 a9 b6 01 00 	mov    0x1b6a9(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    74af:	48 2b 05 7a b6 01 00 	sub    0x1b67a(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    74b6:	48 c1 e2 10          	shl    $0x10,%rdx
    74ba:	48 39 d0             	cmp    %rdx,%rax
    74bd:	73 57                	jae    7516 <e161+0x156>
    74bf:	48 89 c2             	mov    %rax,%rdx
    74c2:	48 c1 ea 10          	shr    $0x10,%rdx
    74c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74ca:	48 8b 15 a7 b6 01 00 	mov    0x1b6a7(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    74d1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74d5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    74d9:	48 85 ed             	test   %rbp,%rbp
    74dc:	74 38                	je     7516 <e161+0x156>
    74de:	0f b6 0a             	movzbl (%rdx),%ecx
    74e1:	80 f9 02             	cmp    $0x2,%cl
    74e4:	0f 84 96 00 00 00    	je     7580 <e161+0x1c0>
    74ea:	80 f9 01             	cmp    $0x1,%cl
    74ed:	75 27                	jne    7516 <e161+0x156>
    74ef:	8b 4a 18             	mov    0x18(%rdx),%ecx
    74f2:	0f b7 c0             	movzwl %ax,%eax
    74f5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74f8:	48 0f af c1          	imul   %rcx,%rax
    74fc:	48 c1 e8 20          	shr    $0x20,%rax
    7500:	48 39 d0             	cmp    %rdx,%rax
    7503:	73 11                	jae    7516 <e161+0x156>
    7505:	48 01 c5             	add    %rax,%rbp
    7508:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    750c:	0f 84 7e 00 00 00    	je     7590 <e161+0x1d0>
    7512:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7516:	48 89 df             	mov    %rbx,%rdi
    7519:	e8 32 ef ff ff       	call   6450 <fwp_rc_share>
    751e:	48 83 c4 10          	add    $0x10,%rsp
    7522:	48 89 d8             	mov    %rbx,%rax
    7525:	5b                   	pop    %rbx
    7526:	5d                   	pop    %rbp
    7527:	41 5e                	pop    %r14
    7529:	c3                   	ret
    752a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7530:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7534:	48 85 db             	test   %rbx,%rbx
    7537:	74 1f                	je     7558 <e161+0x198>
    7539:	48 8b 50 10          	mov    0x10(%rax),%rdx
    753d:	48 29 da             	sub    %rbx,%rdx
    7540:	48 39 ea             	cmp    %rbp,%rdx
    7543:	72 13                	jb     7558 <e161+0x198>
    7545:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7549:	48 89 50 08          	mov    %rdx,0x8(%rax)
    754d:	e9 cf fe ff ff       	jmp    7421 <e161+0x61>
    7552:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7558:	31 f6                	xor    %esi,%esi
    755a:	bf 18 00 00 00       	mov    $0x18,%edi
    755f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7565:	e8 e6 e4 ff ff       	call   5a50 <fwp_heap_alloc>
    756a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7570:	48 89 c3             	mov    %rax,%rbx
    7573:	e9 16 ff ff ff       	jmp    748e <e161+0xce>
    7578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    757f:	00 
    7580:	66 85 c0             	test   %ax,%ax
    7583:	75 91                	jne    7516 <e161+0x156>
    7585:	eb 81                	jmp    7508 <e161+0x148>
    7587:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    758e:	00 00 
    7590:	48 89 ef             	mov    %rbp,%rdi
    7593:	e8 78 dd ff ff       	call   5310 <fwp_rc_forget_slot>
    7598:	e9 75 ff ff ff       	jmp    7512 <e161+0x152>
    759d:	e8 5e c1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    75a2:	e8 09 c7 ff ff       	call   3cb0 <fwp_heap_oom>
    75a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75ae:	00 00 

00000000000075b0 <fwp_drop4>:
    75b0:	48 8b 15 a1 b5 01 00 	mov    0x1b5a1(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    75b7:	48 89 f8             	mov    %rdi,%rax
    75ba:	48 2b 05 6f b5 01 00 	sub    0x1b56f(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    75c1:	48 c1 e2 10          	shl    $0x10,%rdx
    75c5:	48 39 d0             	cmp    %rdx,%rax
    75c8:	0f 83 52 01 00 00    	jae    7720 <fwp_drop4+0x170>
    75ce:	48 83 ec 18          	sub    $0x18,%rsp
    75d2:	4c 8d 05 a7 a1 01 00 	lea    0x1a1a7(%rip),%r8        # 21780 <fwp_heap>
    75d9:	48 89 c2             	mov    %rax,%rdx
    75dc:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    75e3:	48 c1 ea 10          	shr    $0x10,%rdx
    75e7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    75eb:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    75ef:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    75f3:	48 85 d2             	test   %rdx,%rdx
    75f6:	74 46                	je     763e <fwp_drop4+0x8e>
    75f8:	44 0f b6 09          	movzbl (%rcx),%r9d
    75fc:	41 80 f9 02          	cmp    $0x2,%r9b
    7600:	0f 84 ca 00 00 00    	je     76d0 <fwp_drop4+0x120>
    7606:	41 80 f9 01          	cmp    $0x1,%r9b
    760a:	75 32                	jne    763e <fwp_drop4+0x8e>
    760c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7610:	0f b7 c0             	movzwl %ax,%eax
    7613:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7616:	49 0f af c1          	imul   %r9,%rax
    761a:	48 c1 e8 20          	shr    $0x20,%rax
    761e:	48 39 c8             	cmp    %rcx,%rax
    7621:	73 1b                	jae    763e <fwp_drop4+0x8e>
    7623:	48 01 c2             	add    %rax,%rdx
    7626:	0f b6 02             	movzbl (%rdx),%eax
    7629:	84 c0                	test   %al,%al
    762b:	74 11                	je     763e <fwp_drop4+0x8e>
    762d:	3c 01                	cmp    $0x1,%al
    762f:	74 17                	je     7648 <fwp_drop4+0x98>
    7631:	3c ff                	cmp    $0xff,%al
    7633:	0f 84 ef 00 00 00    	je     7728 <fwp_drop4+0x178>
    7639:	83 e8 01             	sub    $0x1,%eax
    763c:	88 02                	mov    %al,(%rdx)
    763e:	48 83 c4 18          	add    $0x18,%rsp
    7642:	c3                   	ret
    7643:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7648:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    764c:	0f 88 8e 00 00 00    	js     76e0 <fwp_drop4+0x130>
    7652:	48 8b 15 ff b4 01 00 	mov    0x1b4ff(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    7659:	48 89 f8             	mov    %rdi,%rax
    765c:	48 2b 05 cd b4 01 00 	sub    0x1b4cd(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    7663:	48 c1 e2 10          	shl    $0x10,%rdx
    7667:	48 39 d0             	cmp    %rdx,%rax
    766a:	73 d2                	jae    763e <fwp_drop4+0x8e>
    766c:	48 89 c2             	mov    %rax,%rdx
    766f:	48 c1 ea 10          	shr    $0x10,%rdx
    7673:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7677:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    767b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    767f:	48 85 c9             	test   %rcx,%rcx
    7682:	74 ba                	je     763e <fwp_drop4+0x8e>
    7684:	0f b6 32             	movzbl (%rdx),%esi
    7687:	40 80 fe 02          	cmp    $0x2,%sil
    768b:	74 33                	je     76c0 <fwp_drop4+0x110>
    768d:	40 80 fe 01          	cmp    $0x1,%sil
    7691:	75 ab                	jne    763e <fwp_drop4+0x8e>
    7693:	8b 72 18             	mov    0x18(%rdx),%esi
    7696:	0f b7 c0             	movzwl %ax,%eax
    7699:	8b 52 1c             	mov    0x1c(%rdx),%edx
    769c:	48 0f af c6          	imul   %rsi,%rax
    76a0:	48 c1 e8 20          	shr    $0x20,%rax
    76a4:	48 39 d0             	cmp    %rdx,%rax
    76a7:	73 95                	jae    763e <fwp_drop4+0x8e>
    76a9:	48 01 c1             	add    %rax,%rcx
    76ac:	80 39 01             	cmpb   $0x1,(%rcx)
    76af:	75 8d                	jne    763e <fwp_drop4+0x8e>
    76b1:	48 83 c4 18          	add    $0x18,%rsp
    76b5:	e9 96 de ff ff       	jmp    5550 <fwp_mem_free>
    76ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76c0:	66 85 c0             	test   %ax,%ax
    76c3:	74 e7                	je     76ac <fwp_drop4+0xfc>
    76c5:	48 83 c4 18          	add    $0x18,%rsp
    76c9:	c3                   	ret
    76ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76d0:	66 85 c0             	test   %ax,%ax
    76d3:	0f 84 4d ff ff ff    	je     7626 <fwp_drop4+0x76>
    76d9:	48 83 c4 18          	add    $0x18,%rsp
    76dd:	c3                   	ret
    76de:	66 90                	xchg   %ax,%ax
    76e0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    76e4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    76e9:	e8 e2 ed ff ff       	call   64d0 <fwp_rc_free_arr>
    76ee:	4c 8d 05 8b a0 01 00 	lea    0x1a08b(%rip),%r8        # 21780 <fwp_heap>
    76f5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    76fa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7701:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7708:	48 c1 e2 10          	shl    $0x10,%rdx
    770c:	48 39 d0             	cmp    %rdx,%rax
    770f:	0f 83 29 ff ff ff    	jae    763e <fwp_drop4+0x8e>
    7715:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    771a:	e9 ba fe ff ff       	jmp    75d9 <fwp_drop4+0x29>
    771f:	90                   	nop
    7720:	c3                   	ret
    7721:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7728:	48 89 d0             	mov    %rdx,%rax
    772b:	48 c1 e8 11          	shr    $0x11,%rax
    772f:	48 31 d0             	xor    %rdx,%rax
    7732:	48 89 c1             	mov    %rax,%rcx
    7735:	48 c1 e9 09          	shr    $0x9,%rcx
    7739:	48 31 c8             	xor    %rcx,%rax
    773c:	0f b6 c8             	movzbl %al,%ecx
    773f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7746:	00 
    7747:	48 85 c0             	test   %rax,%rax
    774a:	75 1d                	jne    7769 <fwp_drop4+0x1b9>
    774c:	eb 56                	jmp    77a4 <fwp_drop4+0x1f4>
    774e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    775c:	00 00 00 00 
    7760:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7764:	48 85 c0             	test   %rax,%rax
    7767:	74 3b                	je     77a4 <fwp_drop4+0x1f4>
    7769:	48 89 c1             	mov    %rax,%rcx
    776c:	48 39 10             	cmp    %rdx,(%rax)
    776f:	75 ef                	jne    7760 <fwp_drop4+0x1b0>
    7771:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7775:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7779:	48 89 48 08          	mov    %rcx,0x8(%rax)
    777d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7784:	0f 85 b4 fe ff ff    	jne    763e <fwp_drop4+0x8e>
    778a:	48 89 d7             	mov    %rdx,%rdi
    778d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7792:	e8 79 db ff ff       	call   5310 <fwp_rc_forget_slot>
    7797:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    779c:	c6 02 fe             	movb   $0xfe,(%rdx)
    779f:	e9 9a fe ff ff       	jmp    763e <fwp_drop4+0x8e>
    77a4:	48 8d 3d ed 5f 00 00 	lea    0x5fed(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    77ab:	e8 f0 c9 ff ff       	call   41a0 <fwp_trap>

00000000000077b0 <fwp_caps161>:
    77b0:	f3 0f 1e fa          	endbr64
    77b4:	85 f6                	test   %esi,%esi
    77b6:	74 08                	je     77c0 <fwp_caps161+0x10>
    77b8:	c3                   	ret
    77b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77c0:	48 8b 15 91 b3 01 00 	mov    0x1b391(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    77c7:	48 89 f8             	mov    %rdi,%rax
    77ca:	48 2b 05 5f b3 01 00 	sub    0x1b35f(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    77d1:	48 c1 e2 10          	shl    $0x10,%rdx
    77d5:	48 39 d0             	cmp    %rdx,%rax
    77d8:	73 de                	jae    77b8 <fwp_caps161+0x8>
    77da:	48 89 c2             	mov    %rax,%rdx
    77dd:	48 c1 ea 10          	shr    $0x10,%rdx
    77e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    77e5:	48 8b 15 8c b3 01 00 	mov    0x1b38c(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    77ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    77f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    77f4:	48 85 c9             	test   %rcx,%rcx
    77f7:	74 bf                	je     77b8 <fwp_caps161+0x8>
    77f9:	0f b6 32             	movzbl (%rdx),%esi
    77fc:	40 80 fe 02          	cmp    $0x2,%sil
    7800:	74 2e                	je     7830 <fwp_caps161+0x80>
    7802:	40 80 fe 01          	cmp    $0x1,%sil
    7806:	75 b0                	jne    77b8 <fwp_caps161+0x8>
    7808:	8b 72 18             	mov    0x18(%rdx),%esi
    780b:	0f b7 c0             	movzwl %ax,%eax
    780e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7811:	48 0f af c6          	imul   %rsi,%rax
    7815:	48 c1 e8 20          	shr    $0x20,%rax
    7819:	48 39 d0             	cmp    %rdx,%rax
    781c:	73 9a                	jae    77b8 <fwp_caps161+0x8>
    781e:	48 01 c1             	add    %rax,%rcx
    7821:	80 39 01             	cmpb   $0x1,(%rcx)
    7824:	75 92                	jne    77b8 <fwp_caps161+0x8>
    7826:	e9 25 dd ff ff       	jmp    5550 <fwp_mem_free>
    782b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7830:	66 85 c0             	test   %ax,%ax
    7833:	74 ec                	je     7821 <fwp_caps161+0x71>
    7835:	c3                   	ret
    7836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    783d:	00 00 00 

0000000000007840 <fwp_args12>:
    7840:	f3 0f 1e fa          	endbr64
    7844:	85 d2                	test   %edx,%edx
    7846:	74 04                	je     784c <fwp_args12+0xc>
    7848:	85 f6                	test   %esi,%esi
    784a:	74 04                	je     7850 <fwp_args12+0x10>
    784c:	c3                   	ret
    784d:	0f 1f 00             	nopl   (%rax)
    7850:	48 8b 15 01 b3 01 00 	mov    0x1b301(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    7857:	48 8b 07             	mov    (%rdi),%rax
    785a:	48 2b 05 cf b2 01 00 	sub    0x1b2cf(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    7861:	48 c1 e2 10          	shl    $0x10,%rdx
    7865:	48 39 d0             	cmp    %rdx,%rax
    7868:	73 e2                	jae    784c <fwp_args12+0xc>
    786a:	48 89 c2             	mov    %rax,%rdx
    786d:	48 c1 ea 10          	shr    $0x10,%rdx
    7871:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7875:	48 8b 15 fc b2 01 00 	mov    0x1b2fc(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    787c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7880:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7884:	48 85 ff             	test   %rdi,%rdi
    7887:	74 c3                	je     784c <fwp_args12+0xc>
    7889:	0f b6 0a             	movzbl (%rdx),%ecx
    788c:	80 f9 02             	cmp    $0x2,%cl
    788f:	74 2f                	je     78c0 <fwp_args12+0x80>
    7891:	80 f9 01             	cmp    $0x1,%cl
    7894:	75 b6                	jne    784c <fwp_args12+0xc>
    7896:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7899:	0f b7 c0             	movzwl %ax,%eax
    789c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    789f:	48 0f af c1          	imul   %rcx,%rax
    78a3:	48 c1 e8 20          	shr    $0x20,%rax
    78a7:	48 39 d0             	cmp    %rdx,%rax
    78aa:	73 a0                	jae    784c <fwp_args12+0xc>
    78ac:	48 01 c7             	add    %rax,%rdi
    78af:	0f b6 07             	movzbl (%rdi),%eax
    78b2:	84 c0                	test   %al,%al
    78b4:	74 96                	je     784c <fwp_args12+0xc>
    78b6:	3c fd                	cmp    $0xfd,%al
    78b8:	77 0c                	ja     78c6 <fwp_args12+0x86>
    78ba:	83 c0 01             	add    $0x1,%eax
    78bd:	88 07                	mov    %al,(%rdi)
    78bf:	c3                   	ret
    78c0:	66 85 c0             	test   %ax,%ax
    78c3:	74 ea                	je     78af <fwp_args12+0x6f>
    78c5:	c3                   	ret
    78c6:	e9 25 d9 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    78cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000078d0 <fwp_args23>:
    78d0:	f3 0f 1e fa          	endbr64
    78d4:	85 d2                	test   %edx,%edx
    78d6:	74 04                	je     78dc <fwp_args23+0xc>
    78d8:	85 f6                	test   %esi,%esi
    78da:	74 04                	je     78e0 <fwp_args23+0x10>
    78dc:	c3                   	ret
    78dd:	0f 1f 00             	nopl   (%rax)
    78e0:	48 8b 15 71 b2 01 00 	mov    0x1b271(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    78e7:	48 8b 07             	mov    (%rdi),%rax
    78ea:	48 2b 05 3f b2 01 00 	sub    0x1b23f(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    78f1:	48 c1 e2 10          	shl    $0x10,%rdx
    78f5:	48 39 d0             	cmp    %rdx,%rax
    78f8:	73 e2                	jae    78dc <fwp_args23+0xc>
    78fa:	48 89 c2             	mov    %rax,%rdx
    78fd:	48 c1 ea 10          	shr    $0x10,%rdx
    7901:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7905:	48 8b 15 6c b2 01 00 	mov    0x1b26c(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    790c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7910:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7914:	48 85 ff             	test   %rdi,%rdi
    7917:	74 c3                	je     78dc <fwp_args23+0xc>
    7919:	0f b6 0a             	movzbl (%rdx),%ecx
    791c:	80 f9 02             	cmp    $0x2,%cl
    791f:	74 2f                	je     7950 <fwp_args23+0x80>
    7921:	80 f9 01             	cmp    $0x1,%cl
    7924:	75 b6                	jne    78dc <fwp_args23+0xc>
    7926:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7929:	0f b7 c0             	movzwl %ax,%eax
    792c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    792f:	48 0f af c1          	imul   %rcx,%rax
    7933:	48 c1 e8 20          	shr    $0x20,%rax
    7937:	48 39 d0             	cmp    %rdx,%rax
    793a:	73 a0                	jae    78dc <fwp_args23+0xc>
    793c:	48 01 c7             	add    %rax,%rdi
    793f:	0f b6 07             	movzbl (%rdi),%eax
    7942:	84 c0                	test   %al,%al
    7944:	74 96                	je     78dc <fwp_args23+0xc>
    7946:	3c fd                	cmp    $0xfd,%al
    7948:	77 0c                	ja     7956 <fwp_args23+0x86>
    794a:	83 c0 01             	add    $0x1,%eax
    794d:	88 07                	mov    %al,(%rdi)
    794f:	c3                   	ret
    7950:	66 85 c0             	test   %ax,%ax
    7953:	74 ea                	je     793f <fwp_args23+0x6f>
    7955:	c3                   	ret
    7956:	e9 95 d8 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    795b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007960 <fwp_caps12>:
    7960:	f3 0f 1e fa          	endbr64
    7964:	48 83 ec 18          	sub    $0x18,%rsp
    7968:	8b 57 04             	mov    0x4(%rdi),%edx
    796b:	48 89 f8             	mov    %rdi,%rax
    796e:	85 d2                	test   %edx,%edx
    7970:	0f 84 9a 00 00 00    	je     7a10 <fwp_caps12+0xb0>
    7976:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    797a:	85 f6                	test   %esi,%esi
    797c:	0f 85 9e 00 00 00    	jne    7a20 <fwp_caps12+0xc0>
    7982:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7987:	e8 54 ec ff ff       	call   65e0 <fwp_drop0>
    798c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7991:	48 8b 0d c0 b1 01 00 	mov    0x1b1c0(%rip),%rcx        # 22b58 <fwp_heap+0x13d8>
    7998:	48 89 c2             	mov    %rax,%rdx
    799b:	48 2b 15 8e b1 01 00 	sub    0x1b18e(%rip),%rdx        # 22b30 <fwp_heap+0x13b0>
    79a2:	48 c1 e1 10          	shl    $0x10,%rcx
    79a6:	48 39 ca             	cmp    %rcx,%rdx
    79a9:	73 6d                	jae    7a18 <fwp_caps12+0xb8>
    79ab:	48 89 d1             	mov    %rdx,%rcx
    79ae:	48 c1 e9 10          	shr    $0x10,%rcx
    79b2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    79b6:	48 8b 0d bb b1 01 00 	mov    0x1b1bb(%rip),%rcx        # 22b78 <fwp_heap+0x13f8>
    79bd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    79c1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    79c5:	48 85 f6             	test   %rsi,%rsi
    79c8:	74 4e                	je     7a18 <fwp_caps12+0xb8>
    79ca:	0f b6 39             	movzbl (%rcx),%edi
    79cd:	40 80 ff 02          	cmp    $0x2,%dil
    79d1:	0f 84 b9 00 00 00    	je     7a90 <fwp_caps12+0x130>
    79d7:	40 80 ff 01          	cmp    $0x1,%dil
    79db:	75 3b                	jne    7a18 <fwp_caps12+0xb8>
    79dd:	8b 79 18             	mov    0x18(%rcx),%edi
    79e0:	0f b7 d2             	movzwl %dx,%edx
    79e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    79e6:	48 0f af d7          	imul   %rdi,%rdx
    79ea:	48 c1 ea 20          	shr    $0x20,%rdx
    79ee:	48 39 ca             	cmp    %rcx,%rdx
    79f1:	73 25                	jae    7a18 <fwp_caps12+0xb8>
    79f3:	48 01 d6             	add    %rdx,%rsi
    79f6:	80 3e 01             	cmpb   $0x1,(%rsi)
    79f9:	75 1d                	jne    7a18 <fwp_caps12+0xb8>
    79fb:	48 89 c7             	mov    %rax,%rdi
    79fe:	48 83 c4 18          	add    $0x18,%rsp
    7a02:	e9 49 db ff ff       	jmp    5550 <fwp_mem_free>
    7a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a0e:	00 00 
    7a10:	85 f6                	test   %esi,%esi
    7a12:	0f 84 79 ff ff ff    	je     7991 <fwp_caps12+0x31>
    7a18:	48 83 c4 18          	add    $0x18,%rsp
    7a1c:	c3                   	ret
    7a1d:	0f 1f 00             	nopl   (%rax)
    7a20:	48 8b 05 31 b1 01 00 	mov    0x1b131(%rip),%rax        # 22b58 <fwp_heap+0x13d8>
    7a27:	48 2b 3d 02 b1 01 00 	sub    0x1b102(%rip),%rdi        # 22b30 <fwp_heap+0x13b0>
    7a2e:	48 c1 e0 10          	shl    $0x10,%rax
    7a32:	48 39 c7             	cmp    %rax,%rdi
    7a35:	73 e1                	jae    7a18 <fwp_caps12+0xb8>
    7a37:	48 89 f8             	mov    %rdi,%rax
    7a3a:	48 c1 e8 10          	shr    $0x10,%rax
    7a3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7a42:	48 8b 05 2f b1 01 00 	mov    0x1b12f(%rip),%rax        # 22b78 <fwp_heap+0x13f8>
    7a49:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7a4d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7a51:	48 85 c0             	test   %rax,%rax
    7a54:	74 c2                	je     7a18 <fwp_caps12+0xb8>
    7a56:	0f b6 0a             	movzbl (%rdx),%ecx
    7a59:	80 f9 02             	cmp    $0x2,%cl
    7a5c:	74 42                	je     7aa0 <fwp_caps12+0x140>
    7a5e:	80 f9 01             	cmp    $0x1,%cl
    7a61:	75 b5                	jne    7a18 <fwp_caps12+0xb8>
    7a63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a66:	0f b7 ff             	movzwl %di,%edi
    7a69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a6c:	48 0f af f9          	imul   %rcx,%rdi
    7a70:	48 c1 ef 20          	shr    $0x20,%rdi
    7a74:	48 39 d7             	cmp    %rdx,%rdi
    7a77:	73 9f                	jae    7a18 <fwp_caps12+0xb8>
    7a79:	48 01 f8             	add    %rdi,%rax
    7a7c:	0f b6 10             	movzbl (%rax),%edx
    7a7f:	84 d2                	test   %dl,%dl
    7a81:	74 95                	je     7a18 <fwp_caps12+0xb8>
    7a83:	80 fa fd             	cmp    $0xfd,%dl
    7a86:	77 23                	ja     7aab <fwp_caps12+0x14b>
    7a88:	83 c2 01             	add    $0x1,%edx
    7a8b:	88 10                	mov    %dl,(%rax)
    7a8d:	eb 89                	jmp    7a18 <fwp_caps12+0xb8>
    7a8f:	90                   	nop
    7a90:	66 85 d2             	test   %dx,%dx
    7a93:	0f 85 7f ff ff ff    	jne    7a18 <fwp_caps12+0xb8>
    7a99:	e9 58 ff ff ff       	jmp    79f6 <fwp_caps12+0x96>
    7a9e:	66 90                	xchg   %ax,%ax
    7aa0:	66 85 ff             	test   %di,%di
    7aa3:	0f 85 6f ff ff ff    	jne    7a18 <fwp_caps12+0xb8>
    7aa9:	eb d1                	jmp    7a7c <fwp_caps12+0x11c>
    7aab:	48 89 c7             	mov    %rax,%rdi
    7aae:	48 83 c4 18          	add    $0x18,%rsp
    7ab2:	e9 39 d7 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7ab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7abe:	00 00 

0000000000007ac0 <f12>:
    7ac0:	41 57                	push   %r15
    7ac2:	41 56                	push   %r14
    7ac4:	41 55                	push   %r13
    7ac6:	4c 8d 2d 33 f1 ff ff 	lea    -0xecd(%rip),%r13        # 6c00 <fwp_tape_scope_release>
    7acd:	41 54                	push   %r12
    7acf:	55                   	push   %rbp
    7ad0:	53                   	push   %rbx
    7ad1:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
    7ad8:	48 8b 15 79 b0 01 00 	mov    0x1b079(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    7adf:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    7ae4:	4c 8d 74 24 5c       	lea    0x5c(%rsp),%r14
    7ae9:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
    7aee:	48 c1 e2 10          	shl    $0x10,%rdx
    7af2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7af9:	00 00 
    7afb:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    7b02:	00 
    7b03:	31 c0                	xor    %eax,%eax
    7b05:	48 8b 05 0c b9 01 00 	mov    0x1b90c(%rip),%rax        # 23418 <fwp_cleanups>
    7b0c:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7b13:	ff 
    7b14:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    7b19:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7b1e:	48 8d 05 eb 94 00 00 	lea    0x94eb(%rip),%rax        # 11010 <fc23>
    7b25:	48 2b 05 04 b0 01 00 	sub    0x1b004(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    7b2c:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
    7b31:	4c 89 3d e0 b8 01 00 	mov    %r15,0x1b8e0(%rip)        # 23418 <fwp_cleanups>
    7b38:	48 39 d0             	cmp    %rdx,%rax
    7b3b:	73 5d                	jae    7b9a <f12+0xda>
    7b3d:	48 89 c2             	mov    %rax,%rdx
    7b40:	48 c1 ea 10          	shr    $0x10,%rdx
    7b44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b48:	48 8b 15 29 b0 01 00 	mov    0x1b029(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    7b4f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b53:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7b57:	48 85 ff             	test   %rdi,%rdi
    7b5a:	74 3e                	je     7b9a <f12+0xda>
    7b5c:	0f b6 0a             	movzbl (%rdx),%ecx
    7b5f:	80 f9 02             	cmp    $0x2,%cl
    7b62:	0f 84 78 11 00 00    	je     8ce0 <f12+0x1220>
    7b68:	80 f9 01             	cmp    $0x1,%cl
    7b6b:	75 2d                	jne    7b9a <f12+0xda>
    7b6d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b70:	0f b7 c0             	movzwl %ax,%eax
    7b73:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b76:	48 0f af c1          	imul   %rcx,%rax
    7b7a:	48 c1 e8 20          	shr    $0x20,%rax
    7b7e:	48 39 d0             	cmp    %rdx,%rax
    7b81:	73 17                	jae    7b9a <f12+0xda>
    7b83:	48 01 c7             	add    %rax,%rdi
    7b86:	0f b6 07             	movzbl (%rdi),%eax
    7b89:	84 c0                	test   %al,%al
    7b8b:	74 0d                	je     7b9a <f12+0xda>
    7b8d:	3c fd                	cmp    $0xfd,%al
    7b8f:	0f 87 a7 13 00 00    	ja     8f3c <f12+0x147c>
    7b95:	83 c0 01             	add    $0x1,%eax
    7b98:	88 07                	mov    %al,(%rdi)
    7b9a:	48 8d 3d 6f 94 00 00 	lea    0x946f(%rip),%rdi        # 11010 <fc23>
    7ba1:	e8 2a ed ff ff       	call   68d0 <fwp_closure_drop>
    7ba6:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    7bab:	48 85 c0             	test   %rax,%rax
    7bae:	0f 84 aa 12 00 00    	je     8e5e <f12+0x139e>
    7bb4:	31 d2                	xor    %edx,%edx
    7bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7bbd:	00 00 00 
    7bc0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7bc4:	48 83 c2 01          	add    $0x1,%rdx
    7bc8:	48 85 c0             	test   %rax,%rax
    7bcb:	75 f3                	jne    7bc0 <f12+0x100>
    7bcd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    7bd4:	0f 87 31 14 00 00    	ja     900b <f12+0x154b>
    7bda:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    7bdf:	44 8b 05 9a 94 00 00 	mov    0x949a(%rip),%r8d        # 11080 <registered_finish.0>
    7be6:	45 85 c0             	test   %r8d,%r8d
    7be9:	0f 84 c1 10 00 00    	je     8cb0 <f12+0x11f0>
    7bef:	48 8b 1d 02 95 01 00 	mov    0x19502(%rip),%rbx        # 210f8 <fwp_tape_next_slot>
    7bf6:	4c 8b 25 0b 95 01 00 	mov    0x1950b(%rip),%r12        # 21108 <fwp_ntapes>
    7bfd:	4c 39 e3             	cmp    %r12,%rbx
    7c00:	0f 8d ea 00 00 00    	jge    7cf0 <f12+0x230>
    7c06:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7c0a:	48 03 05 ff 94 01 00 	add    0x194ff(%rip),%rax        # 21110 <fwp_tapes>
    7c11:	0f 1f 40 00          	nopl   0x0(%rax)
    7c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c1c:	00 00 00 00 
    7c20:	8b 78 04             	mov    0x4(%rax),%edi
    7c23:	85 ff                	test   %edi,%edi
    7c25:	75 0c                	jne    7c33 <f12+0x173>
    7c27:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7c2d:	0f 86 bd 00 00 00    	jbe    7cf0 <f12+0x230>
    7c33:	48 83 c3 01          	add    $0x1,%rbx
    7c37:	48 83 c0 68          	add    $0x68,%rax
    7c3b:	4c 39 e3             	cmp    %r12,%rbx
    7c3e:	75 e0                	jne    7c20 <f12+0x160>
    7c40:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    7c47:	0f 8f 3c 14 00 00    	jg     9089 <f12+0x15c9>
    7c4d:	4c 39 25 ac 94 01 00 	cmp    %r12,0x194ac(%rip)        # 21100 <fwp_tapes_cap>
    7c54:	48 8b 2d b5 94 01 00 	mov    0x194b5(%rip),%rbp        # 21110 <fwp_tapes>
    7c5b:	75 53                	jne    7cb0 <f12+0x1f0>
    7c5d:	4d 85 e4             	test   %r12,%r12
    7c60:	0f 84 5a 12 00 00    	je     8ec0 <f12+0x1400>
    7c66:	4b 8d 0c 24          	lea    (%r12,%r12,1),%rcx
    7c6a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7c6f:	48 39 c1             	cmp    %rax,%rcx
    7c72:	48 0f 4f c8          	cmovg  %rax,%rcx
    7c76:	48 6b f1 68          	imul   $0x68,%rcx,%rsi
    7c7a:	48 89 ef             	mov    %rbp,%rdi
    7c7d:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    7c82:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    7c87:	e8 44 b9 ff ff       	call   35d0 <realloc@plt>
    7c8c:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    7c91:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    7c96:	48 85 c0             	test   %rax,%rax
    7c99:	48 89 c5             	mov    %rax,%rbp
    7c9c:	0f 84 ad 13 00 00    	je     904f <f12+0x158f>
    7ca2:	48 89 05 67 94 01 00 	mov    %rax,0x19467(%rip)        # 21110 <fwp_tapes>
    7ca9:	48 89 0d 50 94 01 00 	mov    %rcx,0x19450(%rip)        # 21100 <fwp_tapes_cap>
    7cb0:	49 6b c4 68          	imul   $0x68,%r12,%rax
    7cb4:	49 83 c4 01          	add    $0x1,%r12
    7cb8:	48 01 e8             	add    %rbp,%rax
    7cbb:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7cbf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7cc6:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7cca:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7cd1:	00 
    7cd2:	48 29 f8             	sub    %rdi,%rax
    7cd5:	8d 48 68             	lea    0x68(%rax),%ecx
    7cd8:	31 c0                	xor    %eax,%eax
    7cda:	c1 e9 03             	shr    $0x3,%ecx
    7cdd:	f3 48 ab             	rep stos %rax,(%rdi)
    7ce0:	4c 89 25 21 94 01 00 	mov    %r12,0x19421(%rip)        # 21108 <fwp_ntapes>
    7ce7:	eb 17                	jmp    7d00 <f12+0x240>
    7ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cf0:	4c 39 e3             	cmp    %r12,%rbx
    7cf3:	0f 84 47 ff ff ff    	je     7c40 <f12+0x180>
    7cf9:	48 8b 2d 10 94 01 00 	mov    0x19410(%rip),%rbp        # 21110 <fwp_tapes>
    7d00:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    7d04:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7d08:	48 8d 3d b0 53 00 00 	lea    0x53b0(%rip),%rdi        # d0bf <_IO_stdin_used+0xbf>
    7d0f:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7d13:	49 01 ec             	add    %rbp,%r12
    7d16:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    7d1d:	00 00 
    7d1f:	e8 7c b6 ff ff       	call   33a0 <getenv@plt>
    7d24:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    7d29:	48 85 c0             	test   %rax,%rax
    7d2c:	74 09                	je     7d37 <f12+0x277>
    7d2e:	80 38 30             	cmpb   $0x30,(%rax)
    7d31:	0f 84 f9 06 00 00    	je     8430 <f12+0x970>
    7d37:	48 83 3d 69 93 01 00 	cmpq   $0x0,0x19369(%rip)        # 210a8 <fwp_tape_cached_bytes>
    7d3e:	00 
    7d3f:	0f 85 fb 0f 00 00    	jne    8d40 <f12+0x1280>
    7d45:	41 8b 04 24          	mov    (%r12),%eax
    7d49:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    7d4d:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    7d54:	00 00 
    7d56:	48 89 3d 9b 93 01 00 	mov    %rdi,0x1939b(%rip)        # 210f8 <fwp_tape_next_slot>
    7d5d:	8d 70 01             	lea    0x1(%rax),%esi
    7d60:	48 8b 05 b1 b6 01 00 	mov    0x1b6b1(%rip),%rax        # 23418 <fwp_cleanups>
    7d67:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    7d6e:	00 00 
    7d70:	41 89 34 24          	mov    %esi,(%r12)
    7d74:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    7d7b:	ff ff 
    7d7d:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    7d83:	48 85 c0             	test   %rax,%rax
    7d86:	75 14                	jne    7d9c <f12+0x2dc>
    7d88:	e9 f0 12 00 00       	jmp    907d <f12+0x15bd>
    7d8d:	0f 1f 00             	nopl   (%rax)
    7d90:	48 8b 00             	mov    (%rax),%rax
    7d93:	48 85 c0             	test   %rax,%rax
    7d96:	0f 84 e1 12 00 00    	je     907d <f12+0x15bd>
    7d9c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    7da0:	75 ee                	jne    7d90 <f12+0x2d0>
    7da2:	48 8b 48 10          	mov    0x10(%rax),%rcx
    7da6:	41 89 d8             	mov    %ebx,%r8d
    7da9:	48 63 01             	movslq (%rcx),%rax
    7dac:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    7db1:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    7db6:	85 c0                	test   %eax,%eax
    7db8:	78 08                	js     7dc2 <f12+0x302>
    7dba:	48 6b c0 68          	imul   $0x68,%rax,%rax
    7dbe:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    7dc2:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
    7dc7:	44 89 01             	mov    %r8d,(%rcx)
    7dca:	31 c9                	xor    %ecx,%ecx
    7dcc:	48 89 d8             	mov    %rbx,%rax
    7dcf:	48 85 db             	test   %rbx,%rbx
    7dd2:	0f 84 d8 0d 00 00    	je     8bb0 <f12+0x10f0>
    7dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7ddf:	00 
    7de0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7de4:	48 83 c1 01          	add    $0x1,%rcx
    7de8:	48 85 c0             	test   %rax,%rax
    7deb:	75 f3                	jne    7de0 <f12+0x320>
    7ded:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    7df2:	0f 1f 00             	nopl   (%rax)
    7df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7dfc:	00 00 00 00 
    7e00:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7e04:	48 83 c0 01          	add    $0x1,%rax
    7e08:	48 85 d2             	test   %rdx,%rdx
    7e0b:	75 f3                	jne    7e00 <f12+0x340>
    7e0d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    7e14:	ff ff 1f 
    7e17:	48 39 c2             	cmp    %rax,%rdx
    7e1a:	0f 82 f7 11 00 00    	jb     9017 <f12+0x1557>
    7e20:	48 85 c9             	test   %rcx,%rcx
    7e23:	0f 8e 87 0d 00 00    	jle    8bb0 <f12+0x10f0>
    7e29:	48 39 c1             	cmp    %rax,%rcx
    7e2c:	48 0f 46 c1          	cmovbe %rcx,%rax
    7e30:	49 89 c5             	mov    %rax,%r13
    7e33:	48 c1 e8 3c          	shr    $0x3c,%rax
    7e37:	0f 85 da 11 00 00    	jne    9017 <f12+0x1557>
    7e3d:	48 c1 e6 10          	shl    $0x10,%rsi
    7e41:	4b 8d 6c 2d 00       	lea    0x0(%r13,%r13,1),%rbp
    7e46:	48 09 fe             	or     %rdi,%rsi
    7e49:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7e50:	00 
    7e51:	49 89 f4             	mov    %rsi,%r12
    7e54:	be 02 00 00 00       	mov    $0x2,%esi
    7e59:	e8 f2 db ff ff       	call   5a50 <fwp_heap_alloc>
    7e5e:	48 89 28             	mov    %rbp,(%rax)
    7e61:	48 8b 15 f0 ac 01 00 	mov    0x1acf0(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    7e68:	48 89 c3             	mov    %rax,%rbx
    7e6b:	48 2b 05 be ac 01 00 	sub    0x1acbe(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    7e72:	48 c1 e2 10          	shl    $0x10,%rdx
    7e76:	48 39 d0             	cmp    %rdx,%rax
    7e79:	0f 83 c9 0d 00 00    	jae    8c48 <f12+0x1188>
    7e7f:	48 89 c2             	mov    %rax,%rdx
    7e82:	48 c1 ea 10          	shr    $0x10,%rdx
    7e86:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e8a:	48 8b 15 e7 ac 01 00 	mov    0x1ace7(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    7e91:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7e95:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7e99:	48 85 d2             	test   %rdx,%rdx
    7e9c:	74 38                	je     7ed6 <f12+0x416>
    7e9e:	0f b6 31             	movzbl (%rcx),%esi
    7ea1:	40 80 fe 02          	cmp    $0x2,%sil
    7ea5:	0f 84 72 0d 00 00    	je     8c1d <f12+0x115d>
    7eab:	40 80 fe 01          	cmp    $0x1,%sil
    7eaf:	75 25                	jne    7ed6 <f12+0x416>
    7eb1:	8b 71 18             	mov    0x18(%rcx),%esi
    7eb4:	0f b7 c0             	movzwl %ax,%eax
    7eb7:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7eba:	48 0f af c6          	imul   %rsi,%rax
    7ebe:	48 c1 e8 20          	shr    $0x20,%rax
    7ec2:	48 39 c8             	cmp    %rcx,%rax
    7ec5:	73 0f                	jae    7ed6 <f12+0x416>
    7ec7:	48 01 c2             	add    %rax,%rdx
    7eca:	80 3a ff             	cmpb   $0xff,(%rdx)
    7ecd:	0f 84 fc 0f 00 00    	je     8ecf <f12+0x140f>
    7ed3:	c6 02 01             	movb   $0x1,(%rdx)
    7ed6:	4d 85 ed             	test   %r13,%r13
    7ed9:	74 58                	je     7f33 <f12+0x473>
    7edb:	4c 89 e1             	mov    %r12,%rcx
    7ede:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    7ee3:	31 c0                	xor    %eax,%eax
    7ee5:	48 c1 e1 20          	shl    $0x20,%rcx
    7ee9:	90                   	nop
    7eea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ef1:	00 00 00 00 
    7ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7efc:	00 00 00 00 
    7f00:	48 89 c6             	mov    %rax,%rsi
    7f03:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    7f08:	48 01 ce             	add    %rcx,%rsi
    7f0b:	0f 80 ed 10 00 00    	jo     8ffe <f12+0x153e>
    7f11:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    7f16:	48 89 c6             	mov    %rax,%rsi
    7f19:	48 83 c0 01          	add    $0x1,%rax
    7f1d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    7f21:	48 c1 e6 04          	shl    $0x4,%rsi
    7f25:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    7f2a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7f2e:	4c 39 e8             	cmp    %r13,%rax
    7f31:	72 cd                	jb     7f00 <f12+0x440>
    7f33:	48 8b 03             	mov    (%rbx),%rax
    7f36:	48 d1 e8             	shr    $1,%rax
    7f39:	0f 84 21 0d 00 00    	je     8c60 <f12+0x11a0>
    7f3f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7f43:	48 89 d1             	mov    %rdx,%rcx
    7f46:	48 c1 e9 3c          	shr    $0x3c,%rcx
    7f4a:	0f 85 c7 10 00 00    	jne    9017 <f12+0x1557>
    7f50:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    7f54:	48 89 0c 24          	mov    %rcx,(%rsp)
    7f58:	48 85 d2             	test   %rdx,%rdx
    7f5b:	74 40                	je     7f9d <f12+0x4dd>
    7f5d:	48 c1 e0 04          	shl    $0x4,%rax
    7f61:	48 8d 6b 08          	lea    0x8(%rbx),%rbp
    7f65:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    7f6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f70:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    7f75:	48 8b 75 18          	mov    0x18(%rbp),%rsi
    7f79:	48 83 c5 10          	add    $0x10,%rbp
    7f7d:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
    7f81:	f2 0f 10 4d 00       	movsd  0x0(%rbp),%xmm1
    7f86:	e8 a5 e1 ff ff       	call   6130 <w107>
    7f8b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    7f90:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    7f94:	0f 11 45 f0          	movups %xmm0,-0x10(%rbp)
    7f98:	49 39 ed             	cmp    %rbp,%r13
    7f9b:	75 d3                	jne    7f70 <f12+0x4b0>
    7f9d:	48 8b 04 24          	mov    (%rsp),%rax
    7fa1:	48 89 df             	mov    %rbx,%rdi
    7fa4:	48 89 03             	mov    %rax,(%rbx)
    7fa7:	e8 f4 e2 ff ff       	call   62a0 <w164.constprop.0>
    7fac:	48 89 df             	mov    %rbx,%rdi
    7faf:	49 63 dc             	movslq %r12d,%rbx
    7fb2:	49 89 c5             	mov    %rax,%r13
    7fb5:	e8 f6 f5 ff ff       	call   75b0 <fwp_drop4>
    7fba:	48 89 df             	mov    %rbx,%rdi
    7fbd:	e8 be c4 ff ff       	call   4480 <fwp_tape_of>
    7fc2:	48 89 c6             	mov    %rax,%rsi
    7fc5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    7fca:	0f 85 ca 10 00 00    	jne    909a <f12+0x15da>
    7fd0:	48 89 c7             	mov    %rax,%rdi
    7fd3:	e8 28 bc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7fd8:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    7fdc:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7fe1:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7fe8:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    7fec:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    7ff0:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    7ff5:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    7ffa:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    7fff:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    8003:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8007:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    800d:	77 19                	ja     8028 <f12+0x568>
    800f:	41 0f b7 c4          	movzwl %r12w,%eax
    8013:	83 e8 01             	sub    $0x1,%eax
    8016:	48 98                	cltq
    8018:	48 3b 05 d9 90 01 00 	cmp    0x190d9(%rip),%rax        # 210f8 <fwp_tape_next_slot>
    801f:	7d 07                	jge    8028 <f12+0x568>
    8021:	48 89 05 d0 90 01 00 	mov    %rax,0x190d0(%rip)        # 210f8 <fwp_tape_next_slot>
    8028:	48 8b 05 e9 b3 01 00 	mov    0x1b3e9(%rip),%rax        # 23418 <fwp_cleanups>
    802f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8033:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    803a:	00 
    803b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8042:	00 
    8043:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8047:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    804e:	00 
    804f:	48 8d 05 da cd ff ff 	lea    -0x3226(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    8056:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    805d:	00 
    805e:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8065:	00 
    8066:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    806a:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    806e:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8075:	00 
    8076:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    807d:	00 
    807e:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    8085:	00 
    8086:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    808d:	00 
    808e:	48 89 05 83 b3 01 00 	mov    %rax,0x1b383(%rip)        # 23418 <fwp_cleanups>
    8095:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    809c:	00 
    809d:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    80a4:	00 
    80a5:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    80ac:	00 
    80ad:	4d 85 ed             	test   %r13,%r13
    80b0:	0f 88 3a 0c 00 00    	js     8cf0 <f12+0x1230>
    80b6:	4c 89 e8             	mov    %r13,%rax
    80b9:	48 c1 f8 20          	sar    $0x20,%rax
    80bd:	48 39 c3             	cmp    %rax,%rbx
    80c0:	0f 85 1b 0f 00 00    	jne    8fe1 <f12+0x1521>
    80c6:	45 89 ea             	mov    %r13d,%r10d
    80c9:	4c 89 d3             	mov    %r10,%rbx
    80cc:	4c 39 d7             	cmp    %r10,%rdi
    80cf:	0f 8e 00 0f 00 00    	jle    8fd5 <f12+0x1515>
    80d5:	4c 39 d5             	cmp    %r10,%rbp
    80d8:	0f 8e 92 0b 00 00    	jle    8c70 <f12+0x11b0>
    80de:	48 39 d5             	cmp    %rdx,%rbp
    80e1:	0f 8e d1 0c 00 00    	jle    8db8 <f12+0x12f8>
    80e7:	49 89 e9             	mov    %rbp,%r9
    80ea:	48 85 d2             	test   %rdx,%rdx
    80ed:	49 0f 44 d1          	cmove  %r9,%rdx
    80f1:	eb 22                	jmp    8115 <f12+0x655>
    80f3:	66 90                	xchg   %ax,%ax
    80f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80fc:	00 00 00 00 
    8100:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    8104:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    810b:	4c 89 c8             	mov    %r9,%rax
    810e:	48 0f 4c c6          	cmovl  %rsi,%rax
    8112:	48 89 c2             	mov    %rax,%rdx
    8115:	49 39 d1             	cmp    %rdx,%r9
    8118:	7f e6                	jg     8100 <f12+0x640>
    811a:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    811f:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8124:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8129:	48 85 c9             	test   %rcx,%rcx
    812c:	0f 84 fe 0c 00 00    	je     8e30 <f12+0x1370>
    8132:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    8139:	00 
    813a:	48 89 cf             	mov    %rcx,%rdi
    813d:	48 89 14 24          	mov    %rdx,(%rsp)
    8141:	e8 8a b4 ff ff       	call   35d0 <realloc@plt>
    8146:	48 8b 14 24          	mov    (%rsp),%rdx
    814a:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    814f:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8155:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    815b:	48 89 c1             	mov    %rax,%rcx
    815e:	48 85 c9             	test   %rcx,%rcx
    8161:	0f 84 c8 0e 00 00    	je     902f <f12+0x156f>
    8167:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    816e:	00 
    816f:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
    8176:	00 
    8177:	4d 85 c9             	test   %r9,%r9
    817a:	0f 85 7d 0d 00 00    	jne    8efd <f12+0x143d>
    8180:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8187:	4d 85 ed             	test   %r13,%r13
    818a:	78 17                	js     81a3 <f12+0x6e3>
    818c:	45 89 ea             	mov    %r13d,%r10d
    818f:	f2 0f 10 05 99 59 00 	movsd  0x5999(%rip),%xmm0        # db30 <msg.4+0xb0>
    8196:	00 
    8197:	f2 42 0f 58 04 d1    	addsd  (%rcx,%r10,8),%xmm0
    819d:	f2 42 0f 11 04 d1    	movsd  %xmm0,(%rcx,%r10,8)
    81a3:	48 39 dd             	cmp    %rbx,%rbp
    81a6:	0f 8f 8e 00 00 00    	jg     823a <f12+0x77a>
    81ac:	0f 12 f3             	movhlps %xmm3,%xmm6
    81af:	66 48 0f 7e de       	movq   %xmm3,%rsi
    81b4:	0f 12 da             	movhlps %xmm2,%xmm3
    81b7:	48 29 eb             	sub    %rbp,%rbx
    81ba:	66 49 0f 7e db       	movq   %xmm3,%r11
    81bf:	66 48 0f 7e f7       	movq   %xmm6,%rdi
    81c4:	66 49 0f 7e d2       	movq   %xmm2,%r10
    81c9:	4c 8d 0c e9          	lea    (%rcx,%rbp,8),%r9
    81cd:	49 8d 14 db          	lea    (%r11,%rbx,8),%rdx
    81d1:	66 0f ef d2          	pxor   %xmm2,%xmm2
    81d5:	48 29 fe             	sub    %rdi,%rsi
    81d8:	48 8d 04 9f          	lea    (%rdi,%rbx,4),%rax
    81dc:	4d 29 d9             	sub    %r11,%r9
    81df:	4d 29 da             	sub    %r11,%r10
    81e2:	eb 08                	jmp    81ec <f12+0x72c>
    81e4:	0f 1f 40 00          	nopl   0x0(%rax)
    81e8:	48 83 e8 04          	sub    $0x4,%rax
    81ec:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    81f2:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    81f6:	7a 02                	jp     81fa <f12+0x73a>
    81f8:	74 37                	je     8231 <f12+0x771>
    81fa:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    81fe:	45 85 db             	test   %r11d,%r11d
    8201:	78 16                	js     8219 <f12+0x759>
    8203:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8209:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    820d:	f2 42 0f 58 0c d9    	addsd  (%rcx,%r11,8),%xmm1
    8213:	f2 42 0f 11 0c d9    	movsd  %xmm1,(%rcx,%r11,8)
    8219:	4c 63 18             	movslq (%rax),%r11
    821c:	45 85 db             	test   %r11d,%r11d
    821f:	78 10                	js     8231 <f12+0x771>
    8221:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8225:	f2 42 0f 58 04 d9    	addsd  (%rcx,%r11,8),%xmm0
    822b:	f2 42 0f 11 04 d9    	movsd  %xmm0,(%rcx,%r11,8)
    8231:	48 83 ea 08          	sub    $0x8,%rdx
    8235:	48 39 c7             	cmp    %rax,%rdi
    8238:	75 ae                	jne    81e8 <f12+0x728>
    823a:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8241:	ff ff 1f 
    8244:	48 39 e8             	cmp    %rbp,%rax
    8247:	0f 82 d6 0d 00 00    	jb     9023 <f12+0x1563>
    824d:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8254:	00 
    8255:	be 02 00 00 00       	mov    $0x2,%esi
    825a:	48 89 0c 24          	mov    %rcx,(%rsp)
    825e:	e8 ed d7 ff ff       	call   5a50 <fwp_heap_alloc>
    8263:	48 8b 0c 24          	mov    (%rsp),%rcx
    8267:	48 89 28             	mov    %rbp,(%rax)
    826a:	48 89 c3             	mov    %rax,%rbx
    826d:	31 c0                	xor    %eax,%eax
    826f:	48 85 ed             	test   %rbp,%rbp
    8272:	74 1e                	je     8292 <f12+0x7d2>
    8274:	90                   	nop
    8275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    827c:	00 00 00 00 
    8280:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    8284:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    8289:	48 83 c0 01          	add    $0x1,%rax
    828d:	48 39 c5             	cmp    %rax,%rbp
    8290:	75 ee                	jne    8280 <f12+0x7c0>
    8292:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    8299:	00 
    829a:	4c 89 e7             	mov    %r12,%rdi
    829d:	4c 89 2d 74 b1 01 00 	mov    %r13,0x1b174(%rip)        # 23418 <fwp_cleanups>
    82a4:	e8 87 cb ff ff       	call   4e30 <fwp_tape_buffers_release>
    82a9:	48 8b 15 a8 a8 01 00 	mov    0x1a8a8(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    82b0:	48 89 d8             	mov    %rbx,%rax
    82b3:	48 2b 05 76 a8 01 00 	sub    0x1a876(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    82ba:	48 c1 e2 10          	shl    $0x10,%rdx
    82be:	48 39 d0             	cmp    %rdx,%rax
    82c1:	73 59                	jae    831c <f12+0x85c>
    82c3:	48 89 c2             	mov    %rax,%rdx
    82c6:	48 c1 ea 10          	shr    $0x10,%rdx
    82ca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82ce:	48 8b 15 a3 a8 01 00 	mov    0x1a8a3(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    82d5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82d9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    82dd:	4d 85 e4             	test   %r12,%r12
    82e0:	74 3a                	je     831c <f12+0x85c>
    82e2:	0f b6 0a             	movzbl (%rdx),%ecx
    82e5:	80 f9 02             	cmp    $0x2,%cl
    82e8:	0f 84 32 0a 00 00    	je     8d20 <f12+0x1260>
    82ee:	80 f9 01             	cmp    $0x1,%cl
    82f1:	75 29                	jne    831c <f12+0x85c>
    82f3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    82f6:	0f b7 c0             	movzwl %ax,%eax
    82f9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    82fc:	48 0f af c1          	imul   %rcx,%rax
    8300:	48 c1 e8 20          	shr    $0x20,%rax
    8304:	48 39 d0             	cmp    %rdx,%rax
    8307:	73 13                	jae    831c <f12+0x85c>
    8309:	49 01 c4             	add    %rax,%r12
    830c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8311:	0f 84 cd 0b 00 00    	je     8ee4 <f12+0x1424>
    8317:	41 c6 04 24 01       	movb   $0x1,(%r12)
    831c:	4d 39 fd             	cmp    %r15,%r13
    831f:	0f 85 26 b4 ff ff    	jne    374b <f12.cold>
    8325:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    832a:	4c 89 f7             	mov    %r14,%rdi
    832d:	48 89 05 e4 b0 01 00 	mov    %rax,0x1b0e4(%rip)        # 23418 <fwp_cleanups>
    8334:	e8 c7 e8 ff ff       	call   6c00 <fwp_tape_scope_release>
    8339:	48 8b 03             	mov    (%rbx),%rax
    833c:	49 89 c4             	mov    %rax,%r12
    833f:	49 0f ba f4 3f       	btr    $0x3f,%r12
    8344:	48 85 c0             	test   %rax,%rax
    8347:	0f 88 b3 07 00 00    	js     8b00 <f12+0x1040>
    834d:	48 8b 15 04 a8 01 00 	mov    0x1a804(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    8354:	48 89 d8             	mov    %rbx,%rax
    8357:	48 2b 05 d2 a7 01 00 	sub    0x1a7d2(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    835e:	48 c1 e2 10          	shl    $0x10,%rdx
    8362:	48 39 d0             	cmp    %rdx,%rax
    8365:	0f 83 95 07 00 00    	jae    8b00 <f12+0x1040>
    836b:	48 89 c2             	mov    %rax,%rdx
    836e:	48 c1 ea 10          	shr    $0x10,%rdx
    8372:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8376:	48 8b 15 fb a7 01 00 	mov    0x1a7fb(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    837d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8381:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8385:	48 85 c9             	test   %rcx,%rcx
    8388:	0f 84 72 07 00 00    	je     8b00 <f12+0x1040>
    838e:	0f b6 32             	movzbl (%rdx),%esi
    8391:	40 80 fe 02          	cmp    $0x2,%sil
    8395:	0f 84 55 07 00 00    	je     8af0 <f12+0x1030>
    839b:	40 80 fe 01          	cmp    $0x1,%sil
    839f:	0f 85 5b 07 00 00    	jne    8b00 <f12+0x1040>
    83a5:	8b 72 18             	mov    0x18(%rdx),%esi
    83a8:	0f b7 c0             	movzwl %ax,%eax
    83ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83ae:	48 0f af c6          	imul   %rsi,%rax
    83b2:	48 c1 e8 20          	shr    $0x20,%rax
    83b6:	48 39 d0             	cmp    %rdx,%rax
    83b9:	0f 83 41 07 00 00    	jae    8b00 <f12+0x1040>
    83bf:	48 01 c1             	add    %rax,%rcx
    83c2:	80 39 01             	cmpb   $0x1,(%rcx)
    83c5:	0f 85 35 07 00 00    	jne    8b00 <f12+0x1040>
    83cb:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
    83d0:	49 89 dd             	mov    %rbx,%r13
    83d3:	31 ff                	xor    %edi,%edi
    83d5:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    83da:	f2 0f 10 0d 66 57 00 	movsd  0x5766(%rip),%xmm1        # db48 <msg.4+0xc8>
    83e1:	00 
    83e2:	48 8d 50 08          	lea    0x8(%rax),%rdx
    83e6:	31 c0                	xor    %eax,%eax
    83e8:	4d 85 e4             	test   %r12,%r12
    83eb:	75 29                	jne    8416 <f12+0x956>
    83ed:	eb 51                	jmp    8440 <f12+0x980>
    83ef:	90                   	nop
    83f0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    83f5:	0f 88 f7 0b 00 00    	js     8ff2 <f12+0x1532>
    83fb:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8400:	48 83 c0 01          	add    $0x1,%rax
    8404:	48 83 c2 08          	add    $0x8,%rdx
    8408:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    840c:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8411:	49 39 c4             	cmp    %rax,%r12
    8414:	74 2a                	je     8440 <f12+0x980>
    8416:	48 8d 4b 08          	lea    0x8(%rbx),%rcx
    841a:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    841e:	79 d0                	jns    83f0 <f12+0x930>
    8420:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    8424:	eb ca                	jmp    83f0 <f12+0x930>
    8426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    842d:	00 00 00 
    8430:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8434:	0f 84 0b f9 ff ff    	je     7d45 <f12+0x285>
    843a:	e9 f8 f8 ff ff       	jmp    7d37 <f12+0x277>
    843f:	90                   	nop
    8440:	e8 6b f1 ff ff       	call   75b0 <fwp_drop4>
    8445:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    844a:	31 d2                	xor    %edx,%edx
    844c:	48 89 c8             	mov    %rcx,%rax
    844f:	48 85 c9             	test   %rcx,%rcx
    8452:	0f 84 0f 0a 00 00    	je     8e67 <f12+0x13a7>
    8458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    845f:	00 
    8460:	48 8b 40 10          	mov    0x10(%rax),%rax
    8464:	48 83 c2 01          	add    $0x1,%rdx
    8468:	48 85 c0             	test   %rax,%rax
    846b:	75 f3                	jne    8460 <f12+0x9a0>
    846d:	49 8b 45 00          	mov    0x0(%r13),%rax
    8471:	49 89 c7             	mov    %rax,%r15
    8474:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8479:	48 85 c0             	test   %rax,%rax
    847c:	0f 88 d3 05 00 00    	js     8a55 <f12+0xf95>
    8482:	48 8b 0d cf a6 01 00 	mov    0x1a6cf(%rip),%rcx        # 22b58 <fwp_heap+0x13d8>
    8489:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    848e:	48 2b 05 9b a6 01 00 	sub    0x1a69b(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    8495:	48 c1 e1 10          	shl    $0x10,%rcx
    8499:	48 39 c8             	cmp    %rcx,%rax
    849c:	0f 83 b3 05 00 00    	jae    8a55 <f12+0xf95>
    84a2:	48 89 c1             	mov    %rax,%rcx
    84a5:	48 c1 e9 10          	shr    $0x10,%rcx
    84a9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    84ad:	48 8b 0d c4 a6 01 00 	mov    0x1a6c4(%rip),%rcx        # 22b78 <fwp_heap+0x13f8>
    84b4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    84b8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    84bc:	48 85 ff             	test   %rdi,%rdi
    84bf:	0f 84 90 05 00 00    	je     8a55 <f12+0xf95>
    84c5:	0f b6 0e             	movzbl (%rsi),%ecx
    84c8:	80 f9 02             	cmp    $0x2,%cl
    84cb:	0f 84 6f 05 00 00    	je     8a40 <f12+0xf80>
    84d1:	80 f9 01             	cmp    $0x1,%cl
    84d4:	0f 85 6f 05 00 00    	jne    8a49 <f12+0xf89>
    84da:	8b 4e 18             	mov    0x18(%rsi),%ecx
    84dd:	0f b7 c0             	movzwl %ax,%eax
    84e0:	48 0f af c1          	imul   %rcx,%rax
    84e4:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    84e7:	48 c1 e8 20          	shr    $0x20,%rax
    84eb:	48 39 c8             	cmp    %rcx,%rax
    84ee:	0f 83 55 05 00 00    	jae    8a49 <f12+0xf89>
    84f4:	48 01 c7             	add    %rax,%rdi
    84f7:	80 3f 01             	cmpb   $0x1,(%rdi)
    84fa:	0f 85 49 05 00 00    	jne    8a49 <f12+0xf89>
    8500:	4c 39 fa             	cmp    %r15,%rdx
    8503:	4c 0f 46 fa          	cmovbe %rdx,%r15
    8507:	4c 89 fd             	mov    %r15,%rbp
    850a:	4d 85 ff             	test   %r15,%r15
    850d:	0f 84 f0 0a 00 00    	je     9003 <f12+0x1543>
    8513:	c7 44 24 4c 01 00 00 	movl   $0x1,0x4c(%rsp)
    851a:	00 
    851b:	4d 8d 65 08          	lea    0x8(%r13),%r12
    851f:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    8524:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    8529:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    8530:	00 
    8531:	31 c0                	xor    %eax,%eax
    8533:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    8537:	eb 24                	jmp    855d <f12+0xa9d>
    8539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8540:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    8545:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    854a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    8550:	48 83 c0 08          	add    $0x8,%rax
    8554:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8558:	49 39 c0             	cmp    %rax,%r8
    855b:	74 1b                	je     8578 <f12+0xab8>
    855d:	48 89 fe             	mov    %rdi,%rsi
    8560:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8565:	79 d9                	jns    8540 <f12+0xa80>
    8567:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    856c:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8570:	eb ce                	jmp    8540 <f12+0xa80>
    8572:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8578:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    857d:	48 85 d2             	test   %rdx,%rdx
    8580:	0f 84 47 0a 00 00    	je     8fcd <f12+0x150d>
    8586:	4c 8b 05 cb a5 01 00 	mov    0x1a5cb(%rip),%r8        # 22b58 <fwp_heap+0x13d8>
    858d:	4c 8b 15 9c a5 01 00 	mov    0x1a59c(%rip),%r10        # 22b30 <fwp_heap+0x13b0>
    8594:	45 31 ff             	xor    %r15d,%r15d
    8597:	4c 8b 1d da a5 01 00 	mov    0x1a5da(%rip),%r11        # 22b78 <fwp_heap+0x13f8>
    859e:	49 c1 e0 10          	shl    $0x10,%r8
    85a2:	eb 1a                	jmp    85be <f12+0xafe>
    85a4:	0f 1f 40 00          	nopl   0x0(%rax)
    85a8:	49 83 c7 01          	add    $0x1,%r15
    85ac:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    85b0:	49 39 ef             	cmp    %rbp,%r15
    85b3:	0f 83 27 02 00 00    	jae    87e0 <f12+0xd20>
    85b9:	48 85 d2             	test   %rdx,%rdx
    85bc:	74 52                	je     8610 <f12+0xb50>
    85be:	48 89 d0             	mov    %rdx,%rax
    85c1:	4c 29 d0             	sub    %r10,%rax
    85c4:	4c 39 c0             	cmp    %r8,%rax
    85c7:	73 47                	jae    8610 <f12+0xb50>
    85c9:	48 89 c6             	mov    %rax,%rsi
    85cc:	48 c1 ee 10          	shr    $0x10,%rsi
    85d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    85d4:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    85d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    85dc:	48 85 ff             	test   %rdi,%rdi
    85df:	74 2f                	je     8610 <f12+0xb50>
    85e1:	0f b6 1e             	movzbl (%rsi),%ebx
    85e4:	80 fb 02             	cmp    $0x2,%bl
    85e7:	0f 84 d3 01 00 00    	je     87c0 <f12+0xd00>
    85ed:	80 fb 01             	cmp    $0x1,%bl
    85f0:	75 1e                	jne    8610 <f12+0xb50>
    85f2:	8b 5e 18             	mov    0x18(%rsi),%ebx
    85f5:	0f b7 c0             	movzwl %ax,%eax
    85f8:	8b 76 1c             	mov    0x1c(%rsi),%esi
    85fb:	48 0f af c3          	imul   %rbx,%rax
    85ff:	48 c1 e8 20          	shr    $0x20,%rax
    8603:	48 39 f0             	cmp    %rsi,%rax
    8606:	73 08                	jae    8610 <f12+0xb50>
    8608:	48 01 c7             	add    %rax,%rdi
    860b:	80 3f 01             	cmpb   $0x1,(%rdi)
    860e:	74 98                	je     85a8 <f12+0xae8>
    8610:	49 39 ef             	cmp    %rbp,%r15
    8613:	0f 83 c7 01 00 00    	jae    87e0 <f12+0xd20>
    8619:	4c 8b 2d d0 54 00 00 	mov    0x54d0(%rip),%r13        # daf0 <msg.4+0x70>
    8620:	45 31 f6             	xor    %r14d,%r14d
    8623:	48 8d 1d 56 91 01 00 	lea    0x19156(%rip),%rbx        # 21780 <fwp_heap>
    862a:	e9 17 01 00 00       	jmp    8746 <f12+0xc86>
    862f:	90                   	nop
    8630:	49 8b 10             	mov    (%r8),%rdx
    8633:	48 f7 d2             	not    %rdx
    8636:	48 89 10             	mov    %rdx,(%rax)
    8639:	49 83 fb 18          	cmp    $0x18,%r11
    863d:	76 39                	jbe    8678 <f12+0xbb8>
    863f:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    8643:	49 8d 78 18          	lea    0x18(%r8),%rdi
    8647:	31 f6                	xor    %esi,%esi
    8649:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
    864e:	48 c1 e8 03          	shr    $0x3,%rax
    8652:	4c 89 04 24          	mov    %r8,(%rsp)
    8656:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    865d:	00 
    865e:	66 0f d6 44 24 20    	movq   %xmm0,0x20(%rsp)
    8664:	e8 57 ae ff ff       	call   34c0 <memset@plt>
    8669:	4c 8b 04 24          	mov    (%rsp),%r8
    866d:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
    8672:	f3 0f 7e 44 24 20    	movq   0x20(%rsp),%xmm0
    8678:	4c 89 d8             	mov    %r11,%rax
    867b:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8682:	0f 82 65 09 00 00    	jb     8fed <f12+0x152d>
    8688:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    868f:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8696:	73 07                	jae    869f <f12+0xbdf>
    8698:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    869f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    86a3:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    86a8:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    86af:	00 
    86b0:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    86b7:	00 
    86b8:	66 49 0f 6e f6       	movq   %r14,%xmm6
    86bd:	4d 89 28             	mov    %r13,(%r8)
    86c0:	4c 89 c0             	mov    %r8,%rax
    86c3:	4d 89 c6             	mov    %r8,%r14
    86c6:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    86ca:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    86cf:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    86d6:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    86dd:	48 c1 e2 10          	shl    $0x10,%rdx
    86e1:	48 39 d0             	cmp    %rdx,%rax
    86e4:	73 57                	jae    873d <f12+0xc7d>
    86e6:	48 89 c2             	mov    %rax,%rdx
    86e9:	48 c1 ea 10          	shr    $0x10,%rdx
    86ed:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    86f1:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    86f8:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    86fc:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    8700:	48 85 d2             	test   %rdx,%rdx
    8703:	74 38                	je     873d <f12+0xc7d>
    8705:	0f b6 3e             	movzbl (%rsi),%edi
    8708:	40 80 ff 02          	cmp    $0x2,%dil
    870c:	0f 84 7e 01 00 00    	je     8890 <f12+0xdd0>
    8712:	40 80 ff 01          	cmp    $0x1,%dil
    8716:	75 25                	jne    873d <f12+0xc7d>
    8718:	8b 7e 18             	mov    0x18(%rsi),%edi
    871b:	0f b7 c0             	movzwl %ax,%eax
    871e:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8721:	48 0f af c7          	imul   %rdi,%rax
    8725:	48 c1 e8 20          	shr    $0x20,%rax
    8729:	48 39 f0             	cmp    %rsi,%rax
    872c:	73 0f                	jae    873d <f12+0xc7d>
    872e:	48 01 c2             	add    %rax,%rdx
    8731:	80 3a ff             	cmpb   $0xff,(%rdx)
    8734:	0f 84 f6 04 00 00    	je     8c30 <f12+0x1170>
    873a:	c6 02 01             	movb   $0x1,(%rdx)
    873d:	49 39 ef             	cmp    %rbp,%r15
    8740:	0f 83 6a 01 00 00    	jae    88b0 <f12+0xdf0>
    8746:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    874c:	48 83 ed 01          	sub    $0x1,%rbp
    8750:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8756:	85 f6                	test   %esi,%esi
    8758:	74 46                	je     87a0 <f12+0xce0>
    875a:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8761:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    8768:	00 
    8769:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    876d:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8771:	4c 8b 00             	mov    (%rax),%r8
    8774:	4d 85 c0             	test   %r8,%r8
    8777:	0f 85 b3 fe ff ff    	jne    8630 <f12+0xb70>
    877d:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8781:	4d 85 c0             	test   %r8,%r8
    8784:	74 1a                	je     87a0 <f12+0xce0>
    8786:	48 8b 50 10          	mov    0x10(%rax),%rdx
    878a:	4c 29 c2             	sub    %r8,%rdx
    878d:	4c 39 da             	cmp    %r11,%rdx
    8790:	72 0e                	jb     87a0 <f12+0xce0>
    8792:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8796:	48 89 50 08          	mov    %rdx,0x8(%rax)
    879a:	e9 9a fe ff ff       	jmp    8639 <f12+0xb79>
    879f:	90                   	nop
    87a0:	31 f6                	xor    %esi,%esi
    87a2:	bf 18 00 00 00       	mov    $0x18,%edi
    87a7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    87ac:	e8 9f d2 ff ff       	call   5a50 <fwp_heap_alloc>
    87b1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    87b6:	49 89 c0             	mov    %rax,%r8
    87b9:	e9 fa fe ff ff       	jmp    86b8 <f12+0xbf8>
    87be:	66 90                	xchg   %ax,%ax
    87c0:	66 85 c0             	test   %ax,%ax
    87c3:	0f 84 42 fe ff ff    	je     860b <f12+0xb4b>
    87c9:	49 39 ef             	cmp    %rbp,%r15
    87cc:	0f 82 47 fe ff ff    	jb     8619 <f12+0xb59>
    87d2:	0f 1f 00             	nopl   (%rax)
    87d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    87dc:	00 00 00 00 
    87e0:	45 31 f6             	xor    %r14d,%r14d
    87e3:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    87e8:	4c 89 e2             	mov    %r12,%rdx
    87eb:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    87ef:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    87fc:	00 00 00 00 
    8800:	48 8b 0a             	mov    (%rdx),%rcx
    8803:	48 83 c2 08          	add    $0x8,%rdx
    8807:	48 89 c6             	mov    %rax,%rsi
    880a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    880e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8812:	48 39 d7             	cmp    %rdx,%rdi
    8815:	75 e9                	jne    8800 <f12+0xd40>
    8817:	8b 4c 24 4c          	mov    0x4c(%rsp),%ecx
    881b:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    881f:	85 c9                	test   %ecx,%ecx
    8821:	0f 84 09 05 00 00    	je     8d30 <f12+0x1270>
    8827:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    882c:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    8831:	45 31 e4             	xor    %r12d,%r12d
    8834:	90                   	nop
    8835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    883c:	00 00 00 00 
    8840:	4c 89 e7             	mov    %r12,%rdi
    8843:	e8 08 cd ff ff       	call   5550 <fwp_mem_free>
    8848:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    884d:	e8 5e ed ff ff       	call   75b0 <fwp_drop4>
    8852:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    8857:	e8 84 dd ff ff       	call   65e0 <fwp_drop0>
    885c:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
    8863:	00 
    8864:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    886b:	00 00 
    886d:	0f 85 22 08 00 00    	jne    9095 <f12+0x15d5>
    8873:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
    887a:	4c 89 f0             	mov    %r14,%rax
    887d:	5b                   	pop    %rbx
    887e:	5d                   	pop    %rbp
    887f:	41 5c                	pop    %r12
    8881:	41 5d                	pop    %r13
    8883:	41 5e                	pop    %r14
    8885:	41 5f                	pop    %r15
    8887:	c3                   	ret
    8888:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    888f:	00 
    8890:	66 85 c0             	test   %ax,%ax
    8893:	0f 84 98 fe ff ff    	je     8731 <f12+0xc71>
    8899:	49 39 ef             	cmp    %rbp,%r15
    889c:	0f 82 a4 fe ff ff    	jb     8746 <f12+0xc86>
    88a2:	0f 1f 00             	nopl   (%rax)
    88a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88ac:	00 00 00 00 
    88b0:	4d 85 ff             	test   %r15,%r15
    88b3:	0f 85 2a ff ff ff    	jne    87e3 <f12+0xd23>
    88b9:	8b 54 24 4c          	mov    0x4c(%rsp),%edx
    88bd:	85 d2                	test   %edx,%edx
    88bf:	4d 0f 45 e7          	cmovne %r15,%r12
    88c3:	66 90                	xchg   %ax,%ax
    88c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88cc:	00 00 00 00 
    88d0:	48 85 ed             	test   %rbp,%rbp
    88d3:	0f 84 67 ff ff ff    	je     8840 <f12+0xd80>
    88d9:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    88df:	48 83 ed 01          	sub    $0x1,%rbp
    88e3:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    88e9:	85 c0                	test   %eax,%eax
    88eb:	0f 84 87 06 00 00    	je     8f78 <f12+0x14b8>
    88f1:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    88f8:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    88ff:	00 
    8900:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8904:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8908:	4c 8b 38             	mov    (%rax),%r15
    890b:	4d 85 ff             	test   %r15,%r15
    890e:	0f 84 3c 06 00 00    	je     8f50 <f12+0x1490>
    8914:	49 8b 17             	mov    (%r15),%rdx
    8917:	48 f7 d2             	not    %rdx
    891a:	48 89 10             	mov    %rdx,(%rax)
    891d:	49 83 f8 18          	cmp    $0x18,%r8
    8921:	76 2f                	jbe    8952 <f12+0xe92>
    8923:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    8927:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    892b:	31 f6                	xor    %esi,%esi
    892d:	4c 89 04 24          	mov    %r8,(%rsp)
    8931:	48 c1 e8 03          	shr    $0x3,%rax
    8935:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    893b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8942:	00 
    8943:	e8 78 ab ff ff       	call   34c0 <memset@plt>
    8948:	4c 8b 04 24          	mov    (%rsp),%r8
    894c:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8952:	4c 89 c0             	mov    %r8,%rax
    8955:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    895c:	0f 82 8b 06 00 00    	jb     8fed <f12+0x152d>
    8962:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8969:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8970:	73 07                	jae    8979 <f12+0xeb9>
    8972:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8979:	66 0f ef c9          	pxor   %xmm1,%xmm1
    897d:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    8982:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8989:	00 
    898a:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8991:	00 
    8992:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8997:	4d 89 2f             	mov    %r13,(%r15)
    899a:	4c 89 f8             	mov    %r15,%rax
    899d:	4d 89 fe             	mov    %r15,%r14
    89a0:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    89a4:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    89a9:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    89b0:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    89b7:	48 c1 e2 10          	shl    $0x10,%rdx
    89bb:	48 39 d0             	cmp    %rdx,%rax
    89be:	0f 83 0c ff ff ff    	jae    88d0 <f12+0xe10>
    89c4:	48 89 c2             	mov    %rax,%rdx
    89c7:	48 c1 ea 10          	shr    $0x10,%rdx
    89cb:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    89cf:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    89d6:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    89da:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    89de:	4d 85 ff             	test   %r15,%r15
    89e1:	0f 84 e9 fe ff ff    	je     88d0 <f12+0xe10>
    89e7:	0f b6 32             	movzbl (%rdx),%esi
    89ea:	40 80 fe 02          	cmp    $0x2,%sil
    89ee:	0f 84 ac 05 00 00    	je     8fa0 <f12+0x14e0>
    89f4:	40 80 fe 01          	cmp    $0x1,%sil
    89f8:	0f 85 d2 fe ff ff    	jne    88d0 <f12+0xe10>
    89fe:	8b 72 18             	mov    0x18(%rdx),%esi
    8a01:	0f b7 c0             	movzwl %ax,%eax
    8a04:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a07:	48 0f af c6          	imul   %rsi,%rax
    8a0b:	48 c1 e8 20          	shr    $0x20,%rax
    8a0f:	48 39 d0             	cmp    %rdx,%rax
    8a12:	0f 83 b8 fe ff ff    	jae    88d0 <f12+0xe10>
    8a18:	49 01 c7             	add    %rax,%r15
    8a1b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8a1f:	0f 84 9b 05 00 00    	je     8fc0 <f12+0x1500>
    8a25:	41 c6 07 01          	movb   $0x1,(%r15)
    8a29:	48 85 ed             	test   %rbp,%rbp
    8a2c:	0f 85 a7 fe ff ff    	jne    88d9 <f12+0xe19>
    8a32:	e9 09 fe ff ff       	jmp    8840 <f12+0xd80>
    8a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a3e:	00 00 
    8a40:	66 85 c0             	test   %ax,%ax
    8a43:	0f 84 ae fa ff ff    	je     84f7 <f12+0xa37>
    8a49:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
    8a4f:	0f 84 a8 03 00 00    	je     8dfd <f12+0x133d>
    8a55:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    8a5a:	31 ed                	xor    %ebp,%ebp
    8a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a60:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a64:	48 89 ea             	mov    %rbp,%rdx
    8a67:	48 83 c5 01          	add    $0x1,%rbp
    8a6b:	48 85 c0             	test   %rax,%rax
    8a6e:	75 f0                	jne    8a60 <f12+0xfa0>
    8a70:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8a77:	ff ff 1f 
    8a7a:	48 39 e8             	cmp    %rbp,%rax
    8a7d:	0f 82 94 05 00 00    	jb     9017 <f12+0x1557>
    8a83:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8a8a:	00 
    8a8b:	be 02 00 00 00       	mov    $0x2,%esi
    8a90:	e8 bb cf ff ff       	call   5a50 <fwp_heap_alloc>
    8a95:	49 39 ef             	cmp    %rbp,%r15
    8a98:	49 89 c4             	mov    %rax,%r12
    8a9b:	48 89 c2             	mov    %rax,%rdx
    8a9e:	49 0f 46 ef          	cmovbe %r15,%rbp
    8aa2:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    8aa7:	0f 1f 00             	nopl   (%rax)
    8aaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ab1:	00 00 00 00 
    8ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8abc:	00 00 00 00 
    8ac0:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8ac4:	48 83 c2 08          	add    $0x8,%rdx
    8ac8:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    8acc:	48 8b 40 10          	mov    0x10(%rax),%rax
    8ad0:	48 85 c0             	test   %rax,%rax
    8ad3:	75 eb                	jne    8ac0 <f12+0x1000>
    8ad5:	48 85 ed             	test   %rbp,%rbp
    8ad8:	0f 84 31 03 00 00    	je     8e0f <f12+0x134f>
    8ade:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
    8ae5:	00 
    8ae6:	e9 34 fa ff ff       	jmp    851f <f12+0xa5f>
    8aeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8af0:	66 85 c0             	test   %ax,%ax
    8af3:	0f 84 c9 f8 ff ff    	je     83c2 <f12+0x902>
    8af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b00:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8b07:	ff ff 1f 
    8b0a:	4c 39 e0             	cmp    %r12,%rax
    8b0d:	0f 82 10 05 00 00    	jb     9023 <f12+0x1563>
    8b13:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    8b1a:	00 
    8b1b:	be 01 00 00 00       	mov    $0x1,%esi
    8b20:	e8 2b cf ff ff       	call   5a50 <fwp_heap_alloc>
    8b25:	4c 89 20             	mov    %r12,(%rax)
    8b28:	48 8b 15 29 a0 01 00 	mov    0x1a029(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    8b2f:	49 89 c5             	mov    %rax,%r13
    8b32:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    8b37:	48 2b 05 f2 9f 01 00 	sub    0x19ff2(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    8b3e:	48 c1 e2 10          	shl    $0x10,%rdx
    8b42:	48 39 d0             	cmp    %rdx,%rax
    8b45:	73 57                	jae    8b9e <f12+0x10de>
    8b47:	48 89 c2             	mov    %rax,%rdx
    8b4a:	48 c1 ea 10          	shr    $0x10,%rdx
    8b4e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b52:	48 8b 15 1f a0 01 00 	mov    0x1a01f(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    8b59:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b5d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8b61:	4d 85 ff             	test   %r15,%r15
    8b64:	74 38                	je     8b9e <f12+0x10de>
    8b66:	0f b6 0a             	movzbl (%rdx),%ecx
    8b69:	80 f9 02             	cmp    $0x2,%cl
    8b6c:	0f 84 ae 02 00 00    	je     8e20 <f12+0x1360>
    8b72:	80 f9 01             	cmp    $0x1,%cl
    8b75:	75 27                	jne    8b9e <f12+0x10de>
    8b77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8b7a:	0f b7 c0             	movzwl %ax,%eax
    8b7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b80:	48 0f af c1          	imul   %rcx,%rax
    8b84:	48 c1 e8 20          	shr    $0x20,%rax
    8b88:	48 39 d0             	cmp    %rdx,%rax
    8b8b:	73 11                	jae    8b9e <f12+0x10de>
    8b8d:	49 01 c7             	add    %rax,%r15
    8b90:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8b94:	0f 84 95 03 00 00    	je     8f2f <f12+0x146f>
    8b9a:	41 c6 07 01          	movb   $0x1,(%r15)
    8b9e:	48 89 df             	mov    %rbx,%rdi
    8ba1:	e9 2f f8 ff ff       	jmp    83d5 <f12+0x915>
    8ba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8bad:	00 00 00 
    8bb0:	48 c1 e6 10          	shl    $0x10,%rsi
    8bb4:	48 09 fe             	or     %rdi,%rsi
    8bb7:	bf 08 00 00 00       	mov    $0x8,%edi
    8bbc:	49 89 f4             	mov    %rsi,%r12
    8bbf:	be 02 00 00 00       	mov    $0x2,%esi
    8bc4:	e8 87 ce ff ff       	call   5a50 <fwp_heap_alloc>
    8bc9:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8bd0:	48 8b 15 81 9f 01 00 	mov    0x19f81(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    8bd7:	48 89 c3             	mov    %rax,%rbx
    8bda:	48 2b 05 4f 9f 01 00 	sub    0x19f4f(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    8be1:	48 c1 e2 10          	shl    $0x10,%rdx
    8be5:	48 39 d0             	cmp    %rdx,%rax
    8be8:	73 76                	jae    8c60 <f12+0x11a0>
    8bea:	48 89 c2             	mov    %rax,%rdx
    8bed:	48 c1 ea 10          	shr    $0x10,%rdx
    8bf1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bf5:	48 8b 15 7c 9f 01 00 	mov    0x19f7c(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    8bfc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8c00:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8c04:	48 85 d2             	test   %rdx,%rdx
    8c07:	0f 84 26 f3 ff ff    	je     7f33 <f12+0x473>
    8c0d:	0f b6 31             	movzbl (%rcx),%esi
    8c10:	45 31 ed             	xor    %r13d,%r13d
    8c13:	40 80 fe 02          	cmp    $0x2,%sil
    8c17:	0f 85 8e f2 ff ff    	jne    7eab <f12+0x3eb>
    8c1d:	66 85 c0             	test   %ax,%ax
    8c20:	0f 85 b0 f2 ff ff    	jne    7ed6 <f12+0x416>
    8c26:	e9 9f f2 ff ff       	jmp    7eca <f12+0x40a>
    8c2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c30:	48 89 d7             	mov    %rdx,%rdi
    8c33:	48 89 14 24          	mov    %rdx,(%rsp)
    8c37:	e8 d4 c6 ff ff       	call   5310 <fwp_rc_forget_slot>
    8c3c:	48 8b 14 24          	mov    (%rsp),%rdx
    8c40:	e9 f5 fa ff ff       	jmp    873a <f12+0xc7a>
    8c45:	0f 1f 00             	nopl   (%rax)
    8c48:	4d 85 ed             	test   %r13,%r13
    8c4b:	0f 85 8a f2 ff ff    	jne    7edb <f12+0x41b>
    8c51:	0f 1f 40 00          	nopl   0x0(%rax)
    8c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c5c:	00 00 00 00 
    8c60:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    8c67:	00 
    8c68:	e9 30 f3 ff ff       	jmp    7f9d <f12+0x4dd>
    8c6d:	0f 1f 00             	nopl   (%rax)
    8c70:	4d 8d 4a 01          	lea    0x1(%r10),%r9
    8c74:	4c 39 ca             	cmp    %r9,%rdx
    8c77:	0f 8c 6d f4 ff ff    	jl     80ea <f12+0x62a>
    8c7d:	48 85 c9             	test   %rcx,%rcx
    8c80:	0f 84 b2 03 00 00    	je     9038 <f12+0x1578>
    8c86:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    8c8b:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    8c92:	00 
    8c93:	31 f6                	xor    %esi,%esi
    8c95:	48 89 cf             	mov    %rcx,%rdi
    8c98:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8c9c:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    8ca1:	e9 3a 01 00 00       	jmp    8de0 <f12+0x1320>
    8ca6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8cad:	00 00 00 
    8cb0:	48 8d 3d 69 de ff ff 	lea    -0x2197(%rip),%rdi        # 6b20 <fwp_tape_finish>
    8cb7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8cbc:	e8 9f 37 00 00       	call   c460 <atexit>
    8cc1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8cc6:	85 c0                	test   %eax,%eax
    8cc8:	0f 85 81 03 00 00    	jne    904f <f12+0x158f>
    8cce:	c7 05 a8 83 00 00 01 	movl   $0x1,0x83a8(%rip)        # 11080 <registered_finish.0>
    8cd5:	00 00 00 
    8cd8:	e9 12 ef ff ff       	jmp    7bef <f12+0x12f>
    8cdd:	0f 1f 00             	nopl   (%rax)
    8ce0:	66 85 c0             	test   %ax,%ax
    8ce3:	0f 85 b1 ee ff ff    	jne    7b9a <f12+0xda>
    8ce9:	e9 98 ee ff ff       	jmp    7b86 <f12+0xc6>
    8cee:	66 90                	xchg   %ax,%ax
    8cf0:	48 39 d5             	cmp    %rdx,%rbp
    8cf3:	0f 8f ee f3 ff ff    	jg     80e7 <f12+0x627>
    8cf9:	48 85 c9             	test   %rcx,%rcx
    8cfc:	0f 85 ef 01 00 00    	jne    8ef1 <f12+0x1431>
    8d02:	48 85 ed             	test   %rbp,%rbp
    8d05:	0f 85 2d 03 00 00    	jne    9038 <f12+0x1578>
    8d0b:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8d12:	e9 8c f4 ff ff       	jmp    81a3 <f12+0x6e3>
    8d17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d1e:	00 00 
    8d20:	66 85 c0             	test   %ax,%ax
    8d23:	0f 85 f3 f5 ff ff    	jne    831c <f12+0x85c>
    8d29:	e9 de f5 ff ff       	jmp    830c <f12+0x84c>
    8d2e:	66 90                	xchg   %ax,%ax
    8d30:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    8d35:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    8d3a:	e9 01 fb ff ff       	jmp    8840 <f12+0xd80>
    8d3f:	90                   	nop
    8d40:	66 0f 6f 0d 78 83 01 	movdqa 0x18378(%rip),%xmm1        # 210c0 <fwp_tape_workspace>
    8d47:	00 
    8d48:	48 c7 05 55 83 01 00 	movq   $0x0,0x18355(%rip)        # 210a8 <fwp_tape_cached_bytes>
    8d4f:	00 00 00 00 
    8d53:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    8d59:	48 8b 05 80 83 01 00 	mov    0x18380(%rip),%rax        # 210e0 <fwp_tape_workspace+0x20>
    8d60:	66 0f 6f 0d 68 83 01 	movdqa 0x18368(%rip),%xmm1        # 210d0 <fwp_tape_workspace+0x10>
    8d67:	00 
    8d68:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    8d6d:	48 8b 05 74 83 01 00 	mov    0x18374(%rip),%rax        # 210e8 <fwp_tape_workspace+0x28>
    8d74:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    8d7a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8d7e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    8d83:	48 8b 05 66 83 01 00 	mov    0x18366(%rip),%rax        # 210f0 <fwp_tape_workspace+0x30>
    8d8a:	0f 29 0d 2f 83 01 00 	movaps %xmm1,0x1832f(%rip)        # 210c0 <fwp_tape_workspace>
    8d91:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    8d96:	0f 29 0d 33 83 01 00 	movaps %xmm1,0x18333(%rip)        # 210d0 <fwp_tape_workspace+0x10>
    8d9d:	48 c7 05 48 83 01 00 	movq   $0x0,0x18348(%rip)        # 210f0 <fwp_tape_workspace+0x30>
    8da4:	00 00 00 00 
    8da8:	0f 29 0d 31 83 01 00 	movaps %xmm1,0x18331(%rip)        # 210e0 <fwp_tape_workspace+0x20>
    8daf:	e9 91 ef ff ff       	jmp    7d45 <f12+0x285>
    8db4:	0f 1f 40 00          	nopl   0x0(%rax)
    8db8:	48 85 c9             	test   %rcx,%rcx
    8dbb:	0f 84 77 02 00 00    	je     9038 <f12+0x1578>
    8dc1:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    8dc6:	48 8d 5d ff          	lea    -0x1(%rbp),%rbx
    8dca:	31 f6                	xor    %esi,%esi
    8dcc:	48 89 cf             	mov    %rcx,%rdi
    8dcf:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    8dd4:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    8ddb:	00 
    8ddc:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8de0:	e8 db a6 ff ff       	call   34c0 <memset@plt>
    8de5:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8dea:	66 0f 6f 5c 24 10    	movdqa 0x10(%rsp),%xmm3
    8df0:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
    8df5:	48 89 c1             	mov    %rax,%rcx
    8df8:	e9 92 f3 ff ff       	jmp    818f <f12+0x6cf>
    8dfd:	be 02 00 00 00       	mov    $0x2,%esi
    8e02:	bf 08 00 00 00       	mov    $0x8,%edi
    8e07:	e8 44 cc ff ff       	call   5a50 <fwp_heap_alloc>
    8e0c:	49 89 c4             	mov    %rax,%r12
    8e0f:	45 31 f6             	xor    %r14d,%r14d
    8e12:	e9 29 fa ff ff       	jmp    8840 <f12+0xd80>
    8e17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e1e:	00 00 
    8e20:	66 85 c0             	test   %ax,%ax
    8e23:	0f 85 75 fd ff ff    	jne    8b9e <f12+0x10de>
    8e29:	e9 62 fd ff ff       	jmp    8b90 <f12+0x10d0>
    8e2e:	66 90                	xchg   %ax,%ax
    8e30:	48 89 d7             	mov    %rdx,%rdi
    8e33:	be 08 00 00 00       	mov    $0x8,%esi
    8e38:	48 89 14 24          	mov    %rdx,(%rsp)
    8e3c:	e8 df a6 ff ff       	call   3520 <calloc@plt>
    8e41:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8e47:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8e4d:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    8e52:	48 8b 14 24          	mov    (%rsp),%rdx
    8e56:	48 89 c1             	mov    %rax,%rcx
    8e59:	e9 00 f3 ff ff       	jmp    815e <f12+0x69e>
    8e5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8e62:	e9 78 ed ff ff       	jmp    7bdf <f12+0x11f>
    8e67:	49 8b 4d 00          	mov    0x0(%r13),%rcx
    8e6b:	48 85 c9             	test   %rcx,%rcx
    8e6e:	78 8d                	js     8dfd <f12+0x133d>
    8e70:	48 8b 35 e1 9c 01 00 	mov    0x19ce1(%rip),%rsi        # 22b58 <fwp_heap+0x13d8>
    8e77:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    8e7c:	48 2b 05 ad 9c 01 00 	sub    0x19cad(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    8e83:	48 c1 e6 10          	shl    $0x10,%rsi
    8e87:	48 39 f0             	cmp    %rsi,%rax
    8e8a:	0f 83 6d ff ff ff    	jae    8dfd <f12+0x133d>
    8e90:	48 89 c6             	mov    %rax,%rsi
    8e93:	48 c1 ee 10          	shr    $0x10,%rsi
    8e97:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    8e9b:	48 8b 35 d6 9c 01 00 	mov    0x19cd6(%rip),%rsi        # 22b78 <fwp_heap+0x13f8>
    8ea2:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    8ea6:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8eaa:	48 85 ff             	test   %rdi,%rdi
    8ead:	0f 84 4a ff ff ff    	je     8dfd <f12+0x133d>
    8eb3:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    8eb8:	49 89 cf             	mov    %rcx,%r15
    8ebb:	e9 05 f6 ff ff       	jmp    84c5 <f12+0xa05>
    8ec0:	be 68 00 00 00       	mov    $0x68,%esi
    8ec5:	b9 01 00 00 00       	mov    $0x1,%ecx
    8eca:	e9 ab ed ff ff       	jmp    7c7a <f12+0x1ba>
    8ecf:	48 89 d7             	mov    %rdx,%rdi
    8ed2:	48 89 14 24          	mov    %rdx,(%rsp)
    8ed6:	e8 35 c4 ff ff       	call   5310 <fwp_rc_forget_slot>
    8edb:	48 8b 14 24          	mov    (%rsp),%rdx
    8edf:	e9 ef ef ff ff       	jmp    7ed3 <f12+0x413>
    8ee4:	4c 89 e7             	mov    %r12,%rdi
    8ee7:	e8 24 c4 ff ff       	call   5310 <fwp_rc_forget_slot>
    8eec:	e9 26 f4 ff ff       	jmp    8317 <f12+0x857>
    8ef1:	48 85 ed             	test   %rbp,%rbp
    8ef4:	0f 84 11 fe ff ff    	je     8d0b <f12+0x124b>
    8efa:	49 89 e9             	mov    %rbp,%r9
    8efd:	48 89 cf             	mov    %rcx,%rdi
    8f00:	31 f6                	xor    %esi,%esi
    8f02:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    8f07:	49 8d 59 ff          	lea    -0x1(%r9),%rbx
    8f0b:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    8f12:	00 
    8f13:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8f17:	e8 a4 a5 ff ff       	call   34c0 <memset@plt>
    8f1c:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8f21:	66 0f 6f 5c 24 10    	movdqa 0x10(%rsp),%xmm3
    8f27:	48 89 c1             	mov    %rax,%rcx
    8f2a:	e9 58 f2 ff ff       	jmp    8187 <f12+0x6c7>
    8f2f:	4c 89 ff             	mov    %r15,%rdi
    8f32:	e8 d9 c3 ff ff       	call   5310 <fwp_rc_forget_slot>
    8f37:	e9 5e fc ff ff       	jmp    8b9a <f12+0x10da>
    8f3c:	e8 af c2 ff ff       	call   51f0 <fwp_rc_wide_dup>
    8f41:	e9 54 ec ff ff       	jmp    7b9a <f12+0xda>
    8f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f4d:	00 00 00 
    8f50:	4c 8b 78 08          	mov    0x8(%rax),%r15
    8f54:	4d 85 ff             	test   %r15,%r15
    8f57:	74 1f                	je     8f78 <f12+0x14b8>
    8f59:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8f5d:	4c 29 fa             	sub    %r15,%rdx
    8f60:	4c 39 c2             	cmp    %r8,%rdx
    8f63:	72 13                	jb     8f78 <f12+0x14b8>
    8f65:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    8f69:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8f6d:	e9 ab f9 ff ff       	jmp    891d <f12+0xe5d>
    8f72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f78:	31 f6                	xor    %esi,%esi
    8f7a:	bf 18 00 00 00       	mov    $0x18,%edi
    8f7f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8f84:	e8 c7 ca ff ff       	call   5a50 <fwp_heap_alloc>
    8f89:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8f8e:	49 89 c7             	mov    %rax,%r15
    8f91:	e9 fc f9 ff ff       	jmp    8992 <f12+0xed2>
    8f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f9d:	00 00 00 
    8fa0:	66 85 c0             	test   %ax,%ax
    8fa3:	0f 85 27 f9 ff ff    	jne    88d0 <f12+0xe10>
    8fa9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8fad:	0f 85 72 fa ff ff    	jne    8a25 <f12+0xf65>
    8fb3:	66 90                	xchg   %ax,%ax
    8fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8fbc:	00 00 00 00 
    8fc0:	4c 89 ff             	mov    %r15,%rdi
    8fc3:	e8 48 c3 ff ff       	call   5310 <fwp_rc_forget_slot>
    8fc8:	e9 58 fa ff ff       	jmp    8a25 <f12+0xf65>
    8fcd:	45 31 ff             	xor    %r15d,%r15d
    8fd0:	e9 44 f6 ff ff       	jmp    8619 <f12+0xb59>
    8fd5:	48 8d 3d 28 41 00 00 	lea    0x4128(%rip),%rdi        # d104 <_IO_stdin_used+0x104>
    8fdc:	e8 bf b1 ff ff       	call   41a0 <fwp_trap>
    8fe1:	48 8d 3d d8 47 00 00 	lea    0x47d8(%rip),%rdi        # d7c0 <_IO_stdin_used+0x7c0>
    8fe8:	e8 b3 b1 ff ff       	call   41a0 <fwp_trap>
    8fed:	e8 be ac ff ff       	call   3cb0 <fwp_heap_oom>
    8ff2:	48 8d 3d cf 48 00 00 	lea    0x48cf(%rip),%rdi        # d8c8 <_IO_stdin_used+0x8c8>
    8ff9:	e8 a2 b1 ff ff       	call   41a0 <fwp_trap>
    8ffe:	e8 fd a6 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9003:	45 31 e4             	xor    %r12d,%r12d
    9006:	e9 04 fe ff ff       	jmp    8e0f <f12+0x134f>
    900b:	48 8d 3d 1b 41 00 00 	lea    0x411b(%rip),%rdi        # d12d <_IO_stdin_used+0x12d>
    9012:	e8 89 b1 ff ff       	call   41a0 <fwp_trap>
    9017:	48 8d 3d 29 41 00 00 	lea    0x4129(%rip),%rdi        # d147 <_IO_stdin_used+0x147>
    901e:	e8 7d b1 ff ff       	call   41a0 <fwp_trap>
    9023:	48 8d 3d 2b 41 00 00 	lea    0x412b(%rip),%rdi        # d155 <_IO_stdin_used+0x155>
    902a:	e8 71 b1 ff ff       	call   41a0 <fwp_trap>
    902f:	4d 85 c9             	test   %r9,%r9
    9032:	0f 84 48 f1 ff ff    	je     8180 <f12+0x6c0>
    9038:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    903f:	00 
    9040:	4c 89 e7             	mov    %r12,%rdi
    9043:	48 89 05 ce a3 01 00 	mov    %rax,0x1a3ce(%rip)        # 23418 <fwp_cleanups>
    904a:	e8 e1 bd ff ff       	call   4e30 <fwp_tape_buffers_release>
    904f:	48 8b 0d 0a 80 00 00 	mov    0x800a(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    9056:	ba 13 00 00 00       	mov    $0x13,%edx
    905b:	be 01 00 00 00       	mov    $0x1,%esi
    9060:	48 8d 3d a1 3f 00 00 	lea    0x3fa1(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    9067:	e8 14 a6 ff ff       	call   3680 <fwrite@plt>
    906c:	31 ff                	xor    %edi,%edi
    906e:	e8 4d a5 ff ff       	call   35c0 <fflush@plt>
    9073:	bf 66 00 00 00       	mov    $0x66,%edi
    9078:	e8 23 a6 ff ff       	call   36a0 <_Exit@plt>
    907d:	48 8d 3d 14 48 00 00 	lea    0x4814(%rip),%rdi        # d898 <_IO_stdin_used+0x898>
    9084:	e8 17 b1 ff ff       	call   41a0 <fwp_trap>
    9089:	48 8d 3d d8 47 00 00 	lea    0x47d8(%rip),%rdi        # d868 <_IO_stdin_used+0x868>
    9090:	e8 0b b1 ff ff       	call   41a0 <fwp_trap>
    9095:	e8 c6 a3 ff ff       	call   3460 <__stack_chk_fail@plt>
    909a:	48 8d 3d 67 47 00 00 	lea    0x4767(%rip),%rdi        # d808 <_IO_stdin_used+0x808>
    90a1:	e8 fa b0 ff ff       	call   41a0 <fwp_trap>
    90a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    90ad:	00 00 00 

00000000000090b0 <fwp_owned_entry12>:
    90b0:	f3 0f 1e fa          	endbr64
    90b4:	48 8b 3f             	mov    (%rdi),%rdi
    90b7:	e9 04 ea ff ff       	jmp    7ac0 <f12>
    90bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000090c0 <e12>:
    90c0:	f3 0f 1e fa          	endbr64
    90c4:	53                   	push   %rbx
    90c5:	48 8b 1f             	mov    (%rdi),%rbx
    90c8:	48 89 df             	mov    %rbx,%rdi
    90cb:	e8 80 d3 ff ff       	call   6450 <fwp_rc_share>
    90d0:	48 89 df             	mov    %rbx,%rdi
    90d3:	e8 e8 e9 ff ff       	call   7ac0 <f12>
    90d8:	48 89 c3             	mov    %rax,%rbx
    90db:	48 89 c7             	mov    %rax,%rdi
    90de:	e8 6d d3 ff ff       	call   6450 <fwp_rc_share>
    90e3:	48 89 d8             	mov    %rbx,%rax
    90e6:	5b                   	pop    %rbx
    90e7:	c3                   	ret
    90e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    90ef:	00 

00000000000090f0 <fwp_drop2>:
    90f0:	48 8b 0d 61 9a 01 00 	mov    0x19a61(%rip),%rcx        # 22b58 <fwp_heap+0x13d8>
    90f7:	48 89 f8             	mov    %rdi,%rax
    90fa:	48 2b 05 2f 9a 01 00 	sub    0x19a2f(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    9101:	48 c1 e1 10          	shl    $0x10,%rcx
    9105:	48 39 c8             	cmp    %rcx,%rax
    9108:	0f 83 42 01 00 00    	jae    9250 <fwp_drop2+0x160>
    910e:	48 83 ec 18          	sub    $0x18,%rsp
    9112:	48 89 fa             	mov    %rdi,%rdx
    9115:	4c 8d 05 64 86 01 00 	lea    0x18664(%rip),%r8        # 21780 <fwp_heap>
    911c:	48 89 c1             	mov    %rax,%rcx
    911f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9126:	48 c1 e9 10          	shr    $0x10,%rcx
    912a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    912e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9132:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9136:	48 85 c9             	test   %rcx,%rcx
    9139:	74 40                	je     917b <fwp_drop2+0x8b>
    913b:	0f b6 3e             	movzbl (%rsi),%edi
    913e:	40 80 ff 02          	cmp    $0x2,%dil
    9142:	74 3c                	je     9180 <fwp_drop2+0x90>
    9144:	40 80 ff 01          	cmp    $0x1,%dil
    9148:	75 31                	jne    917b <fwp_drop2+0x8b>
    914a:	8b 7e 18             	mov    0x18(%rsi),%edi
    914d:	0f b7 c0             	movzwl %ax,%eax
    9150:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9153:	48 0f af c7          	imul   %rdi,%rax
    9157:	48 c1 e8 20          	shr    $0x20,%rax
    915b:	48 39 f0             	cmp    %rsi,%rax
    915e:	73 1b                	jae    917b <fwp_drop2+0x8b>
    9160:	48 01 c1             	add    %rax,%rcx
    9163:	0f b6 01             	movzbl (%rcx),%eax
    9166:	84 c0                	test   %al,%al
    9168:	74 11                	je     917b <fwp_drop2+0x8b>
    916a:	3c 01                	cmp    $0x1,%al
    916c:	74 22                	je     9190 <fwp_drop2+0xa0>
    916e:	3c ff                	cmp    $0xff,%al
    9170:	0f 84 0a 01 00 00    	je     9280 <fwp_drop2+0x190>
    9176:	83 e8 01             	sub    $0x1,%eax
    9179:	88 01                	mov    %al,(%rcx)
    917b:	48 83 c4 18          	add    $0x18,%rsp
    917f:	c3                   	ret
    9180:	66 85 c0             	test   %ax,%ax
    9183:	74 de                	je     9163 <fwp_drop2+0x73>
    9185:	48 83 c4 18          	add    $0x18,%rsp
    9189:	c3                   	ret
    918a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9190:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    9194:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    919b:	48 89 f8             	mov    %rdi,%rax
    919e:	48 c1 e1 10          	shl    $0x10,%rcx
    91a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    91a9:	48 39 c8             	cmp    %rcx,%rax
    91ac:	73 62                	jae    9210 <fwp_drop2+0x120>
    91ae:	48 89 c1             	mov    %rax,%rcx
    91b1:	48 c1 e9 10          	shr    $0x10,%rcx
    91b5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    91b9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    91bd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    91c1:	48 85 c9             	test   %rcx,%rcx
    91c4:	74 4a                	je     9210 <fwp_drop2+0x120>
    91c6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    91ca:	41 80 f9 02          	cmp    $0x2,%r9b
    91ce:	0f 84 9c 00 00 00    	je     9270 <fwp_drop2+0x180>
    91d4:	41 80 f9 01          	cmp    $0x1,%r9b
    91d8:	75 36                	jne    9210 <fwp_drop2+0x120>
    91da:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    91de:	0f b7 c0             	movzwl %ax,%eax
    91e1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    91e4:	49 0f af c1          	imul   %r9,%rax
    91e8:	48 c1 e8 20          	shr    $0x20,%rax
    91ec:	48 39 f0             	cmp    %rsi,%rax
    91ef:	73 1f                	jae    9210 <fwp_drop2+0x120>
    91f1:	48 01 c1             	add    %rax,%rcx
    91f4:	0f b6 01             	movzbl (%rcx),%eax
    91f7:	84 c0                	test   %al,%al
    91f9:	74 15                	je     9210 <fwp_drop2+0x120>
    91fb:	3c 01                	cmp    $0x1,%al
    91fd:	74 59                	je     9258 <fwp_drop2+0x168>
    91ff:	3c ff                	cmp    $0xff,%al
    9201:	0f 84 ff 00 00 00    	je     9306 <fwp_drop2+0x216>
    9207:	83 e8 01             	sub    $0x1,%eax
    920a:	88 01                	mov    %al,(%rcx)
    920c:	0f 1f 40 00          	nopl   0x0(%rax)
    9210:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9214:	48 89 d7             	mov    %rdx,%rdi
    9217:	48 89 0c 24          	mov    %rcx,(%rsp)
    921b:	e8 b0 d2 ff ff       	call   64d0 <fwp_rc_free_arr>
    9220:	4c 8d 05 59 85 01 00 	lea    0x18559(%rip),%r8        # 21780 <fwp_heap>
    9227:	48 8b 04 24          	mov    (%rsp),%rax
    922b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9232:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9239:	48 c1 e2 10          	shl    $0x10,%rdx
    923d:	48 39 d0             	cmp    %rdx,%rax
    9240:	0f 83 35 ff ff ff    	jae    917b <fwp_drop2+0x8b>
    9246:	48 8b 14 24          	mov    (%rsp),%rdx
    924a:	e9 cd fe ff ff       	jmp    911c <fwp_drop2+0x2c>
    924f:	90                   	nop
    9250:	c3                   	ret
    9251:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9258:	48 89 14 24          	mov    %rdx,(%rsp)
    925c:	e8 6f d2 ff ff       	call   64d0 <fwp_rc_free_arr>
    9261:	48 8b 14 24          	mov    (%rsp),%rdx
    9265:	eb a9                	jmp    9210 <fwp_drop2+0x120>
    9267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    926e:	00 00 
    9270:	66 85 c0             	test   %ax,%ax
    9273:	75 9b                	jne    9210 <fwp_drop2+0x120>
    9275:	e9 7a ff ff ff       	jmp    91f4 <fwp_drop2+0x104>
    927a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9280:	48 89 c8             	mov    %rcx,%rax
    9283:	48 c1 e8 11          	shr    $0x11,%rax
    9287:	48 31 c8             	xor    %rcx,%rax
    928a:	48 89 c2             	mov    %rax,%rdx
    928d:	48 c1 ea 09          	shr    $0x9,%rdx
    9291:	48 31 d0             	xor    %rdx,%rax
    9294:	0f b6 d0             	movzbl %al,%edx
    9297:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    929e:	00 
    929f:	48 85 c0             	test   %rax,%rax
    92a2:	75 29                	jne    92cd <fwp_drop2+0x1dd>
    92a4:	e9 e3 00 00 00       	jmp    938c <fwp_drop2+0x29c>
    92a9:	90                   	nop
    92aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    92b1:	00 00 00 00 
    92b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    92bc:	00 00 00 00 
    92c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    92c4:	48 85 c0             	test   %rax,%rax
    92c7:	0f 84 bf 00 00 00    	je     938c <fwp_drop2+0x29c>
    92cd:	48 89 c2             	mov    %rax,%rdx
    92d0:	48 39 08             	cmp    %rcx,(%rax)
    92d3:	75 eb                	jne    92c0 <fwp_drop2+0x1d0>
    92d5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    92d9:	48 83 ea 01          	sub    $0x1,%rdx
    92dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    92e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    92e8:	0f 85 8d fe ff ff    	jne    917b <fwp_drop2+0x8b>
    92ee:	48 89 cf             	mov    %rcx,%rdi
    92f1:	48 89 0c 24          	mov    %rcx,(%rsp)
    92f5:	e8 16 c0 ff ff       	call   5310 <fwp_rc_forget_slot>
    92fa:	48 8b 0c 24          	mov    (%rsp),%rcx
    92fe:	c6 01 fe             	movb   $0xfe,(%rcx)
    9301:	e9 75 fe ff ff       	jmp    917b <fwp_drop2+0x8b>
    9306:	48 89 ce             	mov    %rcx,%rsi
    9309:	48 c1 ee 11          	shr    $0x11,%rsi
    930d:	48 31 ce             	xor    %rcx,%rsi
    9310:	48 89 f0             	mov    %rsi,%rax
    9313:	48 c1 e8 09          	shr    $0x9,%rax
    9317:	48 31 c6             	xor    %rax,%rsi
    931a:	40 0f b6 f6          	movzbl %sil,%esi
    931e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9325:	00 
    9326:	48 85 c0             	test   %rax,%rax
    9329:	75 1e                	jne    9349 <fwp_drop2+0x259>
    932b:	eb 5f                	jmp    938c <fwp_drop2+0x29c>
    932d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9334:	00 
    9335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    933c:	00 00 00 00 
    9340:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9344:	48 85 c0             	test   %rax,%rax
    9347:	74 43                	je     938c <fwp_drop2+0x29c>
    9349:	48 89 c6             	mov    %rax,%rsi
    934c:	48 39 08             	cmp    %rcx,(%rax)
    934f:	75 ef                	jne    9340 <fwp_drop2+0x250>
    9351:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9355:	48 83 ee 01          	sub    $0x1,%rsi
    9359:	48 89 70 08          	mov    %rsi,0x8(%rax)
    935d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    9364:	0f 85 a6 fe ff ff    	jne    9210 <fwp_drop2+0x120>
    936a:	48 89 cf             	mov    %rcx,%rdi
    936d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    9372:	48 89 0c 24          	mov    %rcx,(%rsp)
    9376:	e8 95 bf ff ff       	call   5310 <fwp_rc_forget_slot>
    937b:	48 8b 0c 24          	mov    (%rsp),%rcx
    937f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9384:	c6 01 fe             	movb   $0xfe,(%rcx)
    9387:	e9 84 fe ff ff       	jmp    9210 <fwp_drop2+0x120>
    938c:	48 8d 3d 05 44 00 00 	lea    0x4405(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    9393:	e8 08 ae ff ff       	call   41a0 <fwp_trap>
    9398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    939f:	00 

00000000000093a0 <fwp_arg_drop23>:
    93a0:	f3 0f 1e fa          	endbr64
    93a4:	85 f6                	test   %esi,%esi
    93a6:	75 04                	jne    93ac <fwp_arg_drop23+0xc>
    93a8:	85 d2                	test   %edx,%edx
    93aa:	75 04                	jne    93b0 <fwp_arg_drop23+0x10>
    93ac:	c3                   	ret
    93ad:	0f 1f 00             	nopl   (%rax)
    93b0:	48 8b 3f             	mov    (%rdi),%rdi
    93b3:	e9 38 fd ff ff       	jmp    90f0 <fwp_drop2>
    93b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93bf:	00 

00000000000093c0 <fwp_caps23>:
    93c0:	f3 0f 1e fa          	endbr64
    93c4:	48 83 ec 18          	sub    $0x18,%rsp
    93c8:	8b 57 04             	mov    0x4(%rdi),%edx
    93cb:	48 89 f8             	mov    %rdi,%rax
    93ce:	85 d2                	test   %edx,%edx
    93d0:	0f 84 9a 00 00 00    	je     9470 <fwp_caps23+0xb0>
    93d6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    93da:	85 f6                	test   %esi,%esi
    93dc:	0f 85 9e 00 00 00    	jne    9480 <fwp_caps23+0xc0>
    93e2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    93e7:	e8 04 fd ff ff       	call   90f0 <fwp_drop2>
    93ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    93f1:	48 8b 0d 60 97 01 00 	mov    0x19760(%rip),%rcx        # 22b58 <fwp_heap+0x13d8>
    93f8:	48 89 c2             	mov    %rax,%rdx
    93fb:	48 2b 15 2e 97 01 00 	sub    0x1972e(%rip),%rdx        # 22b30 <fwp_heap+0x13b0>
    9402:	48 c1 e1 10          	shl    $0x10,%rcx
    9406:	48 39 ca             	cmp    %rcx,%rdx
    9409:	73 6d                	jae    9478 <fwp_caps23+0xb8>
    940b:	48 89 d1             	mov    %rdx,%rcx
    940e:	48 c1 e9 10          	shr    $0x10,%rcx
    9412:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9416:	48 8b 0d 5b 97 01 00 	mov    0x1975b(%rip),%rcx        # 22b78 <fwp_heap+0x13f8>
    941d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9421:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9425:	48 85 f6             	test   %rsi,%rsi
    9428:	74 4e                	je     9478 <fwp_caps23+0xb8>
    942a:	0f b6 39             	movzbl (%rcx),%edi
    942d:	40 80 ff 02          	cmp    $0x2,%dil
    9431:	0f 84 b9 00 00 00    	je     94f0 <fwp_caps23+0x130>
    9437:	40 80 ff 01          	cmp    $0x1,%dil
    943b:	75 3b                	jne    9478 <fwp_caps23+0xb8>
    943d:	8b 79 18             	mov    0x18(%rcx),%edi
    9440:	0f b7 d2             	movzwl %dx,%edx
    9443:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9446:	48 0f af d7          	imul   %rdi,%rdx
    944a:	48 c1 ea 20          	shr    $0x20,%rdx
    944e:	48 39 ca             	cmp    %rcx,%rdx
    9451:	73 25                	jae    9478 <fwp_caps23+0xb8>
    9453:	48 01 d6             	add    %rdx,%rsi
    9456:	80 3e 01             	cmpb   $0x1,(%rsi)
    9459:	75 1d                	jne    9478 <fwp_caps23+0xb8>
    945b:	48 89 c7             	mov    %rax,%rdi
    945e:	48 83 c4 18          	add    $0x18,%rsp
    9462:	e9 e9 c0 ff ff       	jmp    5550 <fwp_mem_free>
    9467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    946e:	00 00 
    9470:	85 f6                	test   %esi,%esi
    9472:	0f 84 79 ff ff ff    	je     93f1 <fwp_caps23+0x31>
    9478:	48 83 c4 18          	add    $0x18,%rsp
    947c:	c3                   	ret
    947d:	0f 1f 00             	nopl   (%rax)
    9480:	48 8b 05 d1 96 01 00 	mov    0x196d1(%rip),%rax        # 22b58 <fwp_heap+0x13d8>
    9487:	48 2b 3d a2 96 01 00 	sub    0x196a2(%rip),%rdi        # 22b30 <fwp_heap+0x13b0>
    948e:	48 c1 e0 10          	shl    $0x10,%rax
    9492:	48 39 c7             	cmp    %rax,%rdi
    9495:	73 e1                	jae    9478 <fwp_caps23+0xb8>
    9497:	48 89 f8             	mov    %rdi,%rax
    949a:	48 c1 e8 10          	shr    $0x10,%rax
    949e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    94a2:	48 8b 05 cf 96 01 00 	mov    0x196cf(%rip),%rax        # 22b78 <fwp_heap+0x13f8>
    94a9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    94ad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    94b1:	48 85 c0             	test   %rax,%rax
    94b4:	74 c2                	je     9478 <fwp_caps23+0xb8>
    94b6:	0f b6 0a             	movzbl (%rdx),%ecx
    94b9:	80 f9 02             	cmp    $0x2,%cl
    94bc:	74 42                	je     9500 <fwp_caps23+0x140>
    94be:	80 f9 01             	cmp    $0x1,%cl
    94c1:	75 b5                	jne    9478 <fwp_caps23+0xb8>
    94c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94c6:	0f b7 ff             	movzwl %di,%edi
    94c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94cc:	48 0f af f9          	imul   %rcx,%rdi
    94d0:	48 c1 ef 20          	shr    $0x20,%rdi
    94d4:	48 39 d7             	cmp    %rdx,%rdi
    94d7:	73 9f                	jae    9478 <fwp_caps23+0xb8>
    94d9:	48 01 f8             	add    %rdi,%rax
    94dc:	0f b6 10             	movzbl (%rax),%edx
    94df:	84 d2                	test   %dl,%dl
    94e1:	74 95                	je     9478 <fwp_caps23+0xb8>
    94e3:	80 fa fd             	cmp    $0xfd,%dl
    94e6:	77 23                	ja     950b <fwp_caps23+0x14b>
    94e8:	83 c2 01             	add    $0x1,%edx
    94eb:	88 10                	mov    %dl,(%rax)
    94ed:	eb 89                	jmp    9478 <fwp_caps23+0xb8>
    94ef:	90                   	nop
    94f0:	66 85 d2             	test   %dx,%dx
    94f3:	0f 85 7f ff ff ff    	jne    9478 <fwp_caps23+0xb8>
    94f9:	e9 58 ff ff ff       	jmp    9456 <fwp_caps23+0x96>
    94fe:	66 90                	xchg   %ax,%ax
    9500:	66 85 ff             	test   %di,%di
    9503:	0f 85 6f ff ff ff    	jne    9478 <fwp_caps23+0xb8>
    9509:	eb d1                	jmp    94dc <fwp_caps23+0x11c>
    950b:	48 89 c7             	mov    %rax,%rdi
    950e:	48 83 c4 18          	add    $0x18,%rsp
    9512:	e9 d9 bc ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    9517:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    951e:	00 00 

0000000000009520 <f23>:
    9520:	41 57                	push   %r15
    9522:	41 56                	push   %r14
    9524:	41 55                	push   %r13
    9526:	41 54                	push   %r12
    9528:	55                   	push   %rbp
    9529:	53                   	push   %rbx
    952a:	48 83 ec 38          	sub    $0x38,%rsp
    952e:	48 8b 15 23 96 01 00 	mov    0x19623(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    9535:	48 8b 0d f4 95 01 00 	mov    0x195f4(%rip),%rcx        # 22b30 <fwp_heap+0x13b0>
    953c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9543:	00 00 
    9545:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    954a:	49 89 fc             	mov    %rdi,%r12
    954d:	48 c1 e2 10          	shl    $0x10,%rdx
    9551:	48 85 ff             	test   %rdi,%rdi
    9554:	0f 84 bc 02 00 00    	je     9816 <f23+0x2f6>
    955a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    955f:	48 89 d8             	mov    %rbx,%rax
    9562:	48 29 c8             	sub    %rcx,%rax
    9565:	48 39 d0             	cmp    %rdx,%rax
    9568:	0f 83 72 03 00 00    	jae    98e0 <f23+0x3c0>
    956e:	48 89 c2             	mov    %rax,%rdx
    9571:	48 c1 ea 10          	shr    $0x10,%rdx
    9575:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9579:	48 8b 15 f8 95 01 00 	mov    0x195f8(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    9580:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9584:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9588:	48 85 ff             	test   %rdi,%rdi
    958b:	0f 84 4f 03 00 00    	je     98e0 <f23+0x3c0>
    9591:	0f b6 0a             	movzbl (%rdx),%ecx
    9594:	80 f9 02             	cmp    $0x2,%cl
    9597:	0f 84 53 02 00 00    	je     97f0 <f23+0x2d0>
    959d:	80 f9 01             	cmp    $0x1,%cl
    95a0:	75 24                	jne    95c6 <f23+0xa6>
    95a2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    95a5:	0f b7 c0             	movzwl %ax,%eax
    95a8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    95ab:	48 0f af c1          	imul   %rcx,%rax
    95af:	48 c1 e8 20          	shr    $0x20,%rax
    95b3:	48 39 d0             	cmp    %rdx,%rax
    95b6:	73 0e                	jae    95c6 <f23+0xa6>
    95b8:	48 01 c7             	add    %rax,%rdi
    95bb:	0f b6 07             	movzbl (%rdi),%eax
    95be:	84 c0                	test   %al,%al
    95c0:	0f 85 ca 02 00 00    	jne    9890 <f23+0x370>
    95c6:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    95cb:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    95d0:	ba 01 00 00 00       	mov    $0x1,%edx
    95d5:	48 85 db             	test   %rbx,%rbx
    95d8:	74 13                	je     95ed <f23+0xcd>
    95da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95e0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    95e4:	48 83 c2 01          	add    $0x1,%rdx
    95e8:	48 85 db             	test   %rbx,%rbx
    95eb:	75 f3                	jne    95e0 <f23+0xc0>
    95ed:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    95f2:	48 85 c0             	test   %rax,%rax
    95f5:	0f 84 15 03 00 00    	je     9910 <f23+0x3f0>
    95fb:	31 db                	xor    %ebx,%ebx
    95fd:	0f 1f 00             	nopl   (%rax)
    9600:	48 8b 40 10          	mov    0x10(%rax),%rax
    9604:	48 83 c3 01          	add    $0x1,%rbx
    9608:	48 85 c0             	test   %rax,%rax
    960b:	75 f3                	jne    9600 <f23+0xe0>
    960d:	48 39 d3             	cmp    %rdx,%rbx
    9610:	48 0f 47 da          	cmova  %rdx,%rbx
    9614:	48 89 d8             	mov    %rbx,%rax
    9617:	48 c1 e8 3c          	shr    $0x3c,%rax
    961b:	0f 85 8f 03 00 00    	jne    99b0 <f23+0x490>
    9621:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9625:	be 02 00 00 00       	mov    $0x2,%esi
    962a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9631:	00 
    9632:	e8 19 c4 ff ff       	call   5a50 <fwp_heap_alloc>
    9637:	48 89 28             	mov    %rbp,(%rax)
    963a:	48 8b 15 17 95 01 00 	mov    0x19517(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    9641:	49 89 c6             	mov    %rax,%r14
    9644:	48 2b 05 e5 94 01 00 	sub    0x194e5(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    964b:	48 c1 e2 10          	shl    $0x10,%rdx
    964f:	48 39 d0             	cmp    %rdx,%rax
    9652:	73 57                	jae    96ab <f23+0x18b>
    9654:	48 89 c2             	mov    %rax,%rdx
    9657:	48 c1 ea 10          	shr    $0x10,%rdx
    965b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    965f:	48 8b 15 12 95 01 00 	mov    0x19512(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    9666:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    966a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    966e:	48 85 ed             	test   %rbp,%rbp
    9671:	74 38                	je     96ab <f23+0x18b>
    9673:	0f b6 0a             	movzbl (%rdx),%ecx
    9676:	80 f9 02             	cmp    $0x2,%cl
    9679:	0f 84 51 02 00 00    	je     98d0 <f23+0x3b0>
    967f:	80 f9 01             	cmp    $0x1,%cl
    9682:	75 27                	jne    96ab <f23+0x18b>
    9684:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9687:	0f b7 c0             	movzwl %ax,%eax
    968a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    968d:	48 0f af c1          	imul   %rcx,%rax
    9691:	48 c1 e8 20          	shr    $0x20,%rax
    9695:	48 39 d0             	cmp    %rdx,%rax
    9698:	73 11                	jae    96ab <f23+0x18b>
    969a:	48 01 c5             	add    %rax,%rbp
    969d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    96a1:	0f 84 d5 02 00 00    	je     997c <f23+0x45c>
    96a7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    96ab:	48 85 db             	test   %rbx,%rbx
    96ae:	74 5d                	je     970d <f23+0x1ed>
    96b0:	48 c1 e3 04          	shl    $0x4,%rbx
    96b4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    96b9:	4c 89 f5             	mov    %r14,%rbp
    96bc:	4d 89 e5             	mov    %r12,%r13
    96bf:	4c 01 f3             	add    %r14,%rbx
    96c2:	0f 1f 00             	nopl   (%rax)
    96c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    96cc:	00 00 00 00 
    96d0:	49 8b 45 08          	mov    0x8(%r13),%rax
    96d4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    96d8:	48 83 c5 10          	add    $0x10,%rbp
    96dc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    96e1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    96e5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    96e9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    96ee:	e8 3d ca ff ff       	call   6130 <w107>
    96f3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    96f8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    96fc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9700:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9704:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9708:	48 39 dd             	cmp    %rbx,%rbp
    970b:	75 c3                	jne    96d0 <f23+0x1b0>
    970d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9712:	e8 d9 f9 ff ff       	call   90f0 <fwp_drop2>
    9717:	4c 89 e7             	mov    %r12,%rdi
    971a:	e8 d1 f9 ff ff       	call   90f0 <fwp_drop2>
    971f:	4c 89 f7             	mov    %r14,%rdi
    9722:	e8 79 cb ff ff       	call   62a0 <w164.constprop.0>
    9727:	4c 89 f7             	mov    %r14,%rdi
    972a:	48 89 c3             	mov    %rax,%rbx
    972d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9733:	e8 78 de ff ff       	call   75b0 <fwp_drop4>
    9738:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    973e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    9743:	31 ff                	xor    %edi,%edi
    9745:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    974a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    974e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9753:	e8 c8 cb ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    9758:	48 8b 15 f9 93 01 00 	mov    0x193f9(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    975f:	48 89 c5             	mov    %rax,%rbp
    9762:	48 2b 05 c7 93 01 00 	sub    0x193c7(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    9769:	48 c1 e2 10          	shl    $0x10,%rdx
    976d:	48 39 d0             	cmp    %rdx,%rax
    9770:	73 55                	jae    97c7 <f23+0x2a7>
    9772:	48 89 c2             	mov    %rax,%rdx
    9775:	48 c1 ea 10          	shr    $0x10,%rdx
    9779:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    977d:	48 8b 15 f4 93 01 00 	mov    0x193f4(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    9784:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9788:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    978c:	48 85 db             	test   %rbx,%rbx
    978f:	74 36                	je     97c7 <f23+0x2a7>
    9791:	0f b6 0a             	movzbl (%rdx),%ecx
    9794:	80 f9 02             	cmp    $0x2,%cl
    9797:	0f 84 1b 01 00 00    	je     98b8 <f23+0x398>
    979d:	80 f9 01             	cmp    $0x1,%cl
    97a0:	75 25                	jne    97c7 <f23+0x2a7>
    97a2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97a5:	0f b7 c0             	movzwl %ax,%eax
    97a8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97ab:	48 0f af c1          	imul   %rcx,%rax
    97af:	48 c1 e8 20          	shr    $0x20,%rax
    97b3:	48 39 d0             	cmp    %rdx,%rax
    97b6:	73 0f                	jae    97c7 <f23+0x2a7>
    97b8:	48 01 c3             	add    %rax,%rbx
    97bb:	80 3b ff             	cmpb   $0xff,(%rbx)
    97be:	0f 84 ab 01 00 00    	je     996f <f23+0x44f>
    97c4:	c6 03 01             	movb   $0x1,(%rbx)
    97c7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    97cc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    97d3:	00 00 
    97d5:	0f 85 d0 01 00 00    	jne    99ab <f23+0x48b>
    97db:	48 83 c4 38          	add    $0x38,%rsp
    97df:	48 89 e8             	mov    %rbp,%rax
    97e2:	5b                   	pop    %rbx
    97e3:	5d                   	pop    %rbp
    97e4:	41 5c                	pop    %r12
    97e6:	41 5d                	pop    %r13
    97e8:	41 5e                	pop    %r14
    97ea:	41 5f                	pop    %r15
    97ec:	c3                   	ret
    97ed:	0f 1f 00             	nopl   (%rax)
    97f0:	66 85 c0             	test   %ax,%ax
    97f3:	0f 85 cd fd ff ff    	jne    95c6 <f23+0xa6>
    97f9:	0f b6 07             	movzbl (%rdi),%eax
    97fc:	84 c0                	test   %al,%al
    97fe:	0f 84 c2 fd ff ff    	je     95c6 <f23+0xa6>
    9804:	3c fd                	cmp    $0xfd,%al
    9806:	0f 87 95 01 00 00    	ja     99a1 <f23+0x481>
    980c:	83 c0 01             	add    $0x1,%eax
    980f:	88 07                	mov    %al,(%rdi)
    9811:	e9 b0 fd ff ff       	jmp    95c6 <f23+0xa6>
    9816:	48 f7 d9             	neg    %rcx
    9819:	48 39 d1             	cmp    %rdx,%rcx
    981c:	0f 83 ee 00 00 00    	jae    9910 <f23+0x3f0>
    9822:	48 89 c8             	mov    %rcx,%rax
    9825:	48 c1 e8 10          	shr    $0x10,%rax
    9829:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    982d:	48 8b 05 44 93 01 00 	mov    0x19344(%rip),%rax        # 22b78 <fwp_heap+0x13f8>
    9834:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9838:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    983c:	48 85 ff             	test   %rdi,%rdi
    983f:	0f 84 cb 00 00 00    	je     9910 <f23+0x3f0>
    9845:	0f b6 02             	movzbl (%rdx),%eax
    9848:	3c 02                	cmp    $0x2,%al
    984a:	0f 84 9a 00 00 00    	je     98ea <f23+0x3ca>
    9850:	3c 01                	cmp    $0x1,%al
    9852:	0f 85 b8 00 00 00    	jne    9910 <f23+0x3f0>
    9858:	0f b7 c1             	movzwl %cx,%eax
    985b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    985e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9861:	48 0f af c1          	imul   %rcx,%rax
    9865:	48 c1 e8 20          	shr    $0x20,%rax
    9869:	48 39 d0             	cmp    %rdx,%rax
    986c:	0f 83 9e 00 00 00    	jae    9910 <f23+0x3f0>
    9872:	48 01 c7             	add    %rax,%rdi
    9875:	0f b6 07             	movzbl (%rdi),%eax
    9878:	84 c0                	test   %al,%al
    987a:	0f 84 90 00 00 00    	je     9910 <f23+0x3f0>
    9880:	31 db                	xor    %ebx,%ebx
    9882:	0f 1f 00             	nopl   (%rax)
    9885:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    988c:	00 00 00 00 
    9890:	3c fd                	cmp    $0xfd,%al
    9892:	0f 87 f1 00 00 00    	ja     9989 <f23+0x469>
    9898:	83 c0 01             	add    $0x1,%eax
    989b:	88 07                	mov    %al,(%rdi)
    989d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    98a2:	31 d2                	xor    %edx,%edx
    98a4:	4d 85 e4             	test   %r12,%r12
    98a7:	0f 85 1e fd ff ff    	jne    95cb <f23+0xab>
    98ad:	e9 3b fd ff ff       	jmp    95ed <f23+0xcd>
    98b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98b8:	66 85 c0             	test   %ax,%ax
    98bb:	0f 85 06 ff ff ff    	jne    97c7 <f23+0x2a7>
    98c1:	e9 f5 fe ff ff       	jmp    97bb <f23+0x29b>
    98c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    98cd:	00 00 00 
    98d0:	66 85 c0             	test   %ax,%ax
    98d3:	0f 85 d2 fd ff ff    	jne    96ab <f23+0x18b>
    98d9:	e9 bf fd ff ff       	jmp    969d <f23+0x17d>
    98de:	66 90                	xchg   %ax,%ax
    98e0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    98e5:	e9 e6 fc ff ff       	jmp    95d0 <f23+0xb0>
    98ea:	66 85 c9             	test   %cx,%cx
    98ed:	75 21                	jne    9910 <f23+0x3f0>
    98ef:	0f b6 07             	movzbl (%rdi),%eax
    98f2:	84 c0                	test   %al,%al
    98f4:	74 1a                	je     9910 <f23+0x3f0>
    98f6:	3c fd                	cmp    $0xfd,%al
    98f8:	0f 87 be 00 00 00    	ja     99bc <f23+0x49c>
    98fe:	83 c0 01             	add    $0x1,%eax
    9901:	88 07                	mov    %al,(%rdi)
    9903:	66 90                	xchg   %ax,%ax
    9905:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    990c:	00 00 00 00 
    9910:	be 02 00 00 00       	mov    $0x2,%esi
    9915:	bf 08 00 00 00       	mov    $0x8,%edi
    991a:	e8 31 c1 ff ff       	call   5a50 <fwp_heap_alloc>
    991f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9926:	48 8b 15 2b 92 01 00 	mov    0x1922b(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    992d:	49 89 c6             	mov    %rax,%r14
    9930:	48 2b 05 f9 91 01 00 	sub    0x191f9(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    9937:	48 c1 e2 10          	shl    $0x10,%rdx
    993b:	48 39 d0             	cmp    %rdx,%rax
    993e:	73 53                	jae    9993 <f23+0x473>
    9940:	48 89 c2             	mov    %rax,%rdx
    9943:	48 c1 ea 10          	shr    $0x10,%rdx
    9947:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    994b:	48 8b 15 26 92 01 00 	mov    0x19226(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    9952:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9956:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    995a:	48 85 ed             	test   %rbp,%rbp
    995d:	74 34                	je     9993 <f23+0x473>
    995f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9966:	00 00 
    9968:	31 db                	xor    %ebx,%ebx
    996a:	e9 04 fd ff ff       	jmp    9673 <f23+0x153>
    996f:	48 89 df             	mov    %rbx,%rdi
    9972:	e8 99 b9 ff ff       	call   5310 <fwp_rc_forget_slot>
    9977:	e9 48 fe ff ff       	jmp    97c4 <f23+0x2a4>
    997c:	48 89 ef             	mov    %rbp,%rdi
    997f:	e8 8c b9 ff ff       	call   5310 <fwp_rc_forget_slot>
    9984:	e9 1e fd ff ff       	jmp    96a7 <f23+0x187>
    9989:	e8 62 b8 ff ff       	call   51f0 <fwp_rc_wide_dup>
    998e:	e9 0a ff ff ff       	jmp    989d <f23+0x37d>
    9993:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    999a:	00 00 
    999c:	e9 6c fd ff ff       	jmp    970d <f23+0x1ed>
    99a1:	e8 4a b8 ff ff       	call   51f0 <fwp_rc_wide_dup>
    99a6:	e9 1b fc ff ff       	jmp    95c6 <f23+0xa6>
    99ab:	e8 b0 9a ff ff       	call   3460 <__stack_chk_fail@plt>
    99b0:	48 8d 3d 90 37 00 00 	lea    0x3790(%rip),%rdi        # d147 <_IO_stdin_used+0x147>
    99b7:	e8 e4 a7 ff ff       	call   41a0 <fwp_trap>
    99bc:	e8 2f b8 ff ff       	call   51f0 <fwp_rc_wide_dup>
    99c1:	e9 4a ff ff ff       	jmp    9910 <f23+0x3f0>
    99c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    99cd:	00 00 00 

00000000000099d0 <fwp_owned_entry23>:
    99d0:	f3 0f 1e fa          	endbr64
    99d4:	48 8b 3f             	mov    (%rdi),%rdi
    99d7:	e9 44 fb ff ff       	jmp    9520 <f23>
    99dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000099e0 <e23>:
    99e0:	f3 0f 1e fa          	endbr64
    99e4:	53                   	push   %rbx
    99e5:	48 8b 1f             	mov    (%rdi),%rbx
    99e8:	48 89 df             	mov    %rbx,%rdi
    99eb:	e8 60 ca ff ff       	call   6450 <fwp_rc_share>
    99f0:	48 89 df             	mov    %rbx,%rdi
    99f3:	e8 28 fb ff ff       	call   9520 <f23>
    99f8:	48 89 c3             	mov    %rax,%rbx
    99fb:	48 89 c7             	mov    %rax,%rdi
    99fe:	e8 4d ca ff ff       	call   6450 <fwp_rc_share>
    9a03:	48 89 d8             	mov    %rbx,%rax
    9a06:	5b                   	pop    %rbx
    9a07:	c3                   	ret
    9a08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a0f:	00 

0000000000009a10 <fwp_write>:
    9a10:	41 57                	push   %r15
    9a12:	41 56                	push   %r14
    9a14:	41 55                	push   %r13
    9a16:	41 54                	push   %r12
    9a18:	55                   	push   %rbp
    9a19:	53                   	push   %rbx
    9a1a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9a21:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9a28:	00 00 
    9a2a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9a31:	00 
    9a32:	49 89 d4             	mov    %rdx,%r12
    9a35:	8b 12                	mov    (%rdx),%edx
    9a37:	83 fa 19             	cmp    $0x19,%edx
    9a3a:	77 6a                	ja     9aa6 <fwp_write+0x96>
    9a3c:	48 89 f5             	mov    %rsi,%rbp
    9a3f:	89 d0                	mov    %edx,%eax
    9a41:	89 ce                	mov    %ecx,%esi
    9a43:	48 89 fb             	mov    %rdi,%rbx
    9a46:	48 8d 0d c3 3f 00 00 	lea    0x3fc3(%rip),%rcx        # da10 <_IO_stdin_used+0xa10>
    9a4d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9a51:	48 01 c8             	add    %rcx,%rax
    9a54:	3e ff e0             	notrack jmp *%rax
    9a57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a5e:	00 00 
    9a60:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9a64:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9a68:	48 89 ca             	mov    %rcx,%rdx
    9a6b:	48 85 c9             	test   %rcx,%rcx
    9a6e:	0f 88 9c 0c 00 00    	js     a710 <fwp_write+0xd00>
    9a74:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a7b:	00 
    9a7c:	48 89 c6             	mov    %rax,%rsi
    9a7f:	4c 89 e7             	mov    %r12,%rdi
    9a82:	e8 b9 9f ff ff       	call   3a40 <fwp_fmt_u128>
    9a87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a8e:	00 00 
    9a90:	4c 89 e7             	mov    %r12,%rdi
    9a93:	e8 b8 99 ff ff       	call   3450 <strlen@plt>
    9a98:	4c 89 e6             	mov    %r12,%rsi
    9a9b:	48 89 df             	mov    %rbx,%rdi
    9a9e:	48 89 c2             	mov    %rax,%rdx
    9aa1:	e8 ca a5 ff ff       	call   4070 <buf_put>
    9aa6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9aad:	00 
    9aae:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9ab5:	00 00 
    9ab7:	0f 85 28 04 00 00    	jne    9ee5 <fwp_write+0x4d5>
    9abd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9ac4:	5b                   	pop    %rbx
    9ac5:	5d                   	pop    %rbp
    9ac6:	41 5c                	pop    %r12
    9ac8:	41 5d                	pop    %r13
    9aca:	41 5e                	pop    %r14
    9acc:	41 5f                	pop    %r15
    9ace:	c3                   	ret
    9acf:	90                   	nop
    9ad0:	49 89 e9             	mov    %rbp,%r9
    9ad3:	4c 8d 05 a7 36 00 00 	lea    0x36a7(%rip),%r8        # d181 <_IO_stdin_used+0x181>
    9ada:	b9 00 02 00 00       	mov    $0x200,%ecx
    9adf:	ba 02 00 00 00       	mov    $0x2,%edx
    9ae4:	be 00 02 00 00       	mov    $0x200,%esi
    9ae9:	31 c0                	xor    %eax,%eax
    9aeb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9af2:	00 
    9af3:	e8 b8 98 ff ff       	call   33b0 <__snprintf_chk@plt>
    9af8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9aff:	00 
    9b00:	e8 4b 99 ff ff       	call   3450 <strlen@plt>
    9b05:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9b0c:	00 
    9b0d:	48 89 df             	mov    %rbx,%rdi
    9b10:	48 89 c2             	mov    %rax,%rdx
    9b13:	e8 58 a5 ff ff       	call   4070 <buf_put>
    9b18:	eb 8c                	jmp    9aa6 <fwp_write+0x96>
    9b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b20:	49 89 e9             	mov    %rbp,%r9
    9b23:	4c 8d 05 52 36 00 00 	lea    0x3652(%rip),%r8        # d17c <_IO_stdin_used+0x17c>
    9b2a:	eb ae                	jmp    9ada <fwp_write+0xca>
    9b2c:	0f 1f 40 00          	nopl   0x0(%rax)
    9b30:	83 fa 13             	cmp    $0x13,%edx
    9b33:	48 8d 05 38 36 00 00 	lea    0x3638(%rip),%rax        # d172 <_IO_stdin_used+0x172>
    9b3a:	48 8d 35 36 36 00 00 	lea    0x3636(%rip),%rsi        # d177 <_IO_stdin_used+0x177>
    9b41:	ba 04 00 00 00       	mov    $0x4,%edx
    9b46:	48 0f 44 f0          	cmove  %rax,%rsi
    9b4a:	45 31 ed             	xor    %r13d,%r13d
    9b4d:	e8 1e a5 ff ff       	call   4070 <buf_put>
    9b52:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9b57:	0f 84 a3 08 00 00    	je     a400 <fwp_write+0x9f0>
    9b5d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9b62:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9b67:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9b6c:	48 89 df             	mov    %rbx,%rdi
    9b6f:	49 0f 44 c5          	cmove  %r13,%rax
    9b73:	31 c9                	xor    %ecx,%ecx
    9b75:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9b7a:	e8 91 fe ff ff       	call   9a10 <fwp_write>
    9b7f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9b84:	0f 84 6e 09 00 00    	je     a4f8 <fwp_write+0xae8>
    9b8a:	49 83 c5 01          	add    $0x1,%r13
    9b8e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9b92:	0f 83 68 08 00 00    	jae    a400 <fwp_write+0x9f0>
    9b98:	ba 02 00 00 00       	mov    $0x2,%edx
    9b9d:	48 8d 35 1d 36 00 00 	lea    0x361d(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    9ba4:	48 89 df             	mov    %rbx,%rdi
    9ba7:	e8 c4 a4 ff ff       	call   4070 <buf_put>
    9bac:	eb af                	jmp    9b5d <fwp_write+0x14d>
    9bae:	66 90                	xchg   %ax,%ax
    9bb0:	ba 06 00 00 00       	mov    $0x6,%edx
    9bb5:	48 8d 35 de 35 00 00 	lea    0x35de(%rip),%rsi        # d19a <_IO_stdin_used+0x19a>
    9bbc:	48 83 c5 10          	add    $0x10,%rbp
    9bc0:	e8 ab a4 ff ff       	call   4070 <buf_put>
    9bc5:	48 89 ef             	mov    %rbp,%rdi
    9bc8:	e8 83 98 ff ff       	call   3450 <strlen@plt>
    9bcd:	48 89 ee             	mov    %rbp,%rsi
    9bd0:	48 89 df             	mov    %rbx,%rdi
    9bd3:	48 89 c2             	mov    %rax,%rdx
    9bd6:	e8 95 a4 ff ff       	call   4070 <buf_put>
    9bdb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9be0:	ba 01 00 00 00       	mov    $0x1,%edx
    9be5:	48 89 df             	mov    %rbx,%rdi
    9be8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9bed:	e8 7e a4 ff ff       	call   4070 <buf_put>
    9bf2:	e9 af fe ff ff       	jmp    9aa6 <fwp_write+0x96>
    9bf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9bfe:	00 00 
    9c00:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9c07:	00 
    9c08:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c0f:	00 00 
    9c11:	0f 85 ce 02 00 00    	jne    9ee5 <fwp_write+0x4d5>
    9c17:	ba 0a 00 00 00       	mov    $0xa,%edx
    9c1c:	48 8d 35 63 35 00 00 	lea    0x3563(%rip),%rsi        # d186 <_IO_stdin_used+0x186>
    9c23:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9c2a:	48 89 df             	mov    %rbx,%rdi
    9c2d:	5b                   	pop    %rbx
    9c2e:	5d                   	pop    %rbp
    9c2f:	41 5c                	pop    %r12
    9c31:	41 5d                	pop    %r13
    9c33:	41 5e                	pop    %r14
    9c35:	41 5f                	pop    %r15
    9c37:	e9 34 a4 ff ff       	jmp    4070 <buf_put>
    9c3c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c40:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9c45:	4d 85 ed             	test   %r13,%r13
    9c48:	0f 84 02 0c 00 00    	je     a850 <fwp_write+0xe40>
    9c4e:	48 8d 35 79 35 00 00 	lea    0x3579(%rip),%rsi        # d1ce <_IO_stdin_used+0x1ce>
    9c55:	4c 89 ef             	mov    %r13,%rdi
    9c58:	e8 d3 98 ff ff       	call   3530 <strcmp@plt>
    9c5d:	41 89 c1             	mov    %eax,%r9d
    9c60:	85 c0                	test   %eax,%eax
    9c62:	0f 84 6c 0c 00 00    	je     a8d4 <fwp_write+0xec4>
    9c68:	4c 89 ef             	mov    %r13,%rdi
    9c6b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9c70:	e8 db 97 ff ff       	call   3450 <strlen@plt>
    9c75:	4c 89 ee             	mov    %r13,%rsi
    9c78:	48 89 df             	mov    %rbx,%rdi
    9c7b:	48 89 c2             	mov    %rax,%rdx
    9c7e:	e8 ed a3 ff ff       	call   4070 <buf_put>
    9c83:	ba 01 00 00 00       	mov    $0x1,%edx
    9c88:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9c8d:	48 89 df             	mov    %rbx,%rdi
    9c90:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9c95:	e8 d6 a3 ff ff       	call   4070 <buf_put>
    9c9a:	ba 01 00 00 00       	mov    $0x1,%edx
    9c9f:	4c 89 fe             	mov    %r15,%rsi
    9ca2:	48 89 df             	mov    %rbx,%rdi
    9ca5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9caa:	e8 c1 a3 ff ff       	call   4070 <buf_put>
    9caf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9cb4:	45 31 f6             	xor    %r14d,%r14d
    9cb7:	85 d2                	test   %edx,%edx
    9cb9:	0f 8e 81 0a 00 00    	jle    a740 <fwp_write+0xd30>
    9cbf:	45 31 ed             	xor    %r13d,%r13d
    9cc2:	4d 85 ed             	test   %r13,%r13
    9cc5:	0f 85 75 07 00 00    	jne    a440 <fwp_write+0xa30>
    9ccb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9cd2:	00 
    9cd3:	45 85 f6             	test   %r14d,%r14d
    9cd6:	0f 84 84 07 00 00    	je     a460 <fwp_write+0xa50>
    9cdc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9ce1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9ce6:	48 89 df             	mov    %rbx,%rdi
    9ce9:	49 83 c5 01          	add    $0x1,%r13
    9ced:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9cf1:	31 c9                	xor    %ecx,%ecx
    9cf3:	e8 18 fd ff ff       	call   9a10 <fwp_write>
    9cf8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9cfd:	7f c3                	jg     9cc2 <fwp_write+0x2b2>
    9cff:	45 85 f6             	test   %r14d,%r14d
    9d02:	0f 84 38 0a 00 00    	je     a740 <fwp_write+0xd30>
    9d08:	b8 29 00 00 00       	mov    $0x29,%eax
    9d0d:	ba 01 00 00 00       	mov    $0x1,%edx
    9d12:	4c 89 fe             	mov    %r15,%rsi
    9d15:	48 89 df             	mov    %rbx,%rdi
    9d18:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9d1c:	e8 4f a3 ff ff       	call   4070 <buf_put>
    9d21:	e9 80 fd ff ff       	jmp    9aa6 <fwp_write+0x96>
    9d26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9d2d:	00 00 00 
    9d30:	ba 01 00 00 00       	mov    $0x1,%edx
    9d35:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9d3a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9d3f:	e8 2c a3 ff ff       	call   4070 <buf_put>
    9d44:	48 85 ed             	test   %rbp,%rbp
    9d47:	0f 84 93 06 00 00    	je     a3e0 <fwp_write+0x9d0>
    9d4d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9d51:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9d56:	31 c9                	xor    %ecx,%ecx
    9d58:	48 89 df             	mov    %rbx,%rdi
    9d5b:	e8 b0 fc ff ff       	call   9a10 <fwp_write>
    9d60:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9d64:	48 85 ed             	test   %rbp,%rbp
    9d67:	0f 84 73 06 00 00    	je     a3e0 <fwp_write+0x9d0>
    9d6d:	ba 02 00 00 00       	mov    $0x2,%edx
    9d72:	48 8d 35 48 34 00 00 	lea    0x3448(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    9d79:	48 89 df             	mov    %rbx,%rdi
    9d7c:	e8 ef a2 ff ff       	call   4070 <buf_put>
    9d81:	eb ca                	jmp    9d4d <fwp_write+0x33d>
    9d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d88:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9d8c:	85 f6                	test   %esi,%esi
    9d8e:	0f 84 fc 07 00 00    	je     a590 <fwp_write+0xb80>
    9d94:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d9b:	00 
    9d9c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9da3:	00 00 
    9da5:	0f 85 3a 01 00 00    	jne    9ee5 <fwp_write+0x4d5>
    9dab:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9daf:	4c 89 ea             	mov    %r13,%rdx
    9db2:	e9 6c fe ff ff       	jmp    9c23 <fwp_write+0x213>
    9db7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9dbe:	00 00 
    9dc0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9dc5:	ba 01 00 00 00       	mov    $0x1,%edx
    9dca:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9dcf:	48 89 ee             	mov    %rbp,%rsi
    9dd2:	e8 99 a2 ff ff       	call   4070 <buf_put>
    9dd7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9ddc:	4c 89 e7             	mov    %r12,%rdi
    9ddf:	e8 6c 96 ff ff       	call   3450 <strlen@plt>
    9de4:	4c 89 e6             	mov    %r12,%rsi
    9de7:	48 89 df             	mov    %rbx,%rdi
    9dea:	48 89 c2             	mov    %rax,%rdx
    9ded:	e8 7e a2 ff ff       	call   4070 <buf_put>
    9df2:	ba 01 00 00 00       	mov    $0x1,%edx
    9df7:	48 89 ee             	mov    %rbp,%rsi
    9dfa:	48 89 df             	mov    %rbx,%rdi
    9dfd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9e02:	e8 69 a2 ff ff       	call   4070 <buf_put>
    9e07:	e9 9a fc ff ff       	jmp    9aa6 <fwp_write+0x96>
    9e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e10:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9e15:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9e19:	0f 8a 8e 0b 00 00    	jp     a9ad <fwp_write+0xf9d>
    9e1f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e23:	66 0f 54 05 e5 3c 00 	andpd  0x3ce5(%rip),%xmm0        # db10 <msg.4+0x90>
    9e2a:	00 
    9e2b:	bd 01 00 00 00       	mov    $0x1,%ebp
    9e30:	66 0f 2e 05 18 3d 00 	ucomisd 0x3d18(%rip),%xmm0        # db50 <msg.4+0xd0>
    9e37:	00 
    9e38:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9e3f:	00 
    9e40:	0f 87 b2 09 00 00    	ja     a7f8 <fwp_write+0xde8>
    9e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e4d:	00 00 00 
    9e50:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e54:	89 ee                	mov    %ebp,%esi
    9e56:	4c 89 e7             	mov    %r12,%rdi
    9e59:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9e5e:	e8 5d a6 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9e63:	31 f6                	xor    %esi,%esi
    9e65:	4c 89 e7             	mov    %r12,%rdi
    9e68:	e8 a3 95 ff ff       	call   3410 <strtod@plt>
    9e6d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9e72:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9e76:	7a 06                	jp     9e7e <fwp_write+0x46e>
    9e78:	0f 84 e9 01 00 00    	je     a067 <fwp_write+0x657>
    9e7e:	83 c5 01             	add    $0x1,%ebp
    9e81:	83 fd 12             	cmp    $0x12,%ebp
    9e84:	75 ca                	jne    9e50 <fwp_write+0x440>
    9e86:	be 11 00 00 00       	mov    $0x11,%esi
    9e8b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e8f:	4c 89 e7             	mov    %r12,%rdi
    9e92:	e8 29 a6 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9e97:	e9 cb 01 00 00       	jmp    a067 <fwp_write+0x657>
    9e9c:	0f 1f 40 00          	nopl   0x0(%rax)
    9ea0:	48 83 fd 01          	cmp    $0x1,%rbp
    9ea4:	0f 84 e6 08 00 00    	je     a790 <fwp_write+0xd80>
    9eaa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9eae:	b8 02 00 00 00       	mov    $0x2,%eax
    9eb3:	ba 01 00 00 00       	mov    $0x1,%edx
    9eb8:	48 0f 44 d0          	cmove  %rax,%rdx
    9ebc:	48 8d 35 a7 32 00 00 	lea    0x32a7(%rip),%rsi        # d16a <_IO_stdin_used+0x16a>
    9ec3:	48 8d 05 a5 32 00 00 	lea    0x32a5(%rip),%rax        # d16f <_IO_stdin_used+0x16f>
    9eca:	48 0f 44 f0          	cmove  %rax,%rsi
    9ece:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9ed5:	00 
    9ed6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9edd:	00 00 
    9edf:	0f 84 3e fd ff ff    	je     9c23 <fwp_write+0x213>
    9ee5:	e8 76 95 ff ff       	call   3460 <__stack_chk_fail@plt>
    9eea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ef0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9ef5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9efa:	e8 b1 a0 ff ff       	call   3fb0 <buf_grow>
    9eff:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9f03:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9f09:	4c 03 0b             	add    (%rbx),%r9
    9f0c:	66 45 89 11          	mov    %r10w,(%r9)
    9f10:	45 85 e4             	test   %r12d,%r12d
    9f13:	0f 8e 07 05 00 00    	jle    a420 <fwp_write+0xa10>
    9f19:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9f20:	55 55 55 
    9f23:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9f28:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9f2f:	aa aa aa 
    9f32:	49 83 c1 01          	add    $0x1,%r9
    9f36:	eb 45                	jmp    9f7d <fwp_write+0x56d>
    9f38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f3f:	00 
    9f40:	be 01 00 00 00       	mov    $0x1,%esi
    9f45:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9f4a:	88 07                	mov    %al,(%rdi)
    9f4c:	48 89 e8             	mov    %rbp,%rax
    9f4f:	49 f7 e8             	imul   %r8
    9f52:	48 89 e8             	mov    %rbp,%rax
    9f55:	48 c1 f8 3f          	sar    $0x3f,%rax
    9f59:	48 29 c2             	sub    %rax,%rdx
    9f5c:	48 85 c9             	test   %rcx,%rcx
    9f5f:	0f 95 c0             	setne  %al
    9f62:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9f66:	48 83 ef 01          	sub    $0x1,%rdi
    9f6a:	48 21 c5             	and    %rax,%rbp
    9f6d:	48 29 ea             	sub    %rbp,%rdx
    9f70:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9f74:	49 39 f9             	cmp    %rdi,%r9
    9f77:	0f 84 a3 04 00 00    	je     a420 <fwp_write+0xa10>
    9f7d:	48 89 e8             	mov    %rbp,%rax
    9f80:	49 f7 e8             	imul   %r8
    9f83:	48 89 e8             	mov    %rbp,%rax
    9f86:	48 c1 f8 3f          	sar    $0x3f,%rax
    9f8a:	48 89 d1             	mov    %rdx,%rcx
    9f8d:	48 29 c1             	sub    %rax,%rcx
    9f90:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9f94:	48 89 e9             	mov    %rbp,%rcx
    9f97:	48 29 c1             	sub    %rax,%rcx
    9f9a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9f9e:	49 f7 e2             	mul    %r10
    9fa1:	b8 30 00 00 00       	mov    $0x30,%eax
    9fa6:	48 89 d6             	mov    %rdx,%rsi
    9fa9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9fad:	48 d1 ee             	shr    $1,%rsi
    9fb0:	48 01 f2             	add    %rsi,%rdx
    9fb3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9fb7:	48 29 d6             	sub    %rdx,%rsi
    9fba:	74 8e                	je     9f4a <fwp_write+0x53a>
    9fbc:	48 83 fe 01          	cmp    $0x1,%rsi
    9fc0:	0f 85 7a ff ff ff    	jne    9f40 <fwp_write+0x530>
    9fc6:	31 f6                	xor    %esi,%esi
    9fc8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9fcd:	e9 78 ff ff ff       	jmp    9f4a <fwp_write+0x53a>
    9fd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9fd8:	66 0f 6e cd          	movd   %ebp,%xmm1
    9fdc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9fdf:	0f 8a c8 09 00 00    	jp     a9ad <fwp_write+0xf9d>
    9fe5:	0f 28 c1             	movaps %xmm1,%xmm0
    9fe8:	0f 54 05 11 3b 00 00 	andps  0x3b11(%rip),%xmm0        # db00 <msg.4+0x80>
    9fef:	0f 2e 05 0e 30 00 00 	ucomiss 0x300e(%rip),%xmm0        # d004 <_IO_stdin_used+0x4>
    9ff6:	0f 87 24 08 00 00    	ja     a820 <fwp_write+0xe10>
    9ffc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a000:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a006:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a00d:	00 
    a00e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a012:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a01e:	00 00 
    a020:	44 89 ee             	mov    %r13d,%esi
    a023:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a028:	4c 89 e7             	mov    %r12,%rdi
    a02b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a030:	e8 8b a4 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a035:	31 f6                	xor    %esi,%esi
    a037:	4c 89 e7             	mov    %r12,%rdi
    a03a:	e8 71 94 ff ff       	call   34b0 <strtof@plt>
    a03f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a044:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a047:	7a 02                	jp     a04b <fwp_write+0x63b>
    a049:	74 1c                	je     a067 <fwp_write+0x657>
    a04b:	41 83 c5 01          	add    $0x1,%r13d
    a04f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a053:	75 cb                	jne    a020 <fwp_write+0x610>
    a055:	be 09 00 00 00       	mov    $0x9,%esi
    a05a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a05f:	4c 89 e7             	mov    %r12,%rdi
    a062:	e8 59 a4 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a067:	4c 89 e7             	mov    %r12,%rdi
    a06a:	e8 c1 a0 ff ff       	call   4130 <fwp_finish_float>
    a06f:	e9 1c fa ff ff       	jmp    9a90 <fwp_write+0x80>
    a074:	0f 1f 40 00          	nopl   0x0(%rax)
    a078:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a07c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a080:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a087:	00 
    a088:	48 89 ef             	mov    %rbp,%rdi
    a08b:	e8 b0 99 ff ff       	call   3a40 <fwp_fmt_u128>
    a090:	48 89 ef             	mov    %rbp,%rdi
    a093:	e8 b8 93 ff ff       	call   3450 <strlen@plt>
    a098:	48 89 ee             	mov    %rbp,%rsi
    a09b:	48 89 df             	mov    %rbx,%rdi
    a09e:	48 89 c2             	mov    %rax,%rdx
    a0a1:	e8 ca 9f ff ff       	call   4070 <buf_put>
    a0a6:	e9 fb f9 ff ff       	jmp    9aa6 <fwp_write+0x96>
    a0ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a0b0:	ba 06 00 00 00       	mov    $0x6,%edx
    a0b5:	48 8d 35 08 31 00 00 	lea    0x3108(%rip),%rsi        # d1c4 <_IO_stdin_used+0x1c4>
    a0bc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a0c2:	e8 a9 9f ff ff       	call   4070 <buf_put>
    a0c7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a0ce:	ff ff 7f 
    a0d1:	48 23 55 00          	and    0x0(%rbp),%rdx
    a0d5:	0f 84 86 02 00 00    	je     a361 <fwp_write+0x951>
    a0db:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a0e0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a0e4:	48 85 d2             	test   %rdx,%rdx
    a0e7:	0f 84 ae 00 00 00    	je     a19b <fwp_write+0x78b>
    a0ed:	8b 0a                	mov    (%rdx),%ecx
    a0ef:	83 f9 1c             	cmp    $0x1c,%ecx
    a0f2:	0f 84 58 06 00 00    	je     a750 <fwp_write+0xd40>
    a0f8:	83 f9 1b             	cmp    $0x1b,%ecx
    a0fb:	0f 87 9a 00 00 00    	ja     a19b <fwp_write+0x78b>
    a101:	be 01 00 00 00       	mov    $0x1,%esi
    a106:	48 d3 e6             	shl    %cl,%rsi
    a109:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a10f:	0f 85 4b 04 00 00    	jne    a560 <fwp_write+0xb50>
    a115:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a11b:	0f 85 0f 04 00 00    	jne    a530 <fwp_write+0xb20>
    a121:	83 e6 21             	and    $0x21,%esi
    a124:	74 75                	je     a19b <fwp_write+0x78b>
    a126:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a12b:	48 85 ff             	test   %rdi,%rdi
    a12e:	79 07                	jns    a137 <fwp_write+0x727>
    a130:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a134:	4c 01 ee             	add    %r13,%rsi
    a137:	48 0f be 3e          	movsbq (%rsi),%rdi
    a13b:	85 c9                	test   %ecx,%ecx
    a13d:	40 0f b6 f7          	movzbl %dil,%esi
    a141:	48 0f 44 f7          	cmove  %rdi,%rsi
    a145:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a14c:	00 00 00 00 
    a150:	31 c9                	xor    %ecx,%ecx
    a152:	48 89 df             	mov    %rbx,%rdi
    a155:	49 83 c5 01          	add    $0x1,%r13
    a159:	e8 b2 f8 ff ff       	call   9a10 <fwp_write>
    a15e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a165:	ff ff 7f 
    a168:	48 23 55 00          	and    0x0(%rbp),%rdx
    a16c:	49 39 d5             	cmp    %rdx,%r13
    a16f:	0f 83 ec 01 00 00    	jae    a361 <fwp_write+0x951>
    a175:	ba 02 00 00 00       	mov    $0x2,%edx
    a17a:	48 89 df             	mov    %rbx,%rdi
    a17d:	48 8d 35 3d 30 00 00 	lea    0x303d(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    a184:	e8 e7 9e ff ff       	call   4070 <buf_put>
    a189:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a18e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a192:	48 85 d2             	test   %rdx,%rdx
    a195:	0f 85 52 ff ff ff    	jne    a0ed <fwp_write+0x6dd>
    a19b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a1a0:	48 85 ff             	test   %rdi,%rdi
    a1a3:	0f 88 cf 05 00 00    	js     a778 <fwp_write+0xd68>
    a1a9:	48 8b 31             	mov    (%rcx),%rsi
    a1ac:	eb a2                	jmp    a150 <fwp_write+0x740>
    a1ae:	66 90                	xchg   %ax,%ax
    a1b0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a1b7:	00 
    a1b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a1bf:	00 00 
    a1c1:	0f 85 1e fd ff ff    	jne    9ee5 <fwp_write+0x4d5>
    a1c7:	ba 08 00 00 00       	mov    $0x8,%edx
    a1cc:	48 8d 35 be 2f 00 00 	lea    0x2fbe(%rip),%rsi        # d191 <_IO_stdin_used+0x191>
    a1d3:	e9 4b fa ff ff       	jmp    9c23 <fwp_write+0x213>
    a1d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1df:	00 
    a1e0:	89 e8                	mov    %ebp,%eax
    a1e2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a1e9:	76 03                	jbe    a1ee <fwp_write+0x7de>
    a1eb:	8b 45 00             	mov    0x0(%rbp),%eax
    a1ee:	41 89 c6             	mov    %eax,%r14d
    a1f1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a1f6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a1fb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a1ff:	4c 89 ef             	mov    %r13,%rdi
    a202:	e8 49 92 ff ff       	call   3450 <strlen@plt>
    a207:	4c 89 ee             	mov    %r13,%rsi
    a20a:	48 89 df             	mov    %rbx,%rdi
    a20d:	48 89 c2             	mov    %rax,%rdx
    a210:	e8 5b 9e ff ff       	call   4070 <buf_put>
    a215:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a21a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a21e:	85 f6                	test   %esi,%esi
    a220:	0f 8e 80 f8 ff ff    	jle    9aa6 <fwp_write+0x96>
    a226:	45 31 ed             	xor    %r13d,%r13d
    a229:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a22e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a233:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a238:	ba 01 00 00 00       	mov    $0x1,%edx
    a23d:	4c 89 fe             	mov    %r15,%rsi
    a240:	48 89 04 24          	mov    %rax,(%rsp)
    a244:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a249:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a24d:	48 89 df             	mov    %rbx,%rdi
    a250:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a254:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a259:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a25e:	e8 0d 9e ff ff       	call   4070 <buf_put>
    a263:	41 8b 06             	mov    (%r14),%eax
    a266:	83 f8 0e             	cmp    $0xe,%eax
    a269:	0f 84 71 02 00 00    	je     a4e0 <fwp_write+0xad0>
    a26f:	83 f8 10             	cmp    $0x10,%eax
    a272:	0f 84 38 02 00 00    	je     a4b0 <fwp_write+0xaa0>
    a278:	83 f8 0a             	cmp    $0xa,%eax
    a27b:	0f 84 7f 04 00 00    	je     a700 <fwp_write+0xcf0>
    a281:	0f 8f f9 00 00 00    	jg     a380 <fwp_write+0x970>
    a287:	83 f8 03             	cmp    $0x3,%eax
    a28a:	0f 8f 50 04 00 00    	jg     a6e0 <fwp_write+0xcd0>
    a290:	85 c0                	test   %eax,%eax
    a292:	78 10                	js     a2a4 <fwp_write+0x894>
    a294:	48 8b 04 24          	mov    (%rsp),%rax
    a298:	48 c1 e8 3f          	shr    $0x3f,%rax
    a29c:	85 c0                	test   %eax,%eax
    a29e:	0f 85 f9 00 00 00    	jne    a39d <fwp_write+0x98d>
    a2a4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a2a9:	48 8b 34 24          	mov    (%rsp),%rsi
    a2ad:	31 c9                	xor    %ecx,%ecx
    a2af:	48 89 df             	mov    %rbx,%rdi
    a2b2:	e8 59 f7 ff ff       	call   9a10 <fwp_write>
    a2b7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a2bc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a2c1:	49 83 c5 01          	add    $0x1,%r13
    a2c5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a2c9:	0f 8f 5f ff ff ff    	jg     a22e <fwp_write+0x81e>
    a2cf:	e9 d2 f7 ff ff       	jmp    9aa6 <fwp_write+0x96>
    a2d4:	0f 1f 40 00          	nopl   0x0(%rax)
    a2d8:	ba 06 00 00 00       	mov    $0x6,%edx
    a2dd:	48 8d 35 d3 2e 00 00 	lea    0x2ed3(%rip),%rsi        # d1b7 <_IO_stdin_used+0x1b7>
    a2e4:	45 31 ed             	xor    %r13d,%r13d
    a2e7:	e8 84 9d ff ff       	call   4070 <buf_put>
    a2ec:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a2f1:	75 19                	jne    a30c <fwp_write+0x8fc>
    a2f3:	eb 6c                	jmp    a361 <fwp_write+0x951>
    a2f5:	0f 1f 00             	nopl   (%rax)
    a2f8:	ba 02 00 00 00       	mov    $0x2,%edx
    a2fd:	48 8d 35 bd 2e 00 00 	lea    0x2ebd(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    a304:	48 89 df             	mov    %rbx,%rdi
    a307:	e8 64 9d ff ff       	call   4070 <buf_put>
    a30c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a312:	b9 00 02 00 00       	mov    $0x200,%ecx
    a317:	31 c0                	xor    %eax,%eax
    a319:	49 83 c5 01          	add    $0x1,%r13
    a31d:	4c 8d 05 9a 2e 00 00 	lea    0x2e9a(%rip),%r8        # d1be <_IO_stdin_used+0x1be>
    a324:	ba 02 00 00 00       	mov    $0x2,%edx
    a329:	be 00 02 00 00       	mov    $0x200,%esi
    a32e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a335:	00 
    a336:	e8 75 90 ff ff       	call   33b0 <__snprintf_chk@plt>
    a33b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a342:	00 
    a343:	e8 08 91 ff ff       	call   3450 <strlen@plt>
    a348:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a34f:	00 
    a350:	48 89 df             	mov    %rbx,%rdi
    a353:	48 89 c2             	mov    %rax,%rdx
    a356:	e8 15 9d ff ff       	call   4070 <buf_put>
    a35b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a35f:	72 97                	jb     a2f8 <fwp_write+0x8e8>
    a361:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a366:	ba 01 00 00 00       	mov    $0x1,%edx
    a36b:	48 89 df             	mov    %rbx,%rdi
    a36e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a373:	e8 f8 9c ff ff       	call   4070 <buf_put>
    a378:	e9 29 f7 ff ff       	jmp    9aa6 <fwp_write+0x96>
    a37d:	0f 1f 00             	nopl   (%rax)
    a380:	83 f8 0b             	cmp    $0xb,%eax
    a383:	0f 85 1b ff ff ff    	jne    a2a4 <fwp_write+0x894>
    a389:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a38e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a392:	83 e0 01             	and    $0x1,%eax
    a395:	85 c0                	test   %eax,%eax
    a397:	0f 84 07 ff ff ff    	je     a2a4 <fwp_write+0x894>
    a39d:	4c 89 fe             	mov    %r15,%rsi
    a3a0:	48 89 df             	mov    %rbx,%rdi
    a3a3:	ba 01 00 00 00       	mov    $0x1,%edx
    a3a8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a3ad:	e8 be 9c ff ff       	call   4070 <buf_put>
    a3b2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a3b7:	48 8b 34 24          	mov    (%rsp),%rsi
    a3bb:	31 c9                	xor    %ecx,%ecx
    a3bd:	48 89 df             	mov    %rbx,%rdi
    a3c0:	e8 4b f6 ff ff       	call   9a10 <fwp_write>
    a3c5:	ba 01 00 00 00       	mov    $0x1,%edx
    a3ca:	4c 89 fe             	mov    %r15,%rsi
    a3cd:	48 89 df             	mov    %rbx,%rdi
    a3d0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a3d5:	e8 96 9c ff ff       	call   4070 <buf_put>
    a3da:	e9 d8 fe ff ff       	jmp    a2b7 <fwp_write+0x8a7>
    a3df:	90                   	nop
    a3e0:	ba 01 00 00 00       	mov    $0x1,%edx
    a3e5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a3ea:	48 89 df             	mov    %rbx,%rdi
    a3ed:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a3f2:	e8 79 9c ff ff       	call   4070 <buf_put>
    a3f7:	e9 aa f6 ff ff       	jmp    9aa6 <fwp_write+0x96>
    a3fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a400:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a405:	ba 01 00 00 00       	mov    $0x1,%edx
    a40a:	48 89 df             	mov    %rbx,%rdi
    a40d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a412:	e8 59 9c ff ff       	call   4070 <buf_put>
    a417:	e9 8a f6 ff ff       	jmp    9aa6 <fwp_write+0x96>
    a41c:	0f 1f 40 00          	nopl   0x0(%rax)
    a420:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a424:	48 8b 13             	mov    (%rbx),%rdx
    a427:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a42c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a430:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a434:	e9 6d f6 ff ff       	jmp    9aa6 <fwp_write+0x96>
    a439:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a440:	ba 02 00 00 00       	mov    $0x2,%edx
    a445:	48 8d 35 75 2d 00 00 	lea    0x2d75(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    a44c:	48 89 df             	mov    %rbx,%rdi
    a44f:	e8 1c 9c ff ff       	call   4070 <buf_put>
    a454:	e9 72 f8 ff ff       	jmp    9ccb <fwp_write+0x2bb>
    a459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a460:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a465:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a46a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a46e:	48 89 f7             	mov    %rsi,%rdi
    a471:	48 89 34 24          	mov    %rsi,(%rsp)
    a475:	e8 d6 8f ff ff       	call   3450 <strlen@plt>
    a47a:	48 8b 34 24          	mov    (%rsp),%rsi
    a47e:	48 89 df             	mov    %rbx,%rdi
    a481:	48 89 c2             	mov    %rax,%rdx
    a484:	e8 e7 9b ff ff       	call   4070 <buf_put>
    a489:	ba 03 00 00 00       	mov    $0x3,%edx
    a48e:	48 8d 35 4f 2d 00 00 	lea    0x2d4f(%rip),%rsi        # d1e4 <_IO_stdin_used+0x1e4>
    a495:	48 89 df             	mov    %rbx,%rdi
    a498:	e8 d3 9b ff ff       	call   4070 <buf_put>
    a49d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a4a2:	e9 35 f8 ff ff       	jmp    9cdc <fwp_write+0x2cc>
    a4a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4ae:	00 00 
    a4b0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a4b5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a4b9:	48 85 ff             	test   %rdi,%rdi
    a4bc:	0f 84 e2 fd ff ff    	je     a2a4 <fwp_write+0x894>
    a4c2:	48 8d 35 05 2d 00 00 	lea    0x2d05(%rip),%rsi        # d1ce <_IO_stdin_used+0x1ce>
    a4c9:	e8 62 90 ff ff       	call   3530 <strcmp@plt>
    a4ce:	85 c0                	test   %eax,%eax
    a4d0:	0f 95 c0             	setne  %al
    a4d3:	0f b6 c0             	movzbl %al,%eax
    a4d6:	e9 c1 fd ff ff       	jmp    a29c <fwp_write+0x88c>
    a4db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4e0:	31 c0                	xor    %eax,%eax
    a4e2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a4e9:	00 
    a4ea:	0f 97 c0             	seta   %al
    a4ed:	e9 aa fd ff ff       	jmp    a29c <fwp_write+0x88c>
    a4f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4f8:	48 89 df             	mov    %rbx,%rdi
    a4fb:	ba 02 00 00 00       	mov    $0x2,%edx
    a500:	48 8d 35 c4 2c 00 00 	lea    0x2cc4(%rip),%rsi        # d1cb <_IO_stdin_used+0x1cb>
    a507:	e8 64 9b ff ff       	call   4070 <buf_put>
    a50c:	4c 89 e8             	mov    %r13,%rax
    a50f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a514:	31 c9                	xor    %ecx,%ecx
    a516:	48 c1 e0 04          	shl    $0x4,%rax
    a51a:	48 89 df             	mov    %rbx,%rdi
    a51d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a522:	e8 e9 f4 ff ff       	call   9a10 <fwp_write>
    a527:	e9 5e f6 ff ff       	jmp    9b8a <fwp_write+0x17a>
    a52c:	0f 1f 40 00          	nopl   0x0(%rax)
    a530:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a535:	48 85 ff             	test   %rdi,%rdi
    a538:	79 0c                	jns    a546 <fwp_write+0xb36>
    a53a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a541:	00 
    a542:	48 03 75 10          	add    0x10(%rbp),%rsi
    a546:	48 63 3e             	movslq (%rsi),%rdi
    a549:	83 f9 02             	cmp    $0x2,%ecx
    a54c:	89 fe                	mov    %edi,%esi
    a54e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a552:	e9 f9 fb ff ff       	jmp    a150 <fwp_write+0x740>
    a557:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a55e:	00 00 
    a560:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a565:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a56a:	48 85 ff             	test   %rdi,%rdi
    a56d:	0f 88 0f 03 00 00    	js     a882 <fwp_write+0xe72>
    a573:	49 0f bf 38          	movswq (%r8),%rdi
    a577:	83 f9 01             	cmp    $0x1,%ecx
    a57a:	0f b7 f7             	movzwl %di,%esi
    a57d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a581:	e9 ca fb ff ff       	jmp    a150 <fwp_write+0x740>
    a586:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a58d:	00 00 00 
    a590:	ba 01 00 00 00       	mov    $0x1,%edx
    a595:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a59a:	48 83 c5 08          	add    $0x8,%rbp
    a59e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a5a3:	e8 c8 9a ff ff       	call   4070 <buf_put>
    a5a8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a5ad:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a5b2:	4d 85 ed             	test   %r13,%r13
    a5b5:	75 46                	jne    a5fd <fwp_write+0xbed>
    a5b7:	e9 04 01 00 00       	jmp    a6c0 <fwp_write+0xcb0>
    a5bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a5c0:	41 80 f9 09          	cmp    $0x9,%r9b
    a5c4:	0f 84 d6 00 00 00    	je     a6a0 <fwp_write+0xc90>
    a5ca:	41 80 f9 0a          	cmp    $0xa,%r9b
    a5ce:	0f 85 9c 00 00 00    	jne    a670 <fwp_write+0xc60>
    a5d4:	ba 02 00 00 00       	mov    $0x2,%edx
    a5d9:	48 8d 35 c7 2b 00 00 	lea    0x2bc7(%rip),%rsi        # d1a7 <_IO_stdin_used+0x1a7>
    a5e0:	48 89 df             	mov    %rbx,%rdi
    a5e3:	e8 88 9a ff ff       	call   4070 <buf_put>
    a5e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a5ef:	00 
    a5f0:	48 83 c5 01          	add    $0x1,%rbp
    a5f4:	49 39 ec             	cmp    %rbp,%r12
    a5f7:	0f 84 c3 00 00 00    	je     a6c0 <fwp_write+0xcb0>
    a5fd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a602:	41 80 f9 0d          	cmp    $0xd,%r9b
    a606:	74 28                	je     a630 <fwp_write+0xc20>
    a608:	7e b6                	jle    a5c0 <fwp_write+0xbb0>
    a60a:	41 80 f9 22          	cmp    $0x22,%r9b
    a60e:	74 40                	je     a650 <fwp_write+0xc40>
    a610:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a614:	75 5a                	jne    a670 <fwp_write+0xc60>
    a616:	ba 02 00 00 00       	mov    $0x2,%edx
    a61b:	48 8d 35 82 2b 00 00 	lea    0x2b82(%rip),%rsi        # d1a4 <_IO_stdin_used+0x1a4>
    a622:	48 89 df             	mov    %rbx,%rdi
    a625:	e8 46 9a ff ff       	call   4070 <buf_put>
    a62a:	eb c4                	jmp    a5f0 <fwp_write+0xbe0>
    a62c:	0f 1f 40 00          	nopl   0x0(%rax)
    a630:	ba 02 00 00 00       	mov    $0x2,%edx
    a635:	48 8d 35 71 2b 00 00 	lea    0x2b71(%rip),%rsi        # d1ad <_IO_stdin_used+0x1ad>
    a63c:	48 89 df             	mov    %rbx,%rdi
    a63f:	e8 2c 9a ff ff       	call   4070 <buf_put>
    a644:	eb aa                	jmp    a5f0 <fwp_write+0xbe0>
    a646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a64d:	00 00 00 
    a650:	ba 02 00 00 00       	mov    $0x2,%edx
    a655:	48 8d 35 45 2b 00 00 	lea    0x2b45(%rip),%rsi        # d1a1 <_IO_stdin_used+0x1a1>
    a65c:	48 89 df             	mov    %rbx,%rdi
    a65f:	e8 0c 9a ff ff       	call   4070 <buf_put>
    a664:	eb 8a                	jmp    a5f0 <fwp_write+0xbe0>
    a666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a66d:	00 00 00 
    a670:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a674:	0f 86 2e 01 00 00    	jbe    a7a8 <fwp_write+0xd98>
    a67a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a67e:	0f 84 24 01 00 00    	je     a7a8 <fwp_write+0xd98>
    a684:	ba 01 00 00 00       	mov    $0x1,%edx
    a689:	4c 89 fe             	mov    %r15,%rsi
    a68c:	48 89 df             	mov    %rbx,%rdi
    a68f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a694:	e8 d7 99 ff ff       	call   4070 <buf_put>
    a699:	e9 52 ff ff ff       	jmp    a5f0 <fwp_write+0xbe0>
    a69e:	66 90                	xchg   %ax,%ax
    a6a0:	ba 02 00 00 00       	mov    $0x2,%edx
    a6a5:	48 8d 35 fe 2a 00 00 	lea    0x2afe(%rip),%rsi        # d1aa <_IO_stdin_used+0x1aa>
    a6ac:	48 89 df             	mov    %rbx,%rdi
    a6af:	e8 bc 99 ff ff       	call   4070 <buf_put>
    a6b4:	e9 37 ff ff ff       	jmp    a5f0 <fwp_write+0xbe0>
    a6b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6c0:	ba 01 00 00 00       	mov    $0x1,%edx
    a6c5:	4c 89 fe             	mov    %r15,%rsi
    a6c8:	48 89 df             	mov    %rbx,%rdi
    a6cb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a6d0:	e8 9b 99 ff ff       	call   4070 <buf_put>
    a6d5:	e9 cc f3 ff ff       	jmp    9aa6 <fwp_write+0x96>
    a6da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6e0:	83 f8 04             	cmp    $0x4,%eax
    a6e3:	0f 85 bb fb ff ff    	jne    a2a4 <fwp_write+0x894>
    a6e9:	48 8b 04 24          	mov    (%rsp),%rax
    a6ed:	48 8b 40 08          	mov    0x8(%rax),%rax
    a6f1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a6f6:	48 c1 e8 3f          	shr    $0x3f,%rax
    a6fa:	e9 96 fc ff ff       	jmp    a395 <fwp_write+0x985>
    a6ff:	90                   	nop
    a700:	8b 0c 24             	mov    (%rsp),%ecx
    a703:	31 c0                	xor    %eax,%eax
    a705:	85 c9                	test   %ecx,%ecx
    a707:	0f 98 c0             	sets   %al
    a70a:	e9 86 fc ff ff       	jmp    a395 <fwp_write+0x985>
    a70f:	90                   	nop
    a710:	48 f7 d8             	neg    %rax
    a713:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a71a:	00 
    a71b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a722:	2d 
    a723:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a72a:	00 
    a72b:	48 83 d2 00          	adc    $0x0,%rdx
    a72f:	48 89 c6             	mov    %rax,%rsi
    a732:	48 f7 da             	neg    %rdx
    a735:	e8 06 93 ff ff       	call   3a40 <fwp_fmt_u128>
    a73a:	e9 51 f3 ff ff       	jmp    9a90 <fwp_write+0x80>
    a73f:	90                   	nop
    a740:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a745:	e9 c3 f5 ff ff       	jmp    9d0d <fwp_write+0x2fd>
    a74a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a750:	4c 89 e9             	mov    %r13,%rcx
    a753:	48 c1 e1 04          	shl    $0x4,%rcx
    a757:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a75c:	48 85 ff             	test   %rdi,%rdi
    a75f:	0f 89 eb f9 ff ff    	jns    a150 <fwp_write+0x740>
    a765:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a769:	48 89 ce             	mov    %rcx,%rsi
    a76c:	e9 df f9 ff ff       	jmp    a150 <fwp_write+0x740>
    a771:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a778:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a77f:	00 
    a780:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a784:	e9 20 fa ff ff       	jmp    a1a9 <fwp_write+0x799>
    a789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a790:	ba 02 00 00 00       	mov    $0x2,%edx
    a795:	48 8d 35 d0 29 00 00 	lea    0x29d0(%rip),%rsi        # d16c <_IO_stdin_used+0x16c>
    a79c:	e9 2d f7 ff ff       	jmp    9ece <fwp_write+0x4be>
    a7a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a7a8:	4c 8d 05 01 2a 00 00 	lea    0x2a01(%rip),%r8        # d1b0 <_IO_stdin_used+0x1b0>
    a7af:	b9 10 00 00 00       	mov    $0x10,%ecx
    a7b4:	31 c0                	xor    %eax,%eax
    a7b6:	ba 02 00 00 00       	mov    $0x2,%edx
    a7bb:	be 10 00 00 00       	mov    $0x10,%esi
    a7c0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7c7:	00 
    a7c8:	e8 e3 8b ff ff       	call   33b0 <__snprintf_chk@plt>
    a7cd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7d4:	00 
    a7d5:	e8 76 8c ff ff       	call   3450 <strlen@plt>
    a7da:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a7e1:	00 
    a7e2:	48 89 df             	mov    %rbx,%rdi
    a7e5:	48 89 c2             	mov    %rax,%rdx
    a7e8:	e8 83 98 ff ff       	call   4070 <buf_put>
    a7ed:	e9 fe fd ff ff       	jmp    a5f0 <fwp_write+0xbe0>
    a7f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a7fc:	48 8d 35 63 29 00 00 	lea    0x2963(%rip),%rsi        # d166 <_IO_stdin_used+0x166>
    a803:	48 8d 05 5b 29 00 00 	lea    0x295b(%rip),%rax        # d165 <_IO_stdin_used+0x165>
    a80a:	4c 89 e7             	mov    %r12,%rdi
    a80d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a811:	48 0f 46 f0          	cmovbe %rax,%rsi
    a815:	e8 d6 8b ff ff       	call   33f0 <strcpy@plt>
    a81a:	e9 71 f2 ff ff       	jmp    9a90 <fwp_write+0x80>
    a81f:	90                   	nop
    a820:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a824:	48 8d 35 3b 29 00 00 	lea    0x293b(%rip),%rsi        # d166 <_IO_stdin_used+0x166>
    a82b:	48 8d 05 33 29 00 00 	lea    0x2933(%rip),%rax        # d165 <_IO_stdin_used+0x165>
    a832:	0f 2f c8             	comiss %xmm0,%xmm1
    a835:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a83c:	00 
    a83d:	4c 89 e7             	mov    %r12,%rdi
    a840:	48 0f 46 f0          	cmovbe %rax,%rsi
    a844:	e8 a7 8b ff ff       	call   33f0 <strcpy@plt>
    a849:	e9 42 f2 ff ff       	jmp    9a90 <fwp_write+0x80>
    a84e:	66 90                	xchg   %ax,%ax
    a850:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a855:	45 85 c0             	test   %r8d,%r8d
    a858:	75 34                	jne    a88e <fwp_write+0xe7e>
    a85a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a861:	00 
    a862:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a869:	00 00 
    a86b:	0f 85 74 f6 ff ff    	jne    9ee5 <fwp_write+0x4d5>
    a871:	ba 02 00 00 00       	mov    $0x2,%edx
    a876:	48 8d 35 64 29 00 00 	lea    0x2964(%rip),%rsi        # d1e1 <_IO_stdin_used+0x1e1>
    a87d:	e9 a1 f3 ff ff       	jmp    9c23 <fwp_write+0x213>
    a882:	48 03 75 10          	add    0x10(%rbp),%rsi
    a886:	49 89 f0             	mov    %rsi,%r8
    a889:	e9 e5 fc ff ff       	jmp    a573 <fwp_write+0xb63>
    a88e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a893:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a898:	85 ff                	test   %edi,%edi
    a89a:	0f 84 fa f3 ff ff    	je     9c9a <fwp_write+0x28a>
    a8a0:	ba 01 00 00 00       	mov    $0x1,%edx
    a8a5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a8aa:	48 89 df             	mov    %rbx,%rdi
    a8ad:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a8b2:	e8 b9 97 ff ff       	call   4070 <buf_put>
    a8b7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a8bc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a8c1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a8c7:	85 c0                	test   %eax,%eax
    a8c9:	0f 8f f0 f3 ff ff    	jg     9cbf <fwp_write+0x2af>
    a8cf:	e9 34 f4 ff ff       	jmp    9d08 <fwp_write+0x2f8>
    a8d4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a8d8:	49 89 c5             	mov    %rax,%r13
    a8db:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a8e0:	49 89 c4             	mov    %rax,%r12
    a8e3:	49 c1 fd 3f          	sar    $0x3f,%r13
    a8e7:	4c 09 e8             	or     %r13,%rax
    a8ea:	0f 84 a7 00 00 00    	je     a997 <fwp_write+0xf87>
    a8f0:	48 8d 2d 29 4b 00 00 	lea    0x4b29(%rip),%rbp        # f420 <units.1>
    a8f7:	4d 89 e7             	mov    %r12,%r15
    a8fa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a8fe:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a903:	4c 89 ff             	mov    %r15,%rdi
    a906:	4c 89 ee             	mov    %r13,%rsi
    a909:	44 89 0c 24          	mov    %r9d,(%rsp)
    a90d:	48 99                	cqto
    a90f:	48 89 d1             	mov    %rdx,%rcx
    a912:	48 89 c2             	mov    %rax,%rdx
    a915:	e8 36 19 00 00       	call   c250 <__divmodti4>
    a91a:	44 8b 0c 24          	mov    (%rsp),%r9d
    a91e:	48 89 c1             	mov    %rax,%rcx
    a921:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a926:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a92b:	0f 84 94 00 00 00    	je     a9c5 <fwp_write+0xfb5>
    a931:	41 83 c1 01          	add    $0x1,%r9d
    a935:	48 83 c5 10          	add    $0x10,%rbp
    a939:	41 83 f9 05          	cmp    $0x5,%r9d
    a93d:	75 bb                	jne    a8fa <fwp_write+0xeea>
    a93f:	4d 85 ed             	test   %r13,%r13
    a942:	79 53                	jns    a997 <fwp_write+0xf87>
    a944:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a949:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a94e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a953:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a958:	48 99                	cqto
    a95a:	48 f7 d8             	neg    %rax
    a95d:	48 83 d2 00          	adc    $0x0,%rdx
    a961:	48 89 c6             	mov    %rax,%rsi
    a964:	48 f7 da             	neg    %rdx
    a967:	e8 d4 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a96c:	49 89 e8             	mov    %rbp,%r8
    a96f:	ba 00 02 00 00       	mov    $0x200,%edx
    a974:	be 02 00 00 00       	mov    $0x2,%esi
    a979:	31 c0                	xor    %eax,%eax
    a97b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a982:	00 
    a983:	48 8d 0d 52 28 00 00 	lea    0x2852(%rip),%rcx        # d1dc <_IO_stdin_used+0x1dc>
    a98a:	4c 89 e7             	mov    %r12,%rdi
    a98d:	e8 4e 8d ff ff       	call   36e0 <__sprintf_chk@plt>
    a992:	e9 f9 f0 ff ff       	jmp    9a90 <fwp_write+0x80>
    a997:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a99c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a9a1:	31 d2                	xor    %edx,%edx
    a9a3:	48 89 ef             	mov    %rbp,%rdi
    a9a6:	e8 95 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9ab:	eb bf                	jmp    a96c <fwp_write+0xf5c>
    a9ad:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a9b4:	4e 61 4e 00 
    a9b8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9bf:	00 
    a9c0:	e9 cb f0 ff ff       	jmp    9a90 <fwp_write+0x80>
    a9c5:	44 89 0c 24          	mov    %r9d,(%rsp)
    a9c9:	48 89 c8             	mov    %rcx,%rax
    a9cc:	48 85 d2             	test   %rdx,%rdx
    a9cf:	78 51                	js     aa22 <fwp_write+0x1012>
    a9d1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a9d6:	48 89 c6             	mov    %rax,%rsi
    a9d9:	48 89 ef             	mov    %rbp,%rdi
    a9dc:	e8 5f 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9e1:	44 8b 0c 24          	mov    (%rsp),%r9d
    a9e5:	49 63 c1             	movslq %r9d,%rax
    a9e8:	49 89 e8             	mov    %rbp,%r8
    a9eb:	ba 00 02 00 00       	mov    $0x200,%edx
    a9f0:	be 02 00 00 00       	mov    $0x2,%esi
    a9f5:	48 c1 e0 04          	shl    $0x4,%rax
    a9f9:	48 8d 3d 20 4a 00 00 	lea    0x4a20(%rip),%rdi        # f420 <units.1>
    aa00:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aa07:	00 
    aa08:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    aa0c:	48 8d 0d c4 27 00 00 	lea    0x27c4(%rip),%rcx        # d1d7 <_IO_stdin_used+0x1d7>
    aa13:	4c 89 e7             	mov    %r12,%rdi
    aa16:	31 c0                	xor    %eax,%eax
    aa18:	e8 c3 8c ff ff       	call   36e0 <__sprintf_chk@plt>
    aa1d:	e9 6e f0 ff ff       	jmp    9a90 <fwp_write+0x80>
    aa22:	48 f7 d8             	neg    %rax
    aa25:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    aa2a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    aa2f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aa34:	48 83 d2 00          	adc    $0x0,%rdx
    aa38:	48 89 c6             	mov    %rax,%rsi
    aa3b:	48 f7 da             	neg    %rdx
    aa3e:	e8 fd 8f ff ff       	call   3a40 <fwp_fmt_u128>
    aa43:	44 8b 0c 24          	mov    (%rsp),%r9d
    aa47:	eb 9c                	jmp    a9e5 <fwp_write+0xfd5>
    aa49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000aa50 <fwp_main_thread>:
    aa50:	f3 0f 1e fa          	endbr64
    aa54:	55                   	push   %rbp
    aa55:	48 89 e5             	mov    %rsp,%rbp
    aa58:	41 57                	push   %r15
    aa5a:	41 56                	push   %r14
    aa5c:	41 55                	push   %r13
    aa5e:	41 54                	push   %r12
    aa60:	53                   	push   %rbx
    aa61:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
    aa68:	44 8b 05 b5 80 01 00 	mov    0x180b5(%rip),%r8d        # 22b24 <fwp_heap+0x13a4>
    aa6f:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    aa76:	00 00 
    aa78:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    aa7c:	31 c0                	xor    %eax,%eax
    aa7e:	45 85 c0             	test   %r8d,%r8d
    aa81:	0f 84 09 06 00 00    	je     b090 <fwp_main_thread+0x640>
    aa87:	8b 3d 9b 80 01 00    	mov    0x1809b(%rip),%edi        # 22b28 <fwp_heap+0x13a8>
    aa8d:	85 ff                	test   %edi,%edi
    aa8f:	0f 85 0e 06 00 00    	jne    b0a3 <fwp_main_thread+0x653>
    aa95:	48 8d 05 04 66 00 00 	lea    0x6604(%rip),%rax        # 110a0 <alt.5>
    aa9c:	31 f6                	xor    %esi,%esi
    aa9e:	4c 8d a5 d0 fe ff ff 	lea    -0x130(%rbp),%r12
    aaa5:	48 c7 05 68 66 01 00 	movq   $0x40000000,0x16668(%rip)        # 21118 <fwp_main_stack_size>
    aaac:	00 00 00 40 
    aab0:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
    aab7:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
    aabe:	48 89 c7             	mov    %rax,%rdi
    aac1:	4c 89 25 58 66 01 00 	mov    %r12,0x16658(%rip)        # 21120 <fwp_main_stack_top>
    aac8:	48 c7 85 00 ff ff ff 	movq   $0x10000,-0x100(%rbp)
    aacf:	00 00 01 00 
    aad3:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
    aada:	00 00 00 
    aadd:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
    aae4:	e8 d7 8b ff ff       	call   36c0 <sigaltstack@plt>
    aae9:	85 c0                	test   %eax,%eax
    aaeb:	0f 85 b4 16 00 00    	jne    c1a5 <fwp_main_thread+0x1755>
    aaf1:	31 db                	xor    %ebx,%ebx
    aaf3:	b9 12 00 00 00       	mov    $0x12,%ecx
    aaf8:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    aaff:	48 89 d8             	mov    %rbx,%rax
    ab02:	4c 8d ad 30 ff ff ff 	lea    -0xd0(%rbp),%r13
    ab09:	f3 48 ab             	rep stos %rax,(%rdi)
    ab0c:	48 8d 05 dd 91 ff ff 	lea    -0x6e23(%rip),%rax        # 3cf0 <fwp_segv>
    ab13:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    ab1a:	c7 45 b8 04 00 00 08 	movl   $0x8000004,-0x48(%rbp)
    ab21:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
    ab28:	e8 53 8a ff ff       	call   3580 <sigemptyset@plt>
    ab2d:	85 c0                	test   %eax,%eax
    ab2f:	0f 85 70 16 00 00    	jne    c1a5 <fwp_main_thread+0x1755>
    ab35:	31 d2                	xor    %edx,%edx
    ab37:	4c 89 ee             	mov    %r13,%rsi
    ab3a:	bf 0b 00 00 00       	mov    $0xb,%edi
    ab3f:	e8 bc 88 ff ff       	call   3400 <sigaction@plt>
    ab44:	85 c0                	test   %eax,%eax
    ab46:	0f 85 59 16 00 00    	jne    c1a5 <fwp_main_thread+0x1755>
    ab4c:	31 d2                	xor    %edx,%edx
    ab4e:	4c 89 ee             	mov    %r13,%rsi
    ab51:	bf 07 00 00 00       	mov    $0x7,%edi
    ab56:	e8 a5 88 ff ff       	call   3400 <sigaction@plt>
    ab5b:	85 c0                	test   %eax,%eax
    ab5d:	0f 85 42 16 00 00    	jne    c1a5 <fwp_main_thread+0x1755>
    ab63:	8b 35 27 65 00 00    	mov    0x6527(%rip),%esi        # 11090 <st.3>
    ab69:	85 f6                	test   %esi,%esi
    ab6b:	0f 84 43 05 00 00    	je     b0b4 <fwp_main_thread+0x664>
    ab71:	4c 8b 25 e8 6b 01 00 	mov    0x16be8(%rip),%r12        # 21760 <fwp_cur>
    ab78:	4d 85 e4             	test   %r12,%r12
    ab7b:	0f 84 c5 01 00 00    	je     ad46 <fwp_main_thread+0x2f6>
    ab81:	45 0f b6 6c 24 52    	movzbl 0x52(%r12),%r13d
    ab87:	41 c6 44 24 52 01    	movb   $0x1,0x52(%r12)
    ab8d:	4c 89 e3             	mov    %r12,%rbx
    ab90:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    ab96:	0f 84 48 01 00 00    	je     ace4 <fwp_main_thread+0x294>
    ab9c:	49 83 7c 24 60 00    	cmpq   $0x0,0x60(%r12)
    aba2:	0f 84 91 02 00 00    	je     ae39 <fwp_main_thread+0x3e9>
    aba8:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    abae:	0f 84 69 02 00 00    	je     ae1d <fwp_main_thread+0x3cd>
    abb4:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    abb9:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    abbd:	0f 85 f7 02 00 00    	jne    aeba <fwp_main_thread+0x46a>
    abc3:	48 8b 43 60          	mov    0x60(%rbx),%rax
    abc7:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    abce:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    abd3:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    abda:	00 00 00 00 
    abde:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    abe5:	48 85 d2             	test   %rdx,%rdx
    abe8:	74 07                	je     abf1 <fwp_main_thread+0x1a1>
    abea:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    abf1:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    abf6:	48 85 c0             	test   %rax,%rax
    abf9:	74 34                	je     ac2f <fwp_main_thread+0x1df>
    abfb:	48 89 43 68          	mov    %rax,0x68(%rbx)
    abff:	48 8b 05 32 6b 01 00 	mov    0x16b32(%rip),%rax        # 21738 <fwp_timers>
    ac06:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    ac0a:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    ac11:	00 00 00 00 
    ac15:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    ac1c:	48 85 c0             	test   %rax,%rax
    ac1f:	74 07                	je     ac28 <fwp_main_thread+0x1d8>
    ac21:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    ac28:	48 89 1d 09 6b 01 00 	mov    %rbx,0x16b09(%rip)        # 21738 <fwp_timers>
    ac2f:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    ac33:	e8 f8 c3 ff ff       	call   7030 <fwp_block>
    ac38:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    ac3f:	48 85 c9             	test   %rcx,%rcx
    ac42:	74 47                	je     ac8b <fwp_main_thread+0x23b>
    ac44:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    ac4b:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ac52:	48 85 d2             	test   %rdx,%rdx
    ac55:	0f 84 57 02 00 00    	je     aeb2 <fwp_main_thread+0x462>
    ac5b:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    ac62:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ac69:	48 85 c0             	test   %rax,%rax
    ac6c:	74 07                	je     ac75 <fwp_main_thread+0x225>
    ac6e:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    ac75:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    ac7c:	00 00 00 00 
    ac80:	66 0f ef d2          	pxor   %xmm2,%xmm2
    ac84:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    ac8b:	48 8b 0d ce 6a 01 00 	mov    0x16ace(%rip),%rcx        # 21760 <fwp_cur>
    ac92:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    ac96:	0f 84 0e 02 00 00    	je     aeaa <fwp_main_thread+0x45a>
    ac9c:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    aca3:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    acaa:	48 85 d2             	test   %rdx,%rdx
    acad:	0f 84 d1 03 00 00    	je     b084 <fwp_main_thread+0x634>
    acb3:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    acba:	48 85 c0             	test   %rax,%rax
    acbd:	74 07                	je     acc6 <fwp_main_thread+0x276>
    acbf:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    acc6:	66 0f ef db          	pxor   %xmm3,%xmm3
    acca:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    acce:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    acd5:	48 89 cb             	mov    %rcx,%rbx
    acd8:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    acde:	0f 85 b8 fe ff ff    	jne    ab9c <fwp_main_thread+0x14c>
    ace4:	48 83 3d 0c 87 01 00 	cmpq   $0x0,0x1870c(%rip)        # 233f8 <fwp_state_len>
    aceb:	00 
    acec:	45 88 6c 24 52       	mov    %r13b,0x52(%r12)
    acf1:	74 63                	je     ad56 <fwp_main_thread+0x306>
    acf3:	48 39 1d 5e 6a 01 00 	cmp    %rbx,0x16a5e(%rip)        # 21758 <fwp_root>
    acfa:	c7 05 9c 63 01 00 00 	movl   $0x0,0x1639c(%rip)        # 210a0 <fwp_exit_code>
    ad01:	00 00 00 
    ad04:	0f 85 40 15 00 00    	jne    c24a <fwp_main_thread+0x17fa>
    ad0a:	48 85 db             	test   %rbx,%rbx
    ad0d:	0f 84 f7 01 00 00    	je     af0a <fwp_main_thread+0x4ba>
    ad13:	48 8b 15 0e 6a 01 00 	mov    0x16a0e(%rip),%rdx        # 21728 <fwp_tasks_active>
    ad1a:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    ad1e:	48 85 d2             	test   %rdx,%rdx
    ad21:	0f 84 e3 01 00 00    	je     af0a <fwp_main_thread+0x4ba>
    ad27:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    ad2b:	75 08                	jne    ad35 <fwp_main_thread+0x2e5>
    ad2d:	48 89 d7             	mov    %rdx,%rdi
    ad30:	e8 7b 93 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    ad35:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    ad3c:	48 85 d2             	test   %rdx,%rdx
    ad3f:	75 e6                	jne    ad27 <fwp_main_thread+0x2d7>
    ad41:	e9 a7 00 00 00       	jmp    aded <fwp_main_thread+0x39d>
    ad46:	48 83 3d aa 86 01 00 	cmpq   $0x0,0x186aa(%rip)        # 233f8 <fwp_state_len>
    ad4d:	00 
    ad4e:	0f 85 9e 01 00 00    	jne    aef2 <fwp_main_thread+0x4a2>
    ad54:	31 db                	xor    %ebx,%ebx
    ad56:	48 83 3d 8a 86 01 00 	cmpq   $0x0,0x1868a(%rip)        # 233e8 <fwp_state_owners>
    ad5d:	00 
    ad5e:	75 93                	jne    acf3 <fwp_main_thread+0x2a3>
    ad60:	48 8b 3d 99 86 01 00 	mov    0x18699(%rip),%rdi        # 23400 <fwp_state>
    ad67:	e8 e4 a7 ff ff       	call   5550 <fwp_mem_free>
    ad6c:	48 c7 05 89 86 01 00 	movq   $0x0,0x18689(%rip)        # 23400 <fwp_state>
    ad73:	00 00 00 00 
    ad77:	48 c7 05 6e 86 01 00 	movq   $0x0,0x1866e(%rip)        # 233f0 <fwp_state_cap>
    ad7e:	00 00 00 00 
    ad82:	48 85 db             	test   %rbx,%rbx
    ad85:	0f 84 a3 13 00 00    	je     c12e <fwp_main_thread+0x16de>
    ad8b:	48 39 1d c6 69 01 00 	cmp    %rbx,0x169c6(%rip)        # 21758 <fwp_root>
    ad92:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    ad99:	00 00 00 00 
    ad9d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    ada4:	00 00 00 00 
    ada8:	c7 05 ee 62 01 00 00 	movl   $0x0,0x162ee(%rip)        # 210a0 <fwp_exit_code>
    adaf:	00 00 00 
    adb2:	0f 84 5b ff ff ff    	je     ad13 <fwp_main_thread+0x2c3>
    adb8:	e9 93 89 ff ff       	jmp    3750 <fwp_main_thread.cold>
    adbd:	0f 1f 00             	nopl   (%rax)
    adc0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    adc7:	48 89 1d 72 69 01 00 	mov    %rbx,0x16972(%rip)        # 21740 <fwp_ready_tail>
    adce:	e8 5d c2 ff ff       	call   7030 <fwp_block>
    add3:	e8 58 c0 ff ff       	call   6e30 <fwp_free_zombie>
    add8:	48 83 3d 48 69 01 00 	cmpq   $0x0,0x16948(%rip)        # 21728 <fwp_tasks_active>
    addf:	00 
    ade0:	0f 84 24 01 00 00    	je     af0a <fwp_main_thread+0x4ba>
    ade6:	48 8b 1d 6b 69 01 00 	mov    0x1696b(%rip),%rbx        # 21758 <fwp_root>
    aded:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    adf1:	75 db                	jne    adce <fwp_main_thread+0x37e>
    adf3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    adf7:	75 d5                	jne    adce <fwp_main_thread+0x37e>
    adf9:	48 8b 05 40 69 01 00 	mov    0x16940(%rip),%rax        # 21740 <fwp_ready_tail>
    ae00:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    ae04:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    ae0b:	00 00 00 00 
    ae0f:	48 85 c0             	test   %rax,%rax
    ae12:	75 ac                	jne    adc0 <fwp_main_thread+0x370>
    ae14:	48 89 1d 2d 69 01 00 	mov    %rbx,0x1692d(%rip)        # 21748 <fwp_ready_head>
    ae1b:	eb aa                	jmp    adc7 <fwp_main_thread+0x377>
    ae1d:	e8 ee 94 ff ff       	call   4310 <fwp_now_ns>
    ae22:	49 3b 44 24 60       	cmp    0x60(%r12),%rax
    ae27:	7c 10                	jl     ae39 <fwp_main_thread+0x3e9>
    ae29:	41 80 7c 24 50 00    	cmpb   $0x0,0x50(%r12)
    ae2f:	75 08                	jne    ae39 <fwp_main_thread+0x3e9>
    ae31:	4c 89 e7             	mov    %r12,%rdi
    ae34:	e8 77 92 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    ae39:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    ae3f:	0f 85 6f fd ff ff    	jne    abb4 <fwp_main_thread+0x164>
    ae45:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    ae4a:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    ae4f:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ae53:	0f 85 6e fd ff ff    	jne    abc7 <fwp_main_thread+0x177>
    ae59:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    ae5d:	48 85 c9             	test   %rcx,%rcx
    ae60:	0f 84 61 fd ff ff    	je     abc7 <fwp_main_thread+0x177>
    ae66:	48 85 c0             	test   %rax,%rax
    ae69:	0f 84 86 13 00 00    	je     c1f5 <fwp_main_thread+0x17a5>
    ae6f:	48 39 c8             	cmp    %rcx,%rax
    ae72:	48 0f 4f c1          	cmovg  %rcx,%rax
    ae76:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ae7d:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    ae82:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ae89:	00 00 00 00 
    ae8d:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ae94:	48 85 d2             	test   %rdx,%rdx
    ae97:	74 07                	je     aea0 <fwp_main_thread+0x450>
    ae99:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    aea0:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    aea5:	e9 51 fd ff ff       	jmp    abfb <fwp_main_thread+0x1ab>
    aeaa:	48 89 cb             	mov    %rcx,%rbx
    aead:	e9 de fc ff ff       	jmp    ab90 <fwp_main_thread+0x140>
    aeb2:	48 89 01             	mov    %rax,(%rcx)
    aeb5:	e9 af fd ff ff       	jmp    ac69 <fwp_main_thread+0x219>
    aeba:	49 8b 44 24 40       	mov    0x40(%r12),%rax
    aebf:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    aec6:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    aecd:	00 00 00 00 
    aed1:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    aed8:	48 85 c0             	test   %rax,%rax
    aedb:	0f 84 13 11 00 00    	je     bff4 <fwp_main_thread+0x15a4>
    aee1:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    aee8:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    aeed:	e9 3d fd ff ff       	jmp    ac2f <fwp_main_thread+0x1df>
    aef2:	48 83 3d 5e 68 01 00 	cmpq   $0x0,0x1685e(%rip)        # 21758 <fwp_root>
    aef9:	00 
    aefa:	c7 05 9c 61 01 00 00 	movl   $0x0,0x1619c(%rip)        # 210a0 <fwp_exit_code>
    af01:	00 00 00 
    af04:	0f 85 3b 13 00 00    	jne    c245 <fwp_main_thread+0x17f5>
    af0a:	e8 21 bf ff ff       	call   6e30 <fwp_free_zombie>
    af0f:	48 83 3d 31 68 01 00 	cmpq   $0x0,0x16831(%rip)        # 21748 <fwp_ready_head>
    af16:	00 
    af17:	0f 85 33 88 ff ff    	jne    3750 <fwp_main_thread.cold>
    af1d:	48 83 3d 13 68 01 00 	cmpq   $0x0,0x16813(%rip)        # 21738 <fwp_timers>
    af24:	00 
    af25:	0f 85 25 88 ff ff    	jne    3750 <fwp_main_thread.cold>
    af2b:	8b 05 fb 61 01 00    	mov    0x161fb(%rip),%eax        # 2112c <fwp_stack_pool_n>
    af31:	85 c0                	test   %eax,%eax
    af33:	74 37                	je     af6c <fwp_main_thread+0x51c>
    af35:	83 e8 01             	sub    $0x1,%eax
    af38:	4c 8d 2d 01 62 01 00 	lea    0x16201(%rip),%r13        # 21140 <fwp_stack_pool>
    af3f:	48 63 d8             	movslq %eax,%rbx
    af42:	89 c0                	mov    %eax,%eax
    af44:	48 89 da             	mov    %rbx,%rdx
    af47:	48 29 c2             	sub    %rax,%rdx
    af4a:	4c 8d 62 ff          	lea    -0x1(%rdx),%r12
    af4e:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    af53:	89 1d d3 61 01 00    	mov    %ebx,0x161d3(%rip)        # 2112c <fwp_stack_pool_n>
    af59:	be 00 00 00 10       	mov    $0x10000000,%esi
    af5e:	48 83 eb 01          	sub    $0x1,%rbx
    af62:	e8 79 86 ff ff       	call   35e0 <munmap@plt>
    af67:	4c 39 e3             	cmp    %r12,%rbx
    af6a:	75 e2                	jne    af4e <fwp_main_thread+0x4fe>
    af6c:	8b 3d ae 60 00 00    	mov    0x60ae(%rip),%edi        # 11020 <fwp_epfd>
    af72:	85 ff                	test   %edi,%edi
    af74:	78 05                	js     af7b <fwp_main_thread+0x52b>
    af76:	e8 55 85 ff ff       	call   34d0 <close@plt>
    af7b:	4c 8b 2d be 63 01 00 	mov    0x163be(%rip),%r13        # 21340 <fwp_nfdws>
    af82:	4c 8b 25 bf 63 01 00 	mov    0x163bf(%rip),%r12        # 21348 <fwp_fdws>
    af89:	31 db                	xor    %ebx,%ebx
    af8b:	c7 05 8b 60 00 00 ff 	movl   $0xffffffff,0x608b(%rip)        # 11020 <fwp_epfd>
    af92:	ff ff ff 
    af95:	4d 85 ed             	test   %r13,%r13
    af98:	74 2c                	je     afc6 <fwp_main_thread+0x576>
    af9a:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    af9e:	48 85 ff             	test   %rdi,%rdi
    afa1:	74 1a                	je     afbd <fwp_main_thread+0x56d>
    afa3:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    afa7:	0f 85 a3 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    afad:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    afb2:	0f 85 98 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    afb8:	e8 93 a5 ff ff       	call   5550 <fwp_mem_free>
    afbd:	48 83 c3 01          	add    $0x1,%rbx
    afc1:	4c 39 eb             	cmp    %r13,%rbx
    afc4:	75 d4                	jne    af9a <fwp_main_thread+0x54a>
    afc6:	4c 89 e7             	mov    %r12,%rdi
    afc9:	e8 82 a5 ff ff       	call   5550 <fwp_mem_free>
    afce:	48 8b 15 83 67 01 00 	mov    0x16783(%rip),%rdx        # 21758 <fwp_root>
    afd5:	48 c7 05 68 63 01 00 	movq   $0x0,0x16368(%rip)        # 21348 <fwp_fdws>
    afdc:	00 00 00 00 
    afe0:	48 c7 05 55 63 01 00 	movq   $0x0,0x16355(%rip)        # 21340 <fwp_nfdws>
    afe7:	00 00 00 00 
    afeb:	48 85 d2             	test   %rdx,%rdx
    afee:	74 4e                	je     b03e <fwp_main_thread+0x5ee>
    aff0:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    aff5:	0f 85 55 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    affb:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b002:	00 
    b003:	0f 85 47 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    b009:	48 83 3d e7 83 01 00 	cmpq   $0x0,0x183e7(%rip)        # 233f8 <fwp_state_len>
    b010:	00 
    b011:	0f 85 39 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    b017:	48 83 3d c9 83 01 00 	cmpq   $0x0,0x183c9(%rip)        # 233e8 <fwp_state_owners>
    b01e:	00 
    b01f:	0f 85 2b 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    b025:	b9 79 00 00 00       	mov    $0x79,%ecx
    b02a:	31 c0                	xor    %eax,%eax
    b02c:	48 8d 3d 2d 63 01 00 	lea    0x1632d(%rip),%rdi        # 21360 <fwp_root_context>
    b033:	f3 48 ab             	rep stos %rax,(%rdi)
    b036:	48 89 d7             	mov    %rdx,%rdi
    b039:	e8 12 a5 ff ff       	call   5550 <fwp_mem_free>
    b03e:	48 8b 3d fb 5f 00 00 	mov    0x5ffb(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    b045:	48 c7 05 10 67 01 00 	movq   $0x0,0x16710(%rip)        # 21760 <fwp_cur>
    b04c:	00 00 00 00 
    b050:	48 c7 05 fd 66 01 00 	movq   $0x0,0x166fd(%rip)        # 21758 <fwp_root>
    b057:	00 00 00 00 
    b05b:	e8 60 85 ff ff       	call   35c0 <fflush@plt>
    b060:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b064:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b06b:	00 00 
    b06d:	0f 85 2d 11 00 00    	jne    c1a0 <fwp_main_thread+0x1750>
    b073:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b077:	31 c0                	xor    %eax,%eax
    b079:	5b                   	pop    %rbx
    b07a:	41 5c                	pop    %r12
    b07c:	41 5d                	pop    %r13
    b07e:	41 5e                	pop    %r14
    b080:	41 5f                	pop    %r15
    b082:	5d                   	pop    %rbp
    b083:	c3                   	ret
    b084:	48 89 05 ad 66 01 00 	mov    %rax,0x166ad(%rip)        # 21738 <fwp_timers>
    b08b:	e9 2a fc ff ff       	jmp    acba <fwp_main_thread+0x26a>
    b090:	e8 9b 9a ff ff       	call   4b30 <fwp_heap_init>
    b095:	8b 3d 8d 7a 01 00    	mov    0x17a8d(%rip),%edi        # 22b28 <fwp_heap+0x13a8>
    b09b:	85 ff                	test   %edi,%edi
    b09d:	0f 84 f2 f9 ff ff    	je     aa95 <fwp_main_thread+0x45>
    b0a3:	48 8d 3d 76 99 ff ff 	lea    -0x668a(%rip),%rdi        # 4a20 <fwp_heap_report>
    b0aa:	e8 b1 13 00 00       	call   c460 <atexit>
    b0af:	e9 e1 f9 ff ff       	jmp    aa95 <fwp_main_thread+0x45>
    b0b4:	48 8d 05 b5 b6 ff ff 	lea    -0x494b(%rip),%rax        # 6770 <fwp_drop1>
    b0bb:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    b0c0:	4c 89 ad b0 fe ff ff 	mov    %r13,-0x150(%rbp)
    b0c7:	45 31 ff             	xor    %r15d,%r15d
    b0ca:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b0cf:	48 8b 05 42 83 01 00 	mov    0x18342(%rip),%rax        # 23418 <fwp_cleanups>
    b0d6:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
    b0dd:	00 00 00 00 
    b0e1:	4c 8d 35 98 66 01 00 	lea    0x16698(%rip),%r14        # 21780 <fwp_heap>
    b0e8:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b0ec:	4c 89 25 25 83 01 00 	mov    %r12,0x18325(%rip)        # 23418 <fwp_cleanups>
    b0f3:	41 bd ff 01 00 00    	mov    $0x1ff,%r13d
    b0f9:	4c 8b 25 f0 29 00 00 	mov    0x29f0(%rip),%r12        # daf0 <msg.4+0x70>
    b100:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
    b107:	48 8d 05 c2 8a ff ff 	lea    -0x753e(%rip),%rax        # 3bd0 <fwp_range_release>
    b10e:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    b115:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
    b11c:	0f 29 85 00 ff ff ff 	movaps %xmm0,-0x100(%rbp)
    b123:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
    b12a:	e9 0a 01 00 00       	jmp    b239 <fwp_main_thread+0x7e9>
    b12f:	48 8b 13             	mov    (%rbx),%rdx
    b132:	48 f7 d2             	not    %rdx
    b135:	48 89 10             	mov    %rdx,(%rax)
    b138:	49 83 f8 18          	cmp    $0x18,%r8
    b13c:	76 29                	jbe    b167 <fwp_main_thread+0x717>
    b13e:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    b142:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    b146:	31 f6                	xor    %esi,%esi
    b148:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b14f:	48 c1 e8 03          	shr    $0x3,%rax
    b153:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b15a:	00 
    b15b:	e8 60 83 ff ff       	call   34c0 <memset@plt>
    b160:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b167:	4c 89 c0             	mov    %r8,%rax
    b16a:	49 03 86 20 14 00 00 	add    0x1420(%r14),%rax
    b171:	0f 82 89 10 00 00    	jb     c200 <fwp_main_thread+0x17b0>
    b177:	49 89 86 20 14 00 00 	mov    %rax,0x1420(%r14)
    b17e:	49 39 86 28 14 00 00 	cmp    %rax,0x1428(%r14)
    b185:	73 07                	jae    b18e <fwp_main_thread+0x73e>
    b187:	49 89 86 28 14 00 00 	mov    %rax,0x1428(%r14)
    b18e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b192:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    b197:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    b19e:	00 00 
    b1a0:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    b1a7:	00 00 
    b1a9:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
    b1ad:	48 89 d8             	mov    %rbx,%rax
    b1b0:	49 89 df             	mov    %rbx,%r15
    b1b3:	4c 89 23             	mov    %r12,(%rbx)
    b1b6:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
    b1ba:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b1c1:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b1c8:	48 c1 e2 10          	shl    $0x10,%rdx
    b1cc:	48 39 d0             	cmp    %rdx,%rax
    b1cf:	73 57                	jae    b228 <fwp_main_thread+0x7d8>
    b1d1:	48 89 c2             	mov    %rax,%rdx
    b1d4:	48 c1 ea 10          	shr    $0x10,%rdx
    b1d8:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b1dc:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b1e3:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b1e7:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b1eb:	48 85 d2             	test   %rdx,%rdx
    b1ee:	74 38                	je     b228 <fwp_main_thread+0x7d8>
    b1f0:	0f b6 3e             	movzbl (%rsi),%edi
    b1f3:	40 80 ff 02          	cmp    $0x2,%dil
    b1f7:	0f 84 a8 00 00 00    	je     b2a5 <fwp_main_thread+0x855>
    b1fd:	40 80 ff 01          	cmp    $0x1,%dil
    b201:	75 25                	jne    b228 <fwp_main_thread+0x7d8>
    b203:	8b 7e 18             	mov    0x18(%rsi),%edi
    b206:	0f b7 c0             	movzwl %ax,%eax
    b209:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b20c:	48 0f af c7          	imul   %rdi,%rax
    b210:	48 c1 e8 20          	shr    $0x20,%rax
    b214:	48 39 f0             	cmp    %rsi,%rax
    b217:	73 0f                	jae    b228 <fwp_main_thread+0x7d8>
    b219:	48 01 c2             	add    %rax,%rdx
    b21c:	80 3a ff             	cmpb   $0xff,(%rdx)
    b21f:	0f 84 25 0e 00 00    	je     c04a <fwp_main_thread+0x15fa>
    b225:	c6 02 01             	movb   $0x1,(%rdx)
    b228:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    b22f:	49 83 ed 01          	sub    $0x1,%r13
    b233:	0f 82 86 00 00 00    	jb     b2bf <fwp_main_thread+0x86f>
    b239:	41 8b 8e a4 13 00 00 	mov    0x13a4(%r14),%ecx
    b240:	4c 89 ad f8 fe ff ff 	mov    %r13,-0x108(%rbp)
    b247:	85 c9                	test   %ecx,%ecx
    b249:	74 46                	je     b291 <fwp_main_thread+0x841>
    b24b:	41 0f b6 86 a2 0f 00 	movzbl 0xfa2(%r14),%eax
    b252:	00 
    b253:	45 8b 84 86 00 0f 00 	mov    0xf00(%r14,%rax,4),%r8d
    b25a:	00 
    b25b:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b25f:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
    b263:	48 8b 18             	mov    (%rax),%rbx
    b266:	48 85 db             	test   %rbx,%rbx
    b269:	0f 85 c0 fe ff ff    	jne    b12f <fwp_main_thread+0x6df>
    b26f:	48 8b 58 08          	mov    0x8(%rax),%rbx
    b273:	48 85 db             	test   %rbx,%rbx
    b276:	74 19                	je     b291 <fwp_main_thread+0x841>
    b278:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b27c:	48 29 da             	sub    %rbx,%rdx
    b27f:	4c 39 c2             	cmp    %r8,%rdx
    b282:	72 0d                	jb     b291 <fwp_main_thread+0x841>
    b284:	4a 8d 14 03          	lea    (%rbx,%r8,1),%rdx
    b288:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b28c:	e9 a7 fe ff ff       	jmp    b138 <fwp_main_thread+0x6e8>
    b291:	31 f6                	xor    %esi,%esi
    b293:	bf 18 00 00 00       	mov    $0x18,%edi
    b298:	e8 b3 a7 ff ff       	call   5a50 <fwp_heap_alloc>
    b29d:	48 89 c3             	mov    %rax,%rbx
    b2a0:	e9 04 ff ff ff       	jmp    b1a9 <fwp_main_thread+0x759>
    b2a5:	66 85 c0             	test   %ax,%ax
    b2a8:	0f 84 6e ff ff ff    	je     b21c <fwp_main_thread+0x7cc>
    b2ae:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    b2b5:	49 83 ed 01          	sub    $0x1,%r13
    b2b9:	0f 83 7a ff ff ff    	jae    b239 <fwp_main_thread+0x7e9>
    b2bf:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    b2c6:	66 0f 6f 05 52 28 00 	movdqa 0x2852(%rip),%xmm0        # db20 <msg.4+0xa0>
    b2cd:	00 
    b2ce:	bf 01 00 00 00       	mov    $0x1,%edi
    b2d3:	48 89 9d b8 fe ff ff 	mov    %rbx,-0x148(%rbp)
    b2da:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
    b2e1:	48 89 05 30 81 01 00 	mov    %rax,0x18130(%rip)        # 23418 <fwp_cleanups>
    b2e8:	0f 29 85 30 ff ff ff 	movaps %xmm0,-0xd0(%rbp)
    b2ef:	e8 2c b0 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b2f4:	48 8b 15 5d 78 01 00 	mov    0x1785d(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    b2fb:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b302:	49 89 c5             	mov    %rax,%r13
    b305:	48 2b 05 24 78 01 00 	sub    0x17824(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    b30c:	48 c1 e2 10          	shl    $0x10,%rdx
    b310:	48 39 d0             	cmp    %rdx,%rax
    b313:	73 55                	jae    b36a <fwp_main_thread+0x91a>
    b315:	48 89 c2             	mov    %rax,%rdx
    b318:	48 c1 ea 10          	shr    $0x10,%rdx
    b31c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b320:	48 8b 15 51 78 01 00 	mov    0x17851(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    b327:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b32b:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b32f:	48 85 db             	test   %rbx,%rbx
    b332:	74 36                	je     b36a <fwp_main_thread+0x91a>
    b334:	0f b6 0a             	movzbl (%rdx),%ecx
    b337:	80 f9 02             	cmp    $0x2,%cl
    b33a:	0f 84 ee 0c 00 00    	je     c02e <fwp_main_thread+0x15de>
    b340:	80 f9 01             	cmp    $0x1,%cl
    b343:	75 25                	jne    b36a <fwp_main_thread+0x91a>
    b345:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b348:	0f b7 c0             	movzwl %ax,%eax
    b34b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b34e:	48 0f af c1          	imul   %rcx,%rax
    b352:	48 c1 e8 20          	shr    $0x20,%rax
    b356:	48 39 d0             	cmp    %rdx,%rax
    b359:	73 0f                	jae    b36a <fwp_main_thread+0x91a>
    b35b:	48 01 c3             	add    %rax,%rbx
    b35e:	80 3b ff             	cmpb   $0xff,(%rbx)
    b361:	0f 84 26 0d 00 00    	je     c08d <fwp_main_thread+0x163d>
    b367:	c6 03 01             	movb   $0x1,(%rbx)
    b36a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b371:	00 f0 3f 
    b374:	48 8d b5 20 ff ff ff 	lea    -0xe0(%rbp),%rsi
    b37b:	bf 01 00 00 00       	mov    $0x1,%edi
    b380:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b387:	4c 89 ad 28 ff ff ff 	mov    %r13,-0xd8(%rbp)
    b38e:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
    b395:	e8 86 af ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b39a:	48 8b 15 b7 77 01 00 	mov    0x177b7(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    b3a1:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b3a8:	49 89 c5             	mov    %rax,%r13
    b3ab:	48 2b 05 7e 77 01 00 	sub    0x1777e(%rip),%rax        # 22b30 <fwp_heap+0x13b0>
    b3b2:	48 c1 e2 10          	shl    $0x10,%rdx
    b3b6:	48 39 d0             	cmp    %rdx,%rax
    b3b9:	73 55                	jae    b410 <fwp_main_thread+0x9c0>
    b3bb:	48 89 c2             	mov    %rax,%rdx
    b3be:	48 c1 ea 10          	shr    $0x10,%rdx
    b3c2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3c6:	48 8b 15 ab 77 01 00 	mov    0x177ab(%rip),%rdx        # 22b78 <fwp_heap+0x13f8>
    b3cd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b3d1:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b3d5:	48 85 db             	test   %rbx,%rbx
    b3d8:	74 36                	je     b410 <fwp_main_thread+0x9c0>
    b3da:	0f b6 0a             	movzbl (%rdx),%ecx
    b3dd:	80 f9 02             	cmp    $0x2,%cl
    b3e0:	0f 84 56 0c 00 00    	je     c03c <fwp_main_thread+0x15ec>
    b3e6:	80 f9 01             	cmp    $0x1,%cl
    b3e9:	75 25                	jne    b410 <fwp_main_thread+0x9c0>
    b3eb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b3ee:	0f b7 c0             	movzwl %ax,%eax
    b3f1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b3f4:	48 0f af c1          	imul   %rcx,%rax
    b3f8:	48 c1 e8 20          	shr    $0x20,%rax
    b3fc:	48 39 d0             	cmp    %rdx,%rax
    b3ff:	73 0f                	jae    b410 <fwp_main_thread+0x9c0>
    b401:	48 01 c3             	add    %rax,%rbx
    b404:	80 3b ff             	cmpb   $0xff,(%rbx)
    b407:	0f 84 53 0d 00 00    	je     c160 <fwp_main_thread+0x1710>
    b40d:	c6 03 01             	movb   $0x1,(%rbx)
    b410:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b417:	33 f3 bf 
    b41a:	48 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%rsi
    b421:	bf 01 00 00 00       	mov    $0x1,%edi
    b426:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b42d:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
    b434:	4c 89 ad 18 ff ff ff 	mov    %r13,-0xe8(%rbp)
    b43b:	e8 e0 ae ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b440:	48 8b 15 11 77 01 00 	mov    0x17711(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    b447:	48 8b 0d e2 76 01 00 	mov    0x176e2(%rip),%rcx        # 22b30 <fwp_heap+0x13b0>
    b44e:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
    b455:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b45c:	48 89 d6             	mov    %rdx,%rsi
    b45f:	48 29 c8             	sub    %rcx,%rax
    b462:	48 c1 e6 10          	shl    $0x10,%rsi
    b466:	48 39 f0             	cmp    %rsi,%rax
    b469:	73 65                	jae    b4d0 <fwp_main_thread+0xa80>
    b46b:	48 89 c6             	mov    %rax,%rsi
    b46e:	48 c1 ee 10          	shr    $0x10,%rsi
    b472:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b476:	48 8b 35 fb 76 01 00 	mov    0x176fb(%rip),%rsi        # 22b78 <fwp_heap+0x13f8>
    b47d:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b481:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    b485:	48 85 db             	test   %rbx,%rbx
    b488:	74 46                	je     b4d0 <fwp_main_thread+0xa80>
    b48a:	0f b6 3e             	movzbl (%rsi),%edi
    b48d:	40 80 ff 02          	cmp    $0x2,%dil
    b491:	0f 84 89 0b 00 00    	je     c020 <fwp_main_thread+0x15d0>
    b497:	40 80 ff 01          	cmp    $0x1,%dil
    b49b:	75 33                	jne    b4d0 <fwp_main_thread+0xa80>
    b49d:	8b 7e 18             	mov    0x18(%rsi),%edi
    b4a0:	0f b7 c0             	movzwl %ax,%eax
    b4a3:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b4a6:	48 0f af c7          	imul   %rdi,%rax
    b4aa:	48 c1 e8 20          	shr    $0x20,%rax
    b4ae:	48 39 f0             	cmp    %rsi,%rax
    b4b1:	73 1d                	jae    b4d0 <fwp_main_thread+0xa80>
    b4b3:	48 01 c3             	add    %rax,%rbx
    b4b6:	80 3b ff             	cmpb   $0xff,(%rbx)
    b4b9:	0f 84 bc 0c 00 00    	je     c17b <fwp_main_thread+0x172b>
    b4bf:	c6 03 01             	movb   $0x1,(%rbx)
    b4c2:	48 8b 0d 67 76 01 00 	mov    0x17667(%rip),%rcx        # 22b30 <fwp_heap+0x13b0>
    b4c9:	48 8b 15 88 76 01 00 	mov    0x17688(%rip),%rdx        # 22b58 <fwp_heap+0x13d8>
    b4d0:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
    b4d7:	4c 89 85 68 fe ff ff 	mov    %r8,-0x198(%rbp)
    b4de:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
    b4e5:	4c 89 85 60 fe ff ff 	mov    %r8,-0x1a0(%rbp)
    b4ec:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    b4f3:	48 c1 e2 10          	shl    $0x10,%rdx
    b4f7:	48 29 c8             	sub    %rcx,%rax
    b4fa:	48 39 d0             	cmp    %rdx,%rax
    b4fd:	73 5d                	jae    b55c <fwp_main_thread+0xb0c>
    b4ff:	48 89 c2             	mov    %rax,%rdx
    b502:	48 c1 ea 10          	shr    $0x10,%rdx
    b506:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b50a:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b511:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b515:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b519:	48 85 ff             	test   %rdi,%rdi
    b51c:	74 3e                	je     b55c <fwp_main_thread+0xb0c>
    b51e:	0f b6 0a             	movzbl (%rdx),%ecx
    b521:	80 f9 02             	cmp    $0x2,%cl
    b524:	0f 84 e8 0a 00 00    	je     c012 <fwp_main_thread+0x15c2>
    b52a:	80 f9 01             	cmp    $0x1,%cl
    b52d:	75 2d                	jne    b55c <fwp_main_thread+0xb0c>
    b52f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b532:	0f b7 c0             	movzwl %ax,%eax
    b535:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b538:	48 0f af c1          	imul   %rcx,%rax
    b53c:	48 c1 e8 20          	shr    $0x20,%rax
    b540:	48 39 d0             	cmp    %rdx,%rax
    b543:	73 17                	jae    b55c <fwp_main_thread+0xb0c>
    b545:	48 01 c7             	add    %rax,%rdi
    b548:	0f b6 07             	movzbl (%rdi),%eax
    b54b:	84 c0                	test   %al,%al
    b54d:	74 0d                	je     b55c <fwp_main_thread+0xb0c>
    b54f:	3c fd                	cmp    $0xfd,%al
    b551:	0f 87 3f 0c 00 00    	ja     c196 <fwp_main_thread+0x1746>
    b557:	83 c0 01             	add    $0x1,%eax
    b55a:	88 07                	mov    %al,(%rdi)
    b55c:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    b563:	48 8b 15 6e 7e 01 00 	mov    0x17e6e(%rip),%rdx        # 233d8 <fwp_fns>
    b56a:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    b571:	48 8d 05 a0 5a 00 00 	lea    0x5aa0(%rip),%rax        # 11018 <fc12>
    b578:	44 8b 28             	mov    (%rax),%r13d
    b57b:	49 c1 e5 05          	shl    $0x5,%r13
    b57f:	49 01 d5             	add    %rdx,%r13
    b582:	49 8b 4d 18          	mov    0x18(%r13),%rcx
    b586:	48 85 c9             	test   %rcx,%rcx
    b589:	0f 84 22 0c 00 00    	je     c1b1 <fwp_main_thread+0x1761>
    b58f:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    b594:	0f 84 d6 08 00 00    	je     be70 <fwp_main_thread+0x1420>
    b59a:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    b5a1:	48 8d 05 70 5a 00 00 	lea    0x5a70(%rip),%rax        # 11018 <fc12>
    b5a8:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b5af:	48 c1 e1 10          	shl    $0x10,%rcx
    b5b3:	48 39 c8             	cmp    %rcx,%rax
    b5b6:	73 5f                	jae    b617 <fwp_main_thread+0xbc7>
    b5b8:	48 89 c1             	mov    %rax,%rcx
    b5bb:	48 c1 e9 10          	shr    $0x10,%rcx
    b5bf:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b5c3:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    b5ca:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b5ce:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    b5d2:	48 85 ff             	test   %rdi,%rdi
    b5d5:	74 40                	je     b617 <fwp_main_thread+0xbc7>
    b5d7:	0f b6 31             	movzbl (%rcx),%esi
    b5da:	40 80 fe 02          	cmp    $0x2,%sil
    b5de:	0f 84 69 09 00 00    	je     bf4d <fwp_main_thread+0x14fd>
    b5e4:	40 80 fe 01          	cmp    $0x1,%sil
    b5e8:	75 2d                	jne    b617 <fwp_main_thread+0xbc7>
    b5ea:	8b 71 18             	mov    0x18(%rcx),%esi
    b5ed:	0f b7 c0             	movzwl %ax,%eax
    b5f0:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b5f3:	48 0f af c6          	imul   %rsi,%rax
    b5f7:	48 c1 e8 20          	shr    $0x20,%rax
    b5fb:	48 39 c8             	cmp    %rcx,%rax
    b5fe:	73 17                	jae    b617 <fwp_main_thread+0xbc7>
    b600:	48 01 c7             	add    %rax,%rdi
    b603:	0f b6 07             	movzbl (%rdi),%eax
    b606:	84 c0                	test   %al,%al
    b608:	74 0d                	je     b617 <fwp_main_thread+0xbc7>
    b60a:	3c fd                	cmp    $0xfd,%al
    b60c:	0f 87 d1 09 00 00    	ja     bfe3 <fwp_main_thread+0x1593>
    b612:	83 c0 01             	add    $0x1,%eax
    b615:	88 07                	mov    %al,(%rdi)
    b617:	48 8b 9d 80 fe ff ff 	mov    -0x180(%rbp),%rbx
    b61e:	4c 8d 3d f3 59 00 00 	lea    0x59f3(%rip),%r15        # 11018 <fc12>
    b625:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    b62c:	00 00 00 
    b62f:	4c 89 f8             	mov    %r15,%rax
    b632:	48 89 9d a0 fe ff ff 	mov    %rbx,-0x160(%rbp)
    b639:	8b 9d 9c fe ff ff    	mov    -0x164(%rbp),%ebx
    b63f:	41 8b 4d 00          	mov    0x0(%r13),%ecx
    b643:	4d 89 fa             	mov    %r15,%r10
    b646:	2b 48 04             	sub    0x4(%rax),%ecx
    b649:	41 8b 07             	mov    (%r15),%eax
    b64c:	39 d9                	cmp    %ebx,%ecx
    b64e:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    b655:	41 89 cc             	mov    %ecx,%r12d
    b658:	0f 46 d9             	cmovbe %ecx,%ebx
    b65b:	48 c1 e0 05          	shl    $0x5,%rax
    b65f:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    b663:	4c 89 f8             	mov    %r15,%rax
    b666:	49 8b 50 18          	mov    0x18(%r8),%rdx
    b66a:	89 9d 8c fe ff ff    	mov    %ebx,-0x174(%rbp)
    b670:	89 9d b8 fe ff ff    	mov    %ebx,-0x148(%rbp)
    b676:	48 85 d2             	test   %rdx,%rdx
    b679:	0f 84 38 02 00 00    	je     b8b7 <fwp_main_thread+0xe67>
    b67f:	89 8d 88 fe ff ff    	mov    %ecx,-0x178(%rbp)
    b685:	eb 6d                	jmp    b6f4 <fwp_main_thread+0xca4>
    b687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b68e:	00 00 
    b690:	85 db                	test   %ebx,%ebx
    b692:	0f 84 87 00 00 00    	je     b71f <fwp_main_thread+0xccf>
    b698:	4c 89 ef             	mov    %r13,%rdi
    b69b:	ff 12                	call   *(%rdx)
    b69d:	4c 89 ff             	mov    %r15,%rdi
    b6a0:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    b6a7:	e8 24 b2 ff ff       	call   68d0 <fwp_closure_drop>
    b6ac:	44 3b a5 b8 fe ff ff 	cmp    -0x148(%rbp),%r12d
    b6b3:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    b6ba:	0f 84 a0 07 00 00    	je     be60 <fwp_main_thread+0x1410>
    b6c0:	8b 95 98 fe ff ff    	mov    -0x168(%rbp),%edx
    b6c6:	44 8b 00             	mov    (%rax),%r8d
    b6c9:	4f 8d 6c e5 00       	lea    0x0(%r13,%r12,8),%r13
    b6ce:	49 89 c2             	mov    %rax,%r10
    b6d1:	29 da                	sub    %ebx,%edx
    b6d3:	49 c1 e0 05          	shl    $0x5,%r8
    b6d7:	4c 03 05 fa 7c 01 00 	add    0x17cfa(%rip),%r8        # 233d8 <fwp_fns>
    b6de:	89 95 b8 fe ff ff    	mov    %edx,-0x148(%rbp)
    b6e4:	49 8b 50 18          	mov    0x18(%r8),%rdx
    b6e8:	48 85 d2             	test   %rdx,%rdx
    b6eb:	0f 84 bf 01 00 00    	je     b8b0 <fwp_main_thread+0xe60>
    b6f1:	49 89 c7             	mov    %rax,%r15
    b6f4:	41 8b 4a 04          	mov    0x4(%r10),%ecx
    b6f8:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    b6fe:	41 8b 18             	mov    (%r8),%ebx
    b701:	01 c8                	add    %ecx,%eax
    b703:	89 85 98 fe ff ff    	mov    %eax,-0x168(%rbp)
    b709:	39 d8                	cmp    %ebx,%eax
    b70b:	0f 82 9f 04 00 00    	jb     bbb0 <fwp_main_thread+0x1160>
    b711:	41 89 dc             	mov    %ebx,%r12d
    b714:	41 29 cc             	sub    %ecx,%r12d
    b717:	85 c9                	test   %ecx,%ecx
    b719:	0f 84 71 ff ff ff    	je     b690 <fwp_main_thread+0xc40>
    b71f:	85 db                	test   %ebx,%ebx
    b721:	b8 01 00 00 00       	mov    $0x1,%eax
    b726:	48 89 e6             	mov    %rsp,%rsi
    b729:	48 89 a5 b0 fe ff ff 	mov    %rsp,-0x150(%rbp)
    b730:	0f 45 c3             	cmovne %ebx,%eax
    b733:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    b73a:	00 
    b73b:	48 c1 e8 04          	shr    $0x4,%rax
    b73f:	48 c1 e0 04          	shl    $0x4,%rax
    b743:	48 89 c7             	mov    %rax,%rdi
    b746:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b74d:	48 29 fe             	sub    %rdi,%rsi
    b750:	48 39 f4             	cmp    %rsi,%rsp
    b753:	74 15                	je     b76a <fwp_main_thread+0xd1a>
    b755:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b75c:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b763:	00 00 
    b765:	48 39 f4             	cmp    %rsi,%rsp
    b768:	75 eb                	jne    b755 <fwp_main_thread+0xd05>
    b76a:	25 ff 0f 00 00       	and    $0xfff,%eax
    b76f:	48 29 c4             	sub    %rax,%rsp
    b772:	48 85 c0             	test   %rax,%rax
    b775:	74 06                	je     b77d <fwp_main_thread+0xd2d>
    b777:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    b77d:	89 c8                	mov    %ecx,%eax
    b77f:	48 89 a5 a8 fe ff ff 	mov    %rsp,-0x158(%rbp)
    b786:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
    b78d:	00 
    b78e:	31 c0                	xor    %eax,%eax
    b790:	85 c9                	test   %ecx,%ecx
    b792:	74 25                	je     b7b9 <fwp_main_thread+0xd69>
    b794:	90                   	nop
    b795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b79c:	00 00 00 00 
    b7a0:	49 8b 7c 02 08       	mov    0x8(%r10,%rax,1),%rdi
    b7a5:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    b7ac:	49 89 3c 03          	mov    %rdi,(%r11,%rax,1)
    b7b0:	48 83 c0 08          	add    $0x8,%rax
    b7b4:	48 39 c6             	cmp    %rax,%rsi
    b7b7:	75 e7                	jne    b7a0 <fwp_main_thread+0xd50>
    b7b9:	45 85 e4             	test   %r12d,%r12d
    b7bc:	74 3e                	je     b7fc <fwp_main_thread+0xdac>
    b7be:	44 89 e0             	mov    %r12d,%eax
    b7c1:	4c 89 ee             	mov    %r13,%rsi
    b7c4:	49 8d 44 c5 00       	lea    0x0(%r13,%rax,8),%rax
    b7c9:	90                   	nop
    b7ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b7d1:	00 00 00 00 
    b7d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b7dc:	00 00 00 00 
    b7e0:	4c 8b 0e             	mov    (%rsi),%r9
    b7e3:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    b7ea:	89 cf                	mov    %ecx,%edi
    b7ec:	48 83 c6 08          	add    $0x8,%rsi
    b7f0:	83 c1 01             	add    $0x1,%ecx
    b7f3:	4d 89 0c fb          	mov    %r9,(%r11,%rdi,8)
    b7f7:	48 39 f0             	cmp    %rsi,%rax
    b7fa:	75 e4                	jne    b7e0 <fwp_main_thread+0xd90>
    b7fc:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    b803:	4c 89 f8             	mov    %r15,%rax
    b806:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b80d:	48 c1 e1 10          	shl    $0x10,%rcx
    b811:	48 39 c8             	cmp    %rcx,%rax
    b814:	73 4c                	jae    b862 <fwp_main_thread+0xe12>
    b816:	48 89 c1             	mov    %rax,%rcx
    b819:	48 c1 e9 10          	shr    $0x10,%rcx
    b81d:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b821:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    b828:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b82c:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    b830:	48 85 f6             	test   %rsi,%rsi
    b833:	74 2d                	je     b862 <fwp_main_thread+0xe12>
    b835:	0f b6 39             	movzbl (%rcx),%edi
    b838:	40 80 ff 02          	cmp    $0x2,%dil
    b83c:	74 6a                	je     b8a8 <fwp_main_thread+0xe58>
    b83e:	40 80 ff 01          	cmp    $0x1,%dil
    b842:	75 1e                	jne    b862 <fwp_main_thread+0xe12>
    b844:	8b 79 18             	mov    0x18(%rcx),%edi
    b847:	0f b7 c0             	movzwl %ax,%eax
    b84a:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b84d:	48 0f af c7          	imul   %rdi,%rax
    b851:	48 c1 e8 20          	shr    $0x20,%rax
    b855:	48 39 c8             	cmp    %rcx,%rax
    b858:	73 08                	jae    b862 <fwp_main_thread+0xe12>
    b85a:	48 01 c6             	add    %rax,%rsi
    b85d:	80 3e 01             	cmpb   $0x1,(%rsi)
    b860:	74 36                	je     b898 <fwp_main_thread+0xe48>
    b862:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    b869:	be 01 00 00 00       	mov    $0x1,%esi
    b86e:	4c 89 ff             	mov    %r15,%rdi
    b871:	ff 52 08             	call   *0x8(%rdx)
    b874:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    b87b:	49 8b 40 18          	mov    0x18(%r8),%rax
    b87f:	48 8b bd a8 fe ff ff 	mov    -0x158(%rbp),%rdi
    b886:	ff 10                	call   *(%rax)
    b888:	48 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%rsp
    b88f:	e9 09 fe ff ff       	jmp    b69d <fwp_main_thread+0xc4d>
    b894:	0f 1f 40 00          	nopl   0x0(%rax)
    b898:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    b89f:	00 
    b8a0:	eb d9                	jmp    b87b <fwp_main_thread+0xe2b>
    b8a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b8a8:	66 85 c0             	test   %ax,%ax
    b8ab:	75 b5                	jne    b862 <fwp_main_thread+0xe12>
    b8ad:	eb ae                	jmp    b85d <fwp_main_thread+0xe0d>
    b8af:	90                   	nop
    b8b0:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    b8b7:	48 89 c7             	mov    %rax,%rdi
    b8ba:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    b8c1:	e8 8a ab ff ff       	call   6450 <fwp_rc_share>
    b8c6:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    b8cc:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    b8d3:	85 d2                	test   %edx,%edx
    b8d5:	74 35                	je     b90c <fwp_main_thread+0xebc>
    b8d7:	89 d1                	mov    %edx,%ecx
    b8d9:	44 89 a5 b0 fe ff ff 	mov    %r12d,-0x150(%rbp)
    b8e0:	49 89 c7             	mov    %rax,%r15
    b8e3:	4d 89 ec             	mov    %r13,%r12
    b8e6:	49 8d 5c cd 00       	lea    0x0(%r13,%rcx,8),%rbx
    b8eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b8f0:	49 8b 3c 24          	mov    (%r12),%rdi
    b8f4:	49 83 c4 08          	add    $0x8,%r12
    b8f8:	e8 53 ab ff ff       	call   6450 <fwp_rc_share>
    b8fd:	4c 39 e3             	cmp    %r12,%rbx
    b900:	75 ee                	jne    b8f0 <fwp_main_thread+0xea0>
    b902:	44 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%r12d
    b909:	4c 89 f8             	mov    %r15,%rax
    b90c:	8b b5 b8 fe ff ff    	mov    -0x148(%rbp),%esi
    b912:	4c 89 ea             	mov    %r13,%rdx
    b915:	48 89 c7             	mov    %rax,%rdi
    b918:	e8 53 a2 ff ff       	call   5b70 <fwp_apply>
    b91d:	49 89 c7             	mov    %rax,%r15
    b920:	8b bd 9c fe ff ff    	mov    -0x164(%rbp),%edi
    b926:	41 39 fc             	cmp    %edi,%r12d
    b929:	0f 83 8c 00 00 00    	jae    b9bb <fwp_main_thread+0xf6b>
    b92f:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    b936:	8b 85 8c fe ff ff    	mov    -0x174(%rbp),%eax
    b93c:	45 8b 2f             	mov    (%r15),%r13d
    b93f:	48 89 c6             	mov    %rax,%rsi
    b942:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    b946:	48 8b 15 8b 7a 01 00 	mov    0x17a8b(%rip),%rdx        # 233d8 <fwp_fns>
    b94d:	49 c1 e5 05          	shl    $0x5,%r13
    b951:	29 f7                	sub    %esi,%edi
    b953:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    b95a:	4c 89 f8             	mov    %r15,%rax
    b95d:	49 01 d5             	add    %rdx,%r13
    b960:	89 bd 9c fe ff ff    	mov    %edi,-0x164(%rbp)
    b966:	49 83 7d 18 00       	cmpq   $0x0,0x18(%r13)
    b96b:	0f 85 c8 fc ff ff    	jne    b639 <fwp_main_thread+0xbe9>
    b971:	4c 89 ff             	mov    %r15,%rdi
    b974:	e8 d7 aa ff ff       	call   6450 <fwp_rc_share>
    b979:	44 8b a5 9c fe ff ff 	mov    -0x164(%rbp),%r12d
    b980:	45 85 e4             	test   %r12d,%r12d
    b983:	74 1e                	je     b9a3 <fwp_main_thread+0xf53>
    b985:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    b98c:	31 db                	xor    %ebx,%ebx
    b98e:	66 90                	xchg   %ax,%ax
    b990:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    b995:	48 83 c3 01          	add    $0x1,%rbx
    b999:	e8 b2 aa ff ff       	call   6450 <fwp_rc_share>
    b99e:	44 39 e3             	cmp    %r12d,%ebx
    b9a1:	72 ed                	jb     b990 <fwp_main_thread+0xf40>
    b9a3:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    b9aa:	8b b5 9c fe ff ff    	mov    -0x164(%rbp),%esi
    b9b0:	4c 89 ff             	mov    %r15,%rdi
    b9b3:	e8 b8 a1 ff ff       	call   5b70 <fwp_apply>
    b9b8:	49 89 c7             	mov    %rax,%r15
    b9bb:	48 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%rdi
    b9c2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b9c6:	b9 01 00 00 00       	mov    $0x1,%ecx
    b9cb:	4c 89 fe             	mov    %r15,%rsi
    b9ce:	48 8d 15 cb 51 00 00 	lea    0x51cb(%rip),%rdx        # 10ba0 <d0>
    b9d5:	0f 29 85 f0 fe ff ff 	movaps %xmm0,-0x110(%rbp)
    b9dc:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
    b9e3:	00 00 00 00 
    b9e7:	e8 24 e0 ff ff       	call   9a10 <fwp_write>
    b9ec:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
    b9f3:	4c 8b ad f8 fe ff ff 	mov    -0x108(%rbp),%r13
    b9fa:	48 8d 05 2d 16 00 00 	lea    0x162d(%rip),%rax        # d02e <_IO_stdin_used+0x2e>
    ba01:	48 85 c9             	test   %rcx,%rcx
    ba04:	48 0f 44 c8          	cmove  %rax,%rcx
    ba08:	49 83 fd f6          	cmp    $0xfffffffffffffff6,%r13
    ba0c:	0f 87 d7 07 00 00    	ja     c1e9 <fwp_main_thread+0x1799>
    ba12:	49 8d 7d 09          	lea    0x9(%r13),%rdi
    ba16:	be 01 00 00 00       	mov    $0x1,%esi
    ba1b:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
    ba22:	e8 29 a0 ff ff       	call   5a50 <fwp_heap_alloc>
    ba27:	48 8b b5 b8 fe ff ff 	mov    -0x148(%rbp),%rsi
    ba2e:	4c 89 ea             	mov    %r13,%rdx
    ba31:	4c 89 28             	mov    %r13,(%rax)
    ba34:	4c 8d 60 08          	lea    0x8(%rax),%r12
    ba38:	48 89 c3             	mov    %rax,%rbx
    ba3b:	4c 89 e7             	mov    %r12,%rdi
    ba3e:	e8 5d 7b ff ff       	call   35a0 <memcpy@plt>
    ba43:	42 c6 44 2b 08 00    	movb   $0x0,0x8(%rbx,%r13,1)
    ba49:	48 8b bd f0 fe ff ff 	mov    -0x110(%rbp),%rdi
    ba50:	e8 6b 79 ff ff       	call   33c0 <free@plt>
    ba55:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    ba5c:	48 89 d8             	mov    %rbx,%rax
    ba5f:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    ba66:	48 c1 e2 10          	shl    $0x10,%rdx
    ba6a:	48 39 d0             	cmp    %rdx,%rax
    ba6d:	73 57                	jae    bac6 <fwp_main_thread+0x1076>
    ba6f:	48 89 c2             	mov    %rax,%rdx
    ba72:	48 c1 ea 10          	shr    $0x10,%rdx
    ba76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba7a:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    ba81:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    ba85:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    ba89:	48 85 d2             	test   %rdx,%rdx
    ba8c:	74 38                	je     bac6 <fwp_main_thread+0x1076>
    ba8e:	0f b6 31             	movzbl (%rcx),%esi
    ba91:	40 80 fe 02          	cmp    $0x2,%sil
    ba95:	0f 84 85 06 00 00    	je     c120 <fwp_main_thread+0x16d0>
    ba9b:	40 80 fe 01          	cmp    $0x1,%sil
    ba9f:	75 25                	jne    bac6 <fwp_main_thread+0x1076>
    baa1:	8b 71 18             	mov    0x18(%rcx),%esi
    baa4:	0f b7 c0             	movzwl %ax,%eax
    baa7:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    baaa:	48 0f af c6          	imul   %rsi,%rax
    baae:	48 c1 e8 20          	shr    $0x20,%rax
    bab2:	48 39 c8             	cmp    %rcx,%rax
    bab5:	73 0f                	jae    bac6 <fwp_main_thread+0x1076>
    bab7:	48 01 c2             	add    %rax,%rdx
    baba:	80 3a ff             	cmpb   $0xff,(%rdx)
    babd:	0f 84 af 05 00 00    	je     c072 <fwp_main_thread+0x1622>
    bac3:	c6 02 01             	movb   $0x1,(%rdx)
    bac6:	4c 89 ff             	mov    %r15,%rdi
    bac9:	e8 12 ab ff ff       	call   65e0 <fwp_drop0>
    bace:	48 8b 13             	mov    (%rbx),%rdx
    bad1:	be 01 00 00 00       	mov    $0x1,%esi
    bad6:	4c 89 e7             	mov    %r12,%rdi
    bad9:	48 8b 0d 00 79 01 00 	mov    0x17900(%rip),%rcx        # 233e0 <fwp_prog_out>
    bae0:	e8 9b 7b ff ff       	call   3680 <fwrite@plt>
    bae5:	48 8b 35 f4 78 01 00 	mov    0x178f4(%rip),%rsi        # 233e0 <fwp_prog_out>
    baec:	bf 0a 00 00 00       	mov    $0xa,%edi
    baf1:	e8 ea 79 ff ff       	call   34e0 <fputc@plt>
    baf6:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bafd:	48 89 d8             	mov    %rbx,%rax
    bb00:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bb07:	48 c1 e2 10          	shl    $0x10,%rdx
    bb0b:	48 39 d0             	cmp    %rdx,%rax
    bb0e:	73 69                	jae    bb79 <fwp_main_thread+0x1129>
    bb10:	48 89 c2             	mov    %rax,%rdx
    bb13:	48 c1 ea 10          	shr    $0x10,%rdx
    bb17:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bb1b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bb22:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bb26:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    bb2a:	4d 85 ed             	test   %r13,%r13
    bb2d:	74 4a                	je     bb79 <fwp_main_thread+0x1129>
    bb2f:	0f b6 0a             	movzbl (%rdx),%ecx
    bb32:	80 f9 02             	cmp    $0x2,%cl
    bb35:	0f 84 6d 05 00 00    	je     c0a8 <fwp_main_thread+0x1658>
    bb3b:	80 f9 01             	cmp    $0x1,%cl
    bb3e:	75 39                	jne    bb79 <fwp_main_thread+0x1129>
    bb40:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bb43:	0f b7 c0             	movzwl %ax,%eax
    bb46:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bb49:	48 0f af c1          	imul   %rcx,%rax
    bb4d:	48 c1 e8 20          	shr    $0x20,%rax
    bb51:	48 39 d0             	cmp    %rdx,%rax
    bb54:	73 23                	jae    bb79 <fwp_main_thread+0x1129>
    bb56:	49 01 c5             	add    %rax,%r13
    bb59:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    bb5e:	84 c0                	test   %al,%al
    bb60:	74 17                	je     bb79 <fwp_main_thread+0x1129>
    bb62:	3c 01                	cmp    $0x1,%al
    bb64:	0f 84 fb 04 00 00    	je     c065 <fwp_main_thread+0x1615>
    bb6a:	3c ff                	cmp    $0xff,%al
    bb6c:	0f 84 44 05 00 00    	je     c0b6 <fwp_main_thread+0x1666>
    bb72:	83 e8 01             	sub    $0x1,%eax
    bb75:	41 88 45 00          	mov    %al,0x0(%r13)
    bb79:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
    bb80:	48 8b 40 10          	mov    0x10(%rax),%rax
    bb84:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
    bb8b:	48 85 c0             	test   %rax,%rax
    bb8e:	0f 84 71 06 00 00    	je     c205 <fwp_main_thread+0x17b5>
    bb94:	49 8b 8e b0 13 00 00 	mov    0x13b0(%r14),%rcx
    bb9b:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bba2:	e9 45 f9 ff ff       	jmp    b4ec <fwp_main_thread+0xa9c>
    bba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    bbae:	00 00 
    bbb0:	41 8b 96 a4 13 00 00 	mov    0x13a4(%r14),%edx
    bbb7:	8d 70 01             	lea    0x1(%rax),%esi
    bbba:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    bbc1:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    bbc8:	00 
    bbc9:	85 d2                	test   %edx,%edx
    bbcb:	0f 84 ac 03 00 00    	je     bf7d <fwp_main_thread+0x152d>
    bbd1:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    bbd8:	0f 87 9f 03 00 00    	ja     bf7d <fwp_main_thread+0x152d>
    bbde:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    bbe2:	48 c1 e8 04          	shr    $0x4,%rax
    bbe6:	41 0f b6 94 06 a0 0f 	movzbl 0xfa0(%r14,%rax,1),%edx
    bbed:	00 00 
    bbef:	41 8b 84 96 00 0f 00 	mov    0xf00(%r14,%rdx,4),%eax
    bbf6:	00 
    bbf7:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    bbfb:	49 8d 14 d6          	lea    (%r14,%rdx,8),%rdx
    bbff:	48 8b 1a             	mov    (%rdx),%rbx
    bc02:	48 85 db             	test   %rbx,%rbx
    bc05:	0f 84 50 03 00 00    	je     bf5b <fwp_main_thread+0x150b>
    bc0b:	4c 8b 1b             	mov    (%rbx),%r11
    bc0e:	49 f7 d3             	not    %r11
    bc11:	4c 89 1a             	mov    %r11,(%rdx)
    bc14:	48 39 c7             	cmp    %rax,%rdi
    bc17:	73 61                	jae    bc7a <fwp_main_thread+0x122a>
    bc19:	48 89 fa             	mov    %rdi,%rdx
    bc1c:	48 83 c7 08          	add    $0x8,%rdi
    bc20:	48 c7 04 f3 00 00 00 	movq   $0x0,(%rbx,%rsi,8)
    bc27:	00 
    bc28:	48 f7 d2             	not    %rdx
    bc2b:	48 01 c2             	add    %rax,%rdx
    bc2e:	48 c1 ea 03          	shr    $0x3,%rdx
    bc32:	48 39 c7             	cmp    %rax,%rdi
    bc35:	73 43                	jae    bc7a <fwp_main_thread+0x122a>
    bc37:	83 e2 01             	and    $0x1,%edx
    bc3a:	74 24                	je     bc60 <fwp_main_thread+0x1210>
    bc3c:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    bc43:	00 
    bc44:	48 83 c7 08          	add    $0x8,%rdi
    bc48:	48 39 c7             	cmp    %rax,%rdi
    bc4b:	73 2d                	jae    bc7a <fwp_main_thread+0x122a>
    bc4d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bc54:	00 
    bc55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bc5c:	00 00 00 00 
    bc60:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    bc67:	00 
    bc68:	48 c7 44 3b 08 00 00 	movq   $0x0,0x8(%rbx,%rdi,1)
    bc6f:	00 00 
    bc71:	48 83 c7 10          	add    $0x10,%rdi
    bc75:	48 39 c7             	cmp    %rax,%rdi
    bc78:	72 e6                	jb     bc60 <fwp_main_thread+0x1210>
    bc7a:	48 89 c2             	mov    %rax,%rdx
    bc7d:	49 03 96 20 14 00 00 	add    0x1420(%r14),%rdx
    bc84:	0f 82 76 05 00 00    	jb     c200 <fwp_main_thread+0x17b0>
    bc8a:	49 89 96 20 14 00 00 	mov    %rdx,0x1420(%r14)
    bc91:	49 39 96 28 14 00 00 	cmp    %rdx,0x1428(%r14)
    bc98:	73 07                	jae    bca1 <fwp_main_thread+0x1251>
    bc9a:	49 89 96 28 14 00 00 	mov    %rdx,0x1428(%r14)
    bca1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bca5:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    bcaa:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    bcb1:	00 00 
    bcb3:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    bcba:	00 00 
    bcbc:	66 41 0f 6e 02       	movd   (%r10),%xmm0
    bcc1:	66 0f 6e 8d 98 fe ff 	movd   -0x168(%rbp),%xmm1
    bcc8:	ff 
    bcc9:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    bccd:	66 0f d6 03          	movq   %xmm0,(%rbx)
    bcd1:	85 c9                	test   %ecx,%ecx
    bcd3:	74 3b                	je     bd10 <fwp_main_thread+0x12c0>
    bcd5:	89 ca                	mov    %ecx,%edx
    bcd7:	49 8d 72 08          	lea    0x8(%r10),%rsi
    bcdb:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    bcdf:	89 8d a8 fe ff ff    	mov    %ecx,-0x158(%rbp)
    bce5:	48 c1 e2 03          	shl    $0x3,%rdx
    bce9:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    bcf0:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    bcf7:	e8 14 79 ff ff       	call   3610 <memmove@plt>
    bcfc:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    bd03:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
    bd09:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    bd10:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    bd16:	85 c0                	test   %eax,%eax
    bd18:	74 3c                	je     bd56 <fwp_main_thread+0x1306>
    bd1a:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    bd20:	4c 89 e8             	mov    %r13,%rax
    bd23:	49 8d 7c d5 00       	lea    0x0(%r13,%rdx,8),%rdi
    bd28:	66 90                	xchg   %ax,%ax
    bd2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bd31:	00 00 00 00 
    bd35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bd3c:	00 00 00 00 
    bd40:	48 8b 30             	mov    (%rax),%rsi
    bd43:	89 ca                	mov    %ecx,%edx
    bd45:	48 83 c0 08          	add    $0x8,%rax
    bd49:	83 c1 01             	add    $0x1,%ecx
    bd4c:	48 89 74 d3 08       	mov    %rsi,0x8(%rbx,%rdx,8)
    bd51:	48 39 c7             	cmp    %rax,%rdi
    bd54:	75 ea                	jne    bd40 <fwp_main_thread+0x12f0>
    bd56:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bd5d:	4c 89 f8             	mov    %r15,%rax
    bd60:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bd67:	48 c1 e2 10          	shl    $0x10,%rdx
    bd6b:	48 39 d0             	cmp    %rdx,%rax
    bd6e:	73 54                	jae    bdc4 <fwp_main_thread+0x1374>
    bd70:	48 89 c2             	mov    %rax,%rdx
    bd73:	48 c1 ea 10          	shr    $0x10,%rdx
    bd77:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd7b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bd82:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd86:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    bd8a:	48 85 c9             	test   %rcx,%rcx
    bd8d:	74 35                	je     bdc4 <fwp_main_thread+0x1374>
    bd8f:	0f b6 32             	movzbl (%rdx),%esi
    bd92:	40 80 fe 02          	cmp    $0x2,%sil
    bd96:	0f 84 39 02 00 00    	je     bfd5 <fwp_main_thread+0x1585>
    bd9c:	40 80 fe 01          	cmp    $0x1,%sil
    bda0:	75 22                	jne    bdc4 <fwp_main_thread+0x1374>
    bda2:	8b 72 18             	mov    0x18(%rdx),%esi
    bda5:	0f b7 c0             	movzwl %ax,%eax
    bda8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bdab:	48 0f af c6          	imul   %rsi,%rax
    bdaf:	48 c1 e8 20          	shr    $0x20,%rax
    bdb3:	48 39 d0             	cmp    %rdx,%rax
    bdb6:	73 0c                	jae    bdc4 <fwp_main_thread+0x1374>
    bdb8:	48 01 c1             	add    %rax,%rcx
    bdbb:	80 39 01             	cmpb   $0x1,(%rcx)
    bdbe:	0f 84 7c 01 00 00    	je     bf40 <fwp_main_thread+0x14f0>
    bdc4:	49 8b 40 18          	mov    0x18(%r8),%rax
    bdc8:	be 01 00 00 00       	mov    $0x1,%esi
    bdcd:	4c 89 ff             	mov    %r15,%rdi
    bdd0:	ff 50 08             	call   *0x8(%rax)
    bdd3:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bdda:	48 89 d8             	mov    %rbx,%rax
    bddd:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bde4:	48 c1 e2 10          	shl    $0x10,%rdx
    bde8:	48 39 d0             	cmp    %rdx,%rax
    bdeb:	73 5b                	jae    be48 <fwp_main_thread+0x13f8>
    bded:	48 89 c2             	mov    %rax,%rdx
    bdf0:	48 c1 ea 10          	shr    $0x10,%rdx
    bdf4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bdf8:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bdff:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    be03:	4c 8b 69 20          	mov    0x20(%rcx),%r13
    be07:	4d 85 ed             	test   %r13,%r13
    be0a:	74 3c                	je     be48 <fwp_main_thread+0x13f8>
    be0c:	0f b6 31             	movzbl (%rcx),%esi
    be0f:	40 80 fe 02          	cmp    $0x2,%sil
    be13:	0f 84 9b 01 00 00    	je     bfb4 <fwp_main_thread+0x1564>
    be19:	40 80 fe 01          	cmp    $0x1,%sil
    be1d:	75 29                	jne    be48 <fwp_main_thread+0x13f8>
    be1f:	8b 71 18             	mov    0x18(%rcx),%esi
    be22:	0f b7 c0             	movzwl %ax,%eax
    be25:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    be28:	48 0f af c6          	imul   %rsi,%rax
    be2c:	48 c1 e8 20          	shr    $0x20,%rax
    be30:	48 39 c8             	cmp    %rcx,%rax
    be33:	73 13                	jae    be48 <fwp_main_thread+0x13f8>
    be35:	49 01 c5             	add    %rax,%r13
    be38:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    be3d:	0f 84 85 01 00 00    	je     bfc8 <fwp_main_thread+0x1578>
    be43:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    be48:	4c 89 ff             	mov    %r15,%rdi
    be4b:	49 89 df             	mov    %rbx,%r15
    be4e:	e8 7d aa ff ff       	call   68d0 <fwp_closure_drop>
    be53:	e9 c8 fa ff ff       	jmp    b920 <fwp_main_thread+0xed0>
    be58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    be5f:	00 
    be60:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    be67:	49 89 c7             	mov    %rax,%r15
    be6a:	e9 b1 fa ff ff       	jmp    b920 <fwp_main_thread+0xed0>
    be6f:	90                   	nop
    be70:	41 8b 75 00          	mov    0x0(%r13),%esi
    be74:	8b 05 a2 51 00 00    	mov    0x51a2(%rip),%eax        # 1101c <fc12+0x4>
    be7a:	89 f7                	mov    %esi,%edi
    be7c:	29 c7                	sub    %eax,%edi
    be7e:	83 ff 01             	cmp    $0x1,%edi
    be81:	0f 85 13 f7 ff ff    	jne    b59a <fwp_main_thread+0xb4a>
    be87:	48 89 e3             	mov    %rsp,%rbx
    be8a:	85 c0                	test   %eax,%eax
    be8c:	0f 84 6c 01 00 00    	je     bffe <fwp_main_thread+0x15ae>
    be92:	89 f1                	mov    %esi,%ecx
    be94:	ba 08 00 00 00       	mov    $0x8,%edx
    be99:	48 c1 e1 03          	shl    $0x3,%rcx
    be9d:	85 f6                	test   %esi,%esi
    be9f:	48 89 e6             	mov    %rsp,%rsi
    bea2:	48 0f 45 d1          	cmovne %rcx,%rdx
    bea6:	49 89 d7             	mov    %rdx,%r15
    bea9:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    bead:	48 c1 ea 04          	shr    $0x4,%rdx
    beb1:	48 c1 e2 04          	shl    $0x4,%rdx
    beb5:	48 89 d7             	mov    %rdx,%rdi
    beb8:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    bebf:	48 29 fe             	sub    %rdi,%rsi
    bec2:	48 39 f4             	cmp    %rsi,%rsp
    bec5:	74 15                	je     bedc <fwp_main_thread+0x148c>
    bec7:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    bece:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    bed5:	00 00 
    bed7:	48 39 f4             	cmp    %rsi,%rsp
    beda:	75 eb                	jne    bec7 <fwp_main_thread+0x1477>
    bedc:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    bee2:	48 29 d4             	sub    %rdx,%rsp
    bee5:	48 85 d2             	test   %rdx,%rdx
    bee8:	74 06                	je     bef0 <fwp_main_thread+0x14a0>
    beea:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    bef0:	4c 8d 24 c5 00 00 00 	lea    0x0(,%rax,8),%r12
    bef7:	00 
    bef8:	4c 89 f9             	mov    %r15,%rcx
    befb:	48 8d 35 1e 51 00 00 	lea    0x511e(%rip),%rsi        # 11020 <fwp_epfd>
    bf02:	48 89 e7             	mov    %rsp,%rdi
    bf05:	4c 89 e2             	mov    %r12,%rdx
    bf08:	e8 63 76 ff ff       	call   3570 <__memcpy_chk@plt>
    bf0d:	4d 39 e7             	cmp    %r12,%r15
    bf10:	4c 89 f9             	mov    %r15,%rcx
    bf13:	4a 8d 3c 24          	lea    (%rsp,%r12,1),%rdi
    bf17:	49 0f 42 cc          	cmovb  %r12,%rcx
    bf1b:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    bf22:	ba 08 00 00 00       	mov    $0x8,%edx
    bf27:	4c 29 e1             	sub    %r12,%rcx
    bf2a:	e8 41 76 ff ff       	call   3570 <__memcpy_chk@plt>
    bf2f:	49 8b 45 18          	mov    0x18(%r13),%rax
    bf33:	48 89 e7             	mov    %rsp,%rdi
    bf36:	ff 10                	call   *(%rax)
    bf38:	49 89 c7             	mov    %rax,%r15
    bf3b:	e9 ca 00 00 00       	jmp    c00a <fwp_main_thread+0x15ba>
    bf40:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    bf47:	00 
    bf48:	e9 86 fe ff ff       	jmp    bdd3 <fwp_main_thread+0x1383>
    bf4d:	66 85 c0             	test   %ax,%ax
    bf50:	0f 85 c1 f6 ff ff    	jne    b617 <fwp_main_thread+0xbc7>
    bf56:	e9 a8 f6 ff ff       	jmp    b603 <fwp_main_thread+0xbb3>
    bf5b:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    bf5f:	48 85 db             	test   %rbx,%rbx
    bf62:	74 19                	je     bf7d <fwp_main_thread+0x152d>
    bf64:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    bf68:	49 29 db             	sub    %rbx,%r11
    bf6b:	49 39 c3             	cmp    %rax,%r11
    bf6e:	72 0d                	jb     bf7d <fwp_main_thread+0x152d>
    bf70:	4c 8d 1c 03          	lea    (%rbx,%rax,1),%r11
    bf74:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    bf78:	e9 97 fc ff ff       	jmp    bc14 <fwp_main_thread+0x11c4>
    bf7d:	31 f6                	xor    %esi,%esi
    bf7f:	89 8d 90 fe ff ff    	mov    %ecx,-0x170(%rbp)
    bf85:	4c 89 85 a8 fe ff ff 	mov    %r8,-0x158(%rbp)
    bf8c:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    bf93:	e8 b8 9a ff ff       	call   5a50 <fwp_heap_alloc>
    bf98:	8b 8d 90 fe ff ff    	mov    -0x170(%rbp),%ecx
    bf9e:	4c 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%r8
    bfa5:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    bfac:	48 89 c3             	mov    %rax,%rbx
    bfaf:	e9 08 fd ff ff       	jmp    bcbc <fwp_main_thread+0x126c>
    bfb4:	66 85 c0             	test   %ax,%ax
    bfb7:	0f 85 8b fe ff ff    	jne    be48 <fwp_main_thread+0x13f8>
    bfbd:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    bfc2:	0f 85 7b fe ff ff    	jne    be43 <fwp_main_thread+0x13f3>
    bfc8:	4c 89 ef             	mov    %r13,%rdi
    bfcb:	e8 40 93 ff ff       	call   5310 <fwp_rc_forget_slot>
    bfd0:	e9 6e fe ff ff       	jmp    be43 <fwp_main_thread+0x13f3>
    bfd5:	66 85 c0             	test   %ax,%ax
    bfd8:	0f 85 e6 fd ff ff    	jne    bdc4 <fwp_main_thread+0x1374>
    bfde:	e9 d8 fd ff ff       	jmp    bdbb <fwp_main_thread+0x136b>
    bfe3:	e8 08 92 ff ff       	call   51f0 <fwp_rc_wide_dup>
    bfe8:	48 8b 15 e9 73 01 00 	mov    0x173e9(%rip),%rdx        # 233d8 <fwp_fns>
    bfef:	e9 23 f6 ff ff       	jmp    b617 <fwp_main_thread+0xbc7>
    bff4:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    bff9:	e9 31 ec ff ff       	jmp    ac2f <fwp_main_thread+0x1df>
    bffe:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
    c005:	ff 11                	call   *(%rcx)
    c007:	49 89 c7             	mov    %rax,%r15
    c00a:	48 89 dc             	mov    %rbx,%rsp
    c00d:	e9 a9 f9 ff ff       	jmp    b9bb <fwp_main_thread+0xf6b>
    c012:	66 85 c0             	test   %ax,%ax
    c015:	0f 85 41 f5 ff ff    	jne    b55c <fwp_main_thread+0xb0c>
    c01b:	e9 28 f5 ff ff       	jmp    b548 <fwp_main_thread+0xaf8>
    c020:	66 85 c0             	test   %ax,%ax
    c023:	0f 85 a7 f4 ff ff    	jne    b4d0 <fwp_main_thread+0xa80>
    c029:	e9 88 f4 ff ff       	jmp    b4b6 <fwp_main_thread+0xa66>
    c02e:	66 85 c0             	test   %ax,%ax
    c031:	0f 85 33 f3 ff ff    	jne    b36a <fwp_main_thread+0x91a>
    c037:	e9 22 f3 ff ff       	jmp    b35e <fwp_main_thread+0x90e>
    c03c:	66 85 c0             	test   %ax,%ax
    c03f:	0f 85 cb f3 ff ff    	jne    b410 <fwp_main_thread+0x9c0>
    c045:	e9 ba f3 ff ff       	jmp    b404 <fwp_main_thread+0x9b4>
    c04a:	48 89 d7             	mov    %rdx,%rdi
    c04d:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c054:	e8 b7 92 ff ff       	call   5310 <fwp_rc_forget_slot>
    c059:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c060:	e9 c0 f1 ff ff       	jmp    b225 <fwp_main_thread+0x7d5>
    c065:	48 89 df             	mov    %rbx,%rdi
    c068:	e8 63 a4 ff ff       	call   64d0 <fwp_rc_free_arr>
    c06d:	e9 07 fb ff ff       	jmp    bb79 <fwp_main_thread+0x1129>
    c072:	48 89 d7             	mov    %rdx,%rdi
    c075:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c07c:	e8 8f 92 ff ff       	call   5310 <fwp_rc_forget_slot>
    c081:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c088:	e9 36 fa ff ff       	jmp    bac3 <fwp_main_thread+0x1073>
    c08d:	48 89 df             	mov    %rbx,%rdi
    c090:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c097:	e8 74 92 ff ff       	call   5310 <fwp_rc_forget_slot>
    c09c:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c0a3:	e9 bf f2 ff ff       	jmp    b367 <fwp_main_thread+0x917>
    c0a8:	66 85 c0             	test   %ax,%ax
    c0ab:	0f 85 c8 fa ff ff    	jne    bb79 <fwp_main_thread+0x1129>
    c0b1:	e9 a3 fa ff ff       	jmp    bb59 <fwp_main_thread+0x1109>
    c0b6:	4c 89 e8             	mov    %r13,%rax
    c0b9:	48 c1 e8 11          	shr    $0x11,%rax
    c0bd:	4c 31 e8             	xor    %r13,%rax
    c0c0:	48 89 c2             	mov    %rax,%rdx
    c0c3:	48 c1 ea 09          	shr    $0x9,%rdx
    c0c7:	48 31 d0             	xor    %rdx,%rax
    c0ca:	0f b6 c0             	movzbl %al,%eax
    c0cd:	49 8b 94 c6 48 14 00 	mov    0x1448(%r14,%rax,8),%rdx
    c0d4:	00 
    c0d5:	48 85 d2             	test   %rdx,%rdx
    c0d8:	75 0f                	jne    c0e9 <fwp_main_thread+0x1699>
    c0da:	eb 6f                	jmp    c14b <fwp_main_thread+0x16fb>
    c0dc:	0f 1f 40 00          	nopl   0x0(%rax)
    c0e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    c0e4:	48 85 d2             	test   %rdx,%rdx
    c0e7:	74 62                	je     c14b <fwp_main_thread+0x16fb>
    c0e9:	48 89 d0             	mov    %rdx,%rax
    c0ec:	4c 39 2a             	cmp    %r13,(%rdx)
    c0ef:	75 ef                	jne    c0e0 <fwp_main_thread+0x1690>
    c0f1:	48 8b 42 08          	mov    0x8(%rdx),%rax
    c0f5:	48 83 e8 01          	sub    $0x1,%rax
    c0f9:	48 89 42 08          	mov    %rax,0x8(%rdx)
    c0fd:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    c103:	0f 85 70 fa ff ff    	jne    bb79 <fwp_main_thread+0x1129>
    c109:	4c 89 ef             	mov    %r13,%rdi
    c10c:	e8 ff 91 ff ff       	call   5310 <fwp_rc_forget_slot>
    c111:	41 c6 45 00 fe       	movb   $0xfe,0x0(%r13)
    c116:	e9 5e fa ff ff       	jmp    bb79 <fwp_main_thread+0x1129>
    c11b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    c120:	66 85 c0             	test   %ax,%ax
    c123:	0f 85 9d f9 ff ff    	jne    bac6 <fwp_main_thread+0x1076>
    c129:	e9 8c f9 ff ff       	jmp    baba <fwp_main_thread+0x106a>
    c12e:	48 83 3d 22 56 01 00 	cmpq   $0x0,0x15622(%rip)        # 21758 <fwp_root>
    c135:	00 
    c136:	c7 05 60 4f 01 00 00 	movl   $0x0,0x14f60(%rip)        # 210a0 <fwp_exit_code>
    c13d:	00 00 00 
    c140:	0f 84 c4 ed ff ff    	je     af0a <fwp_main_thread+0x4ba>
    c146:	e9 05 76 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c14b:	48 8d 3d 46 16 00 00 	lea    0x1646(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    c152:	e8 49 80 ff ff       	call   41a0 <fwp_trap>
    c157:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    c15e:	00 00 
    c160:	48 89 df             	mov    %rbx,%rdi
    c163:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c16a:	e8 a1 91 ff ff       	call   5310 <fwp_rc_forget_slot>
    c16f:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c176:	e9 92 f2 ff ff       	jmp    b40d <fwp_main_thread+0x9bd>
    c17b:	48 89 df             	mov    %rbx,%rdi
    c17e:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c185:	e8 86 91 ff ff       	call   5310 <fwp_rc_forget_slot>
    c18a:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c191:	e9 29 f3 ff ff       	jmp    b4bf <fwp_main_thread+0xa6f>
    c196:	e8 55 90 ff ff       	call   51f0 <fwp_rc_wide_dup>
    c19b:	e9 bc f3 ff ff       	jmp    b55c <fwp_main_thread+0xb0c>
    c1a0:	e8 bb 72 ff ff       	call   3460 <__stack_chk_fail@plt>
    c1a5:	48 8d 3d 44 17 00 00 	lea    0x1744(%rip),%rdi        # d8f0 <_IO_stdin_used+0x8f0>
    c1ac:	e8 ef 7f ff ff       	call   41a0 <fwp_trap>
    c1b1:	48 89 c7             	mov    %rax,%rdi
    c1b4:	4c 8d 3d 5d 4e 00 00 	lea    0x4e5d(%rip),%r15        # 11018 <fc12>
    c1bb:	e8 90 a2 ff ff       	call   6450 <fwp_rc_share>
    c1c0:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c1c7:	e8 84 a2 ff ff       	call   6450 <fwp_rc_share>
    c1cc:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
    c1d3:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    c1da:	00 00 00 
    c1dd:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    c1e4:	e9 ba f7 ff ff       	jmp    b9a3 <fwp_main_thread+0xf53>
    c1e9:	48 8d 3d f8 0f 00 00 	lea    0xff8(%rip),%rdi        # d1e8 <_IO_stdin_used+0x1e8>
    c1f0:	e8 ab 7f ff ff       	call   41a0 <fwp_trap>
    c1f5:	48 89 c8             	mov    %rcx,%rax
    c1f8:	e9 79 ec ff ff       	jmp    ae76 <fwp_main_thread+0x426>
    c1fd:	0f 1f 00             	nopl   (%rax)
    c200:	e8 ab 7a ff ff       	call   3cb0 <fwp_heap_oom>
    c205:	4c 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%r8
    c20c:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c213:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c21a:	e8 c1 a3 ff ff       	call   65e0 <fwp_drop0>
    c21f:	48 8b bd b8 fe ff ff 	mov    -0x148(%rbp),%rdi
    c226:	e8 b5 a3 ff ff       	call   65e0 <fwp_drop0>
    c22b:	48 c7 05 52 4e 00 00 	movq   $0x0,0x4e52(%rip)        # 11088 <v.2>
    c232:	00 00 00 00 
    c236:	c7 05 50 4e 00 00 01 	movl   $0x1,0x4e50(%rip)        # 11090 <st.3>
    c23d:	00 00 00 
    c240:	e9 2c e9 ff ff       	jmp    ab71 <fwp_main_thread+0x121>
    c245:	e9 06 75 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c24a:	e9 01 75 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c24f:	90                   	nop

000000000000c250 <__divmodti4>:
    c250:	f3 0f 1e fa          	endbr64
    c254:	55                   	push   %rbp
    c255:	49 89 f1             	mov    %rsi,%r9
    c258:	49 89 d2             	mov    %rdx,%r10
    c25b:	48 89 fe             	mov    %rdi,%rsi
    c25e:	49 89 cb             	mov    %rcx,%r11
    c261:	48 89 e5             	mov    %rsp,%rbp
    c264:	41 57                	push   %r15
    c266:	41 56                	push   %r14
    c268:	41 55                	push   %r13
    c26a:	41 54                	push   %r12
    c26c:	53                   	push   %rbx
    c26d:	4c 89 c3             	mov    %r8,%rbx
    c270:	45 31 c0             	xor    %r8d,%r8d
    c273:	4d 85 c9             	test   %r9,%r9
    c276:	79 12                	jns    c28a <__divmodti4+0x3a>
    c278:	31 ff                	xor    %edi,%edi
    c27a:	48 f7 de             	neg    %rsi
    c27d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    c284:	4c 19 cf             	sbb    %r9,%rdi
    c287:	49 89 f9             	mov    %rdi,%r9
    c28a:	4c 89 d8             	mov    %r11,%rax
    c28d:	4d 85 db             	test   %r11,%r11
    c290:	0f 88 1a 01 00 00    	js     c3b0 <__divmodti4+0x160>
    c296:	4c 89 d9             	mov    %r11,%rcx
    c299:	49 89 f3             	mov    %rsi,%r11
    c29c:	75 62                	jne    c300 <__divmodti4+0xb0>
    c29e:	4d 89 c4             	mov    %r8,%r12
    c2a1:	4d 39 d1             	cmp    %r10,%r9
    c2a4:	0f 83 46 01 00 00    	jae    c3f0 <__divmodti4+0x1a0>
    c2aa:	4c 89 d8             	mov    %r11,%rax
    c2ad:	4c 89 ca             	mov    %r9,%rdx
    c2b0:	49 f7 f2             	div    %r10
    c2b3:	49 89 c3             	mov    %rax,%r11
    c2b6:	31 c0                	xor    %eax,%eax
    c2b8:	48 89 d6             	mov    %rdx,%rsi
    c2bb:	31 ff                	xor    %edi,%edi
    c2bd:	4c 89 d9             	mov    %r11,%rcx
    c2c0:	48 89 c2             	mov    %rax,%rdx
    c2c3:	48 89 c8             	mov    %rcx,%rax
    c2c6:	4d 85 e4             	test   %r12,%r12
    c2c9:	74 0a                	je     c2d5 <__divmodti4+0x85>
    c2cb:	48 f7 d8             	neg    %rax
    c2ce:	48 83 d2 00          	adc    $0x0,%rdx
    c2d2:	48 f7 da             	neg    %rdx
    c2d5:	4d 85 c0             	test   %r8,%r8
    c2d8:	74 0a                	je     c2e4 <__divmodti4+0x94>
    c2da:	48 f7 de             	neg    %rsi
    c2dd:	48 83 d7 00          	adc    $0x0,%rdi
    c2e1:	48 f7 df             	neg    %rdi
    c2e4:	48 89 33             	mov    %rsi,(%rbx)
    c2e7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    c2eb:	5b                   	pop    %rbx
    c2ec:	41 5c                	pop    %r12
    c2ee:	41 5d                	pop    %r13
    c2f0:	41 5e                	pop    %r14
    c2f2:	41 5f                	pop    %r15
    c2f4:	5d                   	pop    %rbp
    c2f5:	c3                   	ret
    c2f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c2fd:	00 00 00 
    c300:	4d 89 c4             	mov    %r8,%r12
    c303:	49 39 c1             	cmp    %rax,%r9
    c306:	0f 82 ce 00 00 00    	jb     c3da <__divmodti4+0x18a>
    c30c:	31 ff                	xor    %edi,%edi
    c30e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    c313:	48 63 c7             	movslq %edi,%rax
    c316:	be 40 00 00 00       	mov    $0x40,%esi
    c31b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    c320:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    c325:	48 29 c6             	sub    %rax,%rsi
    c328:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    c32d:	48 09 c8             	or     %rcx,%rax
    c330:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    c335:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    c33a:	49 89 c6             	mov    %rax,%r14
    c33d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    c341:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    c346:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    c34b:	49 09 c1             	or     %rax,%r9
    c34e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    c352:	4c 89 c8             	mov    %r9,%rax
    c355:	49 f7 f6             	div    %r14
    c358:	48 89 d1             	mov    %rdx,%rcx
    c35b:	49 89 c3             	mov    %rax,%r11
    c35e:	49 89 c1             	mov    %rax,%r9
    c361:	49 f7 e2             	mul    %r10
    c364:	49 89 c6             	mov    %rax,%r14
    c367:	49 89 d2             	mov    %rdx,%r10
    c36a:	48 39 d1             	cmp    %rdx,%rcx
    c36d:	72 07                	jb     c376 <__divmodti4+0x126>
    c36f:	75 17                	jne    c388 <__divmodti4+0x138>
    c371:	49 39 c7             	cmp    %rax,%r15
    c374:	73 12                	jae    c388 <__divmodti4+0x138>
    c376:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    c37a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    c37e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    c382:	49 89 d2             	mov    %rdx,%r10
    c385:	49 89 c6             	mov    %rax,%r14
    c388:	4c 89 f8             	mov    %r15,%rax
    c38b:	4c 29 f0             	sub    %r14,%rax
    c38e:	4c 19 d1             	sbb    %r10,%rcx
    c391:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    c396:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    c39b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    c3a0:	48 09 c6             	or     %rax,%rsi
    c3a3:	48 89 cf             	mov    %rcx,%rdi
    c3a6:	31 c0                	xor    %eax,%eax
    c3a8:	4c 89 c9             	mov    %r9,%rcx
    c3ab:	e9 10 ff ff ff       	jmp    c2c0 <__divmodti4+0x70>
    c3b0:	4c 89 d0             	mov    %r10,%rax
    c3b3:	4c 89 da             	mov    %r11,%rdx
    c3b6:	4d 89 c4             	mov    %r8,%r12
    c3b9:	49 89 f3             	mov    %rsi,%r11
    c3bc:	48 f7 d8             	neg    %rax
    c3bf:	49 f7 d4             	not    %r12
    c3c2:	48 83 d2 00          	adc    $0x0,%rdx
    c3c6:	49 89 c2             	mov    %rax,%r10
    c3c9:	48 f7 da             	neg    %rdx
    c3cc:	48 89 d1             	mov    %rdx,%rcx
    c3cf:	0f 84 cc fe ff ff    	je     c2a1 <__divmodti4+0x51>
    c3d5:	49 39 d1             	cmp    %rdx,%r9
    c3d8:	73 46                	jae    c420 <__divmodti4+0x1d0>
    c3da:	4c 89 cf             	mov    %r9,%rdi
    c3dd:	31 c0                	xor    %eax,%eax
    c3df:	31 c9                	xor    %ecx,%ecx
    c3e1:	e9 da fe ff ff       	jmp    c2c0 <__divmodti4+0x70>
    c3e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c3ed:	00 00 00 
    c3f0:	4d 85 d2             	test   %r10,%r10
    c3f3:	75 0d                	jne    c402 <__divmodti4+0x1b2>
    c3f5:	b8 01 00 00 00       	mov    $0x1,%eax
    c3fa:	31 d2                	xor    %edx,%edx
    c3fc:	49 f7 f2             	div    %r10
    c3ff:	49 89 c2             	mov    %rax,%r10
    c402:	4c 89 c8             	mov    %r9,%rax
    c405:	31 d2                	xor    %edx,%edx
    c407:	49 f7 f2             	div    %r10
    c40a:	49 89 c1             	mov    %rax,%r9
    c40d:	4c 89 d8             	mov    %r11,%rax
    c410:	49 f7 f2             	div    %r10
    c413:	49 89 c3             	mov    %rax,%r11
    c416:	4c 89 c8             	mov    %r9,%rax
    c419:	e9 9a fe ff ff       	jmp    c2b8 <__divmodti4+0x68>
    c41e:	66 90                	xchg   %ax,%ax
    c420:	45 31 f6             	xor    %r14d,%r14d
    c423:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    c428:	44 89 f7             	mov    %r14d,%edi
    c42b:	45 85 f6             	test   %r14d,%r14d
    c42e:	0f 85 df fe ff ff    	jne    c313 <__divmodti4+0xc3>
    c434:	4c 39 ca             	cmp    %r9,%rdx
    c437:	72 17                	jb     c450 <__divmodti4+0x200>
    c439:	31 c9                	xor    %ecx,%ecx
    c43b:	48 39 c6             	cmp    %rax,%rsi
    c43e:	73 10                	jae    c450 <__divmodti4+0x200>
    c440:	4c 89 cf             	mov    %r9,%rdi
    c443:	31 c0                	xor    %eax,%eax
    c445:	e9 76 fe ff ff       	jmp    c2c0 <__divmodti4+0x70>
    c44a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c450:	4c 89 de             	mov    %r11,%rsi
    c453:	b9 01 00 00 00       	mov    $0x1,%ecx
    c458:	48 29 c6             	sub    %rax,%rsi
    c45b:	49 19 d1             	sbb    %rdx,%r9
    c45e:	eb e0                	jmp    c440 <__divmodti4+0x1f0>

000000000000c460 <atexit>:
    c460:	f3 0f 1e fa          	endbr64
    c464:	48 8b 15 9d 4b 00 00 	mov    0x4b9d(%rip),%rdx        # 11008 <__dso_handle>
    c46b:	31 f6                	xor    %esi,%esi
    c46d:	e9 ee 71 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000c474 <_fini>:
    c474:	f3 0f 1e fa          	endbr64
    c478:	48 83 ec 08          	sub    $0x8,%rsp
    c47c:	48 83 c4 08          	add    $0x8,%rsp
    c480:	c3                   	ret
