__attribute__((noinline)) void parser_memory_checkpoint(unsigned phase) {
    __asm__ __volatile__("" : : "r"(phase) : "memory");
}
